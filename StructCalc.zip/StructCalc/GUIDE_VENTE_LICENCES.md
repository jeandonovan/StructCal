# StructCalc – Guide de l'auteur : licences, vente, connexion « Créateur »

Auteur : Maximilien EKRESSIN – jeandonovan33@gmail.com – +225 0777505213 / +225 0799518100

> Ce guide est PRIVÉ. Ne le donnez pas aux clients, ni le dossier `tools`, ni `private_key.xml`.

## 1. Comment marche la protection (en clair)
- Chaque PC a un **numéro de machine** (ex. `A1B2-C3D4-E5F6-0789`).
- Une licence est un petit fichier `.lic` **signé avec votre clé privée**. Le logiciel contient seulement la **clé publique** : il peut vérifier une licence, jamais en fabriquer.
- Une licence est liée à **un seul PC**. Copiée ailleurs, elle est refusée.
- Sans licence : essai de 30 jours, 40 barres maximum, plans avec filigrane « EVALUATION ».
- Éditions : `PRO`, `ENTREPRISE`, `ETUDIANT` (60 barres), `CREATEUR` (à vie, sans limite, c'est la vôtre).

## 2. Mise en place (une seule fois)
1. Double-cliquez **`outils_auteur.bat`** → menu **1 – Générer les clés**.
   Les fichiers sont créés dans `C:\Users\<vous>\StructCalc_Auteur\` : `private_key.xml` (SECRET), `public_key.xml`, `LicensePublicKey.snippet.txt`.
2. **Sauvegardez `private_key.xml`** sur 2 supports (clé USB + cloud privé). Si vous la perdez, vous ne pourrez plus émettre de licences compatibles ; si elle fuit, n'importe qui peut en fabriquer.
3. Ouvrez `LicensePublicKey.snippet.txt`, copiez son contenu dans `src\StructCalc.Core\Licensing\LicensePublicKey.cs` (remplace la clé vide).
4. Recompilez (`restaurer_compiler_tester.bat`). À partir de là, le logiciel n'est plus en « mode développement ».

## 3. Vous connecter avec VOTRE licence Créateur
1. Lancez `outils_auteur.bat` → menu **3 – Créer ma licence CRÉATEUR**.
   Elle est créée pour **votre PC** et **installée automatiquement**.
2. Lancez StructCalc : la barre de titre affiche **★ LICENCE CRÉATEUR** et la barre d'état « Licence CRÉATEUR – accès complet, sans limite ».
3. Menu Aide/Licence : vous voyez ★ et votre numéro de machine.
4. Autre PC à vous (portable) : ouvrez la fenêtre Licence sur ce PC, copiez son numéro, puis menu **4** en choisissant l'édition CREATEUR, et importez le `.lic` obtenu.

## 4. Vendre une licence – le parcours client
1. Le client installe StructCalc (ZIP produit par `publier_version.bat`) et ouvre **Licence**.
2. Il saisit son nom/téléphone et clique **WhatsApp** ou **E-mail** : la demande contenant son numéro de machine vous arrive toute prête.
3. Vous convenez du prix et vous encaissez (Orange Money, MTN MoMo, Wave, virement…). **Pas de paiement = pas de licence.**
4. `outils_auteur.bat` → menu **4 – Émettre une licence client** : nom, e-mail, numéro de machine, édition, durée (jours, vide = perpétuelle), nombre de barres max, prix, mode de paiement.
   Le fichier `.lic` est créé dans `StructCalc_Auteur\licences\` et la vente est inscrite dans `ventes.csv`.
5. Envoyez le `.lic` au client (WhatsApp/mail). Il clique **Importer une licence** → statut ✔ « Licence valide ».

## 5. Suivi
- Menu **5 – Registre des ventes** : liste, total encaissé, licences à renouveler dans les 30 jours.
- `ventes.csv` s'ouvre dans Excel (séparateur point-virgule).
- Menu **6 – Vérifier un .lic** : utile quand un client dit « ça ne marche pas » (mauvaise machine ? expirée ? fichier modifié ?).
- Changement de PC du client : il vous renvoie son nouveau numéro, vous émettez une nouvelle licence (décidez d'une politique : 1 transfert gratuit par an, par exemple).

## 6. Grille de prix indicative (à adapter à votre marché)
| Édition | Usage | Idée de prix |
|---|---|---|
| ETUDIANT | 60 barres, justificatif étudiant | 15 000 – 25 000 FCFA / an |
| PRO | 1 poste, bureau d'études | 150 000 – 300 000 FCFA / an |
| ENTREPRISE | plusieurs postes (1 licence par poste, remise dès 3) | à négocier |
Proposez une location annuelle (renouvellement = revenu régulier) plutôt qu'un achat unique.

## 7. Publier une version à vendre
1. Double-cliquez **`publier_version.bat`**.
2. L'**obfuscation est automatique** (Obfuscar, via `obfuscar.xml`) : plus rien à faire à la main. Vérifiez seulement que le logiciel démarre depuis `publish\StructCalc` avant d'envoyer.
3. Le script **signe ensuite le dossier** (`integrity.sig`) puis crée `publish\StructCalc_client.zip`.
4. ⚠ La signature se fait **après** l'obfuscation et **uniquement** sur le dossier publié. Si vous signez avant, ou si vous modifiez un fichier ensuite, le logiciel affichera « intégrité compromise ».
5. Ne livrez **jamais** une version Debug (elle contourne la licence), ni `tools\`, ni `private_key.xml`.

## 8. Limites honnêtes
Aucune protection locale n'est infaillible : celle-ci décourage 95 % des copies. Pour aller plus loin : activation en ligne (petit serveur), signature de code (certificat), licences à durée courte renouvelées en ligne.

## 9. Légal
Faites relire le contrat d'utilisation (`CLUF_MODELE.md`) par un juriste de votre pays et déclarez votre activité (OHADA / régime fiscal local).
