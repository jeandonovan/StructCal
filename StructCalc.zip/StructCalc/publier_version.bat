@echo off
chcp 65001 >nul
title StructCalc - Publication d'une version a vendre
cd /d "%~dp0"
set OUT=%~dp0publish\StructCalc
echo ============================================================
echo   Choix du mode de livraison
echo   1 = AUTONOME (recommande) : fonctionne sur n'importe quel Windows 10/11 64 bits,
echo       sans rien installer (le runtime .NET est inclus, dossier ~150 Mo)
echo   2 = LEGER : petit dossier, mais le client doit installer ".NET 8 Desktop Runtime"
echo ============================================================
set /p MODE="Votre choix (1 ou 2) : "
set SC=true
if "%MODE%"=="2" set SC=false
echo [1/5] Publication Release (sans symboles de debug)...
if exist "%OUT%" rmdir /s /q "%OUT%"
dotnet publish src\StructCalc.App -c Release -r win-x64 --self-contained %SC% -o "%OUT%" -p:DebugType=None -p:DebugSymbols=false
if errorlevel 1 goto err
echo.
echo [1b] Complement Revit 2025 (facultatif : necessite Revit 2025 sur CETTE machine)...
if not defined REVITDIR set "REVITDIR=C:\Program Files\Autodesk\Revit 2025"
set HASREVIT=0
if exist "%REVITDIR%\RevitAPI.dll" (
  if exist "%~dp0publish\_revit" rmdir /s /q "%~dp0publish\_revit"
  dotnet publish src\StructCalc.RevitAddin -c Release -o "%~dp0publish\_revit" -p:NoDeploy=true -p:RevitDir="%REVITDIR%" -p:DebugType=None -p:DebugSymbols=false
  if not errorlevel 1 (
    copy /y "%~dp0publish\_revit\StructCalc.RevitAddin.dll" "%OUT%\" >nul
    set HASREVIT=1
  )
)
if "%HASREVIT%"=="1" (echo      Complement Revit compile.) else (echo      Revit 2025 introuvable ou compilation impossible : le complement Revit n'est PAS inclus.)
echo.
echo [2/5] Obfuscation automatique du code (Obfuscar)...
set DOTNET_ROLL_FORWARD=Major
dotnet tool update --global Obfuscar.GlobalTool >nul 2>&1
if exist "%~dp0publish\_obf" rmdir /s /q "%~dp0publish\_obf"
set OBFCFG=obfuscar.xml
if "%HASREVIT%"=="1" (
  powershell -NoProfile -Command "(Get-Content '%~dp0obfuscar_revit.xml' -Raw).Replace('@@REVITDIR@@','%REVITDIR%') | Set-Content '%~dp0publish\obfuscar_revit_run.xml' -Encoding UTF8"
  set "OBFCFG=publish\obfuscar_revit_run.xml"
)
"%USERPROFILE%\.dotnet\tools\obfuscar.console.exe" %OBFCFG%
if errorlevel 1 goto noobf
if not exist "%~dp0publish\_obf\StructCalc.Engine.dll" goto noobf
copy /y "%~dp0publish\_obf\StructCalc.*.dll" "%OUT%\" >nul
echo      Code obfusque. Table de correspondance privee : publish\_obf\Mapping.txt (ne pas distribuer).
goto packrevit
:noobf
echo.
echo  !! L'obfuscation a echoue (voir ci-dessus). Le dossier n'est PAS obfusque.
set /p GO="Continuer quand meme ? (O/N) : "
if /i not "%GO%"=="O" goto err
:packrevit
if "%HASREVIT%"=="1" (
  set "REV=%~dp0publish\StructCalc_Revit"
  if exist "%~dp0publish\StructCalc_Revit" rmdir /s /q "%~dp0publish\StructCalc_Revit"
  mkdir "%~dp0publish\StructCalc_Revit\StructCalc"
  copy /y "%OUT%\StructCalc.Core.dll" "%~dp0publish\StructCalc_Revit\StructCalc\" >nul
  copy /y "%OUT%\StructCalc.Engine.dll" "%~dp0publish\StructCalc_Revit\StructCalc\" >nul
  copy /y "%OUT%\StructCalc.RevitAddin.dll" "%~dp0publish\StructCalc_Revit\StructCalc\" >nul
  copy /y "%~dp0src\StructCalc.RevitAddin\StructCalc.addin" "%~dp0publish\StructCalc_Revit\" >nul
  copy /y "%~dp0installer_complement_revit.bat" "%~dp0publish\StructCalc_Revit\" >nul
  del "%OUT%\StructCalc.RevitAddin.dll"
  if exist "%~dp0publish\StructCalc_Revit.zip" del "%~dp0publish\StructCalc_Revit.zip"
  powershell -NoProfile -Command "Compress-Archive -Path '%~dp0publish\StructCalc_Revit\*' -DestinationPath '%~dp0publish\StructCalc_Revit.zip'"
  echo      Complement Revit : publish\StructCalc_Revit.zip ^(a donner avec l'application : installer_complement_revit.bat^)
)
:sign
echo [3/5] Signature d'integrite du dossier...
set TOOL=%~dp0publish\_outil_signature
if exist "%TOOL%" rmdir /s /q "%TOOL%"
dotnet publish tools\StructCalc.LicenseGen -c Release -o "%TOOL%" --self-contained false
if errorlevel 1 goto err
"%TOOL%\StructCalc.LicenseGen.exe" sign-build "%OUT%"
if errorlevel 1 goto err
echo [4/5] Creation du ZIP a donner aux clients...
if exist "%~dp0publish\StructCalc_client.zip" del "%~dp0publish\StructCalc_client.zip"
powershell -NoProfile -Command "Compress-Archive -Path '%OUT%\*' -DestinationPath '%~dp0publish\StructCalc_client.zip'"
echo [5/5] Installateur Setup.exe (si Inno Setup 6 est installe)...
set ISCC=
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set ISCC=%%~P
if not defined ISCC (
  echo Inno Setup absent : installation automatique...
  winget install --id JRSoftware.InnoSetup -e --silent --accept-package-agreements --accept-source-agreements
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set ISCC=%%~P
)
if defined ISCC (
  "%ISCC%" /Qp installateur.iss
  echo Installateur : publish\StructCalc_Setup.exe
) else (
  echo Inno Setup introuvable : lancez installer_inno_setup.bat puis relancez cette publication.
)
echo.
echo TERMINE. A donner aux clients : publish\StructCalc_client.zip  ou  publish\StructCalc_Setup.exe  (+ publish\StructCalc_Revit.zip pour Revit)
echo (jamais le code source, ni tools\, ni private_key.xml)
pause
exit /b 0
:err
echo ERREUR - voir ci-dessus.
pause
exit /b 1
