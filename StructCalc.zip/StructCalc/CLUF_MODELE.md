# Contrat de licence utilisateur final (CLUF) – MODÈLE À FAIRE RELIRE PAR UN JURISTE

**Logiciel** : StructCalc – **Éditeur** : Maximilien EKRESSIN (jeandonovan33@gmail.com)

1. **Licence.** L'éditeur concède au client un droit d'utilisation non exclusif et non transférable, sur un seul poste (identifié par son numéro de machine), pour la durée indiquée sur la licence.
2. **Interdictions.** Copier la licence, la partager, contourner la protection, décompiler, modifier, revendre ou louer le logiciel.
3. **Responsabilité de l'ingénieur.** StructCalc est un outil d'aide. Les résultats et les plans (dessins de principe) doivent être vérifiés, validés et signés par l'ingénieur responsable. L'éditeur ne peut être tenu responsable d'un dommage résultant d'une utilisation sans vérification.
4. **Garantie.** Le logiciel est fourni « en l'état ». Responsabilité limitée au prix payé pour la licence.
5. **Support & mises à jour.** Selon l'édition achetée (à préciser).
6. **Résiliation.** Toute violation met fin immédiatement à la licence, sans remboursement.
7. **Droit applicable.** Droit du pays de l'éditeur ; tribunaux compétents à préciser.
