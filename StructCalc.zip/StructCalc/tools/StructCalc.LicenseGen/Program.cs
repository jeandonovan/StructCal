using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Licensing;

// OUTIL DE L'AUTEUR - NE JAMAIS DISTRIBUER (il manipule la clé privée).
// Sans argument : menu interactif (recommandé).  Avec arguments :
//   genkeys | machineid | creator | issue <nom> <email> <machineId> <jours> [maxBarres] [edition] | list | check <fichier.lic> | sign-build <dossier>
// Tous les fichiers de l'auteur sont rangés dans  %USERPROFILE%\StructCalc_Auteur  (ou dans le dossier de la variable STRUCTCALC_AUTEUR) :
//   private_key.xml (SECRÈTE) · public_key.xml · ventes.csv (registre des ventes) · licences\*.lic

internal static class Program
{
    private static readonly string Dir = Environment.GetEnvironmentVariable("STRUCTCALC_AUTEUR")
        ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "StructCalc_Auteur");
    private static string PrivPath => Path.Combine(Dir, "private_key.xml");
    private static string PubPath => Path.Combine(Dir, "public_key.xml");
    private static string SalesPath => Path.Combine(Dir, "ventes.csv");
    private static string LicDir => Path.Combine(Dir, "licences");

    private static int Main(string[] args)
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        Directory.CreateDirectory(Dir); Directory.CreateDirectory(LicDir);
        if (args.Length == 0) { Menu(); return 0; }
        switch (args[0].ToLowerInvariant())
        {
            case "genkeys": GenKeys(); break;
            case "machineid": Console.WriteLine(LicenseManager.MachineId()); break;
            case "creator": Creator(Arg(args, 1)); break;
            case "issue":
                if (args.Length < 4) { Console.WriteLine("Usage : issue <nom> <email> <machineId> [jours] [maxBarres] [edition]   (préférez le menu interactif)"); return 1; }
                Issue(Arg(args, 1), Arg(args, 2), "", Arg(args, 3).ToUpperInvariant(), int.TryParse(Arg(args, 4), out var d) ? d : 365,
                      int.TryParse(Arg(args, 5), out var mx) ? mx : 0, Arg(args, 6) == "" ? "PRO" : Arg(args, 6), 0, "", "");
                break;
            case "list": ListSales(); break;
            case "check": Check(Arg(args, 1)); break;
            case "sign-build": SignBuild(Arg(args, 1)); break;
            default: Console.WriteLine("Commande inconnue. Lancez l'outil sans argument pour le menu."); return 1;
        }
        return 0;
    }

    private static string Arg(string[] a, int i) => i < a.Length ? a[i] : "";

    private static string Ask(string question, string def = "")
    {
        Console.Write(question + (def != "" ? $" [{def}]" : "") + " : ");
        string? s = Console.ReadLine();
        if (s == null) return def;
        s = s.Trim();
        return s == "" ? def : s;
    }

    // ------------------------------------------------------------------ menu
    private static void Menu()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("==================================================================");
            Console.WriteLine($"  {AppInfo.Name} - OUTIL DE L'AUTEUR ({AppInfo.Author})");
            Console.WriteLine($"  Dossier : {Dir}");
            Console.WriteLine(File.Exists(PrivPath) ? "  Clés : OK (private_key.xml présent)" : "  Clés : ABSENTES -> commencez par l'option 1");
            Console.WriteLine("==================================================================");
            Console.WriteLine("  1  Créer les clés (UNE SEULE FOIS dans la vie du produit)");
            Console.WriteLine("  2  Afficher l'identifiant de CE poste");
            Console.WriteLine("  3  Créer et installer MA licence de créateur (ce poste, perpétuelle)");
            Console.WriteLine("  4  Émettre une licence pour un client");
            Console.WriteLine("  5  Voir le registre des ventes");
            Console.WriteLine("  6  Vérifier un fichier .lic (support client)");
            Console.WriteLine("  7  Signer un dossier de publication (integrity.sig)");
            Console.WriteLine("  0  Quitter");
            string c = Ask("Votre choix");
            if (c == "0" || c == "") return;
            try
            {
                switch (c)
                {
                    case "1": GenKeys(); break;
                    case "2": Console.WriteLine("Identifiant de ce poste : " + LicenseManager.MachineId()); break;
                    case "3": Creator(""); break;
                    case "4": IssueInteractive(); break;
                    case "5": ListSales(); break;
                    case "6": Check(Ask("Chemin du fichier .lic")); break;
                    case "7": SignBuild(Ask("Dossier à signer (celui de la publication Release)")); break;
                    default: Console.WriteLine("Choix inconnu."); break;
                }
            }
            catch (Exception ex) { Console.WriteLine("ERREUR : " + ex.Message); }
        }
    }

    // ------------------------------------------------------------------ clés
    private static void GenKeys()
    {
        if (File.Exists(PrivPath))
        {
            Console.WriteLine("private_key.xml existe déjà : opération annulée.");
            Console.WriteLine("Ne régénérez JAMAIS la clé après avoir vendu des licences : elles deviendraient toutes invalides.");
            return;
        }
        using var rsa = RSA.Create(2048);
        File.WriteAllText(PrivPath, rsa.ToXmlString(true));
        File.WriteAllText(PubPath, rsa.ToXmlString(false));
        string pub = rsa.ToXmlString(false).Replace("\"", "\"\"");
        string snippet = Path.Combine(Dir, "LicensePublicKey.snippet.txt");
        File.WriteAllText(snippet, $"public const string Xml = @\"{pub}\";");
        Console.WriteLine();
        Console.WriteLine("Clés créées dans : " + Dir);
        Console.WriteLine("  private_key.xml = SECRÈTE : sauvegardez-la sur une clé USB (copie hors ligne) et ne l'envoyez à personne.");
        Console.WriteLine("  public_key.xml  = publique.");
        Console.WriteLine();
        Console.WriteLine("ÉTAPE SUIVANTE : ouvrez le fichier suivant, copiez sa ligne et collez-la dans");
        Console.WriteLine("  src\\StructCalc.Core\\Licensing\\LicensePublicKey.cs  (à la place de la ligne  public const string Xml = \"\";)");
        Console.WriteLine("  " + snippet);
        Console.WriteLine("Puis recompilez le logiciel.");
    }

    private static string RequirePrivateKey()
    {
        if (!File.Exists(PrivPath)) throw new InvalidOperationException("private_key.xml introuvable : lancez d'abord l'option 1 (création des clés).");
        return File.ReadAllText(PrivPath);
    }

    // ------------------------------------------------------------------ licence du créateur
    private static void Creator(string machineArg)
    {
        string key = RequirePrivateKey();
        string mid = machineArg != "" ? machineArg : LicenseManager.MachineId();
        var info = new LicenseInfo
        {
            Licensee = AppInfo.Author, Email = AppInfo.Email, MachineId = mid, Edition = "CREATEUR",
            IssuedUtc = DateTime.UtcNow, ExpiresUtc = null, MaxMembers = 0
        };
        string text = LicenseManager.CreateLicenseText(info, key);
        string file = Path.Combine(LicDir, $"licence_CREATEUR_{mid}.lic");
        File.WriteAllText(file, text);
        Log("licence créateur", "", "", mid, "CREATEUR", 0, 0, null, 0, "-", file, "licence de l'auteur");
        Console.WriteLine("Licence créateur créée : " + file);
        if (mid == LicenseManager.MachineId())
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LicenseManager.LicensePath)!);
            File.WriteAllText(LicenseManager.LicensePath, text);
            Console.WriteLine("Elle est déjà INSTALLÉE sur ce poste : " + LicenseManager.LicensePath);
            Console.WriteLine("Lancez StructCalc (version Release) : la barre d'état doit afficher « Licence CRÉATEUR ».");
            Console.WriteLine("(Si une clé publique est configurée mais que la version a été compilée AVANT, recompilez-la.)");
        }
        else Console.WriteLine("Poste différent de celui-ci : importez le fichier sur l'autre poste (Aide > Licence et activation > Importer).");
    }

    // ------------------------------------------------------------------ licence client
    private static void IssueInteractive()
    {
        RequirePrivateKey();
        string name = Ask("Nom du client ou de la société");
        if (name == "") { Console.WriteLine("Nom obligatoire."); return; }
        string email = Ask("E-mail du client");
        string phone = Ask("Téléphone / WhatsApp du client");
        string mid = Ask("Identifiant du poste du client (XXXX-XXXX-XXXX-XXXX)").ToUpperInvariant();
        if (!Regex.IsMatch(mid, @"^[0-9A-F]{4}(-[0-9A-F]{4}){3}$"))
        { Console.WriteLine("Identifiant invalide : le client le lit dans le logiciel (Aide > Licence et activation)."); return; }
        Console.WriteLine("Éditions : 1 = PRO (1 an) · 2 = ENTREPRISE (1 an) · 3 = ÉTUDIANT (1 an, 60 barres max) · 4 = PRO perpétuelle");
        string ed = Ask("Édition", "1");
        string edition = "PRO"; int days = 365, max = 0;
        switch (ed)
        {
            case "2": edition = "ENTREPRISE"; break;
            case "3": edition = "ETUDIANT"; max = 60; break;
            case "4": edition = "PRO"; days = 0; break;
        }
        days = int.TryParse(Ask("Durée en jours (0 = perpétuelle)", days.ToString()), out var dd) ? dd : days;
        double price = double.TryParse(Ask("Prix encaissé en FCFA", "0").Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var pr) ? pr : 0;
        string pay = Ask("Mode de paiement / référence (Orange Money, MTN MoMo, Wave, virement...)", "");
        string note = Ask("Note (facultatif)", "");
        Issue(name, email, phone, mid, days, max, edition, price, pay, note);
    }

    private static void Issue(string name, string email, string phone, string mid, int days, int max, string edition, double price, string pay, string note)
    {
        string key = RequirePrivateKey();
        var info = new LicenseInfo
        {
            Licensee = name, Email = email, MachineId = mid, Edition = edition.ToUpperInvariant(), IssuedUtc = DateTime.UtcNow,
            ExpiresUtc = days > 0 ? DateTime.UtcNow.AddDays(days) : null, MaxMembers = max
        };
        string text = LicenseManager.CreateLicenseText(info, key);
        string safe = string.Concat(name.Where(char.IsLetterOrDigit));
        string file = Path.Combine(LicDir, $"licence_{safe}_{mid}_{DateTime.Now:yyyyMMdd}.lic");
        File.WriteAllText(file, text);
        Log(name, email, phone, mid, info.Edition, days, max, info.ExpiresUtc, price, pay, file, note);
        Console.WriteLine();
        Console.WriteLine("Licence créée : " + file);
        Console.WriteLine(days > 0 ? $"Valable jusqu'au {info.ExpiresUtc:dd/MM/yyyy}." : "Licence perpétuelle.");
        Console.WriteLine("ENVOYEZ ce fichier au client (e-mail ou WhatsApp). Il l'importe : Aide > Licence et activation > Importer une licence.");
        Console.WriteLine("La vente est notée dans : " + SalesPath);
    }

    // ------------------------------------------------------------------ registre des ventes
    private static string Csv(string s) => "\"" + s.Replace("\"", "\"\"") + "\"";

    private static void Log(string client, string email, string phone, string mid, string edition, int days, int max, DateTime? expires, double price, string pay, string file, string note)
    {
        bool isNew = !File.Exists(SalesPath);
        var sb = new StringBuilder();
        if (isNew) sb.AppendLine("date;client;email;telephone;machineId;edition;jours;maxBarres;expiration;prix_FCFA;paiement;fichier;note");
        sb.AppendLine(string.Join(";", new[]
        {
            DateTime.Now.ToString("yyyy-MM-dd HH:mm"), Csv(client), Csv(email), Csv(phone), mid, edition, days.ToString(), max.ToString(),
            expires.HasValue ? expires.Value.ToString("yyyy-MM-dd") : "perpetuelle", price.ToString("0.##", CultureInfo.InvariantCulture), Csv(pay), Csv(Path.GetFileName(file)), Csv(note)
        }));
        File.AppendAllText(SalesPath, sb.ToString(), new UTF8Encoding(true));
    }

    private static void ListSales()
    {
        if (!File.Exists(SalesPath)) { Console.WriteLine("Aucune vente enregistrée pour l'instant."); return; }
        var lines = File.ReadAllLines(SalesPath, Encoding.UTF8);
        Console.WriteLine($"Registre : {SalesPath}  ({Math.Max(0, lines.Length - 1)} ligne(s)). Ouvrez-le avec Excel pour trier et totaliser.");
        double total = 0; int n = 0;
        foreach (var l in lines.Skip(1))
        {
            var parts = l.Split(';');
            if (parts.Length < 10) continue;
            Console.WriteLine($"  {parts[0]}  {parts[1],-28} {parts[5],-11} jusqu'au {parts[8],-11} {parts[9],8} FCFA");
            if (double.TryParse(parts[9], NumberStyles.Float, CultureInfo.InvariantCulture, out var p)) total += p;
            n++;
        }
        Console.WriteLine($"  Total encaissé : {total:0.##} FCFA  ({n} licence(s))");
        var soon = lines.Skip(1).Select(l => l.Split(';')).Where(p => p.Length > 8 && DateTime.TryParse(p[8], out var dt) && dt < DateTime.Now.AddDays(30) && dt > DateTime.Now.AddDays(-1)).ToList();
        foreach (var p in soon) Console.WriteLine($"  >> À RENOUVELER : {p[1]} (expire le {p[8]}) - {p[2]}");
    }

    private static void Check(string file)
    {
        if (file == "" || !File.Exists(file)) { Console.WriteLine("Fichier introuvable."); return; }
        if (!File.Exists(PubPath)) { Console.WriteLine("public_key.xml absent : lancez l'option 1."); return; }
        if (!LicenseManager.VerifyLicenseText(File.ReadAllText(file), File.ReadAllText(PubPath), out var info, out var err))
        { Console.WriteLine("LICENCE INVALIDE : " + err); return; }
        Console.WriteLine("Signature valide.");
        Console.WriteLine($"  Titulaire : {info!.Licensee} <{info.Email}>");
        Console.WriteLine($"  Édition   : {info.Edition}");
        Console.WriteLine($"  Poste     : {info.MachineId}");
        Console.WriteLine($"  Émise le  : {info.IssuedUtc.ToLocalTime():dd/MM/yyyy}");
        Console.WriteLine($"  Expire    : {(info.ExpiresUtc.HasValue ? info.ExpiresUtc.Value.ToLocalTime().ToString("dd/MM/yyyy") : "jamais")}");
        Console.WriteLine($"  Barres    : {(info.MaxMembers == 0 ? "illimité" : info.MaxMembers.ToString())}");
    }

    private static void SignBuild(string folder)
    {
        string key = RequirePrivateKey();
        folder = folder.Trim('"');
        if (!Directory.Exists(folder)) { Console.WriteLine("Dossier introuvable : " + folder); return; }
        File.WriteAllText(Path.Combine(folder, "integrity.sig"), IntegrityChecker.CreateManifest(folder, key));
        Console.WriteLine("integrity.sig créé dans " + folder);
        Console.WriteLine("Ne modifiez plus aucun fichier StructCalc*.dll / .exe de ce dossier après cette signature (sinon : « intégrité compromise »).");
    }
}
