# Registre de validation du moteur StructCalc

Règle : un résultat n'est déclaré « validé » que s'il a été comparé à une référence fiable (solution analytique, calcul à la main, ou logiciel reconnu).
Ce registre dit honnêtement où en est chaque cas. Les tests sont exécutés par `restaurer_compiler_tester.bat`.

| Cas | Grandeurs comparées | Référence | Test | Statut |
|---|---|---|---|---|
| Poutre isostatique, charge uniforme | réactions, M, V, flèche 5wL⁴/384EI | RDM | SolverTests, ValidationLibrary | écrit, à exécuter |
| Poutre isostatique, charge ponctuelle | réactions, M=PL/4, V, flèche PL³/48EI | RDM | ValidationLibrary | écrit, à exécuter |
| Poutre continue 2 travées | réactions 3/8 – 5/4 – 3/8 wL, M appui, M travée 9wL²/128 | RDM / 3 moments | ReferenceCases, ValidationLibrary | écrit, à exécuter |
| Console | flèche PL³/3EI, M=PL, rotation | RDM | SolverTests, ValidationLibrary | écrit, à exécuter |
| Portique 1 niveau | dérive latérale, symétrie, réactions | formule à raideurs | ReferenceCases, ValidationLibrary | écrit, à exécuter |
| Portique 2 niveaux | équilibre des forces et moments, croissance des déplacements | statique | ValidationLibrary | écrit, à exécuter |
| Poteau centré / excentré | N, raccourcissement NH/EA, M=N·e (1er ordre) | RDM | ValidationLibrary | écrit, à exécuter |
| Dalle appuyée / encastrée | flèche, moments | Navier / Timoshenko | SlabMethodsTests | existant |
| Dalle continue | moments Caquot | formules Caquot | SlabMethodsTests | partiel |
| Semelle isolée centrée / excentrée | q_adm, σ max, poinçonnement | Terzaghi / règles de pression | FoundationTests | partiel : cas excentré à ajouter |
| Escalier droit | géométrie, statique, ferraillage | Blondel, RDM | StairTests | partiel : ferraillage à comparer à la main |
| Voile de contreventement | flèche console | Timoshenko | FoundationTests | existant |

## Autres plans de validation ajoutés
| Domaine | Tests | Statut |
|---|---|---|
| Aller-retour Revit sans Revit (poutre, poteau, portique, escalier : fichier d'échange, calcul, résumé, mise à jour sans doublon, détection des modifications) | RevitRoundTripTests | écrit, à exécuter |
| Projet pilote R+1 (chaîne complète côté StructCalc) | PilotProjectTests | écrit, à exécuter |
| Vérifications escaliers / voiles / radiers / planchers nervurés | SurfaceChecksTests | écrit, à exécuter |
| Dispositions de ferraillage (longueurs développées, décalage des recouvrements, couture, ancrages sur appuis, confinement) | RebarDetailingTests | écrit, à exécuter |
| Architecture et valeurs de référence par norme (BAEL, EC2, RPA, EC8) | NormArchitectureTests | écrit, à exécuter |

## Non encore fait (à ne pas prétendre)
* Comparaison à Robot / ETABS : aucune. Elle demande 2 ou 3 modèles de référence avec leurs résultats exportés, fournis par l'utilisateur.
* Flèche différée, ferraillage et taux de travail des cas ci-dessus : à vérifier à la main puis à figer en tests.
* Création des armatures 3D et des plans d'exécution DANS Revit : non testable sans Revit, à contrôler à la main (PROJET_PILOTE.md, étapes 4 et 6).
* Détail de nœud poteau-poutre et escalier à crémaillère : non réalisés.
* Corrections assistées pour les voiles, radiers et planchers : seules celles déjà existantes (DesignFixes) sont disponibles ; rien de nouveau.
* Séparation totale des normes : la filiation actuelle (EC2 et CBA93 héritent du moteur BAEL) est déclarée et testée, mais le moteur commun neutre reste à extraire (voir Codes/README_NORMES.md).
