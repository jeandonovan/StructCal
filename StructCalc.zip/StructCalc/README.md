# StructCalc : dimensionnement automatisé BA / CM (logiciel autonome + add-in Revit 2025)

## Compiler (Visual Studio 2022 Community, .NET 8)
1. Ouvrir `StructCalc.sln` (sinon : `dotnet new sln -n StructCalc` puis `dotnet sln add` des 5 .csproj).
2. Test > Exécuter tous les tests (xUnit).
3. Projet de démarrage : `StructCalc.App` (WPF), F5.
4. `StructCalc.RevitAddin` : Revit 2025 attendu dans `C:\Program Files\Autodesk\Revit 2025\` (sinon `-p:RevitDir=...`). Si Revit est absent, déchargez ce projet.

## Normes disponibles (choix dans la barre d'outils)
BA : BAEL91, CBA93, EC2, RPA99 (+CBA93), EC8 (+EC2). CM : EC3 (EN), EC3ENV (méthode du cours ISA : ky, kz, kLT, beta_M), CM66 (partiel).
- CBA93 réutilise le moteur BAEL91 (hypothèses identiques pour les éléments traités).
- RPA99 / EC8 : combinaisons accidentelles/sismiques, pourcentages minimaux, espacements des zones critiques, force statique équivalente.
- EC3 : classes 1-3, flambement, déversement, interaction (Annexe B). Profilés IPE / HEA / HEB.
- CM66 : combinaisons, traction, 1,54 tau, sigma_f/psi, flexion déviée issus de RDM-CM66 ; k1, kf, kd (flambement/déversement) toujours PROVISOIRES : absents de vos documents.

## Interface
Vue graphique 2D/3D du modèle (élévation, plan, côté, 3D ; molette = zoom, clic droit = déplacer), barres colorées selon le résultat (vert OK, rouge NON OK), appuis, charges, diagrammes d'enveloppe (M, V, N), dessin du ferraillage de la barre sélectionnée, tableau des résultats avec taux, métré estimatif, note de calcul HTML.

## Aiguillage
Chaque barre est traitée selon son matériau : BA -> norme BA choisie ; acier -> norme CM choisie. Modèles mixtes acceptés.

## Séisme
Onglet « Séisme » : Enabled, Norm (RPA99 ou EC8), direction, paramètres. Le cas E est généré (force statique, période empirique, pas de torsion accidentelle).

## Architecture
Core (modèle, normes, catalogue acier) / Engine (solveur EF 3D, séisme, dimensionnement, optimisation, rapports) / App (WPF) / RevitAddin.

## Limites connues (à valider avant usage réel)
- Code jamais compilé à la livraison : corrigez d'éventuelles erreurs de compilation.
- Formules BA/EC2/EC3 écrites de mémoire : valider sur cas de référence (Robot, calcul manuel). Tables de dalles, beta biaxial 0,8, coefficients de continuité à vérifier.
- CM66 provisoire. RPA/EC8 : pas de dimensionnement en capacité, noeuds, voiles, déplacements, analyse modale.
- Pas encore : voiles/coques EF, P-Delta, torsion, poteaux élancés (Faessel), flèche calculée, assemblages acier, classe 4.
- Solveur dense (Cholesky) : quelques centaines de nœuds.


---
## Version 2 : protection, modélisation, plans
**Auteur : Maximilien EKRESSIN - jeandonovan33@gmail.com - +225 0777505213 / +225 0799518100**

### Protection contre le piratage (à mettre en place UNE FOIS par l'auteur)
1. Compiler la solution. Dans `tools\StructCalc.LicenseGen` : `dotnet run -- genkeys` crée `private_key.xml` (SECRÈTE : à sauvegarder hors ligne, ne JAMAIS la distribuer) et `LicensePublicKey.snippet.txt`.
2. Coller le contenu de `LicensePublicKey.snippet.txt` dans `src\StructCalc.Core\Licensing\LicensePublicKey.cs`, puis recompiler en **Release**.
3. Pour un client : il lance StructCalc, copie l'identifiant du poste (fenêtre Licence), vous l'envoie ; vous faites
   `dotnet run -- issue "Nom Client" client@mail.com XXXX-XXXX-XXXX-XXXX 365 [maxBarres]` (365 jours ; 0 = perpétuelle) et lui envoyez le `.lic`.
4. Signer le dossier Release : `dotnet run -- sign-build "chemin\bin\Release\net8.0-windows"` (crée `integrity.sig` : toute DLL modifiée est détectée).
5. Ne distribuer que le dossier Release (jamais Debug, jamais `tools\`, jamais `private_key.xml`).
Sans licence : 30 jours d'évaluation, 40 barres maximum, plans et notes filigranés. Licence liée au poste (signature RSA 2048), horloge et données d'essai protégées.
**Limite honnête** : aucune protection logicielle n'est inviolable. Pour durcir : obfuscation (Dotfuscator / ConfuserEx) des DLL, signature de code (certificat), activation en ligne.

### Modélisation
Barre d'outils de la vue : Sélection, Nœud, Barre, Appui, Supprimer (accrochage grille et nœuds, Échap pour finir, Ctrl+Z pour annuler). Assistant d'ossature (menu Modèle). Panneau droit : modifier la section / le profil d'une barre (ou de toutes les barres du même type), ajouter une charge, puis « Appliquer + recalculer ». Onglet Vérification : erreurs de modèle (appuis manquants, parties non appuyées, mécanismes, sections invalides) avant calcul.

### Plans (menu Plans / bouton PLANS, après le calcul)
Nomenclature, plans de coffrage / élévation, ferraillage des poutres, poteaux, semelles, dalles, assemblages acier (platine d'extrémité, pied de poteau). Export DXF (R12, lu par toutes les versions d'AutoCAD et par Revit : Insérer > Importer CAO), conversion DWG toutes versions via ODA File Converter (gratuit, à installer), impression, export 3D IFC2x3 pour Revit (Fichier > Ouvrir > IFC).
Les plans sont des dessins de PRINCIPE (pas de recouvrements, coudes, ancrages détaillés) et les assemblages un PRÉ-DIMENSIONNEMENT : à valider par l'ingénieur.

## V3
Assistant de configuration (séisme, dispositions constructives, armatures, cartouche), nouveaux plans de ferraillage (coupes, cadres, nomenclature, récapitulatif), mode Créateur et registre des ventes. Voir `GUIDE_VENTE_LICENCES.md`.

## V3.1 — Vue 3D
Styles (filaire, trait, caché, ombré, réaliste, rayons X), détection automatique des étages et des axes,
onglet Structure (arborescence + infos), orbite centrée sur la sélection, perspective. Voir LISEZ-MOI_DEMARRAGE.txt.

## V3.2 — Étages, grille, accrochages, fonds de plan
Fenêtres « Étages » et « Grille » (génération par travées `3x5 4.5`), ossature automatique depuis la grille, duplication d'étage type,
accrochages (nœuds, milieux, axes, niveaux, alignement, fond de plan), import DXF (lecteur intégré), DWG (via ODA File Converter),
PDF et images avec calage d'échelle / déplacement / alignement. Voir LISEZ-MOI_DEMARRAGE.txt.
