@echo off
chcp 65001 >nul
echo === 1/3 Restauration des packages NuGet (internet requis) ===
dotnet restore StructCalc.sln
if errorlevel 1 goto fin
echo === 2/3 Compilation (sans le projet Revit) ===
dotnet build src\StructCalc.App\StructCalc.App.csproj -c Debug --no-restore
if errorlevel 1 goto fin
echo === 3/3 Tests ===
dotnet test tests\StructCalc.Tests\StructCalc.Tests.csproj --no-restore
:fin
echo.
echo Termine. Copiez le texte ci-dessus si vous voyez des erreurs.
pause
