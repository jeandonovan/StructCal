@echo off
chcp 65001 >nul
echo ===============================================================
echo  StructCalc - compilation + installation dans Revit 2025
echo  FERMEZ REVIT avant de continuer (sinon les DLL sont verrouillees).
echo ===============================================================
pause
set "REVITDIR=C:\Program Files\Autodesk\Revit 2025"
if not exist "%REVITDIR%\RevitAPI.dll" (
  echo RevitAPI.dll introuvable dans "%REVITDIR%"
  echo Modifiez la ligne REVITDIR de ce fichier .bat puis recommencez.
  goto fin
)
echo === 1/3 Restauration ===
dotnet restore StructCalc.sln
if errorlevel 1 goto fin
echo === 2/3 Compilation de StructCalc (application) ===
dotnet build src\StructCalc.App\StructCalc.App.csproj -c Debug --no-restore
if errorlevel 1 goto fin
echo Dossier Revit utilise : %REVITDIR%
echo === 3/3 Compilation + installation du complement Revit ===
dotnet build src\StructCalc.RevitAddin\StructCalc.RevitAddin.csproj -c Debug
if errorlevel 1 goto fin
echo.
echo OK. Lancez StructCalc UNE FOIS a la main (il memorise son emplacement pour que Revit puisse l'ouvrir),
echo puis ouvrez Revit 2025 : onglet Complements ^> StructCalc.
echo (Si Revit demande de charger le complement, choisissez "Toujours charger".)
:fin
pause
