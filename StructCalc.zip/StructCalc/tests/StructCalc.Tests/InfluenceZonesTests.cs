using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Zones d'influence : une dalle traversée par une poutre est découpée en panneaux, chacun charge ses poutres.</summary>
public class InfluenceZonesTests
{
    private static StructModel TwoBays()
    {
        var m = new StructModel();
        int id = 1;
        foreach (double y in new[] { 0.0, 4.0 }) foreach (double x in new[] { 0.0, 4.0, 8.0 }) m.Nodes.Add(new Node { Id = id++, X = x, Y = y, Z = 3 });
        // nœuds 1,2,3 (y = 0) et 4,5,6 (y = 4) : poutre centrale 2-5 // Y
        m.Members.Add(new Member { Id = 1, NodeI = 2, NodeJ = 5, Type = MemberType.Beam });
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 8, Ly = 4, Z = 3, H = 0.16, GExtra = 1.5, Q = 2.5 });
        return m;
    }

    [Fact]
    public void SlabCrossedByBeam_IsSplitInTwoPanels()
    {
        var m = TwoBays();
        var cells = SlabCells.Of(m, m.Slabs[0]);
        Assert.Equal(2, cells.Count);
        Assert.Equal(4.0, cells[0].Lx, 6);
        Assert.True(cells[0].XhIn && cells[1].XlIn);
        StoreyOps.SyncSlabLoads(m, m.Slabs[0]);
        Assert.Equal(4, m.SurfaceLoads.Count);                                     // G et Q par panneau
        Assert.Contains(m.SurfaceLoads, l => l.Name == "D1-G#2");
        StoreyOps.RemoveSlabLoads(m, "D1");
        Assert.Empty(m.SurfaceLoads);
    }

    [Fact]
    public void SlabWithoutInnerBeam_IsOnePanel_AndKeepsSimpleLoadNames()
    {
        var m = TwoBays(); m.Members.Clear();
        Assert.Single(SlabCells.Of(m, m.Slabs[0]));
        StoreyOps.SyncSlabLoads(m, m.Slabs[0]);
        Assert.Contains(m.SurfaceLoads, l => l.Name == "D1-G");
    }

    [Fact]
    public void PanelsOfSlabFE_ShareContinuousInnerEdge()
    {
        var m = TwoBays(); m.Slabs[0].Continuity = SlabContinuity.Simple;
        // poutres de rive : sans elles, chaque panneau n'est porté que par la poutre centrale et serait traité en console (ConsoleDesigner)
        int mid = 10;
        foreach (var (a, b) in new[] { (1, 2), (2, 3), (4, 5), (5, 6), (1, 4), (3, 6) }) m.Members.Add(new Member { Id = mid++, NodeI = a, NodeJ = b, Type = MemberType.Beam });
        var fields = SlabFE.SolveAll(m);
        Assert.Equal(2, fields.Count);
        Assert.All(fields, f => Assert.True(f.Partial));
        Assert.True(fields[0].Range(SlabFieldKind.Mx).Min < 0);                    // moment négatif sur l'appui intermédiaire encastré
    }

    [Fact]
    public void OverlappingFootings_AreReported()
    {
        var m = new StructModel();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 1.5, Y = 0, Z = 0 });
        var o = new AnalysisOutput();
        foreach (int n in new[] { 1, 2 })
        {
            var r = new DesignResult { Element = $"Semelle sous nœud {n} (test)" };
            r.Values["A_m"] = 2.0; r.Values["B_m"] = 2.0; r.Values["h_m"] = 0.5;
            o.Footings.Add(r);
        }
        var msgs = InfluenceZones.Check(m, o);
        Assert.Contains(msgs, t => t.Contains("se chevauchent"));
    }

    [Fact]
    public void OverlappingSlabs_AreAnError()
    {
        var m = TwoBays();
        m.Slabs.Add(new SlabPanel { Name = "D2", Placed = true, X0 = 2, Y0 = 1, Lx = 3, Ly = 2, Z = 3, H = 0.16 });
        var issues = ModelChecker.Check(m);
        Assert.Contains(issues, i => i.Level == IssueLevel.Error && i.Message.Contains("superposées"));
    }

    [Fact]
    public void Equilibrium_FlagsLostLoad()
    {
        var m = TwoBays();
        StoreyOps.SyncSlabLoads(m, m.Slabs[0]);
        var o = new AnalysisOutput { Global = new GlobalResults() };
        o.Global.TotalFzByCase["G"] = 10;                      // bien moins que les charges de dalles reportées
        var msgs = InfluenceZones.Check(m, o);
        Assert.Contains(msgs, t => t.Contains("équilibre vertical cas G"));
    }
}
