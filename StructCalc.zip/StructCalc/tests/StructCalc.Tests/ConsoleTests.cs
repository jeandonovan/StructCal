using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Consoles : dalles en porte-à-faux (bande de 1 m) et poutres console.</summary>
public class ConsoleTests
{
    private static StructModel RingWithBalcony()
    {
        var m = new StructModel { IncludeSelfWeight = false, Fc28 = 25, Fe = 500 };
        double[,] p = { { 0, 0 }, { 5, 0 }, { 5, 5 }, { 0, 5 } };
        for (int i = 0; i < 4; i++) m.Nodes.Add(new Node { Id = i + 1, X = p[i, 0], Y = p[i, 1], Z = 3 });
        for (int i = 0; i < 4; i++) m.Members.Add(new Member { Id = i + 1, NodeI = i + 1, NodeJ = (i + 1) % 4 + 1, Type = MemberType.Beam, B = 0.30, H = 0.50 });
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 6.2, Ly = 5, Z = 3, H = 0.16 });   // console de 1,20 m
        return m;
    }

    [Fact]
    public void SlabConsole_IsDetected_AndDesignedOnAOneMeterStrip()
    {
        var m = RingWithBalcony();
        var res = ConsoleDesigner.Slabs(m);
        Assert.Single(res);
        var r = res[0];
        Assert.Equal(1.2, r.L, 6);
        Assert.Equal(5.0, r.W, 6);
        Assert.Equal(11.175 * 1.44 / 2, r.Mu, 3);              // pu = 1,35 x 5,5 + 1,5 x 2,5 = 11,175 kN/m²
        Assert.Equal(11.175 * 1.2, r.Vu, 3);
        Assert.InRange(r.AsTop, 1.4, 1.65);                    // d = 12,4 cm : As ≈ 1,52 cm²/m
        Assert.Contains("SUPÉRIEURES", r.Text);
    }

    [Fact]
    public void SlabConsole_TipLoadRaisesMoment()
    {
        var m = RingWithBalcony();
        double m0 = ConsoleDesigner.Slabs(m)[0].Mu;
        m.Slabs[0].CantileverTipKnM = 1.0;
        double m1 = ConsoleDesigner.Slabs(m)[0].Mu;
        Assert.Equal(m0 + 1.35 * 1.0 * 1.2, m1, 6);
    }

    [Fact]
    public void FullyBeamSupportedSlab_IsNotAConsole()
    {
        var m = RingWithBalcony();
        m.Slabs[0].Lx = 5;
        Assert.Empty(ConsoleDesigner.Slabs(m));
    }

    [Fact]
    public void CantileverBeam_Detected_FlaggedAndDeflectionLimitUsesTwoL()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 3, X = 2, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, Type = MemberType.Beam, B = 0.25, H = 0.40 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        Assert.True(ConsoleDesigner.IsCantileverBeam(m, m.Members[1]));
        Assert.False(ConsoleDesigner.IsCantileverBeam(m, m.Members[0]));

        var o = new AnalysisOutput { Global = new GlobalResults() };
        o.Members.Add(new MemberDesignResult { MemberId = 2, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, B = 0.25, H = 0.40, Length = 2, TopN = 3, TopDia = 14, MuHog = 60, Vu = 50, AsTop = 4.6 });
        o.Global.Deflections.Add(new DeflectionRow { MemberId = 2, LengthM = 2, DeltaMm = 12, LimitMm = 8, Ok = false, Combo = "ELS" });
        var ex = ConsoleDesigner.Compute(m, o);
        Assert.NotNull(ex);
        Assert.True(o.Members[0].Cantilever);
        Assert.Equal(16.0, o.Global.Deflections[0].LimitMm, 6);       // 2 x 2 m / 250 = 16 mm
        Assert.True(o.Global.Deflections[0].Ok);
        Assert.Contains("Poutre console 2", ex!.Text);
    }

    [Fact]
    public void CantileverBeam_TopBarsRunFullLength_InTheSchedule()
    {
        var cfg = new DesignSettings();
        var r = new MemberDesignResult { MemberId = 2, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, B = 0.25, H = 0.40, Length = 2.0, BotN = 3, BotDia = 12, TopN = 3, TopDia = 14, StirDia = 8, StirSpacingCm = 15 };
        var normal = RcSheets.BeamBars(r, cfg, "B2", 1);
        r.Cantilever = true;
        var cons = RcSheets.BeamBars(r, cfg, "B2", 1);
        Assert.Equal(6, normal[1].Count);                           // 2 x 3 chapeaux sur appuis
        Assert.Equal(3, cons[1].Count);                             // 3 chapeaux sur toute la longueur
        Assert.True(cons[1].LengthM > 2.0 - 0.06);
        Assert.Contains("console", cons[1].Role);
    }
}
