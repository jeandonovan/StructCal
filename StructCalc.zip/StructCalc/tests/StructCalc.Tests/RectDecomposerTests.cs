using StructCalc.Engine.Geometry;
using Xunit;

/// <summary>Dalle Revit percée d'une trémie : les panneaux couvrent exactement la surface, sans la trémie.</summary>
public class RectDecomposerTests
{
    private static IList<(double X, double Y)> Rect(double x0, double y0, double x1, double y1) =>
        new List<(double X, double Y)> { (x0, y0), (x1, y0), (x1, y1), (x0, y1) };

    [Fact]
    public void FullRectangle_GivesOnePanel()
    {
        var r = RectDecomposer.Decompose(new List<IList<(double X, double Y)>> { Rect(0, 0, 10, 10.5) });
        Assert.Single(r);
        Assert.Equal(105.0, r[0].Area, 3);
    }

    [Fact]
    public void CornerOpening_IsLeftEmpty()
    {
        var r = RectDecomposer.Decompose(new List<IList<(double X, double Y)>> { Rect(0, 0, 10, 10), Rect(7, 7, 9, 10) });
        Assert.Equal(100.0 - 6.0, r.Sum(q => q.Area), 3);
        Assert.DoesNotContain(r, q => q.X0 < 9 && q.X1 > 7 && q.Y0 < 10 && q.Y1 > 7);
    }

    [Fact]
    public void InnerOpening_GivesPanelsAroundIt()
    {
        var r = RectDecomposer.Decompose(new List<IList<(double X, double Y)>> { Rect(0, 0, 10, 10), Rect(4, 4, 6, 6) });
        Assert.Equal(96.0, r.Sum(q => q.Area), 3);
        Assert.True(r.Count >= 4);
    }

    [Fact]
    public void LShape_GivesTwoPanels()
    {
        var l = new List<(double X, double Y)> { (0, 0), (10, 0), (10, 4), (5, 4), (5, 8), (0, 8) };
        var r = RectDecomposer.Decompose(new List<IList<(double X, double Y)>> { l });
        Assert.Equal(60.0, r.Sum(q => q.Area), 3);
        Assert.Equal(2, r.Count);
    }
}
