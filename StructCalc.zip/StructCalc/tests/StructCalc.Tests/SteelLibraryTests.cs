using StructCalc.Core.Steel;
using Xunit;

namespace StructCalc.Tests;

public class SteelLibraryTests
{
    [Fact]
    public void LibraryContainsAllFamilies()
    {
        Assert.True(SteelLibrary.All.Count >= 450);
        foreach (var s in new[] { "IPE", "IPEA", "IPEAA", "IPEO", "IPN", "HEAA", "HEA", "HEB", "HEM", "HL", "HD", "HP", "UPE", "UPN", "U", "L", "T" })
            Assert.Contains(s, SteelLibrary.Series);
        Assert.Equal(SteelLibrary.All.Count, SteelLibrary.All.Select(x => x.Name).Distinct().Count());
    }

    [Fact]
    public void Ipe240MatchesCatalogue()
    {
        Assert.True(SteelLibrary.TryGet("IPE 240", out var s));
        Assert.Equal(30.7, s.G, 1); Assert.Equal(3892, s.Iy, 0); Assert.Equal(367, s.Wply, 0);
        Assert.Equal(12.9, s.It, 1); Assert.InRange(s.Iw, 37300, 37500); Assert.Equal(ProfileShape.I, s.Shape);
        Assert.True(SteelLibrary.TryGet("hea 200", out var h));
        Assert.Equal(53.8, h.A, 1); Assert.Equal(20.98, h.It, 2);
    }

    [Fact]
    public void TabulatedValuesAreSelfConsistent()
    {
        foreach (var s in SteelLibrary.All.Where(x => x.Shape == ProfileShape.I))
        {
            double a = (2 * s.B * s.Tf + (s.H - 2 * s.Tf) * s.Tw + (4 - Math.PI) * s.R * s.R) / 100.0;
            Assert.True(Math.Abs(a - s.A) / s.A < 0.04, $"{s.Name} A");
            Assert.True(Math.Abs(s.Iy - s.Wely * s.H / 20.0) / s.Iy < 0.02, $"{s.Name} Wel");
            Assert.True(s.Wply >= s.Wely, $"{s.Name} Wpl");
            Assert.True(Math.Abs(s.G - 0.785 * s.A) / s.G < 0.04, $"{s.Name} G");
        }
        foreach (var s in SteelLibrary.All.Where(x => x.Shape == ProfileShape.L))
        {
            Assert.True(Math.Abs(s.G - 0.785 * s.A) / s.G < 0.03, $"{s.Name} G");
            Assert.True(s.ItCm4 > 0);
        }
    }

    [Fact]
    public void ComputedFormulasStayCloseToTables()
    {
        foreach (var n in new[] { "IPE300", "IPE200", "HEA240", "HEB300" })
        {
            var p = SteelCatalog.Get(n); Assert.True(SteelLibrary.TryGet(n, out var t));
            Assert.True(Math.Abs(p.AreaMm2 / 100 - t.A) / t.A < 0.02, n + " A");
            Assert.True(Math.Abs(p.IyMm4 / 1e4 - t.Iy) / t.Iy < 0.02, n + " Iy");
            Assert.True(Math.Abs(p.WplYMm3 / 1e3 - t.Wply) / t.Wply < 0.03, n + " Wpl");
        }
    }

    [Fact]
    public void ExtraIFamiliesAreUsableBySolver()
    {
        var hem = SteelCatalog.Get("HEM300");
        Assert.NotNull(hem.Lib);
        Assert.Equal(303.1, hem.AreaMm2 / 100, 1);
        Assert.True(hem.Iy > SteelCatalog.Get("HEB300").Iy);
        Assert.Equal(hem.Lib!.G, hem.MassKgPerM, 6);
        var ipn = SteelCatalog.Get("IPN200");
        Assert.Equal(33.4, ipn.AreaMm2 / 100, 1); Assert.Equal(2140, ipn.IyMm4 / 1e4, 0);
        Assert.NotNull(SteelCatalog.Next("IPEA240")); Assert.NotNull(SteelCatalog.Get("HL920X342"));
        // les profils d'origine restent calculés
        Assert.Null(SteelCatalog.Get("IPE300").Lib);
    }

    [Fact]
    public void SearchAndSelection()
    {
        Assert.Contains(SteelLibrary.Search("HEA 200"), s => s.Name == "HEA200");
        Assert.All(SteelLibrary.Search("UPN"), s => Assert.Equal("UPN", s.Series));
        var hit = SteelLibrary.LightestForWely("IPE", 500);
        Assert.NotNull(hit); Assert.True(hit!.Wely >= 500);
        Assert.DoesNotContain(SteelLibrary.OfSeries("IPE"), s => s.Wely >= 500 && s.G < hit.G);
        Assert.Contains("IPE 240", SteelLibrary.All.First(x => x.Name == "IPE240").Summary);
    }
}
