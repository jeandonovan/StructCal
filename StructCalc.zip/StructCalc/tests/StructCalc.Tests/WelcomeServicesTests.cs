using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Services de l'écran d'accueil : projets récents, création de projet, lecture contrôlée d'un fichier.</summary>
public class WelcomeServicesTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "sc_welcome_" + Guid.NewGuid().ToString("N"));

    public WelcomeServicesTests() { Directory.CreateDirectory(_dir); }
    public void Dispose() { try { Directory.Delete(_dir, true); } catch { } }

    private string Save(string name, StructModel? m = null)
    {
        string p = Path.Combine(_dir, name + AppInfo.FileExt);
        ModelIO.Save(m ?? ExampleModels.Portal(), p);
        return p;
    }

    private RecentProjects Recents(string legacy = "") => new(Path.Combine(_dir, "recent.json"), legacy);

    // ------------------------------------------------------------------ récents
    [Fact]
    public void Recent_AddsMostRecentFirst_AndDescribesProject()
    {
        var r = Recents();
        string a = Save("a"), b = Save("b");
        r.Add(a); r.Add(b);
        var l = r.Load();
        Assert.Equal(new[] { b, a }, l.Select(e => e.Path).ToArray());
        Assert.True(l[0].Elements > 0);
        Assert.Equal("Béton armé", l[0].SystemType);
        Assert.True(l[0].Thumb.Length >= 6);
        Assert.True(l[0].LastModified > DateTime.MinValue);
    }

    [Fact]
    public void Recent_ReAddingMovesToTop_WithoutDuplicate()
    {
        var r = Recents();
        string a = Save("a"), b = Save("b");
        r.Add(a); r.Add(b); r.Add(a);
        Assert.Equal(new[] { a, b }, r.Load().Select(e => e.Path).ToArray());
    }

    [Fact]
    public void Recent_DropsMissingFiles_AndRemoveKeepsFile()
    {
        var r = Recents();
        string a = Save("a"), b = Save("b");
        r.Add(a); r.Add(b);
        File.Delete(a);
        Assert.Equal(new[] { b }, r.Load().Select(e => e.Path).ToArray());
        r.Remove(b);
        Assert.Empty(r.Load());
        Assert.True(File.Exists(b));
    }

    [Fact]
    public void Recent_ImportsLegacyTextList_Once()
    {
        string a = Save("a"), b = Save("b");
        string legacy = Path.Combine(_dir, "recent.txt");
        File.WriteAllLines(legacy, new[] { a, b, Path.Combine(_dir, "absent.stcx") });
        var l = Recents(legacy).Load();
        Assert.Equal(2, l.Count);
        Assert.Equal(a, l[0].Path);
    }

    [Fact]
    public void Recent_IsLimitedToMaxEntries()
    {
        var r = Recents();
        for (int i = 0; i < RecentProjects.MaxEntries + 5; i++) r.Add(Save("p" + i, new StructModel()));
        Assert.Equal(RecentProjects.MaxEntries, r.Load().Count);
    }

    [Fact]
    public void Recent_DuplicateRenameDelete_WorkOnFilesAndList()
    {
        var r = Recents();
        string a = Save("projet");
        r.Add(a);
        string copy = r.Duplicate(a);
        Assert.True(File.Exists(copy));
        Assert.EndsWith("projet - copie" + AppInfo.FileExt, copy);
        Assert.Equal(2, r.Load().Count);
        Assert.NotEqual(copy, r.Duplicate(a));                       // « copie 2 » : jamais d'écrasement

        string renamed = r.RenameFile(a, "Villa Dupont");
        Assert.False(File.Exists(a));
        Assert.True(File.Exists(renamed));
        Assert.Contains(r.Load(), e => e.Path == renamed && e.Name == "Villa Dupont");
        Assert.Throws<InvalidOperationException>(() => r.RenameFile(renamed, "projet - copie"));
        Assert.Throws<InvalidOperationException>(() => r.RenameFile(renamed, "   "));

        r.DeleteFile(renamed);
        Assert.False(File.Exists(renamed));
        Assert.DoesNotContain(r.Load(), e => e.Path == renamed);
    }

    [Fact]
    public void Thumbnail_IsNormalizedAndEmptyForEmptyModel()
    {
        Assert.Empty(RecentProjects.Thumbnail(new StructModel()));
        var t = RecentProjects.Thumbnail(ExampleModels.Portal());
        Assert.True(t.Length >= 6 && (t.Length - 2) % 4 == 0);
        Assert.All(t, v => Assert.InRange(v, -0.001, 1.001));
    }

    [Fact]
    public void SystemOf_ReflectsMaterials()
    {
        Assert.Equal("Projet vide", RecentProjects.SystemOf(new StructModel()));
        Assert.Equal("Béton armé", RecentProjects.SystemOf(ExampleModels.Portal()));
        Assert.Equal("Acier", RecentProjects.SystemOf(ExampleModels.SteelPortal()));
    }

    // ------------------------------------------------------------------ création de projet
    private NewProjectOptions Opts(string name = "Villa") => new() { Name = name, Folder = Path.Combine(_dir, "projets") };

    [Fact]
    public void Validate_ReportsClearMessages()
    {
        var o = Opts(); o.Name = "  ";
        Assert.Contains("nom", ProjectFactory.Validate(o)!);
        o = Opts(); o.Folder = "";
        Assert.Contains("emplacement", ProjectFactory.Validate(o)!);
        o = Opts(); o.Unit = "km";
        Assert.NotNull(ProjectFactory.Validate(o));
        Assert.Null(ProjectFactory.Validate(Opts()));
    }

    [Fact]
    public void Create_WritesFile_WithChosenSettings()
    {
        var o = Opts("Hangar"); o.StructuralSystem = "Acier"; o.Norm = "CM66"; o.Unit = "cm"; o.ProjectType = "Ouvrage industriel";
        var (m, path) = ProjectFactory.Create(o);
        Assert.True(File.Exists(path));
        Assert.EndsWith("Hangar" + AppInfo.FileExt, path);
        Assert.Equal("Hangar", m.Name);
        Assert.Equal("CM66", m.SteelCodeId);
        Assert.Equal("cm", m.Settings.UnitLength);
        Assert.Equal("Ouvrage industriel", m.Info.ProjectType);
        var back = ProjectFile.Read(path);
        Assert.Equal("Hangar", back.Name);
        Assert.Equal("Ouvrage industriel", back.Info.ProjectType);
        Assert.Empty(back.Members);
    }

    [Fact]
    public void Create_RefusesExistingName_AndInvalidCharactersAreCleaned()
    {
        var o = Opts("Immeuble");
        ProjectFactory.Create(o);
        var ex = Assert.Throws<InvalidOperationException>(() => ProjectFactory.Create(o));
        Assert.Contains("déjà", ex.Message);
        var bad = Opts("Tour A/B");
        var (_, path) = ProjectFactory.Create(bad);
        Assert.True(File.Exists(path));
        Assert.StartsWith("Tour A_B", Path.GetFileName(path));
    }

    [Fact]
    public void Create_ExampleAndCatalogTemplates_ContainElements()
    {
        var ex = Opts("Avec exemple"); ex.Template = "Exemple";
        Assert.NotEmpty(ProjectFactory.Create(ex).Model.Members);
        var tp = Opts("Villa type"); tp.TemplateName = "Villa R+1";
        var (m, _) = ProjectFactory.Create(tp);
        Assert.NotEmpty(m.Members);
        Assert.Equal("Villa type", m.Name);
    }

    [Fact]
    public void DefaultNorm_FollowsSystem()
    {
        Assert.Equal("CM66", ProjectFactory.DefaultNormFor("Acier"));
        Assert.Equal("BAEL91", ProjectFactory.DefaultNormFor("Béton armé"));
        Assert.Equal("BAEL91", ProjectFactory.DefaultNormFor("Mixte"));
    }

    // ------------------------------------------------------------------ lecture contrôlée
    [Fact]
    public void Read_ReportsProgress_AndLoadsModel()
    {
        string p = Save("ok");
        var seen = new List<double>();
        var m = ProjectFile.Read(p, seen.Add);
        Assert.NotEmpty(m.Members);
        Assert.Equal(1.0, seen[^1]);
        Assert.True(seen.SequenceEqual(seen.OrderBy(x => x)));
    }

    [Theory]
    [InlineData("")]
    [InlineData("pas du json")]
    [InlineData("{ \"foo\": 1 }")]
    [InlineData("[1,2,3]")]
    public void Read_InvalidContent_GivesClearError_NotCrash(string content)
    {
        string p = Path.Combine(_dir, "mauvais.stcx");
        File.WriteAllText(p, content);
        var ex = Assert.Throws<InvalidDataException>(() => ProjectFile.Read(p));
        Assert.False(string.IsNullOrWhiteSpace(ex.Message));
    }

    [Fact]
    public void Read_MissingFile_Throws()
    {
        Assert.Throws<FileNotFoundException>(() => ProjectFile.Read(Path.Combine(_dir, "absent.stcx")));
    }

    [Theory]
    [InlineData("a.stcx", false)]
    [InlineData("a.json", false)]
    [InlineData("a.ifc", true)]
    [InlineData("a.rvt", true)]
    [InlineData("a.obj", true)]
    [InlineData("a.dxf", true)]
    [InlineData("a.xyz", true)]
    public void CheckExtension_AcceptsProjectsOnly(string file, bool refused)
    {
        string? msg = ProjectFile.CheckExtension(Path.Combine(_dir, file));
        Assert.Equal(refused, msg != null);
        if (msg != null) Assert.Contains(file, msg);
    }

    [Theory]
    [InlineData(500L, "500 octets")]
    [InlineData(2048L, "2 Ko")]
    [InlineData(3L * 1024 * 1024 + 400 * 1024, "3,4 Mo")]
    public void SizeText_IsReadable(long bytes, string expected) => Assert.Equal(expected, ProjectFile.SizeText(bytes));
}
