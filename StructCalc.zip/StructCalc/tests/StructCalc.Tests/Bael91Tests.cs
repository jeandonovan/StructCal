using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using Xunit;

public class Bael91Tests
{
    private readonly Bael91Code code = new();

    [Fact]
    public void Materials()
    {
        Assert.Equal(14.17, Bael91Materials.Fbu(25, LimitState.ELU), 2);
        Assert.Equal(434.78, Bael91Materials.SigmaSu(500, LimitState.ELU), 2);
        Assert.Equal(2.1, Bael91Materials.Ft28(25), 3);
    }

    // Poutre 25x50, d=0.45, fc28=25, FeE500, Mu=100 kN.m : mu=0.139, As ~ 5.5 cm² (calcul main)
    [Fact]
    public void Beam_Flexure_Reference()
    {
        var r = code.DesignBeamFlexure(new RcRectSection(0.25, 0.50, 0.05, 0.05), 25, 500, 100, 70, CrackingClass.PeuPrejudiciable);
        Assert.Equal(0.139, r.Values["mu"], 2);
        Assert.InRange(r.Values["As_ELU_cm2"], 5.3, 5.8);
    }

    [Fact]
    public void Beam_Shear_Reference()
    {
        // Vu=120 kN, 25x50, d=0.45 : tau = 0.12/(0.25*0.45)=1.067 MPa
        var r = code.DesignBeamShear(new RcRectSection(0.25, 0.50, 0.05, 0.05), 25, 500, 120, CrackingClass.PeuPrejudiciable);
        Assert.Equal(1.067, r.Values["tau_u"], 2);
        Assert.True(r.Ok);
    }

    [Fact]
    public void Column_Pure_Compression_Close_To_Forfaitaire()
    {
        // 30x30, Nu=1500 kN, moments quasi nuls -> doit rester dans [As_min ; As_max]
        var r = code.DesignColumn(new ColumnInput(0.30, 0.30, 2.24, 25, 500, 1500, 0, 0, 0.04));
        Assert.True(r.Ok);
        Assert.InRange(r.Values["As_cm2"], r.Values["As_min_cm2"], r.Values["As_max_cm2"]);
    }

    [Fact]
    public void Column_More_Moment_Needs_More_Steel()
    {
        var r1 = code.DesignColumn(new ColumnInput(0.30, 0.40, 2.5, 25, 500, 800, 20, 0, 0.04));
        var r2 = code.DesignColumn(new ColumnInput(0.30, 0.40, 2.5, 25, 500, 800, 90, 0, 0.04));
        Assert.True(r2.Values["As_cm2"] > r1.Values["As_cm2"]);
    }

    [Fact]
    public void Slab_Square_Simply_Supported()
    {
        // rho=1 : mux=0.0368 ; p=1.35*(25*.15+1)+1.5*2.5 -> M0x ~ mux*pu*l²
        var r = code.DesignSlab(new SlabInput(4, 4, 0.15, 1.0, 2.5, SlabContinuity.Simple, 25, 500));
        Assert.Equal(1.0, r.Values["rho"], 3);
        Assert.True(r.Values["Asx_travee_cm2m"] > 0);
    }

    [Fact]
    public void Footing_Dimensions_Consistent()
    {
        var r = code.DesignIsolatedFooting(new FootingInput(0.30, 0.30, 1000, 730, 200, 25, 500));
        Assert.True(r.Ok);
        Assert.True(r.Values["A_m"] * r.Values["B_m"] * 200 >= 730);
    }

    [Fact]
    public void Registry_Lists_Codes()
    {
        Assert.True(DesignCodeRegistry.Get("BAEL91").IsImplemented);
        Assert.True(DesignCodeRegistry.Get("EC2").IsImplemented);
        Assert.True(DesignCodeRegistry.Get("CM66").IsImplemented);
    }
}
