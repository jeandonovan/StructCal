using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

public class ManualDimTests
{
    [Fact]
    public void ManualDims_SurviveJsonRoundTrip()
    {
        var m = new StructModel();
        m.ManualDims.Add(new ManualDim { X1 = 0, Y1 = 0, Z1 = 0, X2 = 4.5, Y2 = 0, Z2 = 3, OffsetPx = 40 });
        var back = ModelIO.FromJson(ModelIO.ToJson(m));
        Assert.Single(back.ManualDims);
        Assert.Equal(4.5, back.ManualDims[0].X2, 9);
        Assert.Equal(40, back.ManualDims[0].OffsetPx, 9);
    }
}
