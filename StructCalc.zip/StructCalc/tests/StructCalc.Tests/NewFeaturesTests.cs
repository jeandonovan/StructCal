using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

namespace StructCalc.Tests;

public class NewFeaturesTests
{
    [Fact]
    public void CombinationSet_UsesCodeUnlessCustom()
    {
        var m = ExampleModels.Portal();
        var code = DesignCodeRegistry.Get(m.RcCodeId) as IReinforcedConcreteCode;
        Assert.NotNull(code);
        Assert.Same(code!.Combinations, CombinationSet.For(m, code.Combinations));
        m.UseCustomCombos = true;
        m.CustomCombos = new List<CustomCombo> { new() { Name = "ELU test", State = LimitState.ELU, G = 1.2, Q = 1.6 } };
        var c = CombinationSet.For(m, code.Combinations);
        Assert.Single(c);
        Assert.Equal(1.2, c[0].Factors[ActionType.G], 6);
        Assert.False(c[0].Factors.ContainsKey(ActionType.W));
    }

    [Fact]
    public void CombinationSet_FromCode_RoundTrips()
    {
        var m = ExampleModels.Portal();
        var code = (IReinforcedConcreteCode)DesignCodeRegistry.Get(m.RcCodeId);
        var list = CombinationSet.FromCode(code.Combinations);
        Assert.Equal(code.Combinations.Count, list.Count);
        Assert.Equal(code.Combinations[0].Name, list[0].ToCombination().Name);
    }

    [Fact]
    public void Analysis_AddsStabilityAndPdfBuilds()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, false);
        Assert.Contains(o.Extras, e => e.Title.Contains("Stabilité"));
        byte[] pdf = PdfReport.Build(m, o, null, "Bureau test");
        string head = System.Text.Encoding.Latin1.GetString(pdf, 0, 8);
        string tail = System.Text.Encoding.Latin1.GetString(pdf, pdf.Length - 8, 8);
        Assert.StartsWith("%PDF-1.4", head);
        Assert.Contains("%%EOF", tail);
        Assert.True(pdf.Length > 1500);
    }

    [Fact]
    public void TypicalDetails_DrawsSheet()
    {
        var m = ExampleModels.Portal();
        var s = TypicalDetails.Build(m).Single();
        Assert.True(s.Items.Count > 100);
        Assert.Contains(s.Items, i => i.Kind == EntKind.Text && i.Text.Contains("HA16"));
    }

    [Fact]
    public void Variants_ReturnsOneResultPerCombination()
    {
        var m = ExampleModels.Portal();
        var r = VariantComparer.Run(m, new[] { 25.0, 30.0 }, new[] { 500.0 }, new[] { 1.0 }, false);
        Assert.Equal(2, r.Count);
        Assert.All(r, v => Assert.Equal("", v.Error));
    }
}

public class DynamicsTests
{
    /// <summary>Poteau encastré en pied, masse concentrée en tête : T = 2π √(m L³ / 3EI) dans chaque direction.</summary>
    [Fact]
    public void Cantilever_Column_Period_Matches_Analytical()
    {
        double L = 4, b = 0.3, h = 0.5, W = 100;
        var m = new StructModel { IncludeSelfWeight = false, Fc28 = 25 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = L });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = b, H = h });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.G, Fz = -W });
        double mass = W / 9.81;
        // colonne verticale : B // X global, H // Y global -> rigidité en X avec Iz = h b³/12, en Y avec Iy = b h³/12
        double tx = 2 * Math.PI * Math.Sqrt(mass * L * L * L / (3 * m.EcKNm2 * h * b * b * b / 12.0));
        double ty = 2 * Math.PI * Math.Sqrt(mass * L * L * L / (3 * m.EcKNm2 * b * h * h * h / 12.0));
        var r = ModalAnalysis.Compute(m, 2);
        Assert.Equal(2, r.Modes.Count);
        Assert.Equal(tx, r.Modes[0].Period, 5);
        Assert.Equal(ty, r.Modes[1].Period, 5);
        Assert.True(r.Modes[0].Period > r.Modes[1].Period);
        Assert.Equal(1.0, r.CumulX, 6);
        Assert.Equal(1.0, r.CumulY, 6);
    }

    [Fact]
    public void Modal_SeismicPeriod_IsUsedWhenRequested()
    {
        var m = ExampleModels.Portal();
        m.Seismic.Enabled = true;
        m.Seismic.UseModalPeriod = false;
        var emp = SeismicLoads.Compute(m);
        var modal = ModalAnalysis.Compute(m, 6);
        Assert.NotEmpty(modal.Modes);
        var withT = SeismicLoads.Compute(m, modal.DominantPeriod(SeismicDirection.X));
        Assert.Equal(modal.DominantPeriod(SeismicDirection.X), withT.Period, 9);
        Assert.NotEqual(emp.Period, withT.Period);
    }
}
