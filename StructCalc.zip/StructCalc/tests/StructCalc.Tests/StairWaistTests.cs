using StructCalc.Core.Model;
using StructCalc.Engine.Stairs;
using Xunit;

/// <summary>Paillasse visible en 3D : dessous et rives sous les marches et les paliers, sans jamais passer sous le plancher bas.</summary>
public class StairWaistTests
{
    [Theory]
    [InlineData(StairLayout.Droit)]
    [InlineData(StairLayout.DroitPalier)]
    [InlineData(StairLayout.QuartPalier)]
    [InlineData(StairLayout.DemiPalier)]
    [InlineData(StairLayout.DoubleQuartPalier)]
    [InlineData(StairLayout.QuartBalance)]
    [InlineData(StairLayout.DemiBalance)]
    [InlineData(StairLayout.Helicoidal)]
    public void Waist_IsDrawn_AndStaysAboveTheLowerFloor(StairLayout layout)
    {
        var d = new StairDef { Layout = layout, HeightM = 3.2, WidthM = 1.2, Z = 0, Placed = true };
        var faces = StairShape.Build(d);
        var waist = faces.Where(f => f.Kind == StairFaceKind.Waist).ToList();
        Assert.True(waist.Count >= 3);
        Assert.True(faces.SelectMany(f => f.Pts).Min(p => p.Z) >= -1e-9);
        // le dessous de la paillasse est plus bas que le dessus des marches
        double lowestWaist = waist.SelectMany(f => f.Pts).Min(p => p.Z);
        double lowestTread = faces.Where(f => f.Kind == StairFaceKind.Tread).SelectMany(f => f.Pts).Min(p => p.Z);
        Assert.True(lowestWaist <= lowestTread + 1e-9);
    }

    [Theory]
    [InlineData(StairLayout.QuartBalance)]
    [InlineData(StairLayout.DemiBalance)]
    [InlineData(StairLayout.Helicoidal)]
    public void EveryTreadHasItsRiser_AndTheWaistCoversTheTurn(StairLayout layout)
    {
        var d = new StairDef { Layout = layout, HeightM = 3.06, WidthM = 1.0, Z = 0, Placed = true };
        var faces = StairShape.Build(d);
        int treads = faces.Count(f => f.Kind == StairFaceKind.Tread), risers = faces.Count(f => f.Kind == StairFaceKind.Riser);
        Assert.True(risers >= treads);                                  // une contremarche par marche (+ celle du palier)
        Assert.True(faces.Count(f => f.Kind == StairFaceKind.Waist) >= treads);
    }

    [Fact]
    public void MirroredStair_TurnsToTheRight()
    {
        var a = new StairDef { Layout = StairLayout.QuartPalier, HeightM = 3.06, WidthM = 1.0, Placed = true };
        var b = new StairDef { Layout = StairLayout.QuartPalier, HeightM = 3.06, WidthM = 1.0, Placed = true, Mirror = true };
        var pa = StairShape.Build(a).SelectMany(f => f.Pts).ToList();
        var pb = StairShape.Build(b).SelectMany(f => f.Pts).ToList();
        Assert.True(pa.Min(p => p.Y) >= -1e-9);                         // normal : le virage part vers +Y (gauche)
        Assert.True(pb.Max(p => p.Y) <= 1e-9);                          // symétrique : vers -Y (droite)
        Assert.Equal(pa.Max(p => p.Y), -pb.Min(p => p.Y), 6);
    }
}
