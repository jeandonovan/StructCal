using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Stairs;
using Xunit;

/// <summary>Planches d'escalier : les 8 dispositions donnent une planche, avec une coupe par volée.</summary>
public class StairSheetTests
{
    [Theory]
    [InlineData(StairLayout.Droit)]
    [InlineData(StairLayout.DroitPalier)]
    [InlineData(StairLayout.QuartPalier)]
    [InlineData(StairLayout.DemiPalier)]
    [InlineData(StairLayout.DoubleQuartPalier)]
    [InlineData(StairLayout.QuartBalance)]
    [InlineData(StairLayout.DemiBalance)]
    [InlineData(StairLayout.Helicoidal)]
    public void EveryLayout_HasSheetAndOneSectionPerFlight(StairLayout lay)
    {
        var d = new StairDef { Layout = lay, HeightM = 3.2, WidthM = 1.2 };
        var rc = (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
        var r = StairDesigner.Design(d, rc, 25, 500, new DesignSettings());
        Assert.Equal(r.Geo.Flights.Count, r.Elements.Count);
        var o = new AnalysisOutput(); o.Stairs.Add(r);
        var sheets = StairSheets.Build(o).ToList();
        Assert.Single(sheets);
        // une légende « 1 » par coupe de volée (bulle repère) : au moins une ligne de texte par volée
        Assert.True(sheets[0].Items.Count(i => i.Text.StartsWith("V") || i.Text.Contains("échelle 1:")) >= r.Elements.Count);
    }
}
