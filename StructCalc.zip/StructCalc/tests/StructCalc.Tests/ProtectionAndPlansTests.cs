using System.Security.Cryptography;
using StructCalc.Core;
using StructCalc.Core.Licensing;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

public class ProtectionAndPlansTests
{
    [Fact]
    public void License_Sign_And_Verify_RoundTrip()
    {
        using var rsa = RSA.Create(2048);
        string priv = rsa.ToXmlString(true), pub = rsa.ToXmlString(false);
        var info = new LicenseInfo { Licensee = "Client Test", Email = "a@b.c", MachineId = "AAAA-BBBB-CCCC-DDDD", IssuedUtc = DateTime.UtcNow, MaxMembers = 0 };
        string text = LicenseManager.CreateLicenseText(info, priv);
        Assert.True(LicenseManager.VerifyLicenseText(text, pub, out var back, out _));
        Assert.Equal("Client Test", back!.Licensee);
        // falsification du contenu
        string forged = text.Replace("payload", "payload").Replace(Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("x")), "y");
        using var other = RSA.Create(2048);
        Assert.False(LicenseManager.VerifyLicenseText(text, other.ToXmlString(false), out _, out _));
    }

    [Fact]
    public void License_Tampered_Payload_Is_Rejected()
    {
        using var rsa = RSA.Create(2048);
        var info = new LicenseInfo { Licensee = "X", MachineId = "*", IssuedUtc = DateTime.UtcNow };
        string text = LicenseManager.CreateLicenseText(info, rsa.ToXmlString(true));
        using var doc = System.Text.Json.JsonDocument.Parse(text);
        string payload = doc.RootElement.GetProperty("payload").GetString()!;
        string sig = doc.RootElement.GetProperty("signature").GetString()!;
        var bytes = Convert.FromBase64String(payload); bytes[bytes.Length / 2] ^= 0x01;
        string bad = System.Text.Json.JsonSerializer.Serialize(new { payload = Convert.ToBase64String(bytes), signature = sig });
        Assert.False(LicenseManager.VerifyLicenseText(bad, rsa.ToXmlString(false), out _, out _));
    }

    [Fact]
    public void MachineId_Is_Stable_And_Formatted()
    {
        string a = LicenseManager.MachineId(), b = LicenseManager.MachineId();
        Assert.Equal(a, b);
        Assert.Matches(@"^[0-9A-F]{4}(-[0-9A-F]{4}){3}$", a);
    }

    [Fact]
    public void Author_Info_Present()
    {
        Assert.Contains("EKRESSIN", AppInfo.Author);
        Assert.Contains("jeandonovan33@gmail.com", AppInfo.ContactLine);
    }

    [Fact]
    public void ModelChecker_Flags_Missing_Supports()
    {
        var ok = ModelChecker.Check(ExampleModels.Portal());
        Assert.DoesNotContain(ok, i => i.Level == IssueLevel.Error);
        var m = ExampleModels.Portal();
        m.Supports.Clear();
        Assert.Contains(ModelChecker.Check(m), i => i.Level == IssueLevel.Error);
    }

    [Fact]
    public void FrameGenerator_3D_Counts()
    {
        var m = FrameGenerator.Generate(new FrameSpec { BaysX = 2, BaysY = 2, Storeys = 2 });
        Assert.Equal(27, m.Nodes.Count);
        Assert.Equal(18 + 24, m.Members.Count);
        Assert.Equal(9, m.Supports.Count);
        Assert.DoesNotContain(ModelChecker.Check(m), i => i.Level == IssueLevel.Error);
    }

    [Fact]
    public void Connections_Are_Sized()
    {
        var beam = StructCalc.Core.Steel.SteelCatalog.Get("IPE300");
        var col = StructCalc.Core.Steel.SteelCatalog.Get("HEA240");
        var ep = ConnectionDesigner.EndPlate(beam, col, 275, 100, 80);
        Assert.True(ep.BoltDia >= 16 && ep.TensionRows >= 1 && ep.PlateT >= 12);
        var bp = ConnectionDesigner.BasePlate(col, 275, 25, 500, 30, 20);
        Assert.True(bp.PlateB >= col.B + 90 && bp.PlateT >= 15 && bp.AnchorCount >= 4);
    }

    [Fact]
    public void Plans_Generated_For_Concrete_And_Steel()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, true);
        var sheets = DrawingGenerator.Generate(m, o, licensed: false);
        Assert.True(sheets.Count >= 4);
        Assert.All(sheets, s => Assert.True(s.Items.Count > 20));
        Assert.Contains(sheets, s => s.Name == "Poutres");
        Assert.Contains(sheets, s => s.Name == "Poteaux");
        Assert.Contains(sheets, s => s.Items.Any(e => e.Layer == "FILIGRANE"));      // évaluation : filigrane

        var ms = ExampleModels.SteelPortal();
        var os = ProjectAnalyzer.Run(ms, true);
        var ss = DrawingGenerator.Generate(ms, os, licensed: true);
        Assert.Contains(ss, s => s.Name == "Assemblages");
        Assert.DoesNotContain(ss, s => s.Items.Any(e => e.Layer == "FILIGRANE"));
    }

    [Fact]
    public void Dxf_Is_Well_Formed_And_Ascii()
    {
        var s = new Sheet { Title = "Éssai œuvre" };
        s.Line(0, 0, 10, 10); s.Circle(5, 5, 2); s.Text(1, 1, 3, "Armatures Ø16 ≥ 5 cm²");
        string dxf = DxfWriter.ToDxf(s);
        Assert.Contains("SECTION", dxf); Assert.Contains("ENTITIES", dxf); Assert.EndsWith("EOF\r\n", dxf);
        Assert.Contains("LINE", dxf); Assert.Contains("CIRCLE", dxf); Assert.Contains("TEXT", dxf);
        Assert.All(dxf, c => Assert.True(c < 128));
    }

    [Fact]
    public void Ifc_Contains_All_Members()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, false);
        string ifc = IfcWriter.ToIfc(m, o, "t.ifc");
        Assert.StartsWith("ISO-10303-21;", ifc);
        Assert.Contains("FILE_SCHEMA(('IFC2X3'))", ifc);
        int beams = ifc.Split("IFCBEAM(").Length - 1, cols = ifc.Split("IFCCOLUMN(").Length - 1;
        Assert.Equal(m.Members.Count(x => x.Type == MemberType.Beam), beams);
        Assert.Equal(m.Members.Count(x => x.Type == MemberType.Column), cols);
    }
}
