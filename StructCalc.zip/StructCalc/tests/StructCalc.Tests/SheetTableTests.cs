using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

namespace StructCalc.Tests;

public class SheetTableTests
{
    private static List<Sheet> Plans()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, true);
        return DrawingGenerator.Generate(m, o, true);
    }

    [Fact]
    public void Tables_Sit_In_The_Top_Right_Corner_And_Content_Stays_Inside_Cells()
    {
        foreach (var s in Plans().Where(x => x.Tables.Count > 0))
            foreach (var t in s.Tables)
            {
                Assert.Equal(SheetTable.DefaultRight, t.Right, 3);
                Assert.Equal(SheetTable.DefaultTop, t.Top, 3);
                Assert.True(t.X0 >= 8 && t.Bottom >= 55);
                foreach (var e in s.Items.Where(i => ReferenceEquals(i.Owner, t) && i.Kind == EntKind.Text))
                {
                    Assert.InRange(e.X1, t.X0 - 0.1, t.Right + 0.1);
                    Assert.InRange(e.Y1, t.Bottom - 0.1, t.Top + 0.1);
                }
            }
    }

    [Fact]
    public void Reinforcement_Drawings_Do_Not_Run_Under_The_Table()
    {
        foreach (var s in Plans().Where(x => x.Tables.Count > 0 && (x.Name is "Poutres" or "Poteaux" or "Semelles" or "Dalles")))
        {
            var t = s.Tables[0];
            foreach (var e in s.Items.Where(i => i.Owner == null && i.Layer != "CARTOUCHE" && i.Layer != "FILIGRANE" && i.Kind == EntKind.Line))
                foreach (var (x, y) in new[] { (e.X1, e.Y1), (e.X2, e.Y2) })
                    Assert.False(x > t.X0 + 0.5 && x < t.Right - 0.5 && y > t.Bottom + 0.5 && y < t.Top - 0.5, $"{s.Name} : trait sous le tableau ({x:0.0},{y:0.0})");
        }
    }

    [Fact]
    public void Dragging_A_Column_Keeps_The_Width_And_Rebuilds_The_Content()
    {
        var s = Plans().First(x => x.Tables.Count > 0 && x.Tables[0].ShapeCol >= 0);
        var t = s.Tables[0];
        double w0 = t.Width; int n0 = s.Items.Count(i => ReferenceEquals(i.Owner, t));
        var hit = t.HitTest(t.X0 + t.ColW[0], t.GridTop - 1, 1.0);
        Assert.True(hit.HasValue && hit.Value.Kind == TableHitKind.Column);
        t.BeginDrag(); t.Drag(hit!.Value, 4, 0); t.Rebuild(s);
        Assert.Equal(w0, t.Width, 3);
        Assert.Equal(n0 > 0, s.Items.Any(i => ReferenceEquals(i.Owner, t)));
        t.BeginDrag(); t.Drag(new TableHit(TableHitKind.Left, 0), -20, 0); t.Rebuild(s);
        Assert.Equal(w0 + 20, t.Width, 3);
        t.BeginDrag(); t.Drag(new TableHit(TableHitKind.Bottom, 0), 0, -10); t.Rebuild(s);
        Assert.True(t.RowH.Min() >= SheetTable.MinRow - 1e-9);
    }
}
