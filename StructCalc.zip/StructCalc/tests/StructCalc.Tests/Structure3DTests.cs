using System.Linq;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;
using Xunit;

public class Structure3DTests
{
    [Fact]
    public void Analyze_Portal_Finds_Levels_And_Axes()
    {
        var m = ExampleModels.Portal();
        var info = StructureAnalyzer.Analyze(m);
        Assert.False(info.IsEmpty);
        Assert.True(info.Levels.Count >= 2);
        Assert.True(info.Levels[0].Z <= info.Levels[^1].Z);
        Assert.True(info.XAxes.Count + info.YAxes.Count >= 1);
        foreach (var mem in m.Members)
            Assert.NotNull(info.LevelOfMember(mem.Id));
    }

    [Fact]
    public void Describe_Strings_Are_Not_Empty()
    {
        var m = ExampleModels.Portal();
        var info = StructureAnalyzer.Analyze(m);
        Assert.False(string.IsNullOrWhiteSpace(StructureAnalyzer.Overview(m, info)));
        Assert.False(string.IsNullOrWhiteSpace(StructureAnalyzer.DescribeLevel(m, info, 0)));
        Assert.False(string.IsNullOrWhiteSpace(StructureAnalyzer.DescribeMember(m, info, m.Members[0].Id, null)));
        Assert.False(string.IsNullOrWhiteSpace(StructureAnalyzer.MemberTitle(m, m.Members[0].Id, null)));
    }

    [Fact]
    public void Solids_Are_Built_For_Every_Member_With_Unit_Normals()
    {
        var m = ExampleModels.Portal();
        var faces = MemberSolids.Build(m);
        Assert.NotEmpty(faces);
        foreach (var mem in m.Members) Assert.Contains(faces, f => f.MemberId == mem.Id);
        Assert.All(faces, f => Assert.InRange(f.N.Length, 0.99, 1.01));
    }

    [Fact]
    public void Solids_Bounds_Cover_The_Nodes()
    {
        var m = ExampleModels.Portal();
        var (min, max) = MemberSolids.Bounds(MemberSolids.Build(m));
        Assert.True(min.X <= m.Nodes.Min(n => n.X) + 1e-6);
        Assert.True(max.X >= m.Nodes.Max(n => n.X) - 1e-6);
        Assert.True(max.Z >= m.Nodes.Max(n => n.Z) - 1e-6);
    }

    [Fact]
    public void AlphaName_Sequence()
    {
        Assert.Equal("A", StructureAnalyzer.AlphaName(0));
        Assert.Equal("B", StructureAnalyzer.AlphaName(1));
    }
}
