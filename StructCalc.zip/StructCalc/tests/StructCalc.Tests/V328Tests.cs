using StructCalc.Core.Model;
using StructCalc.Engine.Stairs;
using Xunit;

namespace StructCalc.Tests;

public class V328Tests
{
    public static IEnumerable<object[]> Layouts() => Enum.GetValues<StairLayout>().Select(l => new object[] { l });

    [Theory]
    [MemberData(nameof(Layouts))]
    public void EveryStairType_IsDrawnUpToTheFloorAbove(StairLayout layout)
    {
        var d = new StairDef { Layout = layout, HeightM = 3.06, WidthM = 1.2, Z = 3.0, Placed = true };
        var g = StairGeometryBuilder.Build(d);
        var faces = StairShape.Build(d);
        Assert.NotEmpty(faces);
        var treads = faces.Count(f => f.Kind == StairFaceKind.Tread);
        int expected = layout switch
        {
            StairLayout.Droit => g.Risers - 1,
            StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier => g.Risers - 2,
            StairLayout.DoubleQuartPalier => g.Risers - 3,
            _ => g.Risers - 1
        };
        Assert.Equal(expected, treads);
        double zmax = faces.Where(f => f.Kind != StairFaceKind.Rail).SelectMany(f => f.Pts).Max(p => p.Z), zmin = faces.SelectMany(f => f.Pts).Min(p => p.Z);
        Assert.Equal(3.0 + 3.06, zmax, 3);
        Assert.True(zmin >= 3.0 - 1e-9);
    }

    [Fact]
    public void Rotation_TurnsTheFootprint()
    {
        var a = new StairDef { Layout = StairLayout.Droit, HeightM = 3.0, Placed = true };
        var b = new StairDef { Layout = StairLayout.Droit, HeightM = 3.0, AngleDeg = 90, Placed = true };
        var fa = StairShape.Build(a).SelectMany(f => f.Pts).ToList();
        var fb = StairShape.Build(b).SelectMany(f => f.Pts).ToList();
        double lenA = fa.Max(p => p.X) - fa.Min(p => p.X), lenB = fb.Max(p => p.Y) - fb.Min(p => p.Y);
        Assert.Equal(lenA, lenB, 3);
    }

    [Fact]
    public void Winders_StayInsideTheTurningSquare()
    {
        var d = new StairDef { Layout = StairLayout.QuartBalance, HeightM = 3.06, WidthM = 1.0, Placed = true };
        var winders = StairShape.Build(d).Where(f => f.Kind == StairFaceKind.Tread && f.Pts.Length == 3).ToList();
        Assert.True(winders.Count >= 2);
        foreach (var f in winders)
        {
            double minX = f.Pts.Min(p => p.X), maxX = f.Pts.Max(p => p.X), minY = f.Pts.Min(p => p.Y), maxY = f.Pts.Max(p => p.Y);
            Assert.True(maxX - minX <= 1.0 + 1e-6 && maxY - minY <= 1.0 + 1e-6);
        }
    }

    [Fact]
    public void StairDef_PlacedFlag_SurvivesClone()
    {
        var d = new StairDef { Placed = true };
        Assert.True(d.Clone().Placed);
        Assert.False(new StairDef().Placed);
    }

    [Fact]
    public void FootingGlacis_ReducesConcrete_AndIsReported()
    {
        var soil = new SoilProfile();
        soil.Layers.Add(new SoilLayer { Name = "Sable", PhiDeg = 32, CKPa = 0, GammaKnM3 = 18, GammaSatKnM3 = 20, EoedMPa = 30 });
        var rc = (StructCalc.Core.IReinforcedConcreteCode)StructCalc.Core.DesignCodeRegistry.Get("BAEL91");
        var f = new FootingDef { NuKN = 1000, NserKN = 730 };
        var block = StructCalc.Engine.Geotech.FootingSizer.Design(f, soil, rc, 25, 500, 0.05);
        f.Glacis = true;
        var gl = StructCalc.Engine.Geotech.FootingSizer.Design(f, soil, rc, 25, 500, 0.05);
        Assert.True(gl.ConcreteM3 < block.ConcreteM3);
        Assert.Contains("glacis", gl.Report);
        Assert.Contains("Vérification du glacis", gl.Report);
        Assert.Equal(1.0, gl.Design.Values["glacis"]);
        Assert.False(block.Design.Values.ContainsKey("glacis"));
        Assert.Equal(block.A, gl.A, 6);
    }

    [Fact]
    public void FootingDefinedInAssistant_GovernsThePlacedFooting()
    {
        var m = new StructModel();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.3, H = 0.3 });
        m.FootingGlacis = false;
        m.FootingDefs.Add(new FootingDef { Name = "S1", Glacis = true, GlacisEdgeCm = 25 });
        var o = new StructCalc.Engine.AnalysisOutput();
        var dr = new StructCalc.Core.DesignResult { Element = "Semelle sous nœud 1 (Nu=100 kN, Nser=70 kN)" };
        dr.Values["A_m"] = 1.0; dr.Values["B_m"] = 1.0; dr.Values["h_m"] = 0.4;
        o.Footings.Add(dr);
        var pf = StructCalc.Engine.Geometry.FootingPlacement.From(m, o).Single();
        Assert.True(pf.Glacis);
        Assert.True(pf.FromAssistant);
        Assert.Equal(25, pf.EdgeCm, 6);
    }
}
