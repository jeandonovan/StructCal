using System.Linq;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;
using Xunit;

public class GridAndUnderlayTests
{
    private static StructModel GridModel()
    {
        var m = new StructModel();
        m.Grid.XAxes = GridTools.BuildAxes(0, new[] { 5.0, 5.0 }, true);       // 1, 2, 3
        m.Grid.YAxes = GridTools.BuildAxes(0, new[] { 6.0 }, false);           // A, B
        m.Levels = GridTools.GenerateStoreys(2, 0, new[] { 3.0 });             // Base, Niveau 1, Terrasse? (2 étages)
        return m;
    }

    [Fact]
    public void ParseSpacings_Groups_And_Decimal_Comma()
    {
        var s = GridTools.ParseSpacings("3x5 4,5", out string err);
        Assert.Equal("", err);
        Assert.Equal(new[] { 5.0, 5.0, 5.0, 4.5 }, s.ToArray());
        GridTools.ParseSpacings("abc", out string err2);
        Assert.NotEqual("", err2);
        GridTools.ParseSpacings("0x5", out string err3);
        Assert.NotEqual("", err3);
    }

    [Fact]
    public void BuildAxes_Names_And_Positions()
    {
        var x = GridTools.BuildAxes(1.0, new[] { 4.0, 2.5 }, true);
        Assert.Equal(new[] { "1", "2", "3" }, x.Select(a => a.Name).ToArray());
        Assert.Equal(new[] { 1.0, 5.0, 7.5 }, x.Select(a => a.Pos).ToArray());
        var y = GridTools.BuildAxes(0, new[] { 3.0 }, false);
        Assert.Equal(new[] { "A", "B" }, y.Select(a => a.Name).ToArray());
        Assert.Equal("4x5 3", GridTools.SpacingText(GridTools.BuildAxes(0, new[] { 5.0, 5.0, 5.0, 5.0, 3.0 }, true)));
    }

    [Fact]
    public void GenerateStoreys_Names_And_Elevations()
    {
        var l = GridTools.GenerateStoreys(3, 0, new[] { 3.5, 3.0 });
        Assert.Equal(4, l.Count);
        Assert.Equal("Base", l[0].Name);
        Assert.Equal(new[] { 0.0, 3.5, 6.5, 9.5 }, l.Select(q => q.Elevation).ToArray());
        Assert.Equal("Terrasse", l[3].Name);
    }

    [Fact]
    public void GenerateFrame_Counts_And_No_Duplicates()
    {
        var m = GridModel();                                                   // 3 x 2 axes, 3 niveaux
        var r = GridTools.GenerateFrame(m, new GridTools.FrameOptions { G = 10, Q = 3 });
        Assert.Equal(18, r.NewNodes);
        Assert.Equal(12, r.NewColumns);
        Assert.Equal(14, r.NewBeams);                                          // 2 niveaux x (2 axes y x 2 travées + 3 axes x x 1 travée)
        Assert.Equal(6, r.NewSupports);
        Assert.Equal(28, m.MemberLoads.Count);                                 // G et Q sur chaque poutre
        var again = GridTools.GenerateFrame(m, new GridTools.FrameOptions());
        Assert.Equal(0, again.NewNodes + again.NewColumns + again.NewBeams + again.NewSupports);
    }

    [Fact]
    public void Analyze_Uses_User_Levels_And_Grid()
    {
        var m = GridModel();
        GridTools.GenerateFrame(m, new GridTools.FrameOptions());
        m.Levels[1].Name = "RDC";
        var info = StructureAnalyzer.Analyze(m);
        Assert.True(info.UserLevels && info.UserGrid);
        Assert.Equal(3, info.Levels.Count);
        Assert.Equal("RDC", info.Levels[1].Name);
        Assert.Equal(new[] { "1", "2", "3" }, info.XAxes.Select(a => a.Name).ToArray());
        Assert.Equal("B-2", info.AxisRef(5, 6));
    }

    [Fact]
    public void Analyze_Grid_Only_Model_Is_Not_Empty()
    {
        var m = GridModel();
        var info = StructureAnalyzer.Analyze(m);
        Assert.False(info.IsEmpty);
        Assert.Equal(10, info.MaxX);
        Assert.Equal(6, info.MaxZ);
    }

    [Fact]
    public void DuplicateTypicalStorey_Adds_Members_And_Levels()
    {
        var m = GridModel();
        GridTools.GenerateFrame(m, new GridTools.FrameOptions());
        int before = m.Members.Count;
        var (added, levels) = GridTools.DuplicateTypicalStorey(m, 2, 2);
        Assert.Equal(2, levels);
        Assert.Equal(26, added);                                               // (7 poutres + 6 poteaux) x 2
        Assert.Equal(before + 26, m.Members.Count);
        Assert.Equal(5, m.Levels.Count);
        Assert.Equal(12.0, m.Levels.Max(l => l.Elevation), 3);
    }

    // ------------------------------------------------------------------ DXF
    private const string Dxf1 =
        "0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n" +
        "0\nSECTION\n2\nENTITIES\n" +
        "0\nLINE\n8\nWALLS\n10\n0.0\n20\n0.0\n11\n1000.0\n21\n0.0\n" +
        "0\nLWPOLYLINE\n8\nWALLS\n90\n4\n70\n1\n10\n0\n20\n0\n10\n1000\n20\n0\n10\n1000\n20\n500\n10\n0\n20\n500\n" +
        "0\nCIRCLE\n8\nCOL\n10\n200\n20\n200\n40\n150\n" +
        "0\nENDSEC\n0\nEOF\n";

    [Fact]
    public void Dxf_Reads_Lines_Polylines_Circles_And_Units()
    {
        var d = DxfReader.Parse(Dxf1);
        Assert.Equal(53, d.Segments.Count);                                    // 1 + 4 + 48
        Assert.Equal(4, d.InsUnits);
        Assert.Equal(0.001, d.MetersPerUnit, 6);
        Assert.Equal(1000, d.MaxX, 6);
        Assert.Equal(500, d.MaxY, 6);
        Assert.Contains(d.Layers, l => l.Name == "COL");
        Assert.Contains(d.Points, p => Math.Abs(p.X - 200) < 1e-9 && Math.Abs(p.Y - 200) < 1e-9);
        Assert.Equal(0.001, UnderlayMath.DxfInitialScale(d), 6);
    }

    [Fact]
    public void Dxf_Insert_Applies_Scale_Rotation_And_Position()
    {
        string dxf =
            "0\nSECTION\n2\nBLOCKS\n0\nBLOCK\n8\n0\n2\nB1\n70\n0\n10\n0\n20\n0\n30\n0\n3\nB1\n" +
            "0\nLINE\n8\n0\n10\n0\n20\n0\n11\n1\n21\n0\n0\nENDBLK\n8\n0\n0\nENDSEC\n" +
            "0\nSECTION\n2\nENTITIES\n0\nINSERT\n8\n0\n2\nB1\n10\n10\n20\n10\n41\n2\n42\n2\n50\n90\n0\nENDSEC\n0\nEOF\n";
        var d = DxfReader.Parse(dxf);
        Assert.Single(d.Segments);
        var s = d.Segments[0];
        Assert.Equal(10, s.X1, 6); Assert.Equal(10, s.Y1, 6);
        Assert.Equal(10, s.X2, 6); Assert.Equal(12, s.Y2, 6);
    }

    [Fact]
    public void Dxf_Bulge_Makes_An_Arc()
    {
        // demi-cercle de (0,0) à (2,0), bulge = 1 : le point le plus éloigné est à 1 m de la corde
        string dxf = "0\nSECTION\n2\nENTITIES\n0\nLWPOLYLINE\n8\n0\n90\n2\n70\n0\n10\n0\n20\n0\n42\n1\n10\n2\n20\n0\n0\nENDSEC\n0\nEOF\n";
        var d = DxfReader.Parse(dxf);
        Assert.True(d.Segments.Count >= 6);
        double extreme = d.Segments.Max(s => Math.Max(Math.Abs(s.Y1), Math.Abs(s.Y2)));
        Assert.Equal(1.0, extreme, 2);
    }

    // ------------------------------------------------------------------ calage
    [Fact]
    public void Underlay_Model_Roundtrip_And_Calibrate()
    {
        var u = new UnderlayDef { Scale = 0.01, Rotation = 30, OriginX = 5, OriginY = -2 };
        var p = UnderlayMath.ToModel(u, 120, 80);
        var back = UnderlayMath.FromModel(u, p.X, p.Y);
        Assert.Equal(120, back.X, 6); Assert.Equal(80, back.Y, 6);

        var a = UnderlayMath.ToModel(u, 0, 0); var b = UnderlayMath.ToModel(u, 100, 0);
        double d0 = Math.Sqrt((b.X - a.X) * (b.X - a.X) + (b.Y - a.Y) * (b.Y - a.Y));
        Assert.True(UnderlayMath.Calibrate(u, a, b, d0 * 2));
        var a2 = UnderlayMath.ToModel(u, 0, 0); var b2 = UnderlayMath.ToModel(u, 100, 0);
        Assert.Equal(a.X, a2.X, 6); Assert.Equal(a.Y, a2.Y, 6);               // le premier point reste fixe
        Assert.Equal(d0 * 2, Math.Sqrt((b2.X - a2.X) * (b2.X - a2.X) + (b2.Y - a2.Y) * (b2.Y - a2.Y)), 6);
    }

    [Fact]
    public void Underlay_Align_Makes_Line_Horizontal()
    {
        var u = new UnderlayDef { Scale = 1, Rotation = 20 };
        var a = UnderlayMath.ToModel(u, 0, 0); var b = UnderlayMath.ToModel(u, 10, 0);
        Assert.True(UnderlayMath.Align(u, a, b));
        var a2 = UnderlayMath.ToModel(u, 0, 0); var b2 = UnderlayMath.ToModel(u, 10, 0);
        Assert.Equal(a2.Y, b2.Y, 6);
        Assert.Equal(a.X, a2.X, 6);
    }

    [Fact]
    public void PdfScale_A1_At_1_100()
    {
        // feuille A1 (841 mm) rendue sur 4800 px à l'échelle 1/100 : 84,1 m / 4800 px
        Assert.Equal(0.841 * 100 / 4800, UnderlayMath.PdfScale(841, 4800, 100), 9);
    }

    // ------------------------------------------------------------------ accrochage raster
    private static byte[] Cross(int w, int h, int cx, int cy, int arm)
    {
        var ink = new byte[w * h];
        for (int d = -arm; d <= arm; d++)
            for (int t = 0; t < 2; t++)
            {
                ink[(cy + t) * w + (cx + d)] = 1;
                ink[(cy + d) * w + (cx + t)] = 1;
            }
        return ink;
    }

    [Fact]
    public void RasterSnap_Finds_Intersection()
    {
        var ink = Cross(120, 120, 60, 60, 40);
        Assert.True(RasterSnap.Find(ink, 120, 120, 64, 57, 10, out double fx, out double fy, out var kind));
        Assert.Equal(RasterSnapKind.Cross, kind);
        Assert.InRange(fx, 57, 64); Assert.InRange(fy, 57, 64);
    }

    [Fact]
    public void RasterSnap_Finds_Line_And_Nothing_In_Empty_Area()
    {
        var ink = new byte[100 * 100];
        for (int x = 10; x < 90; x++) { ink[50 * 100 + x] = 1; ink[51 * 100 + x] = 1; }
        Assert.True(RasterSnap.Find(ink, 100, 100, 50, 54, 8, out double fx, out double fy, out var kind));
        Assert.Equal(RasterSnapKind.Line, kind);
        Assert.InRange(fy, 49, 52);
        Assert.False(RasterSnap.Find(ink, 100, 100, 50, 85, 8, out _, out _, out _));
    }
}
