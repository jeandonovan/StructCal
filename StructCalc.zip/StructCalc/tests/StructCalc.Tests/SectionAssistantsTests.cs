using StructCalc.Engine.Sections;
using Xunit;

/// <summary>Assistants poutre et poteau : sections rectangulaire, en T, en L, circulaire.</summary>
public class SectionAssistantsTests
{
    [Fact]
    public void RectBeam_MatchesClosedForm()
    {
        var r = BeamSectionDesigner.Design(new BeamSectionInput { Bw = 0.30, H = 0.50, Dprime = 0.05, MuSag = 200, MuHog = 0, Vu = 100 });
        Assert.InRange(r.AsBottom, 11.5, 12.1);              // mu = 0,232 ; z = 0,39 m ; As = 11,8 cm²
        Assert.NotNull(r.Bottom);
        Assert.True(r.StirSpacingCm > 0);
    }

    [Fact]
    public void TeeBeam_UsesFlangeWidth_AndNeedsLessSteelThanRectangle()
    {
        var tee = new BeamSectionInput { Shape = SectionShape.Tee, Bw = 0.30, H = 0.60, Hf = 0.15, BiLeft = 1.5, BiRight = 1.5, Span = 8, Position = SpanPosition.EndSpan, MuSag = 300 };
        double b = BeamSectionDesigner.TableWidth(tee, out double l0, out _);
        Assert.Equal(6.8, l0, 6);
        Assert.Equal(0.30 + 2 * 0.98, b, 6);                  // beff,i = min(0,2 bi + 0,1 l0 ; 0,2 l0 ; bi) = 0,98 m
        var rt = BeamSectionDesigner.Design(tee);
        var rr = BeamSectionDesigner.Design(new BeamSectionInput { Bw = 0.30, H = 0.60, MuSag = 300 });
        Assert.True(rt.AsBottom < rr.AsBottom);
    }

    [Fact]
    public void LBeam_HasOneSidedFlange()
    {
        var p = new BeamSectionInput { Shape = SectionShape.Ell, Bw = 0.30, H = 0.60, Hf = 0.15, BiRight = 1.5, Span = 8 };
        double b = BeamSectionDesigner.TableWidth(p, out _, out _);
        Assert.Equal(0.30 + 0.98, b, 6);
    }

    [Fact]
    public void FiberSection_ReproducesBeamMoment()
    {
        var g = new SectionGeom { Shape = SectionShape.Rectangle, B = 0.30, H = 0.50 };
        var bars = new List<BarGroup> { new(0.15, 0.45, 11.81) };
        var curve = FiberSection.Curve(g, bars, new Mat());
        double m = FiberSection.MomentAt(curve, 0);
        Assert.InRange(m, 200 * 0.92, 200 * 1.08);
    }

    [Fact]
    public void CircleGeometry_AreaAndInertia()
    {
        var g = new SectionGeom { Shape = SectionShape.Circle, B = 0.40 };
        Assert.InRange(g.Area, Math.PI * 0.04 * 0.995, Math.PI * 0.04 * 1.005);
        Assert.InRange(g.Inertia, Math.PI * Math.Pow(0.40, 4) / 64 * 0.99, Math.PI * Math.Pow(0.40, 4) / 64 * 1.01);
    }

    [Fact]
    public void RectColumn_IsDesignedAndCovered()
    {
        var r = ColumnSectionDesigner.Design(new ColumnSectionInput { B = 0.40, H = 0.40, Nu = 1200, Mu = 40, Lf = 3.0 });
        Assert.True(r.Ok, string.Join(" ; ", r.Warnings));
        Assert.True(r.MRes >= r.MTot);
        Assert.True(r.AsUsed >= r.AsMin);
        Assert.True(r.N0 > 1200);
    }

    [Fact]
    public void CircularColumn_AtLeastSixBars()
    {
        var r = ColumnSectionDesigner.Design(new ColumnSectionInput { Shape = SectionShape.Circle, B = 0.40, Nu = 1000, Mu = 30, Lf = 3.0 });
        Assert.True(r.Ok, string.Join(" ; ", r.Warnings));
        Assert.True(r.Bars!.Count >= 6);
        Assert.Equal(r.Bars.Count, r.BarPositions.Count);
    }

    [Fact]
    public void TeeColumn_SignOfMomentMatters()
    {
        var plus = ColumnSectionDesigner.Design(new ColumnSectionInput { Shape = SectionShape.Tee, B = 0.60, Hf = 0.15, Bw = 0.25, H = 0.50, Nu = 300, Mu = 250, Lf = 2.5 });
        var minus = ColumnSectionDesigner.Design(new ColumnSectionInput { Shape = SectionShape.Tee, B = 0.60, Hf = 0.15, Bw = 0.25, H = 0.50, Nu = 300, Mu = -250, Lf = 2.5 });
        // sous compression, comprimer la table (proche du centre de gravité) ou le talon (loin) donne des armatures différentes : le signe compte
        Assert.True(Math.Abs(plus.AsReq - minus.AsReq) > 0.5, $"{plus.AsReq} vs {minus.AsReq}");
        Assert.True(plus.MRes > 0 && minus.MRes > 0);
    }

    [Fact]
    public void OverloadedColumn_IsFlagged()
    {
        var r = ColumnSectionDesigner.Design(new ColumnSectionInput { B = 0.20, H = 0.20, Nu = 3000, Mu = 80, Lf = 3.0 });
        Assert.False(r.Ok);
    }
}
