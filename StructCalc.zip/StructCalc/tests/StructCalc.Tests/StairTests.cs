using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Stairs;
using Xunit;

/// <summary>Escaliers : géométrie (Blondel), charges par couches (exemples de cours), statique des volées, dimensionnement.</summary>
public class StairTests
{
    private static StairDef Cours() => new()
    {
        Layout = StairLayout.Droit, HeightM = 1.53, WidthM = 1.0, TargetRiserCm = 17, TargetTreadCm = 30,
        StartLandingM = 1.65, EndLandingM = 0.70, SlabThicknessCm = 18, StepDensity = 22,
    };

    [Fact]
    public void Geometry_CoursEscalier_9Risers_Blondel()
    {
        var g = StairGeometryBuilder.Build(Cours());
        Assert.Equal(9, g.Risers);
        Assert.Equal(0.17, g.RiserM, 6);
        Assert.Equal(0.30, g.TreadM, 6);
        Assert.Equal(64, g.Blondel * 100, 4);
        Assert.True(g.BlondelOk);
        Assert.Equal(29.54, g.AngleDeg, 1);   // atan(17/30)
        Assert.Equal(2.40, g.Flights[0].RunM, 6);        // (n-1) x g
        Assert.Equal(0.18, g.ThicknessM, 6);
    }

    [Fact]
    public void Loads_MatchTextbookExample()
    {
        var d = Cours();
        d.SlabThicknessCm = 21;                                      // exemple simple : e = 21 cm
        d.TreadCoverCm = 0; d.RiserCoverCm = 0; d.MortarCm = 0; d.PlasterCm = 0; d.RailingKnPerM = 0;
        var g = StairGeometryBuilder.Build(d);
        var lt = StairDesigner.Loads(d, g);
        Assert.Equal(25 * 0.21 / Math.Cos(29.53 * Math.PI / 180), lt.Flight[0].Value, 2);     // 6,03 kN/m²
        Assert.Equal(6.03, lt.Flight[0].Value, 2);
        Assert.Equal(1.87, lt.Flight[1].Value, 2);                                           // marches : 22 x 0,17 / 2
        Assert.Equal(5.25, lt.Landing[0].Value, 2);                                          // palier e = 21 cm
    }

    [Fact]
    public void Statics_UniformBeam_M0()
    {
        var b = new BeamStatics(new[] { new StructCalc.Engine.Stairs.LoadSeg(5, 10) }, 0, 0, false, false);
        Assert.Equal(10 * 25 / 8.0, b.M0Max, 3);
        Assert.Equal(25.0, b.RA, 6);
        Assert.Equal(25.0, b.VMax, 3);
    }

    [Fact]
    public void Statics_FixedFixed_Uniform_EndMomentWL2_12()
    {
        var b = new BeamStatics(new[] { new StructCalc.Engine.Stairs.LoadSeg(6, 8) }, 0, 0, true, true);
        Assert.Equal(8 * 36 / 12.0, b.Ma, 1);
        Assert.Equal(8 * 36 / 12.0, b.Mb, 1);
        Assert.Equal(8 * 36 / 24.0, b.MtMax, 1);
    }

    [Fact]
    public void Statics_PartialLoads_ReactionsBalance()
    {
        var b = new BeamStatics(new[] { new StructCalc.Engine.Stairs.LoadSeg(1.65, 5.9), new StructCalc.Engine.Stairs.LoadSeg(2.85, 12.95), new StructCalc.Engine.Stairs.LoadSeg(0.7, 5.9) }, 0, 0, false, false);
        double total = 1.65 * 5.9 + 2.85 * 12.95 + 0.7 * 5.9;
        Assert.Equal(total, b.RA + b.RB, 6);
    }

    [Theory]
    [InlineData(StairLayout.Droit)]
    [InlineData(StairLayout.DroitPalier)]
    [InlineData(StairLayout.QuartPalier)]
    [InlineData(StairLayout.DemiPalier)]
    [InlineData(StairLayout.DoubleQuartPalier)]
    [InlineData(StairLayout.QuartBalance)]
    [InlineData(StairLayout.DemiBalance)]
    [InlineData(StairLayout.Helicoidal)]
    public void AllLayouts_ProduceConsistentRisers(StairLayout l)
    {
        var d = new StairDef { Layout = l, HeightM = 3.06, WidthM = 1.2, TargetTreadCm = 28 };
        var g = StairGeometryBuilder.Build(d);
        Assert.True(g.Risers >= 16 && g.Risers <= 20);
        Assert.Equal(d.HeightM, g.Risers * g.RiserM, 6);
        if (l != StairLayout.QuartBalance && l != StairLayout.DemiBalance && l != StairLayout.Helicoidal)
            Assert.Equal(g.Risers, g.Flights.Sum(f => f.Steps));
        Assert.True(g.Flights.Count >= 1);
        var rc = (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
        var r = StairDesigner.Design(d, rc, 25, 400, new DesignSettings());
        Assert.NotEmpty(r.Elements);
        Assert.All(r.Elements, e => Assert.True(e.AsT > 0));
        Assert.False(string.IsNullOrWhiteSpace(r.Report));
    }

    [Theory]
    [InlineData(StairLayout.Droit)]
    [InlineData(StairLayout.DroitPalier)]
    [InlineData(StairLayout.QuartPalier)]
    [InlineData(StairLayout.DemiPalier)]
    [InlineData(StairLayout.DoubleQuartPalier)]
    [InlineData(StairLayout.QuartBalance)]
    [InlineData(StairLayout.DemiBalance)]
    [InlineData(StairLayout.Helicoidal)]
    public void AllLayouts_TreadsAreRisersMinusOne_AndSlopeIsConsistent(StairLayout l)
    {
        var d = new StairDef { Layout = l, HeightM = 3.06, WidthM = 1.2, TargetTreadCm = 28 };
        var g = StairGeometryBuilder.Build(d);
        int n = g.Risers;
        Assert.Equal(d.HeightM, n * g.RiserM, 6);
        double h = g.RiserM;
        foreach (var f in g.Flights)
        {
            // pente de la ligne de nez : (k-1) h sur la reculée de la paillasse, identique à l'angle et à la longueur inclinée
            Assert.Equal(Math.Atan2((f.Steps - 1) * h, f.RunM) * 180 / Math.PI, f.AngleDeg, 4);
            Assert.Equal(Math.Sqrt(f.RunM * f.RunM + Math.Pow((f.Steps - 1) * h, 2)), f.InclinedM, 4);
        }
        if (l is not (StairLayout.QuartBalance or StairLayout.DemiBalance or StairLayout.Helicoidal))
            Assert.Equal(n - g.Flights.Count, g.Flights.Sum(f => (int)Math.Round(f.RunM / g.TreadM)));   // chaque volée de k contremarches a k-1 girons
        else if (l != StairLayout.Helicoidal)
        {
            int nw = StairGeometryBuilder.WinderCount(l);
            double corner = (nw == 3 ? Math.PI / 2 : Math.PI) * d.WidthM / 2;
            Assert.Equal((n - 1 - nw) * g.TreadM + corner, g.Flights[0].RunM, 6);              // n-1 girons au total, dont nw balancés
        }
        else Assert.Equal((n - 1) * g.TreadM, g.Flights[0].RunM, 6);
    }

    [Fact]
    public void Design_StraightFlight_RaisesThicknessWarningWhenThin()
    {
        var d = new StairDef { Layout = StairLayout.Droit, HeightM = 3.4, WidthM = 1.2, SlabThicknessCm = 8, StartLandingM = 1.0, EndLandingM = 1.0 };
        var rc = (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
        var r = StairDesigner.Design(d, rc, 25, 400, new DesignSettings());
        Assert.False(r.Ok);
    }

    [Fact]
    public void Analyzer_IncludesStairsInOutputAndQuantities()
    {
        var m = ExampleModels.Portal();
        m.Stairs.Add(new StairDef { Layout = StairLayout.DroitPalier, HeightM = 3.0, WidthM = 1.2 });
        var o = ProjectAnalyzer.Run(m, optimize: false);
        Assert.Single(o.Stairs);
        Assert.Contains(o.Extras, x => x.Title.StartsWith("Escalier"));
        var q0 = Quantities.Compute(m, o);
        Assert.True(q0.ConcreteM3 > 0);
        var sheets = StructCalc.Engine.Drawing.DrawingGenerator.Generate(m, o, true);
        Assert.Contains(sheets, s => s.Name.StartsWith("Escalier"));
    }
}

public class RibbedFloorTests
{
    [Fact]
    public void Forfaitaire_FiveSpans_Works()
    {
        var rc = (StructCalc.Core.IReinforcedConcreteCode)StructCalc.Core.DesignCodeRegistry.Get("BAEL91");
        var d = new StructCalc.Core.Model.RibbedFloorDef();
        var r = StructCalc.Engine.Floors.RibbedFloorDesigner.Design(d, rc, 25, 400);
        Assert.Contains("forfaitaire", r.Method);
        Assert.Equal(5, r.Spans.Count);
        Assert.All(r.Spans, s => Assert.True(s.AsT > 0));
        Assert.Equal(2.85, StructCalc.Engine.Floors.RibbedFloorDesigner.SelfWeight(16, 4), 2);
    }

    [Fact]
    public void ThreeMoments_TwoEqualSpans_MatchesClassic()
    {
        var M = StructCalc.Engine.Floors.ContinuousBeam.SupportMoments(new[] { 4.0, 4.0 }, new[] { 10.0, 10.0 });
        Assert.Equal(-20.0, M[1], 6);   // -wL²/8
    }
}

public class SoilTests
{
    [Fact]
    public void Terzaghi_Factors_Phi30()
    {
        var (nq, nc, ng) = StructCalc.Engine.Geotech.SoilMechanics.Factors(30);
        Assert.Equal(18.4, nq, 1);
        Assert.Equal(30.14, nc, 1);
        Assert.True(ng > 15 && ng < 25);
    }

    [Fact]
    public void Footing_OnSand_IsSized()
    {
        var soil = new StructCalc.Core.Model.SoilProfile();
        soil.Layers.Add(new StructCalc.Core.Model.SoilLayer { Name = "Sable", PhiDeg = 32, CKPa = 0, GammaKnM3 = 18, GammaSatKnM3 = 20, EoedMPa = 30 });
        var rc = (StructCalc.Core.IReinforcedConcreteCode)StructCalc.Core.DesignCodeRegistry.Get("BAEL91");
        var f = new StructCalc.Core.Model.FootingDef { NuKN = 1000, NserKN = 730 };
        var r = StructCalc.Engine.Geotech.FootingSizer.Design(f, soil, rc, 25, 500, 0.05);
        Assert.True(r.Ok, r.Report);
        Assert.True(r.A >= 0.8 && r.A < 3);
        Assert.True(r.SigmaMax <= r.QAdm * 1.01);
    }
}

public class WallTests
{
    private static StructCalc.Core.IReinforcedConcreteCode Rc() => (StructCalc.Core.IReinforcedConcreteCode)StructCalc.Core.DesignCodeRegistry.Get("BAEL91");

    [Fact]
    public void Cantilever_Wall_TopLoad_MatchesTimoshenko()
    {
        // voile plein 4 m x 3 m, e = 0,2 m, effort horizontal en tête de 100 kN, poids propre et charges nulles
        var w = new StructCalc.Core.Model.WallDef { LengthM = 4, HeightM = 3, ThicknessM = 0.2, MeshM = 0.25, SelfWeight = false, GTopKnPerM = 0, QTopKnPerM = 0, EHorizKn = 100, WindKPa = 0, TopHeldOutOfPlane = false };
        var solver = new StructCalc.Engine.Walls.WallSolver(w, 25);
        var r = solver.SolveCase(solver.TopHorizontal(100e3));
        double E = solver.E, I = 0.2 * Math.Pow(4, 3) / 12, G = E / 2.4, A = 0.2 * 4;
        double exact = 100e3 * Math.Pow(3, 3) / (3 * E * I) + 100e3 * 3 / (5.0 / 6.0 * G * A);
        double max = 0;
        for (int k = 0; k < solver.Mesh.Nodes.Count; k++) max = Math.Max(max, Math.Abs(r.U[5 * k]));
        Assert.InRange(max / exact, 0.85, 1.20);     // tête du voile : mouvement du bord supérieur
    }

    [Fact]
    public void Wall_WithDoor_IsDesigned()
    {
        var w = new StructCalc.Core.Model.WallDef { LengthM = 5, HeightM = 3.06, ThicknessM = 0.2, EHorizKn = 150, WindKPa = 0.5 };
        w.Openings.Add(new StructCalc.Core.Model.WallOpening { XM = 2.0, ZM = 0, WidthM = 1.0, HeightM = 2.1 });
        var r = StructCalc.Engine.Walls.WallDesigner.Design(w, Rc(), 25, 500);
        Assert.True(r.Mesh.Elems.Count > 50);
        Assert.Single(r.OpeningResults);
        Assert.True(r.GeneralAsV >= r.MinAs);
        Assert.True(r.Mesh.Elems.All(e => !(e.Xc > 2.0 && e.Xc < 3.0 && e.Yc < 2.1)));     // aucun élément dans la porte
    }

    [Fact]
    public void Nielsen_PureShear_NeedsBothDirections()
    {
        var (tx, ty) = StructCalc.Engine.Walls.WallDesigner.Nielsen(0, 0, 100);
        Assert.Equal(100, tx, 6);
        Assert.Equal(100, ty, 6);
        var (cx, cy) = StructCalc.Engine.Walls.WallDesigner.Nielsen(-500, -500, 0);
        Assert.Equal(0, cx); Assert.Equal(0, cy);
    }
}
