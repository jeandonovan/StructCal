using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Bibliothèque de cas de validation du solveur (étape 1). Chaque cas compare StructCalc à une solution analytique
/// calculée à la main (résistance des matériaux) : valeur attendue, tolérance et message d'échec explicite.
/// Ce n'est PAS une comparaison à Robot / ETABS : ces comparaisons restent à faire sur des cas réels fournis par l'utilisateur.</summary>
public class ValidationLibrary
{
    private static StructModel Empty() => new StructModel { IncludeSelfWeight = false, Fc28 = 25 };

    /// <summary>Compare avec une tolérance relative (abs si attendu nul) et un message qui nomme le cas et la grandeur.</summary>
    private static void Check(string cas, string grandeur, double attendu, double obtenu, double tolRel = 1e-6, double tolAbs = 1e-6)
    {
        double tol = Math.Max(tolAbs, tolRel * Math.Abs(attendu));
        Assert.True(Math.Abs(obtenu - attendu) <= tol,
            $"[Validation {cas}] {grandeur} : attendu {attendu:0.#####}, obtenu {obtenu:0.#####} (tolérance {tol:0.#######}).");
    }

    private static StructModel Beam(double L, int segments, double b = 0.3, double h = 0.5)
    {
        var m = Empty();
        for (int i = 0; i <= segments; i++) m.Nodes.Add(new Node { Id = i + 1, X = L * i / segments, Y = 0, Z = 0 });
        for (int i = 0; i < segments; i++) m.Members.Add(new Member { Id = i + 1, NodeI = i + 1, NodeJ = i + 2, B = b, H = h });
        return m;
    }

    private static void PinRoller(StructModel m, int nodeA, int nodeB)
    {
        m.Supports.Add(new SupportDef { NodeId = nodeA, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = nodeB, Ux = false, Rx = false, Ry = false, Rz = false });
    }

    // ---------------------------------------------------------------- poutre isostatique, charge ponctuelle à mi-portée
    [Fact]
    public void Poutre_isostatique_charge_ponctuelle_milieu()
    {
        const string cas = "poutre isostatique P au milieu";
        double L = 6, P = 80, b = 0.3, h = 0.5;
        var m = Beam(L, 2, b, h);
        PinRoller(m, 1, 3);
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.Q, Fz = -P });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double EI = m.EcKNm2 * b * h * h * h / 12.0;
        Check(cas, "réaction appui gauche = P/2", P / 2, r.Reactions[1][2]);
        Check(cas, "réaction appui droit = P/2", P / 2, r.Reactions[3][2]);
        Check(cas, "flèche à mi-portée = P L³ / 48 EI", -P * L * L * L / (48 * EI), r.NodeDisp[2][2], 1e-6);
        Check(cas, "moment à mi-portée = P L / 4", P * L / 4, Math.Abs(r.Members[1][FrameSolver.Stations - 1].My), 1e-6);
        Check(cas, "effort tranchant = P/2", P / 2, Math.Abs(r.Members[1][0].Vz), 1e-6);
        Check(cas, "effort normal nul", 0, r.Members[1][0].N, tolAbs: 1e-6);
    }

    // ---------------------------------------------------------------- poutre isostatique, charge uniforme : flèche 5wL⁴/384EI
    [Fact]
    public void Poutre_isostatique_charge_uniforme_fleche()
    {
        const string cas = "poutre isostatique w uniforme";
        double L = 6, w = 20, b = 0.3, h = 0.5;
        var m = Beam(L, 2, b, h);                       // nœud central pour lire la flèche
        PinRoller(m, 1, 3);
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -w });
        m.MemberLoads.Add(new MemberLoad { MemberId = 2, Case = ActionType.Q, Wz = -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double EI = m.EcKNm2 * b * h * h * h / 12.0;
        Check(cas, "flèche à mi-portée = 5 w L⁴ / 384 EI", -5 * w * Math.Pow(L, 4) / (384 * EI), r.NodeDisp[2][2], 1e-6);
        Check(cas, "moment à mi-portée = w L² / 8", w * L * L / 8, Math.Abs(r.Members[1][FrameSolver.Stations - 1].My), 1e-5);
        Check(cas, "somme des réactions = w L", w * L, r.Reactions[1][2] + r.Reactions[3][2]);
    }

    // ---------------------------------------------------------------- poutre continue, deux travées : flèche au milieu d'une travée
    [Fact]
    public void Poutre_continue_deux_travees_equilibre_et_symetrie()
    {
        const string cas = "poutre continue 2 travées";
        double L = 5, w = 20;
        var m = Empty();
        for (int i = 0; i < 5; i++) m.Nodes.Add(new Node { Id = i + 1, X = i * L / 2, Y = 0, Z = 0 });
        for (int i = 0; i < 4; i++) m.Members.Add(new Member { Id = i + 1, NodeI = i + 1, NodeJ = i + 2, B = 0.3, H = 0.5 });
        m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 3, Ux = false, Rx = false, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 5, Ux = false, Rx = false, Ry = false, Rz = false });
        for (int i = 1; i <= 4; i++) m.MemberLoads.Add(new MemberLoad { MemberId = i, Case = ActionType.Q, Wz = -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        Check(cas, "somme des réactions = 2 w L", 2 * w * L, r.Reactions[1][2] + r.Reactions[3][2] + r.Reactions[5][2]);
        Check(cas, "réaction d'about = 3 w L / 8", 3 * w * L / 8, r.Reactions[1][2]);
        Check(cas, "réaction centrale = 5 w L / 4", 5 * w * L / 4, r.Reactions[3][2]);
        Check(cas, "symétrie des flèches à mi-travée", r.NodeDisp[2][2], r.NodeDisp[4][2], 1e-9);
        // moment max en travée = 9 w L² / 128, à x = 3L/8 de l'appui d'about
        double mMaxTravee = 0;
        foreach (var s in r.Members[1]) mMaxTravee = Math.Max(mMaxTravee, -s.My);
        foreach (var s in r.Members[2]) mMaxTravee = Math.Max(mMaxTravee, -s.My);
        Check(cas, "moment maximal en travée ≈ 9 w L² / 128", 9 * w * L * L / 128, mMaxTravee, 0.03);   // 3 % : lecture sur 21 stations par barre
    }

    // ---------------------------------------------------------------- console avec charge ponctuelle en bout (déjà couverte pour w) + tranchant
    [Fact]
    public void Console_charge_ponctuelle_en_bout()
    {
        const string cas = "console P en bout";
        double L = 2.5, P = 40, b = 0.25, h = 0.4;
        var m = Beam(L, 1, b, h);
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.Q, Fz = -P });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double EI = m.EcKNm2 * b * h * h * h / 12.0;
        Check(cas, "flèche en bout = P L³ / 3 EI", -P * L * L * L / (3 * EI), r.NodeDisp[2][2]);
        Check(cas, "moment d'encastrement = P L", P * L, Math.Abs(r.Reactions[1][4]));
        Check(cas, "tranchant constant = P", P, Math.Abs(r.Members[1][FrameSolver.Stations / 2].Vz));
        // rotation en bout = P L² / 2 EI (valeur absolue)
        Check(cas, "rotation en bout = P L² / 2 EI", P * L * L / (2 * EI), Math.Abs(r.NodeDisp[2][4]));
    }

    // ---------------------------------------------------------------- portique à un niveau, charge verticale symétrique
    [Fact]
    public void Portique_un_niveau_charge_verticale_symetrique()
    {
        const string cas = "portique 1 niveau, charge verticale";
        double h = 3.5, L = 6, w = 25;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = h });
        m.Nodes.Add(new Node { Id = 3, X = L, Y = 0, Z = h }); m.Nodes.Add(new Node { Id = 4, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, Type = MemberType.Beam, B = 0.3, H = 0.6 });
        m.Members.Add(new Member { Id = 3, NodeI = 4, NodeJ = 3, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Supports.Add(new SupportDef { NodeId = 1 }); m.Supports.Add(new SupportDef { NodeId = 4 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 2, Case = ActionType.Q, Wz = -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        Check(cas, "réaction verticale pied gauche = w L / 2", w * L / 2, r.Reactions[1][2]);
        Check(cas, "réaction verticale pied droit = w L / 2", w * L / 2, r.Reactions[4][2]);
        Check(cas, "poussée horizontale nulle en somme", 0, r.Reactions[1][0] + r.Reactions[4][0], tolAbs: 1e-6);
        Check(cas, "poussées symétriques et opposées", r.Reactions[1][0], -r.Reactions[4][0], 1e-9, 1e-9);
        Check(cas, "moments de pied symétriques", Math.Abs(r.Reactions[1][4]), Math.Abs(r.Reactions[4][4]), 1e-9, 1e-9);
        Check(cas, "déplacements horizontaux des têtes symétriques et opposés (la poussée écarte ou rapproche les têtes, sans balayage d'ensemble)", r.NodeDisp[2][0], -r.NodeDisp[3][0], 1e-6, 1e-9);
    }

    // ---------------------------------------------------------------- portique à deux niveaux, forces horizontales
    [Fact]
    public void Portique_deux_niveaux_forces_horizontales()
    {
        const string cas = "portique 2 niveaux, vent";
        double h = 3.2, L = 5, H1 = 30, H2 = 60;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = h }); m.Nodes.Add(new Node { Id = 4, X = L, Y = 0, Z = h });
        m.Nodes.Add(new Node { Id = 5, X = 0, Y = 0, Z = 2 * h }); m.Nodes.Add(new Node { Id = 6, X = L, Y = 0, Z = 2 * h });
        int id = 1;
        void Col(int a, int b) => m.Members.Add(new Member { Id = id++, NodeI = a, NodeJ = b, Type = MemberType.Column, B = 0.4, H = 0.4 });
        void Bm(int a, int b) => m.Members.Add(new Member { Id = id++, NodeI = a, NodeJ = b, Type = MemberType.Beam, B = 0.3, H = 0.5 });
        Col(1, 3); Col(2, 4); Col(3, 5); Col(4, 6); Bm(3, 4); Bm(5, 6);
        m.Supports.Add(new SupportDef { NodeId = 1 }); m.Supports.Add(new SupportDef { NodeId = 2 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 3, Case = ActionType.W, Fx = H1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 5, Case = ActionType.W, Fx = H2 });
        var r = FrameSolver.Solve(m, ActionType.W);
        Check(cas, "somme des réactions horizontales = -(H1 + H2)", -(H1 + H2), r.Reactions[1][0] + r.Reactions[2][0]);
        Check(cas, "somme des réactions verticales nulle", 0, r.Reactions[1][2] + r.Reactions[2][2], tolAbs: 1e-6);
        Assert.True(r.NodeDisp[5][0] > r.NodeDisp[3][0] && r.NodeDisp[3][0] > 0,
            $"[Validation {cas}] les déplacements latéraux doivent croître avec la hauteur (étage 1 : {r.NodeDisp[3][0]:0.#####}, étage 2 : {r.NodeDisp[5][0]:0.#####}).");
        Assert.True(Math.Abs(r.NodeDisp[3][0] - r.NodeDisp[4][0]) < 0.02 * Math.Abs(r.NodeDisp[3][0]),
            $"[Validation {cas}] traverse supposée quasi indéformable axialement : les deux nœuds d'un même étage doivent se déplacer de la même valeur.");
    }

    /// <summary>Équilibre global exact des moments autour du pied gauche (nœud 1) pour le portique à deux niveaux.
    /// Les moments de pied (My) sont lus dans la convention du solveur : on teste l'équilibre en valeur, sans préjuger du signe.</summary>
    [Fact]
    public void Portique_deux_niveaux_equilibre_des_moments()
    {
        const string cas = "portique 2 niveaux, équilibre moments";
        double h = 3.2, L = 5, H1 = 30, H2 = 60;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = h }); m.Nodes.Add(new Node { Id = 4, X = L, Y = 0, Z = h });
        m.Nodes.Add(new Node { Id = 5, X = 0, Y = 0, Z = 2 * h }); m.Nodes.Add(new Node { Id = 6, X = L, Y = 0, Z = 2 * h });
        int id = 1;
        void Col(int a, int b) => m.Members.Add(new Member { Id = id++, NodeI = a, NodeJ = b, Type = MemberType.Column, B = 0.4, H = 0.4 });
        void Bm(int a, int b) => m.Members.Add(new Member { Id = id++, NodeI = a, NodeJ = b, Type = MemberType.Beam, B = 0.3, H = 0.5 });
        Col(1, 3); Col(2, 4); Col(3, 5); Col(4, 6); Bm(3, 4); Bm(5, 6);
        m.Supports.Add(new SupportDef { NodeId = 1 }); m.Supports.Add(new SupportDef { NodeId = 2 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 3, Case = ActionType.W, Fx = H1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 5, Case = ActionType.W, Fx = H2 });
        var r = FrameSolver.Solve(m, ActionType.W);
        double renversement = H1 * h + H2 * 2 * h;                                    // moment des forces autour du pied gauche
        double resistant1 = Math.Abs(r.Reactions[1][4] + r.Reactions[2][4]);           // moments d'encastrement
        double resistant2 = Math.Abs(r.Reactions[2][2]) * L;                           // couple des réactions verticales
        // selon le signe de My, les deux contributions s'ajoutent ou se retranchent : on accepte l'une des deux combinaisons exactes
        bool ok = Math.Abs(resistant1 + resistant2 - renversement) < 1e-4 * renversement
               || Math.Abs(Math.Abs(resistant2 - resistant1) - renversement) < 1e-4 * renversement;
        Assert.True(ok, $"[Validation {cas}] équilibre des moments : renversement {renversement:0.###}, encastrements {resistant1:0.###}, couple vertical {resistant2:0.###}.");
    }

    // ---------------------------------------------------------------- poteau centré / excentré
    [Fact]
    public void Poteau_centre_effort_normal()
    {
        const string cas = "poteau centré";
        double h = 3.2, N = 900;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = h });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.G, Fz = -N });
        var r = FrameSolver.Solve(m, ActionType.G);
        double EA = m.EcKNm2 * 0.4 * 0.4;
        Check(cas, "réaction = N", N, r.Reactions[1][2]);
        Check(cas, "effort normal = -N (compression)", -N, r.Members[1][FrameSolver.Stations / 2].N);
        Check(cas, "raccourcissement = N h / EA", -N * h / EA, r.NodeDisp[2][2]);
        Check(cas, "moment nul", 0, Math.Max(Math.Abs(r.Members[1][0].My), Math.Abs(r.Members[1][0].Mz)), tolAbs: 1e-6);
    }

    [Fact]
    public void Poteau_excentre_moment_egal_N_fois_e()
    {
        const string cas = "poteau excentré";
        double h = 3.2, N = 900, e = 0.10;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = h });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.G, Fz = -N, My = N * e });     // N appliqué à l'excentricité e
        var r = FrameSolver.Solve(m, ActionType.G);
        Check(cas, "réaction verticale = N", N, r.Reactions[1][2]);
        Check(cas, "moment d'encastrement = N e", N * e, Math.Abs(r.Reactions[1][4]));
        var mid = r.Members[1][FrameSolver.Stations / 2];
        Check(cas, "moment constant sur la hauteur du poteau", N * e, Math.Max(Math.Abs(mid.My), Math.Abs(mid.Mz)));
        // théorie du 1er ordre : le logiciel ne fait pas d'analyse P-Δ ici, cet écart est donc à couvrir par la vérification de stabilité du poteau
    }

    // ---------------------------------------------------------------- équilibre général : poids propre
    [Fact]
    public void Poids_propre_poutre_equilibre()
    {
        const string cas = "poids propre";
        double L = 5, b = 0.3, h = 0.5;
        var m = Beam(L, 1, b, h); m.IncludeSelfWeight = true;
        PinRoller(m, 1, 2);
        var r = FrameSolver.Solve(m, ActionType.G);
        Check(cas, "somme des réactions = poids propre b h L γ", b * h * L * FrameSolver.ConcreteUnitWeight, r.Reactions[1][2] + r.Reactions[2][2], 1e-6);
    }
}
