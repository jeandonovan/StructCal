using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Types de dalles (préréglages) et semelles 3D (volume, facettes, repérage du nœud).</summary>
public class SlabTypeFootingTests
{
    [Fact]
    public void CorpsCreux_PresetGivesThicknessAndLighterWeight()
    {
        var s = new SlabPanel { Kind = SlabKind.CorpsCreux, HourdisCm = 16, ToppingCm = 4 };
        SlabPresets.Apply(s);
        Assert.Equal(0.20, s.H, 3);
        Assert.InRange(s.H * s.Gamma, 2.5, 3.2);          // ~2,85 kN/m² (tableau 16+4)
        Assert.True(s.VolumeFactor < 1);
    }

    [Fact]
    public void Pleine_KeepsGammaAndFullVolume()
    {
        var s = new SlabPanel { Kind = SlabKind.Pleine, H = 0.16, Gamma = 25 };
        SlabPresets.Apply(s);
        Assert.Equal(1.0, s.VolumeFactor, 6);
        Assert.Equal(4.0, s.H * s.Gamma, 6);
        Assert.True(SlabPresets.DesignedAsSolid(SlabKind.Pleine));
        Assert.False(SlabPresets.DesignedAsSolid(SlabKind.CorpsCreux));
    }

    [Fact]
    public void FootingVolume_BlockAndGlacis()
    {
        Assert.Equal(2.0 * 1.5 * 0.5, FootingSolids.Volume(2.0, 1.5, 0.5, 0.3, 0.3, false, 20), 6);
        double g = FootingSolids.Volume(2.0, 1.5, 0.5, 0.3, 0.3, true, 20);
        Assert.InRange(g, 0.2 * 3.0, 2.0 * 1.5 * 0.5);     // plus petit que le bloc, plus grand que le seul bord
    }

    [Fact]
    public void FootingFaces_BlockHasSix_GlacisHasTen()
    {
        Assert.Equal(6, FootingSolids.Build(0, 0, 0, 2, 1.5, 0.5, 0.3, 0.3, false, 20).Count);
        Assert.Equal(10, FootingSolids.Build(0, 0, 0, 2, 1.5, 0.5, 0.3, 0.3, true, 20).Count);
    }

    [Fact]
    public void FootingNodeId_ParsedFromElementName()
    {
        Assert.Equal(5, FootingPlacement.NodeIdOf("Semelle sous nœud 5 (2.0 x 1.5)"));
        Assert.Equal(-1, FootingPlacement.NodeIdOf("Poutre 3"));
    }

    [Fact]
    public void Footing_Eccentric_KeepsColumnOnPlateauAndStaysInside()
    {
        var (ox, oy) = FootingSolids.Shift(2.0, 1.5, 0.3, 0.3, true, 1, 0);
        Assert.True(ox < 0 && Math.Abs(oy) < 1e-9);            // poteau côté +X : la semelle s'étend vers -X
        Assert.Equal(0, FootingSolids.Shift(2.0, 1.5, 0.3, 0.3, true, 0, 0).Ox, 9);
        var faces = FootingSolids.Build(10, 5, 0, 2.0, 1.5, 0.5, 0.3, 0.3, true, 20, 1, 1);
        Assert.Equal(10, faces.Count);
        double minX = faces.SelectMany(f => f.P).Min(v => v.X), maxX = faces.SelectMany(f => f.P).Max(v => v.X);
        Assert.Equal(2.0, maxX - minX, 6);
        Assert.InRange(10.0, minX, maxX);                       // l'axe du poteau reste dans l'emprise
        Assert.Equal(10.0 + 0.15 + 0.15, maxX, 6);              // plateau = poteau + 15 cm de chaque côté : bord +X à 30 cm de l'axe du poteau
    }
}
