using StructCalc.Core;
using StructCalc.Core.Codes;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Codes.EC2;
using StructCalc.Core.Codes.EC8;
using StructCalc.Core.Codes.RPA99;
using Xunit;

/// <summary>Étape 6 : architecture des normes. Garde-fous (fiches, filiation, contrat commun) et valeurs de référence propres à chaque norme.</summary>
public class NormArchitectureTests
{
    private static void Near(string cas, double expected, double actual, double tol)
        => Assert.True(Math.Abs(expected - actual) <= tol, $"[Norme {cas}] attendu {expected:0.####}, obtenu {actual:0.####} (tolérance {tol}).");

    private static readonly RcRectSection Sec = new(0.25, 0.50, 0.05, 0.05);          // d = 0,45 m

    public static IEnumerable<object[]> RcIds => new[] { "BAEL91", "CBA93", "EC2", "RPA99", "EC8" }.Select(x => new object[] { x });

    // ------------------------------------------------------------------ garde-fous d'architecture
    [Fact]
    public void Chaque_norme_implementee_a_une_fiche()
    {
        foreach (var c in DesignCodeRegistry.All.Where(x => x.IsImplemented))
            Assert.True(CodeProfiles.Of(c.Id) != null, $"[Architecture] la norme {c.Id} n'a pas de fiche dans CodeProfiles (périmètre et limites non déclarés).");
    }

    [Fact]
    public void La_filiation_declaree_est_la_filiation_reelle()
    {
        foreach (var p in CodeProfiles.All)
        {
            var code = DesignCodeRegistry.All.FirstOrDefault(x => x.Id == p.Id);
            if (code == null) continue;
            var parent = DesignCodeRegistry.All.FirstOrDefault(x => x.GetType() == code.GetType().BaseType);
            string real = parent?.Id ?? "";
            Assert.True(real == p.BasedOn, $"[Architecture] {p.Id} : la fiche déclare « {p.BasedOn} » mais la classe hérite de « {real} ». Mettre la fiche à jour.");
        }
    }

    [Fact]
    public void La_filiation_n_a_pas_de_cycle_et_pointe_vers_une_norme_existante()
    {
        foreach (var p in CodeProfiles.All)
        {
            var seen = new HashSet<string>(); var cur = p;
            while (cur != null && cur.BasedOn != "")
            {
                Assert.True(seen.Add(cur.Id), $"[Architecture] cycle de filiation autour de {cur.Id}.");
                cur = CodeProfiles.Of(cur.BasedOn);
                Assert.True(cur != null, $"[Architecture] {p.Id} s'appuie sur une norme sans fiche.");
            }
        }
    }

    [Fact]
    public void Chaque_classe_de_norme_est_dans_le_dossier_de_sa_norme()
    {
        foreach (var c in DesignCodeRegistry.All.Where(x => x.IsImplemented))
        {
            string ns = c.GetType().Namespace ?? "";
            Assert.True(ns.StartsWith("StructCalc.Core.Codes."), $"[Architecture] {c.Id} : la classe {c.GetType().Name} doit être sous StructCalc.Core.Codes.<Norme> (obtenu {ns}).");
        }
    }

    [Fact]
    public void Un_ajout_de_norme_prevue_est_visible_mais_non_implemente()
    {
        DesignCodeRegistry.Register(new StructCalc.Core.Codes.Planned.PlannedCode("ZZ_TEST", "Norme de test (prévue)", MaterialKind.ReinforcedConcrete));
        var c = DesignCodeRegistry.Get("ZZ_TEST");
        Assert.False(c.IsImplemented);
        Assert.Empty(c.Combinations);
    }

    // ------------------------------------------------------------------ contrat commun à toutes les normes béton armé
    [Theory, MemberData(nameof(RcIds))]
    public void Contrat_commun_combinaisons(string id)
    {
        var c = (IReinforcedConcreteCode)DesignCodeRegistry.Get(id);
        Assert.True(c.IsImplemented);
        Assert.Equal(MaterialKind.ReinforcedConcrete, c.Material);
        Assert.Contains(c.Combinations, x => x.State == LimitState.ELU);
        Assert.Contains(c.Combinations, x => x.State == LimitState.ELS);
        Assert.Equal(c.Combinations.Count, c.Combinations.Select(x => x.Name).Distinct().Count());
    }

    [Theory, MemberData(nameof(RcIds))]
    public void Contrat_commun_flexion_croit_avec_le_moment(string id)
    {
        var c = (IReinforcedConcreteCode)DesignCodeRegistry.Get(id);
        double a50 = c.DesignBeamFlexure(Sec, 25, 500, 50, 35, CrackingClass.PeuPrejudiciable).Values["As_cm2"];
        double a100 = c.DesignBeamFlexure(Sec, 25, 500, 100, 70, CrackingClass.PeuPrejudiciable).Values["As_cm2"];
        double a150 = c.DesignBeamFlexure(Sec, 25, 500, 150, 105, CrackingClass.PeuPrejudiciable).Values["As_cm2"];
        Assert.True(a50 > 0, $"[{id}] section minimale non nulle attendue même à faible moment.");
        Assert.True(a50 <= a100 + 1e-9 && a100 <= a150 + 1e-9, $"[{id}] As doit croître avec le moment : {a50:0.00} ; {a100:0.00} ; {a150:0.00} cm².");
    }

    [Theory, MemberData(nameof(RcIds))]
    public void Contrat_commun_tranchant_croit_avec_l_effort(string id)
    {
        var c = (IReinforcedConcreteCode)DesignCodeRegistry.Get(id);
        double a = c.DesignBeamShear(Sec, 25, 500, 60, CrackingClass.PeuPrejudiciable).Values["At_over_st_cm2_per_m"];
        double b = c.DesignBeamShear(Sec, 25, 500, 180, CrackingClass.PeuPrejudiciable).Values["At_over_st_cm2_per_m"];
        Assert.True(a > 0 && b >= a - 1e-9, $"[{id}] armatures d'effort tranchant : {a:0.00} puis {b:0.00} cm²/m.");
    }

    [Theory, MemberData(nameof(RcIds))]
    public void Contrat_commun_poteau_respecte_le_minimum_de_sa_norme(string id)
    {
        var c = (IReinforcedConcreteCode)DesignCodeRegistry.Get(id);
        var r = c.DesignColumn(new ColumnInput(0.40, 0.40, 2.5, 25, 500, 600, 20, 0, 0.04));
        Assert.True(r.Values["As_cm2"] >= r.Values["As_min_cm2"] - 1e-9, $"[{id}] As retenue sous le minimum de la norme.");
        Assert.True(r.Values["As_min_cm2"] > 0);
    }

    // ------------------------------------------------------------------ BAEL 91 : valeurs faites à la main
    [Fact]
    public void Bael91_section_minimale_et_fcd()
    {
        // fbu = 0,85 x 25 / 1,5 = 14,17 MPa ; ft28 = 0,6 + 0,06 x 25 = 2,1 ; Amin = 0,23 b d ft28 / fe = 0,23 x 0,25 x 0,45 x 2,1 / 500 = 1,087 cm²
        Near("BAEL fbu", 14.1667, Bael91Materials.Fbu(25, LimitState.ELU), 1e-3);
        var r = new Bael91Code().DesignBeamFlexure(Sec, 25, 500, 1, 0.7, CrackingClass.PeuPrejudiciable);
        Near("BAEL As,min", 1.087, r.Values["As_min_cm2"], 0.005);
    }

    // ------------------------------------------------------------------ EC2 : valeurs faites à la main
    [Fact]
    public void Ec2_flexion_100_kNm()
    {
        // fcd = 25/1,5 = 16,667 ; mu = 0,1 / (0,25 x 0,45² x 16,667) = 0,1185 ; xi = 1,25 (1 - sqrt(1 - 2 mu)) = 0,1581 ; z = 0,45 (1 - 0,4 xi) = 0,4215 ; As = 0,1 / (0,4215 x 434,78) = 5,456 cm²
        var r = new Ec2Code().DesignBeamFlexure(Sec, 25, 500, 100, 70, CrackingClass.PeuPrejudiciable);
        Near("EC2 mu", 0.1185, r.Values["mu"], 5e-4);
        Near("EC2 As", 5.456, r.Values["As_ELU_cm2"], 0.02);
    }

    [Fact]
    public void Ec2_section_minimale_9_2_1_1()
    {
        // fctm = 0,30 x 25^(2/3) = 2,565 MPa ; 0,26 fctm / fyk = 1,334e-3 > 0,0013 ; Amin = 1,334e-3 x 0,25 x 0,45 = 1,50 cm²
        var r = new Ec2Code().DesignBeamFlexure(Sec, 25, 500, 1, 0.7, CrackingClass.PeuPrejudiciable);
        Near("EC2 As,min", 1.50, r.Values["As_min_cm2"], 0.01);
    }

    [Fact]
    public void Ec2_tranchant_120_kN()
    {
        // z = 0,405 ; nu1 = 0,6 (1 - 25/250) = 0,54 ; V/(b z nu1 fcd) = 0,1317 <= 0,345 => cot(theta) = 2,5 ; Asw/s = V / (z fywd cot) = 0,12 / (0,405 x 434,78 x 2,5) = 2,726 cm²/m
        var r = new Ec2Code().DesignBeamShear(Sec, 25, 500, 120, CrackingClass.PeuPrejudiciable);
        Near("EC2 Asw/s", 2.726, r.Values["At_over_st_cm2_per_m"], 0.01);
        Near("EC2 st,max", 33.75, r.Values["st_max_cm"], 0.01);                   // 0,75 d
    }

    [Fact]
    public void Ec2_et_Bael_donnent_des_resultats_differents_en_tranchant()
        => Assert.NotEqual(
            Math.Round(new Bael91Code().DesignBeamShear(Sec, 25, 500, 120, CrackingClass.PeuPrejudiciable).Values["At_over_st_cm2_per_m"], 2),
            Math.Round(new Ec2Code().DesignBeamShear(Sec, 25, 500, 120, CrackingClass.PeuPrejudiciable).Values["At_over_st_cm2_per_m"], 2));

    // ------------------------------------------------------------------ RPA 99 / EC8 : dispositions parasismiques
    [Fact]
    public void Rpa99_poutre_pourcentage_total_et_zone_nodale()
    {
        var rpa = new Rpa99Code();
        Near("RPA 0,5 %", 6.25, rpa.BeamMinTotalAsCm2(Sec), 1e-9);                          // 0,005 x 25 x 50
        Near("RPA zone nodale poutre", 12.5, rpa.NodalStirrupSpacingCm(false, 50, 16), 1e-9); // min(h/4 ; 12 phi) = min(12,5 ; 19,2)
        Near("RPA zone nodale poteau", 10, rpa.NodalStirrupSpacingCm(true, 40, 16), 1e-9);    // min(10 ; 15 phi)
    }

    [Fact]
    public void Ec8_zone_critique()
    {
        var ec8 = new Ec8Code();
        Near("EC8 poutre", 12.5, ec8.NodalStirrupSpacingCm(false, 50, 16), 1e-9);            // min(h/4 ; 225 mm ; 8 phi) = min(12,5 ; 22,5 ; 12,8)
        Near("EC8 poteau", 9.6, ec8.NodalStirrupSpacingCm(true, 40, 16), 1e-9);              // min(125 mm ; 6 phi) = 96 mm
    }

    [Fact]
    public void Norme_non_parasismique_n_impose_pas_de_zone_critique()
    {
        Assert.Equal(0, new Bael91Code().NodalStirrupSpacingCm(false, 50, 16));
        Assert.Equal(0, new Ec2Code().NodalStirrupSpacingCm(true, 40, 16));
    }
}
