using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Choix du maillage éléments finis et du mode de vérification de flèche.</summary>
public class MeshAndDeflectionTests
{
    [Fact]
    public void SlabCounts_FollowThePreset()
    {
        var s = new DesignSettings();
        Assert.Equal((24, 16), MeshPresets.SlabCounts(s, 6, 4));              // Courant 0,25 m
        s.MeshPreset = "Grossier";
        Assert.Equal((12, 8), MeshPresets.SlabCounts(s, 6, 4));
        s.MeshPreset = "Fin";
        Assert.Equal((40, 27), MeshPresets.SlabCounts(s, 8, 4));              // plafonné à 40
    }

    [Fact]
    public void SlabCounts_Manual_CountsOrSize()
    {
        var s = new DesignSettings { MeshPreset = "Manuel", MeshManualNx = 10, MeshManualNy = 8 };
        Assert.Equal((10, 8), MeshPresets.SlabCounts(s, 6, 4));
        s.MeshManualNx = 0; s.MeshManualNy = 0; s.MeshManualM = 0.5;
        Assert.Equal((12, 8), MeshPresets.SlabCounts(s, 6, 4));
    }

    [Fact]
    public void WallSize_GlobalOrOwnSetting()
    {
        var s = new DesignSettings { MeshPreset = "Courant" };
        var w = new WallDef { LengthM = 5, HeightM = 3, MeshM = 0.18 };
        Assert.Equal(0.25, MeshPresets.WallSize(w, s), 6);                    // Global -> Courant
        w.MeshMode = "Fin";
        Assert.Equal(0.15, MeshPresets.WallSize(w, s), 6);
        w.MeshMode = "Manuel";
        Assert.Equal(0.18, MeshPresets.WallSize(w, s), 6);
    }

    [Fact]
    public void DeflectionMode_AutoDependsOnTheCode()
    {
        var cfg = new DesignSettings();
        Assert.Equal("CalcBael", AdvancedChecks.DeflMode(cfg, false, true));
        Assert.Equal("CalcEc2", AdvancedChecks.DeflMode(cfg, true, true));
        cfg.DeflectionMethod = "ForfPuisCalc";
        Assert.Equal("Forfaitaire", AdvancedChecks.DeflMode(cfg, false, true));
        Assert.Equal("CalcBael", AdvancedChecks.DeflMode(cfg, false, false));
    }

    [Fact]
    public void DeflectionLimit_Modes()
    {
        var cfg = new DesignSettings();
        Assert.Equal(4.0 / 500, AdvancedChecks.DeflLimit(4, cfg, false), 9);
        Assert.Equal(0.005 + 8.0 / 1000, AdvancedChecks.DeflLimit(8, cfg, false), 9);
        Assert.Equal(4.0 / 250, AdvancedChecks.DeflLimit(4, cfg, true), 9);
        cfg.DeflectionLimitMode = "Manuel"; cfg.DeflectionManualDenominator = 300;
        Assert.Equal(6.0 / 300, AdvancedChecks.DeflLimit(6, cfg, false), 9);
    }
}
