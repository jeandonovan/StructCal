using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Niveaux : ajout, renommage, génération d'étages, copie du contenu d'un niveau vers un autre.</summary>
public class LevelOpsTests
{
    private static StructModel Frame()
    {
        var m = new StructModel();
        // 2 poteaux (0 -> 3 m) et 1 poutre au niveau 3 m
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 5, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 4, X = 5, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 3, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 4, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 3, NodeI = 3, NodeJ = 4, Type = MemberType.Beam });
        return m;
    }

    [Fact]
    public void AddLevel_RenameAndCopy_BeamsAndColumns()
    {
        var m = Frame();
        var info = StructureAnalyzer.Analyze(m);
        Assert.Equal(2, info.Levels.Count);
        Assert.True(LevelOps.AddLevel(m, info, "R+1", 6.0, out _));
        Assert.True(LevelOps.Rename(m, StructureAnalyzer.Analyze(m), 1, "RDC", out _));
        info = StructureAnalyzer.Analyze(m);
        Assert.Equal(3, info.Levels.Count);
        Assert.Equal("RDC", info.Levels[1].Name);
        var rep = LevelOps.Copy(m, info, 1, 2, true, true, true);
        Assert.Equal(2, rep.Columns);
        Assert.Equal(1, rep.Beams);
        var after = StructureAnalyzer.Analyze(m);
        Assert.Equal(2, after.Levels[2].ColumnIds.Count);      // poteaux entre 3 m et 6 m
        Assert.Single(after.Levels[2].BeamIds);
        var again = LevelOps.Copy(m, after, 1, 2, true, true, true);   // pas de doublons
        Assert.Equal(0, again.Columns + again.Beams);
    }

    [Fact]
    public void BuildFloors_NamesAndElevations()
    {
        var m = new StructModel();
        LevelOps.BuildFloors(m, 3, 3.06);
        Assert.Equal(new[] { "Base", "RDC", "R+1", "R+2" }, m.Levels.Select(l => l.Name).ToArray());
        Assert.Equal(9.18, m.Levels[3].Elevation, 3);
    }

    [Fact]
    public void Member_Roll_SwapsSectionAxes()
    {
        var a = new Node { Id = 1, X = 0, Y = 0, Z = 0 }; var b = new Node { Id = 2, X = 0, Y = 0, Z = 3 };
        var (_, R0) = StructCalc.Engine.FrameSolver.LocalAxes(a, b, 0);
        var (_, R90) = StructCalc.Engine.FrameSolver.LocalAxes(a, b, 90);
        // après 90° : l'axe local y devient l'ancien z (et z devient -y)
        for (int k = 0; k < 3; k++) { Assert.Equal(R0[2, k], R90[1, k], 9); Assert.Equal(-R0[1, k], R90[2, k], 9); }
    }
}

/// <summary>Hauteurs d'étage : tout ce qui est au-dessus suit (nœuds, niveaux, dalles, charges) ; volume et mode de calcul des dalles.</summary>
public class StoreyOpsTests
{
    private static StructModel TwoStoreys()
    {
        var m = new StructModel();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 5, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 4, X = 5, Y = 0, Z = 3 });
        m.Nodes.Add(new Node { Id = 5, X = 0, Y = 0, Z = 6 }); m.Nodes.Add(new Node { Id = 6, X = 5, Y = 0, Z = 6 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 3, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 4, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 3, NodeI = 3, NodeJ = 4, Type = MemberType.Beam });
        m.Members.Add(new Member { Id = 4, NodeI = 3, NodeJ = 5, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 5, NodeI = 4, NodeJ = 6, Type = MemberType.Column });
        m.Members.Add(new Member { Id = 6, NodeI = 5, NodeJ = 6, Type = MemberType.Beam });
        m.Slabs.Add(new SlabPanel { Name = "D1", Lx = 5, Ly = 4, H = 0.20, Placed = true, X0 = 0, Y0 = 0, Z = 3, GExtra = 1.5, Q = 2.5 });
        m.Slabs.Add(new SlabPanel { Name = "D2", Lx = 5, Ly = 4, H = 0.20, Placed = true, X0 = 0, Y0 = 0, Z = 6, GExtra = 1.5, Q = 2.5 });
        StoreyOps.SyncAllSlabLoads(m);
        return m;
    }

    [Fact]
    public void SlabVolumeAndWeight()
    {
        var s = new SlabPanel { Lx = 10, Ly = 10, H = 0.20 };
        Assert.Equal(20.0, s.Volume, 6);
        Assert.Equal(5.0, s.SelfWeightKnM2, 6);
        Assert.Equal(500.0, s.TotalWeightKn, 6);
    }

    [Fact]
    public void SetHeight_ShiftsEverythingAbove()
    {
        var m = TwoStoreys();
        var info = StructureAnalyzer.Analyze(m);
        Assert.Equal(3, info.Levels.Count);
        Assert.True(StoreyOps.SetHeight(m, info, 1, 3.5, out _));           // étage 3 m -> 3,5 m entre les niveaux 3 et 6
        Assert.Equal(6.5, m.Nodes.First(n => n.Id == 5).Z, 6);
        Assert.Equal(3.0, m.Nodes.First(n => n.Id == 3).Z, 6);               // en dessous : inchangé
        Assert.Equal(6.5, m.Slabs.First(s => s.Name == "D2").Z, 6);
        Assert.Equal(3.0, m.Slabs.First(s => s.Name == "D1").Z, 6);
        Assert.Equal(6.5, m.SurfaceLoads.First(l => l.Name == "D2-G").Z, 6); // les charges de la dalle suivent
        var after = StructureAnalyzer.Analyze(m);
        Assert.Equal(3.5, after.Levels[1].HeightToNext, 3);
    }

    [Fact]
    public void SetHeight_LowerStorey_ShiftsAllLevelsAbove()
    {
        var m = TwoStoreys();
        var info = StructureAnalyzer.Analyze(m);
        Assert.True(StoreyOps.SetHeight(m, info, 0, 4.0, out _));           // RDC 3 m -> 4 m : tout le reste monte de 1 m
        Assert.Equal(4.0, m.Nodes.First(n => n.Id == 3).Z, 6);
        Assert.Equal(7.0, m.Nodes.First(n => n.Id == 5).Z, 6);
        Assert.Equal(4.0, m.Slabs.First(s => s.Name == "D1").Z, 6);
        Assert.Equal(7.0, m.Slabs.First(s => s.Name == "D2").Z, 6);
    }

    [Fact]
    public void SetHeight_Invalid_Refused()
    {
        var m = TwoStoreys();
        var info = StructureAnalyzer.Analyze(m);
        Assert.False(StoreyOps.SetHeight(m, info, 2, 3.0, out _));          // pas d'étage au-dessus du dernier niveau
        Assert.False(StoreyOps.SetHeight(m, info, 0, 0.0, out _));
    }

    [Fact]
    public void CalcMode_ControlsLoads()
    {
        var m = TwoStoreys();
        var s = m.Slabs[0];
        s.CalcMode = SlabCalcMode.OneWayX; s.Gamma = 24;
        StoreyOps.SyncSlabLoads(m, s);
        var g = m.SurfaceLoads.First(l => l.Name == "D1-G");
        Assert.Equal(SurfaceDistribution.OneWayX, g.Distribution);
        Assert.Equal(24 * 0.20 + 1.5, g.Q, 6);
        s.CalcMode = SlabCalcMode.MassOnly;
        StoreyOps.SyncSlabLoads(m, s);
        Assert.DoesNotContain(m.SurfaceLoads, l => l.Name == "D1-G" || l.Name == "D1-Q");   // métré seul : aucune charge
    }
}
