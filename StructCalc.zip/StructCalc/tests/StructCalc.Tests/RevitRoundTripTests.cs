using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Aller-retour Revit, partie testable sans Revit (étape 2) : export Revit simulé (fichier modèle avec identifiants) -> import -> calcul -> résumé renvoyé à Revit
/// -> mise à jour sans doublon -> détection des modifications. La création des armatures 3D et des plans dans Revit se vérifie dans Revit même
/// (revit_compiler_installer.bat), pas ici.</summary>
public class RevitRoundTripTests
{
    // ------------------------------------------------------------------ modèles « exportés de Revit » (ExternalId renseigné)
    private static StructModel RevitBeam()
    {
        var m = new StructModel { Name = "Revit poutre", IncludeSelfWeight = true };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 5, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.25, H = 0.50, ExternalId = "1001", Cover = 0.041, CoverNomCm = 2.5 });
        m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 2, Ux = false, Rx = false, Ry = false, Rz = false });
        return m;
    }

    private static StructModel RevitColumn()
    {
        var m = new StructModel { Name = "Revit poteau", IncludeSelfWeight = true };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3.2 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.30, H = 0.30, ExternalId = "2001", Cover = 0.041, CoverNomCm = 2.5 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        return m;
    }

    private static StructModel RevitPortal()
    {
        var m = ExampleModels.Portal();
        m.Slabs.Clear();
        foreach (var mm in m.Members) mm.ExternalId = (3000 + mm.Id).ToString();
        return m;
    }

    private static StructModel RevitStair()
    {
        var m = RevitPortal();
        m.Stairs.Add(new StairDef { Name = "E1", ExternalId = "4001", Layout = StairLayout.DroitPalier, HeightM = 3.0, WidthM = 1.2, Placed = true });
        return m;
    }

    private static void AddLoads(StructModel m)
    {
        if (m.MemberLoads.Count > 0 || m.NodalLoads.Count > 0) return;
        foreach (var b in m.Members.Where(x => x.Type == MemberType.Beam))
        { m.MemberLoads.Add(new MemberLoad { MemberId = b.Id, Case = ActionType.G, Wz = -15 }); m.MemberLoads.Add(new MemberLoad { MemberId = b.Id, Case = ActionType.Q, Wz = -6 }); }
        foreach (var n in m.Members.Where(x => x.Type == MemberType.Column && m.Members.All(o => o.Id == x.Id || (o.NodeI != x.NodeJ && o.NodeJ != x.NodeJ))))
        { m.NodalLoads.Add(new NodalLoad { NodeId = n.NodeJ, Case = ActionType.G, Fz = -300 }); m.NodalLoads.Add(new NodalLoad { NodeId = n.NodeJ, Case = ActionType.Q, Fz = -100 }); }
    }

    /// <summary>Passe tout le trajet : fichier d'échange, relecture, calcul, résumé pour Revit, relecture du résumé.</summary>
    private static (StructModel imported, AnalysisOutput output, List<RevitSummaryItem> summary) Trip(StructModel revit)
    {
        string dir = Path.Combine(Path.GetTempPath(), "sc_rt_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
        try
        {
            string f = Path.Combine(dir, "from_revit.json");
            ModelIO.Save(revit, f);                                  // ce que fait « Envoyer vers StructCalc »
            var imported = ModelIO.Load(f);
            AddLoads(imported);                                      // l'utilisateur ajoute ses charges dans StructCalc
            var o = ProjectAnalyzer.Run(imported, optimize: true);
            string s = Path.Combine(dir, "to_revit.json");
            ModelIO.SaveRevitSummary(o, s, imported);                // ce que fait « Envoyer les résultats à Revit »
            return (imported, o, ModelIO.LoadRevitSummary(s));
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    // ------------------------------------------------------------------ 1. poutre
    [Fact]
    public void Poutre_import_calcul_export_armatures()
    {
        var (m, o, sum) = Trip(RevitBeam());
        var it = Assert.Single(sum);
        Assert.True(it.ExternalId == "1001", "[Revit poutre] l'identifiant Revit doit revenir tel quel pour retrouver l'élément.");
        Assert.True(Math.Abs(it.B - 0.25) < 1e-9 && Math.Abs(it.H - 0.50) < 1e-9, $"[Revit poutre] section importée 25x50 cm, obtenu {it.B * 100:0.#}x{it.H * 100:0.#}.");
        Assert.True(Math.Abs(it.Length - 5.0) < 1e-6, $"[Revit poutre] longueur 5,00 m, obtenu {it.Length:0.###}.");
        Assert.True(it.BotN > 0 && it.BotDia >= 8, "[Revit poutre] armatures inférieures attendues dans le résumé renvoyé à Revit.");
        Assert.True(it.StirDia > 0 && it.StirSpacingCm > 0, "[Revit poutre] cadres attendus dans le résumé.");
        Assert.True(it.Cover >= 0.02 && it.Cover < 0.08, $"[Revit poutre] enrobage net plausible (2 à 8 cm), obtenu {it.Cover * 100:0.#} cm.");
        Assert.Equal("Beam", it.Type);
        Assert.Equal(2, m.Supports.Count);                           // appuis importés
        Assert.True(o.Members.Count == 1 && !o.Members[0].Skipped, "[Revit poutre] la barre doit être calculée.");
    }

    // ------------------------------------------------------------------ 2. poteau
    [Fact]
    public void Poteau_import_calcul_export_armatures()
    {
        var (_, _, sum) = Trip(RevitColumn());
        var it = Assert.Single(sum);
        Assert.Equal("2001", it.ExternalId);
        Assert.Equal("Column", it.Type);
        Assert.True(Math.Abs(it.Length - 3.2) < 1e-6, $"[Revit poteau] longueur 3,20 m, obtenu {it.Length:0.###}.");
        Assert.True(it.BotN + it.TopN > 0 && Math.Max(it.BotDia, it.TopDia) >= 8, "[Revit poteau] barres longitudinales attendues dans le résumé.");
        Assert.True(it.StirDia > 0, "[Revit poteau] cadres attendus.");
    }

    // ------------------------------------------------------------------ 3. portique
    [Fact]
    public void Portique_toutes_les_barres_reviennent_une_seule_fois()
    {
        var revit = RevitPortal();
        var (m, _, sum) = Trip(revit);
        Assert.Equal(revit.Members.Count, sum.Count(x => x.Type == "Beam" || x.Type == "Column"));
        var ids = sum.Where(x => x.Type == "Beam" || x.Type == "Column").Select(x => x.ExternalId).ToList();
        Assert.True(ids.Distinct().Count() == ids.Count, "[Revit portique] chaque identifiant Revit doit apparaître une seule fois dans le résumé (pas de doublon).");
        Assert.All(revit.Members, mm => Assert.Contains(sum, s => s.ExternalId == mm.ExternalId));
        Assert.All(sum.Where(x => x.Type == "Beam" || x.Type == "Column"), s => Assert.True(s.BotN > 0 || s.TopN > 0, $"[Revit portique] barre #{s.ExternalId} sans armatures dans le résumé."));
    }

    // ------------------------------------------------------------------ 4. escalier
    [Fact]
    public void Escalier_revient_avec_ses_armatures_par_volee()
    {
        var (_, o, sum) = Trip(RevitStair());
        var st = Assert.Single(sum, x => x.Type == "Stair");
        Assert.Equal("4001", st.ExternalId);
        Assert.True(int.Parse(st.Extra["N"]) >= 1, "[Revit escalier] au moins une volée attendue.");
        Assert.True(st.Extra.ContainsKey("Main_1") && !string.IsNullOrWhiteSpace(st.Extra["Main_1"]), "[Revit escalier] armature principale de la volée 1 attendue.");
        Assert.Single(o.Stairs);
    }

    // ------------------------------------------------------------------ mise à jour sans doublon
    [Fact]
    public void Mise_a_jour_identique_ne_change_rien_et_ne_duplique_pas()
    {
        var cur = RevitPortal(); AddLoads(cur);
        int nodes = cur.Nodes.Count, members = cur.Members.Count, loads = cur.MemberLoads.Count + cur.NodalLoads.Count;
        var rep = RevitSync.Merge(cur, RevitPortal());
        Assert.False(rep.HasChanges, "[Mise à jour] un export identique ne doit rien changer : " + rep.Details());
        Assert.Equal(members, cur.Members.Count);
        Assert.Equal(nodes, cur.Nodes.Count);
        Assert.Equal(loads, cur.MemberLoads.Count + cur.NodalLoads.Count);
        Assert.Equal(members, rep.Unchanged);
    }

    [Fact]
    public void Mise_a_jour_deux_fois_de_suite_est_stable()
    {
        var cur = RevitBeam(); AddLoads(cur);
        var inc = RevitBeam(); inc.Members[0].H = 0.60;
        var r1 = RevitSync.Merge(cur, inc);
        var r2 = RevitSync.Merge(cur, inc);
        Assert.Single(r1.Updated);
        Assert.False(r2.HasChanges, "[Mise à jour] la deuxième fusion du même export ne doit plus rien changer.");
        Assert.Single(cur.Members);
    }

    // ------------------------------------------------------------------ détection des modifications
    [Fact]
    public void Detection_section_modifiee_conserve_les_charges()
    {
        var cur = RevitBeam(); AddLoads(cur);
        int loads = cur.MemberLoads.Count;
        var inc = RevitBeam(); inc.Members[0].B = 0.30; inc.Members[0].H = 0.60;
        var rep = RevitSync.Merge(cur, inc);
        var ch = Assert.Single(rep.Updated);
        Assert.Contains("section", ch.Detail);
        Assert.Equal("1001", ch.ExternalId);
        Assert.Equal(0.30, cur.Members[0].B, 6);
        Assert.Equal(0.60, cur.Members[0].H, 6);
        Assert.True(cur.MemberLoads.Count == loads, "[Mise à jour] les charges saisies dans StructCalc doivent être conservées.");
        Assert.Empty(rep.Added); Assert.Empty(rep.Removed);
    }

    [Fact]
    public void Detection_poteau_deplace_deplace_le_noeud_et_signale_l_appui_orphelin()
    {
        var cur = RevitColumn();
        var inc = RevitColumn();
        inc.Nodes[0].X = 0.5; inc.Nodes[1].X = 0.5;                         // poteau déplacé de 50 cm
        inc.Supports.Clear(); inc.Supports.Add(new SupportDef { NodeId = 1 });
        var rep = RevitSync.Merge(cur, inc);
        var ch = Assert.Single(rep.Updated);
        Assert.Contains("position", ch.Detail);
        var mm = cur.Members[0];
        Assert.Equal(0.5, cur.Nodes.First(n => n.Id == mm.NodeI).X, 6);
        Assert.Contains(rep.Warnings, w => w.Contains("appui"));              // l'appui de l'ancien nœud n'est plus relié : on le dit
        Assert.True(cur.Supports.Any(s => s.NodeId == mm.NodeI), "[Mise à jour] l'appui venant de Revit doit être posé sur le nouveau nœud.");
    }

    [Fact]
    public void Nouvelle_barre_ajoutee_et_barre_disparue_signalee_mais_conservee()
    {
        var cur = RevitPortal();
        var inc = RevitPortal();
        string goneId = inc.Members[0].ExternalId;
        inc.Members.RemoveAt(0);                                                 // supprimée dans Revit
        inc.Nodes.Add(new Node { Id = 99, X = 20, Y = 0, Z = 3.2 }); inc.Nodes.Add(new Node { Id = 98, X = 25, Y = 0, Z = 3.2 });
        inc.Members.Add(new Member { Id = 99, NodeI = 98, NodeJ = 99, Type = MemberType.Beam, B = 0.25, H = 0.45, ExternalId = "9999" });
        int before = cur.Members.Count;
        var rep = RevitSync.Merge(cur, inc);
        Assert.Single(rep.Added);
        Assert.Equal("9999", rep.Added[0].ExternalId);
        var gone = Assert.Single(rep.Removed);
        Assert.Equal(goneId, gone.ExternalId);
        Assert.True(cur.Members.Any(x => x.ExternalId == goneId), "[Mise à jour] une barre disparue de Revit ne doit jamais être supprimée automatiquement.");
        Assert.Equal(before + 1, cur.Members.Count);
    }

    [Fact]
    public void Les_elements_saisis_dans_StructCalc_sans_identifiant_ne_sont_pas_touches()
    {
        var cur = RevitBeam();
        cur.Nodes.Add(new Node { Id = 10, X = 0, Y = 4, Z = 3 }); cur.Nodes.Add(new Node { Id = 11, X = 5, Y = 4, Z = 3 });
        cur.Members.Add(new Member { Id = 10, NodeI = 10, NodeJ = 11, B = 0.2, H = 0.4 });          // ExternalId vide : créée dans StructCalc
        var rep = RevitSync.Merge(cur, RevitBeam());
        Assert.Empty(rep.Removed);
        Assert.Contains(cur.Members, x => x.Id == 10 && x.ExternalId == "");
    }

    [Fact]
    public void Dalle_voile_escalier_modifies_sont_detectes()
    {
        var cur = RevitStair();
        cur.Slabs.Add(new SlabPanel { Name = "D1", ExternalId = "5001", Placed = true, Lx = 4, Ly = 5, H = 0.16, Z = 3 });
        cur.Walls.Add(new WallDef { Name = "V1", ExternalId = "6001", LengthM = 5, HeightM = 3, ThicknessM = 0.2 });
        var inc = RevitStair();
        inc.Slabs.Add(new SlabPanel { Name = "D1", ExternalId = "5001", Placed = true, Lx = 4, Ly = 5, H = 0.20, Z = 3 });
        inc.Walls.Add(new WallDef { Name = "V1", ExternalId = "6001", LengthM = 5, HeightM = 3, ThicknessM = 0.25 });
        inc.Stairs[0].HeightM = 3.2;
        var rep = RevitSync.Diff(cur, inc);
        Assert.Contains(rep.Updated, c => c.Family == "Dalle" && c.Detail.Contains("épaisseur"));
        Assert.Contains(rep.Updated, c => c.Family == "Voile" && c.Detail.Contains("épaisseur"));
        Assert.Contains(rep.Updated, c => c.Family == "Escalier" && c.Detail.Contains("hauteur"));
        Assert.Equal(0.16, cur.Slabs[0].H, 6);                                  // Diff ne modifie rien
        RevitSync.Merge(cur, inc);
        Assert.Equal(0.20, cur.Slabs[0].H, 6);
        Assert.Equal(0.25, cur.Walls[0].ThicknessM, 6);
        Assert.Equal(3.2, cur.Stairs[0].HeightM, 6);
    }
}
