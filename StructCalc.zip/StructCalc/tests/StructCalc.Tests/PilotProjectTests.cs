using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

/// <summary>Étape 3 : projet pilote R+1 de bout en bout, côté StructCalc (modèle, vérifications, calcul, ferraillage, métré, note de calcul, plans, résumé pour Revit).
/// Ce test dit si la chaîne tourne sans exception et produit des livrables cohérents ; il ne dit pas que les résultats sont justes
/// (voir VALIDATION_MOTEUR.md) ni que la maquette Revit est bien armée (à vérifier dans Revit, cf. PROJET_PILOTE.md).</summary>
public class PilotProjectTests
{
    private static (StructModel m, AnalysisOutput o) Run()
    {
        var m = ExampleModels.Pilot();
        var o = ProjectAnalyzer.Run(m, optimize: true);
        return (m, o);
    }

    [Fact]
    public void Le_modele_pilote_est_sain_avant_calcul()
    {
        var m = ExampleModels.Pilot();
        Assert.Equal(26, m.Members.Count);                              // 12 poteaux + 14 poutres
        Assert.Equal(4, m.Slabs.Count(s => s.Placed));
        Assert.Single(m.Stairs); Assert.Single(m.Walls);
        var errors = ModelChecker.Check(m).Where(i => i.Level == IssueLevel.Error).ToList();
        Assert.True(errors.Count == 0, "[Pilote] erreurs de modèle : " + string.Join(" | ", errors.Select(e => e.Message)));
    }

    [Fact]
    public void Le_calcul_complet_produit_tous_les_livrables_du_pilote()
    {
        var (m, o) = Run();
        Assert.Equal(26, o.Members.Count);
        Assert.All(o.Members, r => Assert.False(r.Skipped, $"[Pilote] barre {r.MemberId} non traitée."));
        Assert.True(o.Members.Where(r => r.Type == MemberType.Beam).All(r => r.BotN > 0 && r.StirDia > 0), "[Pilote] chaque poutre doit avoir des armatures inférieures et des cadres.");
        Assert.True(o.Members.Where(r => r.Type == MemberType.Column).All(r => r.BotN + r.TopN > 0), "[Pilote] chaque poteau doit avoir des armatures longitudinales.");
        Assert.True(o.Slabs.Count >= 1, "[Pilote] les dalles doivent être dimensionnées.");
        Assert.True(o.Footings.Count >= 1, "[Pilote] des semelles doivent être calculées sous les poteaux (contrainte du sol renseignée).");
        Assert.Single(o.Stairs);
        Assert.Single(o.Walls);
        Assert.NotNull(o.Global);
    }

    [Fact]
    public void Metre_note_de_calcul_et_plans_sont_generes()
    {
        var (m, o) = Run();
        var q = Quantities.Compute(m, o);
        Assert.True(q.ConcreteM3 > 10, $"[Pilote] volume de béton plausible (> 10 m³), obtenu {q.ConcreteM3:0.0}.");
        string html = ReportWriter.ToHtml(m, o);
        Assert.Contains("Projet pilote R+1", html);
        Assert.True(html.Length > 3000, "[Pilote] note de calcul HTML trop courte.");
        string txt = PdfReport.BuildText(m, o);
        Assert.False(string.IsNullOrWhiteSpace(txt));
        var sheets = DrawingGenerator.Generate(m, o, true);
        Assert.True(sheets.Count >= 3, $"[Pilote] au moins 3 feuilles de plans attendues, obtenu {sheets.Count}.");
        Assert.Contains(sheets, s => s.Name.StartsWith("Escalier"));
        Assert.True(sheets.All(s => s.Items.Count > 0), "[Pilote] aucune feuille ne doit être vide.");
    }

    [Fact]
    public void Resume_pour_Revit_contient_chaque_barre_liee_une_seule_fois()
    {
        var m = ExampleModels.Pilot();
        foreach (var mm in m.Members) mm.ExternalId = (7000 + mm.Id).ToString();       // comme si la structure venait de Revit
        var o = ProjectAnalyzer.Run(m, optimize: true);
        string f = Path.Combine(Path.GetTempPath(), "sc_pilot_" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            ModelIO.SaveRevitSummary(o, f, m);
            var sum = ModelIO.LoadRevitSummary(f);
            var bars = sum.Where(x => x.Type == "Beam" || x.Type == "Column").ToList();
            Assert.Equal(26, bars.Count);
            Assert.Equal(26, bars.Select(x => x.ExternalId).Distinct().Count());
        }
        finally { File.Delete(f); }
    }

    [Fact]
    public void Le_projet_pilote_se_relit_apres_enregistrement_et_recalcule_pareil()
    {
        var (m, o) = Run();
        string f = Path.Combine(Path.GetTempPath(), "sc_pilot2_" + Guid.NewGuid().ToString("N") + AppInfo.FileExt);
        try
        {
            ModelIO.Save(m, f);
            var back = ModelIO.Load(f);
            var o2 = ProjectAnalyzer.Run(back, optimize: true);
            Assert.Equal(o.Members.Count, o2.Members.Count);
            for (int i = 0; i < o.Members.Count; i++)
            {
                Assert.True(Math.Abs(o.Members[i].AsBottom - o2.Members[i].AsBottom) < 1e-6 && Math.Abs(o.Members[i].AsTop - o2.Members[i].AsTop) < 1e-6,
                    $"[Pilote] barre {o.Members[i].MemberId} : résultat différent après enregistrement / relecture.");
            }
        }
        finally { File.Delete(f); }
    }

    [Fact]
    public void Le_modele_pilote_est_propose_dans_les_modeles_de_depart()
    {
        Assert.Contains(ProjectTemplates.All, t => t.Name == "Projet pilote R+1");
        Assert.Equal(26, ProjectTemplates.All.First(t => t.Name == "Projet pilote R+1").Make().Members.Count);
    }
}
