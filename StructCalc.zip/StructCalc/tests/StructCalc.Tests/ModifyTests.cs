using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Outils de modification CAO (rotation, symétrie, échelle, étirement, division, fusion) et filtre de sélection.</summary>
public class ModifyTests
{
    private static StructModel Beam(double L = 6)
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = 0.3, H = 0.5 });
        return m;
    }

    [Fact]
    public void Rotation_Copy_90Degrees()
    {
        var m = Beam();
        var c = ModifyTools.CopyTransformed(m, new[] { 1 }, Xform.Rotation(0, 0, 90));
        Assert.Single(c);
        var mem = m.Members.First(q => q.Id == c[0]);
        var a = m.Nodes.First(n => n.Id == mem.NodeJ);
        Assert.Equal(0, a.X, 5); Assert.Equal(6, a.Y, 5);
        Assert.Equal(1, mem.NodeI);        // le nœud (0,0) est partagé
    }

    [Fact]
    public void Rotation_RotatesGlobalHorizontalLoad()
    {
        var m = Beam();
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.W, Wx = 0, Wy = 5 });
        var c = ModifyTools.CopyTransformed(m, new[] { 1 }, Xform.Rotation(0, 0, 90));
        var l = m.MemberLoads.First(q => q.MemberId == c[0]);
        Assert.Equal(-5, l.Wx, 6); Assert.Equal(0, l.Wy, 6);
    }

    [Fact]
    public void MirrorLine_AboutYAxis()
    {
        var m = Beam();
        var c = ModifyTools.CopyTransformed(m, new[] { 1 }, Xform.MirrorLine(0, 0, 0, 1));
        var mem = m.Members.First(q => q.Id == c[0]);
        Assert.Equal(-6, m.Nodes.First(n => n.Id == mem.NodeJ).X, 5);
    }

    [Fact]
    public void Scale_InPlace_ScalesLoadPositions()
    {
        var m = Beam();
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Kind = MemberLoadKind.Point, A = 2, Pz = -10 });
        ModifyTools.TransformInPlace(m, new[] { 1, 2 }, Xform.Scale(0, 0, 0, 2, 1, 1));
        Assert.Equal(12, m.Nodes.First(n => n.Id == 2).X, 5);
        Assert.Equal(4, m.MemberLoads[0].A, 5);
    }

    [Fact]
    public void Stretch_MovesOnlyNodesInWindow()
    {
        var m = Beam();
        var r = ModifyTools.Stretch(m, 5, -1, 7, 1, -1, 1, 2, 0, 0);
        Assert.Equal(1, r.Moved);
        Assert.Equal(8, m.Nodes.First(n => n.Id == 2).X, 5);
        Assert.Equal(0, m.Nodes.First(n => n.Id == 1).X, 5);
    }

    [Fact]
    public void Split_PreservesTotalLoad()
    {
        var m = Beam(6);
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Kind = MemberLoadKind.Trapezoid, A = 1, B = 5, Wz = 0, Wz2 = -12 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Kind = MemberLoadKind.Point, A = 4.5, Pz = -20 });
        double Total() => LoadExpander.MemberLoadsOf(m).Sum(l => l.Kind == MemberLoadKind.Point ? l.Pz : (l.Wz + l.Wz2) / 2 * (l.B - l.A));
        double before = Total();
        var parts = ModifyTools.SplitMember(m, 1, new[] { 2.0, 4.0 });
        Assert.Equal(3, parts.Count);
        Assert.Equal(before, Total(), 6);
        Assert.Equal(-24 - 20, Total(), 6);
    }

    [Fact]
    public void Split_KeepsReactions()
    {
        var m1 = Beam(6); var m2 = Beam(6);
        foreach (var m in new[] { m1, m2 })
        {
            m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
            m.Supports.Add(new SupportDef { NodeId = 2, Ux = false, Rx = false, Ry = false, Rz = false });
            m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -10 });
            m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Kind = MemberLoadKind.Point, A = 1.5, Pz = -30 });
        }
        ModifyTools.DivideEqual(m2, new[] { 1 }, 4);
        var r1 = FrameSolver.Solve(m1, ActionType.Q); var r2 = FrameSolver.Solve(m2, ActionType.Q);
        Assert.Equal(r1.Reactions[1][2], r2.Reactions[1][2], 4);
        Assert.Equal(4, m2.Members.Count);
    }

    [Fact]
    public void MergeNodes_RemovesDuplicates()
    {
        var m = Beam();
        m.Nodes.Add(new Node { Id = 3, X = 6.001, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 4, X = 6, Y = 5, Z = 0 });
        m.Members.Add(new Member { Id = 2, NodeI = 3, NodeJ = 4, B = 0.3, H = 0.5 });
        var r = ModifyTools.MergeNodes(m, 0.005);
        Assert.Equal(1, r.MergedNodes);
        Assert.Equal(3, m.Nodes.Count);
        Assert.Equal(2, m.Members[1].NodeI);
    }

    [Fact]
    public void ArrayRect_CreatesExpectedCount()
    {
        var m = Beam();
        var c = ModifyTools.ArrayRect(m, new[] { 1 }, 1, 3, 2, 0, 5, 3);
        Assert.Equal(5, c.Count);
    }

    [Fact]
    public void ArrayPolar_FullCircle()
    {
        var m = Beam(3);
        var c = ModifyTools.ArrayPolar(m, new[] { 1 }, 0, 0, 4, 360);
        Assert.Equal(3, c.Count);
    }

    [Fact]
    public void Filter_ByTypeAndLength()
    {
        var m = Beam(6);
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 2, NodeI = 1, NodeJ = 3, Type = MemberType.Column, B = 0.3, H = 0.3 });
        Assert.Equal(new[] { 2 }, SelectionFilter.Apply(m, null, new SelectionFilterSpec { Beams = false }));
        Assert.Equal(new[] { 1 }, SelectionFilter.Apply(m, null, new SelectionFilterSpec { MinLength = 5 }));
        Assert.Equal(new[] { 1 }, SelectionFilter.Apply(m, null, new SelectionFilterSpec { Vertical = false }));
        Assert.Equal(new[] { 1, 2 }, SelectionFilter.Apply(m, null, new SelectionFilterSpec { Ids = "1-2" }));
    }
}
