using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

public class SolverTests
{
    private static StructModel Beam(double L, double b, double h)
    {
        var m = new StructModel { IncludeSelfWeight = false, Fc28 = 25 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = b, H = h });
        return m;
    }

    [Fact]
    public void Cantilever_TipLoad_Deflection()
    {
        double L = 3, b = 0.3, h = 0.5, P = 50;
        var m = Beam(L, b, h);
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.Q, Fz = -P });
        var res = FrameSolver.Solve(m, ActionType.Q);
        double EI = m.EcKNm2 * b * h * h * h / 12.0;
        double expected = -P * L * L * L / (3 * EI);
        Assert.Equal(expected, res.NodeDisp[2][2], 8);
        Assert.Equal(P, res.Reactions[1][2], 6);
        Assert.Equal(P * L, Math.Abs(res.Reactions[1][4]), 5);
    }

    [Fact]
    public void SimplySupported_UDL_MidspanMoment()
    {
        double L = 6, w = 20;
        var m = Beam(L, 0.3, 0.5);
        m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 2, Ux = false, Rx = false, Ry = false, Rz = false });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -w });
        var res = FrameSolver.Solve(m, ActionType.Q);
        var mid = res.Members[1][FrameSolver.Stations / 2];
        Assert.Equal(w * L * L / 8, -mid.My, 4);          // flexion en travée = -My
        Assert.Equal(w * L / 2, res.Reactions[1][2], 4);
        Assert.Equal(w * L / 2, Math.Abs(res.Members[1][0].Vz), 4);
    }

    [Fact]
    public void FixedFixed_UDL_EndMoment()
    {
        double L = 5, w = 30;
        var m = Beam(L, 0.3, 0.5);
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 2 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -w });
        var res = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(w * L * L / 12, res.Members[1][0].My, 4);                    // appui : My positif (fibre sup. tendue)
        Assert.Equal(-w * L * L / 24, res.Members[1][FrameSolver.Stations / 2].My, 4);
    }

    [Fact]
    public void Portal_Runs_And_Optimizes()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, optimize: true);
        Assert.Equal(m.Members.Count, o.Members.Count);
        Assert.All(o.Members, r => Assert.False(r.Skipped));
        Assert.Single(o.Slabs);
        Assert.NotEmpty(o.Footings);
    }

    [Fact]
    public void Unsupported_Structure_Throws()
    {
        var m = Beam(4, 0.3, 0.5);
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.Q, Fz = -10 });
        Assert.Throws<InvalidOperationException>(() => FrameSolver.Solve(m, ActionType.Q));
    }

    [Fact]
    public void Json_RoundTrip()
    {
        var m = ExampleModels.Portal();
        var m2 = ModelIO.FromJson(ModelIO.ToJson(m));
        Assert.Equal(m.Nodes.Count, m2.Nodes.Count);
        Assert.Equal(m.Members.Count, m2.Members.Count);
        Assert.Equal(m.MemberLoads.Count, m2.MemberLoads.Count);
    }

    [Fact]
    public void Quantities_And_Envelopes_Are_Filled()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, optimize: true);
        var q = Quantities.Compute(m, o);
        Assert.True(q.ConcreteM3 > 0);
        Assert.True(q.RebarKg > 0);
        var beam = o.Members.First(r => r.Type == StructCalc.Core.Model.MemberType.Beam);
        Assert.Equal(FrameSolver.Stations, beam.StX.Length);
        Assert.True(beam.BotN >= 2 && beam.BotDia >= 10 && beam.StirDia >= 6);
        Assert.True(beam.Utilization > 0);
    }
}
