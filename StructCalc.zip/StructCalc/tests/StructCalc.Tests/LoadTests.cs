using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Charges de barre (ponctuelles à distance, trapézoïdales, moments, températures) et charges surfaciques : comparaison aux formules de la RDM.</summary>
public class LoadTests
{
    private static StructModel SimpleBeam(double L = 6)
    {
        var m = new StructModel { IncludeSelfWeight = false, Fc28 = 25 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = 0.3, H = 0.5 });
        m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 2, Ux = false, Rx = false, Ry = false, Rz = false });
        return m;
    }

    private static StructModel FixedBeam(double L = 6)
    {
        var m = SimpleBeam(L);
        m.Supports.Clear();
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 2 });
        return m;
    }

    [Fact]
    public void PointLoad_Midspan()
    {
        double L = 6, P = 40;
        var m = SimpleBeam(L);
        LoadBuilder.AddPointForce(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, 0.5, true, false, 0, 0, -P);
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(P / 2, r.Reactions[1][2], 4);
        Assert.Equal(P / 2, r.Reactions[2][2], 4);
        Assert.Equal(P * L / 4, -r.Members[1][FrameSolver.Stations / 2].My, 4);
    }

    [Fact]
    public void PointLoad_AtDistance_HasExactStationAndPeakMoment()
    {
        double L = 6, P = 30, a = 2.0, b = L - a;
        var m = SimpleBeam(L);
        LoadBuilder.AddPointForce(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, a, false, false, 0, 0, -P);
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(P * b / L, r.Reactions[1][2], 4);
        var st = r.Members[1];
        Assert.Contains(st, s => Math.Abs(s.X - a) < 1e-9);
        Assert.Equal(P * a * b / L, st.Max(s => -s.My), 4);
        for (int k = 1; k < st.Length; k++) Assert.True(st[k].X > st[k - 1].X);      // abscisses strictement croissantes
    }

    [Fact]
    public void PointLoad_FromNodeJ_EqualsMirroredPosition()
    {
        double L = 6, P = 25;
        var m1 = SimpleBeam(L); var m2 = SimpleBeam(L);
        LoadBuilder.AddPointForce(m1, new[] { 1 }, ActionType.Q, LoadFrame.Global, 1.5, false, true, 0, 0, -P);    // 1,5 m depuis j
        LoadBuilder.AddPointForce(m2, new[] { 1 }, ActionType.Q, LoadFrame.Global, 4.5, false, false, 0, 0, -P);   // 4,5 m depuis i
        var r1 = FrameSolver.Solve(m1, ActionType.Q); var r2 = FrameSolver.Solve(m2, ActionType.Q);
        Assert.Equal(r2.Reactions[1][2], r1.Reactions[1][2], 6);
        Assert.Equal(P * 4.5 / L, r1.Reactions[2][2], 6);
        Assert.Equal(P * 1.5 / L, r1.Reactions[1][2], 6);
    }

    [Fact]
    public void LocalAxesPointLoad_OnColumn_IsHorizontalForce()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 4 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.3, H = 0.3 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        LoadBuilder.AddPointForce(m, new[] { 1 }, ActionType.W, LoadFrame.Global, 0.5, true, false, 12, 0, 0);     // 12 kN suivant X au milieu du poteau
        var r = FrameSolver.Solve(m, ActionType.W);
        Assert.Equal(-12, r.Reactions[1][0], 4);                      // la réaction équilibre la force
        Assert.Equal(12 * 2.0, Math.Abs(r.Reactions[1][4]), 4);       // moment d'encastrement P.a
    }

    [Fact]
    public void Triangular_Load_Reactions()
    {
        double L = 6, w = 18;
        var m = SimpleBeam(L);
        // 0 à l'appui i, w à l'appui j
        LoadBuilder.AddTrapezoid(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, 0, 1, true, false, new[] { 0.0, 0, 0 }, new[] { 0.0, 0, -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(w * L / 6, r.Reactions[1][2], 4);
        Assert.Equal(w * L / 3, r.Reactions[2][2], 4);
    }

    [Fact]
    public void Triangular_Load_FromEndJ_IsMirrored()
    {
        double L = 6, w = 18;
        var m = SimpleBeam(L);
        LoadBuilder.AddTrapezoid(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, 0, 1, true, true, new[] { 0.0, 0, 0 }, new[] { 0.0, 0, -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(w * L / 3, r.Reactions[1][2], 4);       // maintenant le maximum est du côté de i
        Assert.Equal(w * L / 6, r.Reactions[2][2], 4);
    }

    [Fact]
    public void PartialUniformLoad_Reactions()
    {
        double L = 8, q = 10, a = 2, b = 5;
        var m = SimpleBeam(L);
        LoadBuilder.AddTrapezoid(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, a, b, false, false, new[] { 0.0, 0, -q }, new[] { 0.0, 0, -q });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double F = q * (b - a), xc = (a + b) / 2;
        Assert.Equal(F * (L - xc) / L, r.Reactions[1][2], 4);
        Assert.Equal(F * xc / L, r.Reactions[2][2], 4);
    }

    [Fact]
    public void Partial_And_Full_Uniform_Agree()
    {
        double L = 5, q = 12;
        var m1 = FixedBeam(L); var m2 = FixedBeam(L);
        m1.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -q });
        LoadBuilder.AddTrapezoid(m2, new[] { 1 }, ActionType.Q, LoadFrame.Global, 0, 1, true, false, new[] { 0.0, 0, -q }, new[] { 0.0, 0, -q });
        var r1 = FrameSolver.Solve(m1, ActionType.Q); var r2 = FrameSolver.Solve(m2, ActionType.Q);
        Assert.Equal(r1.Members[1][0].My, r2.Members[1][0].My, 6);
        Assert.Equal(r1.NodeDisp[2][5], r2.NodeDisp[2][5], 9);
        Assert.Equal(r1.Members[1][FrameSolver.Stations / 2].My, r2.Members[1][FrameSolver.Stations / 2].My, 6);
    }

    [Fact]
    public void PointMoment_Midspan_ReactionsAndJump()
    {
        double L = 6, M0 = 30;
        var m = SimpleBeam(L);
        LoadBuilder.AddPointMoment(m, new[] { 1 }, ActionType.Q, LoadFrame.Global, 0.5, true, false, 0, M0, 0);
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(M0 / L, r.Reactions[2][2], 4);
        Assert.Equal(-M0 / L, r.Reactions[1][2], 4);
        var st = r.Members[1];
        int k = Array.FindIndex(st, s => Math.Abs(s.X - L / 2) < 1e-9);
        Assert.True(k > 0);
        Assert.Equal(M0 / 2, Math.Abs(st[k].My), 4);
        Assert.Equal(0.45 * M0, Math.Abs(st[k - 1].My), 4);                               // juste avant : x.M0/L avec x = 2,7 m
        Assert.True(st[k].My * st[k - 1].My < 0);                                         // le moment change de signe en traversant le moment appliqué
    }

    [Fact]
    public void Thermal_Uniform_Restrained_AxialForce()
    {
        double L = 5, dt = 20;
        var m = FixedBeam(L);
        LoadBuilder.AddThermal(m, new[] { 1 }, ActionType.Q, dt, 0);
        var r = FrameSolver.Solve(m, ActionType.Q);
        double expected = -m.EcKNm2 * 0.3 * 0.5 * 1.0e-5 * dt;            // compression
        Assert.Equal(expected, r.Members[1][3].N, 3);
        Assert.Equal(expected, r.Members[1][FrameSolver.Stations - 1].N, 3);
    }

    [Fact]
    public void Thermal_Gradient_Restrained_ConstantMoment()
    {
        double L = 5, dg = 15;
        var m = FixedBeam(L);
        LoadBuilder.AddThermal(m, new[] { 1 }, ActionType.Q, 0, dg);
        var r = FrameSolver.Solve(m, ActionType.Q);
        double I = 0.3 * Math.Pow(0.5, 3) / 12;
        double expected = m.EcKNm2 * I * 1.0e-5 * dg / 0.5;
        foreach (var s in r.Members[1]) Assert.Equal(expected, Math.Abs(s.My), 3);
        Assert.True(r.Members[1][0].My * r.Members[1][10].My > 0);                         // moment constant (même signe partout)
    }

    [Fact]
    public void Thermal_Free_Cantilever_NoStress()
    {
        var m = SimpleBeam(4);
        m.Supports.Clear();
        m.Supports.Add(new SupportDef { NodeId = 1 });
        LoadBuilder.AddThermal(m, new[] { 1 }, ActionType.Q, 30, 10);
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.All(r.Members[1], s => { Assert.Equal(0, s.N, 4); Assert.Equal(0, s.My, 4); });
        Assert.Equal(1.0e-5 * 30 * 4, r.NodeDisp[2][0], 7);                                // dilatation libre
    }

    [Fact]
    public void Local_Frame_Uniform_On_InclinedBeam_IsPerpendicular()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 3, Y = 0, Z = 4 });      // L = 5, inclinée
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = 0.3, H = 0.4 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 2 });
        LoadBuilder.AddUniform(m, new[] { 1 }, ActionType.Q, LoadFrame.Local, 0, 0, -10);          // 10 kN/m perpendiculaire à la barre
        var r = FrameSolver.Solve(m, ActionType.Q);
        double fx = r.Reactions[1][0] + r.Reactions[2][0], fz = r.Reactions[1][2] + r.Reactions[2][2];
        // normale locale z = (-0,8 ; 0 ; 0,6) : charge globale = -10 x z = (8 ; 0 ; -6) kN/m, soit (40 ; 0 ; -30) kN sur 5 m
        Assert.Equal(-40, fx, 3);
        Assert.Equal(30, fz, 3);
    }

    // ------------------------------------------------------------------ charges surfaciques
    private static StructModel FrameWithSlabs(int bx = 2, int by = 2)
    {
        var m = FrameGenerator.Generate(new FrameSpec { BaysX = bx, BaysY = by, Storeys = 1, SpanX = 4, SpanY = 5, StoreyHeight = 3, G = 0, Q = 0 });
        m.IncludeSelfWeight = false;
        return m;
    }

    [Fact]
    public void DetectPanels_Finds_All_Cells()
    {
        var m = FrameWithSlabs();
        var panels = LoadExpander.DetectPanels(m);
        Assert.Equal(4, panels.Count);
        Assert.All(panels, p => Assert.Equal(3.0, p.Z, 6));
    }

    [Fact]
    public void SurfaceLoad_TwoWay_DistributesWholeLoad()
    {
        var m = FrameWithSlabs(1, 1);
        var s = LoadBuilder.AddSurface(m, ActionType.Q, 5, SurfaceDistribution.TwoWay, 3, 0, 0, 4, 5);
        var ex = LoadExpander.Expand(m, s);
        Assert.Equal(5 * 4 * 5, ex.TotalKn, 6);
        Assert.Equal(ex.TotalKn, ex.CarriedKn, 6);
        Assert.Equal(1.0, ex.LoadedFraction, 6);
        Assert.Equal(1.0, ex.MinEdgeCoverage, 6);
        // bords courts (4 m) : triangle de pointe q.lx/2 = 10 kN/m ; bords longs (5 m) : trapèze de pointe 10 kN/m
        Assert.Contains(ex.Loads, l => Math.Abs(Math.Max(Math.Abs(l.Wz), Math.Abs(l.Wz2)) - 10) < 1e-9);
        Assert.All(ex.Loads, l => Assert.True(Math.Max(Math.Abs(l.Wz), Math.Abs(l.Wz2)) <= 10 + 1e-9));
    }

    [Fact]
    public void SurfaceLoad_OneWay_GoesToTwoEdges()
    {
        var m = FrameWithSlabs(1, 1);
        var s = LoadBuilder.AddSurface(m, ActionType.Q, 6, SurfaceDistribution.OneWayX, 3, 0, 0, 4, 5);
        var ex = LoadExpander.Expand(m, s);
        Assert.Equal(2, ex.Loads.Count);                                  // les deux poutres parallèles à Y
        Assert.All(ex.Loads, l => Assert.Equal(-6 * 4 / 2.0, l.Wz, 9));   // q.Lx/2 = 12 kN/m
        Assert.Equal(6 * 4 * 5, ex.CarriedKn, 6);
    }

    [Fact]
    public void SurfaceLoad_Reactions_Equal_Total_Load()
    {
        var m = FrameWithSlabs();
        int n = LoadBuilder.AddSurfaceAuto(m, ActionType.Q, 5, SurfaceDistribution.TwoWay, null);
        Assert.Equal(4, n);
        var r = FrameSolver.Solve(m, ActionType.Q);
        double fz = r.Reactions.Values.Sum(x => x[2]);
        Assert.Equal(5 * 8 * 10, fz, 3);                                  // somme des réactions = q x aire totale
    }

    [Fact]
    public void SurfaceLoad_Without_Beams_Is_Reported()
    {
        var m = FrameWithSlabs(1, 1);
        LoadBuilder.AddSurface(m, ActionType.Q, 5, SurfaceDistribution.TwoWay, 9.0, 0, 0, 4, 5);   // cote où il n'y a aucune poutre
        var issues = ModelChecker.Check(m);
        Assert.Contains(issues, i => i.Level == IssueLevel.Error && i.Message.Contains("aucune poutre"));
    }

    [Fact]
    public void SurfaceLoad_Json_RoundTrip_And_Clone()
    {
        var m = FrameWithSlabs(1, 1);
        LoadBuilder.AddSurface(m, ActionType.G, 3.5, SurfaceDistribution.OneWayY, 3, 0, 0, 4, 5);
        LoadBuilder.AddPointForce(m, new[] { 5 }, ActionType.Q, LoadFrame.Local, 1.2, false, true, 0, 0, -7);
        var m2 = ModelIO.FromJson(ModelIO.ToJson(m));
        Assert.Single(m2.SurfaceLoads);
        Assert.Equal(SurfaceDistribution.OneWayY, m2.SurfaceLoads[0].Distribution);
        var pl = m2.MemberLoads.Single(l => l.Kind == MemberLoadKind.Point);
        Assert.Equal(LoadFrame.Local, pl.Frame);
        Assert.Equal(-7, pl.Pz, 9);
        Assert.Equal(pl.A, pl.Clone().A);
    }

    [Fact]
    public void MixedLoads_FullAnalysis_Runs()
    {
        var m = ExampleModels.Portal();
        int beam = m.Members.First(x => x.Type == MemberType.Beam).Id;
        LoadBuilder.AddPointForce(m, new[] { beam }, ActionType.Q, LoadFrame.Global, 0.3, true, false, 0, 0, -20);
        LoadBuilder.AddTrapezoid(m, new[] { beam }, ActionType.G, LoadFrame.Global, 0.2, 0.8, true, false, new[] { 0.0, 0, -4 }, new[] { 0.0, 0, -9 });
        LoadBuilder.AddThermal(m, new[] { beam }, ActionType.Q, 10, 0);
        var o = ProjectAnalyzer.Run(m, optimize: true);
        Assert.All(o.Members, r => Assert.False(r.Skipped));
    }

    [Fact]
    public void Describer_Gives_Text_For_Every_Kind()
    {
        foreach (var k in Enum.GetValues<MemberLoadKind>())
        {
            var l = new MemberLoad { MemberId = 1, Kind = k, Wz = -5, Wz2 = -2, Pz = -3, My = 4, Dt = 5, A = 0.5, B = 0.9, Relative = true };
            Assert.False(string.IsNullOrWhiteSpace(LoadDescriber.Describe(l)));
        }
        Assert.False(string.IsNullOrWhiteSpace(LoadDescriber.Describe(new SurfaceLoad { Q = 4 })));
    }
}
