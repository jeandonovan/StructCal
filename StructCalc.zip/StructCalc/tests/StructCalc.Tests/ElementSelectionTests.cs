using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Selection;
using Xunit;

/// <summary>Sélection centrale : identité des éléments, ordre de désignation (le plus proche de la caméra), cycle au clic répété,
/// résumé de la sélection, catalogue par famille, état NON OK / messages et filtre global. Le dessin et la souris se vérifient à l'écran.</summary>
public class ElementSelectionTests
{
    private static StructModel Model()
    {
        var m = new StructModel();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 5, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 5, Y = 4, Z = 0 }); m.Nodes.Add(new Node { Id = 4, X = 0, Y = 4, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3 });
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 5, Ly = 4, Z = 3 });
        m.Slabs.Add(new SlabPanel { Name = "D2", Placed = true, X0 = 5, Y0 = 0, Lx = 5, Ly = 4, Z = 3 });
        m.Slabs.Add(new SlabPanel { Name = "Esquisse", Placed = false });
        m.Stairs.Add(new StairDef { Name = "E1", Placed = true });
        m.Walls.Add(new WallDef { Name = "V1" });
        m.Rafts.Add(new RaftDef { Name = "R1" });
        m.RibbedFloors.Add(new RibbedFloorDef { Name = "PL1" });
        m.Shells.Add(new ShellPanel { Name = "VM1", Kind = "Voile", N1 = 1, N2 = 2, N3 = 3, N4 = 4 });
        m.Shells.Add(new ShellPanel { Name = "VM1", Kind = "Voile", N1 = 1, N2 = 2, N3 = 3, N4 = 4 });
        m.FootingDefs.Add(new FootingDef { Name = "F1", Kind = FootingKind.Filante, LengthM = 6 });
        m.FootingDefs.Add(new FootingDef { Name = "S9", Kind = FootingKind.Isolee });
        return m;
    }

    // ------------------------------------------------------------------ identité
    [Fact]
    public void Keys_AreValuesOfTheModel_NotOfTheView()
    {
        Assert.Equal(ElementKey.Bar(3), ElementKey.Bar(3));
        Assert.NotEqual(ElementKey.Bar(3), ElementKey.Node(3));
        Assert.Equal(ElementKey.Named(ElementKind.Slab, "D1"), ElementKey.Named(ElementKind.Slab, "D1"));
        Assert.NotEqual(ElementKey.Named(ElementKind.Slab, "D1"), ElementKey.Named(ElementKind.Shell, "D1"));
        Assert.Equal("Semelle S12", ElementKey.FootingAt(12).Label);
        Assert.Equal("Plancher nervuré PL1", ElementKey.Named(ElementKind.Ribbed, "PL1").Label);
    }

    // ------------------------------------------------------------------ désignation
    private static PickCandidate Area(string n, double depth, bool opaque = false) => new(ElementKey.Named(ElementKind.Slab, n), depth, false, opaque);
    private static PickCandidate Line(int id, double depth) => new(ElementKey.Bar(id), depth, true, false);

    [Fact]
    public void Pick_NearestToCameraWins()
    {
        var order = PickLogic.Order(new[] { Area("loin", 10), Area("près", 2), Area("milieu", 6) });
        Assert.Equal(new[] { "près", "milieu", "loin" }, order.Select(k => k.Name).ToArray());
    }

    [Fact]
    public void Pick_NodeFirst_ThenBarSeenThroughTranslucentSlab()
    {
        var order = PickLogic.Order(new[] { Area("dalle", 1), Line(7, 5), new PickCandidate(ElementKey.Node(4), 9, true, false) });
        Assert.Equal(ElementKey.Node(4), order[0]);
        Assert.Equal(ElementKey.Bar(7), order[1]);          // la barre visible à travers la dalle translucide reste désignable
        Assert.Equal("dalle", order[2].Name);
    }

    [Fact]
    public void Pick_OpaqueElementInFrontHidesBarBehind()
    {
        var order = PickLogic.Order(new[] { Line(7, 5), Area("mur", 2, opaque: true) });
        Assert.Equal("mur", order[0].Name);                 // un élément opaque plus proche masque la barre derrière lui
        Assert.Equal(ElementKey.Bar(7), order[1]);
        var order2 = PickLogic.Order(new[] { Line(7, 1), Area("mur", 2, opaque: true) });
        Assert.Equal(ElementKey.Bar(7), order2[0]);         // barre devant le mur : elle reste désignable
    }

    [Fact]
    public void Pick_SameElementReportedOnce()
    {
        var order = PickLogic.Order(new[] { Area("D1", 3), Area("D1", 4), Area("D1", 2) });
        Assert.Single(order);
    }

    [Fact]
    public void Pick_SecondClickAtSamePlace_CyclesToNextElement_AndWraps()
    {
        var order = PickLogic.Order(new[] { Area("A", 1), Area("B", 2), Area("C", 3) });
        var first = PickLogic.Choose(order, null, false);
        Assert.Equal("A", first!.Value.Name);
        var second = PickLogic.Choose(order, first, true);
        Assert.Equal("B", second!.Value.Name);
        var third = PickLogic.Choose(order, second, true);
        Assert.Equal("C", third!.Value.Name);
        Assert.Equal("A", PickLogic.Choose(order, third, true)!.Value.Name);           // boucle
        Assert.Equal("A", PickLogic.Choose(order, third, false)!.Value.Name);          // ailleurs : on repart du plus proche
        Assert.Null(PickLogic.Choose(new List<ElementKey>(), null, false));
    }

    // ------------------------------------------------------------------ résumé
    [Fact]
    public void Summary_CountsTypes_HiddenAndOffView()
    {
        var keys = new List<ElementKey>
        {
            ElementKey.Named(ElementKind.Slab, "D1"), ElementKey.Named(ElementKind.Slab, "D2"), ElementKey.FootingAt(3),
            ElementKey.Bar(1), ElementKey.Bar(2), ElementKey.Bar(3)
        };
        string t = SelectionSummary.Describe(keys, k => k == ElementKey.Bar(3), k => k == ElementKey.FootingAt(3));
        Assert.Contains("6 éléments", t);
        Assert.Contains("3 barres", t);
        Assert.Contains("2 dalles", t);
        Assert.Contains("1 semelle", t);
        Assert.Contains("1 masqué", t);
        Assert.Contains("1 hors vue", t);
        Assert.Equal("Aucune sélection", SelectionSummary.Describe(new List<ElementKey>()));
    }

    // ------------------------------------------------------------------ catalogue
    [Fact]
    public void Catalog_ListsEachFamily_ShellsGroupedByName_UnplacedSlabsExcluded()
    {
        var m = Model();
        Assert.Equal(2, ElementCatalog.All(m, null, ElementKind.Bar).Count);
        Assert.Equal(4, ElementCatalog.All(m, null, ElementKind.Node).Count);
        Assert.Equal(new[] { "D1", "D2" }, ElementCatalog.All(m, null, ElementKind.Slab).Select(k => k.Name).ToArray());
        Assert.Single(ElementCatalog.All(m, null, ElementKind.Stair));
        Assert.Single(ElementCatalog.All(m, null, ElementKind.Wall));
        Assert.Single(ElementCatalog.All(m, null, ElementKind.Raft));
        Assert.Single(ElementCatalog.All(m, null, ElementKind.Ribbed));
        Assert.Single(ElementCatalog.All(m, null, ElementKind.Shell));        // deux mailles, un seul voile
        Assert.Equal(new[] { "F1" }, ElementCatalog.All(m, null, ElementKind.Footing).Select(k => k.Name).ToArray());   // la semelle filante ; les isolées apparaissent après calcul
    }

    // ------------------------------------------------------------------ NON OK et messages
    private static AnalysisOutput Output()
    {
        var o = new AnalysisOutput();
        o.Slabs.Add(new DesignResult { Element = "Dalle D1 (4.00 x 5.00)", Ok = false });
        o.Slabs.Add(new DesignResult { Element = "Dalle D2 (4.00 x 5.00)", Ok = true });
        o.Footings.Add(new DesignResult { Element = "Semelle sous nœud 3 (2.00 x 2.00)", Ok = false });
        o.Extras.Add(new ExtraDesign { Title = "Escalier E1", Ok = false, Text = "NON OK : contremarche" });
        o.Extras.Add(new ExtraDesign { Title = "Voile V1", Ok = true, Text = "ok" });
        return o;
    }

    [Fact]
    public void NonOk_OnlyWhenCalculated_AndNeverGuessed()
    {
        var o = Output();
        Assert.True(ElementStatus.NonOk(o, ElementKey.Named(ElementKind.Slab, "D1")));
        Assert.False(ElementStatus.NonOk(o, ElementKey.Named(ElementKind.Slab, "D2")));
        Assert.True(ElementStatus.NonOk(o, ElementKey.FootingAt(3)));
        Assert.True(ElementStatus.NonOk(o, ElementKey.Named(ElementKind.Stair, "E1")));
        Assert.False(ElementStatus.NonOk(o, ElementKey.Named(ElementKind.Wall, "V1")));
        Assert.False(ElementStatus.NonOk(null, ElementKey.Named(ElementKind.Slab, "D1")));         // pas de calcul = jamais NON OK
        Assert.False(ElementStatus.NonOk(o, ElementKey.Named(ElementKind.Shell, "VM1")));
        Assert.True(ElementStatus.HasResult(o, ElementKey.Named(ElementKind.Slab, "D2")));
        Assert.False(ElementStatus.HasResult(o, ElementKey.Named(ElementKind.Slab, "D9")));
        Assert.False(ElementStatus.HasResult(o, ElementKey.Named(ElementKind.Shell, "VM1")));
        Assert.False(ElementStatus.HasResult(null, ElementKey.Bar(1)));
    }

    private static AppMessage Msg(string kind, string label, int? node = null, int? member = null, MsgSource src = MsgSource.Dimensionnement) =>
        new() { Key = kind + label, ElementKind = kind, ElementLabel = label, NodeId = node, MemberId = member, Source = src };

    [Fact]
    public void Messages_AreLinkedToTheirElement()
    {
        var msgs = new List<AppMessage>
        {
            Msg("Dalle", "Dalle D1"), Msg("Barre", "Barre 2", member: 2), Msg("Nœud", "Nœud 4", node: 4),
            Msg("Semelle", "S3", node: 3), Msg("Module", "Escalier E1"), Msg("Coque", "Coque VM1"),
            Msg("Dalle / poteau", "P1 / dalle D2"), Msg("Module", "Semelle S12 (sous le nœud)"),
            Msg("Barre", "Barre 1", member: 1, src: MsgSource.Journal)
        };
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Slab, "D1")));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Slab, "D2")));           // poinçonnement sous la dalle D2
        Assert.False(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Slab, "D3")));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Bar(2)));
        Assert.False(ElementStatus.HasMessages(msgs, ElementKey.Bar(1)));                                  // une ligne du journal ne désigne aucun élément
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Node(4)));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.FootingAt(3)));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.FootingAt(12)));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Stair, "E1")));
        Assert.False(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Stair, "E2")));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Shell, "VM1")));
        Assert.Single(ElementStatus.MessagesOf(msgs, ElementKey.Named(ElementKind.Slab, "D1")));
    }

    [Fact]
    public void Messages_BuiltByTheMessageCenter_AreFoundByElement()
    {
        var m = Model();
        var o = Output();
        var msgs = MessageCenter.Build(m, o, new List<ModelIssue>(), new List<string>(), new List<string>());
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Slab, "D1")));           // dalle NON OK
        Assert.False(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Slab, "D2")));
        Assert.True(ElementStatus.HasMessages(msgs, ElementKey.Named(ElementKind.Stair, "E1")));          // escalier NON OK
    }

    // ------------------------------------------------------------------ filtre global
    [Fact]
    public void Filter_SameLogicForAllFamilies()
    {
        var m = Model(); var o = Output();
        var msgs = new List<AppMessage> { Msg("Dalle", "Dalle D2") };
        var none = new SelectionFilterSpec();

        var slabsOnly = new ElementFilterSpec { Bars = false, Slabs = true };
        Assert.Equal(2, ElementFilter.Apply(m, o, msgs, none, slabsOnly).Count);

        var slabsNonOk = new ElementFilterSpec { Bars = false, Slabs = true, NonOkOnly = true };
        Assert.Equal(new[] { "D1" }, ElementFilter.Apply(m, o, msgs, none, slabsNonOk).Select(k => k.Name).ToArray());

        var slabsMsg = new ElementFilterSpec { Bars = false, Slabs = true, WithMessagesOnly = true };
        Assert.Equal(new[] { "D2" }, ElementFilter.Apply(m, o, msgs, none, slabsMsg).Select(k => k.Name).ToArray());

        var mixed = new ElementFilterSpec { Bars = true, Slabs = true, Stairs = true, Walls = true };
        var all = ElementFilter.Apply(m, o, msgs, none, mixed);
        Assert.Equal(2 + 2 + 1 + 1, all.Count);                                                           // 2 barres, 2 dalles, 1 escalier, 1 voile

        var hiddenD1 = ElementFilter.Apply(m, o, msgs, none, slabsOnly, k => k.Name == "D1");
        Assert.Equal(new[] { "D2" }, hiddenD1.Select(k => k.Name).ToArray());                             // les éléments masqués sont ignorés

        var restrict = ElementFilter.Apply(m, o, msgs, none, slabsOnly, null, new[] { ElementKey.Named(ElementKind.Slab, "D2") });
        Assert.Equal(new[] { "D2" }, restrict.Select(k => k.Name).ToArray());
    }

    [Fact]
    public void Filter_NonOkAcrossFamilies_AndWithMessages()
    {
        var m = Model(); var o = Output();
        var bad = ElementFilter.NonOk(m, o);
        Assert.Contains(ElementKey.Named(ElementKind.Slab, "D1"), bad);
        Assert.Contains(ElementKey.Named(ElementKind.Stair, "E1"), bad);
        Assert.DoesNotContain(ElementKey.Named(ElementKind.Wall, "V1"), bad);
        Assert.Empty(ElementFilter.NonOk(m, null));
        var msgs = new List<AppMessage> { Msg("Coque", "Coque VM1"), Msg("Nœud", "Nœud 2", node: 2) };
        var with = ElementFilter.WithMessages(m, null, msgs);
        Assert.Equal(2, with.Count);
    }

    [Fact]
    public void Plancher_nervure_sans_emprise_est_signale_non_cliquable()
    {
        var m = Model();
        var k = ElementKey.Named(ElementKind.Ribbed, "PL1");
        Assert.True(ElementCatalog.IsUnpickable(m, k));
        m.RibbedFloors[0].X0 = 0; m.RibbedFloors[0].Y0 = 0; m.RibbedFloors[0].X1 = 5; m.RibbedFloors[0].Y1 = 4;
        Assert.False(ElementCatalog.IsUnpickable(m, k));
        Assert.Equal("Plancher nervuré non sélectionnable : emprise non définie.", ElementCatalog.RibbedNoFootprint);
    }
}
