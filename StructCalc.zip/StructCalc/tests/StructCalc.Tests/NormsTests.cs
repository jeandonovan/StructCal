using StructCalc.Core;
using StructCalc.Core.Codes.CM66;
using StructCalc.Core.Codes.EC2;
using StructCalc.Core.Codes.EC3;
using StructCalc.Core.Codes.RPA99;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine;
using Xunit;

public class NormsTests
{
    [Fact]
    public void All_Norms_Registered_And_Implemented()
    {
        foreach (var id in new[] { "BAEL91", "CBA93", "EC2", "RPA99", "EC8", "CM66", "EC3", "EC3ENV" })
            Assert.True(DesignCodeRegistry.Get(id).IsImplemented, id);
    }

    [Fact]
    public void Catalog_IPE300_Properties()
    {
        var p = SteelCatalog.Get("IPE300");
        Assert.InRange(p.AreaMm2 / 100.0, 53.0, 54.5);          // 53,8 cm²
        Assert.InRange(p.IyMm4 / 1e4, 8250, 8450);              // 8356 cm⁴
        Assert.InRange(p.WplYMm3 / 1e3, 620, 636);              // 628 cm³
    }

    [Fact]
    public void Ec2_Beam_Flexure_Reference()
    {
        // 25x50, d=0.45, C25, fyk 500, MEd=100 kN.m : As ~ 5,45 cm²
        var r = new Ec2Code().DesignBeamFlexure(new RcRectSection(0.25, 0.50, 0.05, 0.05), 25, 500, 100, 70, CrackingClass.PeuPrejudiciable);
        Assert.InRange(r.Values["As_ELU_cm2"], 5.2, 5.7);
    }

    [Fact]
    public void Ec2_Shear_Gives_Stirrups()
    {
        var r = new Ec2Code().DesignBeamShear(new RcRectSection(0.25, 0.50, 0.05, 0.05), 25, 500, 120, CrackingClass.PeuPrejudiciable);
        Assert.True(r.Ok);
        Assert.True(r.Values["At_over_st_cm2_per_m"] > 0);
    }

    [Fact]
    public void Rpa_Column_Respects_Minimum_Percentage()
    {
        var code = new Rpa99Code { Zone = "III" };
        var r = code.DesignColumn(new ColumnInput(0.40, 0.40, 2.5, 25, 500, 600, 20, 0, 0.04, LimitState.Accidental));
        Assert.True(r.Values["As_cm2"] >= 0.009 * 0.16 * 1e4 - 1e-6);
    }

    [Fact]
    public void Ec3_Beam_Bending_Utilization_Reasonable()
    {
        // IPE300 S275, L=5 m, My=100 kN.m, V=80 kN : taux < 1
        var inp = new SteelInput(SteelCatalog.Get("IPE300"), 275, 5, 5, 5, 5, 0, 100, 0, 0, 80, 0, true);
        var r = new Ec3Code().CheckMember(inp);
        Assert.True(r.Ok);
        Assert.InRange(r.Values["util"], 0.2, 1.0);
    }

    [Fact]
    public void Ec3_Overloaded_Fails_And_Cm66_Runs()
    {
        var inp = new SteelInput(SteelCatalog.Get("IPE200"), 275, 6, 6, 6, 6, 0, 150, 0, 0, 100, 0, true);
        Assert.False(new Ec3Code().CheckMember(inp).Ok);
        Assert.True(new Cm66Code().CheckMember(inp with { MyKNm = 40 }).Values["util"] > 0);
    }

    [Fact]
    public void Seismic_Rpa_Spectrum_And_Loads()
    {
        double eta = Math.Sqrt(7.0 / 9.0);
        Assert.Equal(2.5 * eta, SeismicLoads.RpaD(0.3, "S3", 7), 6);
        var m = ExampleModels.Portal();
        m.Seismic.Enabled = true;
        var s = SeismicLoads.Compute(m);
        Assert.True(s.BaseShear > 0);
        Assert.NotEmpty(s.Loads);
        Assert.Equal(s.BaseShear, s.Loads.Sum(l => l.Fx), 3);
    }

    [Fact]
    public void Portal_With_Seismic_RPA_Runs()
    {
        var m = ExampleModels.Portal();
        m.RcCodeId = "RPA99";
        m.Seismic.Enabled = true;
        var o = ProjectAnalyzer.Run(m, optimize: true);
        Assert.All(o.Members, r => Assert.False(r.Skipped));
    }

    [Fact]
    public void Steel_Portal_EC3_Runs()
    {
        var m = ExampleModels.SteelPortal();
        var o = ProjectAnalyzer.Run(m, optimize: true);
        Assert.Equal(3, o.Members.Count);
        Assert.All(o.Members, r => Assert.False(r.Skipped));
        Assert.True(o.Members.All(r => r.Ok), string.Join(" | ", o.Members.Select(r => r.Profile + " " + r.Utilization.ToString("F2"))));
    }

    [Fact]
    public void Mixed_Model_Routes_By_Material()
    {
        var m = ExampleModels.SteelPortal();
        m.Members[1].Kind = MaterialKind.ReinforcedConcrete; m.Members[1].B = 0.30; m.Members[1].H = 0.60;
        var o = ProjectAnalyzer.Run(m, optimize: false);
        Assert.Equal(MaterialKind.ReinforcedConcrete, o.Members.First(r => r.MemberId == 2).Kind);
        Assert.Equal(MaterialKind.Steel, o.Members.First(r => r.MemberId == 1).Kind);
    }

    [Fact]
    public void Ec3Env_BetaM_And_Check()
    {
        Assert.Equal(1.8 - 0.7 * 0.5, StructCalc.Core.Codes.EC3.Ec3EnvCode.BetaM(0.5, 0, 0, false), 6);
        var inp = new SteelInput(SteelCatalog.Get("HEA240"), 275, 4, 4, 4, 4, 300, 40, 0, 0, 20, 0.5, false);
        var r = new StructCalc.Core.Codes.EC3.Ec3EnvCode().CheckMember(inp);
        Assert.True(r.Ok);
        Assert.InRange(r.Values["util"], 0.1, 1.0);
    }

    // Valeurs de référence publiées (exemples de calcul CM66, sigma_e = 240 ou 235 MPa)
    [Fact]
    public void Cm66_K_Matches_Published_Values()
    {
        Assert.InRange(Cm66Code.K(114, 240), 2.29, 2.32);
        Assert.InRange(Cm66Code.K(172.5, 240), 4.74, 4.77);
        Assert.InRange(Cm66Code.K(96.12, 240), 1.77, 1.82);
        Assert.InRange(Cm66Code.K(132.3, 235), 2.87, 2.92);
    }

    [Fact]
    public void Cm66_SigmaD_Matches_Published_Example()
    {
        // IPE120 : Ix=317.8, Iy=27.67, J=1.71 cm4, h=12, L=250 cm, B=1, C=1.132 -> sigma_d = 11.53 daN/mm2
        double D = Cm66Code.CoefD(1.71, 27.67, 12, 250);
        Assert.InRange(D, 2.26, 2.29);
        Assert.InRange(Cm66Code.SigmaD(27.67, 317.8, 1.71, 12, 250, 1.0, 1.132, D), 113.0, 118.0);
        // IPE180, L=10.5 m, charge en fibre supérieure : B = 0.914 pour D = 5.12 et C = 1.132
        Assert.InRange(Cm66Code.CoefB(1.0, 1.132, 5.12), 0.90, 0.93);
    }

    [Fact]
    public void EffectiveLength_Portal_Is_Reasonable()
    {
        var m = ExampleModels.SteelPortal();
        double sway = EffectiveLengths.Ratio(m, m.Members[0], true, true);
        double braced = EffectiveLengths.Ratio(m, m.Members[0], true, false);
        Assert.InRange(sway, 1.0, 10.0);
        Assert.InRange(braced, 0.5, 1.0);
    }
}
