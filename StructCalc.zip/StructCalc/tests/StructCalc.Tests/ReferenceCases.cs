using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Cas de référence : solutions analytiques classiques (résistance des matériaux, dynamique des structures).
/// Ils servent de garde-fou à chaque modification du solveur.</summary>
public class ReferenceCases
{
    private static StructModel Empty() => new StructModel { IncludeSelfWeight = false, Fc28 = 25 };

    private static void Rel(double expected, double actual, double tol)
        => Assert.True(Math.Abs(actual - expected) <= tol * Math.Abs(expected), $"attendu {expected}, obtenu {actual} (tolérance {tol * 100:0.#} %)");

    [Fact]
    public void ContinuousBeam_TwoEqualSpans_UDL()
    {
        double L = 5, w = 20;
        var m = Empty();
        for (int i = 0; i < 3; i++) m.Nodes.Add(new Node { Id = i + 1, X = i * L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = 0.3, H = 0.5 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, B = 0.3, H = 0.5 });
        m.Supports.Add(new SupportDef { NodeId = 1, Rx = true, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 2, Ux = false, Rx = false, Ry = false, Rz = false });
        m.Supports.Add(new SupportDef { NodeId = 3, Ux = false, Rx = false, Ry = false, Rz = false });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -w });
        m.MemberLoads.Add(new MemberLoad { MemberId = 2, Case = ActionType.Q, Wz = -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        Rel(3 * w * L / 8, r.Reactions[1][2], 1e-6);
        Rel(5 * w * L / 4, r.Reactions[2][2], 1e-6);
        Rel(3 * w * L / 8, r.Reactions[3][2], 1e-6);
        // moment sur l'appui central : wL²/8 (valeur absolue)
        var st = r.Members[1];
        Rel(w * L * L / 8, Math.Abs(st[st.Length - 1].My), 1e-5);
    }

    [Fact]
    public void Cantilever_UDL_TipDeflection_And_RootMoment()
    {
        double L = 3.5, w = 15, b = 0.3, h = 0.45;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, B = b, H = h });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.Q, Wz = -w });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double EI = m.EcKNm2 * b * h * h * h / 12.0;
        Rel(-w * Math.Pow(L, 4) / (8 * EI), r.NodeDisp[2][2], 1e-6);
        Rel(w * L * L / 2, Math.Abs(r.Reactions[1][4]), 1e-6);
        Rel(w * L, r.Reactions[1][2], 1e-6);
    }

    private static StructModel Portal(double h, double L, double H)
    {
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = h });
        m.Nodes.Add(new Node { Id = 3, X = L, Y = 0, Z = h });
        m.Nodes.Add(new Node { Id = 4, X = L, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.4, H = 0.3 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, Type = MemberType.Beam, B = 0.3, H = 0.6 });
        m.Members.Add(new Member { Id = 3, NodeI = 4, NodeJ = 3, Type = MemberType.Column, B = 0.4, H = 0.3 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 4 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.W, Fx = H });
        return m;
    }

    /// <summary>Portique à pieds encastrés sous charge horizontale H en tête : Δ = H h² (2a+b) / (2a (3a+6b)) avec a = 2EIc/h, b = 6EIb/L.</summary>
    [Fact]
    public void FixedBasePortal_LateralDrift()
    {
        double h = 4, L = 6, H = 100;
        var m = Portal(h, L, H);
        var r = FrameSolver.Solve(m, ActionType.W);
        double E = m.EcKNm2, Ic = 0.0016, Ib = 0.0054;
        double a = 2 * E * Ic / h, b = 6 * E * Ib / L;
        double expected = H * h * h * (2 * a + b) / (2 * a * (3 * a + 6 * b));
        double avg = (r.NodeDisp[2][0] + r.NodeDisp[3][0]) / 2;
        Rel(expected, avg, 0.015);
        // équilibre horizontal
        Assert.Equal(-H, r.Reactions[1][0] + r.Reactions[4][0], 5);
    }

    /// <summary>Portique à 2 niveaux, poutres très rigides : bâtiment à planchers rigides (shear building).</summary>
    [Fact]
    public void TwoStoreyFrame_Periods_MatchShearBuilding()
    {
        double h = 3, L = 6, W = 100;
        var m = Empty();
        int id = 1;
        foreach (double z in new[] { 0.0, h, 2 * h })
            foreach (double x in new[] { 0.0, L }) m.Nodes.Add(new Node { Id = id++, X = x, Y = 0, Z = z });
        // nœuds : 1,2 (z=0) ; 3,4 (z=h) ; 5,6 (z=2h)
        int mid = 1;
        void Col(int a, int b) => m.Members.Add(new Member { Id = mid++, NodeI = a, NodeJ = b, Type = MemberType.Column, B = 0.4, H = 0.3 });
        void Beam(int a, int b) => m.Members.Add(new Member { Id = mid++, NodeI = a, NodeJ = b, Type = MemberType.Beam, B = 0.3, H = 2.5 });
        Col(1, 3); Col(2, 4); Col(3, 5); Col(4, 6); Beam(3, 4); Beam(5, 6);
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 2 });
        foreach (int n in new[] { 3, 4, 5, 6 }) m.NodalLoads.Add(new NodalLoad { NodeId = n, Case = ActionType.G, Fz = -W });

        // shear building : k = 2 x 12 E Ic / h³ par niveau, masses m1 = m2 = 2W/g
        double E = m.EcKNm2, Ic = 0.0016;
        double k = 2 * 12 * E * Ic / (h * h * h), mm = 2 * W / 9.81;
        double s5 = Math.Sqrt(5);
        double w1 = Math.Sqrt(k / mm * (3 - s5) / 2), w2 = Math.Sqrt(k / mm * (3 + s5) / 2);
        double t1 = 2 * Math.PI / w1, t2 = 2 * Math.PI / w2;

        var modal = ModalAnalysis.Compute(m, 6);
        var xs = modal.Modes.Where(x => x.RatioX > 0.05).OrderByDescending(x => x.Period).ToList();
        Assert.True(xs.Count >= 2, "deux modes dominants en X attendus");
        Rel(t1, xs[0].Period, 0.03);
        Rel(t2, xs[1].Period, 0.03);
        Assert.True(modal.CumulX > 0.95);
    }

    /// <summary>Poteau à une seule masse : V = ψ·W·Sd(T)/g (EC8), un seul mode suffit.</summary>
    [Fact]
    public void SingleMass_Ec8ResponseSpectrum_BaseShear()
    {
        double L = 4, b = 0.3, h = 0.5, W = 500;
        var m = Empty();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = L });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = b, H = h });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.G, Fz = -W });
        m.Seismic.Enabled = true; m.Seismic.Norm = "EC8"; m.Seismic.Direction = SeismicDirection.X;
        m.Seismic.AgOverG = 0.2; m.Seismic.Ground = "B"; m.Seismic.BehaviorQ = 3.0; m.Seismic.ImportanceGamma = 1.0; m.Seismic.PsiE = 1.0;

        var modal = ModalAnalysis.Compute(m, 4);
        var rs = ResponseSpectrum.Compute(m, modal, 0);
        Assert.NotNull(rs);
        var mx = modal.Modes.First(x => x.RatioX > 0.9);
        double expected = W * SeismicLoads.Ec8Sd(mx.Period, 0.2, "B", 3.0);
        Rel(expected, rs!.VDynamic, 1e-6);
        Rel(expected, Math.Abs(rs.Case.Reactions[1][0]), 1e-4);
    }

    /// <summary>RPA 99 art. 4.3.6 : l'effort tranchant dynamique retenu ne peut être inférieur à 0,8 V statique.</summary>
    [Fact]
    public void Rpa_ResponseSpectrum_RespectsEightyPercentRule()
    {
        var m = ExampleModels.Portal();
        m.Seismic.Enabled = true; m.Seismic.Norm = "RPA99";
        var st = SeismicLoads.Compute(m);
        var modal = ModalAnalysis.Compute(m, 15);
        var rs = ResponseSpectrum.Compute(m, modal, st.BaseShear);
        Assert.NotNull(rs);
        Assert.True(rs!.VFinal >= 0.8 * st.BaseShear - 1e-6);
        Assert.True(rs.ModesUsed >= 1);
        // l'analyse complète avec le spectre doit se dérouler et fournir des efforts sismiques
        m.Seismic.UseResponseSpectrum = true;
        var o = ProjectAnalyzer.Run(m);
        Assert.Contains(o.Extras, x => x.Title.StartsWith("Analyse modale spectrale"));
    }

    /// <summary>Grand bâtiment (solveur en bande) : équilibre global et temps de calcul raisonnable.</summary>
    [Fact]
    public void LargeBuilding_BandedSolver_EquilibriumAndSpeed()
    {
        var m = FrameGenerator.Generate(new FrameSpec { BaysX = 6, BaysY = 6, Storeys = 8, SpanX = 5, SpanY = 5, StoreyHeight = 3.2, G = 15, Q = 5 });
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var r = FrameSolver.Solve(m, ActionType.G);
        sw.Stop();
        Assert.True(sw.Elapsed.TotalSeconds < 60, $"trop lent : {sw.Elapsed.TotalSeconds:0.0} s");
        double rz = r.Reactions.Values.Sum(v => v[2]);
        Assert.True(rz > 0);
        Assert.Equal(0.0, r.Reactions.Values.Sum(v => v[0]), 3);
        Assert.Equal(0.0, r.Reactions.Values.Sum(v => v[1]), 3);
    }
}
