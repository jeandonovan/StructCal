using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Solutions de dimensionnement des alertes NON OK et liste unique des messages.</summary>
public class DesignFixesTests
{
    /// <summary>Portique à une travée de 6 m : poutre 20 x 30 cm très chargée (barre 3), poteaux 40 x 40 cm.</summary>
    private static StructModel OverloadedBeam()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 6, Y = 0, Z = 3 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 4, X = 6, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 3, NodeJ = 1, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Members.Add(new Member { Id = 2, NodeI = 4, NodeJ = 2, Type = MemberType.Column, B = 0.4, H = 0.4 });
        m.Members.Add(new Member { Id = 3, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.2, H = 0.3 });
        m.Supports.Add(new SupportDef { NodeId = 3 }); m.Supports.Add(new SupportDef { NodeId = 4 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 3, Case = ActionType.G, Wz = -40 });
        return m;
    }

    [Fact]
    public void OverloadedBeam_IsNonOk_AndGetsLaddersOfSolutions()
    {
        var m = OverloadedBeam();
        var o = ProjectAnalyzer.Run(m, false, 1);
        var r = o.Members.First(x => x.MemberId == 3);
        Assert.False(r.Ok);
        var (t, opts) = DesignFixes.ForMember(m, o, 3);
        Assert.False(t.BeforeOk);
        Assert.True(t.HasUtil);
        Assert.Contains("Poutre 3", t.Detail);
        var h = Assert.Single(opts, x => x.Id == "H");
        Assert.Equal("h : 30 → 35 cm", h.Steps[0].Text);
        Assert.Contains(opts, x => x.Id == "B");
        Assert.Contains(opts, x => x.Id == "FC");          // béton 25 -> 30
        Assert.Contains(opts, x => x.Id == "OPTIM");
        Assert.Contains(opts, x => x.Id == "BARS");
    }

    [Fact]
    public void Evaluate_RecomputesOnACopy_AndNeverTouchesTheModel()
    {
        var m = OverloadedBeam();
        var o = ProjectAnalyzer.Run(m, false, 1);
        var (t, opts) = DesignFixes.ForMember(m, o, 3);
        var h = opts.First(x => x.Id == "H");
        string json = ModelIO.ToJson(m);
        DesignFixes.Evaluate(json, h, t, DesignFixes.NonOkCount(o), CancellationToken.None);
        Assert.True(h.Computed);
        Assert.True(h.Chosen >= 0);
        Assert.True(h.After <= t.Before + 1e-9);            // une section plus haute ne peut pas augmenter le taux
        Assert.Equal(0.30, m.Members.First(x => x.Id == 3).H, 6);          // le modèle de l'utilisateur est intact
        Assert.Equal(json, ModelIO.ToJson(m));
        if (h.Reached)
        {
            h.Step!.Apply(m);
            var o2 = ProjectAnalyzer.Run(m, false, 1);
            Assert.True(o2.Members.First(x => x.MemberId == 3).Ok);        // la solution annoncée « vérifiée » l'est vraiment une fois appliquée
        }
    }

    [Fact]
    public void Evaluate_CanBeCancelled()
    {
        var m = OverloadedBeam();
        var o = ProjectAnalyzer.Run(m, false, 1);
        var (t, opts) = DesignFixes.ForMember(m, o, 3);
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        Assert.ThrowsAny<OperationCanceledException>(() => DesignFixes.Evaluate(ModelIO.ToJson(m), opts[0], t, 1, cts.Token));
    }

    [Fact]
    public void CustomSection_IsOneStepWithTheTypedDimensions()
    {
        var m = OverloadedBeam();
        var f = DesignFixes.CustomSection(m, 3, 30, 60);
        var step = Assert.Single(f.Steps);
        var copy = ModelIO.FromJson(ModelIO.ToJson(m));
        step.Apply(copy);
        var b = copy.Members.First(x => x.Id == 3);
        Assert.Equal(0.30, b.B, 6); Assert.Equal(0.60, b.H, 6);
    }

    [Fact]
    public void CriticalCombination_NamesTheGoverningCombos()
    {
        var m = OverloadedBeam();
        var o = ProjectAnalyzer.Run(m, false, 1);
        var c = DesignFixes.Critical(o, 3);
        Assert.Contains("Barre 3", c.Text);
        Assert.NotEqual("", c.MomentCombo);
    }

    [Fact]
    public void Messages_AreClassedByFamily_AndModelErrorsBlock()
    {
        var m = OverloadedBeam();
        m.Supports.Clear();
        var issues = ModelChecker.Check(m);
        var list = MessageCenter.Build(m, null, issues, new[] { "Un conseil" }, new[] { "Envoi à Revit impossible : x", "Dalle D1 dessinée" });
        var ns = Assert.Single(list, x => x.Key.StartsWith("NO_SUPPORT|"));
        Assert.Equal(MsgFamily.Modele, ns.Family); Assert.True(ns.Blocking); Assert.Equal("Erreur bloquante", ns.LevelText);
        var rv = Assert.Single(list, x => x.Text.StartsWith("Envoi à Revit"));
        Assert.Equal(MsgSource.Revit, rv.Source); Assert.Equal(MsgFamily.Information, rv.Family);
        var jr = Assert.Single(list, x => x.Text == "Dalle D1 dessinée");
        Assert.Equal(MsgSource.Journal, jr.Source); Assert.Equal(IssueLevel.Info, jr.Level);
        Assert.Contains(list, x => x.Text == "Un conseil" && x.Family == MsgFamily.Information);
    }

    [Fact]
    public void Messages_FromACalculation_CarryTheDesignAlertAndItsElement()
    {
        var m = OverloadedBeam();
        var o = ProjectAnalyzer.Run(m, false, 1);
        var list = MessageCenter.Build(m, o, ModelChecker.Check(m), Array.Empty<string>(), Array.Empty<string>());
        var a = Assert.Single(list, x => x.Family == MsgFamily.Dimensionnement && x.Subject is MemberDesignResult && x.MemberId == 3 && x.Level == IssueLevel.Error);
        Assert.False(a.Blocking);
        Assert.Equal("Barre 3", a.ElementLabel);
        Assert.NotEqual("", a.Position);
        Assert.IsType<MemberDesignResult>(a.Subject);
        Assert.Contains("NON OK", a.Text);
    }

    [Fact]
    public void NonOkCount_CountsEveryKindOfAlert()
    {
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Ok = false });
        o.Members.Add(new MemberDesignResult { MemberId = 2, Ok = true });
        o.Members.Add(new MemberDesignResult { MemberId = 3, Ok = false, Skipped = true });
        var s = new DesignResult(); s.Fail("x"); o.Slabs.Add(s);
        o.Extras.Add(new ExtraDesign { Title = "Voile V1", Ok = false });
        Assert.Equal(3, DesignFixes.NonOkCount(o));
    }

    // ------------------------------------------------------------------ dalles, poinçonnement, semelles
    private static StructModel WithSlab()
    {
        var m = OverloadedBeam();
        m.Slabs.Add(new SlabPanel { Name = "D1", H = 0.16, Placed = true, X0 = 0, Y0 = 0, Z = 3, Lx = 6, Ly = 5 });
        return m;
    }

    [Fact]
    public void SlabSolutions_AreProposedOnly_AndStayWithinLimits()
    {
        var m = WithSlab();
        var cur = new AnalysisOutput();
        var bad = new DesignResult { Element = "Dalle D1 (4 x 5 m)" }; bad.Fail("flèche excessive");
        cur.Slabs.Add(bad);
        string before = ModelIO.ToJson(m);
        var (t, opts) = DesignFixes.ForSlab(m, cur, "D1");
        Assert.False(t.BeforeOk);
        Assert.False(t.HasUtil);                                   // dalle : OK / NON OK, pas de taux
        Assert.Contains("flèche excessive", t.Detail);              // la cause est affichée
        var th = Assert.Single(opts, x => x.Id == "SLABH");
        Assert.Equal("épaisseur : 16 → 18 cm", th.Steps[0].Text);
        Assert.All(th.Steps, st => { var c = ModelIO.FromJson(ModelIO.ToJson(m)); st.Apply(c); Assert.InRange(c.Slabs[0].H, 0.16, 0.40); });
        Assert.Equal(before, ModelIO.ToJson(m));                    // proposer ne modifie jamais le modèle
        Assert.Equal(0.16, m.Slabs[0].H, 6);
    }

    [Fact]
    public void PunchingSolutions_ApplyOnlyOnACopy_AndKeepTheTargetValues()
    {
        var m = WithSlab();
        var p = new PunchingResult { Column = "Poteau 1", Slab = "D1", Position = "intérieur", Rule = "EC2", VEd = 600, D = 0.13, U1 = 3.0, Beta = 1.15,
            StressEd = 1.8, StressRdc = 0.6, StressRdMax = 2.9, Util = 3.0, UtilMax = 0.62, NeedsShear = true, AswCm2 = 12, Ok = false };
        string before = ModelIO.ToJson(m);
        var (t, opts) = DesignFixes.ForPunching(m, new AnalysisOutput(), p);
        Assert.True(t.HasUtil); Assert.False(t.BeforeOk);
        Assert.Equal(3.0, t.Before, 6);                             // valeur calculée reprise telle quelle
        Assert.Contains("V_Ed = 600", t.Detail); Assert.Contains("v_Rd,c = 0,60", t.Detail.Replace('.', ','));
        Assert.Contains(opts, x => x.Id == "SLABH");
        Assert.Contains(opts, x => x.Id == "CAP");
        Assert.Contains(opts, x => x.Id == "SEC");
        var cap = opts.First(x => x.Id == "CAP");
        var copy = ModelIO.FromJson(before);
        cap.Steps[0].Apply(copy);
        Assert.True(copy.Slabs[0].CapitalSide > 0);
        Assert.Equal(0, m.Slabs[0].CapitalSide);                    // le modèle de l'utilisateur reste intact
        Assert.Equal(before, ModelIO.ToJson(m));
    }

    [Fact]
    public void FootingNonOk_HasNoAutomaticSolution_ButShowsItsCause()
    {
        var f = new DesignResult { Element = "Semelle S1" };
        f.Values["sigma_ser_kPa"] = 310; f.Fail("Contrainte du sol dépassée : 310 kPa > 200 kPa");
        var t = DesignFixes.ForFooting(f);
        Assert.False(t.BeforeOk);
        Assert.False(t.HasUtil);
        Assert.Contains("Contrainte du sol dépassée", t.Detail);
        Assert.Contains("sigma_ser_kPa = 310", t.Detail.Replace(',', '.'));
    }

    [Fact]
    public void NonOkMessages_StayVisibleAndAreLinkedToTheirElement()
    {
        var m = WithSlab();
        var o = new AnalysisOutput();
        var bad = new DesignResult { Element = "Dalle D1 (6 x 5 m)" }; bad.Fail("flèche excessive");
        o.Slabs.Add(bad);
        var list = MessageCenter.Build(m, o, ModelChecker.Check(m), Array.Empty<string>(), new[] { "ligne technique du journal" });
        var a = list.First(x => x.Family == MsgFamily.Dimensionnement && x.Text.Contains("flèche excessive"));
        Assert.False(a.Blocking);
        Assert.NotEqual(MsgSource.Journal, a.Source);
        Assert.Contains("D1", a.ElementLabel);
        Assert.Contains(list, x => x.Source == MsgSource.Journal);  // le journal reste séparé, jamais confondu avec une alerte
    }
}

public class NonOkReportTests
{
    [Fact]
    public void Report_CountsAndListsNonOkElementsByType_AndNeverShowsThemAsValidated()
    {
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Ok = false, Type = MemberType.Beam, Warnings = { "armatures impossibles" } });
        o.Members.Add(new MemberDesignResult { MemberId = 2, Ok = false, Type = MemberType.Column });
        o.Members.Add(new MemberDesignResult { MemberId = 3, Ok = true, Type = MemberType.Beam });
        var s = new DesignResult { Element = "Dalle D1 (4 x 5 m)" }; s.Fail("flèche excessive"); o.Slabs.Add(s);
        var f = new DesignResult { Element = "Semelle S1" }; f.Fail("contrainte du sol dépassée"); o.Footings.Add(f);
        o.Extras.Add(new ExtraDesign { Title = "Voile V1", Ok = false, Text = "NON OK : élancement" });
        var e = NonOkReport.Collect(o);
        Assert.Equal(5, e.Count);
        Assert.Equal(DesignFixes.NonOkCount(o), e.Count);
        var by = NonOkReport.ByType(e);
        Assert.Contains(("Poutre", 1), by); Assert.Contains(("Poteau", 1), by); Assert.Contains(("Dalle", 1), by);
        Assert.Contains(("Semelle", 1), by); Assert.Contains(("Voile", 1), by);
        Assert.False(o.AllOk);
        var html = NonOkReport.ToHtml(o);
        Assert.Contains("5 élément(s) NON OK", html);
        Assert.Contains("contrainte du sol dépassée", System.Net.WebUtility.HtmlDecode(html));   // le HTML encode les accents
        Assert.Contains("armatures impossibles", NonOkReport.ToText(o));
        Assert.DoesNotContain("aucun", NonOkReport.ToText(o));
    }

    [Fact]
    public void Report_WithoutNonOk_SaysSo()
    {
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Ok = true });
        Assert.Empty(NonOkReport.Collect(o));
        Assert.Contains("aucun", NonOkReport.ToText(o));
        Assert.True(o.AllOk);
    }
}

public class MessageStatusPersistenceTests
{
    [Fact]
    public void MessageStatuses_SurviveASaveAndReload_WithDateUserAndReason()
    {
        var m = new StructModel();
        m.MessageStatuses.Add(new MessageStatusRecord { Key = "DIM|Dalle|Dalle D1", Status = "Ignoré", Reason = "Flèche vérifiée par calcul séparé", User = "jean", Date = new DateTime(2026, 10, 16, 21, 0, 0), Text = "Dalle D1 NON OK" });
        m.MessageStatuses.Add(new MessageStatusRecord { Key = "X|y", Status = "Traité", User = "jean" });
        var back = ModelIO.FromJson(ModelIO.ToJson(m));
        Assert.Equal(2, back.MessageStatuses.Count);
        var r = back.MessageStatuses.First(x => x.Status == "Ignoré");
        Assert.Equal("Flèche vérifiée par calcul séparé", r.Reason);
        Assert.Equal("jean", r.User);
        Assert.Equal(new DateTime(2026, 10, 16, 21, 0, 0), r.Date);
        Assert.Equal("Dalle D1 NON OK", r.Text);
    }

    [Fact]
    public void OldProjects_WithoutStatuses_StillOpen()
    {
        var back = ModelIO.FromJson("{\"Name\":\"Ancien\"}");
        Assert.NotNull(back.MessageStatuses);
        Assert.Empty(back.MessageStatuses);
    }
}
