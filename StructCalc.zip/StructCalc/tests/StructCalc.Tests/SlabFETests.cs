using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Maillage et efforts des dalles (différences finies) comparés aux solutions classiques de plaques.</summary>
public class SlabFETests
{
    private static (StructModel M, SlabPanel S) Setup(SlabContinuity c, SlabCalcMode mode)
    {
        var m = new StructModel();
        var s = new SlabPanel { Name = "D1", Lx = 4, Ly = 4, H = 0.2, Gamma = 25, GExtra = 0, Q = 0, Placed = true, Continuity = c, CalcMode = mode, Z = 3 };
        m.Slabs.Add(s);
        return (m, s);
    }

    [Fact]
    public void SimplySupportedSquare_MatchesTimoshenko()
    {
        var (m, s) = Setup(SlabContinuity.Simple, SlabCalcMode.Bidirectional);
        var f = SlabFE.Solve(m, s);
        int c = f.Nx / 2;
        double p = f.PUls, L = 4;
        double mx = 0.0442 * p * L * L;                                              // ν = 0,2 (Timoshenko, 0,0479 pour ν = 0,3)
        Assert.InRange(f.Values[SlabFieldKind.Mx][c, c], mx * 0.94, mx * 1.06);
        double D = m.EcKNm2 * 0.008 / (12 * (1 - 0.04));
        double w = 0.00406 * f.PSer * Math.Pow(L, 4) / D * 1000;
        Assert.InRange(f.Values[SlabFieldKind.Deflection][c, c], w * 0.95, w * 1.05);
    }

    [Fact]
    public void ClampedSquare_CentreMomentSmallerThanSimple()
    {
        var (m1, s1) = Setup(SlabContinuity.Simple, SlabCalcMode.Bidirectional);
        var (m2, s2) = Setup(SlabContinuity.Interieure, SlabCalcMode.Bidirectional);
        var a = SlabFE.Solve(m1, s1); var b = SlabFE.Solve(m2, s2);
        int c = a.Nx / 2;
        Assert.True(b.Values[SlabFieldKind.Mx][c, c] < 0.6 * a.Values[SlabFieldKind.Mx][c, c]);
        Assert.True(b.Range(SlabFieldKind.Mx).Min < 0);                              // moment négatif sur appuis
        Assert.True(b.Range(SlabFieldKind.Deflection).Max < 0.5 * a.Range(SlabFieldKind.Deflection).Max);
    }

    [Fact]
    public void OneWaySimple_GivesQL2Over8()
    {
        var (m, s) = Setup(SlabContinuity.Simple, SlabCalcMode.OneWayX);
        var f = SlabFE.Solve(m, s);
        double expected = f.PUls * 16 / 8;
        Assert.InRange(f.Values[SlabFieldKind.Mx][f.Nx / 2, 3], expected * 0.97, expected * 1.03);
        Assert.Equal(0, f.Values[SlabFieldKind.My][f.Nx / 2, 3], 9);
    }

    [Fact]
    public void SolveAll_SkipsMassOnly_AndReportMentionsSlab()
    {
        var (m, s) = Setup(SlabContinuity.Simple, SlabCalcMode.Bidirectional);
        var s2 = new SlabPanel { Name = "D2", Lx = 3, Ly = 3, H = 0.15, Placed = true, CalcMode = SlabCalcMode.MassOnly };
        m.Slabs.Add(s2);
        var all = SlabFE.SolveAll(m);
        Assert.Single(all);
        Assert.Contains("Dalle D1", SlabFE.Report(all));
    }
}
