using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Sections;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>V3.27 : poinçonnement, voiles dans les zones d'influence, flexion biaxiale des poteaux, cotation automatique des plans.</summary>
public class V327Tests
{
    // ------------------------------------------------------------------ flexion biaxiale
    [Fact]
    public void BiaxialExponent_FollowsEc2Table()
    {
        Assert.Equal(1.0, BiaxialColumn.Exponent(0.05), 6);
        Assert.Equal(1.5, BiaxialColumn.Exponent(0.7), 6);
        Assert.Equal(2.0, BiaxialColumn.Exponent(1.2), 6);
        Assert.InRange(BiaxialColumn.Exponent(0.4), 1.1, 1.4);
    }

    [Fact]
    public void Biaxial_SquareColumn_IsSymmetric_AndWorseThanUniaxial()
    {
        var mat = new Mat { Fc = 25, Fe = 500 };
        var a = BiaxialColumn.Evaluate(0.40, 0.40, 30, 0.05, mat, 3.0, new[] { new BiaxialDemand(1000, 60, 100) });
        var b = BiaxialColumn.Evaluate(0.40, 0.40, 30, 0.05, mat, 3.0, new[] { new BiaxialDemand(1000, 100, 60) });
        Assert.Equal(a.Util, b.Util, 6);
        var uni = BiaxialColumn.Evaluate(0.40, 0.40, 30, 0.05, mat, 3.0, new[] { new BiaxialDemand(1000, 100, 0) });
        Assert.True(b.Util > uni.Util);
        Assert.True(a.MRdY > 0 && a.MRdZ > 0 && a.NRd > 1000);
    }

    [Fact]
    public void Biaxial_RequiredAs_GrowsWithSecondMoment()
    {
        var mat = new Mat { Fc = 25, Fe = 500 };
        double lo = BiaxialColumn.RequiredAs(0.40, 0.40, 8, 80, 0.05, mat, 3.0, new[] { new BiaxialDemand(1000, 100, 0) }, out var r1);
        double hi = BiaxialColumn.RequiredAs(0.40, 0.40, 8, 80, 0.05, mat, 3.0, new[] { new BiaxialDemand(1000, 100, 100) }, out var r2);
        Assert.True(r1.Ok && r2.Ok);
        Assert.True(hi > lo);
        Assert.True(r2.Util <= 1.0 + 1e-6);
    }

    [Fact]
    public void ColumnAssistant_Biaxial_AddsSteelAndReportsRatio()
    {
        var plane = ColumnSectionDesigner.Design(new ColumnSectionInput { B = 0.40, H = 0.40, Nu = 1200, Mu = 60, Lf = 3.0 });
        var dev = ColumnSectionDesigner.Design(new ColumnSectionInput { B = 0.40, H = 0.40, Nu = 1200, Mu = 60, MuZ = 60, Lf = 3.0 });
        Assert.True(plane.Ok, string.Join(" ; ", plane.Warnings));
        Assert.True(dev.Ok, string.Join(" ; ", dev.Warnings));
        Assert.True(dev.AsUsed >= plane.AsUsed);
        Assert.InRange(dev.BiaxUtil, 0.01, 1.0001);
        Assert.Contains("EC2 5.8.9", dev.Report);
        Assert.Equal(0.0, plane.BiaxUtil);
    }

    // ------------------------------------------------------------------ poinçonnement
    private static StructModel FlatSlab(double h = 0.20, string code = "EC2")
    {
        var m = new StructModel { RcCodeId = code };
        int id = 1;
        foreach (double y in new[] { 0.0, 4.0, 8.0 })
            foreach (double x in new[] { 0.0, 4.0, 8.0 })
            {
                m.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = 0 });
                m.Nodes.Add(new Node { Id = id + 100, X = x, Y = y, Z = 3 });
                m.Members.Add(new Member { Id = id, NodeI = id, NodeJ = id + 100, Type = MemberType.Column, B = 0.30, H = 0.30 });
                id++;
            }
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 8, Ly = 8, Z = 3, H = h, GExtra = 2, Q = 5, Kind = SlabKind.Pleine });
        return m;
    }

    [Fact]
    public void Punching_FlatSlab_ClassifiesSupports_AndLoads()
    {
        var m = FlatSlab();
        var r = Punching.Check(m);
        Assert.Equal(9, r.Count);
        Assert.Single(r, x => x.Position == "intérieur");
        Assert.Equal(4, r.Count(x => x.Position == "rive"));
        Assert.Equal(4, r.Count(x => x.Position == "angle"));
        var inner = r.Single(x => x.Position == "intérieur");
        double p = 1.35 * (25 * 0.20 + 2) + 1.5 * 5;
        Assert.Equal(p * 16, inner.VEd, 3);                              // zone d'influence 4 m x 4 m
        Assert.Equal(1.15, inner.Beta, 6);
        Assert.True(inner.U1 > 2 * (0.3 + 0.3));
    }

    [Fact]
    public void Punching_Capital_AddsTwoControlContours()
    {
        var plain = Punching.Check(FlatSlab(0.20)).Single(x => x.Position == "intérieur");
        var m = FlatSlab(0.20);
        m.Slabs[0].CapitalSide = 1.2; m.Slabs[0].CapitalExtraCm = 10;
        var r = Punching.Check(m).Where(x => x.Position == "intérieur").ToList();
        Assert.Equal(2, r.Count);
        Assert.Contains(r, x => x.Column.Contains("contour du chapiteau"));
        Assert.Contains(r, x => x.Column.Contains("sur le chapiteau"));
        Assert.True(r.Single(x => x.Column.Contains("contour du chapiteau")).Util < plain.Util);
    }

    [Fact]
    public void Punching_UsesRealSlabReinforcementRatio()
    {
        var m = FlatSlab(0.20);
        var plain = Punching.Check(m).Single(x => x.Position == "intérieur");
        var o = new StructCalc.Engine.AnalysisOutput();
        var dr = new DesignResult { Element = "Dalle D1 (8.00 x 8.00 m, h=20 cm)" };
        dr.Values["Asx_appui_cm2m"] = 2.0; dr.Values["Asy_appui_cm2m"] = 2.0;
        o.Slabs.Add(dr);
        var real = Punching.Check(m, o).Single(x => x.Position == "intérieur");
        Assert.Contains("√(ρlx ρly)", real.Text);
        Assert.True(real.Util > plain.Util);       // peu d'acier : vRd,c plus faible que celui de ρl = 0,5 %
    }

    [Fact]
    public void Punching_ThickerSlab_ReducesDemandRatio_AndBaelWorks()
    {
        double thin = Punching.Check(FlatSlab(0.14)).Single(x => x.Position == "intérieur").Util;
        double thick = Punching.Check(FlatSlab(0.30)).Single(x => x.Position == "intérieur").Util;
        Assert.True(thick < thin);
        var bael = Punching.Check(FlatSlab(0.20, "BAEL91")).Single(x => x.Position == "intérieur");
        Assert.Contains("BAEL", bael.Rule);
        Assert.True(bael.Util > 0);
    }

    [Fact]
    public void Punching_IgnoresColumnsWithBeams()
    {
        var m = FlatSlab();
        m.Members.Add(new Member { Id = 50, NodeI = 105, NodeJ = 106, Type = MemberType.Beam });       // poutre au centre (nœud 105) : appui par poutre
        var r = Punching.Check(m);
        Assert.Equal(7, r.Count);                                        // la poutre touche deux poteaux : leurs appuis ne sont plus directs
    }

    // ------------------------------------------------------------------ voiles
    [Fact]
    public void Wall_ReceivesSlabEdgeLoad_ByYieldLines()
    {
        var m = new StructModel();
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 8, Ly = 4, Z = 3, H = 0.16, GExtra = 1.5, Q = 2.5 });
        m.Walls.Add(new WallDef { Name = "V1", X = 0, Y = 0, Z = 0, AngleDeg = 0, LengthM = 8, HeightM = 3, ThicknessM = 0.2, GTopKnPerM = 5, QTopKnPerM = 1 });
        StoreyOps.SyncSlabLoads(m, m.Slabs[0]);
        var res = WallInfluence.Compute(m);
        var w = Assert.Single(res);
        Assert.Equal(12.0, w.AreaM2, 6);                                 // 2 triangles de 2 m² + rectangle 4 x 2 : 2 + 8 + 2
        Assert.Equal(12 * (25 * 0.16 + 1.5), w.GKn, 6);
        Assert.Equal(12 * 2.5, w.QKn, 6);
        Assert.Equal((1.35 * w.GKn + 1.5 * w.QKn) / 8, w.UluKnPerM, 6);
        var msgs = WallInfluence.Check(m);
        Assert.Contains(msgs, t => t.Contains("Voile V1") && t.Contains("ATTENTION"));    // charge de tête saisie trop faible
        Assert.True(WallInfluence.CarriedKn(m, ActionType.G) > 0);
    }

    [Fact]
    public void Wall_WithBeamOnEdge_TakesNothing_AndWrongLevelIgnored()
    {
        var m = new StructModel();
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 8, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam });
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 8, Ly = 4, Z = 3, H = 0.16 });
        m.Walls.Add(new WallDef { Name = "V1", X = 0, Y = 0, Z = 0, LengthM = 8, HeightM = 3 });
        StoreyOps.SyncSlabLoads(m, m.Slabs[0]);
        Assert.Empty(WallInfluence.Compute(m));                           // le bord est déjà porté par la poutre
        m.Members.Clear();
        m.Walls[0].Z = 1;                                                 // tête à 4 m : pas au niveau de la dalle
        Assert.Empty(WallInfluence.Compute(m));
    }

    // ------------------------------------------------------------------ plans cotés
    [Fact]
    public void GeneratedElevation_HasAutomaticDimensions()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, true);
        var sheets = DrawingGenerator.Generate(m, o, licensed: true);
        var elev = sheets.First(s => s.Name == "Elevation");
        var dims = elev.Items.Where(e => e.Layer == "COTES" && e.Kind == EntKind.Text && e.Text.Length > 0 && char.IsDigit(e.Text[0])).ToList();
        Assert.True(dims.Count >= 2, "entraxes et hauteurs attendus");
    }
}
