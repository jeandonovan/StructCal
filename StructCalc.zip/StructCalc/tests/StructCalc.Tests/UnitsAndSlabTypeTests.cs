using StructCalc.Core;
using StructCalc.Engine.Drawing;
using Xunit;

namespace StructCalc.Tests;

public class UnitsAndSlabTypeTests
{
    [Fact]
    public void Units_Conversions()
    {
        try
        {
            Units.Set("m", "cm", "kN", "MPa");
            Assert.Equal("4.50", Units.LenS(4.5));
            Assert.Equal("30", Units.SecS(0.30));
            Units.Set("cm", "mm", "daN", "bar");
            Assert.Equal(450.0, Units.Len(4.5), 6);
            Assert.Equal("300", Units.SecS(0.30));
            Assert.Equal(1000.0, Units.Frc(10), 6);
            Assert.Equal("daN.cm", Units.MomentUnit);
            Assert.Equal(10.0, Units.Str(1.0), 6);
            Units.Set("m", "cm", "tf", "kgf/cm²");
            Assert.Equal(1.0, Units.Frc(9.80665), 6);
            Assert.Equal("tf/m", Units.LinearLoadUnit);
        }
        finally { Units.Set("m", "cm", "kN", "MPa"); }
    }

    [Fact]
    public void Units_ConverterRoundTrip()
    {
        try
        {
            Units.Set("cm", "cm", "kN", "MPa");
            double shown = 3.2 * Units.FactorOf("len");
            Assert.Equal(320.0, shown, 6);
            Assert.Equal(3.2, shown / Units.FactorOf("len"), 6);
        }
        finally { Units.Set("m", "cm", "kN", "MPa"); }
    }

    [Fact]
    public void BendShape_KindFromShapeText()
    {
        Assert.Equal(BendShape.Kind.HookBoth, BendShape.KindOf(new BarLine("P", "B1", 1, 2, 16, "droite + 2 crochets 90°", 4.5, "x")));
        Assert.Equal(BendShape.Kind.HookOne, BendShape.KindOf(new BarLine("P", "B1", 2, 2, 16, "droite + crochet 90°", 2.0, "x")));
        Assert.Equal(BendShape.Kind.Stirrup, BendShape.KindOf(new BarLine("P", "B1", 3, 20, 8, "cadre fermé, crochets 135°", 1.2, "x")));
        Assert.Equal(BendShape.Kind.Pin, BendShape.KindOf(new BarLine("P", "B1", 4, 20, 8, "épingle, 2 crochets 135°", 0.4, "x")));
        Assert.Equal(BendShape.Kind.Straight, BendShape.KindOf(new BarLine("P", "B1", 5, 2, 12, "droite", 3.0, "x")));
    }

    [Fact]
    public void BendingSheet_ListsShapes()
    {
        var bars = new List<BarLine>
        {
            new("Poutres", "B1", 1, 4, 16, "droite + 2 crochets 90°", 4.5, "Lit inférieur"),
            new("Poutres", "B1", 4, 30, 8, "cadre fermé, crochets 135°", 1.3, "Cadres") { DimA = 0.2, DimB = 0.4 },
        };
        var sheets = RcSheets.Bending(bars).ToList();
        Assert.Single(sheets);
        Assert.True(sheets[0].Items.Count > 15);
    }

    [Fact]
    public void SlabTypes_SixTypesTwoSheets()
    {
        var sheets = SlabTypeSheets.Build(new SlabTypeParams());
        Assert.Equal(2, sheets.Count);
        Assert.All(sheets, s => Assert.True(s.Items.Count > 100));
        var one = SlabTypeSheets.Build(new SlabTypeParams { Ribbed = false, Predalle = false, HollowCore = false, FlatSlab = false, Composite = false });
        Assert.Single(one);
    }
}
