using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

namespace StructCalc.Tests;

public class RevitExchangeTests
{
    [Fact]
    public void SheetExchange_RoundTrip_KeepsEntities()
    {
        var s = new Sheet { Name = "P1", Title = "Poutre P1", Number = "01", Width = 420, Height = 297 };
        s.Line(0, 0, 100, 50, "ARMATURES");
        s.Circle(10, 20, 5, "ARMATURES");
        s.Text(5, 5, 3.5, "HA16", "TEXTE", 90);
        string path = Path.Combine(Path.GetTempPath(), "sc_sheets_" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            SheetExchange.Save(new[] { s }, path);
            var back = SheetExchange.Load(path);
            Assert.Single(back);
            Assert.Equal("Poutre P1", back[0].Title);
            Assert.Equal(3, back[0].Items.Count);
            Assert.Equal("L", back[0].Items[0].K);
            Assert.Equal(100, back[0].Items[0].X2, 6);
            Assert.Equal("C", back[0].Items[1].K);
            Assert.Equal("T", back[0].Items[2].K);
            Assert.Equal("HA16", back[0].Items[2].T);
            Assert.Equal(90, back[0].Items[2].Rot, 6);
        }
        finally { File.Delete(path); }
    }

    [Fact]
    public void RevitSummary_Slab_CarriesBarsAndExternalId()
    {
        var m = new StructModel();
        m.Slabs.Add(new SlabPanel { Name = "D1", Lx = 4, Ly = 5, H = 0.16, ExternalId = "12345" });
        var o = new AnalysisOutput();
        var d = new DesignResult { Element = "Dalle D1 (4.00 x 5.00 m, h=16 cm)" };
        d.Texts["Travée sens lx"] = "HA10 e=15 cm (5.24 cm²/m)";
        d.Texts["Appui sens ly"] = "HA8 e=20 cm (2.51 cm²/m)";
        o.Slabs.Add(d);
        string path = Path.Combine(Path.GetTempPath(), "sc_sum_" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            ModelIO.SaveRevitSummary(o, path, m);
            var back = ModelIO.LoadRevitSummary(path);
            var s = Assert.Single(back);
            Assert.Equal("Slab", s.Type);
            Assert.Equal("12345", s.ExternalId);
            Assert.StartsWith("HA10 e=15", s.Extra["Travee_lx"]);
            Assert.StartsWith("HA8 e=20", s.Extra["Appui_ly"]);
            Assert.False(s.Extra.ContainsKey("Travee_ly"));
        }
        finally { File.Delete(path); }
    }
}

public class SoilPresetTests
{
    [Fact]
    public void Presets_AreIncreasing_AndMatchable()
    {
        var all = StructCalc.Core.Model.SoilPresets.All;
        Assert.True(all.Length >= 10);
        Assert.All(all, p => Assert.True(p.QAdmKPa > 0 && p.QAdmKPa <= 3000));
        Assert.NotNull(StructCalc.Core.Model.SoilPresets.Match(200));
        Assert.Null(StructCalc.Core.Model.SoilPresets.Match(237));
        for (int i = 1; i < all.Length; i++) Assert.True(all[i].QAdmKPa >= all[i - 1].QAdmKPa);
    }
}

public class NominalCoverTests
{
    [Fact]
    public void NominalCover_AxisIsRecomputedFromChosenBars()
    {
        var m = StructCalc.Engine.ExampleModels.Portal();
        m.Settings.CoverNomBeamCm = 2.5; m.Settings.CoverNomColumnCm = 2.5; m.Settings.SyncAxisCovers();
        StructCalc.Engine.SettingsApplier.ApplyCovers(m);
        var o = StructCalc.Engine.ProjectAnalyzer.Run(m, optimize: true);
        foreach (var r in o.Members.Where(x => !x.Skipped && x.StirDia > 0 && x.Kind == StructCalc.Core.MaterialKind.ReinforcedConcrete))
        {
            var mem = m.Members.First(x => x.Id == r.MemberId);
            double bar = Math.Max(r.BotDia, mem.Type == StructCalc.Core.Model.MemberType.Column ? 0 : r.TopDia);
            double expect = 0.025 + r.StirDia / 1000.0 + bar / 2000.0;
            Assert.Equal(expect, mem.Cover, 3);                                  // axe = enrobage nominal + cadre + demi-barre
            Assert.Contains(r.Notes, n => n.StartsWith("Enrobage nominal 2.5") || n.StartsWith("Enrobage nominal 2,5"));
        }
    }

    [Fact]
    public void SyncAxisCovers_UsesNominalPlusBars()
    {
        var s = new StructCalc.Core.DesignSettings { CoverNomBeamCm = 2.5, CoverNomFootingCm = 5 };
        s.SyncAxisCovers();
        Assert.Equal(4.1, s.CoverBeamCm, 6);
        Assert.Equal(5.6, s.CoverFootingCm, 6);
    }
}

public class FileFormatTests
{
    [Fact]
    public void ProjectInfo_RoundTrips()
    {
        var m = StructCalc.Engine.ExampleModels.Portal();
        m.Info.Client = "Société X"; m.Info.Revision = "B";
        string path = Path.Combine(Path.GetTempPath(), "sc_" + Guid.NewGuid().ToString("N") + StructCalc.Core.AppInfo.FileExt);
        try
        {
            StructCalc.Engine.ModelIO.Save(m, path);
            var back = StructCalc.Engine.ModelIO.Load(path);
            Assert.Equal("Société X", back.Info.Client);
            Assert.Equal("B", back.Info.Revision);
        }
        finally { if (File.Exists(path)) File.Delete(path); }
    }

    [Fact]
    public void Model_RoundTrips_WithStcxExtension()
    {
        var m = StructCalc.Engine.ExampleModels.Portal();
        string path = Path.Combine(Path.GetTempPath(), "sc_" + Guid.NewGuid().ToString("N") + StructCalc.Core.AppInfo.FileExt);
        try
        {
            StructCalc.Engine.ModelIO.Save(m, path);
            var back = StructCalc.Engine.ModelIO.Load(path);
            Assert.Equal(m.Members.Count, back.Members.Count);
            Assert.Equal(".stcx", StructCalc.Core.AppInfo.FileExt);
        }
        finally { File.Delete(path); }
    }
}
