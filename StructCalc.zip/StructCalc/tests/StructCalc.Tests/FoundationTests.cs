using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Walls;
using Xunit;

/// <summary>Radier, mur de soutènement : calcul de base et cohérence des résultats.</summary>
public class FoundationTests
{
    private static SoilProfile Soil()
    {
        var s = new SoilProfile();
        s.Layers.Add(new SoilLayer { Name = "Sable", PhiDeg = 32, CKPa = 0, GammaKnM3 = 18, GammaSatKnM3 = 20, EoedMPa = 30 });
        return s;
    }

    private static RaftDef Raft()
    {
        var r = new RaftDef { Name = "R1", ZTop = -1.2, H = 0.50 };
        r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 10, Ly = 10 });
        return r;
    }

    private static List<RaftLoad> Cols(params (double X, double Y)[] p) =>
        p.Select((q, i) => new RaftLoad { Name = "N" + (i + 1), X = q.X, Y = q.Y, Nu = 1200, Ns = 900, A = 0.4, B = 0.4, Column = true }).ToList();

    [Fact]
    public void Raft_GivesFourNappes_AndAUniformPressure()
    {
        var res = RaftDesigner.Design(Raft(), Cols((2.5, 2.5), (7.5, 2.5), (2.5, 7.5), (7.5, 7.5)), Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings());
        Assert.Equal(4, res.Loads);
        foreach (var k in new[] { "Inf X", "Inf Y", "Sup X", "Sup Y" }) Assert.True(res.Design.Texts.ContainsKey(k) && res.Design.Texts[k].StartsWith("HA"), k);
        Assert.InRange(res.SigmaMax - res.SigmaMin, -1e-6, 1e-6);          // charges centrées : pression uniforme
        Assert.True(res.SigmaMax > 30 && res.SigmaMax < 80);
    }

    [Fact]
    public void Raft_EccentricLoads_GiveUnevenPressure()
    {
        var res = RaftDesigner.Design(Raft(), Cols((1, 1), (3, 1), (1, 3), (3, 3)), Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings());
        Assert.True(res.SigmaMax > res.SigmaMin + 10);
    }

    [Fact]
    public void Raft_ThinSlab_FailsPunching()
    {
        var r = Raft(); r.H = 0.20;
        var loads = Cols((2.5, 2.5), (7.5, 2.5), (2.5, 7.5), (7.5, 7.5));
        foreach (var l in loads) l.Nu = 3000;
        var res = RaftDesigner.Design(r, loads, Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings());
        Assert.False(res.Ok);
        Assert.True(res.HRequired > 0.20);
    }

    [Fact]
    public void Raft_WithoutLoads_IsNotOk()
    {
        var res = RaftDesigner.Design(Raft(), new List<RaftLoad>(), Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings());
        Assert.False(res.Ok);
    }

    [Fact]
    public void RetainingWall_IsLoadedByEarthPressure()
    {
        var code = new Bael91Code();
        var plain = new WallDef { Name = "V1", LengthM = 4, HeightM = 3, ThicknessM = 0.25, GTopKnPerM = 20, QTopKnPerM = 0, TopHeldOutOfPlane = false };
        var soil = new WallDef { Name = "V2", LengthM = 4, HeightM = 3, ThicknessM = 0.25, GTopKnPerM = 20, QTopKnPerM = 0, TopHeldOutOfPlane = false, Retaining = true, RetainedHeightM = 3 };
        var a = WallDesigner.Design(plain, code, 25, 500);
        var b = WallDesigner.Design(soil, code, 25, 500);
        Assert.Contains("poussée des terres", b.Report);
        Assert.True(b.MaxDispMm > a.MaxDispMm + 0.01);
    }

    [Fact]
    public void RaftContains_FollowsThePanels()
    {
        var r = new RaftDef();
        r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 5, Ly = 5 });
        Assert.True(RaftDesigner.Contains(r, 2, 2));
        Assert.False(RaftDesigner.Contains(r, 6, 2));
    }
}
