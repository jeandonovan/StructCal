using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Vérifications complémentaires : poinçonnement de rive du radier, stabilité d'un mur de soutènement, tassements différentiels.</summary>
public class AdvancedChecksTests
{
    private static SoilProfile Soil()
    {
        var s = new SoilProfile();
        s.Layers.Add(new SoilLayer { Name = "Sable", PhiDeg = 32, CKPa = 0, GammaKnM3 = 18, GammaSatKnM3 = 20, EoedMPa = 30 });
        return s;
    }

    private static double HReq(double x, double y)
    {
        var r = new RaftDef { Name = "R", ZTop = -1.2, H = 0.20 };
        r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 10, Ly = 10 });
        var l = new List<RaftLoad> { new() { Name = "N1", X = x, Y = y, Nu = 1200, Ns = 900, A = 0.4, B = 0.4, Column = true } };
        return RaftDesigner.Design(r, l, Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings()).HRequired;
    }

    [Fact]
    public void Raft_CornerColumn_NeedsMoreThickness_ThanInteriorColumn()
    {
        Assert.True(HReq(0.2, 0.2) > HReq(5, 5));
    }

    [Fact]
    public void RetainingWall_StabilityIsReported()
    {
        var m = new StructModel();
        m.Walls.Add(new WallDef { Name = "M1", X = 0, Y = 0, AngleDeg = 0, LengthM = 6, HeightM = 3, ThicknessM = 0.25, Retaining = true, RetainedHeightM = 3 });
        m.FootingDefs.Add(new FootingDef { Name = "F1", Kind = FootingKind.Filante, X0 = 0, Y0 = 0, AngleDeg = 0, LengthM = 6, FixedA = 1.0, ThicknessM = 0.4 });
        var o = new AnalysisOutput();
        AdvancedChecks.Run(m, o);
        var x = Assert.Single(o.Extras, e => e.Title == "Vérifications complémentaires");
        Assert.Contains("renversement", x.Text);
        Assert.False(x.Ok);                         // semelle de 1 m pour 3 m de terres : instable
    }

    [Fact]
    public void RetainingWall_WideFooting_IsStable()
    {
        var m = new StructModel();
        m.Walls.Add(new WallDef { Name = "M1", X = 0, Y = 0, AngleDeg = 0, LengthM = 6, HeightM = 2.5, ThicknessM = 0.30, Retaining = true, RetainedHeightM = 2, KEarth = 0.33 });   // Ka (mur libre) : avec K = 0,5 le glissement vaut 1,48 < 1,5
        m.FootingDefs.Add(new FootingDef { Name = "F1", Kind = FootingKind.Filante, X0 = 0, Y0 = 0, AngleDeg = 0, LengthM = 6, FixedA = 3.5, ThicknessM = 0.6 });
        var o = new AnalysisOutput();
        AdvancedChecks.Run(m, o);
        var x = Assert.Single(o.Extras);
        Assert.True(x.Ok);
    }
}
