using StructCalc.Engine;
using Xunit;

/// <summary>Ancrage, recouvrement et cintrage : valeurs calculées, limites, statuts.</summary>
public class RebarChecksTests
{
    [Fact]
    public void Anchorage_HA16_Fe500_Fc25_MatchesBaelFormula()
    {
        var (ls, tau, fsd) = RebarChecks.Anchorage(16, 500, 25);
        Assert.Equal(2.835, tau, 3);                      // 0,6 x 1,5² x (0,6 + 0,06 x 25)
        Assert.Equal(705.5, ls, 1);                       // 16 x 500 / (4 x 2,835)
        Assert.Equal(434.78, fsd, 2);                     // 500 / 1,15
        Assert.Equal(ls, RebarChecks.LapLength(16, 500, 25), 6);
    }

    [Fact]
    public void Anchorage_GrowsWithDiameterAndSteel_AndShrinksWithConcrete()
    {
        double a = RebarChecks.Anchorage(12, 500, 25).Ls, b = RebarChecks.Anchorage(20, 500, 25).Ls;
        Assert.True(b > a);
        Assert.True(RebarChecks.Anchorage(16, 500, 25).Ls > RebarChecks.Anchorage(16, 400, 25).Ls);
        Assert.True(RebarChecks.Anchorage(16, 500, 35).Ls < RebarChecks.Anchorage(16, 500, 25).Ls);
    }

    [Theory]
    [InlineData(800, 700, "Vérifiée")]
    [InlineData(700, 700, "Vérifiée")]
    [InlineData(650, 700, "À la limite")]      // >= 90 %
    [InlineData(600, 700, "Non vérifiée")]
    public void Verdict_Thresholds(double avail, double req, string expected) => Assert.Equal(expected, RebarChecks.Verdict(avail, req));

    [Fact]
    public void MinBendRadius_4Phi_Up_To_16_Then_7Phi()
    {
        Assert.Equal(32, RebarChecks.MinBendRadius(16), 6);   // mandrin 64 mm
        Assert.Equal(70, RebarChecks.MinBendRadius(20), 6);   // mandrin 140 mm
    }

    private static List<(double X, double Y, double Z)> LShape(double legMm) => new() { (0, 0, 0), (legMm, 0, 0), (legMm, 0, legMm) };

    [Fact]
    public void RightAngleBend_WithLongLegsAndGoodMandrel_IsCompliant()
    {
        var r = Assert.Single(RebarChecks.Bends(16, LShape(1000), (0, 0, -1), 64, 40, 25, false, true));
        Assert.Equal(90, r.AngleDeg, 3);
        Assert.Equal("Conforme", r.Status);
        Assert.True(r.StrBefore >= r.StrMin && r.StrAfter >= r.StrMin);
        Assert.Equal(80, r.StrMin, 6);                         // 5 phi
    }

    [Fact]
    public void Bend_WithTooSmallMandrel_IsNonCompliant()
    {
        var r = Assert.Single(RebarChecks.Bends(16, LShape(1000), (0, 0, -1), 40, 40, 25, false, true));
        Assert.Equal("Non conforme", r.Status);
        Assert.Contains("rayon 20 mm < 32 mm", r.Comment);
    }

    [Fact]
    public void Bend_WithTooShortStraightLeg_IsNonCompliant()
    {
        var r = Assert.Single(RebarChecks.Bends(16, LShape(100), (0, 0, -1), 64, 40, 25, false, true));
        Assert.Equal("Non conforme", r.Status);
        Assert.Contains("longueur droite", r.Comment);
    }

    [Fact]
    public void Bend_TooCloseToFace_IsNonCompliant()
    {
        var r = Assert.Single(RebarChecks.Bends(16, LShape(1000), (0, 0, -1), 64, 10, 25, false, true));
        Assert.Equal("Non conforme", r.Status);
        Assert.Contains("parement", r.Comment);
    }

    [Fact]
    public void TensionBarPushingOutward_NeedsTransverseSteel()
    {
        // pli dont l'intérieur regarde la face la plus proche (z < 0) : poussée au vide pour une barre tendue
        var poly = new List<(double X, double Y, double Z)> { (0, 0, 0), (1000, 0, 0), (1000, 0, -1000) };
        var without = Assert.Single(RebarChecks.Bends(16, poly, (0, 0, -1), 64, 40, 25, true, false));
        var with = Assert.Single(RebarChecks.Bends(16, poly, (0, 0, -1), 64, 40, 25, true, true));
        Assert.Equal("Non conforme", without.Status);
        Assert.NotEqual("Non conforme", with.Status);
    }

    [Fact]
    public void StraightBar_HasNoBend_AndUnknownMandrelIsOnlyToCheck()
    {
        Assert.Empty(RebarChecks.Bends(16, new List<(double, double, double)> { (0, 0, 0), (1000, 0, 0) }, (0, 0, -1), 64, 40, 25, false, true));
        var r = Assert.Single(RebarChecks.Bends(16, LShape(1000), (0, 0, -1), 0, 40, 25, false, true));
        Assert.Equal("À vérifier", r.Status);
    }
}
