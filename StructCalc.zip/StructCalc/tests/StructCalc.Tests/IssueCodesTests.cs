using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Messages de vérification : chaque message porte un code et l'objet visé, pour que l'interface sélectionne l'élément et propose une correction.</summary>
public class IssueCodesTests
{
    private static StructModel Ring()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        double[,] p = { { 0, 0 }, { 5, 0 }, { 5, 5 }, { 0, 5 } };
        for (int i = 0; i < 4; i++) m.Nodes.Add(new Node { Id = i + 1, X = p[i, 0], Y = p[i, 1], Z = 3 });
        for (int i = 0; i < 4; i++) m.Members.Add(new Member { Id = i + 1, NodeI = i + 1, NodeJ = (i + 1) % 4 + 1, Type = MemberType.Beam, B = 0.30, H = 0.50 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        return m;
    }

    [Fact]
    public void OrphanMemberLoad_CarriesItsLoadAsSubject()
    {
        var m = Ring();
        var l = new MemberLoad { MemberId = 99, Wz = -5 };
        m.MemberLoads.Add(l);
        var i = Assert.Single(ModelChecker.Check(m), x => x.Code == "LOAD_MEM_MISSING");
        Assert.Same(l, i.Subject);
        Assert.Equal(IssueLevel.Error, i.Level);
    }

    [Fact]
    public void IsolatedNode_IsFlaggedWithItsNumber()
    {
        var m = Ring();
        m.Nodes.Add(new Node { Id = 50, X = 20, Y = 20, Z = 0 });
        var i = Assert.Single(ModelChecker.Check(m), x => x.Code == "NODE_ISOLATED");
        Assert.Equal(50, i.NodeId);
    }

    [Fact]
    public void NoSupport_HasItsCode()
    {
        var m = Ring();
        m.Supports.Clear();
        Assert.Contains(ModelChecker.Check(m), x => x.Code == "NO_SUPPORT" && x.Level == IssueLevel.Error);
    }

    [Fact]
    public void SlabWithoutBeams_PointsAtTheGeneratedLoad()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.3, H = 0.3 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        var s = new SlabPanel { Name = "D9", Placed = true, X0 = 10, Y0 = 10, Lx = 4, Ly = 4, Z = 3, H = 0.16, Q = 2.5 };
        m.Slabs.Add(s);
        StoreyOps.SyncSlabLoads(m, s);
        var i = Assert.Single(ModelChecker.Check(m), x => x.Code == "SURF_NOBEAM" && x.Message.Contains("D9-Q"));
        Assert.IsType<SurfaceLoad>(i.Subject);
        Assert.Equal("D9-Q", ((SurfaceLoad)i.Subject!).Name);
    }

    [Fact]
    public void OverlappingSlabs_CarryBothSlabs()
    {
        var m = Ring();
        var a = new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 5, Ly = 5, Z = 3, H = 0.16 };
        var b = new SlabPanel { Name = "D2", Placed = true, X0 = 2, Y0 = 2, Lx = 5, Ly = 5, Z = 3, H = 0.16 };
        m.Slabs.Add(a); m.Slabs.Add(b);
        var i = Assert.Single(ModelChecker.Check(m), x => x.Code == "SLAB_OVERLAP");
        Assert.Same(a, i.Subject); Assert.Same(b, i.Subject2);
    }

    private static StructModel LonelyColumnWithSlab()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = 0.3, H = 0.3 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        var s = new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 4, Ly = 4, Z = 3, H = 0.16, Q = 2.5 };
        m.Slabs.Add(s);
        StoreyOps.SyncSlabLoads(m, s);
        return m;
    }

    [Fact]
    public void Perimeter_CreatesRimBeamsAndCornerColumns_SoTheSlabIsCarried()
    {
        var m = LonelyColumnWithSlab();
        var r = SlabPerimeter.Create(m, m.Slabs[0], true);
        Assert.Equal(4, r.Beams);                 // un bord = une poutre entre deux angles
        Assert.Equal(3, r.Columns);               // l'angle (0 ; 0) a déjà son poteau
        Assert.Equal(3, r.Supports);
        var issues = ModelChecker.Check(m);
        Assert.DoesNotContain(issues, i => i.Code is "SURF_NOBEAM" or "UNSUPPORTED" or "NO_SUPPORT" or "MECHANISM");
    }

    [Fact]
    public void Perimeter_WithoutColumns_OnlyAddsBeams_AndIsIdempotent()
    {
        var m = LonelyColumnWithSlab();
        var r = SlabPerimeter.Create(m, m.Slabs[0], false);
        Assert.Equal(4, r.Beams); Assert.Equal(0, r.Columns);
        int members = m.Members.Count;
        var again = SlabPerimeter.Create(m, m.Slabs[0], false);
        Assert.Equal(0, again.Beams);
        Assert.Equal(members, m.Members.Count);
    }

    [Fact]
    public void ShortBeam_BecomesAWall_AndKeepsItsLoadResultant()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 0.8, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.25, H = 0.5 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Case = ActionType.G, Wz = -10 });
        Assert.Contains(ModelChecker.Check(m), x => x.Code == "BEAM_SHORT");
        var r = DeepBeamConversion.ToWall(m, 1);
        Assert.True(r.Done);
        Assert.Empty(m.Members);
        Assert.Empty(m.MemberLoads);
        Assert.NotEmpty(m.Shells);
        Assert.All(m.Shells, s => Assert.Equal(0.25, s.T, 6));
        Assert.Equal(-8.0, m.NodalLoads.Sum(n => n.Fz), 6);              // 10 kN/m x 0,8 m
        Assert.Equal(-4.0, m.NodalLoads.First(n => n.NodeId == 2).Fz, 6);
        Assert.DoesNotContain(ModelChecker.Check(m), x => x.Code == "BEAM_SHORT");
    }

    [Fact]
    public void ShortBeam_WithMoment_IsRefusedAndLeftUntouched()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 0.8, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.25, H = 0.5 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 1, Kind = MemberLoadKind.Moment, Mx = 5 });
        var r = DeepBeamConversion.ToWall(m, 1);
        Assert.False(r.Done);
        Assert.Single(m.Members); Assert.Empty(m.Shells);
    }
}
