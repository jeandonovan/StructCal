using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

/// <summary>Mise en page dynamique des planches : centrage, aucun débordement, échelles qui suivent le dessin.</summary>
public class SheetLayoutTests
{
    [Fact]
    public void SmallDrawing_IsEnlarged_Centered_AndScaleTextFollows()
    {
        var s = new Sheet { Name = "t", Title = "t", ScaleText = "1:20 (coupes 1:10)" };
        s.Rect(100, 100, 100, 60, "BETON");
        SheetLayout.Prepare(s);
        Assert.Equal("1:10 (coupes 1:5)", s.ScaleText);
        var b = SheetLayout.ContentBox(s)!.Value;
        Assert.Equal(200, b.X1 - b.X0, 6);
        Assert.Equal(120, b.Y1 - b.Y0, 6);
        Assert.Equal(210, (b.X0 + b.X1) / 2, 6);          // centre de la zone libre : (16 + 404) / 2
        Assert.Equal(177.5, (b.Y0 + b.Y1) / 2, 6);        // (74 + 281) / 2
    }

    [Fact]
    public void OverflowingDrawing_WithoutScale_IsShrunkInsideTheFrame()
    {
        var s = new Sheet { Name = "t", Title = "t", ScaleText = "Sans échelle" };
        s.Line(-50, 150, 650, 150, "ARMATURES");
        s.Text(20, s.Height - 22, 5, "Titre de la planche", "TEXTE");            // titre : ne bouge pas
        SheetLayout.Prepare(s);
        var b = SheetLayout.ContentBox(s)!.Value;
        Assert.True(b.X0 >= 16 - 1e-6 && b.X1 <= s.Width - 16 + 1e-6, $"{b.X0} {b.X1}");
        Assert.Equal(20, s.Items.First(e => e.Kind == EntKind.Text).X1, 9);
        Assert.Equal("Sans échelle", s.ScaleText);
    }

    [Fact]
    public void ManualScale_OnlyOffersScalesThatFit_AndAutoRestores()
    {
        var s = new Sheet { Name = "t", Title = "t", ScaleText = "1:50" };
        s.Rect(0, 0, 80, 40, "BETON");               // 4 m x 2 m au 1:50 = 80 x 40 mm de papier
        SheetLayout.Prepare(s);
        var opts = SheetLayout.Options(s);
        Assert.NotEmpty(opts);
        Assert.DoesNotContain(opts, d => d < 10);    // 1:10 donnerait 400 x 200 mm : impossible
        double auto = SheetLayout.CurrentDen(s);
        SheetLayout.SetDenominator(s, 100);
        Assert.Equal("1:100", s.ScaleText);
        var b = SheetLayout.ContentBox(s)!.Value;
        Assert.Equal(40, b.X1 - b.X0, 6);
        SheetLayout.SetDenominator(s, 1);            // ne tient pas : ramené à la plus grande échelle possible
        Assert.True(SheetLayout.CurrentDen(s) >= opts[0] - 1e-9);
        var b2 = SheetLayout.ContentBox(s)!.Value;
        Assert.True(b2.X1 - b2.X0 <= 388 + 1e-6);
        SheetLayout.SetAuto(s);
        Assert.Equal(auto, SheetLayout.CurrentDen(s), 6);
    }

    [Fact]
    public void GeneratedSheets_NeverOverflow_FrameTitleBlockOrTables()
    {
        var m = ExampleModels.Portal();
        m.SigmaSolKPa = 200;
        var o = ProjectAnalyzer.Run(m);
        var sheets = DrawingGenerator.Generate(m, o, true);
        Assert.NotEmpty(sheets);
        foreach (var s in sheets.Where(SheetLayout.HasContent))
        {
            var b = SheetLayout.ContentBox(s)!.Value;
            string id = $"{s.Number} {s.Title}";
            Assert.True(b.X0 >= 10 - 1e-6 && b.X1 <= s.Width - 10 + 1e-6 && b.Y0 >= 10 - 1e-6 && b.Y1 <= s.Height - 10 + 1e-6, $"{id} : hors du cadre ({b.X0:0.#},{b.Y0:0.#})-({b.X1:0.#},{b.Y1:0.#})");
            Assert.False(b.X1 > s.Width - 210 + 1e-6 && b.Y0 < 10 + TitleBlock.Height - 1e-6, $"{id} : empiète sur le cartouche");
            foreach (var t in s.Tables)
                Assert.False(b.X1 > t.X0 + 1e-6 && b.X0 < t.Right - 1e-6 && b.Y1 > t.Bottom + 1e-6 && b.Y0 < t.Top - 1e-6, $"{id} : empiète sur un tableau");
        }
    }

    [Fact]
    public void TitleBlock_ShowsTheCurrentScale()
    {
        var m = ExampleModels.Portal();
        m.SigmaSolKPa = 200;
        var o = ProjectAnalyzer.Run(m);
        var sheets = DrawingGenerator.Generate(m, o, true);
        var f = sheets.First(x => x.Name == "Semelles");
        var opts = SheetLayout.Options(f);
        Assert.NotEmpty(opts);
        double d = opts.Last();
        SheetLayout.SetDenominator(f, d);
        Assert.Contains(f.Items, e => e.Block && e.Kind == EntKind.Text && e.Text.StartsWith("1:" + (Math.Abs(d - Math.Round(d)) < 0.05 ? Math.Round(d).ToString("0") : d.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture))));
    }

    [Fact]
    public void ShortTextsInTopBand_AreContent_NotHeadings()
    {
        var s = new Sheet { Name = "t", Title = "t", ScaleText = "1:50" };
        s.Rect(100, 150, 100, 40, "BETON");
        s.Text(120, s.Height - 24, 2.3, "2", "TEXTE");                        // numéro de repère dans la bande haute
        s.Text(20, s.Height - 22, 4, "POUTRE B1   25x40", "TEXTE");           // vrai titre
        SheetLayout.Prepare(s);
        var num = s.Items.First(e => e.Kind == EntKind.Text && e.Text == "2");
        var title = s.Items.First(e => e.Kind == EntKind.Text && e.Text.StartsWith("POUTRE"));
        Assert.True(num.Content);
        Assert.False(title.Content);
    }
}
