using System.Linq;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using Xunit;

public class SettingsAndDetailingTests
{
    [Fact]
    public void Settings_RoundTrip_In_Json()
    {
        var m = ExampleModels.Portal();
        m.Settings.CoverBeamCm = 4.5; m.Settings.BeamDiameters = new[] { 12, 16, 20 }; m.Settings.Company = "Bureau X";
        var back = ModelIO.FromJson(ModelIO.ToJson(m));
        Assert.Equal(4.5, back.Settings.CoverBeamCm);
        Assert.Equal(new[] { 12, 16, 20 }, back.Settings.BeamDiameters);
        Assert.Equal("Bureau X", back.Settings.Company);
    }

    [Fact]
    public void Preset_Rpa_And_Bael_Set_Codes_And_Seismic()
    {
        var m = new StructModel();
        m.Seismic.Zone = "III";
        SettingsPresets.Apply(SettingsPresets.PRpa, m);
        Assert.Equal("RPA99", m.RcCodeId);
        Assert.True(m.Seismic.Enabled);
        Assert.Equal(50, m.Settings.LapFactor);
        SettingsPresets.Apply(SettingsPresets.PBael, m);
        Assert.Equal("BAEL91", m.RcCodeId);
        Assert.False(m.Seismic.Enabled);
    }

    [Fact]
    public void RebarSelector_Uses_Allowed_Diameters_And_Spacing_Step()
    {
        var c = RebarSelector.ForBeam(4.0, 0.25, 0.05, new DesignSettings { BeamDiameters = new[] { 16, 20 } });
        Assert.Contains(c.Diameter, new[] { 16, 20 });
        var st = RebarSelector.Stirrups(3.0, 30, 6, new DesignSettings { StirrupDiameters = new[] { 10 }, SpacingStepCm = 5 });
        Assert.Equal(10, st.Dia);
        Assert.Equal(0.0, st.SpacingCm % 5);
    }

    [Fact]
    public void Column_Min_Percent_Is_Enforced()
    {
        var m = ExampleModels.Portal();
        m.Settings.ColumnMinPercent = 2.0;
        var o = ProjectAnalyzer.Run(m, true);
        var cols = o.Members.Where(r => r.Type == MemberType.Column && r.Kind == MaterialKind.ReinforcedConcrete && !r.Skipped).ToList();
        Assert.NotEmpty(cols);
        Assert.All(cols, r => Assert.True(r.AsBottom >= 0.02 * r.B * r.H * 1e4 - 1e-6));
    }

    [Fact]
    public void Advisor_Flags_Seismic_Without_Seismic_Code()
    {
        var m = ExampleModels.Portal();
        m.RcCodeId = "BAEL91"; m.Seismic.Enabled = true;
        int withSeismic = SettingsAdvisor.Check(m).Count;
        Assert.True(withSeismic > 0);
        m.RcCodeId = "RPA99";
        Assert.True(SettingsAdvisor.Check(m).Count < withSeismic);
    }

    [Fact]
    public void Apply_Covers_Changes_Members()
    {
        var m = ExampleModels.Portal();
        m.Settings.CoverBeamCm = 6; m.Settings.CoverColumnCm = 4.5;
        int n = SettingsApplier.ApplyCovers(m);
        Assert.True(n > 0);
        Assert.All(m.Members.Where(x => x.Type == MemberType.Beam), x => Assert.Equal(0.06, x.Cover, 6));
        Assert.All(m.Members.Where(x => x.Type == MemberType.Column), x => Assert.Equal(0.045, x.Cover, 6));
    }

    [Fact]
    public void BarSchedule_Is_Consistent()
    {
        var r = new MemberDesignResult
        {
            MemberId = 1, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, B = 0.25, H = 0.45, Length = 5.0,
            BotN = 4, BotDia = 16, TopN = 3, TopDia = 14, StirDia = 8, StirSpacingCm = 15, NodalSpacingCm = 10, NodalZoneM = 0.9, CoverM = 0.05
        };
        var lines = RcSheets.BeamBars(r, new DesignSettings(), "B1", 2);
        Assert.NotEmpty(lines);
        Assert.All(lines, l => Assert.True(l.MassKg > 0));
        Assert.Contains(lines, l => l.Dia == 16 && l.Count == 4);
        Assert.InRange(DesignSettings.KgPerM(16), 1.55, 1.60);
        Assert.All(lines, l => Assert.Equal(l.Count * l.Qty * l.LengthM, l.TotalM, 6));
    }

    [Fact]
    public void StirrupPositions_Symmetric_And_Denser_Near_Supports()
    {
        var p = RcSheets.StirrupPositions(4.0, 0.20, 0.8, 0.10);
        Assert.Equal(p.Count, p.Distinct().Count());
        for (int i = 0; i < p.Count; i++) Assert.Equal(4.0 - p[p.Count - 1 - i], p[i], 2);
        var uniform = RcSheets.StirrupPositions(4.0, 0.20, 0, 0);
        Assert.True(p.Count > uniform.Count);
    }

    [Fact]
    public void Plans_Contain_Cut_Marks_Bubbles_Stirrups_And_Schedule()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, true);
        var sheets = DrawingGenerator.Generate(m, o, true);
        var rc = sheets.Where(s => s.Name == "Poutres" || s.Name == "Poteaux").ToList();
        Assert.NotEmpty(rc);
        Assert.All(rc, s =>
        {
            Assert.Contains(s.Items, e => e.Layer == "COUPES");
            Assert.Contains(s.Items, e => e.Layer == "REPERES");
            Assert.Contains(s.Items, e => e.Layer == "CADRES");
            Assert.Contains(s.Items, e => e.Kind == EntKind.Circle && e.Fill);
            Assert.Contains(s.Items, e => e.Kind == EntKind.Text && e.Text.Contains("NOMENCLATURE DES ACIERS"));
        });
        Assert.Contains(sheets, s => s.Name == "Recapitulatif");
    }

    [Fact]
    public void New_Reinforcement_Sheets_Stay_Inside_The_Page()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, true);
        var sheets = DrawingGenerator.Generate(m, o, true);
        string[] mine = { "Poutres", "Poteaux", "Semelles", "Dalles", "Recapitulatif" };
        foreach (var s in sheets.Where(x => mine.Contains(x.Name)))
            foreach (var e in s.Items)
            {
                Assert.InRange(e.X1, -3, s.Width + 3); Assert.InRange(e.Y1, -3, s.Height + 3);
                if (e.Kind == EntKind.Line) { Assert.InRange(e.X2, -3, s.Width + 3); Assert.InRange(e.Y2, -3, s.Height + 3); }
            }
    }

    [Fact]
    public void Dxf_Writes_Filled_Dots_And_New_Layers()
    {
        var s = new Sheet();
        s.Dot(5, 5, 1.0, "ARMATURES"); s.Line(0, 0, 3, 3, "COUPES");
        string dxf = DxfWriter.ToDxf(s);
        Assert.Contains("COUPES", dxf); Assert.Contains("REPERES", dxf); Assert.Contains("TABLEAU", dxf);
        Assert.True(dxf.Split("CIRCLE").Length - 1 >= 4);       // disque plein = 4 cercles concentriques
    }

    [Fact]
    public void License_Creator_Edition_Is_Recognised()
    {
        var info = new StructCalc.Core.Licensing.LicenseInfo { Edition = "CREATEUR" };
        Assert.True(info.IsCreator);
        Assert.False(new StructCalc.Core.Licensing.LicenseInfo { Edition = "PRO" }.IsCreator);
        using var rsa = System.Security.Cryptography.RSA.Create(2048);
        string text = StructCalc.Core.Licensing.LicenseManager.CreateLicenseText(info, rsa.ToXmlString(true));
        Assert.True(StructCalc.Core.Licensing.LicenseManager.VerifyLicenseText(text, rsa.ToXmlString(false), out var back, out _));
        Assert.True(back!.IsCreator);
    }
}
