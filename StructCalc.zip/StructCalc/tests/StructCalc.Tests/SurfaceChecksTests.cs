using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Floors;
using StructCalc.Engine.Stairs;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Walls;
using Xunit;

/// <summary>Étape 4 : vérifications lisibles des escaliers, voiles, radiers et planchers nervurés (valeur, limite, verdict) et leur présence dans la note de calcul.</summary>
public class SurfaceChecksTests
{
    private static SoilProfile Soil()
    {
        var s = new SoilProfile();
        s.Layers.Add(new SoilLayer { Name = "Sable", PhiDeg = 32, CKPa = 0, GammaKnM3 = 18, GammaSatKnM3 = 20, EoedMPa = 30 });
        return s;
    }

    // ---------------------------------------------------------------- escalier (résultat construit à la main : verdicts déterministes)
    [Fact]
    public void Escalier_Blondel_et_cisaillement_sont_jugés_avec_la_limite()
    {
        var o = new AnalysisOutput();
        var r = new StairResult { Def = new StairDef { Name = "E1" } };
        r.Geo.Risers = 18; r.Geo.RiserM = 0.17; r.Geo.TreadM = 0.28;          // 2h + g = 62 cm : OK
        r.Elements.Add(new StairElementResult { Name = "Volée 1", Tau = 0.8, TauLim = 1.5, BarsT = "HA12 e=15", Ok = true });
        r.Elements.Add(new StairElementResult { Name = "Volée 2", Tau = 2.0, TauLim = 1.5, BarsT = "HA12 e=15", Ok = false });
        o.Stairs.Add(r);
        var rows = SurfaceChecks.Collect(o);
        Assert.True(rows.Single(x => x.Check.StartsWith("Formule de Blondel")).Ok, "[Escalier] Blondel 62 cm doit être accepté.");
        Assert.True(rows.Single(x => x.Element.EndsWith("Volée 1") && x.Check == "Cisaillement τu").Ok);
        Assert.False(rows.Single(x => x.Element.EndsWith("Volée 2") && x.Check == "Cisaillement τu").Ok, "[Escalier] τ = 2,0 > 1,5 MPa doit être refusé.");
    }

    [Fact]
    public void Escalier_Blondel_hors_plage_est_refuse()
    {
        var o = new AnalysisOutput();
        var r = new StairResult { Def = new StairDef { Name = "E2" } };
        r.Geo.Risers = 15; r.Geo.RiserM = 0.20; r.Geo.TreadM = 0.30;          // 70 cm : trop long
        o.Stairs.Add(r);
        Assert.False(SurfaceChecks.Collect(o).Single(x => x.Check.StartsWith("Formule de Blondel")).Ok);
    }

    [Fact]
    public void Escalier_reel_produit_des_lignes()
    {
        var rc = new Bael91Code();
        var res = StairDesigner.Design(new StairDef { Name = "E1", Layout = StairLayout.DroitPalier, HeightM = 3.0, WidthM = 1.2 }, rc, 25, 500);
        var o = new AnalysisOutput(); o.Stairs.Add(res);
        var rows = SurfaceChecks.Collect(o);
        Assert.Contains(rows, x => x.Check.StartsWith("Formule de Blondel"));
        Assert.Contains(rows, x => x.Check == "Cisaillement τu");
    }

    // ---------------------------------------------------------------- voile
    [Fact]
    public void Voile_reel_porte_le_cisaillement_et_l_armature_minimale()
    {
        var w = new WallDef { Name = "V1", LengthM = 5, HeightM = 3.06, ThicknessM = 0.2, EHorizKn = 150, WindKPa = 0.5 };
        var res = WallDesigner.Design(w, new Bael91Code(), 25, 500);
        var o = new AnalysisOutput(); o.Walls.Add(res);
        var rows = SurfaceChecks.Collect(o);
        var tau = rows.Single(x => x.Check == "Cisaillement moyen");
        Assert.Equal(res.Tau <= res.TauLim + 1e-9, tau.Ok);
        Assert.Contains(rows, x => x.Check.StartsWith("Armature verticale"));
    }

    [Fact]
    public void Voile_trop_cisaille_est_refuse_dans_le_tableau()
    {
        var o = new AnalysisOutput();
        var res = new WallResult { Def = new WallDef { Name = "V9" }, Tau = 6, TauLim = 5, Ok = false };
        res.Warnings.Add("Contrainte de cisaillement trop forte.");
        o.Walls.Add(res);
        var rows = SurfaceChecks.Collect(o);
        Assert.False(rows.Single(x => x.Check == "Cisaillement moyen").Ok);
        Assert.Contains(rows, x => x.Check == "Avertissement" && !x.Ok);
    }

    // ---------------------------------------------------------------- radier
    [Fact]
    public void Radier_mince_echoue_sur_l_epaisseur_de_poinconnement()
    {
        var r = new RaftDef { Name = "R1", ZTop = -1.2, H = 0.20 };
        r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 10, Ly = 10 });
        var loads = new[] { (2.5, 2.5), (7.5, 2.5), (2.5, 7.5), (7.5, 7.5) }.Select((q, i) => new RaftLoad { Name = "N" + i, X = q.Item1, Y = q.Item2, Nu = 3000, Ns = 2200, A = 0.4, B = 0.4, Column = true }).ToList();
        var res = RaftDesigner.Design(r, loads, Soil(), 0, new Bael91Code(), 25, 500, new DesignSettings());
        var o = new AnalysisOutput(); o.Rafts.Add(res);
        var rows = SurfaceChecks.Collect(o);
        var h = rows.Single(x => x.Check.StartsWith("Épaisseur"));
        Assert.False(h.Ok, "[Radier] 20 cm sous 3000 kN par poteau : le poinçonnement doit échouer.");
        Assert.Contains("cm", h.Limit);
    }

    [Fact]
    public void Radier_contrainte_du_sol_compare_a_la_limite()
    {
        var o = new AnalysisOutput();
        var res = new RaftResult { Def = new RaftDef { Name = "R2", H = 0.5 }, SigmaMax = 250, QAdm = 200 };
        o.Rafts.Add(res);
        Assert.False(SurfaceChecks.Collect(o).Single(x => x.Check.StartsWith("Contrainte maximale")).Ok);
        res.SigmaMax = 150;
        Assert.True(SurfaceChecks.Collect(o).Single(x => x.Check.StartsWith("Contrainte maximale")).Ok);
    }

    // ---------------------------------------------------------------- plancher nervuré
    [Fact]
    public void Plancher_nervure_reel_est_verifie()
    {
        var rc = new Bael91Code();
        var d = new RibbedFloorDef { Name = "PL1" };
        var res = RibbedFloorDesigner.Design(d, rc, 25, 400);
        var o = new AnalysisOutput(); o.RibbedFloors.Add(res);
        var rows = SurfaceChecks.Collect(o);
        Assert.Contains(rows, x => x.Element == "Plancher PL1");
        Assert.Contains(rows, x => x.Check == "Dimensionnement du plancher" || x.Check == "Avertissement");
    }

    // ---------------------------------------------------------------- note de calcul
    [Fact]
    public void Note_de_calcul_contient_le_tableau_des_verifications()
    {
        var m = ExampleModels.Portal();
        m.Stairs.Add(new StairDef { Name = "E1", Layout = StairLayout.DroitPalier, HeightM = 3.0, WidthM = 1.2 });
        var o = ProjectAnalyzer.Run(m, optimize: false);
        string html = ReportWriter.ToHtml(m, o);
        Assert.Contains("Vérifications des escaliers, voiles, radiers et planchers", html);
        Assert.Contains("Formule de Blondel", html);
    }

    [Fact]
    public void Sans_element_surfacique_pas_de_tableau()
    {
        Assert.Equal("", SurfaceChecks.ToHtml(new AnalysisOutput()));
        Assert.Contains("Aucun", SurfaceChecks.ToText(new AnalysisOutput()));
    }
}
