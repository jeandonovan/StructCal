using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Coques planes intégrées au modèle 3D : plaque de Navier, console courte de Timoshenko, équilibre dalle + poteaux, Wood-Armer.</summary>
public class ShellTests
{
    private static StructModel Empty() => new StructModel { IncludeSelfWeight = false, Fc28 = 25 };

    private static int NodeNear(StructModel m, double x, double y, double z)
        => m.Nodes.First(n => Math.Abs(n.X - x) < 1e-6 && Math.Abs(n.Y - y) < 1e-6 && Math.Abs(n.Z - z) < 1e-6).Id;

    [Fact]
    public void SimplySupportedSquarePlate_CentralDeflection_MatchesNavier()
    {
        double a = 4, t = 0.1, q = 10;
        var m = Empty();
        int n = 8;
        Assert.Equal(n * n, ShellMesh.AddSlab(m, "D1", 0, 0, 0, a, a, t, a / n, 0, q));
        foreach (var nd in m.Nodes)
        {
            bool edge = Math.Abs(nd.X) < 1e-9 || Math.Abs(nd.Y) < 1e-9 || Math.Abs(nd.X - a) < 1e-9 || Math.Abs(nd.Y - a) < 1e-9;
            if (!edge) continue;
            bool c00 = Math.Abs(nd.X) < 1e-9 && Math.Abs(nd.Y) < 1e-9, cA0 = Math.Abs(nd.X - a) < 1e-9 && Math.Abs(nd.Y) < 1e-9;
            m.Supports.Add(new SupportDef { NodeId = nd.Id, Ux = c00, Uy = c00 || cA0, Uz = true, Rx = false, Ry = false, Rz = false });
        }
        var r = FrameSolver.Solve(m, ActionType.Q);
        double D = m.EcKNm2 * t * t * t / (12 * (1 - ShellFem.Nu * ShellFem.Nu));
        double expected = 0.00406 * q * Math.Pow(a, 4) / D;
        double w = -r.NodeDisp[NodeNear(m, a / 2, a / 2, 0)][2];
        Assert.True(Math.Abs(w - expected) <= 0.02 * expected, $"flèche {w} attendue {expected}");
        // équilibre vertical
        Assert.Equal(q * a * a, r.Reactions.Values.Sum(v => v[2]), 6);
    }

    [Fact]
    public void ShortCantileverWall_TipDeflection_MatchesTimoshenko()
    {
        double b = 1, L = 4, t = 0.2, P = 100;
        var m = Empty();
        int nx = 2, ny = 8;
        ShellMesh.AddWall(m, "V1", 0, 0, 0, 0, b, L, t, 0.5);
        Assert.Equal(nx * ny, m.Shells.Count);
        var top = m.Nodes.Where(nd => Math.Abs(nd.Z - L) < 1e-9).OrderBy(nd => nd.X).ToList();
        Assert.Equal(nx + 1, top.Count);
        foreach (var nd in m.Nodes.Where(nd => Math.Abs(nd.Z) < 1e-9)) m.Supports.Add(new SupportDef { NodeId = nd.Id });
        for (int i = 0; i < top.Count; i++)
            m.NodalLoads.Add(new NodalLoad { NodeId = top[i].Id, Case = ActionType.Q, Fx = P * ((i == 0 || i == nx) ? 0.5 : 1.0) / nx });
        var r = FrameSolver.Solve(m, ActionType.Q);
        double E = m.EcKNm2, I = t * b * b * b / 12, G = E / (2 * (1 + ShellFem.Nu)), A = b * t;
        double expected = P * L * L * L / (3 * E * I) + P * L / (5.0 / 6.0 * G * A);
        double ux = top.Average(nd => r.NodeDisp[nd.Id][0]);
        Assert.True(Math.Abs(ux - expected) <= 0.04 * expected, $"déplacement {ux} attendu {expected}");
        Assert.Equal(-P, r.Reactions.Values.Sum(v => v[0]), 5);
    }

    private static StructModel SlabOnFourColumns(bool selfWeight)
    {
        var m = Empty();
        m.IncludeSelfWeight = selfWeight;
        double a = 4, h = 3;
        ShellMesh.AddSlab(m, "D1", 0, 0, h, a, a, 0.2, 1.0, 0, 5);
        int id = 1000;
        foreach (var (x, y) in new[] { (0.0, 0.0), (a, 0.0), (a, a), (0.0, a) })
        {
            int top = NodeNear(m, x, y, h);
            m.Nodes.Add(new Node { Id = ++id, X = x, Y = y, Z = 0 });
            m.Members.Add(new Member { Id = id, NodeI = id, NodeJ = top, Type = MemberType.Column, B = 0.3, H = 0.3 });
            m.Supports.Add(new SupportDef { NodeId = id });
        }
        return m;
    }

    [Fact]
    public void SlabOnColumns_Equilibrium_And_Coupling()
    {
        var m = SlabOnFourColumns(false);
        Assert.Equal(16, m.Shells.Count);
        var r = FrameSolver.Solve(m, ActionType.Q);
        Assert.Equal(5.0 * 16, r.Reactions.Values.Sum(v => v[2]), 6);
        Assert.Equal(0.0, r.Reactions.Values.Sum(v => v[0]), 6);
        Assert.Equal(0.0, r.Reactions.Values.Sum(v => v[1]), 6);
        // les 4 poteaux (identiques et symétriques) reprennent chacun le quart de la charge
        foreach (var v in r.Reactions.Values) Assert.Equal(20.0, v[2], 4);
        Assert.Equal(16, r.Shells.Count);
    }

    [Fact]
    public void Shell_SelfWeight_And_SeismicMass()
    {
        var m = SlabOnFourColumns(true);
        var g = FrameSolver.Solve(m, ActionType.G);
        // poids propre de la dalle 25 x 0,2 x 16 = 80 kN + 4 poteaux 25 x 0,09 x 3 = 27 kN
        Assert.Equal(80.0 + 27.0, g.Reactions.Values.Sum(v => v[2]), 5);
        var w = ShellFem.NodalWeights(m, 0.3);
        Assert.Equal(80.0 + 0.3 * 5 * 16, w.Values.Sum(), 6);
    }

    [Fact]
    public void WoodArmer_And_Flexure_Formulas()
    {
        var (x0, y0) = ShellDesigner.WoodArmer(10, 5, 0);
        Assert.Equal(10, x0, 9); Assert.Equal(5, y0, 9);
        var (x1, y1) = ShellDesigner.WoodArmer(10, 5, 3);
        Assert.Equal(13, x1, 9); Assert.Equal(8, y1, 9);
        var (x2, y2) = ShellDesigner.WoodArmer(-4, 5, 3);
        Assert.Equal(0, x2, 9); Assert.Equal(5 + 9.0 / 4, y2, 9);
        double a1 = ShellDesigner.AsFlexion(100, 0.2, 25, 500, out bool over);
        Assert.False(over);
        Assert.Equal(12.7466, a1, 3);
        ShellDesigner.AsFlexion(400, 0.2, 25, 500, out bool over2);
        Assert.True(over2);
    }

    [Fact]
    public void FullAnalysis_ReportsShellDesign()
    {
        var m = SlabOnFourColumns(true);
        var o = ProjectAnalyzer.Run(m);
        Assert.Contains(o.Extras, x => x.Title.StartsWith("Coques"));
    }

    [Fact]
    public void RemoveShells_RemovesOrphanNodesOnly()
    {
        var m = SlabOnFourColumns(false);
        int before = m.Nodes.Count;
        int removed = ShellMesh.Remove(m, "D1");
        Assert.Equal(16, removed);
        Assert.Empty(m.Shells);
        Assert.Equal(8, m.Nodes.Count);          // 4 nœuds de tête de poteau + 4 pieds restent
        Assert.True(before > 8);
    }
}
