using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Dalle dessinée sur les faces intérieures des poutres : recalée sur les axes, charges reportées, pas d'erreur « aucune poutre ».</summary>
public class SlabSnapTests
{
    private static StructModel Ring(double slabInset)
    {
        var m = new StructModel { IncludeSelfWeight = false };
        double[,] p = { { 0, 0 }, { 5, 0 }, { 5, 5 }, { 0, 5 } };
        for (int i = 0; i < 4; i++) m.Nodes.Add(new Node { Id = i + 1, X = p[i, 0], Y = p[i, 1], Z = 3 });
        for (int i = 0; i < 4; i++) m.Members.Add(new Member { Id = i + 1, NodeI = i + 1, NodeJ = (i + 1) % 4 + 1, Type = MemberType.Beam, B = 0.30, H = 0.50 });
        m.Slabs.Add(new SlabPanel { Name = "D1", Placed = true, X0 = slabInset, Y0 = slabInset, Lx = 5 - 2 * slabInset, Ly = 5 - 2 * slabInset, Z = 3, H = 0.16 });
        return m;
    }

    [Fact]
    public void SlabOnBeamFaces_IsSnappedToAxes_AndLoadsAreCarried()
    {
        var m = Ring(0.15);
        var s = m.Slabs[0];
        var e = SlabSnap.Extent(m, s);
        Assert.Equal(0, e.X0, 6); Assert.Equal(5, e.X1, 6); Assert.Equal(0, e.Y0, 6); Assert.Equal(5, e.Y1, 6);
        StoreyOps.SyncSlabLoads(m, s);
        var cells = SlabCells.Of(m, s);
        Assert.Single(cells);
        Assert.Equal(5, cells[0].Lx, 6);
        foreach (var sl in m.SurfaceLoads)
            Assert.True(LoadExpander.Expand(m, sl).LoadedFraction > 0.99);
        var issues = ModelChecker.Check(m);
        Assert.DoesNotContain(issues, i => i.Level == IssueLevel.Error && i.Message.Contains("aucune poutre"));
        Assert.Contains(issues, i => i.Level == IssueLevel.Info && i.Message.Contains("faces des poutres"));
    }

    [Fact]
    public void SlabOnAxes_IsUnchanged_NoInfo()
    {
        var m = Ring(0);
        var e = SlabSnap.Extent(m, m.Slabs[0]);
        Assert.Equal(0, e.X0, 6); Assert.Equal(5, e.X1, 6);
        Assert.DoesNotContain(ModelChecker.Check(m), i => i.Message.Contains("faces des poutres"));
    }

    [Fact]
    public void FarFromBeams_IsNotSnapped()
    {
        var m = Ring(0.60);                                   // 60 cm de décalage : plus qu'une demi-poutre
        var e = SlabSnap.Extent(m, m.Slabs[0]);
        Assert.Equal(0.60, e.X0, 6); Assert.Equal(4.40, e.X1, 6);
    }

    [Fact]
    public void SlabOnOuterBeamFaces_IsSnappedToAxes()
    {
        var m = Ring(-0.15);                                  // dalle jusqu'aux faces extérieures des poutres
        var e = SlabSnap.Extent(m, m.Slabs[0]);
        Assert.Equal(0, e.X0, 6); Assert.Equal(5, e.X1, 6); Assert.Equal(0, e.Y0, 6); Assert.Equal(5, e.Y1, 6);
    }

    [Fact]
    public void Cantilever_LoadGoesToTheSupportingBeam_AndIsReported()
    {
        var m = Ring(0);
        var slab = m.Slabs[0];
        slab.Lx = 6.2;                                        // console de 1,20 m au-delà de la poutre x = 5
        StoreyOps.SyncSlabLoads(m, slab);
        Assert.Equal(2, SlabCells.Of(m, slab).Count);
        var loads = m.SurfaceLoads.Where(l => l.Name.StartsWith("D1-G")).ToList();
        Assert.Equal(2, loads.Count);
        foreach (var l in loads) Assert.True(LoadExpander.Expand(m, l).LoadedFraction > 0.99);
        Assert.Contains(loads, l => LoadExpander.Expand(m, l).FreeEdges == 3);
        var issues = ModelChecker.Check(m);
        Assert.DoesNotContain(issues, i => i.Level == IssueLevel.Error && i.Message.Contains("aucune poutre"));
        Assert.Contains(issues, i => i.Level == IssueLevel.Warning && i.Message.Contains("console"));
    }
}
