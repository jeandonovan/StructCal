using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Xunit;

/// <summary>Prédimensionnement : poutres continues, poteaux superposés, dalles, escaliers, semelles.</summary>
public class PreDesignTests
{
    private static StructModel Frame(out int[] beams, out int[] cols)
    {
        var m = new StructModel { Fc28 = 25 };
        int id = 1;
        // trois travées de 5 m à z = 3, un poteau sous le premier appui à z = 0 -> 3 -> 6
        double[] xs = { 0, 5, 10, 15 };
        foreach (var x in xs) m.Nodes.Add(new Node { Id = id++, X = x, Y = 0, Z = 3 });          // 1..4
        m.Nodes.Add(new Node { Id = 5, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 6, X = 0, Y = 0, Z = 6 });
        m.Nodes.Add(new Node { Id = 7, X = 0, Y = 4, Z = 3 });                                     // poutre perpendiculaire
        var b = new List<int>();
        for (int i = 1; i <= 3; i++) { m.Members.Add(new Member { Id = i, NodeI = i, NodeJ = i + 1, Type = MemberType.Beam }); b.Add(i); }
        m.Members.Add(new Member { Id = 4, NodeI = 5, NodeJ = 1, Type = MemberType.Column, B = 0.25, H = 0.25 });
        m.Members.Add(new Member { Id = 5, NodeI = 1, NodeJ = 6, Type = MemberType.Column, B = 0.25, H = 0.25 });
        m.Members.Add(new Member { Id = 6, NodeI = 1, NodeJ = 7, Type = MemberType.Beam });
        beams = b.ToArray(); cols = new[] { 4, 5 };
        return m;
    }

    [Fact]
    public void BeamChain_FollowsCollinearBeams_IgnoresPerpendicular()
    {
        var m = Frame(out _, out _);
        Assert.Equal(new[] { 1, 2, 3 }, PreDesign.BeamChain(m, 2));
        Assert.Equal(new[] { 6 }, PreDesign.BeamChain(m, 6));
    }

    [Fact]
    public void ColumnStack_ReturnsBottomToTop()
    {
        var m = Frame(out _, out _);
        Assert.Equal(new[] { 4, 5 }, PreDesign.ColumnStack(m, 5));
        Assert.Equal(new[] { 4, 5 }, PreDesign.ColumnStack(m, 4));
    }

    [Fact]
    public void ContinuousBeam_GetsUniformSection_L13()
    {
        var m = Frame(out _, out _);
        var rep = PreDesign.Members(m, new[] { 1 }, null, true);
        Assert.Equal(3, rep.Items.Count);
        Assert.All(rep.Items, i => { Assert.Equal(0.40, i.NewH, 3); Assert.Equal(0.25, i.NewB, 3); });   // 5/13 = 0,385 -> 0,40
        var single = PreDesign.Members(m, new[] { 1 }, null, false);
        Assert.Single(single.Items);
        Assert.Equal(0.50, single.Items[0].NewH, 3);                                                     // 5/11 = 0,4545 -> 0,50
    }

    [Fact]
    public void Beam_ResultsMakeSectionGrow()
    {
        var m = Frame(out _, out _);
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 2, MuSag = 400, MuHog = -450, Vu = 300 });
        var plain = PreDesign.Members(m, new[] { 2 }, null, true).Items[0];
        var with = PreDesign.Members(m, new[] { 2 }, o, true).Items[0];
        Assert.True(with.NewH > plain.NewH);
        double d = with.NewH - m.Members[1].Cover, fbu = 0.85 * 25 / 1.5;
        Assert.True(450 / 1000.0 <= 0.30 * with.NewB * d * d * fbu + 1e-9);
    }

    [Fact]
    public void ColumnStack_NeverSmallerAtBottom_AndMinimumRespected()
    {
        var m = Frame(out _, out _);
        m.Seismic.Enabled = true; m.Seismic.Zone = "IIa";
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 4, NuMax = 2400 });
        o.Members.Add(new MemberDesignResult { MemberId = 5, NuMax = 900 });
        var rep = PreDesign.Members(m, new[] { 5 }, o, true);
        var low = rep.Items.First(i => i.MemberId == 4); var up = rep.Items.First(i => i.MemberId == 5);
        Assert.True(low.NewB >= up.NewB && low.NewH >= up.NewH);
        Assert.True(up.NewB >= 0.30 - 1e-9 && up.NewH >= 0.30 - 1e-9);
        Assert.True(low.NewB * low.NewH >= 2400 / (0.40 * 25 * 1000.0) - 1e-9);
    }

    [Fact]
    public void Slab_Rules()
    {
        var m = new StructModel();
        var s = new SlabPanel { Lx = 4, Ly = 5, Continuity = SlabContinuity.Rive };
        Assert.Equal(0.12, PreDesign.Slab(m, s).V["H"], 3);             // 4/40 = 10 cm -> minimum 12 cm
        s.Lx = 6; s.Ly = 7; Assert.Equal(0.15, PreDesign.Slab(m, s).V["H"], 3);               // 6/40
        s.Lx = 2; s.Ly = 8; s.Continuity = SlabContinuity.Interieure; Assert.Equal(0.12, PreDesign.Slab(m, s).V["H"], 3);
        s.Kind = SlabKind.CorpsCreux; s.Lx = 4; s.Ly = 6; var r = PreDesign.Slab(m, s);
        Assert.Equal(0.20, r.V["H"], 3);                                                       // 4/22,5 = 17,8 -> 16+4
        Assert.Equal(16.0, r.V["HourdisCm"]);
    }

    [Fact]
    public void Stair_Blondel_Holds()
    {
        var d = new StairDef { HeightM = 3.06, Layout = StairLayout.DroitPalier, Usage = StairUsage.Public, WidthM = 1.0 };
        var r = PreDesign.Stair(d);
        double h = r.V["RiserCm"] / 100, g = r.V["TreadCm"] / 100;
        Assert.InRange(2 * h + g, 0.60, 0.66);
        Assert.Equal(18.0, r.V["Steps"]);
        Assert.Equal(1.40, r.V["WidthM"], 3);
        Assert.True(r.V["SlabCm"] >= 12);
    }

    [Fact]
    public void Footing_SurfaceFromReaction()
    {
        var m = Frame(out _, out _);
        m.SigmaSolKPa = 200;
        Assert.Equal(0.0, PreDesign.Footing(m, 5, null).V["Valid"]);
        var o = new AnalysisOutput { Global = new GlobalResults() };
        var rr = new ReactionRow { NodeId = 5, FzService = 880 };
        rr.Max[2] = 1200;
        o.Global.Reactions.Add(rr);
        var r = PreDesign.Footing(m, 5, o);
        Assert.Equal(1.0, r.V["Valid"]);
        Assert.True(r.V["A"] * r.V["B"] >= 1.1 * 880 / 200.0 - 1e-9);
        Assert.True(r.V["H"] >= 0.30);
    }

    [Fact]
    public void Shells_WallAndSlab_Thickness()
    {
        var m = new StructModel { IncludeSelfWeight = false };
        ShellMesh.AddWall(m, "V1", 0, 0, 0, 0, 4, 3.0, 0.15, 0.5);
        Assert.True(m.Shells.Count > 0);
        var w = PreDesign.Shell(m, "V1");
        Assert.Equal(1.0, w.V["Valid"]);
        Assert.Equal(0.15, w.V["T"], 3);                                    // he/20 = 15 cm
        Assert.Equal(0.0, PreDesign.Shell(m, "inconnu").V["Valid"]);
    }
}
