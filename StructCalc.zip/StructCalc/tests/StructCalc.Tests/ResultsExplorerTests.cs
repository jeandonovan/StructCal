using System.IO.Compression;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Results;
using StructCalc.Engine.Structure;
using Xunit;

/// <summary>Résultats détaillés : sources (cas, combinaisons, enveloppes), réactions avec combinaison responsable, tableaux, exports CSV / Excel.</summary>
public class ResultsExplorerTests
{
    private static (StructModel M, AnalysisOutput O) Run()
    {
        var m = ExampleModels.Portal();
        var o = ProjectAnalyzer.Run(m, false);
        return (m, o);
    }

    [Fact]
    public void Store_IsBuilt_AndEnvelopeContainsEachCombination()
    {
        var (m, o) = Run();
        Assert.NotNull(o.Store);
        var st = o.Store!;
        Assert.Contains(ResultsStore.EnvUls, st.ForceSources());
        int id = m.Members.First(x => x.Type == MemberType.Beam).Id;
        var env = st.Series(ResultsStore.EnvUls, id, ForceQty.My);
        Assert.True(env.X.Length > 5);
        // l'enveloppe est au moins aussi grande que chacune des combinaisons ELU
        foreach (var c in st.Uls)
        {
            var one = st.Series(c.Name, id, ForceQty.My);
            for (int k = 0; k < env.X.Length; k++)
            {
                Assert.True(env.Max[k] >= one.Max[k] - 1e-9);
                Assert.True(env.Min[k] <= one.Min[k] + 1e-9);
            }
        }
        Assert.All(env.MaxCombo, c => Assert.False(string.IsNullOrEmpty(c)));
    }

    [Fact]
    public void Reactions_ReportGoverningCombination_AndBalanceVerticalLoad()
    {
        var (m, o) = Run();
        var st = o.Store!;
        var r = st.Reactions(ResultsStore.EnvUls);
        Assert.NotEmpty(r);
        Assert.All(r, x => Assert.False(string.IsNullOrEmpty(x.MaxCombo[2])));
        // réaction totale du cas G = somme des réactions verticales du cas
        double sum = st.Reactions("Cas G").Sum(x => x.Max[2]);
        Assert.Equal(o.Global!.TotalFzByCase["G"], sum, 2);
    }

    [Fact]
    public void Tables_AreBuilt_ForEveryCatalogEntry()
    {
        var (m, o) = Run();
        foreach (var spec in ResultTables.Catalog(m, o, ResultsStore.EnvUls, new ResultFilter()))
        {
            var t = spec.Build();
            Assert.False(string.IsNullOrEmpty(t.Title));
            Assert.All(t.Rows, row => Assert.True(row.Length <= t.Headers.Count, spec.Name));
        }
    }

    [Fact]
    public void Compliance_ListsOnlyAllowedStatuses()
    {
        var (m, o) = Run();
        var t = ResultTables.Compliance(m, o);
        Assert.NotEmpty(t.Rows);
        var allowed = new[] { "Vérifié", "À la limite", "Non vérifié", "À contrôler manuellement" };
        Assert.All(t.Rows, r => Assert.Contains((string)r[^1]!, allowed));
        var (ok, lim, ko, man) = ResultTables.ComplianceCounts(t);
        Assert.Equal(t.Rows.Count, ok + lim + ko + man);
    }

    [Fact]
    public void Stresses_AreConsistentWithAxialAndBending()
    {
        var (m, o) = Run();
        var t = ResultTables.Stresses(m, o.Store!, ResultsStore.EnvSls, new ResultFilter());
        Assert.NotEmpty(t.Rows);
        foreach (var r in t.Rows)
        {
            double tens = Convert.ToDouble(r[5]), comp = Convert.ToDouble(r[8]);
            Assert.True(tens >= comp - 1e-9);               // la fibre tendue est plus tendue que la fibre comprimée
        }
    }

    [Fact]
    public void SlabStress_PrincipalMoments_AndSampling()
    {
        var f = new SlabField { Name = "D1", X0 = 0, Y0 = 0, Lx = 4, Ly = 4, H = 0.2, Nx = 2, Ny = 2 };
        double[,] A(double v) { var a = new double[3, 3]; for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) a[i, j] = v; return a; }
        f.Values[SlabFieldKind.Mx] = A(10); f.Values[SlabFieldKind.My] = A(2); f.Values[SlabFieldKind.Mxy] = A(3);
        SlabStress.Extend(f);
        Assert.Equal(6 + 5.0, f.Values[SlabFieldKind.M1][1, 1], 6);       // (10+2)/2 ± √(16+9)
        Assert.Equal(6 - 5.0, f.Values[SlabFieldKind.M2][1, 1], 6);
        Assert.Equal(6 * 10 / (0.2 * 0.2) / 1000.0, f.Values[SlabFieldKind.SigmaX][0, 0], 6);
        Assert.Equal(11.0, SlabStress.Sample(f, SlabFieldKind.M1, 2, 2), 6);
        Assert.True(double.IsNaN(SlabStress.Sample(f, SlabFieldKind.M1, 9, 2)));
        var cut = ResultTables.SlabCut(new[] { f }, SlabFieldKind.Mx, 0, 2, 4, 2, 10);
        Assert.Equal(11, cut.Count);
        Assert.All(cut, p => Assert.Equal(10, p.V, 6));
    }

    [Fact]
    public void TableData_ExportsCsvAndValidXlsx()
    {
        var t = new TableData("Test: [feuille]/1", "A", "B", "C");
        t.Add("x;y", 1.5, null).Add("é<&>", 2, double.NaN);
        string csv = t.ToCsv();
        Assert.Contains("\"x;y\"", csv);
        Assert.Contains("A;B;C", csv);
        var bytes = TableData.ToXlsx(new[] { t, new TableData("Test: [feuille]/1", "Z") });
        using var zip = new ZipArchive(new MemoryStream(bytes), ZipArchiveMode.Read);
        var names = zip.Entries.Select(e => e.FullName).ToList();
        Assert.Contains("xl/workbook.xml", names);
        Assert.Contains("xl/worksheets/sheet1.xml", names);
        Assert.Contains("xl/worksheets/sheet2.xml", names);
        string wb = new StreamReader(zip.GetEntry("xl/workbook.xml")!.Open()).ReadToEnd();
        Assert.Contains("Test feuille1", wb);
        Assert.Contains("Test feuille1 2", wb);                           // nom en double rendu unique
        string sheet = new StreamReader(zip.GetEntry("xl/worksheets/sheet1.xml")!.Open()).ReadToEnd();
        Assert.Contains("&lt;&amp;&gt;", sheet);
        System.Xml.Linq.XDocument.Parse(sheet);                           // XML bien formé
    }

    [Fact]
    public void Reports_IncludeDetailedSections()
    {
        var (m, o) = Run();
        string html = ReportWriter.ToHtml(m, o);
        Assert.Contains("Résultats détaillés", html);
        Assert.Contains("Vérifications de conformité", html);
        Assert.Contains("CONFORMITE", PdfReport.BuildText(m, o));
    }

    [Fact]
    public void CrackedSection_PureBending_MatchesHandCalculation()
    {
        // b = 30 cm, h = 50 cm, As = 8 cm² (d = 45 cm), n = 15, M = 100 kN.m
        var r = ResultTables.CrackedStress(0.30, 0.50, 0.45, 0.05, 8e-4, 0, 15, 0, 100);
        Assert.NotNull(r);
        Assert.Equal(0.1539, r!.Value.Y, 3);
        Assert.Equal(10.86, r.Value.Sc / 1000, 1);                 // MPa
        Assert.Equal(15 * r.Value.Sc * (0.45 - r.Value.Y) / r.Value.Y / 1000, r.Value.Ss / 1000, 3);
        // équilibre : la résultante de compression du béton moins la traction de l'acier = effort normal (nul)
        double fc = 0.30 * r.Value.Y * r.Value.Sc / 2, fs = 8e-4 * r.Value.Ss;
        Assert.Equal(fc, fs, 1);
    }

    [Fact]
    public void CrackedSection_UncrackedColumnUnderLargeCompression_ReturnsNull()
    {
        Assert.Null(ResultTables.CrackedStress(0.40, 0.40, 0.36, 0.04, 6e-4, 6e-4, 15, 3000, 10));
    }

    [Fact]
    public void VerticalModal_MassFractionsAreBounded()
    {
        var m = ExampleModels.Portal();
        var r = ModalAnalysis.Compute(m, 10, true);
        Assert.True(r.Vertical);
        Assert.True(r.CumulZ <= 1.0001);
        Assert.All(r.Modes, md => Assert.True(md.RatioZ >= 0 && md.RatioZ <= 1.0001));
    }

    [Fact]
    public void SeismicDirections_AreEmptyWhenSeismicIsOff_AndComparedWhenOn()
    {
        var (m, o) = Run();
        m.Seismic.Enabled = false;
        Assert.Empty(new ResultsStore(m, o.Store!.Cases, o.Store.Combos).SeismicDirections());
        m.Seismic.Enabled = true;
        var orig = m.Seismic.Direction;
        var dirs = new ResultsStore(m, o.Store.Cases, o.Store.Combos).SeismicDirections();
        Assert.Equal(orig, m.Seismic.Direction);                       // la direction du projet est restaurée
        if (dirs.Count == 2) Assert.True(dirs[0].Vx != 0 || dirs[0].Vy != 0);
    }
}
