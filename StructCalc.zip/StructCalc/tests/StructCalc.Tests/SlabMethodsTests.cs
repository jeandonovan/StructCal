using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Walls;
using Xunit;

/// <summary>Maillage triangulé (DKT, CST) et méthodes de calcul des dalles.</summary>
public class SlabMethodsTests
{
    [Fact]
    public void SlabTri_SimplySupportedSquare_MatchesNavier()
    {
        SlabTri.Solve(12, 12, 1.0 / 12, 1.0 / 12, 1.0, 0.2, -1, -1, -1, -1, out var w, out var mx, out _, out _, out _, out _);
        Assert.InRange(w[6, 6], 0.00398, 0.00414);           // 0,00406 q a⁴ / D
        Assert.InRange(mx[6, 6], 0.040, 0.050);              // ≈ 0,0469 q a² (ν = 0,2), lissé par le maillage
    }

    [Fact]
    public void SlabTri_ClampedSquare_MatchesTimoshenko()
    {
        SlabTri.Solve(12, 12, 1.0 / 12, 1.0 / 12, 1.0, 0.2, 1, 1, 1, 1, out var w, out var mx, out _, out _, out _, out _);
        Assert.InRange(w[6, 6], 0.00122, 0.00133);           // 0,00126 q a⁴ / D
        Assert.InRange(mx[0, 6], -0.056, -0.044);            // moment d'encastrement ≈ -0,0513 q a²
    }

    [Fact]
    public void ShellTri_RigidBodyModes_GiveNoForce()
    {
        var p = new ShellElement.Props { A = 0.8, B = 0.5, T = 0.15, E = 3e10, Nu = 0.2 };
        foreach (bool diag in new[] { true, false })
        {
            var k = ShellTri.Stiffness(p, diag);
            foreach (int comp in new[] { 0, 1, 2 })
            {
                var u = new double[20];
                for (int n = 0; n < 4; n++) u[5 * n + comp] = 1.0;
                double maxF = 0, kmax = 0;
                for (int i = 0; i < 20; i++)
                {
                    double f = 0; for (int j = 0; j < 20; j++) { f += k[i, j] * u[j]; kmax = Math.Max(kmax, Math.Abs(k[i, j])); }
                    maxF = Math.Max(maxF, Math.Abs(f));
                }
                Assert.True(maxF < 1e-7 * kmax, $"mode {comp} diag {diag} : {maxF} / {kmax}");
            }
            for (int i = 0; i < 20; i++) for (int j = 0; j < i; j++) Assert.True(Math.Abs(k[i, j] - k[j, i]) < 1e-6 * Math.Abs(k[i, i]) + 1e-3);
        }
    }

    [Fact]
    public void YieldLine_Square_MatchesJohansen()
    {
        Assert.Equal(10 * 4 / 24.0, SlabMethods.YieldMoment(2, 2, 10, new double[] { 0, 0, 0, 0 }), 2);
        Assert.Equal(10 * 4 / 48.0, SlabMethods.YieldMoment(2, 2, 10, new double[] { 1, 1, 1, 1 }), 2);
    }

    [Theory]
    [InlineData("Forfaitaire")]
    [InlineData("Caquot")]
    [InlineData("CaquotMinoree")]
    [InlineData("LignesRupture")]
    [InlineData("Bandes")]
    [InlineData("DDM")]
    [InlineData("ElementsFinis")]
    public void EveryMethod_DesignsASlab(string id)
    {
        var m = new StructModel();
        m.Settings.MeshPreset = "Grossier";
        var s = new SlabPanel { Name = "D1", Lx = 4, Ly = 5, H = 0.18, GExtra = 1.5, Q = 2.5, Continuity = SlabContinuity.Interieure };
        var rc = new Bael91Code();
        var input = new SlabInput(s.Lx, s.Ly, s.H, s.GExtra, s.Q, s.Continuity, 25, 500, CrackingClass.PeuPrejudiciable, 0.03, m.Settings);
        var r = SlabMethods.Design(m, s, rc, input, id);
        Assert.True(r.Texts.ContainsKey("Travée sens lx"), string.Join("|", r.Warnings));
        Assert.True(r.Values["Asx_travee_cm2m"] > 0);
        Assert.Contains(r.Notes, n => n.StartsWith("Méthode de calcul"));
    }

    [Fact]
    public void Caquot_SimplySupportedSlab_HasNoSupportMoment()
    {
        // dalle isolée sur appuis simples (aucun prolongement fictif) : pas de moment d'appui, travée = moment isostatique
        var m = new StructModel();
        var s = new SlabPanel { Name = "D1", Placed = true, X0 = 0, Y0 = 0, Lx = 4, Ly = 12, H = 0.16, GExtra = 1.5, Q = 5, Continuity = SlabContinuity.Simple };
        var input = new SlabInput(s.Lx, s.Ly, s.H, s.GExtra, s.Q, s.Continuity, 25, 500, CrackingClass.PeuPrejudiciable, 0.03, m.Settings);
        var mo = SlabMethods.Moments(m, s, input, "Caquot");
        Assert.NotNull(mo);
        Assert.True(mo!.MtxU > 0);
        Assert.Equal(0, mo.MaxU, 6);                          // aucun appui continu
    }

    [Fact]
    public void Wall_Triangulated_RunsAndSaysSo()
    {
        var w = new WallDef { Name = "V1", LengthM = 4, HeightM = 3, ThicknessM = 0.2, MeshMode = "Grossier", WindKPa = 5, MeshElement = "Tri" };
        var res = WallDesigner.Design(w, new Bael91Code(), 25, 500, new DesignSettings());
        Assert.True(res.Triangulated);
        Assert.Contains("triangles", res.Report);
    }
}
