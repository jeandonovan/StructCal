using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Detailing;
using Xunit;

/// <summary>Étape 5 : dispositions constructives. Valeurs attendues calculées à la main (voir commentaires).</summary>
public class RebarDetailingTests
{
    private static void Near(string cas, double expected, double actual, double tol)
        => Assert.True(Math.Abs(expected - actual) <= tol, $"[Détail {cas}] attendu {expected:0.###}, obtenu {actual:0.###} (tolérance {tol}).");

    // ---------------------------------------------------------------- longueurs développées
    [Fact]
    public void Barre_en_L_longueur_developpee()
    {
        // axe : 500 + 300 mm, phi 16, mandrin 4 phi = 64 => R = 40 ; tangente 40 ; arc 40 x pi/2 = 62,832 ; total = 460 + 260 + 62,832 = 782,832
        var b = DevelopedLength.Of(new[] { (0.0, 0.0), (500.0, 0.0), (500.0, 300.0) }, 16, 64);
        Assert.True(b.Valid, b.Message);
        Near("L 500+300", 782.832, b.LengthMm, 0.01);
        Near("L gain de cintrage", 800 - 782.832, DevelopedLength.BendGainMm(90, 16, 64), 0.01);
    }

    [Fact]
    public void Barre_droite_garde_sa_longueur()
    {
        var b = DevelopedLength.Of(new[] { (0.0, 0.0), (1000.0, 0.0) }, 12, 48);
        Near("droite", 1000, b.LengthMm, 1e-9);
    }

    [Fact]
    public void Segment_trop_court_pour_le_cintrage_est_signale()
    {
        var b = DevelopedLength.Of(new[] { (0.0, 0.0), (30.0, 0.0), (30.0, 300.0) }, 16, 64);      // tangente 40 mm > 30 mm
        Assert.False(b.Valid);
        Assert.Contains("plus court", b.Message);
    }

    [Fact]
    public void Retour_sur_soi_est_refuse()
    {
        var b = DevelopedLength.Of(new[] { (0.0, 0.0), (300.0, 0.0), (0.0, 0.0) }, 12, 48);
        Assert.False(b.Valid);
    }

    [Fact]
    public void Barre_en_U_somme_de_deux_plis()
    {
        // 300 + 200 + 300 (U à angles droits), phi 12, mandrin 48 => R = 30 ; gain par pli = 30 (2 - pi/2) = 12,876 ; développée = 800 - 2 x 12,876 = 774,248
        var b = DevelopedLength.Of(new[] { (0.0, 300.0), (0.0, 0.0), (200.0, 0.0), (200.0, 300.0) }, 12, 48);
        Assert.True(b.Valid, b.Message);
        Near("U", 800 - 2 * DevelopedLength.BendGainMm(90, 12, 48), b.LengthMm, 0.01);
        Near("U valeur", 774.248, b.LengthMm, 0.01);
    }

    [Fact]
    public void Cadre_25x50_developpee()
    {
        // b=250 h=500 enrobage 25 phi 8 mandrin 32 : axe 192 x 442 ; périmètre 1268 ; R = 20 ; gain 4 x 8,584 = 34,337 ; crochet : 20 x 135° (47,124) + retour 80 = 127,124 x 2 = 254,248 ; total 1487,911
        Near("cadre", 1487.911, DevelopedLength.Stirrup(250, 500, 25, 8, 32), 0.01);
    }

    // ---------------------------------------------------------------- décalage des recouvrements
    [Fact]
    public void Six_barres_alternees_donnent_50_pour_cent_au_plus()
    {
        var plan = LapStagger.Plan(6, 0.6);
        Near("décalage groupe 2", 0.78, plan[1].OffsetM, 1e-9);                        // 1,3 x 0,60
        Near("part recouverte", 0.5, LapStagger.MaxLappedFraction(plan, 0.6), 1e-9);
        Assert.True(LapStagger.Ok(plan, 0.6));
    }

    [Fact]
    public void Recouvrements_tous_alignes_depassent_50_pour_cent()
    {
        var aligned = Enumerable.Range(0, 4).Select(i => new LapPlacement(i, 0, 0)).ToList();
        Near("alignés", 1.0, LapStagger.MaxLappedFraction(aligned, 0.6), 1e-9);
        Assert.False(LapStagger.Ok(aligned, 0.6));
    }

    [Fact]
    public void Une_seule_barre_ne_peut_pas_etre_decalee()
        => Assert.False(LapStagger.Ok(LapStagger.Plan(1, 0.6), 0.6), "[Détail recouvrement] une barre isolée ne respecte pas la règle des 50 %.");

    // ---------------------------------------------------------------- armatures de couture
    [Fact]
    public void Couture_table_tendue_et_comprimee()
    {
        // dF = 300 kN sur 2 m, hf = 0,15 m : vEd = 0,3 / (0,15 x 2) = 1,0 MPa ; fyd = 500/1,15 = 434,78 ; As = 1,0 x 0,15 / 434,78 = 3,45 cm²/m (table tendue, cot = 1) ; 2,76 (comprimée, cot = 1,25)
        var t = FlangeWebStitching.Design(300, 2, 0.15, 500, 25, compressionFlange: false);
        Near("vEd", 1.0, t.VedMPa, 1e-9);
        Near("As tendue", 3.45, t.AsPerMetreCm2, 0.01);
        Assert.True(t.StrutOk);
        Near("Vrd,max", 4.5, t.VrdMaxMPa, 0.001);               // 0,54 x 16,667 x 0,5
        var c = FlangeWebStitching.Design(300, 2, 0.15, 500, 25, compressionFlange: true);
        Near("As comprimée", 2.76, c.AsPerMetreCm2, 0.01);
    }

    [Fact]
    public void Couture_bielle_ecrasee_est_signalee()
    {
        var t = FlangeWebStitching.Design(3000, 1, 0.10, 500, 25, false);              // vEd = 30 MPa
        Assert.False(t.StrutOk);
        Assert.Contains("écrasée", t.Note);
    }

    // ---------------------------------------------------------------- ancrage sur les vrais appuis
    private static (StructModel m, AnalysisOutput o) BeamOnColumns(double colB, int dia)
    {
        var m = new StructModel { Fc28 = 25, Fe = 500 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); m.Nodes.Add(new Node { Id = 2, X = 4, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 3, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 4, X = 4, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 3, Type = MemberType.Column, B = colB, H = colB });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 4, Type = MemberType.Column, B = colB, H = colB });
        m.Members.Add(new Member { Id = 3, NodeI = 3, NodeJ = 4, Type = MemberType.Beam, B = 0.25, H = 0.45 });
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 3, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, BotDia = dia, BotN = 3 });
        return (m, o);
    }

    [Fact]
    public void Ancrage_sur_poteau_trop_etroit_est_refuse()
    {
        // HA20 : ls = 20 x 500 / (4 x 2,835) = 881,8 mm ; 0,4 ls = 352,7 mm ; poteau 30 cm : disponible 260 mm => insuffisant
        var (m, o) = BeamOnColumns(0.30, 20);
        var rows = SupportAnchorage.Evaluate(m, o, 25, 500);
        Assert.Equal(2, rows.Count);
        Assert.All(rows, r => { Near("ls HA20", 881.8, r.LsMm, 0.2); Near("0,4 ls", 352.7, r.HookMm, 0.1); Near("disponible", 260, r.AvailMm, 1e-9); Assert.Equal("Non vérifiée", r.Verdict); Assert.Equal("poteau", r.Support); });
    }

    [Fact]
    public void Ancrage_sur_poteau_large_accepte_le_crochet()
    {
        var (m, o) = BeamOnColumns(0.40, 20);                            // disponible 360 mm >= 352,7 mm
        var rows = SupportAnchorage.Evaluate(m, o, 25, 500);
        Assert.All(rows, r => { Assert.Equal("crochet normal", r.Solution); Assert.Equal("Vérifiée", r.Verdict); });
    }

    [Fact]
    public void Ancrage_poutre_sur_poutre_porteuse()
    {
        var m = new StructModel { Fc28 = 25, Fe = 500 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 4, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 5, X = 4, Y = 5, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.25, H = 0.45 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 5, Type = MemberType.Beam, B = 0.30, H = 0.50 });
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, BotDia = 12, BotN = 3 });
        var r = Assert.Single(SupportAnchorage.Evaluate(m, o, 25, 500));
        Assert.Equal("poutre porteuse", r.Support);
        Near("disponible = B - 4 cm", 260, r.AvailMm, 1e-9);
        Assert.Equal("Vérifiée", r.Verdict);                              // HA12 : 0,4 ls = 211,6 mm <= 260 mm
    }

    [Fact]
    public void Poutre_prolongee_n_est_pas_un_appui_d_extremite()
    {
        var m = new StructModel { Fc28 = 25, Fe = 500 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 2, X = 4, Y = 0, Z = 3 }); m.Nodes.Add(new Node { Id = 3, X = 8, Y = 0, Z = 3 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Beam, B = 0.25, H = 0.45 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, Type = MemberType.Beam, B = 0.25, H = 0.45 });
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, BotDia = 12, BotN = 3 });
        Assert.Empty(SupportAnchorage.Evaluate(m, o, 25, 500));
    }

    // ---------------------------------------------------------------- zones de confinement
    [Fact]
    public void Zone_de_confinement_listee_et_sans_exigence_signalee()
    {
        var o = new AnalysisOutput();
        o.Members.Add(new MemberDesignResult { MemberId = 1, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, StirDia = 8, StirSpacingCm = 15, NodalSpacingCm = 10, NodalZoneM = 0.5 });
        o.Members.Add(new MemberDesignResult { MemberId = 2, Type = MemberType.Beam, Kind = MaterialKind.ReinforcedConcrete, StirDia = 8, StirSpacingCm = 15, NodalSpacingCm = 0 });
        var l = ConfinementZones.Collect(o);
        Assert.Equal(2, l.Count);
        Near("zone", 0.5, l[0].ZoneM, 1e-9);
        Assert.Contains("resserrés", l[0].Note);
        Assert.Contains("aucune exigence", l[1].Note);
        Assert.Contains("Zones de confinement", ConfinementZones.ToHtml(o));
    }
}
