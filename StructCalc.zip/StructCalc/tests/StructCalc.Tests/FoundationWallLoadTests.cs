using StructCalc.Core.Model;
using StructCalc.Engine.Structure;
using Xunit;

namespace StructCalc.Tests;

public class FoundationWallLoadTests
{
    [Fact]
    public void Footing_WithWallLoads_AddsFactoredLoads()
    {
        var f = new FootingDef { Kind = FootingKind.Filante, NuKN = 10, NserKN = 7 };
        f.WallLoads.Add(new LineLoadItem { Text = "mur", GKnM = 12.15, QKnM = 2 });
        var t = f.WithWallLoads();
        Assert.Equal(10 + 1.35 * 12.15 + 3.0, t.NuKN, 6);
        Assert.Equal(7 + 14.15, t.NserKN, 6);
        Assert.Empty(t.WallLoads);
        Assert.Single(f.WallLoads);
        Assert.Single(f.Clone().WallLoads);
    }

    [Fact]
    public void Raft_LineLoad_IsSplitIntoSegmentsWithTotalLoad()
    {
        var l = new RaftLineLoad { Text = "mur", X1 = 0, Y1 = 0, X2 = 5, Y2 = 0, GKnM = 10, QKnM = 0 };
        var loads = RaftDesigner.LineLoadLoads(l);
        Assert.Equal(5, loads.Count);
        Assert.Equal(5 * 10 * 1.35, loads.Sum(x => x.Nu), 6);
        Assert.Equal(50, loads.Sum(x => x.Ns), 6);
    }
}
