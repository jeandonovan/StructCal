using StructCalc.Core.Loads;
using Xunit;

namespace StructCalc.Tests;

public class LoadCatalogTests
{
    [Fact]
    public void Wall_BriquesPleines_21_5cm_3m_Is_12_15()
    {
        var w = LoadCatalog.Wall(LoadCatalog.Find("bp")!, 21.5, 3.0, 0, null, 0, 0, RangeMode.Max);
        Assert.Equal(4.05, w.MasonryKnM2, 6);
        Assert.Equal(12.15, w.LinearKnM, 6);
        Assert.False(w.OutsideTable);
    }

    [Fact]
    public void Wall_Interpolates_And_Adds_Plaster_And_Openings()
    {
        var w = LoadCatalog.Wall(LoadCatalog.Find("bc")!, 12.5, 2.8, 2, LoadCatalog.Find("enm"), 1.5, 20, RangeMode.Max);
        Assert.Equal(1.1, w.MasonryKnM2, 6);                 // entre 0,9 (10 cm) et 1,3 (15 cm)
        Assert.Equal(2 * 0.18 * 1.5, w.PlasterKnM2, 6);
        Assert.Equal((1.1 + 0.54) * 2.8 * 0.8, w.LinearKnM, 6);
    }

    [Fact]
    public void Range_Modes_Pick_Min_Mean_Max()
    {
        var it = LoadCatalog.Find("bap")!;
        Assert.Equal(1.6, it.Surface(10, RangeMode.Max, out _), 6);
        Assert.Equal(0.9, it.Surface(10, RangeMode.Min, out _), 6);
        Assert.Equal(1.25, it.Surface(10, RangeMode.Mean, out _), 6);
    }

    [Fact]
    public void Outside_Table_Is_Flagged_And_PerCm_Is_Linear()
    {
        var bc = LoadCatalog.Find("bc")!;
        bc.Surface(40, RangeMode.Max, out bool outside);
        Assert.True(outside);
        Assert.Equal(0.1 * 7, LoadCatalog.Find("plat")!.Surface(7, RangeMode.Max, out _), 6);
        Assert.Equal(0.25 * 20, LoadCatalog.Find("dalle")!.Surface(20, RangeMode.Max, out _), 6);
    }

    [Fact]
    public void Partition_Equivalent_And_Catalog_Integrity()
    {
        Assert.Equal(0.5, LoadCatalog.PartitionEquivalent(0.8));
        Assert.Equal(0.8, LoadCatalog.PartitionEquivalent(1.5));
        Assert.Equal(1.2, LoadCatalog.PartitionEquivalent(2.5));
        Assert.True(double.IsNaN(LoadCatalog.PartitionEquivalent(4)));
        Assert.Equal(LoadCatalog.Items.Count, LoadCatalog.Items.Select(i => i.Id).Distinct().Count());
        Assert.All(LoadCatalog.Items.Where(i => i.Unit == CatalogUnit.Table), i => Assert.True(i.Points.Length >= 2));
        Assert.Equal(25.0, LoadCatalog.Find("ba")!.Volumic(), 6);
    }
}
