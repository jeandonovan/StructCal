@echo off
chcp 65001 >nul
echo ===============================================================
echo  Associe les fichiers .stcx a StructCalc (double-clic = ouverture)
echo  Pour la version de developpement (compilee dans ce dossier).
echo  La version installee par Setup.exe le fait deja toute seule.
echo ===============================================================
set "EXE=%~dp0src\StructCalc.App\bin\Debug\net8.0-windows10.0.19041.0\StructCalc.App.exe"
if not exist "%EXE%" (
  echo StructCalc.App.exe introuvable : lancez d'abord restaurer_compiler_tester.bat
  goto fin
)
set "ICO=%~dp0src\StructCalc.App\bin\Debug\net8.0-windows10.0.19041.0\StructCalcFile.ico"
reg add "HKCU\Software\Classes\.stcx" /ve /d "StructCalc.Projet" /f >nul
reg add "HKCU\Software\Classes\StructCalc.Projet" /ve /d "Projet StructCalc" /f >nul
reg add "HKCU\Software\Classes\StructCalc.Projet\DefaultIcon" /ve /d "%ICO%" /f >nul
reg add "HKCU\Software\Classes\StructCalc.Projet\shell\open\command" /ve /d "\"%EXE%\" \"%%1\"" /f >nul
echo Association faite pour : %EXE%
echo Si l'icone ne change pas tout de suite, redemarrez l'Explorateur Windows (ou deconnectez-vous).
:fin
pause
