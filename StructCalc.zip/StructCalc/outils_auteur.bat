@echo off
chcp 65001 >nul
title StructCalc - Outils de l'auteur (PRIVE)
cd /d "%~dp0"
echo ============================================================
echo   OUTILS DE L'AUTEUR - ne jamais distribuer ce dossier "tools"
echo ============================================================
set TOOL=%~dp0publish\_outil_menu
if exist "%TOOL%" rmdir /s /q "%TOOL%" 2>nul
dotnet publish tools\StructCalc.LicenseGen -c Release -o "%TOOL%" --self-contained false
if errorlevel 1 goto fin
"%TOOL%\StructCalc.LicenseGen.exe"
:fin
pause
