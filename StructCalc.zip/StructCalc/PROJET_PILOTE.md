# Projet pilote R+1 : scénario de bout en bout

Objectif : prouver, sur un petit bâtiment réel de bout en bout, que la chaîne StructCalc ⇄ Revit tient. Rien ici n'est déclaré « validé » tant que la case n'est pas cochée par une personne.

## Modèle de départ
Accueil > Modèles > **Projet pilote R+1** : ossature 3D 2 x 1 travées (4,50 m x 4,00 m), 2 niveaux de 3,00 m, 12 poteaux 25x25, 14 poutres 25x40, 4 dalles posées (h = 16 cm),
un escalier à deux volées (3,00 m), un voile (4,50 x 3,00 x 0,20 m), sol 200 kPa (semelles calculées après le calcul).

## Partie automatique (tests `PilotProjectTests`, exécutés par `restaurer_compiler_tester.bat`)
- [ ] le modèle ne contient aucune erreur de vérification ;
- [ ] le calcul passe, chaque barre est traitée, chaque poutre a ses armatures et ses cadres, des semelles sont calculées ;
- [ ] métré, note de calcul HTML/texte et planches de plans sont produits, aucune planche vide ;
- [ ] le résumé pour Revit contient chaque barre liée une seule fois ;
- [ ] enregistrer puis relire le projet redonne exactement les mêmes armatures.

## Partie manuelle (à faire par une personne, avec Revit)
1. [ ] Recréer (ou ouvrir) la maquette Revit correspondante, **Envoyer vers StructCalc**. Vérifier le nombre de barres, dalles, voile, escalier annoncé.
2. [ ] Dans StructCalc : ajouter les charges, F5. Relever les NON OK et les corriger avec les assistants.
3. [ ] **Envoyer les résultats à Revit** puis **Importer résultats** : contrôler 3 poutres et 2 poteaux au hasard (section, armatures, état).
4. [ ] **Créer armatures** : contrôler en 3D une poutre, un poteau, une dalle, l'escalier (barres bien dans le béton, enrobage, pas de doublon).
5. [ ] Modifier dans Revit la section d'une poutre et déplacer un poteau, ré-exporter, puis dans StructCalc : Fichier > **Mettre à jour depuis Revit**. Contrôler que le compte rendu annonce exactement ces deux modifications, que les charges sont conservées, qu'aucune barre n'est dupliquée.
6. [ ] **Plans d'exécution** : pas de textes qui se chevauchent sur les feuilles ; cotes cohérentes avec la maquette.
7. [ ] Note de calcul : relire les sections 5b (vérifications), 5c (ancrages sur appuis réels), 5d (zones de confinement).
8. [ ] Comparer 2 ou 3 éléments (une poutre, un poteau, une semelle) à Robot / ETABS ou à un calcul manuel, et consigner l'écart dans `VALIDATION_MOTEUR.md`.

## Ce que ce scénario ne prouve pas
Qu'un résultat soit juste : seul le point 8 le fait, élément par élément.
