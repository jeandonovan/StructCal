; Installateur StructCalc (Inno Setup 6) - lance par publier_version.bat apres signature du dossier publish\StructCalc
[Setup]
AppId={{7C1E5B1A-4D52-4B7A-9E0F-5A7C3C0D2E11}
AppName=StructCalc
AppVersion=3.18
AppPublisher=Maximilien EKRESSIN
AppPublisherURL=mailto:jeandonovan33@gmail.com
DefaultDirName={autopf}\StructCalc
DefaultGroupName=StructCalc
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=publish
OutputBaseFilename=StructCalc_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ChangesAssociations=yes
UninstallDisplayIcon={app}\StructCalc.App.exe
; Decommentez pour afficher le contrat de licence avant l'installation (texte brut) :
; LicenseFile=CLUF_MODELE.txt

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis :"

[Files]
Source: "publish\StructCalc\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\StructCalc"; Filename: "{app}\StructCalc.App.exe"
Name: "{autodesktop}\StructCalc"; Filename: "{app}\StructCalc.App.exe"; Tasks: desktopicon

[Registry]
; association du type de fichier .stcx : double-clic = ouverture dans StructCalc, avec son icône
Root: HKA; Subkey: "Software\Classes\.stcx"; ValueType: string; ValueName: ""; ValueData: "StructCalc.Projet"; Flags: uninsdeletevalue
Root: HKA; Subkey: "Software\Classes\StructCalc.Projet"; ValueType: string; ValueName: ""; ValueData: "Projet StructCalc"; Flags: uninsdeletekey
Root: HKA; Subkey: "Software\Classes\StructCalc.Projet\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\StructCalcFile.ico"
Root: HKA; Subkey: "Software\Classes\StructCalc.Projet\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\StructCalc.App.exe"" ""%1"""

[Run]
Filename: "{app}\StructCalc.App.exe"; Description: "Lancer StructCalc"; Flags: nowait postinstall skipifsilent

; Complement Revit 2025 (inclus seulement si publier_version.bat l'a compile : necessite Revit 2025 sur la machine de l'auteur)
#ifexist "publish\StructCalc_Revit\StructCalc.addin"
[Tasks]
Name: "revitaddin"; Description: "Installer le complement StructCalc pour Revit 2025"; GroupDescription: "Revit :"; Flags: unchecked

[Files]
Source: "publish\StructCalc_Revit\StructCalc\*"; DestDir: "{userappdata}\Autodesk\Revit\Addins\2025\StructCalc"; Tasks: revitaddin; Flags: ignoreversion
Source: "publish\StructCalc_Revit\StructCalc.addin"; DestDir: "{userappdata}\Autodesk\Revit\Addins\2025"; Tasks: revitaddin; Flags: ignoreversion
#endif
