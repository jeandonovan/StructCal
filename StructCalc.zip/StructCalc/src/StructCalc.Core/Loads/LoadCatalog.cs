namespace StructCalc.Core.Loads;

public enum CatalogUnit { PerCm, Fixed, Table, Volumic }

/// <summary>Valeur retenue quand le tableau donne une fourchette (« 0,35 à 0,45 ») : Max = sécuritaire pour une charge permanente défavorable.</summary>
public enum RangeMode { Max, Mean, Min }

/// <summary>Point d'un tableau épaisseur - poids : épaisseur (cm) et poids surfacique minimal / maximal (kN/m²).</summary>
public sealed record CatalogPoint(double Thickness, double Min, double Max);

/// <summary>Ligne du catalogue des charges permanentes : maçonnerie, plancher, revêtement, toiture, isolant, enduit (kN/m²) ou matériau (kN/m³).</summary>
public sealed class CatalogItem
{
    public string Id { get; init; } = "";
    public string Group { get; init; } = "";
    public string Name { get; init; } = "";
    public CatalogUnit Unit { get; init; }
    /// <summary>PerCm : kN/m² par cm d'épaisseur ; Fixed : kN/m² ; Volumic : kN/m³.</summary>
    public double Min { get; init; }
    public double Max { get; init; }
    public CatalogPoint[] Points { get; init; } = Array.Empty<CatalogPoint>();
    public string Note { get; init; } = "";

    public bool NeedsThickness => Unit is CatalogUnit.PerCm or CatalogUnit.Table;
    public bool IsSurface => Unit != CatalogUnit.Volumic;

    private static double Pick(double min, double max, RangeMode m) => m switch { RangeMode.Min => min, RangeMode.Mean => (min + max) / 2, _ => max };

    /// <summary>Poids volumique (kN/m³) d'un matériau.</summary>
    public double Volumic(RangeMode m = RangeMode.Max) => Pick(Min, Max, m);

    /// <summary>Poids surfacique (kN/m²) pour l'épaisseur donnée (cm). Tableau : interpolation linéaire entre les épaisseurs du tableau, proportionnelle
    /// à l'épaisseur en dehors (<paramref name="outside"/> = vrai).</summary>
    public double Surface(double thicknessCm, RangeMode m, out bool outside)
    {
        outside = false;
        switch (Unit)
        {
            case CatalogUnit.Fixed: return Pick(Min, Max, m);
            case CatalogUnit.PerCm: return Pick(Min, Max, m) * Math.Max(thicknessCm, 0);
            case CatalogUnit.Table:
            {
                var p = Points;
                if (p.Length == 0 || thicknessCm <= 0) return 0;
                double G(CatalogPoint q) => Pick(q.Min, q.Max, m);
                if (thicknessCm < p[0].Thickness - 1e-9) { outside = true; return G(p[0]) * thicknessCm / p[0].Thickness; }
                if (thicknessCm > p[^1].Thickness + 1e-9) { outside = true; return G(p[^1]) * thicknessCm / p[^1].Thickness; }
                for (int i = 0; i + 1 < p.Length; i++)
                    if (thicknessCm <= p[i + 1].Thickness + 1e-9)
                    {
                        double f = (thicknessCm - p[i].Thickness) / (p[i + 1].Thickness - p[i].Thickness);
                        return G(p[i]) + f * (G(p[i + 1]) - G(p[i]));
                    }
                return G(p[^1]);
            }
            default: return 0;
        }
    }

    public override string ToString() => $"{Group} - {Name}";
}

/// <summary>Catégorie d'usage (EN 1991-1-1, Annexe Nationale française) : charge répartie qk, concentrée Qk, horizontale sur garde-corps.</summary>
public sealed record LiveCategory(string Id, string Name, double QkKnM2, double PointKn, double HorizKnM, string Note);

public sealed record WallLoadResult(double MasonryKnM2, double PlasterKnM2, double SurfaceKnM2, double LinearKnM, double PartitionEquivalentKnM2, bool OutsideTable);

/// <summary>Charges permanentes et d'exploitation du bâtiment : tableaux de la fiche NF P 06-004 (poids surfaciques des maçonneries, planchers, revêtements,
/// toitures, isolants, enduits ; poids volumiques) et de l'Annexe Nationale de la NF EN 1991-1-1 (charges d'exploitation, charges horizontales, cloisons).
/// Les valeurs sont indicatives (pays d'origine : France) : à confirmer avec les fiches techniques des produits et la réglementation locale.</summary>
public static class LoadCatalog
{
    public const string GMasTc = "Maçonnerie - terre cuite", GMasBeton = "Maçonnerie - blocs de béton", GMasOther = "Pierre, plâtre et revêtements de façade";
    public const string GFloor = "Planchers (enduit non compris)", GFinish = "Revêtements de plancher", GRoof = "Toitures", GInsul = "Isolants", GPlaster = "Enduits";
    public const string GMat = "Matériaux", GBulk = "Corps en vrac";

    public static readonly string[] MasonryGroups = { GMasTc, GMasBeton, GMasOther };
    public static readonly string[] SurfaceGroups = { GFloor, GFinish, GRoof, GInsul, GPlaster };

    private static CatalogItem Tab(string id, string group, string name, string note, params (double T, double Min, double Max)[] pts) => new()
    {
        Id = id, Group = group, Name = name, Unit = CatalogUnit.Table, Note = note,
        Points = pts.Select(p => new CatalogPoint(p.T, p.Min, p.Max)).ToArray()
    };
    private static (double, double, double) P(double t, double g) => (t, g, g);
    private static (double, double, double) R(double t, double a, double b) => (t, Math.Min(a, b), Math.Max(a, b));
    private static CatalogItem Cm(string id, string group, string name, double g, string note = "") => new() { Id = id, Group = group, Name = name, Unit = CatalogUnit.PerCm, Min = g, Max = g, Note = note };
    private static CatalogItem Fx(string id, string group, string name, double a, double b, string note = "") => new() { Id = id, Group = group, Name = name, Unit = CatalogUnit.Fixed, Min = Math.Min(a, b), Max = Math.Max(a, b), Note = note };
    private static CatalogItem Vol(string id, string group, string name, double a, double b, string note = "") => new() { Id = id, Group = group, Name = name, Unit = CatalogUnit.Volumic, Min = Math.Min(a, b), Max = Math.Max(a, b), Note = note };

    public static readonly IReadOnlyList<CatalogItem> Items = Build();

    private static List<CatalogItem> Build()
    {
        var l = new List<CatalogItem>();
        // ---------------------------------------------------------------- maçonneries (poids surfacique, enduit non compris)
        l.Add(Tab("bp", GMasTc, "Briques pleines", "", P(5.5, 1.5), P(10.5, 2), P(21.5, 4.05), P(33, 6.3)));
        l.Add(Tab("bc", GMasTc, "Briques creuses (cloisons)", "Non porteuses, mauvaise isolation phonique.", P(5, 0.45), P(10, 0.9), P(15, 1.3), P(20, 1.75), P(25, 2.15), P(30, 2.6)));
        l.Add(Tab("bf", GMasTc, "Briques perforées (porteuses)", "", P(5.5, 0.75), P(10.5, 1.4), P(21.5, 2.95), P(33, 4.5)));
        l.Add(Tab("bk", GMasTc, "Blocs perforés", "", P(17.5, 2.3), P(22.5, 2.95), P(27.5, 3.6)));
        l.Add(Tab("bbp", GMasBeton, "Blocs pleins en béton de granulats lourds", "", P(5, 1.05), P(10, 2.1), P(15, 3.15), P(20, 4.2)));
        l.Add(Tab("bbc", GMasBeton, "Blocs creux en béton de granulats lourds à parois épaisses (parpaings)", "", P(5, 0.65), P(10, 1.35), P(15, 2), P(20, 2.7), P(25, 3.25), P(30, 3.85)));
        l.Add(Tab("bap", GMasBeton, "Blocs pleins en béton d'argile ou de schiste expansé (750 à 1550 kg/m³)", "Fourchette selon la masse volumique du béton.", R(5, 0.45, 0.8), R(10, 0.9, 1.6), R(15, 1.35, 2.4), R(20, 1.8, 3.2)));
        l.Add(Tab("bac", GMasBeton, "Blocs creux en béton d'argile ou de schiste expansé à parois épaisses", "Fourchette selon la masse volumique du béton.", R(10, 0.6, 1), R(15, 0.9, 1.5), R(20, 1.2, 2), R(25, 1.5, 2.5)));
        l.Add(Tab("blp", GMasBeton, "Blocs pleins en béton de laitier expansé ou de pouzzolane (1450 kg/m³)", "", P(5, 0.75), P(10, 1.5), P(15, 2.25), P(20, 3)));
        l.Add(Tab("blc", GMasBeton, "Blocs creux en béton de laitier expansé ou de pouzzolane à parois épaisses", "", P(10, 0.95), P(15, 1.4), P(20, 1.9), P(25, 2.3)));
        l.Add(Tab("bcel", GMasBeton, "Blocs pleins en béton cellulaire (600 kg/m³)", "Bonnes caractéristiques isolantes.", P(15, 1.2), P(20, 1.6), P(25, 2.05), P(30, 2.45)));
        l.Add(Cm("plat", GMasOther, "Cloisons à carreaux de plâtre à parements lisses", 0.1, "0,1 kN/m² par cm d'épaisseur ; carreaux pleins de 5 à 15 cm."));
        l.Add(Tab("pierre", GMasOther, "Pierres de taille : parois pleines", "", P(20, 5.3), P(30, 8.1)));
        l.Add(Cm("pfa", GMasOther, "Revêtement de façade autoportant en pierre", 2.2 / 8.0, "2,2 kN/m² pour 8 cm."));
        l.Add(Cm("pat", GMasOther, "Revêtement de pierre attaché", 0.8 / 3.0, "0,8 kN/m² pour 3 cm."));
        l.Add(Fx("psc", GMasOther, "Revêtement de pierre scellé (mortier compris)", 0.4, 0.4));

        // ---------------------------------------------------------------- planchers (enduit non compris)
        l.Add(Cm("dalle", GFloor, "Dalle pleine en béton armé (par cm d'épaisseur)", 0.25, "25 kN/m³."));
        l.Add(Tab("alv", GFloor, "Plancher à dalles alvéolées préfabriquées (éléments jointifs)", "Épaisseur totale en cm ; fourchette selon les alvéoles.", R(12, 2, 2.5), R(16, 2.4, 2.9), R(20, 2.8, 3.3), R(25, 3.2, 3.7)));
        l.Add(Tab("pbe", GFloor, "Plancher nervuré à poutrelles préfabriquées, entrevous béton (entraxe 60 cm, table de compression béton)", "Épaisseur = hauteur d'entrevous + table (12+4 = 16 cm...).", R(16, 2.5, 2.6), R(20, 2.75, 2.85), R(24, 3.1, 3.3), R(30, 3.4, 3.6)));
        l.Add(Tab("ptc", GFloor, "Plancher à poutrelles et entrevous en terre cuite", "Épaisseur = hauteur d'entrevous + table (12+4 = 16 cm...).", R(16, 2.2, 2.3), R(20, 2.5, 2.6), R(24, 2.8, 3.3), R(30, 3.2, 3.6)));
        l.Add(Tab("pps", GFloor, "Plancher à poutrelles et entrevous en polystyrène", "Épaisseur = hauteur d'entrevous + table (12+4 = 16 cm...).", R(16, 1.5, 1.7), R(20, 1.7, 2), R(24, 1.8, 2.1), R(30, 2.4, 2.8)));

        // ---------------------------------------------------------------- revêtements de plancher
        l.Add(Fx("gcm", GFinish, "Carrelage scellé : grès cérame mince (4,5 mm), mortier de pose de 2 cm compris", 0.5, 0.5));
        l.Add(Fx("gc", GFinish, "Carrelage scellé : grès cérame (9 mm), mortier de pose de 2 cm compris", 0.6, 0.6));
        l.Add(Fx("dc", GFinish, "Carrelage scellé : dallage céramique, pierre dure (15 à 30 mm), mortier de pose de 2 cm compris", 0.7, 1));
        l.Add(Cm("cc", GFinish, "Carrelage ou dallage collé (par cm d'épaisseur)", 0.2));
        l.Add(Cm("chape", GFinish, "Chape en mortier de ciment (par cm d'épaisseur)", 0.2));
        l.Add(Fx("chfa", GFinish, "Chape flottante en asphalte, 2 à 2,5 mm, couche élastique comprise (revêtement non compris)", 0.5, 0.5));
        l.Add(Cm("dfb", GFinish, "Dalle flottante en béton, sous-couche élastique comprise (par cm d'épaisseur)", 0.22));
        l.Add(Fx("parq", GFinish, "Parquet 23 mm", 0.25, 0.25));
        l.Add(Fx("sol", GFinish, "Sols minces ou plastique", 0.08, 0.08));

        // ---------------------------------------------------------------- toitures
        l.Add(Fx("lat", GRoof, "Support : lattis ou liteaux en sapin", 0.03, 0.03));
        l.Add(Fx("vol", GRoof, "Support : voligeage en sapin", 0.1, 0.1));
        l.Add(Fx("sceram", GRoof, "Support : support céramique", 0.45, 0.45));
        l.Add(Cm("ctp", GRoof, "Sous-toiture : contreplaqué Okoumé (par cm)", 0.05));
        l.Add(Cm("lin", GRoof, "Sous-toiture : panneau de lin (par cm)", 0.04));
        l.Add(Cm("pld", GRoof, "Sous-toiture : plaques de plâtre, type placoplâtre ou Prégypan (par cm)", 0.09));
        l.Add(Cm("paille", GRoof, "Sous-toiture : panneau de paille compressé (par cm)", 0.03));
        l.Add(Cm("amc", GRoof, "Sous-toiture : plaques planes d'amiante-ciment (par cm)", 0.11));
        l.Add(Fx("zinc", GRoof, "Couverture métallique : zinc, voligeage et tasseaux compris", 0.25, 0.25));
        l.Add(Fx("alu1", GRoof, "Couverture métallique : aluminium 8/10, plaques ondulées sans support", 0.03, 0.03));
        l.Add(Fx("alu2", GRoof, "Couverture métallique : aluminium 8/10, voligeage et tasseaux compris", 0.17, 0.17));
        l.Add(Fx("inox", GRoof, "Couverture métallique : acier inox, voligeage et tasseaux compris", 0.25, 0.25));
        l.Add(Fx("tole", GRoof, "Couverture métallique : tôle ondulée d'acier galvanisé 8/10", 0.06, 0.06));
        l.Add(Fx("ard1", GRoof, "Ardoises naturelles ordinaires (voligeage et tasseaux compris)", 0.28, 0.28));
        l.Add(Fx("ard2", GRoof, "Ardoises naturelles en fibrociment (voligeage et tasseaux compris)", 0.3, 0.3));
        l.Add(Fx("tm", GRoof, "Tuiles mécaniques à emboîtement (liteaux, voligeage et tasseaux compris)", 0.35, 0.45));
        l.Add(Fx("tp", GRoof, "Tuiles plates (liteaux, voligeage et tasseaux compris)", 0.55, 0.75));
        l.Add(Fx("tc", GRoof, "Tuiles canal (liteaux, voligeage et tasseaux compris)", 0.4, 0.6));
        l.Add(Fx("tb", GRoof, "Tuiles béton (liteaux, voligeage et tasseaux compris)", 0.45, 0.45));
        l.Add(Fx("fibro", GRoof, "Plaques de fibrociment auto-portantes (ex amiante-ciment)", 0.17, 0.17));
        l.Add(Fx("asph", GRoof, "Terrasse : asphalte coulé de 0,5 cm plus 1,5 cm d'asphalte coulé sablé", 0.5, 0.5));
        l.Add(Fx("etm1", GRoof, "Terrasse : étanchéité multicouche en enduit plastique ou feutre bitumineux", 0.12, 0.12));
        l.Add(Fx("etm2", GRoof, "Terrasse : étanchéité multicouche auto-protégée", 0.22, 0.22));
        l.Add(Cm("grav", GRoof, "Terrasse : gravillon de protection de l'étanchéité (par cm)", 0.2));
        l.Add(Fx("prot", GRoof, "Terrasse : protection par asphalte gravillonné de 2 cm sur 2 feuilles de papier kraft", 0.5, 0.5));

        // ---------------------------------------------------------------- isolants (par cm d'épaisseur)
        l.Add(Cm("pse1", GInsul, "Polystyrène expansé faible densité (par cm)", 0.013));
        l.Add(Cm("pse2", GInsul, "Polystyrène forte densité (par cm)", 0.025));
        l.Add(Cm("pur", GInsul, "Mousse de polyuréthane (par cm)", 0.05));
        l.Add(Cm("lr", GInsul, "Laine de roche forte densité, support d'étanchéité ou chape flottante (par cm)", 0.07));
        l.Add(Cm("lv1", GInsul, "Laine de verre en rouleau (par cm)", 0.01));
        l.Add(Cm("lv2", GInsul, "Laine de verre en plaque, plus dense (par cm)", 0.02));

        // ---------------------------------------------------------------- enduits (par cm d'épaisseur)
        l.Add(Cm("enp", GPlaster, "Enduit en plâtre (par cm)", 0.1));
        l.Add(Cm("enm", GPlaster, "Enduit au mortier de liants hydrauliques (par cm)", 0.18));

        // ---------------------------------------------------------------- poids volumiques (kN/m³)
        l.Add(Vol("acier", GMat, "Acier", 78.5, 78.5));
        l.Add(Vol("alu", GMat, "Aluminium", 27, 27));
        l.Add(Vol("asphc", GMat, "Asphalte coulé", 18, 18));
        l.Add(Vol("bbit", GMat, "Béton bitumineux", 22, 22));
        l.Add(Vol("bna", GMat, "Béton non armé", 22, 22, "Valeur du tableau ; 24 kN/m³ est courant pour un béton ordinaire."));
        l.Add(Vol("ba", GMat, "Béton armé", 25, 25));
        l.Add(Vol("bleg", GMat, "Béton de granulats légers", 7.5, 15.5));
        l.Add(Vol("liege", GMat, "Blocs de liège", 4, 4));
        l.Add(Vol("conif", GMat, "Bois de conifères séché à l'air", 6, 6));
        l.Add(Vol("feuil", GMat, "Bois de feuillus séché à l'air", 8, 8));
        l.Add(Vol("tropic", GMat, "Bois durs tropicaux", 10, 10));
        l.Add(Vol("calt", GMat, "Calcaire tendre", 18, 18));
        l.Add(Vol("calc", GMat, "Calcaire compact, marbre, granit", 28, 28));
        l.Add(Vol("calm", GMat, "Calcaire de dureté moyenne", 22, 22));
        l.Add(Vol("fonte", GMat, "Fonte", 72.5, 72.5));
        l.Add(Vol("gres", GMat, "Grès", 25, 25));
        l.Add(Vol("moel", GMat, "Maçonnerie sans enduit : en moellons", 23, 23));
        l.Add(Vol("mbp", GMat, "Maçonnerie sans enduit : en briques pleines", 19, 19));
        l.Add(Vol("mbf", GMat, "Maçonnerie sans enduit : en briques perforées", 13.5, 13.5));
        l.Add(Vol("mbc", GMat, "Maçonnerie sans enduit : en briques creuses", 9, 9));
        l.Add(Vol("mbbp", GMat, "Maçonnerie sans enduit : blocs de béton pleins en granulats lourds", 21, 21));
        l.Add(Vol("mbbc", GMat, "Maçonnerie sans enduit : blocs de béton creux en granulats lourds", 13.5, 13.5));
        l.Add(Vol("ptail", GMat, "Pierre de taille", 27, 27));
        l.Add(Vol("cuivre", GMat, "Métaux cuivreux", 89, 89));
        l.Add(Vol("plomb", GMat, "Plomb", 114, 114));
        l.Add(Vol("verre", GMat, "Verre", 25, 25));
        // corps en vrac (angle de talus naturel dans la note)
        l.Add(Vol("avoine", GBulk, "Avoine en vrac", 5.5, 5.5, "Angle de talus 30°"));
        l.Add(Vol("briqv", GBulk, "Briquettes en vrac", 5, 5));
        l.Add(Vol("brique", GBulk, "Briquettes empilées", 13, 13));
        l.Add(Vol("ble", GBulk, "Blé, orge, seigle", 8, 8, "Angle de talus 30°"));
        l.Add(Vol("bcs", GBulk, "Bois en bûches : conifères secs", 4.5, 4.5, "Angle de talus 45°"));
        l.Add(Vol("bch", GBulk, "Bois en bûches : conifères humides", 6.5, 6.5, "Angle de talus 45°"));
        l.Add(Vol("bfs", GBulk, "Bois en bûches : feuillus secs", 7, 7, "Angle de talus 45°"));
        l.Add(Vol("bfh", GBulk, "Bois en bûches : feuillus humides", 10, 10, "Angle de talus 45°"));
        l.Add(Vol("copv", GBulk, "Bois en copeaux : en vrac", 2, 2, "Angle de talus 25°"));
        l.Add(Vol("copc", GBulk, "Bois en copeaux : compact", 3, 3, "Angle de talus 45°"));
        l.Add(Vol("cendre", GBulk, "Cendres", 8, 8, "Angle de talus 25°"));
        l.Add(Vol("farv", GBulk, "Farine en vrac", 6, 6, "Angle de talus 25°"));
        l.Add(Vol("fars", GBulk, "Farine en sac", 5, 5));
        l.Add(Vol("paillev", GBulk, "Paille et foin en vrac", 1, 1));
        l.Add(Vol("paillb", GBulk, "Paille et foin bottelés", 1.5, 1.5));
        l.Add(Vol("fruits", GBulk, "Fruits", 4.5, 4.5, "Angle de talus 35°"));
        l.Add(Vol("gravier", GBulk, "Gravier", 17, 17, "Angle de talus 35°"));
        l.Add(Vol("hous", GBulk, "Houille, anthracite secs", 8, 8, "Angle de talus 35°"));
        l.Add(Vol("houh", GBulk, "Houille, anthracite humides", 10, 10, "Angle de talus 30°"));
        l.Add(Vol("mache", GBulk, "Mâchefer", 8, 8, "Angle de talus 45°"));
        l.Add(Vol("papie", GBulk, "Papier empilé", 11, 11));
        l.Add(Vol("papir", GBulk, "Papier en rouleau", 16, 16));
        l.Add(Vol("pdt", GBulk, "Pommes de terre", 7, 7, "Angle de talus 30°"));
        l.Add(Vol("sable", GBulk, "Sable", 17, 19, "Angle de talus 30 à 35°"));
        l.Add(Vol("sels", GBulk, "Sel en sac", 10, 10));
        l.Add(Vol("selv", GBulk, "Sel en vrac", 12, 12, "Angle de talus 40°"));
        l.Add(Vol("sucs", GBulk, "Sucre en sac", 16, 16));
        l.Add(Vol("sucv", GBulk, "Sucre en vrac", 9, 9, "Angle de talus 35°"));
        l.Add(Vol("terres", GBulk, "Terre sèche", 18, 18, "Angle de talus 40°"));
        l.Add(Vol("terreh", GBulk, "Terre humide", 21, 21, "Angle de talus 20°"));
        l.Add(Vol("arch", GBulk, "Classeurs, armoires, bibliothèques", 6, 6));
        return l;
    }

    public static CatalogItem? Find(string id) => Items.FirstOrDefault(i => i.Id == id);
    public static IEnumerable<CatalogItem> Of(params string[] groups) => Items.Where(i => groups.Contains(i.Group));
    public static IEnumerable<CatalogItem> Masonry => Of(MasonryGroups);
    public static IEnumerable<CatalogItem> Surfaces => Of(SurfaceGroups);
    public static IEnumerable<CatalogItem> Volumics => Of(GMat, GBulk);

    // ---------------------------------------------------------------- charges d'exploitation (EN 1991-1-1, Annexe Nationale française)
    public static readonly IReadOnlyList<LiveCategory> LiveCategories = new List<LiveCategory>
    {
        new("A1", "A : habitation, résidentiel (chambres d'hôpitaux, hôtels, foyers, cuisines, sanitaires) - planchers", 1.5, 2.0, 0.6, ""),
        new("A2", "A : escaliers", 2.5, 2.0, 0.6, "Sauf marches indépendantes (approche dynamique)."),
        new("A3", "A : balcons", 3.5, 2.0, 0.6, ""),
        new("B", "B : bureaux", 2.5, 4.0, 0.6, ""),
        new("C1", "C1 : espaces à tables (écoles, cafés, restaurants, salles de banquet, de lecture, de réception)", 2.5, 3.0, 0.6, ""),
        new("C2", "C2 : espaces à sièges fixes (églises, théâtres, cinémas, salles de conférence, amphithéâtres, de réunion, d'attente)", 4.0, 4.0, 1.0, ""),
        new("C3", "C3 : espaces sans obstacle à la circulation (musées, expositions, accès de bâtiments publics, hôtels, hôpitaux, gares)", 4.0, 4.0, 1.0, ""),
        new("C4", "C4 : activités physiques (dancings, salles de gymnastique, scènes)", 5.0, 7.0, 1.0, ""),
        new("C5", "C5 : foules importantes (salles de concert, de sport, tribunes, terrasses, quais de gare)", 5.0, 4.5, 3.0, ""),
        new("D1", "D1 : commerce de détail", 5.0, 5.0, 1.0, "Catégorie à retenir si l'usage futur n'est pas connu."),
        new("D2", "D2 : grandes surfaces", 5.0, 7.0, 1.0, ""),
        new("E", "E : stockage, usage industriel", 0, 0, 2.0, "Charge horizontale 2 kN/m minimale ; la charge répartie dépend de la destination des locaux."),
        new("F", "F : garages et circulation de véhicules, PTAC ≤ 30 kN", 2.3, 15, 0, "Valable pour une vitesse inférieure à 20 km/h."),
        new("G", "G : circulation de véhicules, 30 kN < PTAC ≤ 160 kN", 5.0, 90, 0, "Valable pour une vitesse inférieure à 10 km/h."),
        new("H1", "H : toiture inaccessible (sauf entretien), pente < 15 % avec étanchéité", 1.0, 1.5, 0, "qk sur une aire de 10 m² ; non cumulée avec la neige ou le vent ; qk et Qk non simultanées."),
        new("H2", "H : toiture inaccessible (sauf entretien), autres toitures", 0.0, 1.5, 0, "Non cumulée avec la neige ou le vent ; qk et Qk non simultanées.")
    };

    /// <summary>Charge d'exploitation répartie équivalente d'une cloison (EN 1991-1-1 6.3.1.2) selon son poids par mètre de longueur : ≤ 1 kN/m : 0,5 ; ≤ 2 : 0,8 ; ≤ 3 : 1,2 kN/m². NaN au-delà.</summary>
    public static double PartitionEquivalent(double weightKnPerM) => weightKnPerM <= 0 ? 0 : weightKnPerM <= 1.0 ? 0.5 : weightKnPerM <= 2.0 ? 0.8 : weightKnPerM <= 3.0 ? 1.2 : double.NaN;

    /// <summary>Charge d'un mur ou d'une cloison : poids surfacique de la maçonnerie (épaisseur donnée) + enduits sur 0, 1 ou 2 faces, charge linéaire = poids × hauteur
    /// (réduit du pourcentage d'ouvertures).</summary>
    public static WallLoadResult Wall(CatalogItem masonry, double thicknessCm, double heightM, int plasterFaces, CatalogItem? plaster, double plasterCm, double openingPercent, RangeMode mode)
    {
        double mas = masonry.Surface(thicknessCm, mode, out bool outside);
        double pl = plaster == null ? 0 : Math.Clamp(plasterFaces, 0, 2) * plaster.Surface(plasterCm, mode, out _);
        double s = mas + pl, lin = s * Math.Max(heightM, 0) * (1 - Math.Clamp(openingPercent, 0, 100) / 100.0);
        return new WallLoadResult(mas, pl, s, lin, PartitionEquivalent(lin), outside);
    }
}
