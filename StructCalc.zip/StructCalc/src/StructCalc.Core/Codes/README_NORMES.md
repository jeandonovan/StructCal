# Organisation des normes de calcul

Chaque norme vit dans son dossier `Codes/<Norme>/` avec ses propres classes. Les formules d'une norme ne sont jamais écrites dans le dossier d'une autre.

## État actuel (honnête)
* **Moteur commun** : aujourd'hui, c'est la classe `Bael91Code` (dossier `BAEL91`) qui porte les algorithmes partagés (flexion, ELS, poteaux, dalles, semelles) et expose des points de variation `virtual`
  (`Fcd`, `Fyd`, `Fct`, limites de contraintes, `AsMinBeam`, tranchant, flèche, limites d'acier des poteaux, moment total).
  `EC2` et `CBA93` en héritent et redéfinissent ces points ; `RPA99` hérite de `CBA93`, `EC8` hérite de `EC2`.
* **Limite connue** : la méthode des coefficients pour les dalles et le calcul de semelle isolée sont ceux du BAEL, y compris pour l'EC2. Un moteur commun totalement neutre
  (classe abstraite sans aucune formule d'une norme) reste à extraire : ce serait un refactor de `Bael91Code` à faire avec le compilateur et les tests sous la main.
* **Fiches** : `CodeProfile.cs` déclare pour chaque norme sa famille, sa filiation, ce qu'elle couvre et ce qu'elle ne couvre pas. Les tests (`NormArchitectureTests`) vérifient que la filiation
  déclarée est la filiation réelle.

## Ajouter une norme (ex. NF EN 1992 + AN, DTR, ACI 318)
1. Créer `Codes/<Norme>/<Norme>Code.cs` (classe implémentant `IReinforcedConcreteCode` ou `ISteelCode`, ou héritant d'une norme voisine si les hypothèses sont les mêmes).
2. Marquer la classe `[AutoRegisterCode]` (constructeur sans paramètre) : le registre la découvre seul.
3. Ajouter sa fiche dans `CodeProfiles` (périmètre, limites, filiation).
4. Écrire `tests/.../<Norme>Tests.cs` avec au moins : une flexion, un tranchant, une section minimale et les dispositions constructives, valeurs faites à la main avec leur source.
5. Ne déclarer la norme « validée » qu'après comparaison à une référence fiable (voir `VALIDATION_MOTEUR.md`).
