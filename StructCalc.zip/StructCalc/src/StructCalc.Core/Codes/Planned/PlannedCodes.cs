namespace StructCalc.Core.Codes.Planned;

/// <summary>Modèle pour une future norme non encore codée (visible dans la liste, désactivée).</summary>
public class PlannedCode : IDesignCode
{
    public PlannedCode(string id, string name, MaterialKind m) { Id = id; DisplayName = name; Material = m; }
    public string Id { get; }
    public string DisplayName { get; }
    public MaterialKind Material { get; }
    public bool IsImplemented => false;
    public IReadOnlyList<Combination> Combinations => Array.Empty<Combination>();
}

public static class PlannedCodes
{
    /// <summary>Toutes les normes prévues sont maintenant implémentées. Ajoutez ici les prochaines (ex. NF EN 1992 AN, DTR...).</summary>
    public static IEnumerable<IDesignCode> All() => Array.Empty<IDesignCode>();
}
