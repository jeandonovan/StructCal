using StructCalc.Core.Steel;

namespace StructCalc.Core.Codes.CM66;

/// <summary>CM66 / Additif 80 - vérification élastique (sigma_e = fy), axes CM66 : x = axe fort, y = axe faible.
/// Formules reprises (et recoupées sur plusieurs exemples chiffrés publiés) :
///  - flambement 3,411 : K = (0,5+0,65 s) + sqrt((0,5+0,65 s)² - s), s = sigma_e/sigma_k, sigma_k = pi² E / lambda² ;
///  - déversement 3,61 : sigma_d = 40000 (Iy/Ix)(h/L)²(D-1) B C [daN/mm²], D = sqrt(1+0,156 (J/Iy)(L/h)²), B = sqrt(1+(0,405 beta C/D)²) - 0,405 beta C/D,
///    C = 1,132 (charge répartie) ; kd = K0 / (1 + (K0-1) sigma_d/sigma_e) ;
///  - flexion composée déviée, formule enveloppe 3,731 : 9/8 (K sigma + kd sigma_fx + sigma_fy) <= sigma_e ;
///  - cisaillement : 1,54 tau <= sigma_e.
/// Réserve : l'élancement fictif lambda_0 = (L/h) (Ix/Iy)^(3/4) ((1 - sigma_d/sigma_e)/(B C))^(1/4) a été reconstitué à partir d'exemples (écart &lt; 0,3 % sur 2 exemples,
/// 10 % sur un 3e, côté sécurité) : à confirmer sur le texte (3,611 / annexe 13,611). Le coefficient d'amplification kf (3,513) n'est pas utilisé.
/// psi (adaptation plastique, art. 13,212) : 1,0 par défaut (pratique usuelle) ; modifiable via PsiStrong.</summary>
public class Cm66Code : ISteelCode
{
    public string Id => "CM66";
    public string DisplayName => "CM66 / Additif 80 - Charpente métallique";
    public MaterialKind Material => MaterialKind.Steel;
    public bool IsImplemented => true;
    public double PsiStrong { get; set; } = 1.0;

    private static IReadOnlyDictionary<ActionType, double> F(double g = 0, double q = 0, double w = 0, double e = 0, double sn = 0) =>
        new Dictionary<ActionType, double> { { ActionType.G, g }, { ActionType.Q, q }, { ActionType.W, w }, { ActionType.E, e }, { ActionType.S, sn } };

    /// <summary>Combinaisons pratiques CM66 avec G, Q, S = neige normale Sn, W = vent normal Wn. Neige extrême Se et vent extrême We : non gérés.</summary>
    public IReadOnlyList<Combination> Combinations { get; } = new[]
    {
        new Combination("CM 1.33G+1.5Sn",               LimitState.ELU, F(1.33, 0, 0, 0, 1.5)),
        new Combination("CM 1.33G+1.5Q",                LimitState.ELU, F(1.33, 1.5)),
        new Combination("CM 1.33G+1.5Wn",               LimitState.ELU, F(1.33, 0, 1.5)),
        new Combination("CM 1.33G-1.5Wn",               LimitState.ELU, F(1.33, 0, -1.5)),
        new Combination("CM G+1.75Wn",                  LimitState.ELU, F(1.0, 0, 1.75)),
        new Combination("CM G-1.75Wn",                  LimitState.ELU, F(1.0, 0, -1.75)),
        new Combination("CM 1.33G+1.42Sn+1.42Q",        LimitState.ELU, F(1.33, 1.42, 0, 0, 1.42)),
        new Combination("CM 1.33G+0.5*1.42Sn+1.42Wn",   LimitState.ELU, F(1.33, 0, 1.42, 0, 0.71)),
        new Combination("CM 1.33G+0.5*1.42Sn-1.42Wn",   LimitState.ELU, F(1.33, 0, -1.42, 0, 0.71)),
        new Combination("CM 1.33G+1.42Q+1.42Wn",        LimitState.ELU, F(1.33, 1.42, 1.42)),
        new Combination("CM 1.33G+1.42Q-1.42Wn",        LimitState.ELU, F(1.33, 1.42, -1.42)),
        new Combination("CM G+Q+1.75Wn",                LimitState.ELU, F(1.0, 1.0, 1.75)),
        new Combination("CM G+Q-1.75Wn",                LimitState.ELU, F(1.0, 1.0, -1.75)),
        new Combination("CM 1.33(G+Sn+Wn+Q)",           LimitState.ELU, F(1.33, 1.33, 1.33, 0, 1.33)),
        new Combination("CM G+0.3Q+E",                  LimitState.ELU, F(1.0, 0.3, 0, 1.0)),
        new Combination("CM G+0.3Q-E",                  LimitState.ELU, F(1.0, 0.3, 0, -1.0)),
        new Combination("ELS G+Q",                      LimitState.ELS, F(1.0, 1.0, 0)),
    };

    // ---------------------------------------------------------------- formules (publiques pour les tests)
    public const double E = 210000.0;   // MPa

    /// <summary>Coefficient de flambement K (3,411). se en MPa.</summary>
    public static double K(double lambda, double se)
    {
        double sk = Math.PI * Math.PI * E / (lambda * lambda);
        double s = se / sk;
        double a = 0.5 + 0.65 * s;
        return a + Math.Sqrt(Math.Max(a * a - s, 0));
    }

    public static double CoefD(double J, double iWeak, double h, double L) => Math.Sqrt(1 + 0.156 * J / iWeak * (L / h) * (L / h));
    public static double CoefB(double beta, double C, double D) { double t = 0.405 * beta * C / D; return Math.Sqrt(1 + t * t) - t; }

    /// <summary>Contrainte de non-déversement sigma_d en MPa (3,61). Inerties et J dans une même unité, h et L dans une même unité.</summary>
    public static double SigmaD(double iWeak, double iStrong, double J, double h, double L, double B, double C, double D) =>
        400000.0 * iWeak / iStrong * (h / L) * (h / L) * (D - 1) * B * C;

    public static double Lambda0(double L, double h, double iStrong, double iWeak, double sd, double se, double B, double C) =>
        L / h * Math.Pow(Math.Pow(iStrong / iWeak, 3) * (1 - sd / se) / (B * C), 0.25);

    public static double Kd(double K0, double sd, double se) => K0 / (1 + (K0 - 1) * sd / se);

    // ---------------------------------------------------------------- vérification d'une barre
    public DesignResult CheckMember(SteelInput i)
    {
        var p = i.P;
        var r = new DesignResult { Element = $"Acier CM66 - {p.Name}" };
        double se = i.Fy;
        double A = p.AreaMm2, Ix = p.IyMm4, Iy = p.IzMm4;           // CM66 : x = fort, y = faible
        double ix = Math.Sqrt(Ix / A), iy = Math.Sqrt(Iy / A);
        double Nc = Math.Max(0, i.NKN) * 1e3, Nt = Math.Max(0, -i.NKN) * 1e3;
        double Mx = Math.Abs(i.MyKNm) * 1e6, My = Math.Abs(i.MzKNm) * 1e6;     // moments autour de l'axe fort / faible
        double Vz = Math.Abs(i.VzKN) * 1e3, Vy = Math.Abs(i.VyKN) * 1e3;
        double sN = Nc / A, sT = Nt / A, sfx = Mx / p.WelYMm3, sfy = My / p.WelZMm3;

        double uSection = (sN + sT + sfx / PsiStrong + sfy) / se;
        double aWeb = (p.H - 2 * p.Tf) * p.Tw, aFl = 2 * p.B * p.Tf;
        double uTau = 1.54 * Math.Max(Vz / aWeb, Vy / aFl) / se;
        double util = Math.Max(uSection, uTau);
        r.Notes.Add($"Section : (N/A + sf_x/psi + sf_y)/sigma_e = {uSection:F3} ; 1,54 tau/sigma_e = {uTau:F3}");

        if (Nt == 0)
        {
            double lamX = i.Lfy * 1000 / ix, lamY = i.Lfz * 1000 / iy, lamMax = Math.Max(lamX, lamY);
            double K = Nc > 0 ? K0Safe(lamMax, se) : 1.0;
            if (Nc > 0 && lamMax > 210) r.Fail($"Élancement {lamMax:F0} > 210.");
            double kd = 1.0, sd = double.PositiveInfinity;
            if (Mx > 0 && Iy < Ix)
            {
                double L = Math.Max(i.Lt, 0.01) * 1000, h = p.H;
                double psi = Math.Max(-1.0, Math.Min(1.0, i.PsiY));
                double C = i.Loaded ? 1.132 : Math.Min(2.3, 1.75 - 1.05 * psi + 0.3 * psi * psi);
                double D = CoefD(p.ItMm4, Iy, h, L);
                double B = i.Loaded ? CoefB(1.0, C, D) : 1.0;
                sd = SigmaD(Iy, Ix, p.ItMm4, h, L, B, C, D);
                if (sd < se)
                {
                    double l0 = Lambda0(L, h, Ix, Iy, sd, se, B, C);
                    kd = Kd(K0Safe(l0, se), sd, se);
                    r.Notes.Add($"Déversement : D={D:F2}, B={B:F2}, C={C:F3}, sigma_d={sd:F1} MPa < sigma_e -> lambda_0={l0:F0}, kd={kd:F2}");
                    r.Warnings.Add("CM66 : lambda_0 du déversement reconstitué à partir d'exemples, à confirmer (3,611).");
                }
            }
            double sEq = (Nc > 0 && (Mx > 0 || My > 0)) ? 9.0 / 8.0 * (K * sN + kd * sfx + sfy)
                       : Nc > 0 ? K * sN : kd * sfx + sfy;
            r.Values["K"] = K; r.Values["kd"] = kd; r.Values["sigma_d"] = double.IsInfinity(sd) ? 0 : sd;
            r.Notes.Add($"lam_x={lamX:F0}, lam_y={lamY:F0}, K={K:F3} ; formule enveloppe 3,731 : sigma_eq={sEq:F0} MPa / sigma_e={se:F0}");
            util = Math.Max(util, sEq / se);
        }
        r.Values["util"] = util;
        if (util > 1.0) r.Fail($"{p.Name} : taux de travail {util:F2} > 1.");
        return r;
    }

    private static double K0Safe(double lambda, double se) => K(Math.Max(lambda, 1.0), se);
}
