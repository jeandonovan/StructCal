using StructCalc.Core.Codes.BAEL91;

namespace StructCalc.Core.Codes.EC2;

/// <summary>Eurocode 2 (EN 1992-1-1) : fcd = fck/1,5 (alpha_cc = 1,0), fyd = fyk/1,15, bloc rectangulaire (flexion), bielles à inclinaison variable (tranchant),
/// courbure nominale (2nd ordre des poteaux). fc28 est interprété comme fck. Fissuration : seule la limitation des contraintes est vérifiée (7.2), pas l'ouverture w_k.</summary>
public class Ec2Code : Bael91Code
{
    public override string Id => "EC2";
    public override string DisplayName => "Eurocode 2 (EN 1992-1-1) - Béton armé";

    public override IReadOnlyList<Combination> Combinations { get; } = new[]
    {
        new Combination("ELU 1.35G+1.5Q",           LimitState.ELU, F(1.35, 1.5, 0)),
        new Combination("ELU 1.35G+1.5W+1.05Q",    LimitState.ELU, F(1.35, 1.05, 1.5)),
        new Combination("ELU 1.35G-1.5W+1.05Q",    LimitState.ELU, F(1.35, 1.05, -1.5)),
        new Combination("ELU 1.35G+1.5Q+0.9W",     LimitState.ELU, F(1.35, 1.5, 0.9)),
        new Combination("ELU 1.35G+1.5Q-0.9W",     LimitState.ELU, F(1.35, 1.5, -0.9)),
        new Combination("ELU G+1.5W",               LimitState.ELU, F(1.0, 0, 1.5)),
        new Combination("ELU G-1.5W",               LimitState.ELU, F(1.0, 0, -1.5)),
        new Combination("ELS car. G+Q",             LimitState.ELS, F(1.0, 1.0, 0)),
        new Combination("ELS car. G+W+0.7Q",       LimitState.ELS, F(1.0, 0.7, 1.0)),
        new Combination("ELS car. G-W+0.7Q",       LimitState.ELS, F(1.0, 0.7, -1.0)),
        new Combination("ELS car. G+Q+0.6W",       LimitState.ELS, F(1.0, 1.0, 0.6)),
        new Combination("ELS car. G+Q-0.6W",       LimitState.ELS, F(1.0, 1.0, -0.6)),
    };

    private static double GammaC(LimitState s) => s == LimitState.Accidental ? 1.2 : 1.5;
    private static double GammaS(LimitState s) => s == LimitState.Accidental ? 1.0 : 1.15;

    protected override double Fcd(double fck, LimitState s) => 1.0 * fck / GammaC(s);
    protected override double Fyd(double fyk, LimitState s) => fyk / GammaS(s);
    protected override double Fct(double fck) => 0.30 * Math.Pow(fck, 2.0 / 3.0);              // fctm
    protected override double SigmaSLimit(double fyk, double fck, CrackingClass c) => 0.8 * fyk;   // 7.2(5)
    protected override double SigmaBcLimit(double fck) => 0.6 * fck;                            // 7.2(2)
    protected override double XiLimit(double fyk, LimitState s) => 0.45;                       // ductilité (x/d <= 0,45)
    protected override double AsMinBeam(double b, double d, double fck, double fyk) =>
        Math.Max(0.26 * Fct(fck) / fyk, 0.0013) * b * d * 1e4;                               // 9.2.1.1(1)

    protected override double SlabTauLimit(double fck, double dMeters)
    {
        double k = Math.Min(2.0, 1.0 + Math.Sqrt(200.0 / (dMeters * 1000.0)));
        return 0.035 * Math.Pow(k, 1.5) * Math.Sqrt(fck);                                     // v_min, 6.2.2(1)
    }

    // ---- Effort tranchant 6.2.3 (armatures verticales, theta variable 21,8° - 45°)
    public override DesignResult DesignBeamShear(RcRectSection s, double fck, double fyk, double vuKN, CrackingClass crack,
                                                 LimitState state = LimitState.ELU)
    {
        var r = new DesignResult { Element = "Effort tranchant (EC2 6.2.3)" };
        double b = s.B, d = s.D, z = 0.9 * d;
        double V = Math.Abs(vuKN) / 1000.0;
        double fcd = Fcd(fck, state), fywd = Fyd(fyk, state);
        double nu1 = 0.6 * (1.0 - fck / 250.0);
        double sv = V / (b * z * nu1 * fcd);                 // = 1/(cot + tan)
        double cot;
        if (sv > 0.5) { cot = 1.0; r.Fail($"V_Ed > V_Rd,max : bielle comprimée insuffisante, augmenter la section."); }
        else if (sv <= 1.0 / 2.9) cot = 2.5;
        else cot = Math.Min(2.5, (1.0 / sv + Math.Sqrt(1.0 / (sv * sv) - 4.0)) / 2.0);
        double aswS = V / (z * fywd * cot);                  // m²/m
        double aswMin = 0.08 * Math.Sqrt(fck) / fyk * b;
        double asw = Math.Max(aswS, aswMin);
        double vrdMax = b * z * nu1 * fcd / (cot + 1.0 / cot);
        double stMax = Math.Min(0.75 * d, 0.60);
        r.Values["tau_u"] = V / (b * d); r.Values["tau_lim"] = b * z * nu1 * fcd * 0.5 / (b * d);
        r.Values["At_over_st_cm2_per_m"] = asw * 1e4; r.Values["st_max_cm"] = stMax * 100;
        r.Notes.Add($"VEd={vuKN:F1} kN ; cot(theta)={cot:F2} ; V_Rd,max={vrdMax * 1000:F0} kN ; Asw/s={asw * 1e4:F2} cm²/m ; s <= {stMax * 100:F0} cm");
        return r;
    }

    // ---- Flèche : limitation du rapport portée/hauteur utile 7.4.2 (K = 1,3 : travée de rive)
    public override DesignResult CheckBeamDeflection(RcRectSection s, double span, double fck, double fyk, double asCm2, double mtKNm, double m0KNm)
    {
        var r = new DesignResult { Element = "Flèche (EC2 7.4.2)" };
        double rho = asCm2 * 1e-4 / (s.B * s.D), rho0 = Math.Sqrt(fck) * 1e-3, K = 1.3;
        double sq = Math.Sqrt(fck);
        double lim = rho <= rho0
            ? K * (11 + 1.5 * sq * rho0 / rho + 3.2 * sq * Math.Pow(Math.Max(rho0 / rho - 1.0, 0), 1.5))
            : K * (11 + 1.5 * sq * rho0 / rho);
        lim = Math.Min(lim, 40.0 * K);
        double ld = span / s.D;
        r.Values["L_over_d"] = ld; r.Values["L_over_d_lim"] = lim;
        r.Values["needs_calc"] = ld <= lim ? 0 : 1;
        r.Notes.Add($"L/d = {ld:F1} <= {lim:F1} (K={K}, rho={rho * 100:F2} %)");
        if (ld > lim) r.Warnings.Add("EC2 7.4.2 : rapport L/d dépassé, calcul de flèche requis.");
        return r;
    }

    // ---- Poteaux : 5.8 courbure nominale, 9.5.2 sections limites
    protected override (double min, double max) ColumnAsLimits(ColumnInput i)
    {
        double area = i.Bw * i.Hd;
        double fyd = Fyd(i.Fe, i.State);
        double min = Math.Max(0.10 * (i.NuKN / 1000.0) / fyd * 1e4, 0.002 * area * 1e4);
        return (min, 0.04 * area * 1e4);
    }

    protected override double TotalMoment(double mKNm, double nKN, double depth, double lf, ColumnInput i, DesignResult r, string tag)
    {
        double m = Math.Abs(mKNm);
        if (nKN <= 1.0) return m;
        double e0 = m / nKN;
        double ei = Math.Max(lf / 400.0, 0.02);                       // imperfection géométrique 5.2
        double n = (nKN / 1000.0) / (i.Bw * i.Hd * Fcd(i.Fc28, i.State));
        double lambda = lf * Math.Sqrt(12) / depth;
        double lamLim = 20.0 * 0.7 * 1.1 * 0.7 / Math.Sqrt(Math.Max(n, 0.01));   // A=0,7 B=1,1 C=0,7
        double e2 = 0;
        if (lambda > lamLim)
        {
            double fyd = Fyd(i.Fe, i.State), dEff = depth - i.Cover;
            double invR0 = (fyd / Bael91Materials.Es) / (0.45 * dEff);
            double beta = Math.Max(0.0, 0.35 + i.Fc28 / 200.0 - lambda / 150.0);
            double kphi = Math.Max(1.0, 1.0 + beta * 2.0);            // phi_ef = 2 (hypothèse sécuritaire), Kr = 1
            e2 = kphi * invR0 * lf * lf / 10.0;
            r.Notes.Add($"{tag} : lambda={lambda:F1} > lambda_lim={lamLim:F1} : 2nd ordre e2={e2 * 100:F1} cm");
        }
        if (lambda > 140) r.Fail($"Poteau trop élancé ({tag}) : lambda={lambda:F0}.");
        r.Notes.Add($"{tag} : e0={e0 * 100:F1} cm, ei={ei * 100:F1} cm");
        return nKN * (e0 + ei + e2);
    }
}
