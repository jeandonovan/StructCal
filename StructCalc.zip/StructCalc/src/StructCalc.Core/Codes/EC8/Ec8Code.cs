using StructCalc.Core.Codes.EC2;

namespace StructCalc.Core.Codes.EC8;

/// <summary>Eurocode 8 (EN 1998-1), classe de ductilité moyenne (DCM) : combinaison sismique Gk + psi2 Qk + E (facteurs matériaux de situation durable,
/// par prudence), pourcentages minimaux et espacements des zones critiques. Base béton : EC2.
/// NON vérifié : dimensionnement en capacité (poteau fort/poutre faible), noeuds, murs, déplacements.</summary>
public class Ec8Code : Ec2Code
{
    public override string Id => "EC8";
    public override string DisplayName => "Eurocode 8 (+EC2) - Béton armé parasismique";

    public override IReadOnlyList<Combination> Combinations { get; } = Build();

    private static IReadOnlyList<Combination> Build()
    {
        var list = new List<Combination>(new Ec2Code().Combinations);
        list.Add(new Combination("SIS G+0.3Q+E", LimitState.ELU, F(1.0, 0.3, 0, 1.0)));
        list.Add(new Combination("SIS G+0.3Q-E", LimitState.ELU, F(1.0, 0.3, 0, -1.0)));
        return list;
    }

    protected override (double min, double max) ColumnAsLimits(ColumnInput i)
    {
        double area = i.Bw * i.Hd;
        return (0.01 * area * 1e4, 0.04 * area * 1e4);      // 5.4.3.2.2 : 1 % <= rho <= 4 %
    }

    protected override double AsMinBeam(double b, double d, double fck, double fyk) =>
        Math.Max(0.5 * Fct(fck) / fyk, 0.0013) * b * d * 1e4;      // 5.4.3.1.2 : rho_min = 0,5 fctm/fyk

    /// <summary>Zone critique : poutre s <= min(h/4 ; 24 d_bw ; 225 mm ; 8 d_bL) ; poteau s <= min(b/3 ; 125 mm ; 6 d_bL) (approx. b ~ 30 cm).</summary>
    public override double NodalStirrupSpacingCm(bool isColumn, double hCm, double minBarMm) =>
        isColumn ? Math.Min(12.5, 0.6 * minBarMm) : Math.Min(Math.Min(hCm / 4.0, 22.5), 0.8 * minBarMm);
}
