namespace StructCalc.Core.Codes.BAEL91;

/// <summary>Analyse de section BA à l'ELU par compatibilité des déformations
/// (diagramme parabole-rectangle, pivots A, B, C). Unités : m, MPa, MN, MN.m. Compression positive.</summary>
public static class Bael91Section
{
    private const int Slices = 100;

    private static double ConcreteStress(double e, double fbu)
    {
        if (e <= 0) return 0;
        if (e >= 2e-3) return fbu;
        double t = 1.0 - e / 2e-3;
        return fbu * (1.0 - t * t);
    }

    private static double SteelStress(double e, double fsu)
    {
        double s = Bael91Materials.Es * e;
        return Math.Max(-fsu, Math.Min(fsu, s));
    }

    private static double Strain(double y, double x, double d, double h)
    {
        if (x <= 3.5 / 13.5 * d) return 10e-3 * (x - y) / (d - x);          // pivot A
        if (x <= h) return 3.5e-3 * (x - y) / x;                            // pivot B
        return 2e-3 * (x - y) / (x - 3.0 * h / 7.0);                        // pivot C
    }

    /// <summary>Résultantes (N, M/centre) pour un axe neutre à la profondeur x depuis la fibre la plus comprimée.
    /// asT : aciers à y=d (face tendue), asC : aciers à y=dp (face comprimée), en m².</summary>
    public static (double N, double M) Resultants(double b, double h, double d, double dp,
                                                  double asT, double asC, double fbu, double fsu, double x)
    {
        double xc = Math.Min(x, h);
        double dy = xc / Slices;
        double fc = 0, mc = 0;
        for (int i = 0; i < Slices; i++)
        {
            double y = (i + 0.5) * dy;
            double f = ConcreteStress(Strain(y, x, d, h), fbu) * b * dy;
            fc += f;
            mc += f * (h / 2 - y);
        }
        double sC = SteelStress(Strain(dp, x, d, h), fsu);
        double sT = SteelStress(Strain(d, x, d, h), fsu);
        double n = fc + asC * sC + asT * sT;
        double m = mc + asC * sC * (h / 2 - dp) + asT * sT * (h / 2 - d);
        return (n, m);
    }

    /// <summary>Profondeur d'axe neutre x telle que N_R(x) = Nu ; -1 si Nu est hors de la capacité de la section.</summary>
    public static double FindX(double b, double h, double d, double dp, double asT, double asC,
                               double fbu, double fsu, double nu)
    {
        double lo = 1e-4, hi = 100.0 * h;
        if (Resultants(b, h, d, dp, asT, asC, fbu, fsu, lo).N > nu) return -1;
        if (Resultants(b, h, d, dp, asT, asC, fbu, fsu, hi).N < nu) return -1;
        for (int i = 0; i < 60; i++)
        {
            double mid = 0.5 * (lo + hi);
            if (Resultants(b, h, d, dp, asT, asC, fbu, fsu, mid).N < nu) lo = mid; else hi = mid;
        }
        return 0.5 * (lo + hi);
    }
}
