namespace StructCalc.Core.Codes.BAEL91;

/// <summary>Caractéristiques de calcul BAEL 91 révisé 99. Contraintes en MPa.</summary>
public static class Bael91Materials
{
    public const double Es = 200000.0;
    public const double N = 15.0;                                          // coefficient d'équivalence
    public static double Ft28(double fc28) => 0.6 + 0.06 * fc28;           // fc28 <= 60 MPa
    public static double GammaB(LimitState s) => s == LimitState.Accidental ? 1.15 : 1.5;
    public static double GammaS(LimitState s) => s == LimitState.Accidental ? 1.00 : 1.15;
    public static double Fbu(double fc28, LimitState s, double theta = 1.0) => 0.85 * fc28 / (theta * GammaB(s));
    public static double SigmaSu(double fe, LimitState s) => fe / GammaS(s);
    public static double EpsilonSl(double fe, LimitState s) => SigmaSu(fe, s) / Es;
    public static double SigmaBcServ(double fc28) => 0.6 * fc28;

    /// <summary>Contrainte limite de l'acier à l'ELS. eta = 1,6 pour HA.</summary>
    public static double SigmaSServ(double fe, double fc28, CrackingClass c, double eta = 1.6) => c switch
    {
        CrackingClass.PeuPrejudiciable => fe,
        CrackingClass.Prejudiciable => Math.Min(2.0 / 3.0 * fe, Math.Max(0.5 * fe, 110.0 * Math.Sqrt(eta * Ft28(fc28)))),
        _ => Math.Min(0.5 * fe, 90.0 * Math.Sqrt(eta * Ft28(fc28))),
    };
}
