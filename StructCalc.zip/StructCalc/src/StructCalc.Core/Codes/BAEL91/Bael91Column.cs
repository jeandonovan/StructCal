namespace StructCalc.Core.Codes.BAEL91;

public partial class Bael91Code
{
    /// <summary>Coefficient de combinaison de la flexion biaxiale (approximation forfaitaire, à ajuster si besoin).</summary>
    public const double BiaxialBeta = 0.8;

    /// <summary>Limites de section d'acier (cm², total) : BAEL = max(4 cm²/m de périmètre ; 0,2 % B) et 5 % B.</summary>
    protected virtual (double min, double max) ColumnAsLimits(ColumnInput i)
    {
        double area = i.Bw * i.Hd;
        return (Math.Max(4.0 * 2.0 * (i.Bw + i.Hd), 0.002 * area * 1e4), 0.05 * area * 1e4);
    }

    /// <summary>Moment total de calcul autour d'un axe : excentricités de 1er ordre, accidentelle et du 2nd ordre (méthode forfaitaire BAEL A.4.3,5).</summary>
    protected virtual double TotalMoment(double mKNm, double nKN, double depth, double lf, ColumnInput i, DesignResult r, string tag)
    {
        double m = Math.Abs(mKNm);
        if (nKN <= 1.0) return m;
        double e0 = m / nKN;
        double ea = Math.Max(0.02, lf / 250.0);
        double e1 = e0 + ea;
        double lim = Math.Max(15.0, 20.0 * e1 / depth);
        if (lf / depth > lim)
            r.Fail($"Poteau élancé ({tag}) : lf/h={lf / depth:F1} > {lim:F1} ; méthode forfaitaire non applicable (calcul de flambement requis).");
        double e2 = 3.0 * lf * lf * (2.0 + 2.0) / (1e4 * depth);     // alpha*phi = 2 (hypothèse sécuritaire)
        r.Notes.Add($"{tag} : e0={e0 * 100:F1} cm, ea={ea * 100:F1} cm, e2={e2 * 100:F1} cm");
        return nKN * (e1 + e2);
    }

    /// <summary>Poteau en flexion composée (biaxiale approchée) : armatures symétriques par compatibilité des déformations.</summary>
    public virtual DesignResult DesignColumn(ColumnInput i)
    {
        var r = new DesignResult { Element = "Poteau - flexion composée" };
        double nuMN = i.NuKN / 1000.0;
        double fbu = Fcd(i.Fc28, i.State);
        double fsu = Fyd(i.Fe, i.State);
        double lambda = i.Lf * Math.Sqrt(12) / Math.Min(i.Bw, i.Hd);
        r.Values["lambda"] = lambda;
        if (lambda > 70 && Id != "EC2" && Id != "EC8") r.Fail($"Élancement {lambda:F1} > 70.");

        double mH = TotalMoment(i.MyKNm, i.NuKN, i.Hd, i.Lf, i, r, "plan de h");
        double mB = TotalMoment(i.MzKNm, i.NuKN, i.Bw, i.Lf, i, r, "plan de b");

        double depth, width, mEq;
        if (mH / i.Hd >= mB / i.Bw) { depth = i.Hd; width = i.Bw; mEq = mH + BiaxialBeta * (i.Hd / i.Bw) * mB; }
        else { depth = i.Bw; width = i.Hd; mEq = mB + BiaxialBeta * (i.Bw / i.Hd) * mH; }
        double dd = depth - i.Cover, dp = i.Cover;
        var (asMinTot, asMaxTot) = ColumnAsLimits(i);
        double mEqMN = mEq / 1000.0;

        bool Ok(double asFace)
        {
            double x = Bael91Section.FindX(width, depth, dd, dp, asFace, asFace, fbu, fsu, nuMN);
            if (x < 0) return false;
            var (_, m) = Bael91Section.Resultants(width, depth, dd, dp, asFace, asFace, fbu, fsu, x);
            return m >= mEqMN;
        }

        double faceMax = asMaxTot / 2.0 * 1e-4;
        double asReq;
        if (!Ok(faceMax))
        {
            asReq = asMaxTot;
            r.Fail($"Section insuffisante (As > {asMaxTot / (i.Bw * i.Hd * 1e4) * 100:F0} % B) : augmenter les dimensions.");
        }
        else if (Ok(0.0)) asReq = 0.0;
        else
        {
            double lo = 0.0, hi = faceMax;
            for (int k = 0; k < 30; k++)
            {
                double mid = 0.5 * (lo + hi);
                if (Ok(mid)) hi = mid; else lo = mid;
            }
            asReq = 2.0 * hi * 1e4;
        }
        double asFinal = Math.Max(asReq, asMinTot);
        r.Values["As_req_cm2"] = asReq; r.Values["As_min_cm2"] = asMinTot; r.Values["As_max_cm2"] = asMaxTot;
        r.Values["As_cm2"] = asFinal; r.Values["M_eq_kNm"] = mEq; r.Values["Nu_kN"] = i.NuKN;
        r.Notes.Add($"Nu={i.NuKN:F0} kN, M_eq={mEq:F1} kN.m (biaxial beta={BiaxialBeta}), lambda={lambda:F1}");
        r.Notes.Add($"As_req={asReq:F2}, As_min={asMinTot:F2}, As_max={asMaxTot:F2} -> As={asFinal:F2} cm² (total, symétrique)");
        return r;
    }
}
