namespace StructCalc.Core.Codes.BAEL91;

/// <summary>BAEL 91 révisé 99. Les autres normes BA (CBA93, EC2, RPA99, EC8) en héritent et redéfinissent les points spécifiques (virtual).</summary>
public partial class Bael91Code : IReinforcedConcreteCode
{
    public virtual string Id => "BAEL91";
    public virtual string DisplayName => "BAEL 91 révisé 99 - Béton armé";
    public MaterialKind Material => MaterialKind.ReinforcedConcrete;
    public virtual bool IsImplemented => true;

    protected static IReadOnlyDictionary<ActionType, double> F(double g = 0, double q = 0, double w = 0, double e = 0) =>
        new Dictionary<ActionType, double> { { ActionType.G, g }, { ActionType.Q, q }, { ActionType.W, w }, { ActionType.E, e } };

    /// <summary>Combinaisons fondamentales. Vent : 1,5 W ; 1,3·psi0 = 1,0 (psi0 = 0,77) en accompagnement.</summary>
    public virtual IReadOnlyList<Combination> Combinations { get; } = new[]
    {
        new Combination("ELU 1.35G+1.5Q",          LimitState.ELU, F(1.35, 1.5, 0)),
        new Combination("ELU 1.35G+1.5W+1.0Q",     LimitState.ELU, F(1.35, 1.0, 1.5)),
        new Combination("ELU 1.35G-1.5W+1.0Q",     LimitState.ELU, F(1.35, 1.0, -1.5)),
        new Combination("ELU 1.35G+1.5Q+1.0W",     LimitState.ELU, F(1.35, 1.5, 1.0)),
        new Combination("ELU 1.35G+1.5Q-1.0W",     LimitState.ELU, F(1.35, 1.5, -1.0)),
        new Combination("ELU G+1.5W",              LimitState.ELU, F(1.0, 0, 1.5)),
        new Combination("ELU G-1.5W",              LimitState.ELU, F(1.0, 0, -1.5)),
        new Combination("ELS G+Q",                 LimitState.ELS, F(1.0, 1.0, 0)),
        new Combination("ELS G+W",                 LimitState.ELS, F(1.0, 0.77, 1.0)),
        new Combination("ELS G-W",                 LimitState.ELS, F(1.0, 0.77, -1.0)),
        new Combination("ELS G+Q+0.77W",           LimitState.ELS, F(1.0, 1.0, 0.77)),
        new Combination("ELS G+Q-0.77W",           LimitState.ELS, F(1.0, 1.0, -0.77)),
    };

    // ------------------------------------------------------------------ points de variation entre normes
    protected virtual double Fcd(double fc28, LimitState s) => Bael91Materials.Fbu(fc28, s);
    protected virtual double Fyd(double fe, LimitState s) => Bael91Materials.SigmaSu(fe, s);
    protected virtual double Fct(double fc28) => Bael91Materials.Ft28(fc28);
    protected virtual double SigmaSLimit(double fe, double fc28, CrackingClass c) => Bael91Materials.SigmaSServ(fe, fc28, c);
    protected virtual double SigmaBcLimit(double fc28) => Bael91Materials.SigmaBcServ(fc28);
    /// <summary>Position relative limite de l'axe neutre (x/d) en flexion simple.</summary>
    protected virtual double XiLimit(double fe, LimitState s) => 3.5 / (3.5 + 1000.0 * Fyd(fe, s) / Bael91Materials.Es);
    protected virtual double AsMinBeam(double b, double d, double fc28, double fe) => 0.23 * b * d * Fct(fc28) / fe * 1e4;
    protected virtual double SlabTauLimit(double fc28, double dMeters) => 0.07 * fc28 / 1.5;
    public virtual double BeamMinTotalAsCm2(RcRectSection s) => 0;
    public virtual double NodalStirrupSpacingCm(bool isColumn, double hCm, double minBarMm) => 0;

    // ---------------------------------------------------------- POUTRE : FLEXION
    /// <summary>Flexion simple, section rectangulaire. Mu, Mser en kN.m ; As en cm².</summary>
    public virtual DesignResult DesignBeamFlexure(RcRectSection s, double fc28, double fe, double muKNm, double mserKNm,
                                                  CrackingClass crack, LimitState state = LimitState.ELU)
    {
        var r = new DesignResult { Element = "Flexion simple" };
        double b = s.B, d = s.D, dp = s.Dprime;
        double fbu = Fcd(fc28, state);
        double fsu = Fyd(fe, state);
        double epsL = fsu / Bael91Materials.Es;
        double alphaL = XiLimit(fe, state);
        double muL = 0.8 * alphaL * (1 - 0.4 * alphaL);
        double Mu = Math.Abs(muKNm) / 1000.0;                         // MN.m
        double mu = Mu / (b * d * d * fbu);
        r.Notes.Add($"fcd={fbu:F2} MPa, fyd={fsu:F1} MPa, x/d lim={alphaL:F3}, mu_lim={muL:F3} ({state})");
        r.Notes.Add($"mu = Mu/(b d² fcd) = {mu:F4}");

        double asU, asComp = 0;
        if (mu <= muL)
        {
            double alpha = 1.25 * (1 - Math.Sqrt(1 - 2 * mu));
            double z = d * (1 - 0.4 * alpha);
            asU = Mu / (z * fsu) * 1e4;
            r.Notes.Add($"Pas d'aciers comprimés : alpha={alpha:F3}, z={z:F3} m, As={asU:F2} cm²");
        }
        else
        {
            double Mr = muL * b * d * d * fbu;
            double dM = Mu - Mr;
            double zl = d * (1 - 0.4 * alphaL);
            double epsSc = 3.5e-3 * (alphaL * d - dp) / (alphaL * d);
            double sigSc = epsSc >= epsL ? fsu : epsSc * Bael91Materials.Es;
            asComp = dM / ((d - dp) * sigSc) * 1e4;
            asU = (Mr / (zl * fsu) + dM / ((d - dp) * fsu)) * 1e4;
            r.Notes.Add($"mu > mu_lim : aciers comprimés. As'={asComp:F2} cm², As={asU:F2} cm²");
            r.Warnings.Add("Armatures doublées : envisager d'augmenter h.");
        }

        double asMin = AsMinBeam(b, d, fc28, fe);
        double asEls = 0;
        if (state != LimitState.Accidental)
        {
            asEls = ElsSteelArea(s, fc28, fe, Math.Abs(mserKNm) / 1000.0, asComp * 1e-4, crack, out string elsNote);
            r.Notes.Add(elsNote);
        }
        double asFinal = Math.Max(asU, Math.Max(asMin, asEls));
        r.Values["mu"] = mu; r.Values["mu_l"] = muL;
        r.Values["As_ELU_cm2"] = asU; r.Values["As_min_cm2"] = asMin; r.Values["As_ELS_cm2"] = asEls;
        r.Values["As_cm2"] = asFinal; r.Values["As_comp_cm2"] = asComp;
        r.Notes.Add($"As retenue = max(ELU, ELS, Amin) = {asFinal:F2} cm²");
        if (asFinal > 0.04 * b * s.H * 1e4) r.Fail("As > 4 % de la section.");
        return r;
    }

    /// <summary>Contraintes ELS, section fissurée. As, AsC en m², Mser en MN.m.</summary>
    public static (double y, double I, double sigBc, double sigS) ServiceStresses(RcRectSection s, double As, double AsC, double Mser)
    {
        double n = Bael91Materials.N, b = s.B, d = s.D, dp = s.Dprime;
        double A = b / 2, B = n * (AsC + As), C = -n * (AsC * dp + As * d);
        double y = (-B + Math.Sqrt(B * B - 4 * A * C)) / (2 * A);
        double I = b * y * y * y / 3 + n * AsC * (y - dp) * (y - dp) + n * As * (d - y) * (d - y);
        return (y, I, Mser * y / I, n * Mser * (d - y) / I);
    }

    private double ElsSteelArea(RcRectSection s, double fc28, double fe, double mser, double asC, CrackingClass crack, out string note)
    {
        double limS = SigmaSLimit(fe, fc28, crack);
        double limB = SigmaBcLimit(fc28);
        if (mser <= 0) { note = "ELS : Mser nul."; return 0; }
        double As = 1e-4;
        for (int i = 0; i < 5000; i++)
        {
            var (_, _, sb, ss) = ServiceStresses(s, As, asC, mser);
            if (ss <= limS && sb <= limB) break;
            As *= 1.005;
        }
        var res = ServiceStresses(s, As, asC, mser);
        note = $"ELS ({crack}) : sigma_s lim={limS:F0} MPa, sigma_bc lim={limB:F1} MPa -> As={As * 1e4:F2} cm² (sigma_s={res.sigS:F0}, sigma_bc={res.sigBc:F1})";
        return As * 1e4;
    }

    // ---------------------------------------------------------- POUTRE : EFFORT TRANCHANT
    /// <summary>BAEL A.5 : cadres droits, K=1, alpha=90°.</summary>
    public virtual DesignResult DesignBeamShear(RcRectSection s, double fc28, double fe, double vuKN, CrackingClass crack,
                                                LimitState state = LimitState.ELU)
    {
        var r = new DesignResult { Element = "Effort tranchant" };
        double Vu = Math.Abs(vuKN) / 1000.0, b = s.B, d = s.D;
        double tau = Vu / (b * d);
        double gb = Bael91Materials.GammaB(state), ft = Bael91Materials.Ft28(fc28);
        double tauLim = crack == CrackingClass.PeuPrejudiciable
            ? Math.Min(0.20 * fc28 / gb, 5.0) : Math.Min(0.15 * fc28 / gb, 4.0);
        r.Notes.Add($"tau_u = {tau:F3} MPa ; tau_lim = {tauLim:F2} MPa ({state})");
        if (tau > tauLim) r.Fail($"tau_u={tau:F2} > tau_lim={tauLim:F2} MPa : augmenter la section.");

        double gs = Bael91Materials.GammaS(state);
        double atSt1 = b * (tau - 0.3 * ft) * gs / (0.9 * fe);             // m²/m
        double atSt2 = 0.4 * b / fe;
        double atSt = Math.Max(Math.Max(atSt1, atSt2), 0);
        double stMax = Math.Min(0.9 * d, 0.40);
        r.Values["tau_u"] = tau; r.Values["tau_lim"] = tauLim;
        r.Values["At_over_st_cm2_per_m"] = atSt * 1e4;
        r.Values["st_max_cm"] = stMax * 100;
        r.Notes.Add($"At/st = {atSt * 1e4:F2} cm²/m ; st <= {stMax * 100:F1} cm");
        return r;
    }

    // ---------------------------------------------------------- POUTRE : FLÈCHE forfaitaire (B.6.5,1)
    public virtual DesignResult CheckBeamDeflection(RcRectSection s, double span, double fc28, double fe, double asCm2, double mtKNm, double m0KNm)
    {
        var r = new DesignResult { Element = "Flèche (vérification forfaitaire)" };
        double hl = s.H / span;
        bool c1 = hl >= 1.0 / 16.0;
        bool c2 = m0KNm <= 1e-9 || hl >= mtKNm / (10.0 * m0KNm);
        double rho = asCm2 * 1e-4 / (s.B * s.D);
        bool c3 = rho <= 4.2 / fe;
        r.Values["h_over_L"] = hl; r.Values["rho"] = rho; r.Values["rho_lim"] = 4.2 / fe;
        r.Notes.Add($"h/L={hl:F3} (>=1/16 : {c1}) ; h/L >= Mt/(10 M0) : {c2} ; A/(b d)={rho:E2} <= 4.2/fe={4.2 / fe:E2} : {c3}");
        bool all = c1 && c2 && c3;
        r.Values["needs_calc"] = all ? 0 : 1;
        if (!all) r.Warnings.Add("Conditions forfaitaires non satisfaites : calcul de flèche requis.");
        return r;
    }
}
