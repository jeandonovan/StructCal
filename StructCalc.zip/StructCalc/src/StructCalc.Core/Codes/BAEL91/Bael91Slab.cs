namespace StructCalc.Core.Codes.BAEL91;

public partial class Bael91Code
{
    // Dalle rectangulaire articulée sur 4 côtés, charge uniforme (BAEL Annexe E.3). A VÉRIFIER avec votre exemplaire du texte.
    private static readonly double[] Rho  = { 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00 };
    private static readonly double[] MuxU = { 0.1101, 0.1036, 0.0966, 0.0894, 0.0822, 0.0751, 0.0684, 0.0621, 0.0561, 0.0506, 0.0456, 0.0410, 0.0368 };
    private static readonly double[] MuyU = { 0.2500, 0.2500, 0.2500, 0.2500, 0.2500, 0.2703, 0.3075, 0.3613, 0.4292, 0.5017, 0.5959, 0.7461, 1.0000 };
    private static readonly double[] MuxS = { 0.1121, 0.1063, 0.1000, 0.0936, 0.0870, 0.0805, 0.0743, 0.0684, 0.0628, 0.0576, 0.0528, 0.0483, 0.0441 };
    private static readonly double[] MuyS = { 0.2854, 0.3234, 0.3671, 0.4150, 0.4672, 0.5235, 0.5817, 0.6447, 0.7111, 0.7794, 0.8502, 0.9236, 1.0000 };

    private static double Interp(double[] t, double rho)
    {
        if (rho <= Rho[0]) return t[0];
        if (rho >= Rho[^1]) return t[^1];
        for (int k = 0; k < Rho.Length - 1; k++)
            if (rho <= Rho[k + 1])
            {
                double f = (rho - Rho[k]) / (Rho[k + 1] - Rho[k]);
                return t[k] + f * (t[k + 1] - t[k]);
            }
        return t[^1];
    }

    /// <summary>Méthode des coefficients (BAEL Annexe E.3) : réglage par défaut. Les autres méthodes (Caquot, lignes de rupture, bandes, éléments finis...)
    /// fournissent leurs moments à <see cref="DesignSlabFromMoments"/>.</summary>
    public virtual DesignResult DesignSlab(SlabInput i)
    {
        var r = new DesignResult { Element = "Dalle" };
        double lx = Math.Min(i.Lx, i.Ly), ly = Math.Max(i.Lx, i.Ly), rho = lx / ly, h = i.H;
        double g = 25.0 * h + i.GExtra;
        double pu = 1.35 * g + 1.5 * i.Q, ps = g + i.Q;
        double mxU, myU, mxS, myS;
        if (rho < 0.4)
        {
            mxU = pu * lx * lx / 8; myU = mxU / 4;
            mxS = ps * lx * lx / 8; myS = mxS / 4;
            r.Notes.Add($"rho={rho:F2} < 0.4 : dalle portant dans un seul sens (armatures de répartition = As/4).");
        }
        else
        {
            mxU = Interp(MuxU, rho) * pu * lx * lx; myU = Interp(MuyU, rho) * mxU;
            mxS = Interp(MuxS, rho) * ps * lx * lx; myS = Interp(MuyS, rho) * mxS;
        }
        r.Notes.Add($"g={g:F2} kN/m², pu={pu:F2}, ps={ps:F2} kN/m² ; rho={rho:F2}");
        r.Notes.Add($"M0x={mxU:F2}, M0y={myU:F2} kN.m/m (ELU)");

        (double kt, double ka) = i.Continuity switch
        {
            SlabContinuity.Simple => (1.0, 0.0),
            SlabContinuity.Rive => (0.85, 0.5),
            _ => (0.75, 0.5),
        };
        var mo = new SlabMoments
        {
            Method = "Coefficients (BAEL Annexe E.3)",
            MtxU = kt * mxU, MtxS = kt * mxS, MtyU = kt * myU, MtyS = kt * myS,
            MaxU = ka * mxU, MaxS = ka * mxS, MayU = ka * myU, MayS = ka * myS,
            M0xS = mxS
        };
        return FinishSlab(i, r, mo);
    }

    /// <summary>Dimensionne une dalle à partir de moments fournis par une autre méthode de calcul (kN.m/m, x = petite portée, y = grande portée).</summary>
    public virtual DesignResult DesignSlabFromMoments(SlabInput i, SlabMoments mo)
    {
        var r = new DesignResult { Element = "Dalle" };
        double lx = Math.Min(i.Lx, i.Ly), ly = Math.Max(i.Lx, i.Ly), g = 25.0 * i.H + i.GExtra;
        double pu = 1.35 * g + 1.5 * i.Q, ps = g + i.Q;
        r.Notes.Add($"g={g:F2} kN/m², pu={pu:F2}, ps={ps:F2} kN/m² ; rho={lx / ly:F2}");
        r.Notes.Add($"Méthode de calcul : {mo.Method}");
        r.Notes.AddRange(mo.Notes);
        r.Warnings.AddRange(mo.Warnings);
        return FinishSlab(i, r, mo);
    }

    private DesignResult FinishSlab(SlabInput i, DesignResult r, SlabMoments mo)
    {
        double lx = Math.Min(i.Lx, i.Ly), ly = Math.Max(i.Lx, i.Ly), rho = lx / ly, h = i.H;
        double g = 25.0 * h + i.GExtra;
        double pu = 1.35 * g + 1.5 * i.Q, ps = g + i.Q;

        var secX = new RcRectSection(1.0, h, i.Cover, i.Cover);
        var secY = new RcRectSection(1.0, h, i.Cover + 0.012, i.Cover + 0.012);
        double rho0 = i.Fe >= 500 ? 0.0006 : 0.0008;
        double hcm = h * 100.0;
        double asMinY = rho0 * 100.0 * hcm;
        double asMinX = rho0 * (3.0 - rho) / 2.0 * 100.0 * hcm;

        double AsOf(DesignResult d, double min) => Math.Max(d.Values["As_cm2"], min);

        var xt = DesignBeamFlexure(secX, i.Fc28, i.Fe, mo.MtxU, mo.MtxS, i.Crack);
        var yt = DesignBeamFlexure(secY, i.Fc28, i.Fe, mo.MtyU, mo.MtyS, i.Crack);
        double asXt = AsOf(xt, asMinX), asYt = AsOf(yt, asMinY);
        if (rho < 0.4) asYt = Math.Max(asYt, asXt / 4.0);
        double asXa = 0, asYa = 0;
        bool supX = mo.MaxU > 1e-9, supY = mo.MayU > 1e-9, ka = supX || supY;
        if (supX)
        {
            var xa = DesignBeamFlexure(secX, i.Fc28, i.Fe, mo.MaxU, mo.MaxS, i.Crack);
            asXa = AsOf(xa, asMinX);
            if (!xa.Ok) r.Fail("Section de dalle insuffisante sur appui.");
        }
        if (supY)
        {
            var ya = DesignBeamFlexure(secY, i.Fc28, i.Fe, mo.MayU, mo.MayS, i.Crack);
            asYa = AsOf(ya, asMinY);
            if (!ya.Ok) r.Fail("Section de dalle insuffisante sur appui.");
        }
        r.Notes.Add($"Moments retenus (ELU, kN.m/m) : travée x = {mo.MtxU:F2}, travée y = {mo.MtyU:F2}, appui x = {mo.MaxU:F2}, appui y = {mo.MayU:F2}");
        if (!xt.Ok || !yt.Ok) r.Fail("Section de dalle insuffisante en travée : augmenter h.");

        r.Values["rho"] = rho; r.Values["pu"] = pu; r.Values["ps"] = ps;
        r.Values["Asx_travee_cm2m"] = asXt; r.Values["Asy_travee_cm2m"] = asYt;
        r.Values["Asx_appui_cm2m"] = asXa; r.Values["Asy_appui_cm2m"] = asYa;

        double dX = secX.D;
        double vux = mo.VuX > 0 ? mo.VuX : (rho < 0.4 ? pu * lx / 2 : pu * lx / (2.0 + rho));
        double vuy = mo.VuY > 0 ? mo.VuY : pu * lx / 3.0;
        double tau = Math.Max(vux, vuy) / 1000.0 / (1.0 * dX);
        double tauLim = SlabTauLimit(i.Fc28, dX);
        r.Values["tau_u"] = tau; r.Values["tau_lim"] = tauLim;
        r.Notes.Add($"Vu={Math.Max(vux, vuy):F1} kN/m ; tau_u={tau:F3} <= {tauLim:F3} MPa (sans armatures d'effort tranchant)");
        if (tau > tauLim) r.Fail("Effort tranchant dalle : tau_u > tau_lim, augmenter h.");

        double m0 = mo.M0xS > 1e-9 ? mo.M0xS : Math.Max(mo.MtxS + 0.5 * mo.MaxS, 1e-9);
        bool defl = h / lx >= Math.Max(3.0 / 80.0, mo.MtxS / (20.0 * m0)) && asXt * 1e-4 / dX <= 2.0 / i.Fe;
        r.Values["needs_deflection_calc"] = defl ? 0 : 1;
        if (!defl) r.Warnings.Add("Flèche : conditions forfaitaires non satisfaites, calcul de flèche requis.");

        var cfg = i.Settings;
        double maxMain = Math.Min(3 * hcm, cfg?.SlabMaxMainSpacingCm ?? 33.0), maxDist = Math.Min(4 * hcm, cfg?.SlabMaxDistribSpacingCm ?? 45.0);
        var sx = RebarSelector.Spacing(asXt, maxMain, cfg);
        var sy = RebarSelector.Spacing(asYt, maxDist, cfg);
        r.Texts["Travée sens lx"] = $"HA{sx.Dia} e={sx.SpacingCm:F0} cm ({asXt:F2} cm²/m)";
        r.Texts["Travée sens ly"] = $"HA{sy.Dia} e={sy.SpacingCm:F0} cm ({asYt:F2} cm²/m)";
        if (ka)
        {
            var ax = RebarSelector.Spacing(Math.Max(asXa, asMinX), maxMain, cfg);
            var ay = RebarSelector.Spacing(Math.Max(asYa, asMinY), maxDist, cfg);
            r.Texts["Appui sens lx"] = $"HA{ax.Dia} e={ax.SpacingCm:F0} cm ({Math.Max(asXa, asMinX):F2} cm²/m)";
            r.Texts["Appui sens ly"] = $"HA{ay.Dia} e={ay.SpacingCm:F0} cm ({Math.Max(asYa, asMinY):F2} cm²/m)";
        }
        return r;
    }
}

/// <summary>Moments de calcul d'une dalle (kN.m/m) fournis par une méthode : x = petite portée, y = grande portée ; U = ELU, S = ELS.</summary>
public sealed class SlabMoments
{
    public string Method = "";
    public double MtxU, MtxS, MtyU, MtyS;      // travée
    public double MaxU, MaxS, MayU, MayS;      // appui (valeurs absolues)
    public double M0xS;                        // moment isostatique ELS de référence (vérification de flèche) ; 0 = déduit
    public double VuX, VuY;                    // tranchant ELU (kN/m) ; 0 = formules de la méthode des coefficients
    public List<string> Notes = new();
    public List<string> Warnings = new();
}
