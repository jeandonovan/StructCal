namespace StructCalc.Core.Codes.BAEL91;

public partial class Bael91Code
{
    private static double Ceil5(double v) => Math.Ceiling(v / 0.05 - 1e-9) * 0.05;

    /// <summary>Semelle isolée rectangulaire sous poteau centré, méthode des bielles.</summary>
    public virtual DesignResult DesignIsolatedFooting(FootingInput i)
    {
        var r = new DesignResult { Element = "Semelle isolée" };
        if (i.SigmaSolKPa <= 0) { r.Fail("Contrainte admissible du sol non définie."); return r; }
        double a = i.ColA, b = i.ColB;
        double S = 1.1 * i.NserKN / i.SigmaSolKPa;
        double Bf = Math.Sqrt(S * b / a), Af = S / Bf;
        Af = Math.Max(Ceil5(Af), Ceil5(a + 0.10));
        Bf = Math.Max(Ceil5(Bf), Ceil5(b + 0.10));
        double h = 0.30;
        for (int it = 0; it < 300; it++)
        {
            double dNeed = Math.Max((Af - a) / 4.0, (Bf - b) / 4.0);
            h = Math.Max(0.30, Ceil5(dNeed + i.Cover));
            double sig = (i.NserKN + 25.0 * Af * Bf * h) / (Af * Bf);
            if (sig <= i.SigmaSolKPa) break;
            Af += 0.05; Bf += 0.05;
        }
        double d = h - i.Cover;
        double sigServ = (i.NserKN + 25.0 * Af * Bf * h) / (Af * Bf);
        double fsu = Fyd(i.Fe, LimitState.ELU);
        double ss = SigmaSLimit(i.Fe, i.Fc28, CrackingClass.Prejudiciable);
        double nuMN = i.NuKN / 1000.0, nsMN = i.NserKN / 1000.0;
        double ft = Fct(i.Fc28);

        double asAU = nuMN * (Af - a) / (8 * d * fsu) * 1e4, asAS = nsMN * (Af - a) / (8 * d * ss) * 1e4;
        double asBU = nuMN * (Bf - b) / (8 * d * fsu) * 1e4, asBS = nsMN * (Bf - b) / (8 * d * ss) * 1e4;
        double asA = Math.Max(Math.Max(asAU, asAS), 0.23 * Bf * d * ft / i.Fe * 1e4);
        double asB = Math.Max(Math.Max(asBU, asBS), 0.23 * Af * d * ft / i.Fe * 1e4);

        r.Values["A_m"] = Af; r.Values["B_m"] = Bf; r.Values["h_m"] = h; r.Values["d_m"] = d;
        r.Values["As_A_cm2"] = asA; r.Values["As_B_cm2"] = asB; r.Values["sigma_ser_kPa"] = sigServ;
        r.Notes.Add($"Dimensions A x B = {Af:F2} x {Bf:F2} m, h={h:F2} m, d={d:F2} m (d >= (A-a)/4 et (B-b)/4)");
        r.Notes.Add($"sigma_ser (avec poids propre) = {sigServ:F0} kPa <= {i.SigmaSolKPa:F0} kPa");
        r.Notes.Add($"Nappe // A : As = {asA:F2} cm² (ELU {asAU:F2}, ELS {asAS:F2}) ; Nappe // B : As = {asB:F2} cm² (ELU {asBU:F2}, ELS {asBS:F2})");
        var sa = RebarSelector.Spacing(asA / Bf, 25);
        var sb = RebarSelector.Spacing(asB / Af, 25);
        r.Texts["Nappe // A"] = $"HA{sa.Dia} e={sa.SpacingCm:F0} cm";
        r.Texts["Nappe // B"] = $"HA{sb.Dia} e={sb.SpacingCm:F0} cm";
        if (sigServ > i.SigmaSolKPa) r.Fail("Contrainte sol dépassée (boucle d'agrandissement interrompue).");
        return r;
    }
}
