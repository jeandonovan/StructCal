using StructCalc.Core.Steel;

namespace StructCalc.Core.Codes.EC3;

/// <summary>EC3 version prénorme ENV 1993-1-1 (§5.5), telle qu'exposée dans le cours ISABTP (P. Maron, chap. 8 et 9) :
/// flambement chi (courbes a0..d), déversement lam_LT = (L/iz)/sqrt(C1) ... ou via Mcr, interaction N+M par les coefficients ky, kz, kLT
/// (mu_y, mu_z, mu_LT) et les facteurs de moment uniforme équivalent beta_M (Fig. 8.10). gamma_M1 = 1,0. Classes 1 à 3.</summary>
public class Ec3EnvCode : Ec3Code
{
    public override string Id => "EC3ENV";
    public override string DisplayName => "Eurocode 3 ENV 1993-1-1 (cours ISA) - Charpente métallique";

    /// <summary>beta_M = beta_M,psi + MQ/dM (beta_M,Q - beta_M,psi), Fig. 8.10. psi : rapport des moments d'extrémité (-1..1).
    /// mq : |max M| dû aux seules charges latérales ; dm : amplitude du diagramme (voir Fig. 8.10) ; point = charge ponctuelle (1,4) sinon répartie (1,3).</summary>
    public static double BetaM(double psi, double mq, double dm, bool pointLoad)
    {
        psi = Math.Max(-1.0, Math.Min(1.0, psi));
        double bpsi = 1.8 - 0.7 * psi;
        if (mq <= 1e-9 || dm <= 1e-9) return bpsi;
        double bq = pointLoad ? 1.4 : 1.3;
        return bpsi + mq / dm * (bq - bpsi);
    }

    public override DesignResult CheckMember(SteelInput i)
    {
        var p = i.P;
        var r = new DesignResult { Element = $"Acier EC3-ENV - {p.Name}" };
        const double E = 210000.0, G = 81000.0, pi2 = Math.PI * Math.PI;
        double fy = i.Fy, eps = Math.Sqrt(235.0 / fy);
        double A = p.AreaMm2, Iy = p.IyMm4, Iz = p.IzMm4, hw = p.H - 2 * p.Tf;
        double Npl = A * fy;
        double Nc = Math.Max(0, i.NKN) * 1e3, Nt = Math.Max(0, -i.NKN) * 1e3;
        double My = Math.Abs(i.MyKNm) * 1e6, Mz = Math.Abs(i.MzKNm) * 1e6;
        double Vz = Math.Abs(i.VzKN) * 1e3, Vy = Math.Abs(i.VyKN) * 1e3;

        double rF = (p.B - p.Tw - 2 * p.R) / 2.0 / p.Tf;
        int clF = rF <= 9 * eps ? 1 : rF <= 10 * eps ? 2 : rF <= 14 * eps ? 3 : 4;
        double rW = (hw - 2 * p.R) / p.Tw;
        bool comp = Nc > 0.05 * Npl;
        int clW = comp ? (rW <= 33 * eps ? 1 : rW <= 38 * eps ? 2 : rW <= 42 * eps ? 3 : 4)
                       : (rW <= 72 * eps ? 1 : rW <= 83 * eps ? 2 : rW <= 124 * eps ? 3 : 4);
        int cls = Math.Max(clF, clW);
        r.Values["classe"] = cls;
        if (cls == 4) { r.Fail($"{p.Name} : classe 4 non traitée."); r.Values["util"] = 9.99; return r; }

        double Wy = cls <= 2 ? p.WplYMm3 : p.WelYMm3, Wz = cls <= 2 ? p.WplZMm3 : p.WelZMm3;
        double Avz = Math.Max(A - 2 * p.B * p.Tf + (p.Tw + 2 * p.R) * p.Tf, hw * p.Tw);
        double Vplz = Avz * fy / Math.Sqrt(3), Vply = 2 * p.B * p.Tf * fy / Math.Sqrt(3);
        double uV = Math.Max(Vz / Vplz, Vy / Vply);
        double Mry = Wy * fy, Mrz = Wz * fy;
        double util;

        if (Nt > 0)
        {
            util = Math.Max(Nt / Npl + My / Mry + Mz / Mrz, uV);
            r.Notes.Add($"Traction + flexion : {util:F3}");
        }
        else
        {
            double Lfy = i.Lfy * 1000, Lfz = i.Lfz * 1000, Lt = Math.Max(i.Lt, 0.01) * 1000;
            double Nky = pi2 * E * Iy / (Lfy * Lfy), Nkz = pi2 * E * Iz / (Lfz * Lfz);
            double lamY = Math.Sqrt(Npl / Nky), lamZ = Math.Sqrt(Npl / Nkz);
            bool hb = p.H / p.B > 1.2;
            double chiY = Chi(lamY, hb ? 0.21 : 0.34), chiZ = Chi(lamZ, hb ? 0.34 : 0.49);
            double chiMin = Math.Min(chiY, chiZ);

            // déversement : courbe a (h/b <= 2) ou b (h/b > 2) pour les I laminés ; lam_LT via Mcr (Annexe F), kLT, kz
            double psi = Math.Max(-1.0, Math.Min(1.0, i.PsiY));
            double C1 = i.Loaded ? 1.13 : Math.Min(2.7, 1.88 - 1.40 * psi + 0.52 * psi * psi);
            double Mcr = C1 * pi2 * E * Iz / (Lt * Lt) * Math.Sqrt(p.IwMm6 / Iz + Lt * Lt * G * p.ItMm4 / (pi2 * E * Iz));
            double betaW = cls <= 2 ? 1.0 : p.WelYMm3 / p.WplYMm3;
            double lamLT = Math.Sqrt(betaW * p.WplYMm3 * fy / Mcr);
            double chiLT = lamLT > 0.4 ? Chi(lamLT, p.H / p.B <= 2 ? 0.21 : 0.34) : 1.0;

            // beta_M : moment d'extrémité psi + charges latérales (approximation : charge répartie si Loaded)
            double bMy = BetaM(psi, i.Loaded ? My * 0.5 : 0, Math.Max(My, 1e-9), false);
            double bMz = 1.8 - 0.7 * 1.0;   // Mz : moment supposé uniforme (valeur sécuritaire beta=1,8-0,7=1,1)
            double bMLT = bMy;

            double ky, kz, kLT, muY, muZ, muLT;
            double wy = cls <= 2 ? (p.WplYMm3 - p.WelYMm3) / p.WelYMm3 : 0, wz = cls <= 2 ? (p.WplZMm3 - p.WelZMm3) / p.WelZMm3 : 0;
            muY = Math.Min(lamY * (2 * bMy - 4) + wy, 0.9);
            muZ = Math.Min(lamZ * (2 * bMz - 4) + wz, 0.9);
            muLT = Math.Min(0.15 * lamZ * bMLT - 0.15, 0.9);
            ky = Math.Min(1 - muY * Nc / (chiY * Npl), 1.5);
            kz = Math.Min(1 - muZ * Nc / (chiZ * Npl), 1.5);
            kLT = Math.Min(1 - muLT * Nc / (chiZ * Npl), 1.0);

            double uN = Nc / (chiMin * Npl);
            double uNoLT = uN + ky * My / Mry + kz * Mz / Mrz;                    // sans déversement
            double uLTB = uN + kLT * My / (chiLT * Mry) + kz * Mz / Mrz;          // avec déversement (lam_LT > 0,4)
            double uSection = Nc / Npl + My / Mry + Mz / Mrz;                     // résistance de section (si k < 1)
            double main = lamLT > 0.4 ? uLTB : uNoLT;
            util = Math.Max(Math.Max(main, uSection), uV);
            r.Values["chi_y"] = chiY; r.Values["chi_z"] = chiZ; r.Values["chi_LT"] = chiLT;
            r.Notes.Add($"Classe {cls} ; lam_y={lamY:F2}, lam_z={lamZ:F2}, lam_LT={lamLT:F2} ; chi_y={chiY:F3}, chi_z={chiZ:F3}, chi_LT={chiLT:F3}");
            r.Notes.Add($"beta_M,y={bMy:F2} ; ky={ky:F3}, kz={kz:F3}, kLT={kLT:F3} ; sans déversement={uNoLT:F3}, avec déversement={uLTB:F3}, section={uSection:F3}, tranchant={uV:F3}");
        }
        r.Values["util"] = util;
        if (util > 1.0) r.Fail($"{p.Name} : taux de travail {util:F2} > 1.");
        return r;
    }
}
