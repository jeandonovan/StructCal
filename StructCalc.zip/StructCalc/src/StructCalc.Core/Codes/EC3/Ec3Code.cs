using StructCalc.Core.Steel;

namespace StructCalc.Core.Codes.EC3;

/// <summary>Eurocode 3 (EN 1993-1-1) : profilés en I laminés, classes 1 à 3, résistance de section, flambement (6.3.1), déversement (6.3.2.3),
/// interaction N+M (6.3.3, Annexe B). Non traité : classe 4, assemblages, flèche, effets du second ordre globaux.</summary>
public class Ec3Code : ISteelCode
{
    public virtual string Id => "EC3";
    public virtual string DisplayName => "Eurocode 3 (EN 1993-1-1) - Charpente métallique";
    public MaterialKind Material => MaterialKind.Steel;
    public bool IsImplemented => true;

    protected static IReadOnlyDictionary<ActionType, double> F(double g = 0, double q = 0, double w = 0, double e = 0) =>
        new Dictionary<ActionType, double> { { ActionType.G, g }, { ActionType.Q, q }, { ActionType.W, w }, { ActionType.E, e } };

    public virtual IReadOnlyList<Combination> Combinations { get; } = new[]
    {
        new Combination("ELU 1.35G+1.5Q",         LimitState.ELU, F(1.35, 1.5, 0)),
        new Combination("ELU 1.35G+1.5W+1.05Q",  LimitState.ELU, F(1.35, 1.05, 1.5)),
        new Combination("ELU 1.35G-1.5W+1.05Q",  LimitState.ELU, F(1.35, 1.05, -1.5)),
        new Combination("ELU 1.35G+1.5Q+0.9W",   LimitState.ELU, F(1.35, 1.5, 0.9)),
        new Combination("ELU 1.35G+1.5Q-0.9W",   LimitState.ELU, F(1.35, 1.5, -0.9)),
        new Combination("ELU G+1.5W",             LimitState.ELU, F(1.0, 0, 1.5)),
        new Combination("ELU G-1.5W",             LimitState.ELU, F(1.0, 0, -1.5)),
        new Combination("SIS G+0.3Q+E",           LimitState.ELU, F(1.0, 0.3, 0, 1.0)),
        new Combination("SIS G+0.3Q-E",           LimitState.ELU, F(1.0, 0.3, 0, -1.0)),
        new Combination("ELS G+Q",                LimitState.ELS, F(1.0, 1.0, 0)),
    };

    protected static double Chi(double lam, double alpha)
    {
        if (lam <= 0.2) return 1.0;
        double phi = 0.5 * (1 + alpha * (lam - 0.2) + lam * lam);
        return Math.Min(1.0, 1.0 / (phi + Math.Sqrt(phi * phi - lam * lam)));
    }

    public virtual DesignResult CheckMember(SteelInput i)
    {
        var p = i.P;
        var r = new DesignResult { Element = $"Acier EC3 - {p.Name}" };
        const double E = 210000.0, G = 81000.0, pi2 = Math.PI * Math.PI;
        double fy = i.Fy, eps = Math.Sqrt(235.0 / fy);
        double A = p.AreaMm2, Iy = p.IyMm4, Iz = p.IzMm4, hw = p.H - 2 * p.Tf;
        double Npl = A * fy;
        double Nc = Math.Max(0, i.NKN) * 1e3, Nt = Math.Max(0, -i.NKN) * 1e3;
        double My = Math.Abs(i.MyKNm) * 1e6, Mz = Math.Abs(i.MzKNm) * 1e6;
        double Vz = Math.Abs(i.VzKN) * 1e3, Vy = Math.Abs(i.VyKN) * 1e3;

        // Classification (6 lames comprimées/fléchies, tableau 5.2)
        double rF = (p.B - p.Tw - 2 * p.R) / 2.0 / p.Tf;
        int clF = rF <= 9 * eps ? 1 : rF <= 10 * eps ? 2 : rF <= 14 * eps ? 3 : 4;
        double rW = (hw - 2 * p.R) / p.Tw;
        bool comp = Nc > 0.05 * Npl;
        int clW = comp ? (rW <= 33 * eps ? 1 : rW <= 38 * eps ? 2 : rW <= 42 * eps ? 3 : 4)
                       : (rW <= 72 * eps ? 1 : rW <= 83 * eps ? 2 : rW <= 124 * eps ? 3 : 4);
        int cls = Math.Max(clF, clW);
        r.Values["classe"] = cls;
        if (cls == 4)
        {
            r.Fail($"{p.Name} : section de classe 4 (non traitée). Choisir un profil plus massif.");
            r.Values["util"] = 9.99;
            return r;
        }

        double Wy = cls <= 2 ? p.WplYMm3 : p.WelYMm3;
        double Wz = cls <= 2 ? p.WplZMm3 : p.WelZMm3;
        double Wybase = Wy;
        double Avz = Math.Max(A - 2 * p.B * p.Tf + (p.Tw + 2 * p.R) * p.Tf, hw * p.Tw);
        double Vplz = Avz * fy / Math.Sqrt(3), Vply = 2 * p.B * p.Tf * fy / Math.Sqrt(3);
        double uV = Math.Max(Vz / Vplz, Vy / Vply);
        if (Vz > 0.5 * Vplz && cls <= 2)
        {
            double rho = Math.Pow(2 * Vz / Vplz - 1, 2);
            Wy -= rho * (hw * p.Tw) * (hw * p.Tw) / (4 * p.Tw);
        }
        double Mry = Wy * fy, Mrz = Wz * fy;

        double util;
        if (Nt > 0)    // traction + flexion (somme linéaire, sécuritaire)
        {
            util = Math.Max(Nt / Npl + My / Mry + Mz / Mrz, uV);
            r.Notes.Add($"Traction + flexion : Nt/Npl + My/Mry + Mz/Mrz = {util:F3}");
        }
        else
        {
            double Lfy = i.Lfy * 1000, Lfz = i.Lfz * 1000, Lt = Math.Max(i.Lt, 0.01) * 1000;
            double lamY = Math.Sqrt(Npl / (pi2 * E * Iy / (Lfy * Lfy)));
            double lamZ = Math.Sqrt(Npl / (pi2 * E * Iz / (Lfz * Lfz)));
            bool hb = p.H / p.B > 1.2;
            double chiY = Chi(lamY, hb ? 0.21 : 0.34), chiZ = Chi(lamZ, hb ? 0.34 : 0.49);

            double psi = Math.Max(-1.0, Math.Min(1.0, i.PsiY));
            double C1 = i.Loaded ? 1.13 : Math.Min(2.7, 1.88 - 1.40 * psi + 0.52 * psi * psi);
            double Mcr = C1 * pi2 * E * Iz / (Lt * Lt) * Math.Sqrt(p.IwMm6 / Iz + Lt * Lt * G * p.ItMm4 / (pi2 * E * Iz));
            double lamLT = Math.Sqrt(Wybase * fy / Mcr);
            double aLT = p.H / p.B <= 2 ? 0.34 : 0.49;
            double chiLT = 1.0;
            if (lamLT > 0.4)
            {
                double phiLT = 0.5 * (1 + aLT * (lamLT - 0.4) + 0.75 * lamLT * lamLT);
                chiLT = Math.Min(1.0, Math.Min(1.0 / (phiLT + Math.Sqrt(phiLT * phiLT - 0.75 * lamLT * lamLT)), 1.0 / (lamLT * lamLT)));
            }

            double nY = Nc / (chiY * Npl), nZ = Nc / (chiZ * Npl);
            const double Cmy = 0.9, Cmz = 0.9, CmLT = 0.9;     // mode à noeuds déplaçables (tableau B.3), sécuritaire
            double kyy = Math.Min(Cmy * (1 + (lamY - 0.2) * nY), Cmy * (1 + 0.8 * nY));
            double kzz = Math.Min(Cmz * (1 + (2 * lamZ - 0.6) * nZ), Cmz * (1 + 1.4 * nZ));
            double kyz = 0.6 * kzz;
            double kzy = lamZ < 0.4
                ? Math.Min(0.6 + lamZ, 1 - 0.1 * lamZ / (CmLT - 0.25) * nZ)
                : Math.Max(1 - 0.1 * lamZ / (CmLT - 0.25) * nZ, 1 - 0.1 / (CmLT - 0.25) * nZ);
            double u1 = nY + kyy * My / (chiLT * Mry) + kyz * Mz / Mrz;
            double u2 = nZ + kzy * My / (chiLT * Mry) + kzz * Mz / Mrz;
            double uN = Nc / (Math.Min(chiY, chiZ) * Npl);
            double uLT = My / (chiLT * Mry) + Mz / Mrz;
            util = Math.Max(Math.Max(u1, u2), Math.Max(Math.Max(uN, uLT), uV));
            r.Values["chi_y"] = chiY; r.Values["chi_z"] = chiZ; r.Values["chi_LT"] = chiLT;
            r.Notes.Add($"Classe {cls} ; lam_y={lamY:F2}, lam_z={lamZ:F2}, lam_LT={lamLT:F2} ; chi_y={chiY:F3}, chi_z={chiZ:F3}, chi_LT={chiLT:F3} ; Mcr={Mcr / 1e6:F0} kN.m (C1={C1:F2})");
            r.Notes.Add($"6.61 = {u1:F3} ; 6.62 = {u2:F3} ; compression seule = {uN:F3} ; déversement = {uLT:F3} ; effort tranchant = {uV:F3}");
        }
        r.Values["util"] = util;
        if (util > 1.0) r.Fail($"{p.Name} : taux de travail {util:F2} > 1.");
        return r;
    }
}
