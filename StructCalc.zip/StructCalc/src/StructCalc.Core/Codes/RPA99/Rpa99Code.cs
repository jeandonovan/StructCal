using StructCalc.Core.Codes.CBA93;

namespace StructCalc.Core.Codes.RPA99;

/// <summary>RPA 99 version 2003 : combinaisons accidentelles (G+Q±E ; 0,8G±E) avec gamma_b = 1,15 et gamma_s = 1,0,
/// pourcentages minimaux de ferraillage et espacements des zones nodales. Base de calcul béton : CBA93.
/// NON vérifié : dimensionnement en capacité, noeuds, voiles, vérification des déplacements inter-étages.</summary>
public class Rpa99Code : Cba93Code
{
    /// <summary>Zone sismique : I, IIa, IIb, III (renseignée par le moteur depuis le modèle).</summary>
    public string Zone { get; set; } = "IIa";

    public override string Id => "RPA99";
    public override string DisplayName => "RPA 99 v2003 (+CBA93) - Béton armé parasismique";

    public override IReadOnlyList<Combination> Combinations { get; } = Build();

    private static IReadOnlyList<Combination> Build()
    {
        var list = new List<Combination>(new Cba93Code().Combinations);
        list.Add(new Combination("ACC G+Q+E",  LimitState.Accidental, F(1.0, 1.0, 0, 1.0)));
        list.Add(new Combination("ACC G+Q-E",  LimitState.Accidental, F(1.0, 1.0, 0, -1.0)));
        list.Add(new Combination("ACC 0.8G+E", LimitState.Accidental, F(0.8, 0, 0, 1.0)));
        list.Add(new Combination("ACC 0.8G-E", LimitState.Accidental, F(0.8, 0, 0, -1.0)));
        return list;
    }

    private double ColPct => (Zone == "IIb" || Zone == "III") ? 0.009 : 0.008;

    protected override (double min, double max) ColumnAsLimits(ColumnInput i)
    {
        double area = i.Bw * i.Hd;
        return (ColPct * area * 1e4, 0.04 * area * 1e4);   // 0,8 % (I, IIa) ou 0,9 % (IIb, III) ; max 4 % en zone courante
    }

    public override DesignResult DesignColumn(ColumnInput i)
    {
        var r = base.DesignColumn(i);
        double minDim = (Zone == "IIb" || Zone == "III") ? 0.30 : 0.25;
        if (Math.Min(i.Bw, i.Hd) < minDim - 1e-9)
            r.Fail($"RPA : dimension minimale du poteau {minDim * 100:F0} cm (zone {Zone}).");
        double ratio = i.Bw / i.Hd;
        if (ratio < 0.25 || ratio > 4.0) r.Fail("RPA : 1/4 < b/h < 4 non respecté.");
        return r;
    }

    /// <summary>Poutres : pourcentage total minimal 0,5 % de la section en toute section.</summary>
    public override double BeamMinTotalAsCm2(RcRectSection s) => 0.005 * s.B * s.H * 1e4;

    /// <summary>Zone nodale : poutre t <= min(h/4 ; 12 phi_l) ; poteau t <= min(10 cm ; 15 phi_l).</summary>
    public override double NodalStirrupSpacingCm(bool isColumn, double hCm, double minBarMm) =>
        isColumn ? Math.Min(10.0, 1.5 * minBarMm) : Math.Min(hCm / 4.0, 1.2 * minBarMm);
}
