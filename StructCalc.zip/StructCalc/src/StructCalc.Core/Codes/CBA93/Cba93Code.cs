using StructCalc.Core.Codes.BAEL91;

namespace StructCalc.Core.Codes.CBA93;

/// <summary>CBA 93 (Algérie, DTR B.C.2-41). Hypothèses de calcul du béton armé identiques au BAEL 91 pour les éléments traités ici
/// (gamma_b = 1,5 ; gamma_s = 1,15 ; accidentel 1,15 / 1,0 ; ELS) : le moteur BAEL est réutilisé. À vérifier article par article.</summary>
public class Cba93Code : Bael91Code
{
    public override string Id => "CBA93";
    public override string DisplayName => "CBA 93 (Algérie) - Béton armé";
}
