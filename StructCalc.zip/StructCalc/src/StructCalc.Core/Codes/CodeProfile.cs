namespace StructCalc.Core.Codes;

/// <summary>Niveau de couverture déclaré d'une norme. « Complète » ne veut pas dire « validée » : voir VALIDATION_MOTEUR.md.</summary>
public enum CodeCoverage { Partielle, Principale, Prevue }

/// <summary>Fiche d'identité d'une norme : à quelle famille elle appartient, sur quelle autre norme elle s'appuie (héritage de moteur), ce qu'elle couvre et ce qu'elle ne couvre pas.
/// Ces fiches sont la mémoire du projet sur le périmètre réel de chaque norme ; elles servent aussi de garde-fou dans les tests d'architecture.</summary>
public sealed record CodeProfile(string Id, string Family, string Edition, string BasedOn, CodeCoverage Coverage, string Covers, string NotCovered);

/// <summary>Catalogue des fiches. Pour ajouter une norme : (1) un dossier Codes/&lt;Norme&gt;/ avec ses propres classes, (2) une fiche ici, (3) un fichier de tests dédié,
/// (4) l'attribut [AutoRegisterCode] sur la classe pour qu'elle soit découverte sans modifier le registre.</summary>
public static class CodeProfiles
{
    private static readonly List<CodeProfile> _all = new()
    {
        new("BAEL91", "Béton armé", "BAEL 91 révisé 99", "", CodeCoverage.Principale,
            "flexion simple (ELU/ELS), effort tranchant, flèche forfaitaire, poteaux en flexion composée, dalles (coefficients Annexe E.3), semelles isolées",
            "calcul de flèche par intégration des courbures, fissuration calculée (ouverture), poinçonnement détaillé hors modules dédiés"),
        new("CBA93", "Béton armé", "CBA 93 (DTR B.C.2-41)", "BAEL91", CodeCoverage.Partielle,
            "mêmes hypothèses que BAEL 91 pour les éléments traités (réutilise son moteur)",
            "vérification article par article du CBA 93 : non faite, différences éventuelles avec le BAEL non codées"),
        new("EC2", "Béton armé", "EN 1992-1-1", "BAEL91", CodeCoverage.Principale,
            "flexion (bloc rectangulaire), tranchant (bielles à inclinaison variable), flèche L/d, poteaux (courbure nominale), limitation des contraintes ELS",
            "ouverture de fissures wk, annexes nationales, dalles avec ses propres formules (la méthode des coefficients de la dalle est celle du BAEL), poinçonnement 6.4 dans les modules dédiés"),
        new("RPA99", "Béton armé parasismique", "RPA 99 v2003", "CBA93", CodeCoverage.Partielle,
            "combinaisons accidentelles, pourcentages minimaux, dimensions minimales des poteaux, zones nodales",
            "dimensionnement en capacité, nœuds, voiles, vérification des déplacements inter-étages"),
        new("EC8", "Béton armé parasismique", "EN 1998-1 (DCM)", "EC2", CodeCoverage.Partielle,
            "combinaison sismique, pourcentages minimaux, zones critiques",
            "dimensionnement en capacité (poteau fort / poutre faible), nœuds, murs, déplacements, classe de ductilité haute (DCH)"),
        new("CM66", "Acier", "CM66 / Additif 80", "", CodeCoverage.Principale,
            "flambement, déversement, flexion composée déviée (formule enveloppe 3,731), cisaillement, vérification élastique",
            "élancement fictif λ0 reconstitué à partir d'exemples (à confirmer sur le texte), coefficient d'amplification kf, neige et vent extrêmes"),
        new("EC3", "Acier", "EN 1993-1-1", "", CodeCoverage.Principale,
            "résistance des sections, flambement, déversement, interaction N-M",
            "assemblages (module séparé), classes 4 détaillées, annexes nationales"),
        new("EC3ENV", "Acier", "ENV 1993-1-1", "EC3", CodeCoverage.Partielle,
            "version prénorme (βM, vérifications de barre)",
            "tout ce qui n'est pas listé ci-contre : voir EC3 pour la version actuelle"),
    };

    public static IReadOnlyList<CodeProfile> All => _all;
    public static CodeProfile? Of(string id) => _all.FirstOrDefault(p => p.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

    /// <summary>Enregistre (ou remplace) la fiche d'une norme ajoutée par extension.</summary>
    public static void Register(CodeProfile p) { _all.RemoveAll(x => x.Id.Equals(p.Id, StringComparison.OrdinalIgnoreCase)); _all.Add(p); }
}

/// <summary>À poser sur une classe de norme (implémentant IDesignCode, avec constructeur sans paramètre) pour qu'elle soit découverte automatiquement par le registre.</summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public sealed class AutoRegisterCodeAttribute : Attribute { }
