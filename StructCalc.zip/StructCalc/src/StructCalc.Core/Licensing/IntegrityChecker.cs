using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace StructCalc.Core.Licensing;

/// <summary>Contrôle d'intégrité : un manifeste signé (integrity.sig, produit par l'outil LicenseGen après la compilation Release) liste les empreintes
/// SHA-256 des DLL/EXE StructCalc. Toute modification d'un fichier listé est détectée. Absent : build non signé, avertissement seulement.</summary>
public static class IntegrityChecker
{
    public static string Canonical(IDictionary<string, string> files) =>
        string.Join("\n", files.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase).Select(k => $"{k.Key.ToLowerInvariant()}={k.Value}"));

    public static string HashFile(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

    public static string CreateManifest(string folder, string privateKeyXml)
    {
        var files = new Dictionary<string, string>();
        foreach (var f in Directory.GetFiles(folder).Where(x =>
                     (x.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) || x.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                     && Path.GetFileName(x).StartsWith("StructCalc", StringComparison.OrdinalIgnoreCase)))
            files[Path.GetFileName(f)] = HashFile(f);
        using var rsa = RSA.Create();
        rsa.FromXmlString(privateKeyXml);
        byte[] sig = rsa.SignData(Encoding.UTF8.GetBytes(Canonical(files)), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        return JsonSerializer.Serialize(new { files, signature = Convert.ToBase64String(sig) }, new JsonSerializerOptions { WriteIndented = true });
    }

    public static bool Verify(string publicKeyXml, out string message)
    {
        message = "";
        try
        {
            string dir = AppContext.BaseDirectory;
            string manifest = Path.Combine(dir, "integrity.sig");
            if (!File.Exists(manifest)) { message = "build non signé"; return true; }
            using var doc = JsonDocument.Parse(File.ReadAllText(manifest));
            var files = new Dictionary<string, string>();
            foreach (var p in doc.RootElement.GetProperty("files").EnumerateObject()) files[p.Name] = p.Value.GetString() ?? "";
            byte[] sig = Convert.FromBase64String(doc.RootElement.GetProperty("signature").GetString()!);
            using var rsa = RSA.Create();
            rsa.FromXmlString(publicKeyXml);
            if (!rsa.VerifyData(Encoding.UTF8.GetBytes(Canonical(files)), sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1))
            { message = "manifeste d'intégrité invalide"; return false; }
            foreach (var kv in files)
            {
                string path = Path.Combine(dir, kv.Key);
                if (!File.Exists(path)) { message = "fichier manquant : " + kv.Key; return false; }
                if (!HashFile(path).Equals(kv.Value, StringComparison.OrdinalIgnoreCase)) { message = "fichier modifié : " + kv.Key; return false; }
            }
            return true;
        }
        catch (Exception ex) { message = ex.Message; return false; }
    }
}
