using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace StructCalc.Core.Licensing;

public sealed class LicenseInfo
{
    public string Licensee { get; set; } = "";
    public string Email { get; set; } = "";
    public string MachineId { get; set; } = "";          // "*" = tous les postes (déconseillé)
    public string Edition { get; set; } = "PRO";
    public DateTime IssuedUtc { get; set; }
    public DateTime? ExpiresUtc { get; set; }            // null = perpétuelle
    public int MaxMembers { get; set; }                  // 0 = illimité

    /// <summary>Licence du créateur du logiciel (édition « CREATEUR »).</summary>
    [JsonIgnore] public bool IsCreator => string.Equals(Edition, "CREATEUR", StringComparison.OrdinalIgnoreCase);
}

public enum LicenseState { Licensed, Trial, TrialExpired, Invalid, Tampered }

public sealed class LicenseStatus
{
    public LicenseState State { get; set; }
    public string Message { get; set; } = "";
    public LicenseInfo? Info { get; set; }
    public int DaysLeft { get; set; }
    public bool IsFull => State == LicenseState.Licensed;
    public bool IsCreator => State == LicenseState.Licensed && Info != null && Info.IsCreator;
    public bool CanRun => State == LicenseState.Licensed || State == LicenseState.Trial;
    /// <summary>Nombre maximal de barres (0 = illimité).</summary>
    public int MemberLimit => State == LicenseState.Licensed ? (Info?.MaxMembers ?? 0) : LicenseManager.TrialMaxMembers;
}

/// <summary>Licences signées (RSA 2048 / SHA-256) liées au poste, période d'essai protégée (HMAC + double stockage + détection de recul d'horloge).
/// Limite : aucune protection logicielle n'est inviolable ; ce mécanisme décourage la copie et le partage, il ne remplace pas
/// l'obfuscation du code, la signature de code et, idéalement, une activation en ligne.</summary>
public static class LicenseManager
{
    public const int TrialDays = 30;
    public const int TrialMaxMembers = 40;
    private const string Secret = "SC|7f3a9c1e|EKRESSIN|2026";

    private static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc");
    public static string LicensePath => Path.Combine(Dir, "license.lic");
    private static string TrialFile => Path.Combine(Dir, "sys.dat");
    private static string LastFile => Path.Combine(Dir, "sys2.dat");
    private const string RegPath = @"Software\StructCalc\Sys";

    private static LicenseStatus? _cached;
    public static LicenseStatus Current => _cached ??= Check();
    public static void Refresh() => _cached = null;

    // ---------------------------------------------------------------- identité du poste
    public static string MachineId()
    {
        string raw = "";
        try
        {
            using var k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography");
            raw = k?.GetValue("MachineGuid") as string ?? "";
        }
        catch { }
        if (raw.Length == 0) raw = Environment.MachineName + "|" + Environment.UserName;
        string hex = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("StructCalc|" + raw)))[..16];
        return $"{hex[..4]}-{hex.Substring(4, 4)}-{hex.Substring(8, 4)}-{hex.Substring(12, 4)}";
    }

    // ---------------------------------------------------------------- signature / vérification
    public static string CreateLicenseText(LicenseInfo info, string privateKeyXml)
    {
        byte[] payload = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(info));
        using var rsa = RSA.Create();
        rsa.FromXmlString(privateKeyXml);
        byte[] sig = rsa.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        return JsonSerializer.Serialize(new { payload = Convert.ToBase64String(payload), signature = Convert.ToBase64String(sig) },
                                        new JsonSerializerOptions { WriteIndented = true });
    }

    public static bool VerifyLicenseText(string text, string publicKeyXml, out LicenseInfo? info, out string error)
    {
        info = null; error = "";
        try
        {
            using var doc = JsonDocument.Parse(text);
            byte[] payload = Convert.FromBase64String(doc.RootElement.GetProperty("payload").GetString()!);
            byte[] sig = Convert.FromBase64String(doc.RootElement.GetProperty("signature").GetString()!);
            using var rsa = RSA.Create();
            rsa.FromXmlString(publicKeyXml);
            if (!rsa.VerifyData(payload, sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) { error = "signature invalide"; return false; }
            info = JsonSerializer.Deserialize<LicenseInfo>(Encoding.UTF8.GetString(payload));
            return info != null;
        }
        catch (Exception ex) { error = ex.Message; return false; }
    }

    /// <summary>Installe un fichier de licence après vérification (copie dans %AppData%\StructCalc).</summary>
    public static bool Install(string licFile, out string message)
    {
        message = "";
        try
        {
            if (string.IsNullOrWhiteSpace(LicensePublicKey.Xml)) { message = "Clé publique non configurée dans cette version : impossible de valider une licence."; return false; }
            string text = File.ReadAllText(licFile);
            if (!VerifyLicenseText(text, LicensePublicKey.Xml, out var info, out var err)) { message = "Licence invalide : " + err; return false; }
            if (info!.MachineId != "*" && !string.Equals(info.MachineId, MachineId(), StringComparison.OrdinalIgnoreCase))
            { message = "Cette licence a été émise pour un autre poste."; return false; }
            if (info.ExpiresUtc.HasValue && info.ExpiresUtc.Value < DateTime.UtcNow) { message = "Licence expirée."; return false; }
            Directory.CreateDirectory(Dir);
            File.WriteAllText(LicensePath, text);
            Refresh();
            message = $"Licence activée pour {info.Licensee}.";
            return true;
        }
        catch (Exception ex) { message = ex.Message; return false; }
    }

    // ---------------------------------------------------------------- état courant
    public static LicenseStatus Check()
    {
        string mid = MachineId();
        bool keyConfigured = !string.IsNullOrWhiteSpace(LicensePublicKey.Xml);
        if (keyConfigured && File.Exists(LicensePath))
        {
            if (!VerifyLicenseText(File.ReadAllText(LicensePath), LicensePublicKey.Xml, out var info, out var err))
                return new LicenseStatus { State = LicenseState.Invalid, Message = "Fichier de licence invalide ou modifié : " + err };
            if (info!.MachineId != "*" && !string.Equals(info.MachineId, mid, StringComparison.OrdinalIgnoreCase))
                return new LicenseStatus { State = LicenseState.Invalid, Message = "Licence émise pour un autre poste." };
            if (info.ExpiresUtc.HasValue && info.ExpiresUtc.Value < DateTime.UtcNow)
                return new LicenseStatus { State = LicenseState.Invalid, Message = $"Licence expirée le {info.ExpiresUtc:dd/MM/yyyy}.", Info = info };
            if (!IntegrityChecker.Verify(LicensePublicKey.Xml, out string im))
                return new LicenseStatus { State = LicenseState.Tampered, Message = "Intégrité du logiciel compromise : " + im };
            string until = info.ExpiresUtc.HasValue ? $" (valable jusqu'au {info.ExpiresUtc.Value.ToLocalTime():dd/MM/yyyy})" : " (perpétuelle)";
            string msg = info.IsCreator ? $"Licence CRÉATEUR - {info.Licensee} : accès complet, sans limite{until}" : $"Licence {info.Edition} - {info.Licensee}{until}";
            return new LicenseStatus { State = LicenseState.Licensed, Info = info, Message = msg };
        }
        var trial = CheckTrial(mid);
        if (!keyConfigured && trial.State == LicenseState.Trial) trial.Message += " (clé publique non configurée : mode développeur)";
        return trial;
    }

    // ---------------------------------------------------------------- période d'essai
    private static string Protect(long ticks, string mid)
    {
        string data = ticks.ToString();
        using var h = new HMACSHA256(Encoding.UTF8.GetBytes(Secret + "|" + mid));
        return data + ":" + Convert.ToHexString(h.ComputeHash(Encoding.UTF8.GetBytes(data)));
    }

    private static bool TryRead(string? s, string mid, out long ticks)
    {
        ticks = 0;
        if (string.IsNullOrEmpty(s)) return false;
        var parts = s.Trim().Split(':');
        if (parts.Length != 2 || !long.TryParse(parts[0], out ticks)) return false;
        return Protect(ticks, mid).Equals(s.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static string? ReadReg(string name)
    {
        try { using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RegPath); return k?.GetValue(name) as string; }
        catch { return null; }
    }
    private static void WriteReg(string name, string value)
    {
        try { using var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(RegPath); k?.SetValue(name, value); }
        catch { }
    }
    private static string? ReadFile(string path) { try { return File.Exists(path) ? File.ReadAllText(path) : null; } catch { return null; } }
    private static void WriteFile(string path, string value) { try { Directory.CreateDirectory(Dir); File.WriteAllText(path, value); } catch { } }

    private static LicenseStatus CheckTrial(string mid)
    {
        long now = DateTime.UtcNow.Ticks;
        string? f = ReadFile(TrialFile), r = ReadReg("t");
        bool fOk = TryRead(f, mid, out long tf), rOk = TryRead(r, mid, out long tr);
        if ((f != null && !fOk) || (r != null && !rOk))
            return new LicenseStatus { State = LicenseState.Tampered, Message = "Données de la période d'évaluation altérées." };
        long start;
        if (!fOk && !rOk) start = now;
        else if (fOk && rOk) start = Math.Min(tf, tr);
        else start = fOk ? tf : tr;
        string prot = Protect(start, mid);
        if (!fOk) WriteFile(TrialFile, prot);
        if (!rOk) WriteReg("t", prot);

        string? l1 = ReadFile(LastFile), l2 = ReadReg("l");
        long last = 0;
        bool l1Ok = TryRead(l1, mid, out long a), l2Ok = TryRead(l2, mid, out long b);
        if ((l1 != null && !l1Ok) || (l2 != null && !l2Ok))
            return new LicenseStatus { State = LicenseState.Tampered, Message = "Données de la période d'évaluation altérées." };
        if (l1Ok) last = Math.Max(last, a);
        if (l2Ok) last = Math.Max(last, b);
        if (last > 0 && now < last - TimeSpan.TicksPerDay)
            return new LicenseStatus { State = LicenseState.Tampered, Message = "Horloge système anormale (retour en arrière détecté)." };
        string lp = Protect(Math.Max(now, last), mid);
        WriteFile(LastFile, lp); WriteReg("l", lp);

        int used = (int)((now - start) / TimeSpan.TicksPerDay);
        int left = TrialDays - used;
        if (left <= 0) return new LicenseStatus { State = LicenseState.TrialExpired, Message = "La période d'évaluation de 30 jours est terminée.", DaysLeft = 0 };
        return new LicenseStatus { State = LicenseState.Trial, DaysLeft = left, Message = $"Version d'évaluation : {left} jour(s) restant(s), {TrialMaxMembers} barres maximum, plans filigranés." };
    }

    /// <summary>À appeler avant un calcul : lève une exception si la licence ne permet pas de continuer ou si le modèle dépasse la limite.</summary>
    public static void Require(int memberCount)
    {
#if DEBUG
        return;      // compilation Debug : contrôle désactivé (ne JAMAIS distribuer une version Debug)
#endif
#pragma warning disable CS0162
        var st = Current;
        if (!st.CanRun) throw new InvalidOperationException("Licence requise : " + st.Message);
        int lim = st.MemberLimit;
        if (lim > 0 && memberCount > lim)
            throw new InvalidOperationException($"Version d'évaluation limitée à {lim} barres ({memberCount} dans le modèle). Activez une licence : {AppInfo.ContactLine}");
#pragma warning restore CS0162
    }
}
