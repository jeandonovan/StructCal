namespace StructCalc.Core;

public enum MaterialKind { ReinforcedConcrete, Steel }
public enum LimitState { ELU, ELS, Accidental }
public enum CrackingClass { PeuPrejudiciable, Prejudiciable, TresPrejudiciable }
public enum ActionType { G, Q, W, S, E }
public enum SlabContinuity { Simple, Rive, Interieure }

/// <summary>Combinaison d'actions : facteurs par type d'action (peuvent être négatifs, ex. vent inversé).</summary>
public record Combination(string Name, LimitState State, IReadOnlyDictionary<ActionType, double> Factors);

/// <summary>Résultat générique de dimensionnement/vérification.</summary>
public class DesignResult
{
    public string Element { get; set; } = "";
    public bool Ok { get; set; } = true;
    public Dictionary<string, double> Values { get; } = new();
    public Dictionary<string, string> Texts { get; } = new();
    public List<string> Notes { get; } = new();
    public List<string> Warnings { get; } = new();
    public void Fail(string msg) { Ok = false; Warnings.Add(msg); }
}

/// <summary>Section rectangulaire BA (m). Cover = distance du bord à l'axe des armatures.</summary>
public record RcRectSection(double B, double H, double Cover = 0.05, double Dprime = 0.05)
{
    public double D => H - Cover;
}

/// <summary>Poteau rectangulaire. Bw // axe local y, Hd // axe local z. My : moment autour de y (profondeur Hd), Mz : autour de z (profondeur Bw).
/// Nu en kN (compression positive), moments en kN.m, Cover = distance bord-axe des aciers.</summary>
public record ColumnInput(double Bw, double Hd, double Lf, double Fc28, double Fe, double NuKN, double MyKNm, double MzKNm, double Cover = 0.04, LimitState State = LimitState.ELU);

public record SlabInput(double Lx, double Ly, double H, double GExtra, double Q, SlabContinuity Continuity,
                        double Fc28, double Fe, CrackingClass Crack = CrackingClass.PeuPrejudiciable, double Cover = 0.03,
                        DesignSettings? Settings = null);

/// <summary>Semelle isolée sous poteau centré. SigmaSolKPa = contrainte admissible du sol à l'ELS.</summary>
public record FootingInput(double ColA, double ColB, double NuKN, double NserKN, double SigmaSolKPa,
                           double Fc28, double Fe, double Cover = 0.05);

/// <summary>Vérification d'une barre acier. Unités : m, MPa, kN, kN.m. N compression positive.</summary>
public record SteelInput(Steel.SteelProfile P, double Fy, double L, double Lfy, double Lfz, double Lt,
                         double NKN, double MyKNm, double MzKNm, double VyKN, double VzKN,
                         double PsiY, bool Loaded, LimitState State = LimitState.ELU);
