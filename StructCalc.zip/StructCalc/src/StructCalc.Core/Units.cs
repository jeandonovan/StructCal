using System.Globalization;

namespace StructCalc.Core;

/// <summary>Unités d'affichage du projet. Le calcul reste en interne en m, kN, kN.m, MPa et cm² ; seuls l'affichage (tableaux, résultats, plans)
/// et la saisie dans les tableaux passent par ces conversions. Enregistré dans les paramètres du projet.</summary>
public static class Units
{
    public static string Length { get; private set; } = "m";        // m | cm | mm  : portées, coordonnées, longueurs de barres
    public static string Section { get; private set; } = "cm";      // cm | mm | m   : dimensions de section, espacements, enrobages
    public static string Force { get; private set; } = "kN";        // kN | daN | N | tf
    public static string Stress { get; private set; } = "MPa";      // MPa | kPa | bar | kgf/cm²

    public static readonly string[] Lengths = { "m", "cm", "mm" };
    public static readonly string[] Sections = { "cm", "mm", "m" };
    public static readonly string[] Forces = { "kN", "daN", "N", "tf" };
    public static readonly string[] Stresses = { "MPa", "kPa", "bar", "kgf/cm²" };

    public static void Apply(DesignSettings? s)
    {
        Set(s?.UnitLength ?? "m", s?.UnitSection ?? "cm", s?.UnitForce ?? "kN", s?.UnitStress ?? "MPa");
    }

    public static void Set(string length, string section, string force, string stress)
    {
        Length = Lengths.Contains(length) ? length : "m";
        Section = Sections.Contains(section) ? section : "cm";
        Force = Forces.Contains(force) ? force : "kN";
        Stress = Stresses.Contains(stress) ? stress : "MPa";
    }

    public static void Store(DesignSettings s)
    {
        s.UnitLength = Length; s.UnitSection = Section; s.UnitForce = Force; s.UnitStress = Stress;
    }

    // ------------------------------------------------------------------ facteurs (valeur affichée = valeur interne x facteur)
    private static double LenF(string u) => u switch { "cm" => 100, "mm" => 1000, _ => 1 };
    public static double LengthFactor => LenF(Length);
    public static double SectionFactor => LenF(Section);
    public static double ForceFactor => Force switch { "daN" => 100, "N" => 1000, "tf" => 1 / 9.80665, _ => 1 };
    public static double StressFactor => Stress switch { "kPa" => 1000, "bar" => 10, "kgf/cm²" => 10.19716, _ => 1 };

    // ------------------------------------------------------------------ étiquettes
    public static string MomentUnit => Force + "." + Length;
    public static string LinearLoadUnit => Force + "/" + Length;
    public static string AreaLoadUnit => Force + "/" + Length + "²";
    public static string SteelAreaUnit => Length == "mm" || Section == "mm" ? "mm²" : "cm²";
    public static double SteelAreaFactor => SteelAreaUnit == "mm²" ? 100 : 1;          // valeur interne en cm²
    public static string AsU => SteelAreaUnit;

    // ------------------------------------------------------------------ conversions numériques (interne -> affichage)
    public static double Len(double m) => m * LengthFactor;
    public static double Sec(double m) => m * SectionFactor;
    public static double Frc(double kN) => kN * ForceFactor;
    public static double Mom(double kNm) => kNm * ForceFactor * LengthFactor;
    public static double Lin(double kNperM) => kNperM * ForceFactor / LengthFactor;
    public static double Surf(double kNperM2) => kNperM2 * ForceFactor / (LengthFactor * LengthFactor);
    public static double Str(double mpa) => mpa * StressFactor;
    public static double AsA(double cm2) => cm2 * SteelAreaFactor;

    /// <summary>Facteur de conversion selon le type de grandeur (utilisé par les tableaux de saisie).</summary>
    public static double FactorOf(string kind) => kind switch
    {
        "len" => LengthFactor,
        "sec" => SectionFactor,
        "force" => ForceFactor,
        "moment" => ForceFactor * LengthFactor,
        "lin" => ForceFactor / LengthFactor,
        "surf" => ForceFactor / (LengthFactor * LengthFactor),
        "stress" => StressFactor,
        _ => 1,
    };

    public static string LabelOf(string kind) => kind switch
    {
        "len" => Length,
        "sec" => Section,
        "force" => Force,
        "moment" => MomentUnit,
        "lin" => LinearLoadUnit,
        "surf" => AreaLoadUnit,
        "stress" => Stress,
        _ => "",
    };

    // ------------------------------------------------------------------ textes
    private static string F(double v, string fmt) => v.ToString(fmt, CultureInfo.InvariantCulture);
    private static string Dec(string unit) => unit == "m" ? "0.00" : unit == "cm" ? "0.#" : "0";

    /// <summary>Longueur en unité de longueur, sans unité (ex. « 4.50 », « 450 »).</summary>
    public static string LenS(double m) => F(Len(m), Length == "m" ? "0.00" : Length == "cm" ? "0" : "0");
    /// <summary>Dimension de section en unité de section (ex. « 30 », « 300 », « 0.30 »).</summary>
    public static string SecS(double m) => F(Sec(m), Dec(Section));
    /// <summary>Espacement donné en cm, converti dans l'unité de section.</summary>
    public static string SpS(double cm) => F(Sec(cm / 100.0), Dec(Section));
    /// <summary>Section d'acier donnée en cm².</summary>
    public static string AsS(double cm2) => F(AsA(cm2), SteelAreaUnit == "mm²" ? "0" : "0.00");
    public static string FrcS(double kN, string fmt = "0.0") => F(Frc(kN), fmt);
    public static string MomS(double kNm, string fmt = "0.0") => F(Mom(kNm), fmt);

    /// <summary>Texte descriptif du jeu d'unités courant.</summary>
    public static string Describe() => $"longueurs en {Length}, sections en {Section}, forces en {Force}, contraintes en {Stress}";

    /// <summary>Jeux prédéfinis.</summary>
    public static readonly (string Name, string L, string S, string F, string C)[] Presets =
    {
        ("Pratique béton armé : m, cm, kN, MPa", "m", "cm", "kN", "MPa"),
        ("Système international : m, mm, kN, MPa", "m", "mm", "kN", "MPa"),
        ("Charpente : mm, mm, kN, MPa", "mm", "mm", "kN", "MPa"),
        ("Ancien système : m, cm, tf, kgf/cm²", "m", "cm", "tf", "kgf/cm²"),
        ("Centimètres : cm, cm, daN, bar", "cm", "cm", "daN", "bar"),
    };
}
