namespace StructCalc.Core;

/// <summary>Contrat commun à toutes les normes.</summary>
public interface IDesignCode
{
    string Id { get; }
    string DisplayName { get; }
    MaterialKind Material { get; }
    bool IsImplemented { get; }
    IReadOnlyList<Combination> Combinations { get; }
}

/// <summary>Normes béton armé (BAEL91, CBA93, EC2, RPA99, EC8...).</summary>
public interface IReinforcedConcreteCode : IDesignCode
{
    DesignResult DesignBeamFlexure(RcRectSection s, double fc28, double fe, double muKNm, double mserKNm, CrackingClass crack, LimitState state = LimitState.ELU);
    DesignResult DesignBeamShear(RcRectSection s, double fc28, double fe, double vuKN, CrackingClass crack, LimitState state = LimitState.ELU);
    DesignResult CheckBeamDeflection(RcRectSection s, double span, double fc28, double fe, double asCm2, double mtKNm, double m0KNm);
    DesignResult DesignColumn(ColumnInput input);
    DesignResult DesignSlab(SlabInput input);
    DesignResult DesignIsolatedFooting(FootingInput input);
    /// <summary>Section minimale totale (inf + sup) d'une poutre, cm² (dispositions parasismiques). 0 = pas d'exigence.</summary>
    double BeamMinTotalAsCm2(RcRectSection s);
    /// <summary>Espacement maximal des cadres en zone nodale/critique (cm). 0 = pas d'exigence.</summary>
    double NodalStirrupSpacingCm(bool isColumn, double hCm, double minBarMm);
}

/// <summary>Normes charpente métallique (CM66, EC3...).</summary>
public interface ISteelCode : IDesignCode
{
    DesignResult CheckMember(SteelInput input);
}

public static class DesignCodeRegistry
{
    private static readonly List<IDesignCode> _codes = new();
    static DesignCodeRegistry()
    {
        Register(new Codes.BAEL91.Bael91Code());
        Register(new Codes.CBA93.Cba93Code());
        Register(new Codes.EC2.Ec2Code());
        Register(new Codes.RPA99.Rpa99Code());
        Register(new Codes.EC8.Ec8Code());
        Register(new Codes.EC3.Ec3Code());
        Register(new Codes.EC3.Ec3EnvCode());
        Register(new Codes.CM66.Cm66Code());
        foreach (var p in Codes.Planned.PlannedCodes.All()) Register(p);
        RegisterDiscovered();
    }

    /// <summary>Normes ajoutées par simple dépôt d'une classe marquée [AutoRegisterCode] dans l'assemblage : aucune modification du registre n'est nécessaire.</summary>
    private static void RegisterDiscovered()
    {
        foreach (var t in typeof(DesignCodeRegistry).Assembly.GetTypes())
        {
            if (t.IsAbstract || !typeof(IDesignCode).IsAssignableFrom(t) || t.GetCustomAttributes(typeof(Codes.AutoRegisterCodeAttribute), false).Length == 0) continue;
            if (t.GetConstructor(Type.EmptyTypes) == null) continue;
            if (Activator.CreateInstance(t) is IDesignCode c) Register(c);
        }
    }
    public static void Register(IDesignCode c)
    {
        _codes.RemoveAll(x => x.Id.Equals(c.Id, StringComparison.OrdinalIgnoreCase));
        _codes.Add(c);
    }
    public static IReadOnlyList<IDesignCode> All => _codes;
    public static IEnumerable<IDesignCode> Available(MaterialKind k) => _codes.Where(c => c.Material == k);
    public static IDesignCode Get(string id) =>
        _codes.First(c => c.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
}
