using System.Globalization;

namespace StructCalc.Core;

/// <summary>Paramètres de configuration du projet : enrobages, choix des armatures, dispositions constructives et parasismiques, mise en page des plans.
/// Enregistrés dans le fichier projet. Une valeur 0 pour un pourcentage ou un espacement signifie « appliquer la norme choisie ».</summary>
public class DesignSettings
{
    public string Preset { get; set; } = "Personnalisé";

    // ---- unités d'affichage du projet (le calcul reste en m, kN, MPa)
    public string UnitLength { get; set; } = "m";
    public string UnitSection { get; set; } = "cm";
    public string UnitForce { get; set; } = "kN";
    public string UnitStress { get; set; } = "MPa";

    // ---- enrobages (cm, du bord à l'axe des armatures)
    public double CoverBeamCm { get; set; } = 5.0;
    public double CoverColumnCm { get; set; } = 4.0;
    public double CoverSlabCm { get; set; } = 3.0;
    public double CoverFootingCm { get; set; } = 5.0;

    // ---- enrobages NOMINAUX (cm, du bord à la face extérieure du cadre) : saisie de l'utilisateur ; les enrobages à l'axe ci-dessus en sont déduits
    public double CoverNomBeamCm { get; set; } = 2.5;
    public double CoverNomColumnCm { get; set; } = 2.5;
    public double CoverNomSlabCm { get; set; } = 2.5;
    public double CoverNomFootingCm { get; set; } = 5.0;

    /// <summary>Déduit les enrobages à l'axe (estimation de départ) des enrobages nominaux : + cadre HA8 + demi-barre HA16 (poutres, poteaux),
    /// demi-barre HA10 (dalles), demi-barre HA12 (semelles). Pour poutres et poteaux, la valeur exacte est recalculée après le choix des barres.</summary>
    public void SyncAxisCovers()
    {
        CoverBeamCm = Math.Round(CoverNomBeamCm + 0.8 + 0.8, 2);
        CoverColumnCm = Math.Round(CoverNomColumnCm + 0.8 + 0.8, 2);
        CoverSlabCm = Math.Round(CoverNomSlabCm + 0.5, 2);
        CoverFootingCm = Math.Round(CoverNomFootingCm + 0.6, 2);
    }

    // ---- armatures disponibles et règles de choix
    public int[] BeamDiameters { get; set; } = { 10, 12, 14, 16, 20, 25, 32 };
    public int[] ColumnDiameters { get; set; } = { 12, 14, 16, 20, 25, 32 };
    public int[] StirrupDiameters { get; set; } = { 6, 8, 10, 12 };
    public int[] SlabDiameters { get; set; } = { 8, 10, 12, 14, 16 };
    public int MountingBarDiaMm { get; set; } = 10;            // barres de montage des poutres
    public double MinClearSpacingMm { get; set; } = 25;        // espacement libre minimal entre barres
    public int MaxBarsPerLayer { get; set; } = 6;              // poutres : nombre maximal de barres par lit
    public int MaxColumnBars { get; set; } = 12;               // poteaux : nombre maximal de barres longitudinales
    public double StirrupDiaRatio { get; set; } = 3.0;         // diamètre des cadres >= diamètre longitudinal / ratio
    public double SpacingStepCm { get; set; } = 1.0;           // arrondi des espacements des cadres (cm)
    public double MinStirrupSpacingCm { get; set; } = 5.0;
    public double MaxStirrupSpacingColumnCm { get; set; } = 40.0;
    public double SlabMaxMainSpacingCm { get; set; } = 33.0;
    public double SlabMaxDistribSpacingCm { get; set; } = 45.0;
    public double SlabMinSpacingCm { get; set; } = 10.0;       // en dessous, on passe au diamètre supérieur

    // ---- dispositions constructives et parasismiques (0 = selon la norme)
    public double BeamCriticalZoneFactor { get; set; } = 2.0;      // longueur de zone critique des poutres = facteur x h
    public double ColumnCriticalZoneMinCm { get; set; } = 60.0;    // zone nodale des poteaux = max(h, L/6, cette valeur)
    public double BeamNodalSpacingCm { get; set; } = 0;
    public double ColumnNodalSpacingCm { get; set; } = 0;
    public double ColumnMinPercent { get; set; } = 0;              // % de la section de béton
    public double ColumnMaxPercent { get; set; } = 0;
    public double BeamMinPercent { get; set; } = 0;
    public double BeamMaxPercent { get; set; } = 0;
    // ---- maillage éléments finis (dalles : plaque ; voiles : coques) : préréglage de MeshPresets, ou saisie manuelle
    public string MeshPreset { get; set; } = "Courant";
    public double MeshManualM { get; set; } = 0.25;               // taille de maille en mode Manuel (m)
    public int MeshManualNx { get; set; }                         // dalles, mode Manuel : nombre de mailles en X (0 = déduit de la taille)
    public int MeshManualNy { get; set; }
    /// <summary>Type d'éléments : Quad = quadrangles (dalles : différences finies ; voiles : coques MITC4/QM6) ; Tri = maillage triangulé (dalles : DKT ; voiles : CST + DKT).</summary>
    public string MeshElement { get; set; } = "Quad";

    // ---- méthode de calcul des dalles pleines : Coefficients | Forfaitaire | Caquot | CaquotMinoree | LignesRupture | Bandes | DDM | ElementsFinis
    public string SlabMethod { get; set; } = "Coefficients";
    public double SlabYieldSupportRatio { get; set; } = 1.0;       // lignes de rupture : moment sur appui encastré / moment en travée
    public double SlabSupportWidthM { get; set; } = 0.30;          // direct design : largeur d'appui (poutre ou poteau) retranchée de la portée libre
    public bool SlabCompareMethods { get; set; } = true;           // note « comparaison des méthodes » pour chaque dalle

    // ---- vérification de flèche : Auto | Forfaitaire | ForfPuisCalc | CalcBael | CalcEc2 | CalcMax | Aucune
    public string DeflectionMethod { get; set; } = "Auto";
    // limite : Norme | EC2 (L/250) | L500 | Manuel (L / DeflectionManualDenominator)
    public string DeflectionLimitMode { get; set; } = "Norme";
    public double DeflectionManualDenominator { get; set; } = 250;
    public double DeflectionPermanentShare { get; set; } = 0.70;   // part des charges de service qui est permanente (fluage)
    public double CreepPhi { get; set; } = 2.0;                    // coefficient de fluage φ (EC2 7.4.3)

    public double LapFactor { get; set; } = 40;                    // recouvrement = facteur x diamètre
    public double AnchorageFactor { get; set; } = 40;              // ancrage droit = facteur x diamètre
    public double HookFactor { get; set; } = 10;                   // retour de crochet des cadres = facteur x diamètre
    public double BeamTopBarFactor { get; set; } = 0.25;           // chapeaux de poutre = facteur x portée
    public double SlabTopBarFactor { get; set; } = 0.25;           // chapeaux de dalle = facteur x petite portée

    // ---- plans
    public string Company { get; set; } = "";
    public string Engineer { get; set; } = "";
    public string Client { get; set; } = "";
    public string SiteName { get; set; } = "";
    public string Revision { get; set; } = "A";
    public bool ShowBarMarks { get; set; } = true;
    public bool ShowCutMarks { get; set; } = true;
    public bool ShowBarSchedule { get; set; } = true;
    public bool GroupIdenticalElements { get; set; } = true;

    // ---------------------------------------------------------------- accès sécurisés (listes jamais vides)
    private static int[] Clean(int[]? v, int[] def)
    {
        var r = (v ?? Array.Empty<int>()).Where(x => x >= 6 && x <= 40).Distinct().OrderBy(x => x).ToArray();
        return r.Length == 0 ? def : r;
    }
    public int[] BeamDias() => Clean(BeamDiameters, new[] { 10, 12, 14, 16, 20, 25, 32 });
    public int[] ColumnDias() => Clean(ColumnDiameters, new[] { 12, 14, 16, 20, 25, 32 });
    public int[] StirrupDias() => Clean(StirrupDiameters, new[] { 6, 8, 10, 12 });
    public int[] SlabDias() => Clean(SlabDiameters, new[] { 8, 10, 12, 14, 16 });

    public static string IntsToText(int[] v) => string.Join(", ", v);
    public static int[] TextToInts(string t)
    {
        var res = new List<int>();
        foreach (var p in t.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            if (int.TryParse(p.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int v)) res.Add(v);
        return res.ToArray();
    }

    /// <summary>Masse linéique d'un rond HA (kg/m).</summary>
    public static double KgPerM(int dia) => 0.00617 * dia * dia;
}
