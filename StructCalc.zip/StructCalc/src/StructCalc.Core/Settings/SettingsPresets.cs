using StructCalc.Core.Model;

namespace StructCalc.Core;

/// <summary>Préréglages de configuration (norme + dispositions usuelles). Ce sont des points de départ : chaque valeur reste modifiable dans l'assistant.</summary>
public static class SettingsPresets
{
    public const string PBael = "BAEL 91 - non sismique (Côte d'Ivoire / UEMOA)";
    public const string PRpa = "RPA 99 v2003 + CBA 93 (Algérie, zone sismique)";
    public const string PEc = "Eurocodes EC2 + EC8 (ductilité moyenne DCM)";
    public const string PSteel = "Charpente métallique CM66 / Eurocode 3";

    public static readonly string[] Names = { PBael, PRpa, PEc, PSteel };

    /// <summary>Applique un préréglage au projet : codes de calcul, séisme, dispositions constructives. Ne touche pas aux sections ni aux charges.</summary>
    public static void Apply(string name, StructModel m)
    {
        var s = m.Settings;
        s.Preset = name;
        s.LapFactor = 40; s.AnchorageFactor = 40; s.HookFactor = 10;
        s.BeamCriticalZoneFactor = 2.0; s.ColumnCriticalZoneMinCm = 60;
        s.BeamNodalSpacingCm = 0; s.ColumnNodalSpacingCm = 0;
        s.ColumnMinPercent = 0; s.ColumnMaxPercent = 0; s.BeamMinPercent = 0; s.BeamMaxPercent = 0;
        switch (name)
        {
            case PBael:
                m.RcCodeId = "BAEL91";
                m.Seismic.Enabled = false;
                s.LapFactor = m.Fe >= 500 ? 50 : 40;
                s.AnchorageFactor = s.LapFactor;
                break;
            case PRpa:
                m.RcCodeId = "RPA99";
                m.Seismic.Enabled = true; m.Seismic.Norm = "RPA99";
                s.LapFactor = (m.Seismic.Zone == "IIb" || m.Seismic.Zone == "III") ? 50 : 40;   // RPA 99 : Lr = 40 phi (zones I, IIa) ou 50 phi (IIb, III)
                s.AnchorageFactor = s.LapFactor;
                s.ColumnMaxPercent = 4.0;       // zone courante
                s.BeamMaxPercent = 4.0;
                break;
            case PEc:
                m.RcCodeId = "EC8";
                m.Seismic.Enabled = true; m.Seismic.Norm = "EC8";
                s.LapFactor = 45; s.AnchorageFactor = 45;
                s.BeamCriticalZoneFactor = 1.5;
                s.ColumnMaxPercent = 4.0; s.BeamMaxPercent = 4.0;
                break;
            case PSteel:
                m.SteelCodeId = "CM66";
                break;
        }
    }
}
