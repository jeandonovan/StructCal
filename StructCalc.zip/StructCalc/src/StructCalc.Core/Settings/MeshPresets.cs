using StructCalc.Core.Model;

namespace StructCalc.Core;

/// <summary>Type de maillage éléments finis : taille cible des mailles et type de calcul auquel il convient.</summary>
public sealed record MeshPreset(string Id, string Label, double TargetM, int MaxCells, string Calc);

/// <summary>Choix du maillage des dalles (plaque, différences finies) et des voiles (coques MITC4/QM6) : préréglages ou saisie manuelle.
/// Réglage global dans l'assistant de configuration ; chaque voile peut y déroger.</summary>
public static class MeshPresets
{
    public const string Manual = "Manuel", Auto = "Auto", GlobalId = "Global";

    public static readonly MeshPreset[] All =
    {
        new("Grossier", "Grossier (0,50 m) - avant-projet", 0.50, 16, "Avant-projet : ordres de grandeur de la flèche et des moments, calcul très rapide ; résultats lissés, peu fiables près des appuis et des ouvertures."),
        new("Courant", "Courant (0,25 m) - dimensionnement", 0.25, 28, "Dimensionnement courant (réglage par défaut) : flèche et moments de travée fiables ; pics d'encastrement lissés."),
        new("Fin", "Fin (0,15 m) - dimensionnement précis", 0.15, 40, "Dimensionnement précis : bon suivi des moments d'encastrement, de la flèche et des angles d'ouvertures ; calcul plus long."),
        new("TresFin", "Très fin (0,10 m) - vérification", 0.10, 40, "Vérification fine / étude de concentrations de contraintes ; calcul long (dalles plafonnées à 40 mailles par côté)."),
        new(Auto, "Automatique (selon la portée)", 0.0, 40, "Environ 12 mailles sur la plus petite dimension (taille entre 0,12 et 0,40 m) : maillage adapté à chaque dalle ou voile."),
        new(Manual, "Manuel (saisie)", 0.0, 40, "Taille de maille, ou nombre de mailles en X et en Y (dalles), saisis à la main ; calcul identique, précision choisie par vous.")
    };

    public static MeshPreset Get(string? id) => All.FirstOrDefault(p => p.Id == id) ?? All[1];

    /// <summary>Nombre de mailles (X, Y) d'un panneau de dalle.</summary>
    public static (int Nx, int Ny) SlabCounts(DesignSettings? s, double lx, double ly)
    {
        s ??= new DesignSettings();
        var p = Get(s.MeshPreset);
        if (p.Id == Manual)
        {
            if (s.MeshManualNx >= 2 && s.MeshManualNy >= 2) return (Math.Clamp(s.MeshManualNx, 3, 40), Math.Clamp(s.MeshManualNy, 3, 40));
            double t = Math.Max(s.MeshManualM, 0.05);
            return (Math.Clamp((int)Math.Ceiling(lx / t - 1e-9), 3, 40), Math.Clamp((int)Math.Ceiling(ly / t - 1e-9), 3, 40));
        }
        double target = p.Id == Auto ? Math.Clamp(Math.Min(lx, ly) / 12.0, 0.12, 0.40) : p.TargetM;
        int lo = p.Id == "Grossier" ? 3 : 4;
        return (Math.Clamp((int)Math.Ceiling(lx / target - 1e-9), lo, p.MaxCells), Math.Clamp((int)Math.Ceiling(ly / target - 1e-9), lo, p.MaxCells));
    }

    /// <summary>Taille des éléments d'un voile : réglage propre au voile, sinon réglage global.</summary>
    public static double WallSize(WallDef w, DesignSettings? s)
    {
        s ??= new DesignSettings();
        string id = string.IsNullOrEmpty(w.MeshMode) || w.MeshMode == GlobalId ? s.MeshPreset : w.MeshMode;
        double size;
        if (id == Manual) size = w.MeshMode == Manual ? w.MeshM : s.MeshManualM;
        else if (id == Auto) size = Math.Clamp(Math.Min(w.LengthM, w.HeightM) / 12.0, 0.10, 0.40);
        else size = Get(id).TargetM;
        size = Math.Max(size, 0.05);
        double n = w.LengthM / size * (w.HeightM / size);
        if (n > 6000) size *= Math.Sqrt(n / 6000.0);           // plafond de taille du calcul
        return size;
    }
}
