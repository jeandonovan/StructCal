namespace StructCalc.Core;

/// <summary>Identité du logiciel et de son auteur (affichée dans l'interface, les notes de calcul, les plans et les fichiers exportés).</summary>
public static class AppInfo
{
    public const string Name = "StructCalc";
    /// <summary>Extension des fichiers de projet StructCalc (contenu JSON lisible). Les anciens projets « .json » restent ouvrables.</summary>
    public const string FileExt = ".stcx";
    public const string OpenFilter = "Projet StructCalc (*.stcx;*.json)|*.stcx;*.json|Tous les fichiers (*.*)|*.*";
    public const string SaveFilter = "Projet StructCalc (*.stcx)|*.stcx";
    public const string Version = "1.0.0";
    public const string Author = "Maximilien EKRESSIN";
    public const string Email = "jeandonovan33@gmail.com";
    public const string Phones = "+225 0777505213 / +225 0799518100";
    public const string WhatsAppNumber = "2250777505213";     // format international sans « + », pour les liens wa.me
    public const string Copyright = "© Maximilien EKRESSIN - Tous droits réservés";
    public static string ContactLine => $"{Author} - {Email} - {Phones}";
    public static string Banner => $"{Name} {Version} - {Copyright}";
}
