namespace StructCalc.Core;

public record RebarChoice(int Count, int Diameter, double AreaCm2)
{
    public string Label => $"{Count}HA{Diameter}";
}

/// <summary>Choix pratique de barres HA à partir d'une section d'acier. Le paramètre facultatif <c>cfg</c> impose les diamètres disponibles et les règles de l'utilisateur.</summary>
public static class RebarSelector
{
    private static readonly int[] BeamDiams = { 10, 12, 14, 16, 20, 25, 32 };
    private static readonly int[] ColDiams = { 12, 14, 16, 20, 25, 32 };

    public static double Area(int dia) => Math.PI * dia * dia / 4.0 / 100.0;   // cm²

    public static RebarChoice ForBeam(double asCm2, double widthM, double coverM, DesignSettings? cfg = null)
    {
        double avail = widthM * 1000.0 - 2.0 * coverM * 1000.0;   // entre axes des barres d'angle
        int[] dias = cfg?.BeamDias() ?? BeamDiams;
        int maxBars = cfg?.MaxBarsPerLayer ?? 6;
        double minClear = cfg?.MinClearSpacingMm ?? 25.0;
        RebarChoice? last = null;
        foreach (int dia in dias)
        {
            int n = Math.Max(2, (int)Math.Ceiling(asCm2 / Area(dia) - 1e-9));
            last = new RebarChoice(n, dia, n * Area(dia));
            bool fits = (n - 1) * (dia + Math.Max(dia, minClear)) <= avail;
            if (fits && n <= maxBars) return last;
        }
        return last!;
    }

    public static RebarChoice ForColumn(double asTotCm2, DesignSettings? cfg = null)
    {
        int[] dias = cfg?.ColumnDias() ?? ColDiams;
        int maxBars = cfg?.MaxColumnBars ?? 12;
        RebarChoice? last = null;
        foreach (int dia in dias)
        {
            int n = Math.Max(4, (int)Math.Ceiling(asTotCm2 / Area(dia) - 1e-9));
            if (n % 2 == 1) n++;
            last = new RebarChoice(n, dia, n * Area(dia));
            if (n <= maxBars) return last;
        }
        return last!;
    }

    /// <summary>Cadres (2 brins) : retourne (diamètre mm, espacement cm).</summary>
    public static (int Dia, double SpacingCm) Stirrups(double atStCm2PerM, double stMaxCm, int minDia = 6, DesignSettings? cfg = null)
    {
        int[] dias = cfg?.StirrupDias() ?? new[] { 6, 8, 10, 12 };
        double step = cfg != null && cfg.SpacingStepCm > 0 ? cfg.SpacingStepCm : 1.0;
        double minSp = cfg?.MinStirrupSpacingCm ?? 5.0;
        (int, double) last = (dias[^1], Math.Max(minSp, 5));
        foreach (int dia in dias)
        {
            if (dia < minDia) continue;
            double at = 2.0 * Area(dia);
            double st = atStCm2PerM <= 1e-9 ? stMaxCm : Math.Min(stMaxCm, Math.Floor(100.0 * at / atStCm2PerM / step) * step);
            last = (dia, Math.Max(st, minSp));
            if (st >= Math.Max(7, minSp)) return (dia, st);
        }
        return last;
    }

    /// <summary>Dalles : (diamètre, espacement cm) pour As en cm²/m.</summary>
    public static (int Dia, double SpacingCm) Spacing(double asCm2PerM, double maxSpacingCm, DesignSettings? cfg = null)
    {
        int[] dias = cfg?.SlabDias() ?? new[] { 8, 10, 12, 14, 16 };
        double minS = cfg?.SlabMinSpacingCm ?? 10.0;
        (int, double) last = (dias[^1], 5);
        foreach (int dia in dias)
        {
            double s = asCm2PerM <= 1e-9 ? maxSpacingCm : Math.Min(maxSpacingCm, Math.Floor(100.0 * Area(dia) / asCm2PerM));
            last = (dia, Math.Max(s, 5));
            if (s >= minS) return (dia, s);
        }
        return last;
    }
}
