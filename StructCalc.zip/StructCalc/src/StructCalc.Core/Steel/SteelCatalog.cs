namespace StructCalc.Core.Steel;

/// <summary>Profilé en I laminé (dimensions en mm). Les propriétés sont calculées avec les formules usuelles incluant les congés de raccordement
/// (écart typique &lt; 1 % par rapport aux catalogues ; la constante de torsion est sous-estimée).</summary>
public sealed class SteelProfile
{
    public SteelProfile(string name, string family, double h, double b, double tw, double tf, double r)
    { Name = name; Family = family; H = h; B = b; Tw = tw; Tf = tf; R = r; }

    /// <summary>Profil dont les caractéristiques sont celles du catalogue (bibliothèque ArcelorMittal) et non calculées.</summary>
    public SteelProfile(LibrarySection lib)
        : this(lib.Name, lib.Series, lib.H, lib.B, lib.Tw, lib.Tf, double.IsNaN(lib.R) ? 0 : lib.R)
    { Lib = lib; }

    /// <summary>Données tabulées (null = caractéristiques calculées par formules).</summary>
    public LibrarySection? Lib { get; }

    public string Name { get; }
    public string Family { get; }
    public double H { get; }
    public double B { get; }
    public double Tw { get; }
    public double Tf { get; }
    public double R { get; }

    public double AreaMm2 => Lib != null ? Lib.A * 100.0 : 2 * B * Tf + (H - 2 * Tf) * Tw + (4 - Math.PI) * R * R;
    public double IyMm4
    {
        get
        {
            if (Lib != null) return Lib.Iy * 1e4;
            double hw = H - 2 * Tf;
            return (B * Math.Pow(H, 3) - (B - Tw) * Math.Pow(hw, 3)) / 12.0 + 0.03 * Math.Pow(R, 4)
                   + 0.2146 * R * R * Math.Pow(hw - 0.4468 * R, 2);
        }
    }
    public double IzMm4 => Lib != null && !double.IsNaN(Lib.Iz) ? Lib.Iz * 1e4 : (2 * Tf * Math.Pow(B, 3) + (H - 2 * Tf) * Math.Pow(Tw, 3)) / 12.0 + 0.03 * Math.Pow(R, 4)
                           + 0.2146 * R * R * Math.Pow(Tw + 0.4468 * R, 2);
    public double WelYMm3 => Lib != null ? Lib.Wely * 1e3 : IyMm4 / (H / 2);
    public double WelZMm3 => Lib != null && !double.IsNaN(Lib.Welz) ? Lib.Welz * 1e3 : IzMm4 / (B / 2);
    public double WplYMm3 => Lib != null ? Lib.WplyCm3 * 1e3 : B * Tf * (H - Tf) + Tw * Math.Pow(H - 2 * Tf, 2) / 4.0 + (4 - Math.PI) * R * R * (H / 2 - Tf - 0.2234 * R);
    public double WplZMm3 => Lib != null && !double.IsNaN(Lib.Wplz) ? Lib.Wplz * 1e3 : Tf * B * B / 2.0 + (H - 2 * Tf) * Tw * Tw / 4.0 + (4 - Math.PI) * R * R * (Tw / 2 + 0.2234 * R);
    public double ItMm4 => Lib != null && !double.IsNaN(Lib.ItCm4) ? Lib.ItCm4 * 1e4 : (2 * B * Math.Pow(Tf, 3) + (H - Tf) * Math.Pow(Tw, 3)) / 3.0;
    public double IwMm6 => Lib != null && !double.IsNaN(Lib.Iw) ? Lib.Iw * 1e6 : IzMm4 * Math.Pow(H - Tf, 2) / 4.0;
    public double MassKgPerM => Lib != null ? Lib.G : AreaMm2 * 1e-6 * 7850.0;

    // Valeurs SI pour le solveur (m, m², m⁴)
    public double A => AreaMm2 * 1e-6;
    public double Iy => IyMm4 * 1e-12;
    public double Iz => IzMm4 * 1e-12;
    public double J => ItMm4 * 1e-12;
}

public static class SteelCatalog
{
    private static readonly List<SteelProfile> _all = Build();
    public static IReadOnlyList<SteelProfile> All => _all;

    /// <summary>Remplace les profilés personnalisés (famille « PERSO ») par la liste donnée.</summary>
    public static void SetCustom(IEnumerable<SteelProfile> custom)
    {
        _all.RemoveAll(p => p.Family == "PERSO");
        _all.AddRange(custom);
    }

    public static bool TryGet(string name, out SteelProfile profile)
    {
        string key = (name ?? "").Replace(" ", "").ToUpperInvariant();
        profile = _all.FirstOrDefault(p => p.Name == key)!;
        return profile != null;
    }

    public static SteelProfile Get(string name) =>
        TryGet(name, out var p) ? p : throw new InvalidOperationException($"Profil inconnu : '{name}'.");

    /// <summary>Profil immédiatement supérieur (même famille, section croissante) ; null si dernier.</summary>
    public static SteelProfile? Next(string name)
    {
        if (!TryGet(name, out var p)) return null;
        var fam = _all.Where(x => x.Family == p.Family).OrderBy(x => x.AreaMm2).ToList();
        int i = fam.FindIndex(x => x.Name == p.Name);
        return i >= 0 && i < fam.Count - 1 ? fam[i + 1] : null;
    }

    private static List<SteelProfile> Build()
    {
        var l = new List<SteelProfile>();
        // (h, b, tw, tf, r)
        double[][] ipe =
        {
            new[]{80d,46,3.8,5.2,5}, new[]{100d,55,4.1,5.7,7}, new[]{120d,64,4.4,6.3,7}, new[]{140d,73,4.7,6.9,7},
            new[]{160d,82,5.0,7.4,9}, new[]{180d,91,5.3,8.0,9}, new[]{200d,100,5.6,8.5,12}, new[]{220d,110,5.9,9.2,12},
            new[]{240d,120,6.2,9.8,15}, new[]{270d,135,6.6,10.2,15}, new[]{300d,150,7.1,10.7,15}, new[]{330d,160,7.5,11.5,18},
            new[]{360d,170,8.0,12.7,18}, new[]{400d,180,8.6,13.5,21}, new[]{450d,190,9.4,14.6,21}, new[]{500d,200,10.2,16.0,21},
            new[]{550d,210,11.1,17.2,24}, new[]{600d,220,12.0,19.0,24},
        };
        double[][] hea =
        {
            new[]{96d,100,5.0,8.0,12}, new[]{114d,120,5.0,8.0,12}, new[]{133d,140,5.5,8.5,12}, new[]{152d,160,6.0,9.0,15},
            new[]{171d,180,6.0,9.5,15}, new[]{190d,200,6.5,10.0,18}, new[]{210d,220,7.0,11.0,18}, new[]{230d,240,7.5,12.0,21},
            new[]{250d,260,7.5,12.5,24}, new[]{270d,280,8.0,13.0,24}, new[]{290d,300,8.5,14.0,27}, new[]{310d,300,9.0,15.5,27},
            new[]{330d,300,9.5,16.5,27}, new[]{350d,300,10.0,17.5,27}, new[]{390d,300,11.0,19.0,27}, new[]{440d,300,11.5,21.0,27},
            new[]{490d,300,12.0,23.0,27}, new[]{590d,300,13.0,25.0,27},
        };
        double[][] heb =
        {
            new[]{100d,100,6.0,10.0,12}, new[]{120d,120,6.5,11.0,12}, new[]{140d,140,7.0,12.0,12}, new[]{160d,160,8.0,13.0,15},
            new[]{180d,180,8.5,14.0,15}, new[]{200d,200,9.0,15.0,18}, new[]{220d,220,9.5,16.0,18}, new[]{240d,240,10.0,17.0,21},
            new[]{260d,260,10.0,17.5,24}, new[]{280d,280,10.5,18.0,24}, new[]{300d,300,11.0,19.0,27}, new[]{320d,300,11.5,20.5,27},
            new[]{340d,300,12.0,21.5,27}, new[]{360d,300,12.5,22.5,27}, new[]{400d,300,13.5,24.0,27}, new[]{450d,300,14.0,26.0,27},
            new[]{500d,300,14.5,28.0,27}, new[]{600d,300,15.5,30.0,27},
        };
        int[] ipeN = { 80, 100, 120, 140, 160, 180, 200, 220, 240, 270, 300, 330, 360, 400, 450, 500, 550, 600 };
        int[] hN = { 100, 120, 140, 160, 180, 200, 220, 240, 260, 280, 300, 320, 340, 360, 400, 450, 500, 600 };
        for (int i = 0; i < ipe.Length; i++) l.Add(new SteelProfile("IPE" + ipeN[i], "IPE", ipe[i][0], ipe[i][1], ipe[i][2], ipe[i][3], ipe[i][4]));
        for (int i = 0; i < hea.Length; i++) l.Add(new SteelProfile("HEA" + hN[i], "HEA", hea[i][0], hea[i][1], hea[i][2], hea[i][3], hea[i][4]));
        for (int i = 0; i < heb.Length; i++) l.Add(new SteelProfile("HEB" + hN[i], "HEB", heb[i][0], heb[i][1], heb[i][2], heb[i][3], heb[i][4]));
        // Autres poutrelles en I/H de la bibliothèque (IPE A/O/AA, IPN, HE AA/M/C, HL, HD, HP, grandes dimensions) : valeurs tabulées.
        // Les IPE/HEA/HEB ci-dessus gardent leurs formules (comportement et résultats inchangés).
        var known = new HashSet<string>(l.Select(p => p.Name));
        foreach (var s in SteelLibrary.All)
            if (s.Shape == ProfileShape.I && !known.Contains(s.Name) && !double.IsNaN(s.Tw) && !double.IsNaN(s.R))
                l.Add(new SteelProfile(s));
        return l;
    }
}
