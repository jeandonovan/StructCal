using System.Globalization;

namespace StructCalc.Core.Steel;

public enum ProfileShape { I, U, L, T }

/// <summary>Profilé de la bibliothèque (catalogue ArcelorMittal « Gammes de profilés européens »). Valeurs tabulées :
/// longueurs en mm, aires en cm², inerties en cm⁴, modules en cm³, rayons en cm, Iw en cm⁶, masse en kg/m, surfaces AL (m²/m) et AG (m²/t).
/// Les valeurs absentes pour une forme donnée valent NaN.</summary>
public sealed class LibrarySection
{
    public string Name { get; init; } = "";      // « IPE300 », « HEA200 », « L100X100X10 »
    public string Label { get; init; } = "";     // « IPE 300 », « HE 200 A »
    public string Series { get; init; } = "";    // IPE, IPEA, IPEAA, IPEO, IPN, HEAA, HEA, HEB, HEM, HEC, HL, HD, HP, UPE, UPN, U, L, T
    public string Group { get; init; } = "";     // famille du catalogue : IPE, IPN, HE, HL, HD, HP, UPE, UPN, U, L, T
    public ProfileShape Shape { get; init; }
    public double G { get; init; }
    public double H { get; init; }
    public double B { get; init; }
    public double Tw { get; init; }
    public double Tf { get; init; }
    public double R { get; init; }
    public double R2 { get; init; } = double.NaN;
    public double A { get; init; }
    public double AL { get; init; } = double.NaN;
    public double AG { get; init; } = double.NaN;
    public double Iy { get; init; }
    public double Wely { get; init; }
    public double Wply { get; init; } = double.NaN;
    public double iy { get; init; }
    public double Avz { get; init; } = double.NaN;
    public double Iz { get; init; } = double.NaN;
    public double Welz { get; init; } = double.NaN;
    public double Wplz { get; init; } = double.NaN;
    public double iz { get; init; } = double.NaN;
    public double It { get; init; } = double.NaN;
    public double Iw { get; init; } = double.NaN;
    public double Ys { get; init; } = double.NaN;     // U : position du centre de gravité
    public double Ym { get; init; } = double.NaN;     // U : centre de cisaillement
    public double Zs { get; init; } = double.NaN;     // L, T : position du centre de gravité
    public double Iu { get; init; } = double.NaN;     // L : axes principaux
    public double iu { get; init; } = double.NaN;
    public double Iv { get; init; } = double.NaN;
    public double iv { get; init; } = double.NaN;
    public double Iyz { get; init; } = double.NaN;
    public double Alpha { get; init; } = double.NaN;  // L inégale : angle de l'axe principal (°)

    /// <summary>Constante de torsion (cm⁴) : valeur tabulée, ou estimation Σ b·t³/3 pour les cornières et tés.</summary>
    public double ItCm4 => !double.IsNaN(It) ? It : Shape == ProfileShape.L ? (H + B - Tf) * Math.Pow(Tf / 10.0, 3) / 10.0 / 3.0
        : Shape == ProfileShape.T ? (B * Math.Pow(Tf / 10.0, 3) + (H - Tf) * Math.Pow(Tw / 10.0, 3)) / 10.0 / 3.0 : double.NaN;

    /// <summary>Module plastique (cm³) : valeur tabulée, ou estimation 1,5·Wel (cornières, tés).</summary>
    public double WplyCm3 => !double.IsNaN(Wply) ? Wply : 1.5 * Wely;

    /// <summary>Résumé sur une ligne (info-bulle, barre d'état).</summary>
    public string Summary =>
        $"{Label} : {G:0.0#} kg/m, A = {A:0.0} cm², Iy = {Iy:0.#} cm⁴, Wel,y = {Wely:0.#} cm³" + (double.IsNaN(Iz) ? "" : $", Iz = {Iz:0.#} cm⁴");
}

/// <summary>Bibliothèque de profilés laminés européens (poutrelles I/H, U, cornières, tés) avec leurs caractéristiques tabulées.</summary>
public static class SteelLibrary
{
    private static readonly List<LibrarySection> _all = Load();
    private static readonly Dictionary<string, LibrarySection> _byName = _all.GroupBy(s => s.Name).ToDictionary(g => g.Key, g => g.First());

    public static IReadOnlyList<LibrarySection> All => _all;

    /// <summary>Séries disponibles dans l'ordre du catalogue.</summary>
    public static IReadOnlyList<string> Series { get; } = _all.Select(s => s.Series).Distinct().ToList();

    public static IReadOnlyList<LibrarySection> OfSeries(string series) => _all.Where(s => s.Series == series).ToList();

    public static string Normalize(string name) => (name ?? "").Replace(" ", "").Replace(',', '.').ToUpperInvariant();

    public static bool TryGet(string name, out LibrarySection section) => _byName.TryGetValue(Normalize(name), out section!);

    /// <summary>Recherche par mots (désignation) : tous les mots doivent figurer dans la désignation.</summary>
    public static IEnumerable<LibrarySection> Search(string text)
    {
        var words = (text ?? "").ToUpperInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return _all.Where(s => words.All(w => s.Name.Contains(w) || s.Label.ToUpperInvariant().Contains(w)));
    }

    /// <summary>Profil le plus léger de la série dont le module élastique Wel,y atteint la valeur demandée (cm³) ; null si aucun.</summary>
    public static LibrarySection? LightestForWely(string series, double welyCm3) =>
        _all.Where(s => s.Series == series && s.Wely >= welyCm3).OrderBy(s => s.G).FirstOrDefault();

    /// <summary>Nom du profil dans le catalogue de calcul : « HE 200 A » → « HEA200 ». Retourne la désignation inchangée pour les autres.</summary>
    public static string SeriesOf(string name)
    {
        int i = 0;
        while (i < name.Length && char.IsLetter(name[i])) i++;
        return name[..i];
    }

    private static double P(string[] f, Dictionary<string, int> col, string key)
    {
        if (!col.TryGetValue(key, out int i) || i >= f.Length || f[i].Length == 0) return double.NaN;
        return double.TryParse(f[i], NumberStyles.Float, CultureInfo.InvariantCulture, out double v) ? v : double.NaN;
    }

    private static List<LibrarySection> Load()
    {
        var col = SteelLibraryData.Columns.Split('|').Select((c, i) => (c, i)).ToDictionary(x => x.c, x => x.i);
        var list = new List<LibrarySection>();
        foreach (var line in SteelLibraryData.Rows.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var f = line.TrimEnd('\r').Split('|');
            if (f.Length < 12) continue;
            string name = f[col["name"]];
            var shape = f[col["shape"]] switch { "U" => ProfileShape.U, "L" => ProfileShape.L, "T" => ProfileShape.T, _ => ProfileShape.I };
            list.Add(new LibrarySection
            {
                Name = name, Label = f[col["label"]], Group = f[col["family"]], Series = SeriesOf(name), Shape = shape,
                G = P(f, col, "G"), H = P(f, col, "h"), B = P(f, col, "b"), Tw = P(f, col, "tw"), Tf = P(f, col, "tf"),
                R = P(f, col, "r"), R2 = P(f, col, "r2"), A = P(f, col, "A"), AL = P(f, col, "AL"), AG = P(f, col, "AG"),
                Iy = P(f, col, "Iy"), Wely = P(f, col, "Wely"), Wply = P(f, col, "Wply"), iy = P(f, col, "iy"), Avz = P(f, col, "Avz"),
                Iz = P(f, col, "Iz"), Welz = P(f, col, "Welz"), Wplz = P(f, col, "Wplz"), iz = P(f, col, "iz"),
                It = P(f, col, "It"), Iw = P(f, col, "Iw"), Ys = P(f, col, "ys"), Ym = P(f, col, "ym"), Zs = P(f, col, "zs"),
                Iu = P(f, col, "Iu"), iu = P(f, col, "iu"), Iv = P(f, col, "Iv"), iv = P(f, col, "iv"), Iyz = P(f, col, "Iyz"),
                Alpha = P(f, col, "alpha")
            });
        }
        return list;
    }
}
