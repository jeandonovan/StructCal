namespace StructCalc.Core.Model;

/// <summary>Ouverture rectangulaire dans un voile (porte, fenêtre, trémie).</summary>
public class WallOpening
{
    public string Name { get; set; } = "O1";
    public double XM { get; set; } = 1.5;        // distance du bord gauche du voile au bord gauche de l'ouverture
    public double ZM { get; set; } = 0.0;        // hauteur de l'allège (0 = porte)
    public double WidthM { get; set; } = 1.0;
    public double HeightM { get; set; } = 2.1;
    public WallOpening Clone() => (WallOpening)MemberwiseClone();
}

public enum WallBase { Encastre, Articule }

/// <summary>Voile en béton armé modélisé par éléments finis de coque (membrane + flexion de plaque), avec ouvertures.</summary>
public class WallDef
{
    public string Name { get; set; } = "V1";
    /// <summary>Identifiant du mur dans Revit (ElementId) quand il vient d'un export Revit ; vide sinon.</summary>
    public string ExternalId { get; set; } = "";
    public double X { get; set; }                 // origine (pied gauche) dans le plan, m
    public double Y { get; set; }
    public double Z { get; set; }                 // niveau du pied, m
    public double AngleDeg { get; set; }          // direction du voile dans le plan XY (0 = selon X)
    public double LengthM { get; set; } = 5.0;
    public double HeightM { get; set; } = 3.06;
    public double ThicknessM { get; set; } = 0.20;
    public string MeshElement { get; set; } = "Global";   // Global (réglage du projet) | Quad (quadrangles MITC4/QM6) | Tri (triangles CST + DKT)
    public string MeshMode { get; set; } = "Global";     // Global (réglage du projet) | Grossier | Courant | Fin | TresFin | Auto | Manuel (MeshM)
    public double MeshM { get; set; } = 0.25;     // taille cible des éléments
    public List<WallOpening> Openings { get; set; } = new();

    public WallBase Base { get; set; } = WallBase.Encastre;
    public bool TopHeldOutOfPlane { get; set; } = true;    // plancher maintenant la tête hors plan
    public bool SelfWeight { get; set; } = true;
    public double GTopKnPerM { get; set; } = 60;           // charge permanente en tête (kN/m), hors poids propre
    public double QTopKnPerM { get; set; } = 20;           // charge d'exploitation en tête (kN/m)
    public double EHorizKn { get; set; } = 0;              // effort horizontal dans le plan en tête (séisme), kN
    public double WindKPa { get; set; } = 0;               // pression perpendiculaire au voile (vent / poussée), kPa
    public CrackingClass Crack { get; set; } = CrackingClass.PeuPrejudiciable;
    public double CoverCm { get; set; } = 3;

    /// <summary>Mur de soutènement / voile périphérique : poussée des terres triangulaire (K γ z) + surcharge sur la hauteur retenue, à la place de la pression uniforme W.</summary>
    public bool Retaining { get; set; }
    /// <summary>Hauteur de terre retenue au-dessus du pied du mur (m) ; 0 = toute la hauteur du mur.</summary>
    public double RetainedHeightM { get; set; }
    public double SoilGammaKnM3 { get; set; } = 18;
    /// <summary>Coefficient de poussée (0,5 = repos K0 ; Ka pour un mur libre de se déplacer).</summary>
    public double KEarth { get; set; } = 0.5;
    public double SurchargeKPa { get; set; } = 10;

    public WallDef Clone() { var c = (WallDef)MemberwiseClone(); c.Openings = Openings.Select(o => o.Clone()).ToList(); return c; }
}
