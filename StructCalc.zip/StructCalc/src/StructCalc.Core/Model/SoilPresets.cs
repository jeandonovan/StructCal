namespace StructCalc.Core.Model;

/// <summary>Contraintes admissibles usuelles du sol à l'ELS (kPa), valeurs PRUDENTES avec coefficient de sécurité déjà inclus (capacité portante / 3 environ),
/// pour un avant-projet ou en l'absence d'étude géotechnique. Une étude de sol remplace toujours ces valeurs : saisie libre.</summary>
public static class SoilPresets
{
    public sealed record Preset(string Name, double QAdmKPa, string Remark);

    public static readonly Preset[] All =
    {
        new("Argile molle", 50, "Tassements importants : étude de sol indispensable."),
        new("Limon", 100, "Sensible à l'eau : drainer, éviter le gel."),
        new("Argile moyenne", 100, "Consistance moyenne."),
        new("Sable lâche", 100, "Compactage conseillé."),
        new("Argile ferme", 200, "Consistance ferme."),
        new("Sable moyen compact", 200, "Hors nappe."),
        new("Argile raide, marne", 300, "Consistance raide."),
        new("Sable dense", 300, "Compact à très compact."),
        new("Grave, sable et gravier compact", 400, "Bonne portance."),
        new("Roche tendre ou altérée", 700, "Purger les parties décomposées."),
        new("Roche saine fracturée", 1500, "Calcaire, grès, granite fracturés."),
        new("Roche saine massive", 3000, "Valeur prudente : la portance réelle peut dépasser 5 à 10 MPa."),
    };

    /// <summary>Texte de la « saisie libre » (valeur issue d'une étude géotechnique).</summary>
    public const string Custom = "Saisie libre (étude géotechnique)";

    public static Preset? Match(double kpa) => All.FirstOrDefault(p => Math.Abs(p.QAdmKPa - kpa) < 1e-6);
}
