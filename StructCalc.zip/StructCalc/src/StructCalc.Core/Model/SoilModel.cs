namespace StructCalc.Core.Model;

/// <summary>Couche de sol (paramètres usuels d'une reconnaissance géotechnique).</summary>
public class SoilLayer
{
    public string Name { get; set; } = "Argile sableuse";
    public double ThicknessM { get; set; } = 0;          // 0 = couche semi-infinie (dernière couche)
    public double GammaKnM3 { get; set; } = 18;          // poids volumique humide / hors d'eau
    public double GammaSatKnM3 { get; set; } = 20;       // poids volumique saturé
    public double PhiDeg { get; set; } = 25;             // angle de frottement effectif (drainé)
    public double CKPa { get; set; } = 10;               // cohésion effective (drainé) ou cohésion non drainée cu si PhiDeg = 0
    public double EoedMPa { get; set; } = 10;            // module œdométrique
    public double Cc { get; set; } = 0;                  // indice de compression (0 = utiliser Eoed)
    public double E0 { get; set; } = 0.8;                // indice des vides initial
    public SoilLayer Clone() => (SoilLayer)MemberwiseClone();
}

/// <summary>Coupe de sol du site : couches depuis le terrain naturel, nappe, coefficients de sécurité.</summary>
public class SoilProfile
{
    public List<SoilLayer> Layers { get; set; } = new();
    public double WaterDepthM { get; set; } = -1;        // profondeur de la nappe depuis le terrain naturel (< 0 = pas de nappe)
    public double FoundationDepthM { get; set; } = 1.5;  // encastrement D des semelles sous le terrain naturel
    public double FsServ { get; set; } = 3.0;            // sécurité sur la capacité portante (ELS)
    public double SettlementLimitMm { get; set; } = 25;  // tassement admissible
    public bool CheckSettlement { get; set; } = true;
    public bool Enabled => Layers.Count > 0;
    public SoilProfile Clone() { var c = (SoilProfile)MemberwiseClone(); c.Layers = Layers.Select(l => l.Clone()).ToList(); return c; }
}

public enum FootingKind { Isolee, Filante }

/// <summary>Charge linéaire (kN/m) venant de la bibliothèque de charges : mur, cloison, façade... G permanente et Q d'exploitation.</summary>
public class LineLoadItem
{
    public string Text { get; set; } = "";
    public double GKnM { get; set; }
    public double QKnM { get; set; }
    public LineLoadItem Clone() => (LineLoadItem)MemberwiseClone();
}

/// <summary>Semelle créée par l'assistant (indépendante des poteaux du modèle) : isolée ou filante sous voile.</summary>
public class FootingDef
{
    public string Name { get; set; } = "S1";
    /// <summary>Identifiant de la semelle dans Revit (si elle en vient) : sert à créer les armatures dans la maquette.</summary>
    public string ExternalId { get; set; } = "";
    public FootingKind Kind { get; set; } = FootingKind.Isolee;
    public double ColA { get; set; } = 0.30;             // poteau (ou épaisseur du voile pour une filante), sens A
    public double ColB { get; set; } = 0.30;
    public double NuKN { get; set; } = 800;              // ELU (kN, ou kN/m pour une filante)
    public double NserKN { get; set; } = 580;            // ELS
    public double MaKNm { get; set; } = 0;               // moment ELS dans le sens A (autour de B)
    public double MbKNm { get; set; } = 0;               // moment ELS dans le sens B
    public double DepthM { get; set; } = 0;              // 0 = profondeur du profil de sol
    public double FixedA { get; set; } = 0;              // 0 = dimension automatique
    public double FixedB { get; set; } = 0;
    public double QAdmOverrideKPa { get; set; } = 0;     // > 0 : contrainte admissible imposée (sans profil de sol)
    /// <summary>Semelle à glacis : bord vertical de faible épaisseur puis dessus en pente jusqu'à un plateau sous le poteau (volume de béton réduit).</summary>
    public bool Glacis { get; set; }
    /// <summary>Épaisseur au bord (cm) d'une semelle à glacis.</summary>
    public double GlacisEdgeCm { get; set; } = 25;
    /// <summary>Semelle filante posée (venue de Revit) : début de l'axe (m), direction (°), longueur (m) et cote du dessus (m) ; LengthM = 0 : non posée.
    /// La largeur A est celle de la semelle (FixedA), l'épaisseur est calculée.</summary>
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double AngleDeg { get; set; }
    public double LengthM { get; set; }
    public double ZTop { get; set; }
    /// <summary>Épaisseur réelle de la semelle dans la maquette (m), 0 = calculée.</summary>
    public double ThicknessM { get; set; }
    /// <summary>Murs et charges linéaires portés par la semelle filante (kN/m), ajoutés à Nu / Nser : 1,35 G + 1,5 Q à l'ELU, G + Q à l'ELS.</summary>
    public List<LineLoadItem> WallLoads { get; set; } = new();
    public FootingDef Clone() { var c = (FootingDef)MemberwiseClone(); c.WallLoads = WallLoads.Select(w => w.Clone()).ToList(); return c; }

    /// <summary>Copie dont Nu et Nser incluent les charges de murs (sans doublon : la liste de la copie est vidée).</summary>
    public FootingDef WithWallLoads()
    {
        var c = Clone();
        foreach (var w in WallLoads) { c.NuKN += 1.35 * w.GKnM + 1.5 * w.QKnM; c.NserKN += w.GKnM + w.QKnM; }
        c.WallLoads = new();
        return c;
    }
}
