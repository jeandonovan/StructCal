using System.Collections.ObjectModel;

namespace StructCalc.Core.Model;

public class Node
{
    public int Id { get; set; }
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
}

/// <summary>Appui : true = degré de liberté bloqué.</summary>
public class SupportDef
{
    public int NodeId { get; set; }
    public bool Ux { get; set; } = true;
    public bool Uy { get; set; } = true;
    public bool Uz { get; set; } = true;
    public bool Rx { get; set; } = true;
    public bool Ry { get; set; } = true;
    public bool Rz { get; set; } = true;
}

public enum MemberType { Beam, Column }

/// <summary>Barre. Axes locaux : x le long de la barre ; z "vers le haut" pour une barre non verticale ;
/// pour un poteau vertical, y = X global et z = Y global. B // y local, H // z local (m).</summary>
public class Member
{
    public int Id { get; set; }
    public int NodeI { get; set; }
    public int NodeJ { get; set; }
    public MemberType Type { get; set; } = MemberType.Beam;
    public MaterialKind Kind { get; set; } = MaterialKind.ReinforcedConcrete;
    public double B { get; set; } = 0.25;
    public double H { get; set; } = 0.50;
    public double Cover { get; set; } = 0.05;          // bord -> axe des aciers (m) ; recalculé après le choix des barres si CoverNomCm > 0
    /// <summary>Enrobage nominal (cm) : du bord à la face extérieure du cadre. 0 = ancien mode (l'enrobage « Cover » à l'axe est pris tel quel).
    /// Sinon l'axe des barres vaut enrobage + diamètre du cadre + demi-barre, recalculé après le choix des armatures.</summary>
    public double CoverNomCm { get; set; }
    public double LfFactor { get; set; } = 0.7;        // longueur de flambement = LfFactor x L (poteaux)
    public CrackingClass Crack { get; set; } = CrackingClass.PeuPrejudiciable;
    // Propriétés explicites (profilés acier...) ; 0 = calculées depuis B x H
    public double PropA { get; set; }
    public double PropIy { get; set; }
    public double PropIz { get; set; }
    public double PropJ { get; set; }
    public string ExternalId { get; set; } = "";       // ex. ElementId Revit
    public double Roll { get; set; }                   // rotation de la section autour de l'axe de la barre (°, sens trigonométrique)
    public string Profile { get; set; } = "";          // acier : "IPE300", "HEA240"... (vide = choix auto)
}

public class NodalLoad
{
    public int NodeId { get; set; }
    public ActionType Case { get; set; } = ActionType.G;
    public double Fx { get; set; }
    public double Fy { get; set; }
    public double Fz { get; set; }
    public double Mx { get; set; }
    public double My { get; set; }
    public double Mz { get; set; }
}

public enum MemberLoadKind
{
    /// <summary>Charge répartie uniforme sur toute la barre (kN par mètre de barre).</summary>
    Uniform,
    /// <summary>Charge répartie linéaire (trapèze, triangle ou partielle) entre les abscisses A et B : intensité Wx,Wy,Wz en A et Wx2,Wy2,Wz2 en B.</summary>
    Trapezoid,
    /// <summary>Force concentrée Px,Py,Pz (kN) à l'abscisse A.</summary>
    Point,
    /// <summary>Moment concentré Mx,My,Mz (kN.m) à l'abscisse A.</summary>
    Moment,
    /// <summary>Température : Dt = variation uniforme (°C), Dg = gradient (T haut - T bas, °C) sur la hauteur de la section.</summary>
    Thermal
}

/// <summary>Repère dans lequel les composantes d'une charge de barre sont exprimées.</summary>
public enum LoadFrame { Global, Local }

/// <summary>Charge sur une barre. Par défaut (Kind = Uniform, Frame = Global) : charge répartie uniforme en axes GLOBAUX (kN par mètre de barre).
/// Les abscisses A et B se mesurent depuis le nœud i, en mètres, ou en fraction de la longueur si Relative = true (0 à 1).</summary>
public class MemberLoad
{
    public int MemberId { get; set; }
    public ActionType Case { get; set; } = ActionType.G;
    public double Wx { get; set; }
    public double Wy { get; set; }
    public double Wz { get; set; }
    public MemberLoadKind Kind { get; set; } = MemberLoadKind.Uniform;
    public LoadFrame Frame { get; set; } = LoadFrame.Global;
    public double A { get; set; }
    public double B { get; set; }
    public bool Relative { get; set; }
    public double Wx2 { get; set; }
    public double Wy2 { get; set; }
    public double Wz2 { get; set; }
    public double Px { get; set; }
    public double Py { get; set; }
    public double Pz { get; set; }
    public double Mx { get; set; }
    public double My { get; set; }
    public double Mz { get; set; }
    public double Dt { get; set; }
    public double Dg { get; set; }
    public string Label { get; set; } = "";

    public MemberLoad Clone(int? newMemberId = null) => new()
    {
        MemberId = newMemberId ?? MemberId, Case = Case, Wx = Wx, Wy = Wy, Wz = Wz, Kind = Kind, Frame = Frame, A = A, B = B, Relative = Relative,
        Wx2 = Wx2, Wy2 = Wy2, Wz2 = Wz2, Px = Px, Py = Py, Pz = Pz, Mx = Mx, My = My, Mz = Mz, Dt = Dt, Dg = Dg, Label = Label
    };
}

/// <summary>Répartition d'une charge surfacique sur les poutres du contour.</summary>
public enum SurfaceDistribution
{
    /// <summary>Dalle portant dans les deux sens : lignes de rupture à 45° (triangles et trapèzes sur les bords).</summary>
    TwoWay,
    /// <summary>Dalle portant dans le sens X : la charge va sur les deux bords perpendiculaires à X (poutres parallèles à Y), q.Lx/2 chacun.</summary>
    OneWayX,
    /// <summary>Dalle portant dans le sens Y : la charge va sur les deux bords perpendiculaires à Y (poutres parallèles à X), q.Ly/2 chacun.</summary>
    OneWayY
}

/// <summary>Charge surfacique (kN/m², positive vers le bas) sur un panneau rectangulaire horizontal délimité par des poutres.
/// Elle est transformée en charges trapézoïdales sur les poutres du contour au moment du calcul.</summary>
public class SurfaceLoad
{
    public string Name { get; set; } = "";
    public ActionType Case { get; set; } = ActionType.Q;
    public double Q { get; set; } = 2.5;
    public SurfaceDistribution Distribution { get; set; } = SurfaceDistribution.TwoWay;
    public double Z { get; set; }
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double X1 { get; set; }
    public double Y1 { get; set; }
}

/// <summary>Prise en compte d'une dalle dans le calcul de la structure.</summary>
public enum SlabCalcMode
{
    /// <summary>Charge surfacique (poids propre + charges permanentes + exploitation) reprise dans les deux sens (lignes de rupture à 45°).</summary>
    Bidirectional,
    /// <summary>Dalle portant dans le sens X : la charge va sur les bords perpendiculaires à X.</summary>
    OneWayX,
    /// <summary>Dalle portant dans le sens Y : la charge va sur les bords perpendiculaires à Y.</summary>
    OneWayY,
    /// <summary>Dalle non chargée dans le calcul : prise en compte uniquement dans le métré (volume, coffrage).</summary>
    MassOnly
}

/// <summary>Type de dalle ou de plancher.</summary>
public enum SlabKind { Pleine, CorpsCreux, Predalle, Alveolee, Champignon, Mixte }

public class SlabPanel
{
    public string Name { get; set; } = "D1";
    /// <summary>Identifiant de la dalle dans Revit (ElementId) quand elle vient d'un export Revit ; vide sinon.</summary>
    public string ExternalId { get; set; } = "";
    public double Lx { get; set; } = 4.0;
    public double Ly { get; set; } = 5.0;
    public double H { get; set; } = 0.16;
    public double GExtra { get; set; } = 1.5;   // revêtements/cloisons (kN/m²), poids propre ajouté auto
    public double Q { get; set; } = 2.5;        // kN/m²
    public SlabContinuity Continuity { get; set; } = SlabContinuity.Interieure;
    public CrackingClass Crack { get; set; } = CrackingClass.PeuPrejudiciable;
    // Emplacement (dalle dessinée sur le modèle) : coin minimal, cote du dessus et indicateur de placement
    public bool Placed { get; set; }
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double Z { get; set; }
    /// <summary>Poids volumique du matériau de la dalle (kN/m³) : poids propre = γ x h.</summary>
    public double Gamma { get; set; } = 25;
    /// <summary>Façon dont la dalle est prise en compte dans le calcul (répartition des charges sur les poutres, ou métré seul).</summary>
    public SlabCalcMode CalcMode { get; set; } = SlabCalcMode.Bidirectional;
    /// <summary>Méthode de calcul de cette dalle : vide = réglage du projet ; sinon Coefficients, Forfaitaire, Caquot, CaquotMinoree, LignesRupture, Bandes, DDM, ElementsFinis.</summary>
    public string Method { get; set; } = "";

    /// <summary>Type de dalle (pleine, corps creux, prédalle, alvéolée, champignon, mixte).</summary>
    public SlabKind Kind { get; set; } = SlabKind.Pleine;
    /// <summary>Hauteur du hourdis (cm) et dalle de compression (cm) pour un plancher à corps creux (0 sinon).</summary>
    public double HourdisCm { get; set; }
    public double ToppingCm { get; set; }
    /// <summary>Part de béton dans le volume brut Lx x Ly x h (1 = dalle pleine ; corps creux, alvéolée, mixte < 1).</summary>
    public double VolumeFactor { get; set; } = 1;
    /// <summary>Chapiteau sous la dalle au droit des poteaux : côté carré (m) et surépaisseur (cm) ; 0 = aucun. Le poinçonnement est vérifié sur le contour du chapiteau et sur le chapiteau.</summary>
    public double CapitalSide { get; set; }
    public double CapitalExtraCm { get; set; }
    /// <summary>Enrobage des armatures (cm) ; 0 = valeur générale du projet.</summary>
    public double CoverCm { get; set; }
    /// <summary>Console (porte-à-faux) : charge linéique permanente en bout de dalle (garde-corps, acrotère), en kN/m.</summary>
    public double CantileverTipKnM { get; set; }

    /// <summary>Volume de béton (m³) = Lx x Ly x h x part de béton.</summary>
    [System.Text.Json.Serialization.JsonIgnore] public double Volume => Lx * Ly * H * VolumeFactor;
    /// <summary>Poids propre surfacique (kN/m²) = γ x h.</summary>
    [System.Text.Json.Serialization.JsonIgnore] public double SelfWeightKnM2 => Gamma * H;
    /// <summary>Poids propre total (kN) = volume x γ.</summary>
    [System.Text.Json.Serialization.JsonIgnore] public double TotalWeightKn => Volume * Gamma;
}

/// <summary>Cote manuelle entre deux points de l'espace.</summary>
public class ManualDim
{
    public double X1 { get; set; }
    public double Y1 { get; set; }
    public double Z1 { get; set; }
    public double X2 { get; set; }
    public double Y2 { get; set; }
    public double Z2 { get; set; }
    public double OffsetPx { get; set; } = 32;
}

public enum SeismicDirection { X, Y }

/// <summary>Paramètres sismiques (force statique équivalente). Norm = "RPA99" ou "EC8".</summary>
public class SeismicParams
{
    public bool Enabled { get; set; } = false;
    public string Norm { get; set; } = "RPA99";
    public SeismicDirection Direction { get; set; } = SeismicDirection.X;
    // RPA 99 v2003
    public string Zone { get; set; } = "IIa";        // I, IIa, IIb, III
    public string Group { get; set; } = "2";         // 1A, 1B, 2, 3
    public string Site { get; set; } = "S3";         // S1..S4
    public double R { get; set; } = 5.0;             // coefficient de comportement
    public double Q { get; set; } = 1.2;             // facteur de qualité
    public double Beta { get; set; } = 0.2;          // pondération charges d'exploitation
    public double XiPercent { get; set; } = 7.0;     // amortissement
    // Commun / EC8
    public double Ct { get; set; } = 0.075;          // T = Ct H^(3/4)
    public double AgOverG { get; set; } = 0.25;      // EC8 : ag/g
    public string Ground { get; set; } = "B";        // EC8 : A..E
    public double BehaviorQ { get; set; } = 3.0;     // EC8 : q
    public double ImportanceGamma { get; set; } = 1.0;
    public double PsiE { get; set; } = 0.3;          // EC8 : psi_E = phi psi_2
    /// <summary>Utiliser la période de l'analyse modale (au lieu de la formule empirique) pour l'effort sismique.
    /// RPA 99 : la période retenue ne dépasse pas 1,3 fois la période empirique.</summary>
    public bool UseModalPeriod { get; set; }
    /// <summary>Remplace la force statique équivalente par l'analyse modale spectrale (spectre de calcul, combinaison CQC).
    /// RPA 99 art. 4.3.6 : si l'effort tranchant à la base obtenu est inférieur à 80 % de l'effort statique, toutes les réponses sont augmentées.</summary>
    public bool UseResponseSpectrum { get; set; }
}

/// <summary>Niveau défini par l'utilisateur (fenêtre « Étages »). Elevation en m.</summary>
public class StoreyDef
{
    public string Name { get; set; } = "";
    public double Elevation { get; set; }
}

/// <summary>Axe de construction (grid line) défini par l'utilisateur.</summary>
public class AxisDef
{
    public string Name { get; set; } = "";
    public double Pos { get; set; }
}

/// <summary>Grille de construction : axes X (lignes x = cste, numérotés) et axes Y (lignes y = cste, lettrés).</summary>
public class GridDef
{
    public List<AxisDef> XAxes { get; set; } = new();
    public List<AxisDef> YAxes { get; set; } = new();
    public bool IsEmpty => XAxes.Count == 0 && YAxes.Count == 0;
}

/// <summary>Fond de plan importé (DXF, DWG converti, PDF, image). Placement : coordonnées modèle = Origine + Rot(Rotation) x Echelle x coordonnées source.</summary>
public class UnderlayDef
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Kind { get; set; } = "dxf";          // dxf | pdf | img
    public string Path { get; set; } = "";
    public int Page { get; set; } = 0;                 // PDF : page (0 = première)
    public double OriginX { get; set; }
    public double OriginY { get; set; }
    public double OriginZ { get; set; }
    public double Scale { get; set; } = 1.0;           // m par unité source (DXF) ou m par pixel (PDF / image)
    public double Rotation { get; set; }               // degrés, anti-horaire
    public double Opacity { get; set; } = 0.6;
    public bool Visible { get; set; } = true;
    public bool Locked { get; set; }
    public double PageWidthMm { get; set; }            // PDF : largeur de la feuille (mm)
    public List<string> HiddenLayers { get; set; } = new();   // DXF : calques masqués
    public int PixelWidth { get; set; }                // PDF/image : taille du bitmap de rendu
    public int PixelHeight { get; set; }
}

/// <summary>Bordereau de prix unitaires pour le métré chiffré (valeurs par défaut indicatives : à adapter au marché local).</summary>
public class PriceList
{
    public string Currency { get; set; } = "FCFA";
    public double ConcretePerM3 { get; set; } = 110000;      // béton dosé, coulé, vibré
    public double RebarPerKg { get; set; } = 1000;           // acier HA façonné et posé
    public double FormworkPerM2 { get; set; } = 9000;        // coffrage et décoffrage
    public double ProfilePerKg { get; set; } = 1800;         // charpente métallique fournie et posée
    public double RebarWastePercent { get; set; } = 10;      // chutes, recouvrements, coudes
    public double OverheadPercent { get; set; } = 15;        // frais généraux
    public double ProfitPercent { get; set; } = 10;          // bénéfice
    public double ContingencyPercent { get; set; } = 5;      // aléas
}

/// <summary>Combinaison d'actions définie par l'utilisateur (coefficients sur G, Q, W, S, E).</summary>
public class CustomCombo
{
    public string Name { get; set; } = "Nouvelle combinaison";
    public LimitState State { get; set; } = LimitState.ELU;
    public double G { get; set; } = 1.35;
    public double Q { get; set; } = 1.5;
    public double W { get; set; }
    public double S { get; set; }
    public double E { get; set; }

    public Combination ToCombination()
    {
        var f = new Dictionary<ActionType, double>();
        if (G != 0) f[ActionType.G] = G;
        if (Q != 0) f[ActionType.Q] = Q;
        if (W != 0) f[ActionType.W] = W;
        if (S != 0) f[ActionType.S] = S;
        if (E != 0) f[ActionType.E] = E;
        return new Combination(Name, State, f);
    }
}

/// <summary>Statut d'un message (traité / ignoré) enregistré dans le projet, avec date, utilisateur et justification : un message ignoré ne disparaît jamais sans trace.</summary>
public class MessageStatusRecord
{
    public string Key { get; set; } = "";
    /// <summary>« Traité » ou « Ignoré ».</summary>
    public string Status { get; set; } = "";
    public string Reason { get; set; } = "";
    public string User { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Now;
    /// <summary>Texte du message au moment du changement de statut (pour le retrouver même si le message a disparu depuis).</summary>
    public string Text { get; set; } = "";
}

/// <summary>Informations d'en-tête du projet (note de calcul).</summary>
public class ProjectInfo
{
    /// <summary>Type de projet choisi à la création (Bâtiment, Fondations, Ouvrage industriel, Autre) : affiché dans l'écran d'accueil.</summary>
    public string ProjectType { get; set; } = "";
    public string Client { get; set; } = "";
    public string Site { get; set; } = "";
    public string Designer { get; set; } = "";
    public string Reference { get; set; } = "";
    public string Revision { get; set; } = "";
    public string Notes { get; set; } = "";
    /// <summary>Système structurel choisi à la création : « Béton armé », « Acier » ou « Mixte » (vide = déduit des barres).</summary>
    public string StructureSystem { get; set; } = "";
}

public class StructModel
{
    public string Name { get; set; } = "Projet";
    public ProjectInfo Info { get; set; } = new();
    /// <summary>Messages marqués traités ou ignorés (conservés à la réouverture du projet).</summary>
    public List<MessageStatusRecord> MessageStatuses { get; set; } = new();
    /// <summary>Si vrai, les combinaisons ci-dessous remplacent celles de la norme.</summary>
    public bool UseCustomCombos { get; set; }
    public List<CustomCombo> CustomCombos { get; set; } = new();
    /// <summary>Coefficient de frottement semelle / sol pour le contrôle au glissement.</summary>
    public double BaseFriction { get; set; } = 0.5;
    public double Fc28 { get; set; } = 25;          // MPa
    public double Fe { get; set; } = 500;           // MPa
    public string RcCodeId { get; set; } = "BAEL91";
    public string SteelCodeId { get; set; } = "CM66";
    public bool IncludeSelfWeight { get; set; } = true;
    /// <summary>Semelles sous poteaux dessinées avec glacis (dessus en pente du bord vers le poteau) : volume de béton réduit.</summary>
    public bool FootingGlacis { get; set; }
    /// <summary>Position du poteau sur la semelle : 0 = centré ; ±1 = excentré vers le bord +X/-X (AlignX) ou +Y/-Y (AlignY).</summary>
    public int FootingAlignX { get; set; }
    /// <summary>Cotes dessinées à la main dans les vues (deux points et décalage de la ligne de cote en pixels).</summary>
    public List<ManualDim> ManualDims { get; set; } = new();
    public int FootingAlignY { get; set; }
    /// <summary>Épaisseur au bord (cm) d'une semelle à glacis.</summary>
    public double FootingGlacisEdgeCm { get; set; } = 25;
    public double SigmaSolKPa { get; set; } = 0;    // 0 = pas de calcul de semelles
    public double SteelFy { get; set; } = 275;      // limite d'élasticité acier (MPa)
    public SeismicParams Seismic { get; set; } = new();
    public DesignSettings Settings { get; set; } = new();
    public bool SwayFrame { get; set; } = true;              // ossature à noeuds déplaçables (sinon contreventée)
    public double DeflectionLimitDenominator { get; set; } = 250;   // flèche admissible des poutres = L / 250 (ELS)
    public bool AutoEffectiveLength { get; set; } = true;
    public bool BracedOutOfPlane { get; set; } = false;      // poteaux acier maintenus hors du plan du portique (lf = L)    // longueurs de flambement des poteaux acier par l'Annexe E (EC3)
    public ObservableCollection<Node> Nodes { get; set; } = new();
    public ObservableCollection<Member> Members { get; set; } = new();
    public ObservableCollection<SupportDef> Supports { get; set; } = new();
    public ObservableCollection<NodalLoad> NodalLoads { get; set; } = new();
    public ObservableCollection<MemberLoad> MemberLoads { get; set; } = new();
    public List<SurfaceLoad> SurfaceLoads { get; set; } = new();
    public ObservableCollection<SlabPanel> Slabs { get; set; } = new();
    /// <summary>Coques (voiles et dalles maillés) intégrées à la structure 3D.</summary>
    public List<ShellPanel> Shells { get; set; } = new();
    public List<StoreyDef> Levels { get; set; } = new();     // vide = détection automatique
    public GridDef Grid { get; set; } = new();               // vide = détection automatique
    public List<UnderlayDef> Underlays { get; set; } = new();
    public List<StairDef> Stairs { get; set; } = new();
    public List<RibbedFloorDef> RibbedFloors { get; set; } = new();
    public SoilProfile Soil { get; set; } = new();
    public List<WallDef> Walls { get; set; } = new();
    public List<RaftDef> Rafts { get; set; } = new();
    public List<FootingDef> FootingDefs { get; set; } = new();
    public PriceList Prices { get; set; } = new();

    /// <summary>Module d'Young instantané du béton Ei28 = 11000 fc28^(1/3), en kN/m².</summary>
    public double EcKNm2 => 11000.0 * Math.Cbrt(Fc28) * 1000.0;
}
