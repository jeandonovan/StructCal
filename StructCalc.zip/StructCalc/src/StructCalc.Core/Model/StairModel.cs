namespace StructCalc.Core.Model;

/// <summary>Disposition de l'escalier.</summary>
public enum StairLayout
{
    Droit,                 // une seule volée
    DroitPalier,           // deux volées dans l'axe + palier intermédiaire
    QuartPalier,           // quart tournant (L) avec palier d'angle
    DemiPalier,            // demi-tournant (U) : deux volées parallèles + palier
    DoubleQuartPalier,     // trois volées, deux quarts tournants (palier d'angle x2)
    QuartBalance,          // quart tournant à marches balancées (sans palier)
    DemiBalance,           // demi-tournant à marches balancées
    Helicoidal,            // hélicoïdal / colimaçon
}

public enum StairEnd { Simple, SemiEncastre, Encastre }

public enum StairUsage { Habitation, Bureaux, Public, Industrie }

/// <summary>Escalier en béton armé : données du projet (géométrie, revêtements, appuis, position). Enregistré avec le modèle.</summary>
public class StairDef
{
    public string Name { get; set; } = "E1";
    /// <summary>Identifiant de l'escalier dans Revit (vide si créé dans StructCalc) : sert à armer ses volées et paliers en 3D.</summary>
    public string ExternalId { get; set; } = "";
    public StairLayout Layout { get; set; } = StairLayout.DroitPalier;
    public StairUsage Usage { get; set; } = StairUsage.Habitation;

    // ---- géométrie
    public double HeightM { get; set; } = 3.06;          // hauteur à franchir (sol fini à sol fini)
    public double WidthM { get; set; } = 1.20;           // emmarchement
    public double TargetRiserCm { get; set; } = 17;      // hauteur de contremarche visée
    public double TargetTreadCm { get; set; } = 28;      // giron visé (0 = calculé par Blondel)
    public double RunM { get; set; } = 0;                // reculée disponible (0 = libre)
    public double StartLandingM { get; set; } = 0;       // palier de départ (dalle attenante, m)
    public double EndLandingM { get; set; } = 1.20;      // palier d'arrivée (m)
    public double MidLandingM { get; set; } = 1.20;      // longueur du palier intermédiaire (dans le sens de la volée, m)
    public double GapM { get; set; } = 0.10;             // jour entre volées (demi-tournant)
    public double InnerRadiusM { get; set; } = 0.30;     // hélicoïdal : rayon intérieur (jour)
    public double TurnAngleDeg { get; set; } = 270;      // hélicoïdal : angle total
    public double SlabThicknessCm { get; set; } = 0;     // 0 = automatique (L/30 à L/20)
    public bool StepsFilled { get; set; } = true;        // marches en béton (poids des marches)

    // ---- revêtements (épaisseur cm) et densités (kN/m³)
    public double TreadCoverCm { get; set; } = 2.0;
    public double RiserCoverCm { get; set; } = 2.0;
    public double CoverDensity { get; set; } = 22;
    public double MortarCm { get; set; } = 2.0;
    public double MortarDensity { get; set; } = 20;
    public double PlasterCm { get; set; } = 1.5;
    public double PlasterDensity { get; set; } = 18;
    public double StepDensity { get; set; } = 24;
    public double RailingKnPerM { get; set; } = 0.5;     // garde-corps par mètre de volée (horizontal)
    public double QKnPerM2 { get; set; } = 0;            // 0 = selon l'usage (2,5 / 3,0 / 4,0 / 5,0)

    // ---- appuis et béton
    public StairEnd StartSupport { get; set; } = StairEnd.SemiEncastre;
    public StairEnd EndSupport { get; set; } = StairEnd.SemiEncastre;
    public double SemiFactor { get; set; } = 0.30;       // moment d'appui = facteur x M0 (appui semi-encastré)
    public double CoverCm { get; set; } = 3.0;
    public CrackingClass Crack { get; set; } = CrackingClass.PeuPrejudiciable;

    // ---- position dans le projet (pour les plans)
    /// <summary>Escalier symétrique : le virage se fait à droite (en montant) au lieu de la gauche. Pose par l'import Revit.</summary>
    public bool Mirror { get; set; }
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
    public double AngleDeg { get; set; }
    /// <summary>Escalier posé dans le modèle d'ensemble (dessiné dans les vues 3D, plan, élévation et côté).</summary>
    public bool Placed { get; set; }

    public StairDef Clone() => (StairDef)MemberwiseClone();
}
