namespace StructCalc.Core.Model;

/// <summary>Rectangle en plan d'un radier (le contour réel est découpé en rectangles, trous exclus).</summary>
public class RaftPanel
{
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double Lx { get; set; }
    public double Ly { get; set; }
}

/// <summary>Charge linéaire posée sur un radier (mur, cloison, façade) : segment (x1,y1)-(x2,y2) en plan, G et Q en kN/m.</summary>
public class RaftLineLoad
{
    public string Text { get; set; } = "";
    public double X1 { get; set; }
    public double Y1 { get; set; }
    public double X2 { get; set; }
    public double Y2 { get; set; }
    public double GKnM { get; set; }
    public double QKnM { get; set; }
    public RaftLineLoad Clone() => (RaftLineLoad)MemberwiseClone();
    public double Length => Math.Sqrt((X2 - X1) * (X2 - X1) + (Y2 - Y1) * (Y2 - Y1));
}

/// <summary>Radier général (dalle de fondation sur le sol) : contour en rectangles, cote du dessus et épaisseur. Les poteaux et voiles du modèle posés sur lui le chargent ;
/// la pression du sol est supposée linéaire (rigidité infinie) et le ferraillage vient d'un dimensionnement en dalle inversée sur la trame des poteaux.</summary>
public class RaftDef
{
    public string Name { get; set; } = "R1";
    /// <summary>Identifiant du radier dans Revit (ElementId) quand il vient d'un export Revit ; vide sinon.</summary>
    public string ExternalId { get; set; } = "";
    public List<RaftPanel> Panels { get; set; } = new();
    public double ZTop { get; set; }
    public double H { get; set; } = 0.40;
    public double CoverCm { get; set; } = 5;
    /// <summary>Murs et charges linéaires posés directement sur le radier (en plus des poteaux et voiles du modèle).</summary>
    public List<RaftLineLoad> LineLoads { get; set; } = new();
    public RaftDef Clone() { var c = (RaftDef)MemberwiseClone(); c.LineLoads = LineLoads.Select(l => l.Clone()).ToList(); c.Panels = Panels.Select(p => new RaftPanel { X0 = p.X0, Y0 = p.Y0, Lx = p.Lx, Ly = p.Ly }).ToList(); return c; }
    public double Area => Panels.Sum(p => p.Lx * p.Ly);
}
