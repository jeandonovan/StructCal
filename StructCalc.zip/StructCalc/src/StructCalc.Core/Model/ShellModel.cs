namespace StructCalc.Core.Model;

/// <summary>Élément de coque plane à 4 nœuds (voile ou dalle maillé) intégré au modèle 3D : membrane + flexion, 6 ddl par nœud, couplé aux poutres et poteaux.
/// Les nœuds sont dans l'ordre trigonométrique autour de la normale ; la normale (N1N2 x N1N4) définit la « face +n ».</summary>
public class ShellPanel
{
    public int Id { get; set; }
    /// <summary>Nom du groupe (voile V1, dalle D1...) : les résultats sont regroupés par nom.</summary>
    public string Name { get; set; } = "V1";
    /// <summary>"Voile" ou "Dalle".</summary>
    public string Kind { get; set; } = "Voile";
    public int N1 { get; set; }
    public int N2 { get; set; }
    public int N3 { get; set; }
    public int N4 { get; set; }
    /// <summary>Épaisseur (m).</summary>
    public double T { get; set; } = 0.20;
    /// <summary>Charge permanente supplémentaire verticale (kN/m² de surface projetée), hors poids propre.</summary>
    public double GExtra { get; set; }
    /// <summary>Charge d'exploitation verticale (kN/m² de surface projetée).</summary>
    public double Q { get; set; }
}
