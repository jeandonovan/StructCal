using StructCalc.Core;

namespace StructCalc.Core.Model;

/// <summary>Plancher à corps creux (poutrelles préfabriquées + hourdis + dalle de compression) : une file de poutrelles continue sur plusieurs travées.</summary>
public class RibbedFloorDef
{
    public string Name { get; set; } = "PL1";
    public double HourdisCm { get; set; } = 16;            // hauteur du hourdis (12, 16, 20, 25, 30)
    public double ToppingCm { get; set; } = 4;             // dalle de compression
    public double SpacingM { get; set; } = 0.65;           // entraxe des poutrelles
    public double WebCm { get; set; } = 10;                // largeur de la nervure b0
    public List<double> Spans { get; set; } = new() { 3.40, 3.05, 2.95, 3.15, 3.40 };
    public double GExtraKnM2 { get; set; } = 2.36;         // revêtement + mortier + enduit sous plafond (+ cloisons légères)
    public double QKnM2 { get; set; } = 1.5;               // charge d'exploitation
    public double CoverCm { get; set; } = 2.0;
    public bool EdgeRestrained { get; set; } = true;       // appuis de rive solidaires d'un poteau/poutre (chapeaux 0,15 M0)
    public CrackingClass Crack { get; set; } = CrackingClass.PeuPrejudiciable;
    public char RibDirection { get; set; } = 'X';          // sens des poutrelles (pour les charges sur les poutres)

    // ---- emprise pour créer les charges sur les poutres (facultatif)
    public bool CreateLoads { get; set; } = false;
    public double Z { get; set; }
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double X1 { get; set; }
    /// <summary>Vrai si l'emprise (X0..X1 / Y0..Y1) est définie : sans elle le plancher ne peut être ni dessiné ni cliqué.</summary>
    public bool HasFootprint => X1 > X0 + 0.1 && Y1 > Y0 + 0.1;
    public double Y1 { get; set; }

    public double TotalHeightCm => HourdisCm + ToppingCm;
    public RibbedFloorDef Clone() { var c = (RibbedFloorDef)MemberwiseClone(); c.Spans = new List<double>(Spans); return c; }
}
