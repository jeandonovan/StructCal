using System.Globalization;
using System.Text.RegularExpressions;
using Autodesk.Revit.DB;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Reporte dans Revit les dimensions calculées ou prédimensionnées par StructCalc : sections b x h des poteaux et poutres béton, épaisseurs des dalles, radiers,
/// voiles et semelles filantes, dimensions des semelles isolées. Les types d'origine ne sont jamais modifiés : un type « SC ... » est créé (ou réutilisé) par dimension et
/// affecté à l'élément. À appeler dans une transaction ouverte.</summary>
internal static class SectionUpdater
{
    private static double Ft(double m) => UnitUtils.ConvertToInternalUnits(m, UnitTypeId.Meters);
    private static double M(double ft) => UnitUtils.ConvertFromInternalUnits(ft, UnitTypeId.Meters);
    private const double Tol = 0.005;                       // 5 mm : en dessous, rien à changer
    private static string Cm(double m) => (m * 100).ToString("0.#", CultureInfo.InvariantCulture);

    internal sealed class Report
    {
        public int Changed, Unchanged;
        public List<string> Notes = new();
    }

    public static Report Apply(Document doc, IEnumerable<RevitSummaryItem> items)
    {
        var rep = new Report();
        var done = new HashSet<string>();
        foreach (var it in items)
        {
            if (!long.TryParse(it.ExternalId, out long id)) continue;
            if (it.Type is "Slab" or "Raft" or "Wall" or "FootingStrip" or "Footing")
            {
                // une dalle ou un radier venu de Revit est repris en plusieurs panneaux : l'élément Revit n'est traité qu'une fois
                if (!done.Add(it.Type + "|" + it.ExternalId)) continue;
            }
            Element? el = doc.GetElement(new ElementId(id));
            if (el == null) continue;
            try
            {
                bool? r = it.Type switch
                {
                    "Column" or "Beam" => it.Kind == "ReinforcedConcrete" ? Frame(doc, el, it, rep) : null,
                    "Slab" or "Raft" => Layered(doc, el, it.H, rep),
                    "Wall" => Layered(doc, el, it.H, rep),
                    "FootingStrip" => Strip(doc, el, it, rep),
                    "Footing" => Isolated(doc, el, it, rep),
                    _ => null
                };
                if (r == true) rep.Changed++; else if (r == false) rep.Unchanged++;
            }
            catch (Exception ex) { rep.Notes.Add($"#{id} : {ex.Message}"); }
        }
        return rep;
    }

    // ------------------------------------------------------------------ outils
    private static Parameter? FindParam(Element e, params string[] names)
    {
        foreach (var n in names)
        {
            Parameter? p = e.LookupParameter(n);
            if (p != null && p.StorageType == StorageType.Double) return p;
        }
        return null;
    }

    private static ElementType? FindType(Document doc, ElementType baseType, string name)
    {
        foreach (Element e in new FilteredElementCollector(doc).OfClass(baseType.GetType()))
        {
            if (e is not ElementType t || t.Name != name) continue;
            if (baseType is FamilySymbol bs && t is FamilySymbol ts && ts.Family.Id != bs.Family.Id) continue;
            return t;
        }
        return null;
    }

    private static string StripTag(string name) => Regex.Replace(name, @"\s*\(SC [^)]*\)$", "");

    // ------------------------------------------------------------------ poteaux et poutres béton : b x h
    private static bool? Frame(Document doc, Element el, RevitSummaryItem it, Report rep)
    {
        if (el is not FamilyInstance fi || it.B <= 0 || it.H <= 0) return null;
        FamilySymbol sym = fi.Symbol;
        Parameter? pb = FindParam(sym, "b", "B", "Width", "Largeur"), ph = FindParam(sym, "h", "H", "Height", "Hauteur");
        if (pb == null || ph == null) { rep.Notes.Add($"#{el.Id.Value} ({sym.Name}) : paramètres b / h introuvables dans la famille, section non reportée."); return null; }
        if (Math.Abs(M(pb.AsDouble()) - it.B) < Tol && Math.Abs(M(ph.AsDouble()) - it.H) < Tol) return false;

        string name = $"SC {Cm(it.B)}x{Cm(it.H)}";
        var nt = FindType(doc, sym, name) as FamilySymbol;
        if (nt == null)
        {
            nt = sym.Duplicate(name) as FamilySymbol;
            if (nt == null) { rep.Notes.Add($"#{el.Id.Value} : création du type {name} impossible."); return null; }
            FindParam(nt, pb.Definition.Name)?.Set(Ft(it.B));
            FindParam(nt, ph.Definition.Name)?.Set(Ft(it.H));
        }
        if (!nt.IsActive) { nt.Activate(); doc.Regenerate(); }
        fi.ChangeTypeId(nt.Id);
        return true;
    }

    // ------------------------------------------------------------------ dalles, radiers, voiles : épaisseur de la structure composée
    private static bool? Layered(Document doc, Element el, double target, Report rep)
    {
        if (target <= 0) return null;
        ElementType? baseType = el switch { Floor f => f.FloorType, Wall w => w.WallType, _ => null };
        if (baseType == null) return null;
        CompoundStructure? cs = baseType switch { FloorType ft => ft.GetCompoundStructure(), WallType wt => wt.GetCompoundStructure(), _ => null };
        if (cs == null) { rep.Notes.Add($"#{el.Id.Value} ({baseType.Name}) : type sans structure composée (mur-rideau ?), épaisseur non reportée."); return null; }
        double cur = M(cs.GetWidth());
        if (Math.Abs(cur - target) < Tol) return false;

        string name = $"{StripTag(baseType.Name)} (SC {Cm(target)}cm)";
        ElementType? nt = FindType(doc, baseType, name);
        if (nt == null)
        {
            nt = baseType.Duplicate(name);
            var cs2 = cs;                                  // copie lue plus haut (GetCompoundStructure renvoie une copie) : modifiée puis réaffectée au nouveau type
            int layer = cs2.LayerCount == 1 ? 0 : cs2.StructuralMaterialIndex;
            if (layer < 0 || layer >= cs2.LayerCount) { rep.Notes.Add($"#{el.Id.Value} ({baseType.Name}) : aucune couche structurelle repérable, épaisseur non reportée."); return null; }
            double delta = Ft(target) - cs2.GetWidth();
            double nw = cs2.GetLayerWidth(layer) + delta;
            if (nw < Ft(0.01)) { rep.Notes.Add($"#{el.Id.Value} : épaisseur {Cm(target)} cm incompatible avec les couches du type {baseType.Name}."); return null; }
            cs2.SetLayerWidth(layer, nw);
            switch (nt) { case FloorType nf: nf.SetCompoundStructure(cs2); break; case WallType nw2: nw2.SetCompoundStructure(cs2); break; }
        }
        el.ChangeTypeId(nt.Id);
        return true;
    }

    // ------------------------------------------------------------------ semelle filante : largeur et épaisseur
    private static bool? Strip(Document doc, Element el, RevitSummaryItem it, Report rep)
    {
        if (el is not WallFoundation wf || it.B <= 0 || it.H <= 0) return null;
        var bt = doc.GetElement(wf.GetTypeId()) as ElementType;
        if (bt == null) return null;
        Parameter? pw = bt.get_Parameter(BuiltInParameter.CONTINUOUS_FOOTING_WIDTH);
        Parameter? pt = FindParam(bt, "Foundation Thickness", "Thickness", "Épaisseur de la fondation", "Epaisseur de la fondation", "Épaisseur", "Epaisseur");
        double curW = pw != null && pw.HasValue ? M(pw.AsDouble()) : -1, curT = pt != null && pt.HasValue ? M(pt.AsDouble()) : -1;
        bool diffW = pw != null && Math.Abs(curW - it.B) >= Tol, diffT = pt != null && Math.Abs(curT - it.H) >= Tol;
        if (pw == null && pt == null) { rep.Notes.Add($"#{el.Id.Value} ({bt.Name}) : largeur / épaisseur introuvables dans le type de semelle filante."); return null; }
        if (!diffW && !diffT) return false;

        string name = $"{StripTag(bt.Name)} (SC {Cm(it.B)}x{Cm(it.H)})";
        ElementType? nt = FindType(doc, bt, name);
        if (nt == null)
        {
            nt = bt.Duplicate(name);
            if (pw != null) nt.get_Parameter(BuiltInParameter.CONTINUOUS_FOOTING_WIDTH)?.Set(Ft(it.B));
            if (pt != null) FindParam(nt, pt.Definition.Name)?.Set(Ft(it.H));
        }
        el.ChangeTypeId(nt.Id);
        return true;
    }

    // ------------------------------------------------------------------ semelle isolée : longueur, largeur, épaisseur (selon l'orientation de l'instance)
    private static bool? Isolated(Document doc, Element el, RevitSummaryItem it, Report rep)
    {
        if (el is not FamilyInstance fi || it.B <= 0 || it.Length <= 0 || it.H <= 0) return null;
        FamilySymbol sym = fi.Symbol;
        Parameter? pl = FindParam(sym, "Length", "Longueur"), pw = FindParam(sym, "Width", "Largeur");
        Parameter? pt = FindParam(sym, "Foundation Thickness", "Thickness", "Épaisseur de la fondation", "Epaisseur de la fondation", "Épaisseur", "Epaisseur");
        if (pl == null || pw == null) { rep.Notes.Add($"#{el.Id.Value} ({sym.Name}) : semelle isolée sans paramètres Longueur / Largeur, dimensions non reportées."); return null; }
        // A = dimension suivant X, B = suivant Y : si l'instance est tournée d'un quart de tour, Longueur et Largeur s'échangent
        double rot = fi.Location is LocationPoint lp ? lp.Rotation : 0;
        bool quarter = Math.Abs(Math.Sin(rot)) > 0.7;
        double wantL = quarter ? it.Length : it.B, wantW = quarter ? it.B : it.Length;
        bool same = Math.Abs(M(pl.AsDouble()) - wantL) < Tol && Math.Abs(M(pw.AsDouble()) - wantW) < Tol && (pt == null || Math.Abs(M(pt.AsDouble()) - it.H) < Tol);
        if (same) return false;

        string name = $"SC {Cm(wantL)}x{Cm(wantW)}x{Cm(it.H)}";
        var nt = FindType(doc, sym, name) as FamilySymbol;
        if (nt == null)
        {
            nt = sym.Duplicate(name) as FamilySymbol;
            if (nt == null) { rep.Notes.Add($"#{el.Id.Value} : création du type {name} impossible."); return null; }
            FindParam(nt, pl.Definition.Name)?.Set(Ft(wantL));
            FindParam(nt, pw.Definition.Name)?.Set(Ft(wantW));
            if (pt != null) FindParam(nt, pt.Definition.Name)?.Set(Ft(it.H));
        }
        if (!nt.IsActive) { nt.Activate(); doc.Regenerate(); }
        fi.ChangeTypeId(nt.Id);
        return true;
    }
}
