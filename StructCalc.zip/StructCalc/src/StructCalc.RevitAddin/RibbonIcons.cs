using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace StructCalc.RevitAddin;

/// <summary>Icônes du ruban StructCalc, dessinées en vectoriel puis converties en images (32 px pour les grands boutons, 16 px pour les petits, rendues en double résolution
/// pour rester nettes sur les écrans à forte densité). Une pastille arrondie de couleur par fonction, avec un pictogramme blanc propre au nom du bouton :
/// liste de contrôle (Vérifier), portique + flèche (Envoyer), histogramme + flèche (Résultats), plan quadrillé (Plans), section armée (Armatures),
/// planche avec cartouche et poutre (Plans d'exécution), portique chargé (Ouvrir). Aucun fichier image à installer.</summary>
internal static class RibbonIcons
{
    /// <summary>Un tracé du pictogramme (grille 24 x 24). Fill = surface teintée en plus du contour.</summary>
    private readonly record struct Layer(string Data, bool Fill = false);

    private static readonly Dictionary<string, (Layer[] Layers, Point[] Dots, string Color)> Defs = new()
    {
        // Vérifier le modèle : liste de contrôle avec coches
        ["check"] = (new[]
        {
            new Layer("M6,5 H18 V21 H6 Z", true),
            new Layer("M9.5,3 H14.5 V6.5 H9.5 Z"),
            new Layer("M8.8,11 L10,12.2 L12.2,9.8 M14,11 H16 M8.8,16.2 L10,17.4 L12.2,15 M14,16.2 H16"),
        }, Array.Empty<Point>(), "#16A34A"),
        // Créer le modèle dans Revit : portique en construction + signe plus
        ["create"] = (new[]
        {
            new Layer("M2.5,21 V9 H13 V21 M2.5,15 H13 M1.5,21 H14"),
            new Layer("M18,6 V14 M14,10 H22"),
        }, Array.Empty<Point>(), "#7C3AED"),
        // Envoyer vers StructCalc : portique Revit à gauche, flèche vers la droite
        ["send"] = (new[]
        {
            new Layer("M2.5,20 V8 H11 V20 M2.5,14 H11 M1.5,20 H12.5"),
            new Layer("M14,14 H21.5 M18.2,10.7 L21.5,14 L18.2,17.3"),
        }, Array.Empty<Point>(), "#0284C7"),
        // Importer les résultats : flèche qui descend sur un histogramme
        ["results"] = (new[]
        {
            new Layer("M4.5,21 V15 H8.5 V21 M10,21 V11 H14 V21 M15.5,21 V13 H19.5 V21", true),
            new Layer("M3,21.5 H21 M12,2.5 V8 M9.3,5.5 L12,8.2 L14.7,5.5"),
        }, Array.Empty<Point>(), "#0D9488"),
        // Importer les plans : feuille de plan quadrillée (axes) avec flèche vers le bas
        ["plans"] = (new[]
        {
            new Layer("M5,3 H14 L19,8 V21 H5 Z", true),
            new Layer("M14,3 V8 H19 M9,12 H15 M9,17 H15 M10.5,10.5 V18.5 M13.5,10.5 V18.5"),
        }, Array.Empty<Point>(), "#6366F1"),
        // Créer les armatures : section de poteau, cadre fermé et quatre barres d'angle
        ["rebar"] = (new[]
        {
            new Layer("M3.5,3.5 H20.5 V20.5 H3.5 Z", true),
            new Layer("M7.5,7.5 H16.5 V16.5 H7.5 Z"),
        }, new[] { new Point(7.5, 7.5), new Point(16.5, 7.5), new Point(7.5, 16.5), new Point(16.5, 16.5), new Point(12, 7.5), new Point(12, 16.5) }, "#EA580C"),
        // Plans d'exécution : planche, poutre armée en élévation (cadres), cote et cartouche
        ["exec"] = (new[]
        {
            new Layer("M3.5,3.5 H20.5 V20.5 H3.5 Z"),
            new Layer("M6,6.5 H18 V11.5 H6 Z", true),
            new Layer("M9,6.5 V11.5 M12,6.5 V11.5 M15,6.5 V11.5 M6,13.8 H18 M6,12.8 V14.8 M18,12.8 V14.8 M3.5,16.5 H20.5 M13,16.5 V20.5"),
        }, Array.Empty<Point>(), "#7C3AED"),
        // Ouvrir StructCalc : portique sous des charges
        ["open"] = (new[]
        {
            new Layer("M5,21 V10 H19 V21 M5,15.5 H19 M2.5,21 H21.5"),
            new Layer("M7,2.5 V7 M5.7,5.7 L7,7 L8.3,5.7 M12,2.5 V7 M10.7,5.7 L12,7 L13.3,5.7 M17,2.5 V7 M15.7,5.7 L17,7 L18.3,5.7"),
        }, Array.Empty<Point>(), "#1E3A5F"),
    };

    private static Color Lighten(Color c, double t) =>
        Color.FromRgb((byte)(c.R + (255 - c.R) * t), (byte)(c.G + (255 - c.G) * t), (byte)(c.B + (255 - c.B) * t));

    /// <summary>Image de l'icône, ou null si le dessin échoue (le bouton s'affiche alors sans icône, sans empêcher le ruban de se charger).</summary>
    public static ImageSource? Make(string key, int size)
    {
        try
        {
            var (layers, dots, hex) = Defs[key];
            var color = (Color)ColorConverter.ConvertFromString(hex)!;
            var tile = new LinearGradientBrush(Lighten(color, 0.16), color, 90);
            tile.Freeze();
            var tint = new SolidColorBrush(Color.FromArgb(0x4D, 255, 255, 255));
            tint.Freeze();
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                double r = size * 0.22;
                dc.DrawRoundedRectangle(tile, null, new Rect(0.5, 0.5, size - 1, size - 1), r, r);
                double scale = size * 0.70 / 24, off = (size - 24 * scale) / 2;
                dc.PushTransform(new TranslateTransform(off, off));
                dc.PushTransform(new ScaleTransform(scale, scale));
                var pen = new Pen(Brushes.White, size <= 16 ? 2.6 : 1.9) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
                pen.Freeze();
                foreach (var l in layers) dc.DrawGeometry(l.Fill ? tint : null, pen, Geometry.Parse(l.Data));
                double dr = size <= 16 ? 2.3 : 1.8;
                foreach (var d in dots) dc.DrawEllipse(Brushes.White, null, d, dr, dr);
                dc.Pop(); dc.Pop();
            }
            // rendu en double résolution (192 ppp) : l'icône reste de la même taille à l'écran mais nette sur les écrans haute densité
            var bmp = new RenderTargetBitmap(size * 2, size * 2, 192, 192, PixelFormats.Pbgra32);
            bmp.Render(dv);
            bmp.Freeze();
            return bmp;
        }
        catch { return null; }
    }
}
