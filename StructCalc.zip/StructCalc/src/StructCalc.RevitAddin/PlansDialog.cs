using System.Windows;
using System.Windows.Controls;

namespace StructCalc.RevitAddin;

/// <summary>Choix avant la génération des plans d'exécution Revit : cartouche, marges de la feuille, ouvrages à traiter.</summary>
internal sealed class PlansOptions
{
    public long TitleBlockId;                       // 0 = feuilles sans cartouche
    public double LeftMm = 20, RightMm = 10, TopMm = 10, BottomMm = 55;
    public bool Beams = true, Columns = true, Slabs = true, Footings = true, Walls = true;
    public bool Dimensions = true, Schedule = true, ExportPdf, ExportDwg;

    private static string FilePath => System.IO.Path.Combine(StructCalc.Engine.RevitLink.Dir, "plans_options.txt");

    /// <summary>Derniers réglages utilisés (cartouche, marges, cases) : relus à l'ouverture de la fenêtre.</summary>
    public static PlansOptions Load()
    {
        var o = new PlansOptions();
        try
        {
            if (!System.IO.File.Exists(FilePath)) return o;
            foreach (var line in System.IO.File.ReadAllLines(FilePath))
            {
                int i = line.IndexOf('=');
                if (i <= 0) continue;
                string k = line.Substring(0, i).Trim(), v = line.Substring(i + 1).Trim();
                bool b = v == "1";
                double.TryParse(v, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double d);
                switch (k)
                {
                    case "tb": long.TryParse(v, out o.TitleBlockId); break;
                    case "l": o.LeftMm = d; break;
                    case "r": o.RightMm = d; break;
                    case "t": o.TopMm = d; break;
                    case "b": o.BottomMm = d; break;
                    case "beams": o.Beams = b; break;
                    case "cols": o.Columns = b; break;
                    case "slabs": o.Slabs = b; break;
                    case "foot": o.Footings = b; break;
                    case "walls": o.Walls = b; break;
                    case "dims": o.Dimensions = b; break;
                    case "sched": o.Schedule = b; break;
                    case "pdf": o.ExportPdf = b; break;
                    case "dwg": o.ExportDwg = b; break;
                }
            }
        }
        catch { /* réglages par défaut */ }
        return o;
    }

    public void Save()
    {
        try
        {
            string F(double d) => d.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
            string B(bool b) => b ? "1" : "0";
            System.IO.File.WriteAllLines(FilePath, new[]
            {
                "tb=" + TitleBlockId, "l=" + F(LeftMm), "r=" + F(RightMm), "t=" + F(TopMm), "b=" + F(BottomMm),
                "beams=" + B(Beams), "cols=" + B(Columns), "slabs=" + B(Slabs), "foot=" + B(Footings), "walls=" + B(Walls),
                "dims=" + B(Dimensions), "sched=" + B(Schedule), "pdf=" + B(ExportPdf), "dwg=" + B(ExportDwg)
            });
        }
        catch { /* sans importance */ }
    }
}

internal static class PlansDialog
{
    /// <summary>Retourne null si annulé. titleBlocks : (identifiant, nom) des types de cartouche du projet.</summary>
    public static PlansOptions? Ask(List<(long Id, string Name)> titleBlocks, int nBeams, int nColumns, int nSlabs, int nFootings, int nWalls)
    {
        var last = PlansOptions.Load();
        var w = new Window
        {
            Title = "StructCalc - plans d'exécution", SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize,
            WindowStartupLocation = WindowStartupLocation.CenterScreen, MinWidth = 460
        };
        var p = new StackPanel { Margin = new Thickness(16) };
        p.Children.Add(new TextBlock { Text = "Crée de vraies vues Revit (coupes, plans) des ouvrages armés par StructCalc, avec les fers visibles et cliquables, " +
                                              "des étiquettes sans chevauchement, puis les range sur des feuilles avec cartouche.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });
        p.Children.Add(new TextBlock { Text = "Cartouche :" });
        var cb = new ComboBox { Margin = new Thickness(0, 2, 0, 8) };
        cb.Items.Add("(sans cartouche)");
        foreach (var t in titleBlocks) cb.Items.Add(t.Name);
        cb.SelectedIndex = titleBlocks.Count > 0 ? 1 : 0;
        for (int i = 0; i < titleBlocks.Count; i++) if (titleBlocks[i].Id == last.TitleBlockId) cb.SelectedIndex = i + 1;
        p.Children.Add(cb);
        p.Children.Add(new TextBlock { Text = "Zones réservées sur la feuille (mm) - le cartouche occupe en général le bas ou la droite :" });
        var g = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 8) };
        TextBox Box(string label, double v)
        {
            g.Children.Add(new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 3, 0) });
            var t = new TextBox { Text = v.ToString("0"), Width = 40, Margin = new Thickness(0, 0, 10, 0) };
            g.Children.Add(t); return t;
        }
        var tl = Box("gauche", last.LeftMm); var tr = Box("droite", last.RightMm); var tt = Box("haut", last.TopMm); var tb = Box("bas", last.BottomMm);
        p.Children.Add(g);
        CheckBox C(string text, int n, bool on, double bottom = 2) => new CheckBox { Content = text, IsChecked = n > 0 && on, IsEnabled = n > 0, Margin = new Thickness(0, 2, 0, bottom) };
        var cBeam = C($"Poutres ({nBeams} armée(s) : coupe en long + 3 coupes en travers)", nBeams, last.Beams);
        var cCol = C($"Poteaux ({nColumns} armé(s) : élévation + coupe horizontale)", nColumns, last.Columns);
        var cSlab = C($"Dalles, radiers ({nSlabs} armé(s) : plan de ferraillage)", nSlabs, last.Slabs);
        var cFoot = C($"Semelles isolées et filantes ({nFootings} armée(s) : plan + coupes)", nFootings, last.Footings);
        var cWall = C($"Voiles ({nWalls} armé(s) : élévation + coupe horizontale)", nWalls, last.Walls, 8);
        foreach (var c in new[] { cBeam, cCol, cSlab, cFoot, cWall }) p.Children.Add(c);
        var cDim = new CheckBox { Content = "Cotes (dimensions de l'ouvrage) sur les vues", IsChecked = last.Dimensions, Margin = new Thickness(0, 2, 0, 2) };
        var cSch = new CheckBox { Content = "Nomenclature des aciers + récapitulatif (poids d'acier, volume de béton, kg/m³) sur des feuilles", IsChecked = last.Schedule, Margin = new Thickness(0, 2, 0, 2) };
        var cPdf = new CheckBox { Content = "Exporter les feuilles en PDF (dossier d'échange StructCalc\\Revit\\plans)", IsChecked = last.ExportPdf, Margin = new Thickness(0, 2, 0, 2) };
        var cDwg = new CheckBox { Content = "Exporter les feuilles en DWG", IsChecked = last.ExportDwg, Margin = new Thickness(0, 2, 0, 8) };
        foreach (var c in new[] { cDim, cSch, cPdf, cDwg }) p.Children.Add(c);
        p.Children.Add(new TextBlock { Text = "Les feuilles et vues « SC » d'un précédent passage sont remplacées. Pour garder une vue retouchée à la main, ajoutez « [fige] » à son nom : elle et son ouvrage ne sont plus touchés.", Foreground = System.Windows.Media.Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 0, 0, 10) });
        var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var ok = new Button { Content = "Générer", Width = 100, Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        ok.Click += (s, e) => w.DialogResult = true;
        row.Children.Add(ok); row.Children.Add(new Button { Content = "Annuler", Width = 90, IsCancel = true });
        p.Children.Add(row);
        w.Content = p;
        if (w.ShowDialog() != true) return null;
        static double N(TextBox t, double d) => double.TryParse(t.Text.Replace(',', '.'), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var v) && v >= 0 ? v : d;
        var res = new PlansOptions
        {
            TitleBlockId = cb.SelectedIndex <= 0 ? 0 : titleBlocks[cb.SelectedIndex - 1].Id,
            LeftMm = N(tl, 20), RightMm = N(tr, 10), TopMm = N(tt, 10), BottomMm = N(tb, 55),
            Beams = cBeam.IsChecked == true, Columns = cCol.IsChecked == true, Slabs = cSlab.IsChecked == true,
            Footings = cFoot.IsChecked == true, Walls = cWall.IsChecked == true,
            Dimensions = cDim.IsChecked == true, Schedule = cSch.IsChecked == true, ExportPdf = cPdf.IsChecked == true, ExportDwg = cDwg.IsChecked == true
        };
        res.Save();
        return res;
    }
}
