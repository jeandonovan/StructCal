using System.Globalization;
using System.IO;
using System.Reflection;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Crée dans Revit les vraies armatures (Rebar) calculées par StructCalc sur les poteaux et poutres béton : barres longitudinales
/// et cadres (zones nodales/critiques comprises). Les armatures créées portent le commentaire « StructCalc » et sont remplacées à chaque nouvel appel.</summary>
[Transaction(TransactionMode.Manual)]
public class ReinforceCommand : IExternalCommand
{
    internal const double MM = 1.0 / 304.8;
    internal const string Tag = "StructCalc";
    /// <summary>Commentaire des semelles créées par StructCalc (ne pas les reprendre comme dalles à l'export).</summary>
    internal const string FootingTag = "StructCalc semelle ";

    /// <summary>Boîtes englobantes des poteaux du projet : sert à prolonger les barres de poutre dans le poteau d'appui (ancrage dans le nœud).</summary>
    private static List<BoundingBoxXYZ> _columnBoxes = new();

    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            Document doc = data.Application.ActiveUIDocument.Document;
            if (!File.Exists(RevitLink.ToRevit))
            {
                TaskDialog.Show("StructCalc", "Aucun résultat reçu. Dans StructCalc : calculez (F5) puis cliquez sur « 🔗 Revit ».");
                return Result.Cancelled;
            }
            var items = ModelIO.LoadRevitSummary(RevitLink.ToRevit)
                .Where(i => i.Kind == "ReinforcedConcrete" && (long.TryParse(i.ExternalId, out _) || (i.Type == "Footing" && i.HasRect))
                            && (((i.Type == "Column" || i.Type == "Beam") && i.BotN > 0 && i.StirDia > 0) || ((i.Type == "Slab" || i.Type == "Footing" || i.Type == "FootingStrip" || i.Type == "Raft" || i.Type == "Wall" || i.Type == "Stair") && i.Extra.Count > 0)))
                .ToList();
            if (items.Count == 0)
            {
                TaskDialog.Show("StructCalc", "Aucun poteau, poutre, dalle, radier, voile, escalier ou semelle béton lié à Revit dans les derniers résultats (modèle non issu de Revit, ou ferraillage absent).");
                return Result.Cancelled;
            }
            var td = new TaskDialog("StructCalc") { MainInstruction = $"Créer les armatures de {items.Count} élément(s) béton ?" };
            int nNew = items.Count(i => i.Type == "Footing" && !long.TryParse(i.ExternalId, out _));
            td.MainContent = "Les armatures « StructCalc » déjà présentes sur ces éléments seront remplacées." +
                (nNew > 0 ? $"\n\n{nNew} semelle(s) calculée(s) par StructCalc n'existent pas dans Revit : elles seront créées (dalle de fondation) puis armées. Les semelles déjà créées par StructCalc sont recréées." : "");
            td.CommonButtons = TaskDialogCommonButtons.Ok | TaskDialogCommonButtons.Cancel;
            if (td.Show() != TaskDialogResult.Ok) return Result.Cancelled;

            _columnBoxes = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType()
                .Select(el => el.get_BoundingBox(null)).Where(bb => bb != null).Select(bb => bb!).ToList();
            int done = 0, bars = 0;
            var errors = new List<string>();
            // escaliers : associations palier-volée détectées, à vérifier ou corriger par l'utilisateur avant la création des armatures
            var stairPlans = new Dictionary<string, StairPlan>();
            var stairOpts = new StairTransOptions();
            var stairChecks = new StairCheckSet();
            string stairParamMsg = "";
            foreach (var sit in items.Where(i => i.Type == "Stair"))
            {
                var plan = StairRebar.Detect(doc, long.TryParse(sit.ExternalId, out var sid) ? doc.GetElement(new ElementId(sid)) : null);
                if (plan == null) continue;
                if (!StairLinksDialog.Ask(sit.Summary.Length > 30 ? sit.Summary.Substring(0, 30) : sit.Summary, plan.RunNames, plan.LandNames, plan.Start, plan.End, stairOpts)) return Result.Cancelled;
                stairPlans[sit.ExternalId] = plan;
            }
            using (var tx = new Transaction(doc, "StructCalc - armatures"))
            {
                tx.Start();
                var types = new Dictionary<int, RebarBarType?>();
                RebarHookType? hook = GetHook(doc, 135.0, "135");
                RebarHookType? hook90 = GetHook(doc, 90.0, "90");
                var cleared = new HashSet<string>();
                // semelles créées lors d'un appel précédent : supprimées (avec leurs armatures) avant d'être recréées
                // (celles déjà liées à StructCalc par leur identifiant — après un nouvel export — sont conservées et simplement armées)
                var linked = new HashSet<string>(items.Select(i => i.ExternalId));
                foreach (var old in new FilteredElementCollector(doc).OfClass(typeof(Floor)).WhereElementIsNotElementType().ToList())
                    if ((old.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() ?? "").StartsWith(FootingTag) && !linked.Contains(old.Id.Value.ToString(CultureInfo.InvariantCulture)))
                    { try { doc.Delete(old.Id); } catch { } }
                foreach (var it in items)
                {
                    var sub = new SubTransaction(doc);
                    sub.Start();
                    string label = it.MemberId > 0 ? $"#{it.MemberId}" : (it.Summary.Length > 24 ? it.Summary.Substring(0, 24) : it.Summary);
                    try
                    {
                        Element? host;
                        if (it.Type == "Footing" && !long.TryParse(it.ExternalId, out _))
                        {
                            host = CreateFooting(doc, it, out string ferr);
                            if (host == null) { sub.RollBack(); errors.Add($"{label} : {ferr}"); continue; }
                        }
                        else
                        {
                            host = doc.GetElement(new ElementId(long.Parse(it.ExternalId, CultureInfo.InvariantCulture)));
                            if (host == null) { sub.RollBack(); errors.Add($"{label} : élément introuvable"); continue; }
                        }
                        if (it.Type == "Stair")
                        {
                            stairPlans.TryGetValue(it.ExternalId, out var splan);
                            string serr = "associations palier-volée non établies";
                            int ns = -1;
                            if (splan != null) ns = StairRebar.Reinforce(doc, splan, it, types, stairOpts, stairChecks, out serr);
                            if (ns <= 0) { sub.RollBack(); errors.Add($"{label} : {serr}"); continue; }
                            if (serr != "") errors.Add($"{label} : {serr}");
                            sub.Commit(); done++; bars += ns; continue;
                        }
                        var hd = RebarHostData.GetRebarHostData(host);
                        if (hd == null || !hd.IsValidHost()) { sub.RollBack(); errors.Add($"{label} : l'élément n'accepte pas d'armatures (famille non béton ?)"); continue; }
                        if (cleared.Add(host.Id.Value.ToString()))
                            foreach (var old in hd.GetRebarsInHost().ToList())
                                if (old.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() == Tag) doc.Delete(old.Id);

                        string err;
                        int n;
                        if (it.Type == "Slab") n = ReinforceSlab(doc, host, it, types, out err);
                        else if (it.Type == "Footing") n = ReinforceFooting(doc, host, it, types, out err);
                        else if (it.Type == "FootingStrip") n = ReinforceStrip(doc, host, it, types, out err);
                        else if (it.Type == "Raft") n = ReinforceRaft(doc, host, it, types, out err);
                        else if (it.Type == "Wall") n = ReinforceWall(doc, host, it, types, out err);
                        else n = Reinforce(doc, (FamilyInstance)host, it, types, hook, hook90, out err);
                        if (n < 0) { sub.RollBack(); errors.Add($"{label} : {err}"); continue; }
                        sub.Commit(); done++; bars += n;
                    }
                    catch (Exception ex) { try { sub.RollBack(); } catch { } errors.Add($"{label} : {ex.Message}"); }
                }
                if (stairChecks.Anchors.Count + stairChecks.Laps.Count + stairChecks.Bends.Count > 0) stairParamMsg = stairChecks.ApplyToRevit(doc, data.Application.Application);
                tx.Commit();
            }
            string msg = $"{done} élément(s) armé(s), {bars} jeu(x) d'armatures créé(s).";
            if (stairChecks.Anchors.Count + stairChecks.Laps.Count + stairChecks.Bends.Count > 0)
            {
                try
                {
                    string cdir = stairChecks.Write();
                    msg += $"\n\nContrôle des escaliers : {stairChecks.Anchors.Count} ancrage(s), {stairChecks.Laps.Count} recouvrement(s), {stairChecks.Bends.Count} cintrage(s), {stairChecks.NonCompliant} point(s) à traiter. Rapport : {System.IO.Path.Combine(cdir, "controle_escaliers.html")}" + (stairParamMsg != "" ? $" ; {stairParamMsg}" : "");
                }
                catch (Exception ex) { msg += "\n\nRapport de contrôle des escaliers non écrit : " + ex.Message; }
            }
            if (errors.Count > 0) msg += $"\n\n{errors.Count} élément(s) non armé(s) :\n" + string.Join("\n", errors.Take(8)) + (errors.Count > 8 ? "\n..." : "");
            if (items.Any(i => i.Type == "Footing" && !long.TryParse(i.ExternalId, out _)))
                msg += "\n\nLes semelles créées ont maintenant un identifiant Revit : refaites « Envoyer vers StructCalc » pour les lier au modèle (dimensions et ferraillage suivront ensuite chaque recalcul).";
            TaskDialog.Show("StructCalc", msg);
            return Result.Succeeded;
        }
        catch (Exception ex) { message = ex.Message; return Result.Failed; }
    }

    // ------------------------------------------------------------------ géométrie de l'élément
    internal static List<XYZ> Vertices(Element e)
    {
        var pts = new List<XYZ>();
        var ge = e.get_Geometry(new Options { DetailLevel = ViewDetailLevel.Fine, ComputeReferences = false });
        if (ge == null) return pts;
        void AddSolid(Solid s)
        {
            if (s == null || s.Volume < 1e-9) return;
            foreach (Edge ed in s.Edges) { var c = ed.AsCurve(); pts.Add(c.GetEndPoint(0)); pts.Add(c.GetEndPoint(1)); }
        }
        foreach (GeometryObject go in ge)
        {
            if (go is Solid s) AddSolid(s);
            else if (go is GeometryInstance gi) foreach (GeometryObject g2 in gi.GetInstanceGeometry()) if (g2 is Solid s2) AddSolid(s2);
        }
        return pts;
    }

    /// <summary>Repère de l'élément : u = axe, v et w = axes de la section (orthonormés), et étendues (projections sur u, v, w).</summary>
    private static bool Frame(FamilyInstance fi, bool column, out XYZ u, out XYZ v, out XYZ w)
    {
        u = XYZ.BasisZ; v = XYZ.BasisX; w = XYZ.BasisY;
        if (column)
        {
            XYZ bx = fi.GetTransform().BasisX; bx = new XYZ(bx.X, bx.Y, 0);
            v = bx.GetLength() > 0.1 ? bx.Normalize() : XYZ.BasisX;
            w = u.CrossProduct(v).Normalize();
            return true;
        }
        if (fi.Location is not LocationCurve lc) return false;
        XYZ d = lc.Curve.GetEndPoint(1) - lc.Curve.GetEndPoint(0);
        if (d.GetLength() < 1e-6) return false;
        u = d.Normalize();
        XYZ vv = XYZ.BasisZ.CrossProduct(u);
        if (vv.GetLength() < 0.1) return false;                // poutre verticale : non gérée
        v = vv.Normalize();
        w = u.CrossProduct(v).Normalize();
        return true;
    }

    private static XYZ P(XYZ u, XYZ v, XYZ w, double a, double b, double c) => u * a + v * b + w * c;

    /// <summary>Si un poteau enveloppe l'extrémité de la poutre (sens = +1 fin, -1 début), retourne la position (le long de u) de sa face opposée ; sinon l'extrémité inchangée.</summary>
    private static double ColumnReach(XYZ u, XYZ v, XYZ w, double uEnd, int sens, double vm, double wm)
    {
        double tol = 0.03 / 0.3048;                                         // 3 cm de tolérance
        XYZ pt = P(u, v, w, uEnd + sens * 0.02 / 0.3048, vm, wm);
        foreach (var bb in _columnBoxes)
        {
            XYZ mn = bb.Min, mx = bb.Max;
            if (pt.X < mn.X - tol || pt.X > mx.X + tol || pt.Y < mn.Y - tol || pt.Y > mx.Y + tol || pt.Z < mn.Z - tol || pt.Z > mx.Z + tol) continue;
            double best = sens > 0 ? double.MinValue : double.MaxValue;
            foreach (double cx in new[] { mn.X, mx.X })
                foreach (double cy in new[] { mn.Y, mx.Y })
                    foreach (double cz in new[] { mn.Z, mx.Z })
                    {
                        double pr = cx * u.X + cy * u.Y + cz * u.Z;
                        best = sens > 0 ? Math.Max(best, pr) : Math.Min(best, pr);
                    }
            double gain = sens * (best - uEnd);
            if (gain > 0.02 / 0.3048 && gain < 1.5 / 0.3048) return best;       // poteau raisonnable (< 1,5 m de large dans l'axe)
        }
        return uEnd;
    }

    // ------------------------------------------------------------------ armatures
    private static int Reinforce(Document doc, FamilyInstance fi, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, RebarHookType? hook, RebarHookType? hook90, out string err)
    {
        err = "";
        bool column = it.Type == "Column";
        if (!Frame(fi, column, out XYZ u, out XYZ v, out XYZ w)) { err = "orientation non reconnue (poutre verticale ?)"; return -1; }
        var pts = Vertices(fi);
        if (pts.Count < 4) { err = "géométrie illisible"; return -1; }
        double u0 = pts.Min(p => p.DotProduct(u)), u1 = pts.Max(p => p.DotProduct(u));
        double v0 = pts.Min(p => p.DotProduct(v)), v1 = pts.Max(p => p.DotProduct(v));
        double w0 = pts.Min(p => p.DotProduct(w)), w1 = pts.Max(p => p.DotProduct(w));

        double cover = it.Cover > 0.005 ? it.Cover : (column ? 0.04 : 0.05);   // m
        double cv = cover / 0.3048;                                       // enrobage en pieds
        double ds = it.StirDia * MM;
        RebarBarType? stirType = BarTypeFor(doc, types, it.StirDia);
        RebarBarType? botType = BarTypeFor(doc, types, it.BotDia);
        RebarBarType? topType = BarTypeFor(doc, types, it.TopDia > 0 ? it.TopDia : it.BotDia);
        if (stirType == null || botType == null || topType == null)
        {
            err = "aucun type d'armature HA" + it.BotDia + " dans le projet et création impossible (chargez/dupliquez un type d'armature)";
            return -1;
        }
        int count = 0;

        // --- cadres : rectangle fermé dans le plan (v, w), à la cote a le long de u
        double off = cv + ds / 2;
        IList<Curve> Loop(double a)
        {
            var c = new List<Curve>();
            XYZ p1 = P(u, v, w, a, v0 + off, w0 + off), p2 = P(u, v, w, a, v1 - off, w0 + off), p3 = P(u, v, w, a, v1 - off, w1 - off), p4 = P(u, v, w, a, v0 + off, w1 - off);
            c.Add(Line.CreateBound(p1, p2)); c.Add(Line.CreateBound(p2, p3)); c.Add(Line.CreateBound(p3, p4)); c.Add(Line.CreateBound(p4, p1));
            return c;
        }
        // contrôle sur la géométrie réelle : les crochets de cadre doivent rentrer dans la section, jamais en sortir
        bool StirrupHooksInside(Rebar rb)
        {
            var cs = CenterlineOf(rb);
            if (cs == null) return true;
            double tol = 0.004;        // ~1 mm
            foreach (var c in cs)
                foreach (var pt in c.Tessellate())
                {
                    double pv = pt.DotProduct(v), pw = pt.DotProduct(w);
                    if (pv < v0 + off - tol || pv > v1 - off + tol || pw < w0 + off - tol || pw > w1 - off + tol) return false;
                }
            return true;
        }
        int Stirrups(double aStart, double aEnd, double spacingCm)
        {
            if (aEnd < aStart) return 0;
            var r = CreateWithHookCheck(doc, RebarStyle.StirrupTie, stirType, hook, hook, fi, u, Loop(aStart),
                RebarHookOrientation.Right, RebarHookOrientation.Left, StirrupHooksInside);
            if (r == null) return 0;
            r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
            double len = aEnd - aStart, sp = Math.Max(spacingCm, 5) / 100.0 / 0.3048;
            if (len > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, len, true, true, true);
            return 1;
        }

        double L = u1 - u0, ccv = cv;                                      // pieds
        double sMid = it.StirSpacingCm, sNod = it.NodalSpacingCm, zone = it.NodalZoneM / 0.3048;
        if (sNod > 0 && zone > 0 && 2 * zone < 0.9 * L)
        {
            double spN = sNod / 100.0 / 0.3048, spM = Math.Max(sMid, 5) / 100.0 / 0.3048;
            int nz = (int)Math.Floor((zone - ccv) / spN);
            double endZ1 = u0 + ccv + nz * spN, startZ3 = u1 - ccv - nz * spN;
            count += Stirrups(u0 + ccv, endZ1, sNod);
            double midA = endZ1 + spM, midB = startZ3 - spM;
            if (midB > midA) count += Stirrups(midA, midB, sMid);
            count += Stirrups(startZ3, u1 - ccv, sNod);
        }
        else count += Stirrups(u0 + ccv, u1 - ccv, sMid);

        // --- barres longitudinales
        // ancrage dans le nœud : à chaque extrémité de poutre appuyée sur un poteau, la barre est prolongée jusqu'à la face opposée du poteau (moins l'enrobage)
        double u0e = u0, u1e = u1;
        if (!column)
        {
            double vm = (v0 + v1) / 2, wm = (w0 + w1) / 2;
            u0e = ColumnReach(u, v, w, u0, -1, vm, wm);
            u1e = ColumnReach(u, v, w, u1, +1, vm, wm);
        }
        double offL = cv + ds + 0;                                          // + moitié du diamètre de la barre, ajouté plus bas
        // crochets d'ancrage à 90° (poutres) : lit inférieur relevé (Right = vers +w), lit supérieur rabattu (Left = vers -w)
        void Bar(RebarBarType t, double vv, double ww, int hookDir = 0)
        {
            XYZ a = P(u, v, w, u0e + cv, vv, ww), b = P(u, v, w, u1e - cv, vv, ww);
            RebarHookType? hk = hookDir != 0 ? hook90 : null;
            var ori = hookDir > 0 ? RebarHookOrientation.Right : RebarHookOrientation.Left;
            // contrôle sur la géométrie réelle : à chaque extrémité le crochet doit partir du côté voulu (hookDir > 0 : vers +w)
            bool HooksOk(Rebar rb)
            {
                var cs = CenterlineOf(rb);
                if (cs == null || cs.Count < 1) return true;
                // lecture indépendante de l'ordre des courbes : on regarde, à CHAQUE extrémité de la barre (selon u), de quel côté (w) part le crochet
                var pts = new List<XYZ>();
                foreach (var c in cs) pts.AddRange(c.Tessellate());
                if (pts.Count < 2) return true;
                double lo = pts.Min(q => q.DotProduct(u)), hi = pts.Max(q => q.DotProduct(u));
                double win = Math.Min(0.8, (hi - lo) / 3);                       // ~240 mm : couvre le coude et la jambe du crochet
                int Side(Func<XYZ, bool> inEnd)
                {
                    double best = 0;
                    foreach (var q in pts) if (inEnd(q)) { double dd = q.DotProduct(w) - ww; if (Math.Abs(dd) > Math.Abs(best)) best = dd; }
                    return Math.Abs(best) < 0.003 ? 0 : Math.Sign(best);
                }
                return Side(q => q.DotProduct(u) - lo < win) == hookDir && Side(q => hi - q.DotProduct(u) < win) == hookDir;
            }
            var r = hk == null
                ? Rebar.CreateFromCurves(doc, RebarStyle.Standard, t, null, null, fi, v, new List<Curve> { Line.CreateBound(a, b) }, ori, ori, true, true)
                : CreateWithHookCheck(doc, RebarStyle.Standard, t, hk, hk, fi, v, new List<Curve> { Line.CreateBound(a, b) }, ori, ori, HooksOk);
            r?.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
            if (r != null) count++;
        }
        if (column)
        {
            double dl = it.BotDia * MM, o = offL + dl / 2;
            double a0 = v0 + o, a1 = v1 - o, b0 = w0 + o, b1 = w1 - o;
            int n = Math.Max(it.BotN, 4);
            // 4 angles, puis les barres restantes réparties sur les faces (la plus longue d'abord)
            var faceLen = new[] { a1 - a0, a1 - a0, b1 - b0, b1 - b0 };   // bas, haut, gauche, droite
            var extra = new int[4];
            for (int k = 0; k < n - 4; k++)
            {
                int best = 0; double bestV = -1;
                for (int f = 0; f < 4; f++) { double val = faceLen[f] / (extra[f] + 1); if (val > bestV + 1e-9) { bestV = val; best = f; } }
                extra[best]++;
            }
            Bar(botType, a0, b0); Bar(botType, a1, b0); Bar(botType, a1, b1); Bar(botType, a0, b1);
            for (int i = 1; i <= extra[0]; i++) Bar(botType, a0 + (a1 - a0) * i / (extra[0] + 1), b0);
            for (int i = 1; i <= extra[1]; i++) Bar(botType, a0 + (a1 - a0) * i / (extra[1] + 1), b1);
            for (int i = 1; i <= extra[2]; i++) Bar(botType, a0, b0 + (b1 - b0) * i / (extra[2] + 1));
            for (int i = 1; i <= extra[3]; i++) Bar(botType, a1, b0 + (b1 - b0) * i / (extra[3] + 1));
        }
        else
        {
            // poutre : lits inférieur et supérieur, sur plusieurs files si les barres ne tiennent pas côte à côte ; crochets d'ancrage à 90°
            void Layer(RebarBarType t, int n, int dia, bool bottom)
            {
                double dl = dia * MM, gap = Math.Max(dl, 25 * MM);               // espacement libre mini entre barres : max(Ø, 25 mm)
                double o = offL + dl / 2, a0 = v0 + o, a1 = v1 - o;
                int perRow = Math.Max(1, (int)Math.Floor((a1 - a0) / (dl + gap)) + 1);
                int placed = 0, row = 0;
                while (placed < n)
                {
                    int k = Math.Min(perRow, n - placed);
                    double ww = bottom ? w0 + o + row * (dl + gap) : w1 - o - row * (dl + gap);
                    int dir = row == 0 ? (bottom ? 1 : -1) : 0;                  // seule la première file reçoit les crochets (les autres s'arrêtent)
                    if (k == 1) Bar(t, (a0 + a1) / 2, ww, dir);
                    else for (int i = 0; i < k; i++) Bar(t, a0 + (a1 - a0) * i / (k - 1), ww, dir);
                    placed += k; row++;
                }
            }
            Layer(botType, it.BotN, it.BotDia, true);
            if (it.TopN > 0) Layer(topType, it.TopN, it.TopDia > 0 ? it.TopDia : it.BotDia, false);
        }
        return count;
    }


    // ------------------------------------------------------------------ dalles
    internal static bool ParseBars(string? txt, out int dia, out double spCm)
    {
        dia = 0; spCm = 0;
        if (string.IsNullOrEmpty(txt)) return false;
        var m = System.Text.RegularExpressions.Regex.Match(txt, @"HA(\d+)\s*e\s*=\s*(\d+(?:[.,]\d+)?)");
        if (!m.Success) return false;
        dia = int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
        spCm = double.Parse(m.Groups[2].Value.Replace(',', '.'), CultureInfo.InvariantCulture);
        return dia > 0 && spCm > 0;
    }

    /// <summary>Dalle : nappe inférieure dans les deux sens sur toute l'emprise, chapeaux sur appuis (0,25 x portée depuis chaque rive) si le calcul en donne.</summary>
    /// <summary>Semelle isolée : deux nappes inférieures croisées (barres // A le long de X, barres // B le long de Y) avec l'enrobage de fond.</summary>
    /// <summary>Crée la semelle dans Revit : dalle de fondation rectangulaire (type à l'épaisseur voulue, dupliqué au besoin), dessus à la cote du calcul.
    /// Repérée par son commentaire pour être recréée (et non doublée) au prochain appel.</summary>
    private static Element? CreateFooting(Document doc, RevitSummaryItem it, out string err)
    {
        err = "";
        double h = it.H, ztop = it.ZTop;
        var level = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().OrderBy(l => l.Elevation).ToList();
        if (level.Count == 0) { err = "aucun niveau dans le projet"; return null; }
        double ztopFt = ztop / 0.3048;
        Level lv = level.LastOrDefault(l => l.Elevation <= ztopFt + 0.01) ?? level[0];

        var types = new FilteredElementCollector(doc).OfClass(typeof(FloorType)).Cast<FloorType>().ToList();
        long fid = (long)BuiltInCategory.OST_StructuralFoundation;
        FloorType? baseType = types.FirstOrDefault(t => t.Category != null && t.Category.Id.Value == fid) ?? types.FirstOrDefault();
        if (baseType == null) { err = "aucun type de dalle dans le projet"; return null; }

        string tn = $"StructCalc semelle {h * 100:0} cm";
        FloorType? ft = types.FirstOrDefault(t => t.Name == tn);
        if (ft == null)
        {
            ft = baseType.Duplicate(tn) as FloorType;
            if (ft == null) { err = "type de dalle non dupliquable"; return null; }
            var cs = ft.GetCompoundStructure();
            int core = Math.Max(0, cs.GetFirstCoreLayerIndex());
            cs.SetLayerWidth(core, h / 0.3048);
            ft.SetCompoundStructure(cs);
        }

        double x0 = it.X0 / 0.3048, y0 = it.Y0 / 0.3048, x1 = (it.X0 + it.B) / 0.3048, y1 = (it.Y0 + it.Length) / 0.3048, z = lv.Elevation;
        var loop = new CurveLoop();
        loop.Append(Line.CreateBound(new XYZ(x0, y0, z), new XYZ(x1, y0, z)));
        loop.Append(Line.CreateBound(new XYZ(x1, y0, z), new XYZ(x1, y1, z)));
        loop.Append(Line.CreateBound(new XYZ(x1, y1, z), new XYZ(x0, y1, z)));
        loop.Append(Line.CreateBound(new XYZ(x0, y1, z), new XYZ(x0, y0, z)));
        Floor fl = Floor.Create(doc, new List<CurveLoop> { loop }, ft.Id, lv.Id);
        fl.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)?.Set(ztopFt - lv.Elevation);
        fl.get_Parameter(BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL)?.Set(1);
        string name = it.Extra.TryGetValue("Nom", out var nm) ? nm : "S";
        fl.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(FootingTag + name);
        doc.Regenerate();
        return fl;
    }

    /// <summary>Crée une armature droite (barre le long de A -> B) sur un hôte, répartie sur arrayLen dans la direction de la normale du plan de la barre.</summary>
    internal static bool MakeBar(Document doc, Element host, RebarBarType t, XYZ a, XYZ b, XYZ norm, double arrayLen, double spCm, string? role = null)
    {
        if (a.DistanceTo(b) < 0.01) return false;
        var r = Rebar.CreateFromCurves(doc, RebarStyle.Standard, t, null, null, host, norm, new List<Curve> { Line.CreateBound(a, b) },
            RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
        if (r == null) return false;
        r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
        SetRole(r, role);
        LastRebar = r;
        double sp = spCm / 100.0 / 0.3048;
        if (arrayLen > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, arrayLen, true, true, true);
        return true;
    }

    /// <summary>Radier : nappes inférieure et supérieure dans les deux sens sur le rectangle du panneau (Inf_X, Inf_Y, Sup_X, Sup_Y).</summary>
    private static int ReinforceRaft(Document doc, Element host, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, out string err)
    {
        err = "";
        if (!it.HasRect) { err = "rectangle du radier inconnu (refaire l'export depuis Revit)"; return -1; }
        double x0 = it.X0 / 0.3048, x1 = (it.X0 + it.B) / 0.3048, y0 = it.Y0 / 0.3048, y1 = (it.Y0 + it.Length) / 0.3048;
        double zt = it.ZTop / 0.3048, zb0 = (it.ZTop - it.H) / 0.3048;
        double cv = (it.Cover > 0.005 ? it.Cover : 0.05) / 0.3048;
        string? E(string k) => it.Extra.TryGetValue(k, out var v) ? v : null;
        bool iX = ParseBars(E("Inf_X"), out int dIX, out double sIX), iY = ParseBars(E("Inf_Y"), out int dIY, out double sIY);
        bool sX = ParseBars(E("Sup_X"), out int dSX, out double sSX), sY = ParseBars(E("Sup_Y"), out int dSY, out double sSY);
        if (!iX && !iY && !sX && !sY) { err = "pas d'armatures de radier dans le calcul"; return -1; }
        RebarBarType? T(bool ok, int d) => ok ? BarTypeFor(doc, types, d) : null;
        var tIX = T(iX, dIX); var tIY = T(iY, dIY); var tSX = T(sX, dSX); var tSY = T(sY, dSY);
        if ((iX && tIX == null) || (iY && tIY == null) || (sX && tSX == null) || (sY && tSY == null)) { err = "type d'armature introuvable ou non créable"; return -1; }
        double lenX = x1 - x0 - 2 * cv, lenY = y1 - y0 - 2 * cv, zb = zb0 + cv;
        int count = 0;
        if (iX && MakeBar(doc, host, tIX!, new XYZ(x0 + cv, y0 + cv, zb + dIX * MM / 2), new XYZ(x1 - cv, y0 + cv, zb + dIX * MM / 2), XYZ.BasisY, lenY, sIX)) count++;
        if (iY && MakeBar(doc, host, tIY!, new XYZ(x0 + cv, y0 + cv, zb + (iX ? dIX * MM : 0) + dIY * MM / 2), new XYZ(x0 + cv, y1 - cv, zb + (iX ? dIX * MM : 0) + dIY * MM / 2), XYZ.BasisX, lenX, sIY)) count++;
        double zs = zt - cv;
        if (sX && MakeBar(doc, host, tSX!, new XYZ(x0 + cv, y0 + cv, zs - dSX * MM / 2), new XYZ(x1 - cv, y0 + cv, zs - dSX * MM / 2), XYZ.BasisY, lenY, sSX)) count++;
        if (sY && MakeBar(doc, host, tSY!, new XYZ(x0 + cv, y0 + cv, zs - (sX ? dSX * MM : 0) - dSY * MM / 2), new XYZ(x0 + cv, y1 - cv, zs - (sX ? dSX * MM : 0) - dSY * MM / 2), XYZ.BasisX, lenX, sSY)) count++;
        if (count == 0) { err = "aucune armature créée"; return -1; }
        return count;
    }

    /// <summary>Semelle filante : barres transversales (nappe // largeur, « Nappe_A ») réparties sur la longueur, barres de répartition longitudinales (« Nappe_B »).
    /// Le repère (direction de la semelle, largeur) est lu sur la géométrie réelle, quelle que soit son orientation.</summary>
    private static int ReinforceStrip(Document doc, Element host, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, out string err)
    {
        err = "";
        var pts = Vertices(host);
        if (pts.Count < 4) { err = "géométrie illisible"; return -1; }
        XYZ dir = XYZ.BasisX;
        if (host.Location is LocationCurve lc && lc.Curve is Line ln) { var d = ln.GetEndPoint(1) - ln.GetEndPoint(0); d = new XYZ(d.X, d.Y, 0); if (d.GetLength() > 1e-6) dir = d.Normalize(); }
        XYZ nrm = new XYZ(-dir.Y, dir.X, 0);
        double u0 = pts.Min(p => p.DotProduct(dir)), u1 = pts.Max(p => p.DotProduct(dir)), v0 = pts.Min(p => p.DotProduct(nrm)), v1 = pts.Max(p => p.DotProduct(nrm)), z0 = pts.Min(p => p.Z);
        double cv = (it.Cover > 0.005 ? it.Cover : 0.05) / 0.3048;
        bool okA = ParseBars(it.Extra.TryGetValue("Nappe_A", out var ta) ? ta : null, out int dA, out double sA);
        bool okB = ParseBars(it.Extra.TryGetValue("Nappe_B", out var tb) ? tb : null, out int dB, out double sB);
        if (!okA && !okB) { err = "pas d'armatures de semelle filante dans le calcul"; return -1; }
        var typeA = okA ? BarTypeFor(doc, types, dA) : null; var typeB = okB ? BarTypeFor(doc, types, dB) : null;
        if ((okA && typeA == null) || (okB && typeB == null)) { err = "type d'armature introuvable ou non créable"; return -1; }
        XYZ P(double u, double v, double z) => dir * u + nrm * v + XYZ.BasisZ * z;
        int count = 0;
        double zA = z0 + cv + (okA ? dA * MM / 2 : 0);
        if (okA && MakeBar(doc, host, typeA!, P(u0 + cv, v0 + cv, zA), P(u0 + cv, v1 - cv, zA), dir, (u1 - u0) - 2 * cv, sA)) count++;
        double zB = z0 + cv + (okA ? dA * MM : 0) + (okB ? dB * MM / 2 : 0);
        if (okB && MakeBar(doc, host, typeB!, P(u0 + cv, v0 + cv, zB), P(u1 - cv, v0 + cv, zB), nrm, (v1 - v0) - 2 * cv, sB)) count++;
        if (count == 0) { err = "aucune armature créée"; return -1; }
        return count;
    }

    /// <summary>Voile : barres verticales et horizontales sur chacune des deux faces (« Vert », « Horiz »), interrompues par les ouvertures : l'élévation du mur
    /// est découpée en rectangles pleins, chacun reçoit ses barres.</summary>
    private static int ReinforceWall(Document doc, Element host, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, out string err)
    {
        err = "";
        if (host is not Wall wl) { err = "l'élément n'est pas un mur"; return -1; }
        var g = WallGeo.Read(wl);
        if (g == null) { err = "mur courbe ou illisible (seuls les murs droits sont armés)"; return -1; }
        double cv = (it.Cover > 0.005 ? it.Cover : 0.03) / 0.3048;
        bool okV = ParseBars(it.Extra.TryGetValue("Vert", out var tv) ? tv : null, out int dV, out double sV);
        bool okH = ParseBars(it.Extra.TryGetValue("Horiz", out var th) ? th : null, out int dH, out double sH);
        if (!okV && !okH) { err = "pas d'armatures de voile dans le calcul"; return -1; }
        var typeV = okV ? BarTypeFor(doc, types, dV) : null; var typeH = okH ? BarTypeFor(doc, types, dH) : null;
        if ((okV && typeV == null) || (okH && typeH == null)) { err = "type d'armature introuvable ou non créable"; return -1; }
        var loops = new List<IList<(double X, double Y)>> { new List<(double X, double Y)> { (g.UMin, g.ZMin), (g.UMax, g.ZMin), (g.UMax, g.ZMax), (g.UMin, g.ZMax) } };
        foreach (var o in g.Openings) loops.Add(new List<(double X, double Y)> { (o.U0, o.Z0), (o.U1, o.Z0), (o.U1, o.Z1), (o.U0, o.Z1) });
        var rects = StructCalc.Engine.Geometry.RectDecomposer.Decompose(loops, 0.07, 0.5);
        if (rects.Count == 0) { err = "aucune zone pleine dans le mur"; return -1; }
        XYZ P(double u, double v, double z) => g.Dir * u + g.N * v + XYZ.BasisZ * z;
        double hH = okH ? dH * MM : 0, hV = okV ? dV * MM : 0;
        int count = 0;
        foreach (int side in new[] { -1, 1 })
        {
            // horizontales à l'extérieur, verticales à l'intérieur de chaque face
            double vh = side < 0 ? g.VMin + cv + hH / 2 : g.VMax - cv - hH / 2;
            double vv = side < 0 ? g.VMin + cv + hH + hV / 2 : g.VMax - cv - hH - hV / 2;
            foreach (var r in rects)
            {
                if (okH && MakeBar(doc, host, typeH!, P(r.X0 + cv, vh, r.Y0 + cv), P(r.X1 - cv, vh, r.Y0 + cv), XYZ.BasisZ, r.H - 2 * cv, sH)) count++;
                if (okV && MakeBar(doc, host, typeV!, P(r.X0 + cv, vv, r.Y0 + cv), P(r.X0 + cv, vv, r.Y1 - cv), g.Dir, r.W - 2 * cv, sV)) count++;
            }
        }
        if (count == 0) { err = "aucune armature créée"; return -1; }
        return count;
    }

    private static int ReinforceFooting(Document doc, Element fl, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, out string err)
    {
        err = "";
        var pts = Vertices(fl);
        if (pts.Count < 4) { err = "géométrie illisible"; return -1; }
        double x0 = pts.Min(p => p.X), x1 = pts.Max(p => p.X), y0 = pts.Min(p => p.Y), y1 = pts.Max(p => p.Y), z0 = pts.Min(p => p.Z);
        if (it.HasRect) { x0 = it.X0 / 0.3048; x1 = (it.X0 + it.B) / 0.3048; y0 = it.Y0 / 0.3048; y1 = (it.Y0 + it.Length) / 0.3048; z0 = (it.ZTop - it.H) / 0.3048; }
        double cv = (it.Cover > 0.005 ? it.Cover : 0.05) / 0.3048;
        bool okA = ParseBars(it.Extra.TryGetValue("Nappe_A", out var ta) ? ta : null, out int dA, out double sA);
        bool okB = ParseBars(it.Extra.TryGetValue("Nappe_B", out var tb) ? tb : null, out int dB, out double sB);
        if (!okA && !okB) { err = "pas d'armatures de semelle dans le calcul"; return -1; }
        var typeA = okA ? BarTypeFor(doc, types, dA) : null;
        var typeB = okB ? BarTypeFor(doc, types, dB) : null;
        if ((okA && typeA == null) || (okB && typeB == null)) { err = "type d'armature introuvable ou non créable"; return -1; }
        int count = 0;
        void Set(RebarBarType t, XYZ a, XYZ b, XYZ norm, double arrayLen, double spCm)
        {
            if (a.DistanceTo(b) < 0.01) return;
            var r = Rebar.CreateFromCurves(doc, RebarStyle.Standard, t, null, null, fl, norm, new List<Curve> { Line.CreateBound(a, b) },
                RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
            if (r == null) return;
            r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
            double sp = spCm / 100.0 / 0.3048;
            if (arrayLen > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, arrayLen, true, true, true);
            count++;
        }
        double lenX = x1 - x0 - 2 * cv, lenY = y1 - y0 - 2 * cv;
        // nappe la plus basse = celle dont les barres sont parallèles au grand côté de la semelle (bras de levier le plus grand pour le moment le plus fort)
        bool aLower = lenX >= lenY;
        bool okLow = aLower ? okA : okB, okUp = aLower ? okB : okA;
        double dLow = aLower ? dA : dB, dUp = aLower ? dB : dA;
        double zLow = z0 + cv + (okLow ? dLow * MM / 2 : 0), zUp = zLow + (okLow ? dLow * MM / 2 : 0) + (okUp ? dUp * MM / 2 : 0);
        double zA = aLower ? zLow : zUp, zB = aLower ? zUp : zLow;
        if (!okLow) { zUp = z0 + cv + (okUp ? dUp * MM / 2 : 0); zA = aLower ? zLow : zUp; zB = aLower ? zUp : zLow; }
        // nappe // A le long de X, nappe // B le long de Y
        if (okA) Set(typeA!, new XYZ(x0 + cv, y0 + cv, zA), new XYZ(x1 - cv, y0 + cv, zA), XYZ.BasisY, lenY, sA);
        if (okB) Set(typeB!, new XYZ(x0 + cv, y0 + cv, zB), new XYZ(x0 + cv, y1 - cv, zB), XYZ.BasisX, lenX, sB);
        if (count == 0) { err = "aucune armature créée"; return -1; }
        return count;
    }

    private static int ReinforceSlab(Document doc, Element fl, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, out string err)
    {
        err = "";
        var pts = Vertices(fl);
        if (pts.Count < 4) { err = "géométrie illisible"; return -1; }
        double x0 = pts.Min(p => p.X), x1 = pts.Max(p => p.X), y0 = pts.Min(p => p.Y), y1 = pts.Max(p => p.Y);
        double z0 = pts.Min(p => p.Z), z1 = pts.Max(p => p.Z);
        if (it.HasRect)      // panneau d'une dalle découpée (contour, trémies) : le rectangle du panneau, pas l'emprise de toute la dalle
        { x0 = it.X0 / 0.3048; x1 = (it.X0 + it.B) / 0.3048; y0 = it.Y0 / 0.3048; y1 = (it.Y0 + it.Length) / 0.3048; z1 = it.ZTop / 0.3048; z0 = (it.ZTop - it.H) / 0.3048; }
        double cv = (it.Cover > 0.005 ? it.Cover : 0.03) / 0.3048;                      // axe de la 1re nappe depuis la face (pieds)
        int count = 0;

        string? E(string k) => it.Extra.TryGetValue(k, out var ev) ? ev : null;
        bool tx = ParseBars(E("Travee_lx"), out int dTx, out double sTx);
        bool ty = ParseBars(E("Travee_ly"), out int dTy, out double sTy);
        bool ax = ParseBars(E("Appui_lx"), out int dAx, out double sAx);
        bool ay = ParseBars(E("Appui_ly"), out int dAy, out double sAy);
        if (!tx && !ty) { err = "pas d'armatures de travée dans le calcul"; return -1; }

        RebarBarType? TypeOf(int d) => BarTypeFor(doc, types, d);

        // barre droite le long de A->B ; réseau réparti le long de « array » (perpendiculaire) sur arrayLen
        void Set(RebarBarType t, XYZ a, XYZ b, XYZ norm, double arrayLen, double spCm)
        {
            if (a.DistanceTo(b) < 0.01) return;
            var r = Rebar.CreateFromCurves(doc, RebarStyle.Standard, t, null, null, fl, norm, new List<Curve> { Line.CreateBound(a, b) },
                RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
            if (r == null) return;
            r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
            double sp = spCm / 100.0 / 0.3048;
            if (arrayLen > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, arrayLen, true, true, true);
            count++;
        }

        double lenX = x1 - x0 - 2 * cv, lenY = y1 - y0 - 2 * cv;
        double zb = z0 + cv, zt = z1 - cv;
        var tTx = tx ? TypeOf(dTx) : null; var tTy = ty ? TypeOf(dTy) : null;
        if ((tx && tTx == null) || (ty && tTy == null)) { err = "type d'armature introuvable ou non créable"; return -1; }
        double gx = dTx * MM / 2, gy = dTy * MM / 2;
        // nappe inférieure : sens x (le plus bas), puis sens y au-dessus
        if (tx) Set(tTx!, new XYZ(x0 + cv, y0 + cv, zb), new XYZ(x1 - cv, y0 + cv, zb), XYZ.BasisY, lenY, sTx);
        if (ty) Set(tTy!, new XYZ(x0 + cv, y0 + cv, zb + gx + gy), new XYZ(x0 + cv, y1 - cv, zb + gx + gy), XYZ.BasisX, lenX, sTy);

        // chapeaux sur appuis : bandes de 0,25 x portée le long de chaque rive, nappe supérieure
        if (ax)
        {
            var t = TypeOf(dAx);
            if (t != null)
            {
                double band = 0.25 * (x1 - x0);
                Set(t, new XYZ(x0 + cv, y0 + cv, zt), new XYZ(x0 + band, y0 + cv, zt), XYZ.BasisY, lenY, sAx);
                Set(t, new XYZ(x1 - band, y0 + cv, zt), new XYZ(x1 - cv, y0 + cv, zt), XYZ.BasisY, lenY, sAx);
            }
        }
        if (ay)
        {
            var t = TypeOf(dAy);
            if (t != null)
            {
                double band = 0.25 * (y1 - y0), zt2 = zt - dAx * MM / 2 - dAy * MM / 2;
                Set(t, new XYZ(x0 + cv, y0 + cv, zt2), new XYZ(x0 + cv, y0 + band, zt2), XYZ.BasisX, lenX, sAy);
                Set(t, new XYZ(x0 + cv, y1 - band, zt2), new XYZ(x0 + cv, y1 - cv, zt2), XYZ.BasisX, lenX, sAy);
            }
        }
        return count;
    }

    // ------------------------------------------------------------------ escaliers : volées (face inférieure inclinée) et paliers (face inférieure horizontale)
    internal static void CollectFaces(GeometryElement ge, List<PlanarFace> res)
    {
        foreach (GeometryObject go in ge)
        {
            if (go is Solid sd && sd.Volume > 1e-9) { foreach (Face f in sd.Faces) if (f is PlanarFace pf) res.Add(pf); }
            else if (go is GeometryInstance gi) { try { CollectFaces(gi.GetInstanceGeometry(), res); } catch { } }
        }
    }

    /// <summary>Rôle de la barre (écrit dans « Repère ») : lu par la nomenclature et les étiquettes des plans d'exécution.</summary>
    internal static Rebar? LastRebar;                       // dernière barre créée par MakeBar/MakePoly (lue par les contrôles d'escalier)

    internal static void SetRole(Rebar r, string? role)
    {
        if (string.IsNullOrEmpty(role)) return;
        try { var p = r.get_Parameter(BuiltInParameter.ALL_MODEL_MARK); if (p != null && !p.IsReadOnly) p.Set(role); } catch { }
    }

    internal static bool MakePoly(Document doc, Element host, RebarBarType t, List<XYZ> pts, XYZ norm, double arrayLen, double spCm, string? role = null)
    {
        var curves = new List<Curve>();
        for (int i = 0; i + 1 < pts.Count; i++) if (pts[i].DistanceTo(pts[i + 1]) > 0.01) curves.Add(Line.CreateBound(pts[i], pts[i + 1]));
        if (curves.Count == 0) return false;
        var r = Rebar.CreateFromCurves(doc, RebarStyle.Standard, t, null, null, host, norm, curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);
        if (r == null) return false;
        r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(Tag);
        SetRole(r, role);
        LastRebar = r;
        double sp = spCm / 100.0 / 0.3048;
        if (arrayLen > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, arrayLen, true, true, true);
        return true;
    }

    /// <summary>Volée ou palier qui n'accepte pas d'armatures : on tente de lui affecter un matériau béton (instance puis type) avant de renoncer.</summary>
    internal static bool EnsureConcreteHost(Document doc, Element host, List<string> notes, string name)
    {
        bool Valid() { var h = RebarHostData.GetRebarHostData(host); return h != null && h.IsValidHost(); }
        if (Valid()) return true;
        try
        {
            var mat = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>()
                .FirstOrDefault(m => string.Equals(m.MaterialClass, "Concrete", StringComparison.OrdinalIgnoreCase) || string.Equals(m.MaterialClass, "Béton", StringComparison.OrdinalIgnoreCase)
                                     || m.Name.IndexOf("béton", StringComparison.OrdinalIgnoreCase) >= 0 || m.Name.IndexOf("beton", StringComparison.OrdinalIgnoreCase) >= 0
                                     || m.Name.IndexOf("concrete", StringComparison.OrdinalIgnoreCase) >= 0);
            if (mat == null)
            {
                // aucun matériau béton dans le projet (gabarit vide) : on en crée un, classe « Béton »
                try
                {
                    var id = Material.Create(doc, "StructCalc - Béton armé");
                    mat = doc.GetElement(id) as Material;
                    if (mat != null)
                    {
                        foreach (string cls in new[] { "Concrete", "Béton" }) { try { mat.MaterialClass = cls; if (!string.IsNullOrEmpty(mat.MaterialClass)) break; } catch { } }
                        notes.Add($"{name} : aucun matériau béton dans le projet, « {mat.Name} » créé");
                    }
                }
                catch { mat = null; }
            }
            if (mat != null)
            {
                foreach (Element target in new[] { host, doc.GetElement(host.GetTypeId()) })
                {
                    if (target == null) continue;
                    foreach (var p in new[] { target.get_Parameter(BuiltInParameter.STRUCTURAL_MATERIAL_PARAM), target.LookupParameter("Matériau structurel"), target.LookupParameter("Structural Material") })
                        if (p != null && !p.IsReadOnly && p.StorageType == StorageType.ElementId) { try { p.Set(mat.Id); } catch { } }
                    doc.Regenerate();
                    if (Valid()) { notes.Add($"{name} : matériau « {mat.Name} » affecté pour permettre l'armature"); return true; }
                }
            }
        }
        catch { }
        notes.Add($"{name} : n'accepte pas d'armatures (affectez un matériau structurel béton à la volée ou au palier)");
        return false;
    }

    /// <summary>Volée à sous-face à marches : plan de pose déduit de la pente du tracé et du point le plus bas.</summary>
    internal static bool SoffitFromPath(Autodesk.Revit.DB.Architecture.StairsRun run, out XYZ o, out XYZ nIn, out XYZ u, out List<XYZ> pts, out string why)
    {
        o = XYZ.Zero; nIn = XYZ.BasisZ; u = XYZ.BasisX; pts = new List<XYZ>(); why = "";
        var path = run.GetStairsPath().ToList();
        if (path.Count == 0) { why = "tracé illisible"; return false; }
        if (path.Any(c => c is Arc)) { why = "volée courbe (hélicoïdale ou balancée) : à armer à la main"; return false; }
        XYZ a = path[0].GetEndPoint(0), b = path[^1].GetEndPoint(1);
        var flat = new XYZ(b.X - a.X, b.Y - a.Y, 0);
        if (flat.GetLength() < 0.5) { why = "tracé trop court"; return false; }
        flat = flat.Normalize();
        if (b.Z < a.Z) flat = flat.Negate();                 // la pente monte toujours du départ vers l'arrivée
        var bb = run.get_BoundingBox(null);
        var verts = Vertices(run);
        if (bb == null || verts.Count < 4) { why = "géométrie illisible"; return false; }
        double rise = bb.Max.Z - bb.Min.Z, runLen = verts.Max(p => p.DotProduct(flat)) - verts.Min(p => p.DotProduct(flat));
        double slope = Math.Atan2(Math.Max(rise - 0.3, 0.1), Math.Max(runLen, 0.5));    // pente moyenne (la hauteur englobante compte l'épaisseur)
        // pente exacte du tracé quand elle est lisible (le tracé monte du départ à l'arrivée)
        if (Math.Abs(b.Z - a.Z) > 0.2) slope = Math.Atan2(Math.Abs(b.Z - a.Z), new XYZ(b.X - a.X, b.Y - a.Y, 0).GetLength());
        u = flat.Multiply(Math.Cos(slope)).Add(XYZ.BasisZ.Multiply(Math.Sin(slope))).Normalize();
        nIn = XYZ.BasisZ.Multiply(Math.Cos(slope)).Subtract(flat.Multiply(Math.Sin(slope))).Normalize();
        XYZ nLoc = nIn;
        o = verts.OrderBy(p => p.DotProduct(nLoc)).First();
        pts = verts;
        return true;
    }

    /// <summary>Plus grande face plane tournée vers le bas : inclinée pour une volée, horizontale pour un palier.</summary>
    internal static PlanarFace? Underside(Element e, bool inclined)
    {
        var ge = e.get_Geometry(new Options { DetailLevel = ViewDetailLevel.Fine, ComputeReferences = false });
        if (ge == null) return null;
        var faces = new List<PlanarFace>();
        CollectFaces(ge, faces);
        var cand = faces.Where(f => inclined ? (f.FaceNormal.Z < -0.2 && f.FaceNormal.Z > -0.97) : f.FaceNormal.Z < -0.97).OrderByDescending(f => f.Area).ToList();
        return cand.FirstOrDefault();
    }

    // ------------------------------------------------------------------ crochets : contrôle de l'orientation sur la géométrie réelle
    private static RebarHookOrientation Flip(RebarHookOrientation o) => o == RebarHookOrientation.Right ? RebarHookOrientation.Left : RebarHookOrientation.Right;

    private static IList<Curve>? CenterlineOf(Rebar r)
    {
        try { return r.GetCenterlineCurves(false, false, false, MultiplanarOption.IncludeOnlyPlanarCurves, 0); }
        catch { return null; }
    }

    /// <summary>Crée l'armature, lit sa géométrie réelle (Revit la régénère) et vérifie que les crochets partent du bon côté. Sinon, essaie les autres orientations
    /// (Right/Left inversés) et garde la première qui convient ; si aucune ne convient (ou si la géométrie est illisible), garde la création d'origine.</summary>
    private static Rebar? CreateWithHookCheck(Document doc, RebarStyle style, RebarBarType type, RebarHookType? hs, RebarHookType? he, Element host, XYZ norm,
        IList<Curve> curves, RebarHookOrientation os, RebarHookOrientation oe, Func<Rebar, bool> hooksOk)
    {
        Rebar? Make(RebarHookOrientation oa, RebarHookOrientation ob) => Rebar.CreateFromCurves(doc, style, type, hs, he, host, norm, curves, oa, ob, true, true);
        var first = Make(os, oe);
        if (first == null || (hs == null && he == null)) return first;
        try { doc.Regenerate(); if (hooksOk(first)) return first; }
        catch { return first; }
        foreach (var (a, b) in new[] { (Flip(os), Flip(oe)), (os, Flip(oe)), (Flip(os), oe) })
        {
            Rebar? r = null;
            try
            {
                r = Make(a, b);
                if (r == null) continue;
                doc.Regenerate();
                if (hooksOk(r)) { doc.Delete(first.Id); return r; }
                doc.Delete(r.Id);
            }
            catch
            {
                if (r != null) { try { doc.Delete(r.Id); } catch { } }
            }
        }
        return first;
    }

    // ------------------------------------------------------------------ types d'armature et de crochet
    private static double DiaMm(RebarBarType t)
    {
        double d = t.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER)?.AsDouble() ?? 0;
        return d / MM;
    }

    internal static RebarBarType? BarTypeFor(Document doc, Dictionary<int, RebarBarType?> cache, int dia)
    {
        if (cache.TryGetValue(dia, out var c)) return c;
        var all = new FilteredElementCollector(doc).OfClass(typeof(RebarBarType)).Cast<RebarBarType>().ToList();
        RebarBarType? found = all.FirstOrDefault(t => Math.Abs(DiaMm(t) - dia) < 0.5);
        if (found == null)
        {
            // pas de type de ce diamètre : copie d'un type existant, sinon création par l'API (si la version de Revit la propose)
            try
            {
                if (all.Count > 0) found = (RebarBarType)all[0].Duplicate("HA" + dia);
                else
                {
                    MethodInfo? m = typeof(RebarBarType).GetMethod("Create", BindingFlags.Public | BindingFlags.Static, null, new[] { typeof(Document) }, null);
                    found = m?.Invoke(null, new object[] { doc }) as RebarBarType;
                    if (found != null) found.Name = "HA" + dia;
                }
                if (found != null)
                {
                    double d = dia * MM;
                    found.get_Parameter(BuiltInParameter.REBAR_BAR_DIAMETER)?.Set(d);
                    foreach (string prop in new[] { "BarModelDiameter", "BarNominalDiameter" }) SetProp(found, prop, d);
                    foreach (string prop in new[] { "StandardBendDiameter", "StandardHookBendDiameter", "StirrupTieBendDiameter" }) SetProp(found, prop, 4 * d);
                }
            }
            catch { found = null; }
        }
        cache[dia] = found;
        return found;
    }

    private static void SetProp(object o, string name, double val)
    {
        try { o.GetType().GetProperty(name)?.SetValue(o, val); } catch { }
    }

    internal static RebarHookType? GetHook(Document doc, double angleDeg, string nameHint)
    {
        var hooks = new FilteredElementCollector(doc).OfClass(typeof(RebarHookType)).Cast<RebarHookType>().ToList();
        var h = hooks.FirstOrDefault(x => x.Name.Contains(nameHint));
        if (h != null) return h;
        try
        {
            MethodInfo? m = typeof(RebarHookType).GetMethod("Create", BindingFlags.Public | BindingFlags.Static, null, new[] { typeof(Document), typeof(double), typeof(double) }, null);
            var created = m?.Invoke(null, new object[] { doc, angleDeg * Math.PI / 180.0, angleDeg > 100 ? 6.0 : 12.0 }) as RebarHookType;
            if (created != null) created.Name = "StructCalc " + nameHint;
            return created;
        }
        catch { return null; }
    }
}
