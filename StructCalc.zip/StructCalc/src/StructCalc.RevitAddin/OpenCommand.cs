using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace StructCalc.RevitAddin;

[Transaction(TransactionMode.ReadOnly)]
public class OpenCommand : IExternalCommand
{
    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        TaskDialog.Show("StructCalc", AppLauncher.Launch(null));
        return Result.Succeeded;
    }
}
