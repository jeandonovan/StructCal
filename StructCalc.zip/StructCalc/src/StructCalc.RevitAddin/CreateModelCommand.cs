using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Crée dans Revit les poteaux, poutres et dalles béton du modèle déposé par StructCalc (« Envoyer le modèle à Revit »).
/// Niveaux : repris s'ils existent (à 5 mm près), créés sinon. Sections : un type « SC b x h » dupliqué d'une famille béton du projet.
/// Un élément déjà lié (ExternalId présent et retrouvé dans le projet) n'est jamais recréé. Voiles et radiers sont créés ; escaliers, semelles, planchers nervurés,
/// barres acier et poteaux inclinés ne le sont pas (comptés et signalés). Tout est annulable d'un seul Ctrl+Z.</summary>
[Transaction(TransactionMode.Manual)]
public class CreateModelCommand : IExternalCommand
{
    private static double Ft(double m) => UnitUtils.ConvertToInternalUnits(m, UnitTypeId.Meters);
    private static double M(double ft) => UnitUtils.ConvertFromInternalUnits(ft, UnitTypeId.Meters);
    private static string Cm(double m) => (m * 100).ToString("0.#", CultureInfo.InvariantCulture);
    private const double LevelTol = 0.005;                  // 5 mm

    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            Document doc = data.Application.ActiveUIDocument.Document;
            if (!File.Exists(RevitLink.ModelToRevit))
            {
                TaskDialog.Show("StructCalc", "Aucun modèle déposé par StructCalc.\nDans StructCalc : Fichier > « Envoyer le modèle à Revit pour y créer poteaux, poutres et dalles ».");
                return Result.Cancelled;
            }
            StructModel model = ModelIO.Load(RevitLink.ModelToRevit);
            var nodes = model.Nodes.ToDictionary(n => n.Id);
            var notes = new List<string>();

            var concrete = model.Members.Where(m => m.Kind == MaterialKind.ReinforcedConcrete && nodes.ContainsKey(m.NodeI) && nodes.ContainsKey(m.NodeJ)).ToList();
            int steel = model.Members.Count(m => m.Kind != MaterialKind.ReinforcedConcrete);
            var slabs = model.Slabs.Where(s => s.Placed && s.Lx > 0.1 && s.Ly > 0.1 && s.H > 0.01).ToList();
            var walls = model.Walls.Where(w => w.LengthM > 0.1 && w.HeightM > 0.1 && w.ThicknessM > 0.01).ToList();
            var rafts = model.Rafts.Where(r => r.Panels.Count > 0 && r.H > 0.01).ToList();
            var cols = concrete.Where(m => m.Type == MemberType.Column).ToList();
            var beams = concrete.Where(m => m.Type == MemberType.Beam).ToList();

            // familles de base : on les choisit AVANT toute modification et on refuse proprement si le projet n'en a pas
            FamilySymbol? colBase = cols.Count > 0 ? PickSymbol(doc, BuiltInCategory.OST_StructuralColumns) : null;
            FamilySymbol? beamBase = beams.Count > 0 ? PickSymbol(doc, BuiltInCategory.OST_StructuralFraming) : null;
            FloorType? floorBase = slabs.Count + rafts.Count > 0 ? PickFloorType(doc) : null;
            WallType? wallBase = walls.Count > 0 ? PickWallType(doc) : null;
            var missing = new List<string>();
            if (cols.Count > 0 && colBase == null) missing.Add("famille de poteau béton rectangulaire avec paramètres b et h (Insérer > Charger une famille > Éléments porteurs > Béton)");
            if (beams.Count > 0 && beamBase == null) missing.Add("famille de poutre béton rectangulaire avec paramètres b et h");
            if (walls.Count > 0 && wallBase == null) missing.Add("type de mur à structure composée dans le projet");
            if (slabs.Count + rafts.Count > 0 && floorBase == null) missing.Add("type de dalle (plancher) dans le projet");
            if (missing.Count > 0)
            {
                TaskDialog.Show("StructCalc", "Rien n'a été créé. Il manque dans le projet Revit :\n- " + string.Join("\n- ", missing));
                return Result.Failed;
            }

            var td = new TaskDialog("StructCalc - Créer le modèle") { MainInstruction = "Créer ces éléments dans Revit ?" };
            td.MainContent =
                $"{cols.Count} poteau(x), {beams.Count} poutre(s), {slabs.Count} dalle(s), {walls.Count} voile(s), {rafts.Count} radier(s).\n" +
                (colBase != null ? $"Poteaux : famille « {colBase.FamilyName} ».\n" : "") +
                (beamBase != null ? $"Poutres : famille « {beamBase.FamilyName} ».\n" : "") +
                (floorBase != null ? $"Dalles : type « {floorBase.Name} » (copié à chaque épaisseur).\n" : "") +
                $"\nNon créés : {steel} barre(s) acier, {model.Stairs.Count} escalier(s), {model.FootingDefs.Count} semelle(s) (créées par « Créer armatures » à partir des réactions), {model.RibbedFloors.Count} plancher(s) nervuré(s).\n" +
                "Annulable avec Ctrl+Z.";
            td.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No;
            if (td.Show() != TaskDialogResult.Yes) return Result.Cancelled;

            var ids = new CreatedIdsFile();
            int nCol = 0, nBeam = 0, nSlab = 0, nWall = 0, nRaft = 0, nSkip = 0, nLevels = 0;
            using (var tg = new TransactionGroup(doc, "StructCalc - créer le modèle"))
            {
                tg.Start();
                using (var tx = new Transaction(doc, "StructCalc - niveaux et types"))
                {
                    tx.Start();
                    // niveaux nécessaires : cotes des extrémités des barres et du dessus des dalles
                    var zs = new SortedSet<double>();
                    foreach (var m in concrete) { zs.Add(Math.Round(nodes[m.NodeI].Z, 3)); zs.Add(Math.Round(nodes[m.NodeJ].Z, 3)); }
                    foreach (var s in slabs) zs.Add(Math.Round(s.Z, 3));
                    foreach (var w in walls) zs.Add(Math.Round(w.Z, 3));
                    foreach (var r in rafts) zs.Add(Math.Round(r.ZTop, 3));
                    levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().ToList();
                    foreach (double z in zs)
                    {
                        if (FindLevel(z) != null) continue;
                        try
                        {
                            var lv = Level.Create(doc, Ft(z));
                            string nm = model.Levels.FirstOrDefault(l => Math.Abs(l.Elevation - z) < 0.01)?.Name ?? $"SC Niveau {z.ToString("0.###", CultureInfo.InvariantCulture)} m";
                            try { lv.Name = nm; } catch { /* nom déjà pris : nom automatique de Revit conservé */ }
                            levels.Add(lv); nLevels++;
                        }
                        catch (Exception ex) { notes.Add($"niveau à {z:0.###} m non créé : {ex.Message}"); }
                    }
                    tx.Commit();
                }

                using (var tx = new Transaction(doc, "StructCalc - poteaux, poutres, dalles"))
                {
                    tx.Start();
                    var symCache = new Dictionary<string, FamilySymbol>();
                    foreach (var m in cols)
                    {
                        if (Linked(doc, m.ExternalId)) { nSkip++; continue; }
                        Node a = nodes[m.NodeI], b = nodes[m.NodeJ];
                        Node lo = a.Z <= b.Z ? a : b, hi = a.Z <= b.Z ? b : a;
                        Level? l0 = FindLevel(lo.Z), l1 = FindLevel(hi.Z);
                        if (hi.Z - lo.Z < 0.05 || Math.Abs(a.X - b.X) > 0.01 || Math.Abs(a.Y - b.Y) > 0.01) { notes.Add($"barre {m.Id} : poteau non vertical, non créé."); continue; }
                        if (l0 == null || l1 == null) { notes.Add($"barre {m.Id} : niveau introuvable, non créé."); continue; }
                        try
                        {
                            FamilySymbol sym = Sized(doc, colBase!, m.B, m.H, symCache);
                            var fi = doc.Create.NewFamilyInstance(new XYZ(Ft(lo.X), Ft(lo.Y), Ft(lo.Z)), sym, l0, StructuralType.Column);
                            fi.get_Parameter(BuiltInParameter.FAMILY_BASE_LEVEL_PARAM)?.Set(l0.Id);
                            fi.get_Parameter(BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)?.Set(l1.Id);
                            fi.get_Parameter(BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM)?.Set(0.0);
                            fi.get_Parameter(BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM)?.Set(0.0);
                            ids.Items.Add(new CreatedId { Kind = "Member", Key = m.Id.ToString(), ExternalId = fi.Id.Value.ToString() });
                            nCol++;
                        }
                        catch (Exception ex) { notes.Add($"barre {m.Id} (poteau) : {ex.Message}"); }
                    }
                    foreach (var m in beams)
                    {
                        if (Linked(doc, m.ExternalId)) { nSkip++; continue; }
                        Node a = nodes[m.NodeI], b = nodes[m.NodeJ];
                        XYZ p0 = new(Ft(a.X), Ft(a.Y), Ft(a.Z)), p1 = new(Ft(b.X), Ft(b.Y), Ft(b.Z));
                        if (p0.DistanceTo(p1) < 0.01) { notes.Add($"barre {m.Id} : longueur nulle, non créée."); continue; }
                        Level? lv = FindLevel(Math.Min(a.Z, b.Z));
                        if (lv == null) { notes.Add($"barre {m.Id} : niveau introuvable, non créée."); continue; }
                        try
                        {
                            FamilySymbol sym = Sized(doc, beamBase!, m.B, m.H, symCache);
                            var fi = doc.Create.NewFamilyInstance(Line.CreateBound(p0, p1), sym, lv, StructuralType.Beam);
                            // l'axe de la barre dans StructCalc est le centre de la section : la poutre est référencée sur son axe
                            fi.get_Parameter(BuiltInParameter.Z_JUSTIFICATION)?.Set((int)ZJustification.Center);
                            ids.Items.Add(new CreatedId { Kind = "Member", Key = m.Id.ToString(), ExternalId = fi.Id.Value.ToString() });
                            nBeam++;
                        }
                        catch (Exception ex) { notes.Add($"barre {m.Id} (poutre) : {ex.Message}"); }
                    }
                    var ftCache = new Dictionary<string, FloorType>();
                    var wtCache = new Dictionary<string, WallType>();
                    foreach (var s in slabs)
                    {
                        if (Linked(doc, s.ExternalId)) { nSkip++; continue; }
                        Level? lv = levels.Where(l => M(l.Elevation) <= s.Z + LevelTol).OrderByDescending(l => l.Elevation).FirstOrDefault();
                        if (lv == null) { notes.Add($"dalle {s.Name} : niveau introuvable, non créée."); continue; }
                        try
                        {
                            FloorType ft = SizedFloor(doc, floorBase!, s.H, ftCache);
                            double z = lv.Elevation, x0 = Ft(s.X0), y0 = Ft(s.Y0), x1 = Ft(s.X0 + s.Lx), y1 = Ft(s.Y0 + s.Ly);
                            var loop = new CurveLoop();
                            loop.Append(Line.CreateBound(new XYZ(x0, y0, z), new XYZ(x1, y0, z)));
                            loop.Append(Line.CreateBound(new XYZ(x1, y0, z), new XYZ(x1, y1, z)));
                            loop.Append(Line.CreateBound(new XYZ(x1, y1, z), new XYZ(x0, y1, z)));
                            loop.Append(Line.CreateBound(new XYZ(x0, y1, z), new XYZ(x0, y0, z)));
                            Floor fl = Floor.Create(doc, new List<CurveLoop> { loop }, ft.Id, lv.Id);
                            fl.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)?.Set(Ft(s.Z) - z);     // dessus de la dalle à la cote de StructCalc
                            fl.get_Parameter(BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL)?.Set(1);
                            ids.Items.Add(new CreatedId { Kind = "Slab", Key = s.Name, ExternalId = fl.Id.Value.ToString() });
                            nSlab++;
                        }
                        catch (Exception ex) { notes.Add($"dalle {s.Name} : {ex.Message}"); }
                    }
                    foreach (var w in walls)
                    {
                        if (Linked(doc, w.ExternalId)) { nSkip++; continue; }
                        Level? lv = FindLevel(w.Z);
                        if (lv == null) { notes.Add($"voile {w.Name} : niveau introuvable, non créé."); continue; }
                        try
                        {
                            double ang = w.AngleDeg * Math.PI / 180.0;
                            XYZ p0 = new(Ft(w.X), Ft(w.Y), lv.Elevation), p1 = new(Ft(w.X + w.LengthM * Math.Cos(ang)), Ft(w.Y + w.LengthM * Math.Sin(ang)), lv.Elevation);
                            WallType wt = SizedWall(doc, wallBase!, w.ThicknessM, wtCache);
                            var wl = Wall.Create(doc, Line.CreateBound(p0, p1), wt.Id, lv.Id, Ft(w.HeightM), 0.0, false, true);
                            wl.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM)?.Set((int)WallLocationLine.WallCenterline);
                            ids.Items.Add(new CreatedId { Kind = "Wall", Key = w.Name, ExternalId = wl.Id.Value.ToString() });
                            if (w.Openings.Count > 0) notes.Add($"voile {w.Name} : {w.Openings.Count} ouverture(s) non créée(s).");
                            nWall++;
                        }
                        catch (Exception ex) { notes.Add($"voile {w.Name} : {ex.Message}"); }
                    }
                    foreach (var r in rafts)
                    {
                        if (Linked(doc, r.ExternalId)) { nSkip++; continue; }
                        Level? lv = levels.Where(l => M(l.Elevation) <= r.ZTop + LevelTol).OrderByDescending(l => l.Elevation).FirstOrDefault();
                        if (lv == null) { notes.Add($"radier {r.Name} : niveau introuvable, non créé."); continue; }
                        try
                        {
                            FloorType ft = SizedFloor(doc, floorBase!, r.H, ftCache);
                            string first = "";
                            foreach (var pn in r.Panels)
                            {
                                double z = lv.Elevation, x0 = Ft(pn.X0), y0 = Ft(pn.Y0), x1 = Ft(pn.X0 + pn.Lx), y1 = Ft(pn.Y0 + pn.Ly);
                                var loop = new CurveLoop();
                                loop.Append(Line.CreateBound(new XYZ(x0, y0, z), new XYZ(x1, y0, z)));
                                loop.Append(Line.CreateBound(new XYZ(x1, y0, z), new XYZ(x1, y1, z)));
                                loop.Append(Line.CreateBound(new XYZ(x1, y1, z), new XYZ(x0, y1, z)));
                                loop.Append(Line.CreateBound(new XYZ(x0, y1, z), new XYZ(x0, y0, z)));
                                Floor fl = Floor.Create(doc, new List<CurveLoop> { loop }, ft.Id, lv.Id);
                                fl.get_Parameter(BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)?.Set(Ft(r.ZTop) - z);
                                fl.get_Parameter(BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL)?.Set(1);
                                if (first == "") first = fl.Id.Value.ToString();
                            }
                            ids.Items.Add(new CreatedId { Kind = "Raft", Key = r.Name, ExternalId = first });
                            if (r.Panels.Count > 1) notes.Add($"radier {r.Name} : {r.Panels.Count} panneaux créés comme {r.Panels.Count} dalles séparées ; seul le premier est lié.");
                            nRaft++;
                        }
                        catch (Exception ex) { notes.Add($"radier {r.Name} : {ex.Message}"); }
                    }
                    tx.Commit();
                }
                if (nCol + nBeam + nSlab + nWall + nRaft + nLevels > 0) tg.Assimilate(); else tg.RollBack();
            }

            ids.Notes.AddRange(notes);
            CreatedIdsFile.Save(ids, RevitLink.CreatedIds);
            string rep = $"Créés : {nCol} poteau(x), {nBeam} poutre(s), {nSlab} dalle(s), {nWall} voile(s), {nRaft} radier(s), {nLevels} niveau(x). Déjà liés (ignorés) : {nSkip}.";
            if (notes.Count > 0) rep += "\n\nNon créés / remarques :\n- " + string.Join("\n- ", notes.Take(12)) + (notes.Count > 12 ? $"\n... (+{notes.Count - 12})" : "");
            rep += "\n\nDans StructCalc : Fichier > « Reprendre les identifiants des éléments créés dans Revit ».";
            TaskDialog.Show("StructCalc", rep);
            return Result.Succeeded;
        }
        catch (Exception ex) { message = ex.Message; return Result.Failed; }
    }

    private List<Level> levels = new();
    private Level? FindLevel(double zM) => levels.FirstOrDefault(l => Math.Abs(M(l.Elevation) - zM) <= LevelTol);

    private static bool Linked(Document doc, string externalId) =>
        long.TryParse(externalId, out long id) && doc.GetElement(new ElementId(id)) != null;

    private static Parameter? FindParam(Element e, params string[] names)
    {
        foreach (var n in names)
        {
            Parameter? p = e.LookupParameter(n);
            if (p != null && p.StorageType == StorageType.Double && !p.IsReadOnly) return p;
        }
        return null;
    }

    /// <summary>Premier type d'une famille béton de la catégorie qui expose b et h modifiables (les familles « béton rectangulaire » d'Autodesk). Null si aucune.</summary>
    private static FamilySymbol? PickSymbol(Document doc, BuiltInCategory cat)
    {
        var all = new FilteredElementCollector(doc).OfCategory(cat).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>()
            .Where(s => FindParam(s, "b", "B", "Width", "Largeur") != null && FindParam(s, "h", "H", "Height", "Hauteur") != null).ToList();
        var concrete = all.Where(s => Regex.IsMatch(s.FamilyName + " " + s.Name, @"concrete|béton|beton|rectangular|rectangulaire", RegexOptions.IgnoreCase)
                                   && !Regex.IsMatch(s.FamilyName, @"steel|acier|metal|métal|W-|HEA|IPE", RegexOptions.IgnoreCase)).ToList();
        return concrete.FirstOrDefault();
    }

    private static FloorType? PickFloorType(Document doc)
    {
        var types = new FilteredElementCollector(doc).OfClass(typeof(FloorType)).Cast<FloorType>().ToList();
        long fid = (long)BuiltInCategory.OST_StructuralFoundation;
        return types.FirstOrDefault(t => t.Category != null && t.Category.Id.Value != fid && t.GetCompoundStructure() != null) ?? types.FirstOrDefault(t => t.GetCompoundStructure() != null);
    }

    /// <summary>Type « SC b x h » de la famille de base (créé une fois, réutilisé ensuite).</summary>
    private static FamilySymbol Sized(Document doc, FamilySymbol baseSym, double b, double h, Dictionary<string, FamilySymbol> cache)
    {
        string name = $"SC {Cm(b)}x{Cm(h)}";
        string key = baseSym.Family.Id.Value + "|" + name;
        if (cache.TryGetValue(key, out var c)) return c;
        FamilySymbol? sym = new FilteredElementCollector(doc).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>()
            .FirstOrDefault(s => s.Family.Id == baseSym.Family.Id && s.Name == name);
        if (sym == null)
        {
            sym = baseSym.Duplicate(name) as FamilySymbol ?? throw new InvalidOperationException($"type {name} non dupliquable");
            Parameter pb = FindParam(baseSym, "b", "B", "Width", "Largeur")!, ph = FindParam(baseSym, "h", "H", "Height", "Hauteur")!;
            FindParam(sym, pb.Definition.Name)?.Set(Ft(b));
            FindParam(sym, ph.Definition.Name)?.Set(Ft(h));
        }
        if (!sym.IsActive) { sym.Activate(); doc.Regenerate(); }
        cache[key] = sym;
        return sym;
    }

    /// <summary>Type de dalle de l'épaisseur voulue : copie du type de base dont la couche structurelle est ajustée.</summary>
    private static FloorType SizedFloor(Document doc, FloorType baseType, double h, Dictionary<string, FloorType> cache)
    {
        string name = $"SC dalle {Cm(h)} cm";
        if (cache.TryGetValue(name, out var c)) return c;
        FloorType? ft = new FilteredElementCollector(doc).OfClass(typeof(FloorType)).Cast<FloorType>().FirstOrDefault(t => t.Name == name);
        if (ft == null)
        {
            ft = baseType.Duplicate(name) as FloorType ?? throw new InvalidOperationException($"type de dalle {name} non dupliquable");
            var cs = ft.GetCompoundStructure();
            int layer = cs.LayerCount == 1 ? 0 : cs.StructuralMaterialIndex;
            if (layer < 0 || layer >= cs.LayerCount) layer = Math.Max(0, cs.GetFirstCoreLayerIndex());
            // les autres couches (revêtements) sont conservées : l'épaisseur totale = h + revêtements ; la couche structurelle vaut h
            cs.SetLayerWidth(layer, Ft(h));
            ft.SetCompoundStructure(cs);
        }
        cache[name] = ft;
        return ft;
    }

    private static WallType? PickWallType(Document doc) =>
        new FilteredElementCollector(doc).OfClass(typeof(WallType)).Cast<WallType>()
            .FirstOrDefault(t => t.Kind == WallKind.Basic && t.GetCompoundStructure() != null);

    /// <summary>Type de mur de l'épaisseur voulue : copie du type de base dont la couche structurelle est ajustée.</summary>
    private static WallType SizedWall(Document doc, WallType baseType, double t, Dictionary<string, WallType> cache)
    {
        string name = $"SC voile {Cm(t)} cm";
        if (cache.TryGetValue(name, out var c)) return c;
        WallType? wt = new FilteredElementCollector(doc).OfClass(typeof(WallType)).Cast<WallType>().FirstOrDefault(x => x.Name == name);
        if (wt == null)
        {
            wt = baseType.Duplicate(name) as WallType ?? throw new InvalidOperationException($"type de mur {name} non dupliquable");
            var cs = wt.GetCompoundStructure();
            int layer = cs.LayerCount == 1 ? 0 : cs.StructuralMaterialIndex;
            if (layer < 0 || layer >= cs.LayerCount) layer = Math.Max(0, cs.GetFirstCoreLayerIndex());
            cs.SetLayerWidth(layer, Ft(t));
            wt.SetCompoundStructure(cs);
        }
        cache[name] = wt;
        return wt;
    }
}
