using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;

namespace StructCalc.RevitAddin;

/// <summary>Reprend dans Revit les planches d'exécution de StructCalc (ferraillage, coffrage...) : une vue de dessin par planche
/// (lignes de détail, cercles, textes, 1:1 = millimètres de papier), puis une feuille Revit qui la reçoit.</summary>
[Transaction(TransactionMode.Manual)]
public class ImportPlansCommand : IExternalCommand
{
    private const double MM = 1.0 / 304.8;   // millimètre en pieds (unité interne Revit)

    private static Color AciColor(string layer)
    {
        int aci = Layers.ColorOf(layer);
        return aci switch
        {
            1 => new Color(220, 30, 30), 2 => new Color(200, 160, 0), 3 => new Color(20, 150, 60), 4 => new Color(0, 150, 170),
            5 => new Color(30, 60, 220), 6 => new Color(180, 40, 170), 8 => new Color(128, 128, 128), 9 => new Color(170, 170, 170),
            30 => new Color(230, 120, 0), _ => new Color(0, 0, 0)
        };
    }

    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            Document doc = data.Application.ActiveUIDocument.Document;
            if (!File.Exists(RevitLink.PlansToRevit))
            {
                TaskDialog.Show("StructCalc", "Aucun plan reçu. Dans StructCalc : calculez le modèle (F5), puis cliquez sur « 🔗 Revit ».");
                return Result.Cancelled;
            }
            var sheets = SheetExchange.Load(RevitLink.PlansToRevit);
            if (sheets.Count == 0) { TaskDialog.Show("StructCalc", "Le fichier de plans est vide."); return Result.Cancelled; }

            ViewFamilyType? vft = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>()
                .FirstOrDefault(v => v.ViewFamily == ViewFamily.Drafting);
            if (vft == null) { TaskDialog.Show("StructCalc", "Aucun type de vue de dessin dans ce projet."); return Result.Failed; }

            int nViews = 0, nSheets = 0, nEnt = 0, nFail = 0;
            using (var tx = new Transaction(doc, "StructCalc - plans d'exécution"))
            {
                tx.Start();
                var styles = new Dictionary<string, GraphicsStyle?>();
                var textTypes = new Dictionary<int, ElementId>();
                Category linesCat = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines);
                TextNoteType? baseText = new FilteredElementCollector(doc).OfClass(typeof(TextNoteType)).Cast<TextNoteType>().FirstOrDefault();

                GraphicsStyle? StyleOf(string layer)
                {
                    if (styles.TryGetValue(layer, out var gs)) return gs;
                    GraphicsStyle? res = null;
                    try
                    {
                        string name = "SC_" + layer;
                        Category? sub = linesCat.SubCategories.Cast<Category>().FirstOrDefault(c => c.Name == name);
                        if (sub == null)
                        {
                            sub = doc.Settings.Categories.NewSubcategory(linesCat, name);
                            sub.LineColor = AciColor(layer);
                            sub.SetLineWeight(layer is "CONTOUR" or "BETON" or "CARTOUCHE" ? 3 : layer is "ARMATURES" or "ARMATURES2" or "ARMATURES_HAUTES" or "CADRES" ? 2 : 1, GraphicsStyleType.Projection);
                        }
                        res = sub.GetGraphicsStyle(GraphicsStyleType.Projection);
                    }
                    catch { res = null; }
                    styles[layer] = res;
                    return res;
                }

                ElementId TextTypeFor(double hMm)
                {
                    int key = (int)Math.Round(Math.Max(hMm, 2.0) * 10);   // pas de 0,1 mm, mini 2 mm
                    if (textTypes.TryGetValue(key, out var id)) return id;
                    ElementId result = baseText!.Id;
                    try
                    {
                        var t = (TextNoteType)baseText.Duplicate("SC_texte_" + (key / 10.0).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + "mm");
                        t.get_Parameter(BuiltInParameter.TEXT_SIZE)?.Set(key / 10.0 * MM);
                        result = t.Id;
                    }
                    catch
                    {
                        // le type existe déjà (import précédent) : on le retrouve par son nom
                        string nm = "SC_texte_" + (key / 10.0).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + "mm";
                        var ex = new FilteredElementCollector(doc).OfClass(typeof(TextNoteType)).Cast<TextNoteType>().FirstOrDefault(x => x.Name == nm);
                        if (ex != null) result = ex.Id;
                    }
                    textTypes[key] = result;
                    return result;
                }

                foreach (var sh in sheets)
                {
                    string baseName = "SC - " + (string.IsNullOrWhiteSpace(sh.Number) ? sh.Name : sh.Number + " " + sh.Title).Trim();
                    baseName = baseName.Replace(":", "-").Replace("{", "(").Replace("}", ")").Replace("[", "(").Replace("]", ")").Replace("|", "-");

                    // remplacement d'une importation précédente (même nom)
                    foreach (var old in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>().Where(v => v.Name == baseName && !v.IsTemplate).ToList())
                    { try { doc.Delete(old.Id); } catch { } }

                    ViewDrafting view = ViewDrafting.Create(doc, vft.Id);
                    view.Name = baseName;
                    try { view.Scale = 1; } catch { }

                    foreach (var e in sh.Items)
                    {
                        try
                        {
                            if (e.K == "L")
                            {
                                var p1 = new XYZ(e.X1 * MM, e.Y1 * MM, 0); var p2 = new XYZ(e.X2 * MM, e.Y2 * MM, 0);
                                if (p1.DistanceTo(p2) < 1.0 * MM) continue;   // plus court que la tolérance de Revit
                                var dc = doc.Create.NewDetailCurve(view, Line.CreateBound(p1, p2));
                                var gs = StyleOf(e.L); if (gs != null) dc.LineStyle = gs;
                                nEnt++;
                            }
                            else if (e.K == "C")
                            {
                                var c = new XYZ(e.X1 * MM, e.Y1 * MM, 0);
                                var gs = StyleOf(e.L);
                                var radii = e.Fill ? new[] { 1.0, 0.7, 0.4 } : new[] { 1.0 };
                                foreach (double f in radii)
                                {
                                    double r = Math.Max(e.R * f, 0.8) * MM;
                                    foreach (var (a0, a1) in new[] { (0.0, Math.PI), (Math.PI, 2 * Math.PI) })
                                    {
                                        var dc = doc.Create.NewDetailCurve(view, Arc.Create(c, r, a0, a1, XYZ.BasisX, XYZ.BasisY));
                                        if (gs != null) dc.LineStyle = gs;
                                    }
                                }
                                nEnt++;
                            }
                            else if (e.K == "T" && !string.IsNullOrWhiteSpace(e.T))
                            {
                                // DXF : point d'insertion = bas gauche du texte ; Revit : haut gauche
                                double th = Math.Max(e.H, 2.0), rad = e.Rot * Math.PI / 180.0;
                                var pos = new XYZ((e.X1 - Math.Sin(rad) * th) * MM, (e.Y1 + Math.Cos(rad) * th) * MM, 0);
                                var opt = new TextNoteOptions(TextTypeFor(e.H)) { HorizontalAlignment = HorizontalTextAlignment.Left, Rotation = rad };
                                TextNote.Create(doc, view.Id, pos, e.T, opt);
                                nEnt++;
                            }
                        }
                        catch { nFail++; }
                    }
                    nViews++;

                    // feuille Revit sans cartouche portant la vue
                    try
                    {
                        string num = "SC-" + (string.IsNullOrWhiteSpace(sh.Number) ? sh.Name : sh.Number);
                        foreach (var os in new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Where(v => v.SheetNumber == num).ToList())
                        { try { doc.Delete(os.Id); } catch { } }
                        ViewSheet vs = ViewSheet.Create(doc, ElementId.InvalidElementId);
                        vs.SheetNumber = num;
                        vs.Name = (sh.Title ?? "").Length > 0 ? sh.Title! : sh.Name;
                        Viewport.Create(doc, vs.Id, view.Id, new XYZ(sh.Width / 2 * MM, sh.Height / 2 * MM, 0));
                        nSheets++;
                    }
                    catch { /* la vue reste utilisable sans feuille */ }
                }
                tx.Commit();
            }
            TaskDialog.Show("StructCalc",
                $"{nViews} vue(s) de dessin créée(s) ({nEnt} éléments), {nSheets} feuille(s) Revit." +
                (nFail > 0 ? $"\n{nFail} élément(s) non reproduits (trop petits ou illisibles)." : "") +
                "\n\nVues : Navigateur de projet > Vues de dessin, préfixe « SC - ». Feuilles : préfixe « SC- ».");
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }
}
