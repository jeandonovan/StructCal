using System.Globalization;
using System.IO;
using System.Text;
using Autodesk.Revit.DB;

namespace StructCalc.RevitAddin;

/// <summary>Ancrage ou recouvrement d'une barre : exigence, disponible, statut.</summary>
internal sealed class AnchorRow
{
    public string Kind = "", Element = "", Role = "", Position = "", Status = "", Comment = "";
    public long RebarId;
    public int Dia;
    public double Fe, Fsd, Tau, ReqMm, AvailMm;
}

/// <summary>Cintrage d'une barre : angle, rayon réel/minimal, longueurs droites, poussée au vide, statut.</summary>
internal sealed class BendRow
{
    public string Element = "", Role = "", BendType = "", Direction = "", Risk = "", Status = "", Comment = "";
    public long RebarId;
    public int Dia;
    public double AngleDeg, RReal, RMin, StrBefore, StrAfter, StrMin, CoverMm;
}

/// <summary>Tableaux de contrôle des escaliers : ancrages, recouvrements, cintrages, avertissements. Écrits en HTML et CSV, repris dans les plans et la nomenclature.</summary>
internal sealed class StairCheckSet
{
    public List<AnchorRow> Anchors = new(), Laps = new();
    public List<BendRow> Bends = new();
    public List<string> Warnings = new();

    private const double Ft = 304.8;                            // pieds -> mm

    public static string Verdict(double avail, double req) => StructCalc.Engine.RebarChecks.Verdict(avail, req);

    /// <summary>Longueur d'ancrage de scellement droit (BAEL A.6.1,22) : ls = phi.fe / (4 tau_su), tau_su = 0,6 psi_s² ft28, psi_s = 1,5 (HA).</summary>
    public static (double Ls, double Tau, double Fsd) Anchorage(int dia, double fe, double fc) => StructCalc.Engine.RebarChecks.Anchorage(dia, fe, fc);

    public AnchorRow AddAnchor(bool lap, string element, string role, long id, int dia, double fe, double fc, double availMm, string position, string comment = "")
    {
        var (ls, tau, fsd) = Anchorage(dia, fe, fc);
        // recouvrement : lr = ls (barres au même niveau, espacement <= 5 phi) ; l'équerre n'est pas comptée (sécuritaire)
        var row = new AnchorRow { Kind = lap ? "Recouvrement" : "Ancrage", Element = element, Role = role, RebarId = id, Dia = dia, Fe = fe, Fsd = fsd, Tau = tau, ReqMm = ls, AvailMm = availMm, Position = position, Comment = comment };
        row.Status = Verdict(availMm, ls);
        (lap ? Laps : Anchors).Add(row);
        return row;
    }

    /// <summary>Contrôle chaque pli d'une barre polyligne. poly en pieds ; nearFaceOut : direction de la face de béton la plus proche de la barre (vers l'extérieur).</summary>
    public void AddBends(string element, string role, long id, int dia, IList<XYZ> poly, XYZ nearFaceOut, double bendDiaFtOfType, double coverMm, double coverMinMm, bool tension, bool hasTransverse, bool closedLoop = false)
    {
        if (poly.Count < 3) return;
        var pts = poly.Select(p => (p.X * Ft, p.Y * Ft, p.Z * Ft)).ToList();
        foreach (var r in StructCalc.Engine.RebarChecks.Bends(dia, pts, (nearFaceOut.X, nearFaceOut.Y, nearFaceOut.Z), bendDiaFtOfType * Ft, coverMm, coverMinMm, tension, hasTransverse, closedLoop))
            Bends.Add(new BendRow
            {
                Element = element, Role = role, RebarId = id, Dia = dia, BendType = r.BendType, AngleDeg = r.AngleDeg, RReal = r.RReal, RMin = r.RMin,
                StrBefore = r.StrBefore, StrAfter = r.StrAfter, StrMin = r.StrMin, CoverMm = coverMm, Direction = r.Direction, Risk = r.Risk, Status = r.Status, Comment = r.Comment
            });
    }

    public int NonCompliant => Anchors.Count(a => a.Status != "Vérifiée") + Laps.Count(a => a.Status != "Vérifiée") + Bends.Count(b => b.Status == "Non conforme");

    private static string F(double v, string f = "0") => v.ToString(f, CultureInfo.InvariantCulture);

    /// <summary>Écrit controle_escaliers.html / .csv / drapeaux pour les étiquettes des plans. Retourne le dossier.</summary>
    public string Write()
    {
        string dir = System.IO.Path.Combine(StructCalc.Engine.RevitLink.Dir, "controle");
        Directory.CreateDirectory(dir);
        var csv = new StringBuilder();
        csv.AppendLine("ANCRAGES;Élément;Rôle;Repère Revit;Ø (mm);Nuance fe (MPa);Contrainte de calcul fsd (MPa);Adhérence tau_su (MPa);Ancrage requis (mm);Disponible (mm);Statut;Position;Commentaire");
        foreach (var a in Anchors) csv.AppendLine($"A;{a.Element};{a.Role};{a.RebarId};{a.Dia};{F(a.Fe)};{F(a.Fsd)};{F(a.Tau, "0.00")};{F(a.ReqMm)};{F(a.AvailMm)};{a.Status};{a.Position};{a.Comment}");
        csv.AppendLine("RECOUVREMENTS;Élément;Rôle;Repère Revit;Ø (mm);Nuance fe (MPa);Contrainte de calcul fsd (MPa);Adhérence tau_su (MPa);Recouvrement requis (mm);Disponible (mm);Statut;Position;Commentaire");
        foreach (var a in Laps) csv.AppendLine($"R;{a.Element};{a.Role};{a.RebarId};{a.Dia};{F(a.Fe)};{F(a.Fsd)};{F(a.Tau, "0.00")};{F(a.ReqMm)};{F(a.AvailMm)};{a.Status};{a.Position};{a.Comment}");
        csv.AppendLine("CINTRAGES;Élément;Rôle;Repère Revit;Ø (mm);Type;Angle (°);Rayon réel (mm);Rayon mini (mm);Droit avant (mm);Droit après (mm);Droit mini (mm);Enrobage au pli (mm);Sens de traction;Poussée au vide;Statut;Commentaire");
        foreach (var b in Bends) csv.AppendLine($"C;{b.Element};{b.Role};{b.RebarId};{b.Dia};{b.BendType};{F(b.AngleDeg)};{F(b.RReal)};{F(b.RMin)};{F(b.StrBefore)};{F(b.StrAfter)};{F(b.StrMin)};{F(b.CoverMm)};{b.Direction};{b.Risk};{b.Status};{b.Comment}");
        File.WriteAllText(Path.Combine(dir, "controle_escaliers.csv"), csv.ToString(), new UTF8Encoding(true));

        // drapeaux repris par les plans d'exécution : « identifiant ; statut » pour chaque barre non conforme
        var flags = new Dictionary<long, string>();
        foreach (var a in Anchors.Concat(Laps).Where(x => x.Status != "Vérifiée")) flags[a.RebarId] = a.Kind + " " + a.Status.ToLowerInvariant();
        foreach (var b in Bends.Where(x => x.Status == "Non conforme")) flags[b.RebarId] = "cintrage non conforme";
        File.WriteAllLines(Path.Combine(dir, "drapeaux.txt"), flags.Select(kv => kv.Key.ToString(CultureInfo.InvariantCulture) + ";" + kv.Value));
        var sum = new List<string> { $"Contrôle des escaliers : {Anchors.Count} ancrage(s), {Laps.Count} recouvrement(s), {Bends.Count} cintrage(s) ; {NonCompliant} point(s) à traiter." };
        foreach (var a in Anchors.Concat(Laps).Where(x => x.Status != "Vérifiée").Take(12)) sum.Add($"  {a.Element} - {a.Role} HA{a.Dia} : {a.Kind.ToLowerInvariant()} {a.Status.ToLowerInvariant()} (requis {a.ReqMm:0} mm, disponible {a.AvailMm:0} mm)");
        sum.AddRange(Warnings.Take(10).Select(w => "  " + w));
        File.WriteAllLines(Path.Combine(dir, "resume.txt"), sum);

        var h = new StringBuilder();
        string Cls(string st) => st is "Vérifiée" or "Conforme" ? "ok" : st is "À la limite" or "À vérifier" ? "lim" : "ko";
        h.AppendLine("<!doctype html><html lang='fr'><head><meta charset='utf-8'><title>StructCalc - contrôle des escaliers</title><style>body{font-family:Segoe UI,Arial;margin:24px}table{border-collapse:collapse;margin:8px 0 24px;font-size:12px}th,td{border:1px solid #999;padding:3px 6px}th{background:#e8eef6}.ok{background:#dff3df}.lim{background:#fff1c9}.ko{background:#f9d6d6}</style></head><body>");
        h.AppendLine($"<h1>Contrôle des escaliers</h1><p>{HtmlEncode(sum[0])}</p>");
        if (Warnings.Count > 0) { h.AppendLine("<h2>Avertissements</h2><ul>"); foreach (var w in Warnings) h.AppendLine("<li>" + HtmlEncode(w) + "</li>"); h.AppendLine("</ul>"); }
        h.AppendLine("<h2>Ancrages barre par barre</h2><table><tr><th>Élément</th><th>Rôle</th><th>Repère</th><th>Ø</th><th>fe</th><th>fsd</th><th>τsu</th><th>Requis (mm)</th><th>Disponible (mm)</th><th>Statut</th><th>Position</th><th>Commentaire</th></tr>");
        foreach (var a in Anchors) h.AppendLine($"<tr><td>{HtmlEncode(a.Element)}</td><td>{HtmlEncode(a.Role)}</td><td>{a.RebarId}</td><td>HA{a.Dia}</td><td>{F(a.Fe)}</td><td>{F(a.Fsd)}</td><td>{F(a.Tau, "0.00")}</td><td>{F(a.ReqMm)}</td><td>{F(a.AvailMm)}</td><td class='{Cls(a.Status)}'>{a.Status}</td><td>{HtmlEncode(a.Position)}</td><td>{HtmlEncode(a.Comment)}</td></tr>");
        h.AppendLine("</table><h2>Recouvrements barre par barre</h2><table><tr><th>Élément</th><th>Rôle</th><th>Repère</th><th>Ø</th><th>fe</th><th>fsd</th><th>τsu</th><th>Requis (mm)</th><th>Disponible (mm)</th><th>Statut</th><th>Position / zone</th><th>Commentaire</th></tr>");
        foreach (var a in Laps) h.AppendLine($"<tr><td>{HtmlEncode(a.Element)}</td><td>{HtmlEncode(a.Role)}</td><td>{a.RebarId}</td><td>HA{a.Dia}</td><td>{F(a.Fe)}</td><td>{F(a.Fsd)}</td><td>{F(a.Tau, "0.00")}</td><td>{F(a.ReqMm)}</td><td>{F(a.AvailMm)}</td><td class='{Cls(a.Status)}'>{a.Status}</td><td>{HtmlEncode(a.Position)}</td><td>{HtmlEncode(a.Comment)}</td></tr>");
        h.AppendLine("</table><h2>Contrôle des cintrages</h2><table><tr><th>Élément</th><th>Rôle</th><th>Repère</th><th>Ø</th><th>Type</th><th>Angle</th><th>Rayon réel</th><th>Rayon mini</th><th>Droit avant</th><th>Droit après</th><th>Droit mini</th><th>Enrobage</th><th>Traction</th><th>Poussée au vide</th><th>Statut</th><th>Commentaire</th></tr>");
        foreach (var b in Bends) h.AppendLine($"<tr><td>{HtmlEncode(b.Element)}</td><td>{HtmlEncode(b.Role)}</td><td>{b.RebarId}</td><td>HA{b.Dia}</td><td>{HtmlEncode(b.BendType)}</td><td>{F(b.AngleDeg)}°</td><td>{F(b.RReal)}</td><td>{F(b.RMin)}</td><td>{F(b.StrBefore)}</td><td>{F(b.StrAfter)}</td><td>{F(b.StrMin)}</td><td>{F(b.CoverMm)}</td><td>{HtmlEncode(b.Direction)}</td><td>{HtmlEncode(b.Risk)}</td><td class='{Cls(b.Status)}'>{b.Status}</td><td>{HtmlEncode(b.Comment)}</td></tr>");
        h.AppendLine("</table><p>Méthode : ancrage ls = Ø·fe / (4·τsu), τsu = 0,6·ψs²·ft28 (ψs = 1,5), recouvrement lr = ls ; mandrin mini 4Ø (Ø ≤ 16) ou 7Ø ; longueur droite mini 5Ø après un pli ≥ 45° ; équerres non comptées dans l'ancrage (sécuritaire). Longueurs en mm. Contrôle à confirmer sur plan d'exécution.</p></body></html>");
        File.WriteAllText(Path.Combine(dir, "controle_escaliers.html"), h.ToString(), new UTF8Encoding(true));
        return dir;
    }

    internal static readonly string[] ParamNames =
    {
        "SC_Escalier", "SC_Ancrage_statut", "SC_Ancrage_requis_mm", "SC_Ancrage_disponible_mm",
        "SC_Cintrage_rayon_reel_mm", "SC_Cintrage_rayon_mini_mm", "SC_Cintrage_droit_reel_mm", "SC_Cintrage_droit_mini_mm", "SC_Cintrage_statut", "SC_Cintrage_commentaire"
    };

    /// <summary>Crée les paramètres partagés « SC_... » sur les armatures et y écrit le contrôle de chaque barre : la nomenclature Revit peut alors les afficher en colonnes.</summary>
    public string ApplyToRevit(Document doc, Autodesk.Revit.ApplicationServices.Application app)
    {
        string oldFile = app.SharedParametersFilename;
        try
        {
            string path = Path.Combine(StructCalc.Engine.RevitLink.Dir, "StructCalc_params.txt");
            if (!File.Exists(path))
                File.WriteAllText(path, "# This is a Revit shared parameter file.\r\n# Do not edit manually.\r\n*META\tVERSION\tMINVERSION\r\nMETA\t2\t1\r\n*GROUP\tID\tNAME\r\nGROUP\t1\tStructCalc\r\n" +
                                       "*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE\r\n", new UTF8Encoding(false));
            app.SharedParametersFilename = path;
            var file = app.OpenSharedParameterFile();
            if (file == null) return "fichier de paramètres partagés illisible";
            var grp = file.Groups.get_Item("StructCalc") ?? file.Groups.Create("StructCalc");
            var cat = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Rebar);
            foreach (string name in ParamNames)
            {
                Definition def = grp.Definitions.get_Item(name) ?? grp.Definitions.Create(new ExternalDefinitionCreationOptions(name, SpecTypeId.String.Text));
                if (!doc.ParameterBindings.Contains(def))
                {
                    var cs = app.Create.NewCategorySet(); cs.Insert(cat);
                    doc.ParameterBindings.Insert(def, app.Create.NewInstanceBinding(cs), GroupTypeId.Data);
                }
            }
            var vals = new Dictionary<long, Dictionary<string, string>>();
            Dictionary<string, string> Of(long id) { if (!vals.TryGetValue(id, out var d)) vals[id] = d = new Dictionary<string, string> { ["SC_Escalier"] = "1" }; return d; }
            foreach (var g in Anchors.Concat(Laps).Where(x => x.RebarId > 0).GroupBy(x => x.RebarId))
            {
                var w = g.OrderBy(x => x.AvailMm / Math.Max(x.ReqMm, 1)).First();                  // la plus défavorable
                var d = Of(g.Key);
                d["SC_Ancrage_statut"] = w.Kind + " : " + w.Status; d["SC_Ancrage_requis_mm"] = F(w.ReqMm); d["SC_Ancrage_disponible_mm"] = F(w.AvailMm);
            }
            int Rank(string st) => st == "Non conforme" ? 2 : st == "À vérifier" ? 1 : 0;
            foreach (var g in Bends.Where(x => x.RebarId > 0).GroupBy(x => x.RebarId))
            {
                var w = g.OrderByDescending(x => Rank(x.Status)).ThenBy(x => Math.Min(x.StrBefore, x.StrAfter)).First();
                var d = Of(g.Key);
                d["SC_Cintrage_rayon_reel_mm"] = F(w.RReal); d["SC_Cintrage_rayon_mini_mm"] = F(w.RMin);
                d["SC_Cintrage_droit_reel_mm"] = F(Math.Min(w.StrBefore, w.StrAfter)); d["SC_Cintrage_droit_mini_mm"] = F(w.StrMin);
                d["SC_Cintrage_statut"] = w.Status; d["SC_Cintrage_commentaire"] = string.Join(" | ", g.Where(x => x.Comment != "").Select(x => x.BendType + " : " + x.Comment).Distinct().Take(3));
            }
            int n = 0;
            foreach (var kv in vals)
            {
                if (doc.GetElement(new ElementId(kv.Key)) is not Element el) continue;
                foreach (var pv in kv.Value) { try { var pr = el.LookupParameter(pv.Key); if (pr != null && !pr.IsReadOnly) pr.Set(pv.Value); } catch { } }
                n++;
            }
            return n + " barre(s) renseignée(s) pour la nomenclature";
        }
        catch (Exception ex) { return "paramètres de contrôle non écrits : " + ex.Message; }
        finally { try { app.SharedParametersFilename = oldFile; } catch { } }
    }

    private static string HtmlEncode(string s) => s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
}
