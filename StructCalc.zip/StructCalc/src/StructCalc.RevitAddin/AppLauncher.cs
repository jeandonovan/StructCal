using System.IO;
using System.Diagnostics;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Ouvre StructCalc depuis Revit : si le logiciel est déjà ouvert il reçoit le modèle par le dossier d'échange (il propose de l'ouvrir),
/// sinon il est lancé avec le fichier en argument.</summary>
public static class AppLauncher
{
    /// <summary>Retourne un message décrivant ce qui s'est passé.</summary>
    public static string SendModel(string modelPath)
    {
        if (RevitLink.AppRunning()) return "StructCalc est déjà ouvert : il vous propose d'ouvrir le modèle reçu.";
        return Launch(modelPath);
    }

    public static string Launch(string? modelPath)
    {
        string? exe = RevitLink.FindApp();
        if (exe == null)
            return "StructCalc.App.exe est introuvable : lancez StructCalc une fois à la main (il mémorise alors son emplacement), puis recommencez. Le modèle est enregistré : " + modelPath;
        try
        {
            var psi = new ProcessStartInfo(exe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(exe)! };
            if (!string.IsNullOrEmpty(modelPath)) psi.ArgumentList.Add(modelPath);
            Process.Start(psi);
            return "StructCalc est lancé avec le modèle.";
        }
        catch (Exception ex) { return "Impossible de lancer StructCalc : " + ex.Message; }
    }
}
