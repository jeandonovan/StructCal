using System.Globalization;
using System.Text.RegularExpressions;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;

namespace StructCalc.RevitAddin;

/// <summary>Plans d'exécution Revit : pour chaque poutre, poteau et dalle (ou radier) armé par StructCalc, crée de vraies vues (coupes, plans) où les fers et le béton restent des éléments
/// Revit cliquables, pose des étiquettes d'armatures SANS chevauchement (empilées en colonne à droite, avec repères vers les fers) puis range les vues sur des feuilles avec cartouche,
/// par type d'ouvrage et par niveau. Les vues et feuilles « SC » d'un précédent passage sont remplacées.</summary>
[Transaction(TransactionMode.Manual)]
public class ExecutionPlansCommand : IExternalCommand
{
    private const double Mm = 1.0 / 304.8;                 // 1 mm en pieds
    private const string Prefix = "SC - ";                 // préfixe des vues créées
    private const string SheetPrefix = "SC-";              // préfixe des feuilles créées
    private static readonly int[] Scales = { 10, 20, 25, 50, 100, 200 };

    // ------------------------------------------------------------------ structures de travail
    private sealed class Frame
    {
        public XYZ O = XYZ.Zero, R = XYZ.BasisX, U = XYZ.BasisY;
        public XYZ W(double x, double y) => O + R.Multiply(x) + U.Multiply(y);
        public double X(XYZ p) => (p - O).DotProduct(R);
        public double Y(XYZ p) => (p - O).DotProduct(U);
    }

    private sealed class RInfo
    {
        public Rebar R = null!;
        public XYZ Center = XYZ.Zero;
        public List<Curve> Curves = new();
        public bool Long;                                  // barre parallèle à l'axe de l'ouvrage
        public bool AlongX;                                // dalle : barre dirigée suivant X
        public string Text = "";
        public double Zc;
        public double ZMin, ZMax, AMin, AMax;              // étendue en Z et le long de l'axe (stations)
        public string Role = "";                           // rôle écrit par StructCalc (Épingle, Étrier fermé, Couture...)
        public int No;                                     // numéro de position du fer
        public double Kg;                                  // poids d'acier de ce fer (toutes barres du jeu)
    }

    private sealed class Job
    {
        public View View = null!;
        public Frame F = new();
        public double X0, X1, Y0, Y1;                      // cadre de la vue, repère local, en pieds
        public int Scale;
        public string Group = "", Level = "", Title = "";
        public double WPaper, HPaper;                      // taille sur la feuille, en pieds
        public bool Fit = true;
    }

    private sealed class Host
    {
        public Element E = null!;
        public string Kind = "";                           // Beam / Column / Slab / Footing / Strip / Wall
        public double Kg, Vol;                             // acier (kg), béton (m³)
        public string Label = "";
        public Level Lv = null!;
        public List<RInfo> Bars = new();
    }

    private sealed class Counters { public int Views, Sheets, Overlaps, NoFit, Hosts, Skipped; public List<string> Notes = new(); public List<ElementId> SheetIds = new(); public string Extra = ""; }

    // ------------------------------------------------------------------ commande
    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            UIDocument uidoc = data.Application.ActiveUIDocument;
            Document doc = uidoc.Document;

            var hosts = CollectHosts(doc, out int nOther);
            int nB = hosts.Count(h => h.Kind == "Beam"), nC = hosts.Count(h => h.Kind == "Column"), nS = hosts.Count(h => h.Kind == "Slab" || h.Kind == "Stair");
            int nF = hosts.Count(h => h.Kind == "Footing" || h.Kind == "Strip"), nW = hosts.Count(h => h.Kind == "Wall");
            if (hosts.Count == 0)
            {
                TaskDialog.Show("StructCalc", "Aucun ouvrage armé par StructCalc trouvé dans ce projet.\nFaites d'abord « Créer armatures » (poutres, poteaux, dalles)." +
                                (nOther > 0 ? $"\n({nOther} autre(s) ouvrage(s) armé(s) de types non pris en charge.)" : ""));
                return Result.Cancelled;
            }
            var tbs = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_TitleBlocks).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>()
                .Select(s => (s.Id.Value, s.FamilyName + " : " + s.Name)).OrderBy(t => t.Item2).ToList();
            var opt = PlansDialog.Ask(tbs, nB, nC, nS, nF, nW);
            if (opt == null) return Result.Cancelled;
            hosts = hosts.Where(h => (h.Kind == "Beam" && opt.Beams) || (h.Kind == "Column" && opt.Columns) || ((h.Kind == "Slab" || h.Kind == "Stair") && opt.Slabs) ||
                                          ((h.Kind == "Footing" || h.Kind == "Strip") && opt.Footings) || (h.Kind == "Wall" && opt.Walls)).ToList();
            if (hosts.Count == 0) return Result.Cancelled;

            var cnt = new Counters();
            LoadFlags();
            using (var tx = new Transaction(doc, "StructCalc - plans d'exécution"))
            {
                tx.Start();
                var keptViews = ClearPrevious(doc, uidoc.ActiveView?.Id);
                _allHosts = hosts;
                int nKept = hosts.RemoveAll(h => keptViews.Any(n => n.StartsWith(Prefix + h.Label + " - ")));
                if (nKept > 0) cnt.Extra = $"{nKept} ouvrage(s) conservé(s) tel(s) quel(s) (vues marquées « [fige] »).";
                if (hosts.Count == 0) { tx.Commit(); TaskDialog.Show("StructCalc", cnt.Extra != "" ? cnt.Extra : "Rien à générer."); return Result.Succeeded; }
                ElementId tbId = opt.TitleBlockId > 0 ? new ElementId(opt.TitleBlockId) : ElementId.InvalidElementId;
                var (sheetW, sheetH) = SheetSize(doc, tbId);
                double availW = sheetW - (opt.LeftMm + opt.RightMm) * Mm, availH = sheetH - (opt.TopMm + opt.BottomMm) * Mm;

                ElementId textType = doc.GetDefaultElementTypeId(ElementTypeGroup.TextNoteType);
                double textSize = 2.5 * Mm;
                if (doc.GetElement(textType) is Element tt) { var ps = tt.get_Parameter(BuiltInParameter.TEXT_SIZE); if (ps != null && ps.AsDouble() > 0) textSize = ps.AsDouble(); }

                var sectionType = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault(v => v.ViewFamily == ViewFamily.Section);
                var planType = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault(v => v.ViewFamily == ViewFamily.StructuralPlan)
                               ?? new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault(v => v.ViewFamily == ViewFamily.FloorPlan);
                if (sectionType == null || planType == null) { tx.RollBack(); TaskDialog.Show("StructCalc", "Types de vue « Coupe » ou « Plan » introuvables dans le projet."); return Result.Failed; }

                var jobs = new List<Job>();
                var baseViews = new Dictionary<long, ViewPlan>();          // plan de base par niveau (existant, sinon créé puis supprimé)
                var createdBase = new List<ElementId>();
                foreach (var h in hosts)
                {
                    var sub = new SubTransaction(doc);
                    sub.Start();
                    try
                    {
                        var made = h.Kind switch
                        {
                            "Beam" => BuildBeam(doc, h, sectionType.Id, textType, textSize, availW, availH, opt),
                            "Column" => BuildColumn(doc, h, sectionType.Id, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt),
                            "Footing" => BuildFooting(doc, h, sectionType.Id, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt),
                            "Strip" => BuildStrip(doc, h, sectionType.Id, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt),
                            "Wall" => BuildWall(doc, h, sectionType.Id, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt),
                            "Stair" => BuildStair(doc, h, sectionType.Id, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt),
                            _ => BuildSlab(doc, h, planType.Id, baseViews, createdBase, textType, textSize, availW, availH, opt)
                        };
                        sub.Commit();
                        jobs.AddRange(made);
                        cnt.Hosts++;
                    }
                    catch (Exception ex) { try { sub.RollBack(); } catch { } cnt.Skipped++; cnt.Notes.Add($"{h.Label} : {ex.Message}"); }
                }
                foreach (var id in createdBase) { try { doc.Delete(id); } catch { } }

                // bilan des chevauchements et mise sur feuilles
                foreach (var j in jobs) cnt.Overlaps += CountOverlaps(doc, j);
                cnt.Views = jobs.Count;
                PlaceOnSheets(doc, jobs, tbId, opt, sheetW, sheetH, cnt);
                if (opt.Schedule) { try { BuildNomenclature(doc, hosts, tbId, textType, textSize, opt, sheetW, sheetH, cnt); } catch (Exception ex) { cnt.Notes.Add("Nomenclature : " + ex.Message); } }
                tx.Commit();
            }
            ExportSheets(doc, opt, cnt);

            string msg = $"{cnt.Hosts} ouvrage(s) traité(s) : {cnt.Views} vue(s) créée(s), {cnt.Sheets} feuille(s).";
            msg += cnt.Overlaps == 0 ? "\nAucun chevauchement de textes dans les vues." : $"\n{cnt.Overlaps} chevauchement(s) de textes restant(s) : à déplacer à la main.";
            if (cnt.NoFit > 0) msg += $"\n{cnt.NoFit} vue(s) plus grande(s) que la zone libre de la feuille : réduisez les marges ou changez de cartouche.";
            if (cnt.Notes.Count > 0) msg += $"\n\nÀ signaler ({cnt.Skipped} ouvrage(s) non traité(s)) :\n- " + string.Join("\n- ", cnt.Notes.Take(8)) + (cnt.Notes.Count > 8 ? "\n..." : "");
            if (cnt.Extra != "") msg += "\n\n" + cnt.Extra;
            if (nOther > 0) msg += $"\n\n{nOther} autre(s) ouvrage(s) armé(s) de types non pris en charge (ignorés).";
            TaskDialog.Show("StructCalc", msg);
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }

    // ------------------------------------------------------------------ ouvrages armés par StructCalc
    private static List<Host> CollectHosts(Document doc, out int other)
    {
        other = 0;
        var byHost = new Dictionary<long, Host>();
        var levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().OrderBy(l => l.Elevation).ToList();
        foreach (Rebar r in new FilteredElementCollector(doc).OfClass(typeof(Rebar)).Cast<Rebar>())
        {
            if (r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() != ReinforceCommand.Tag) continue;
            ElementId hid = r.GetHostId();
            if (hid == ElementId.InvalidElementId) continue;
            if (!byHost.TryGetValue(hid.Value, out var h))
            {
                Element? e = doc.GetElement(hid);
                if (e == null) continue;
                string kind = "";
                if (e is FamilyInstance fi && fi.Category != null)
                {
                    long cat = fi.Category.Id.Value;
                    if (cat == (long)BuiltInCategory.OST_StructuralColumns) kind = "Column";
                    else if (cat == (long)BuiltInCategory.OST_StructuralFraming) kind = "Beam";
                    else if (cat == (long)BuiltInCategory.OST_StructuralFoundation) kind = "Footing";
                }
                else if (e is Floor) kind = "Slab";
                else if (e is Autodesk.Revit.DB.Architecture.StairsRun || e is Autodesk.Revit.DB.Architecture.StairsLanding) kind = "Stair";
                else if (e is WallFoundation) kind = "Strip";
                else if (e is Wall) kind = "Wall";
                if (kind == "") { byHost[hid.Value] = new Host { E = e, Kind = "" }; continue; }
                BoundingBoxXYZ? bb = e.get_BoundingBox(null);
                if (bb == null) continue;
                double zRef = (kind == "Column" || kind == "Wall") ? bb.Min.Z : (bb.Min.Z + bb.Max.Z) / 2;
                Level lv = levels.LastOrDefault(l => l.Elevation <= zRef + 0.01) ?? levels.First();
                string mark = e.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString() ?? "";
                string tl = kind == "Beam" ? "Poutre" : kind == "Column" ? "Poteau" : kind == "Footing" ? "Semelle" : kind == "Strip" ? "Semelle filante" : kind == "Wall" ? "Voile" : kind == "Stair" ? (e is Autodesk.Revit.DB.Architecture.StairsRun ? "Volée" : "Palier")
                    : (e.Category != null && e.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFoundation ? "Fondation" : "Dalle");
                double vol = 0;
                try { vol = (e.get_Parameter(BuiltInParameter.HOST_VOLUME_COMPUTED)?.AsDouble() ?? 0) * 0.0283168466; } catch { }
                h = new Host { E = e, Kind = kind, Lv = lv, Vol = vol, Label = tl + " " + (string.IsNullOrWhiteSpace(mark) ? "#" + e.Id.Value : mark) };
                byHost[hid.Value] = h;
            }
            if (h.Kind == "") continue;
            BoundingBoxXYZ? rb = r.get_BoundingBox(null);
            if (rb == null) continue;
            h.Bars.Add(new RInfo { R = r, Role = r.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString() ?? "", Center = (rb.Min + rb.Max).Multiply(0.5), ZMin = rb.Min.Z, ZMax = rb.Max.Z, Zc = (rb.Min.Z + rb.Max.Z) / 2 });
        }
        other = byHost.Values.Count(h => h.Kind == "");
        return byHost.Values.Where(h => h.Kind != "" && h.Bars.Count > 0).OrderBy(h => h.Lv.Elevation).ThenBy(h => h.Label).ToList();
    }

    private static bool IsFrozen(string name) => name.IndexOf("[fig", StringComparison.OrdinalIgnoreCase) >= 0;

    /// <summary>Supprime les anciennes feuilles et vues « SC », sauf les vues dont le nom contient « [fige] » (retouchées à la main) et les feuilles qui les portent.</summary>
    private static List<string> ClearPrevious(Document doc, ElementId? activeId)
    {
        var frozen = new HashSet<long>(new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
            .Where(v => !v.IsTemplate && v.Name.StartsWith(Prefix) && IsFrozen(v.Name)).Select(v => v.Id.Value));
        foreach (var sh in new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Where(x => x.SheetNumber.StartsWith(SheetPrefix)).ToList())
        {
            try
            {
                bool keep = sh.GetAllViewports().Select(id => doc.GetElement(id) as Viewport).Any(vp => vp != null && frozen.Contains(vp.ViewId.Value));
                if (!keep && (activeId == null || sh.Id != activeId)) doc.Delete(sh.Id);
            }
            catch { }
        }
        var names = new List<string>();
        foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>().Where(v => !v.IsTemplate && v.Name.StartsWith(Prefix)).ToList())
        {
            try
            {
                if (frozen.Contains(v.Id.Value)) { names.Add(v.Name); continue; }
                if (activeId == null || v.Id != activeId) doc.Delete(v.Id);
            }
            catch { }
        }
        return names;
    }

    private static (double W, double H) SheetSize(Document doc, ElementId tbId)
    {
        double w = 420 * Mm, h = 297 * Mm;
        try
        {
            var tmp = ViewSheet.Create(doc, tbId);
            var o = tmp.Outline;
            if (o != null && o.Max.U - o.Min.U > 50 * Mm && o.Max.V - o.Min.V > 50 * Mm) { w = o.Max.U - o.Min.U; h = o.Max.V - o.Min.V; }
            doc.Delete(tmp.Id);
        }
        catch { /* taille par défaut A3 */ }
        return (w, h);
    }

    // ------------------------------------------------------------------ analyse des barres
    private static string Diam(Document doc, Rebar r)
    {
        if (doc.GetElement(r.GetTypeId()) is RebarBarType bt)
        {
            double d = Math.Round(UnitUtils.ConvertFromInternalUnits(bt.BarModelDiameter, UnitTypeId.Millimeters));
            if (d > 0) return "HA" + d.ToString("0", CultureInfo.InvariantCulture);
            return bt.Name;
        }
        return "HA?";
    }

    private static string Spacing(Rebar r)
    {
        try
        {
            var lr = r.LayoutRule;
            if (lr == RebarLayoutRule.MaximumSpacing || lr == RebarLayoutRule.NumberWithSpacing || lr == RebarLayoutRule.MinimumClearSpacing)
                return " e = " + Math.Round(UnitUtils.ConvertFromInternalUnits(r.MaxSpacing, UnitTypeId.Centimeters)).ToString("0", CultureInfo.InvariantCulture) + " cm";
        }
        catch { /* pas d'espacement pour cette disposition */ }
        return "";
    }

    /// <summary>Courbes, direction, libellé numéroté et poids de chaque barre de l'ouvrage. axis : axe de l'ouvrage (poutre : sa direction, poteau/voile : Z), null pour une dalle ou une semelle.
    /// faceAxis/faceMid : direction et valeur médiane qui séparent les deux faces (par défaut Z : inf./sup.).</summary>
    private static void Analyse(Document doc, Host h, XYZ? axis, double midZ, XYZ? faceAxis = null, double faceMid = 0)
    {
        foreach (var b in h.Bars)
        {
            try { b.Curves = b.R.GetCenterlineCurves(false, false, false, MultiplanarOption.IncludeOnlyPlanarCurves, 0).ToList(); } catch { b.Curves = new(); }
            var ln = b.Curves.OfType<Line>().OrderByDescending(c => c.Length).FirstOrDefault();
            if (axis != null)
            {
                b.Long = ln != null && Math.Abs(ln.Direction.DotProduct(axis)) > 0.75;
                var pts = b.Curves.SelectMany(c => new[] { c.GetEndPoint(0), c.GetEndPoint(1) }).ToList();
                if (pts.Count > 0) { b.AMin = pts.Min(p => p.DotProduct(axis)); b.AMax = pts.Max(p => p.DotProduct(axis)); }
            }
            else b.AlongX = ln != null && Math.Abs(ln.Direction.X) >= Math.Abs(ln.Direction.Y);
            string d = Diam(doc, b.R), sp = Spacing(b.R);
            int n = 1;
            try { n = Math.Max(1, b.R.NumberOfBarPositions); } catch { }
            bool upper = faceAxis == null ? b.Zc >= midZ : b.Center.DotProduct(faceAxis) >= faceMid;
            string face = faceAxis == null ? (upper ? "sup." : "inf.") : (upper ? "face 1" : "face 2");
            switch (h.Kind)
            {
                case "Slab":
                case "Footing":
                    b.Text = $"{d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))} ({face}, //{(b.AlongX ? "X" : "Y")})"; break;
                case "Stair": b.Text = b.Long ? $"{d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))} princ. ({face})" : $"{d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))} répart. ({face})"; break;
                case "Beam": b.Text = b.Long ? $"{n} {d} ({face})" : $"Cadres {d}{sp}"; break;
                case "Column": b.Text = b.Long ? $"{n} {d}" : $"Cadres {d}{sp}"; break;
                case "Strip": b.Text = b.Long ? $"{n} {d} ({face})" : $"{d}{sp} transv."; break;
                case "Wall": b.Text = b.Long ? $"{d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))} vert. ({face})" : $"{d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))} horiz. ({face})"; break;
                default: b.Text = $"{d}{sp}"; break;
            }
            if (KnownRoles.Contains(b.Role)) b.Text = $"{b.Role} {d}{(sp != "" ? sp : (n > 1 ? $" x{n}" : ""))}";
            if (_flags.ContainsKey(b.R.Id.Value)) b.Text += " (!)";
            // poids : longueur développée x nombre de barres x section x 7850 kg/m³
            try
            {
                double len = b.Curves.Sum(c => c.Length);
                double dia = (doc.GetElement(b.R.GetTypeId()) as RebarBarType)?.BarModelDiameter ?? 0;
                b.Kg = len * n * Math.PI * dia * dia / 4 * 0.0283168466 * 7850;
            }
            catch { b.Kg = 0; }
        }
        // numéros de position : un numéro par libellé distinct, identique sur toutes les vues de l'ouvrage
        var order = new Dictionary<string, int>();
        foreach (var b in h.Bars.OrderBy(x => x.Text, StringComparer.Ordinal))
        {
            if (!order.TryGetValue(b.Text, out int no)) { no = order.Count + 1; order[b.Text] = no; }
            b.No = no;
        }
        foreach (var b in h.Bars) b.Text = b.No + ") " + b.Text;
        h.Kg = h.Bars.Sum(b => b.Kg);
    }

    // ------------------------------------------------------------------ préparation des vues
    private static void PrepareView(Document doc, View v, Host h, IEnumerable<RInfo> shown)
    {
        v.DetailLevel = ViewDetailLevel.Fine;
        foreach (var bc in new[] { BuiltInCategory.OST_Levels, BuiltInCategory.OST_Grids, BuiltInCategory.OST_Viewers, BuiltInCategory.OST_Cameras })
        { try { var id = new ElementId(bc); if (v.CanCategoryBeHidden(id)) v.SetCategoryHidden(id, true); } catch { } }
        try { var rc = new ElementId(BuiltInCategory.OST_Rebar); if (v.CanCategoryBeHidden(rc)) v.SetCategoryHidden(rc, false); } catch { }
        var mine = new HashSet<long> { h.E.Id.Value };
        foreach (var b in h.Bars) mine.Add(b.R.Id.Value);
        foreach (long x in _extraMine) mine.Add(x);
        foreach (var b in shown) { try { b.R.SetUnobscuredInView(v, true); } catch { } }
        // seuls l'ouvrage et ses fers restent affichés : pas de voisins sous les textes
        var hide = new FilteredElementCollector(doc, v.Id).WhereElementIsNotElementType()
            .Where(e => e.Category != null && e.Category.CategoryType == CategoryType.Model && !mine.Contains(e.Id.Value)).Select(e => e.Id).ToList();
        if (hide.Count > 0)
        {
            try { v.HideElements(hide); }
            catch { foreach (var id in hide) { try { v.HideElements(new List<ElementId> { id }); } catch { } } }
        }
    }

    private static string UniqueName(Document doc, string name)
    {
        var used = new HashSet<string>(new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>().Select(v => v.Name));
        string n = name; int k = 2;
        while (used.Contains(n)) n = $"{name} ({k++})";
        return n;
    }

    private static int PickScale(double extW, double extH, double tagHPaper, double availW, double availH)
    {
        foreach (int s in Scales)
        {
            double w = extW / s + 20 * Mm + 55 * Mm, hh = Math.Max(extH / s + 18 * Mm, tagHPaper + 12 * Mm) + 12 * Mm;
            if (w <= availW && hh <= availH) return s;
        }
        return Scales[^1];
    }

    private static double TagHeightPaper(IEnumerable<string> texts, double textSize)
    {
        double sum = 0;
        int perLine = Math.Max(8, (int)(55 * Mm / (textSize * 0.85)));
        foreach (var t in texts) sum += Math.Ceiling(t.Length / (double)perLine) * textSize * 1.3 + textSize * 0.8;
        return sum;
    }

    // ------------------------------------------------------------------ poutres
    private static readonly HashSet<string> KnownRoles = new() { "Épingle", "Étrier fermé", "Couture", "Renfort d'angle", "Principale pliée", "Principale", "Principale palier (recouvrement)", "Chapeau", "Répartition" };

    private static Dictionary<long, string> _flags = new();          // barres d'escalier à traiter (contrôle des ancrages, recouvrements, cintrages)

    private static void LoadFlags()
    {
        _flags = new Dictionary<long, string>();
        try
        {
            string f = System.IO.Path.Combine(StructCalc.Engine.RevitLink.Dir, "controle", "drapeaux.txt");
            if (!System.IO.File.Exists(f)) return;
            foreach (var line in System.IO.File.ReadAllLines(f))
            {
                int i = line.IndexOf(';');
                if (i > 0 && long.TryParse(line.Substring(0, i), out long id)) _flags[id] = line.Substring(i + 1);
            }
        }
        catch { }
    }

    private static List<Host> _allHosts = new();                      // tous les ouvrages traités (paliers : accès aux volées associées)
    private static readonly HashSet<long> _extraMine = new();           // éléments supplémentaires gardés visibles dans la vue en cours (volées d'un palier)

    private static bool _dims = true;                      // cotes demandées pour la génération en cours

    private static List<Job> BuildBeam(Document doc, Host h, ElementId sectionType, ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        var fi = (FamilyInstance)h.E;
        if (fi.Location is not LocationCurve lc) throw new InvalidOperationException("poutre sans tracé");
        XYZ p0 = lc.Curve.GetEndPoint(0), p1 = lc.Curve.GetEndPoint(1);
        XYZ d = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0);
        if (d.GetLength() < 0.1) throw new InvalidOperationException("poutre verticale ou nulle");
        d = d.Normalize();
        XYZ n = XYZ.BasisZ.CrossProduct(d);
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double a0 = verts.Min(p => p.DotProduct(d)), a1 = verts.Max(p => p.DotProduct(d));
        double w0 = verts.Min(p => p.DotProduct(n)), w1 = verts.Max(p => p.DotProduct(n));
        double z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double midZ = (z0 + z1) / 2, wMid = (w0 + w1) / 2;
        Analyse(doc, h, d, midZ);
        var jobs = new List<Job>();

        // coupe en long
        {
            XYZ o = d.Multiply((a0 + a1) / 2) + n.Multiply(wMid) + XYZ.BasisZ.Multiply(midZ);
            var f = new Frame { O = o, R = d, U = XYZ.BasisZ };
            var texts = Dedupe(h.Bars, null, 0, 0);
            jobs.Add(MakeSection(doc, h, sectionType, f, -(a1 - a0) / 2, (a1 - a0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, (w1 - w0) / 2 + 0.1, texts, h.Label + " - coupe en long", "Poutres", textType, textSize, availW, availH, h.Bars));
        }
        // trois coupes en travers : appuis et milieu
        double L = a1 - a0;
        foreach (var (frac, name) in new[] { (0.12, "appui gauche"), (0.5, "travée"), (0.88, "appui droit") })
        {
            double st = a0 + L * frac;
            XYZ o = d.Multiply(st) + n.Multiply(wMid) + XYZ.BasisZ.Multiply(midZ);
            var f = new Frame { O = o, R = n, U = XYZ.BasisZ };
            var texts = Dedupe(h.Bars, d, st, 0.02);
            jobs.Add(MakeSection(doc, h, sectionType, f, -(w1 - w0) / 2, (w1 - w0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, 0.12, texts, $"{h.Label} - coupe {name}", "Poutres", textType, textSize, availW, availH, h.Bars));
        }
        return jobs;
    }

    // ------------------------------------------------------------------ poteaux
    private static List<Job> BuildColumn(Document doc, Host h, ElementId sectionType, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                         ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        _dims = opt.Dimensions;
        double cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, midZ = (z0 + z1) / 2;
        Analyse(doc, h, XYZ.BasisZ, midZ);
        var jobs = new List<Job>();
        {   // élévation
            var f = new Frame { O = new XYZ(cx, cy, midZ), R = XYZ.BasisX, U = XYZ.BasisZ };
            var texts = Dedupe(h.Bars, null, 0, 0);
            jobs.Add(MakeSection(doc, h, sectionType, f, -(x1 - x0) / 2, (x1 - x0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, (y1 - y0) / 2 + 0.1, texts, h.Label + " - élévation", "Poteaux", textType, textSize, availW, availH, h.Bars));
        }
        {   // coupe horizontale à mi-hauteur
            var texts = Dedupe(h.Bars, XYZ.BasisZ, midZ, 0.02);
            jobs.Add(MakePlan(doc, h, planType, baseViews, createdBase, cx, cy, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, midZ - 0.05, midZ + 0.05,
                              texts, h.Label + " - coupe horizontale", "Poteaux", textType, textSize, availW, availH, h.Bars));
        }
        return jobs;
    }

    // ------------------------------------------------------------------ dalles, radiers
    private static List<Job> BuildSlab(Document doc, Host h, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase, ElementId textType, double textSize,
                                       double availW, double availH, PlansOptions opt)
    {
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double midZ = (z0 + z1) / 2;
        Analyse(doc, h, null, midZ);
        var texts = Dedupe(h.Bars, null, 0, 0);
        string grp = h.Label.StartsWith("Fondation") ? "Fondations" : "Dalles";
        _dims = opt.Dimensions;
        return new List<Job>
        {
            MakePlan(doc, h, planType, baseViews, createdBase, (x0 + x1) / 2, (y0 + y1) / 2, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, z0 - 0.05, z1 + 0.05,
                     texts, h.Label + " - plan de ferraillage", grp, textType, textSize, availW, availH, h.Bars)
        };
    }

    // ------------------------------------------------------------------ semelles isolées
    private static List<Job> BuildFooting(Document doc, Host h, ElementId sectionType, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                           ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, midZ = (z0 + z1) / 2;
        Analyse(doc, h, null, midZ);
        var texts = Dedupe(h.Bars, null, 0, 0);
        var jobs = new List<Job>
        {
            MakePlan(doc, h, planType, baseViews, createdBase, cx, cy, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, z0 - 0.05, z1 + 0.05,
                     texts, h.Label + " - plan de ferraillage", "Fondations", textType, textSize, availW, availH, h.Bars)
        };
        var f = new Frame { O = new XYZ(cx, cy, midZ), R = XYZ.BasisX, U = XYZ.BasisZ };
        jobs.Add(MakeSection(doc, h, sectionType, f, -(x1 - x0) / 2, (x1 - x0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, (y1 - y0) / 2 + 0.1, texts, h.Label + " - coupe", "Fondations", textType, textSize, availW, availH, h.Bars));
        return jobs;
    }

    // ------------------------------------------------------------------ semelles filantes
    private static List<Job> BuildStrip(Document doc, Host h, ElementId sectionType, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                         ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        if (h.E.Location is not LocationCurve lc) throw new InvalidOperationException("semelle filante sans tracé");
        XYZ p0 = lc.Curve.GetEndPoint(0), p1 = lc.Curve.GetEndPoint(1);
        XYZ d = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0);
        if (d.GetLength() < 0.1) throw new InvalidOperationException("tracé nul");
        d = d.Normalize();
        XYZ n = XYZ.BasisZ.CrossProduct(d);
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double a0 = verts.Min(p => p.DotProduct(d)), a1 = verts.Max(p => p.DotProduct(d)), w0 = verts.Min(p => p.DotProduct(n)), w1 = verts.Max(p => p.DotProduct(n));
        double midZ = (z0 + z1) / 2, wMid = (w0 + w1) / 2;
        Analyse(doc, h, d, midZ);
        var jobs = new List<Job>
        {
            MakePlan(doc, h, planType, baseViews, createdBase, (x0 + x1) / 2, (y0 + y1) / 2, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, z0 - 0.05, z1 + 0.05,
                     Dedupe(h.Bars, null, 0, 0), h.Label + " - plan de ferraillage", "Fondations", textType, textSize, availW, availH, h.Bars)
        };
        double st = (a0 + a1) / 2;
        var f = new Frame { O = d.Multiply(st) + n.Multiply(wMid) + XYZ.BasisZ.Multiply(midZ), R = n, U = XYZ.BasisZ };
        jobs.Add(MakeSection(doc, h, sectionType, f, -(w1 - w0) / 2, (w1 - w0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, 0.12, Dedupe(h.Bars, d, st, 0.02),
                             h.Label + " - coupe en travers", "Fondations", textType, textSize, availW, availH, h.Bars));
        return jobs;
    }

    // ------------------------------------------------------------------ voiles
    private static List<Job> BuildWall(Document doc, Host h, ElementId sectionType, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                        ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        if (h.E.Location is not LocationCurve lc) throw new InvalidOperationException("voile sans tracé");
        XYZ p0 = lc.Curve.GetEndPoint(0), p1 = lc.Curve.GetEndPoint(1);
        XYZ d = new XYZ(p1.X - p0.X, p1.Y - p0.Y, 0);
        if (d.GetLength() < 0.1) throw new InvalidOperationException("tracé nul");
        d = d.Normalize();
        XYZ n = XYZ.BasisZ.CrossProduct(d);
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double a0 = verts.Min(p => p.DotProduct(d)), a1 = verts.Max(p => p.DotProduct(d)), w0 = verts.Min(p => p.DotProduct(n)), w1 = verts.Max(p => p.DotProduct(n));
        double midZ = (z0 + z1) / 2, wMid = (w0 + w1) / 2;
        Analyse(doc, h, XYZ.BasisZ, midZ, n, wMid);
        var jobs = new List<Job>();
        var f = new Frame { O = d.Multiply((a0 + a1) / 2) + n.Multiply(wMid) + XYZ.BasisZ.Multiply(midZ), R = d, U = XYZ.BasisZ };
        jobs.Add(MakeSection(doc, h, sectionType, f, -(a1 - a0) / 2, (a1 - a0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, (w1 - w0) / 2 + 0.1, Dedupe(h.Bars, null, 0, 0),
                             h.Label + " - élévation", "Voiles", textType, textSize, availW, availH, h.Bars));
        jobs.Add(MakePlan(doc, h, planType, baseViews, createdBase, (x0 + x1) / 2, (y0 + y1) / 2, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, midZ - 0.05, midZ + 0.05,
                          Dedupe(h.Bars, XYZ.BasisZ, midZ, 0.02), h.Label + " - coupe horizontale", "Voiles", textType, textSize, availW, availH, h.Bars));
        return jobs;
    }

    /// <summary>Sens (en plan) d'une volée ou d'un palier : direction de la plus longue barre.</summary>
    private static XYZ StairDir(Host h)
    {
        XYZ d = XYZ.BasisX; double best = 0;
        foreach (var b in h.Bars)
        {
            try
            {
                foreach (var l in b.R.GetCenterlineCurves(false, false, false, MultiplanarOption.IncludeOnlyPlanarCurves, 0).OfType<Line>())
                    if (l.Length > best && new XYZ(l.Direction.X, l.Direction.Y, 0).GetLength() > 0.2) { best = l.Length; d = new XYZ(l.Direction.X, l.Direction.Y, 0).Normalize(); }
            }
            catch { }
        }
        return d;
    }

    /// <summary>Plan de ferraillage d'un palier : le palier et TOUTES les volées qui y aboutissent ou en partent, avec leurs fers et leurs repères préfixés (P = palier, V1, V2... = volées).</summary>
    private static List<Job> BuildLandingWithRuns(Document doc, Host h, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                                   ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double cutZ = (z0 + z1) / 2;
        Analyse(doc, h, StairDir(h), cutZ);
        foreach (var b in h.Bars) b.Text = "P: " + b.Text;
        var shown = Dedupe(h.Bars, null, 0, 0);
        _extraMine.Clear();
        string assocTxt = "";
        var st = (h.E as Autodesk.Revit.DB.Architecture.StairsLanding)?.GetStairs();
        var plan = st != null ? StairRebar.Detect(doc, st) : null;
        if (plan != null)
        {
            int k = plan.Lands.FindIndex(l => l.Id == h.E.Id);
            for (int j = 0; k >= 0 && j < plan.Runs.Count; j++)
            {
                if (plan.End[j] != k && plan.Start[j] != k) continue;
                var rh = _allHosts.FirstOrDefault(x => x.E.Id == plan.Runs[j].Id);
                var rv = ReinforceCommand.Vertices(plan.Runs[j]);
                if (rv.Count == 0) continue;
                x0 = Math.Min(x0, rv.Min(p => p.X)); x1 = Math.Max(x1, rv.Max(p => p.X)); y0 = Math.Min(y0, rv.Min(p => p.Y)); y1 = Math.Max(y1, rv.Max(p => p.Y));
                z0 = Math.Min(z0, rv.Min(p => p.Z)); z1 = Math.Max(z1, rv.Max(p => p.Z));
                _extraMine.Add(plan.Runs[j].Id.Value);
                assocTxt += (plan.End[j] == k ? $" V{j + 1} (arrive)" : $" V{j + 1} (part)");
                if (rh == null) continue;
                var rbb = rh.E.get_BoundingBox(null);
                Analyse(doc, rh, StairDir(rh), rbb != null ? (rbb.Min.Z + rbb.Max.Z) / 2 : z0);
                foreach (var b in rh.Bars) { b.Text = $"V{j + 1}: " + b.Text; _extraMine.Add(b.R.Id.Value); }
                shown.AddRange(Dedupe(rh.Bars, null, 0, 0));
            }
        }
        string title = h.Label + " - plan de ferraillage" + (assocTxt != "" ? " et volées associées" : "");
        var job = MakePlan(doc, h, planType, baseViews, createdBase, (x0 + x1) / 2, (y0 + y1) / 2, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, cutZ, z0 - 0.05, z1 + 0.05,
                           shown, title, "Escaliers", textType, textSize, availW, availH, h.Bars);
        _extraMine.Clear();
        if (assocTxt != "")
        {
            var ol = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Left, VerticalAlignment = VerticalTextAlignment.Top };
            try { TextNote.Create(doc, job.View.Id, job.F.W(job.X0 + 0.5 * Mm * job.Scale, job.Y1 - 4.5 * Mm * job.Scale), 70 * Mm, "Volées associées :" + assocTxt, ol); } catch { }
        }
        return new List<Job> { job };
    }

    // ------------------------------------------------------------------ escaliers : volées (plan + coupe suivant la pente) et paliers (plan)
    private static List<Job> BuildStair(Document doc, Host h, ElementId sectionType, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase,
                                         ElementId textType, double textSize, double availW, double availH, PlansOptions opt)
    {
        _dims = opt.Dimensions;
        if (h.Label.StartsWith("Palier")) return BuildLandingWithRuns(doc, h, planType, baseViews, createdBase, textType, textSize, availW, availH, opt);
        var verts = ReinforceCommand.Vertices(h.E);
        if (verts.Count == 0) throw new InvalidOperationException("géométrie illisible");
        double x0 = verts.Min(p => p.X), x1 = verts.Max(p => p.X), y0 = verts.Min(p => p.Y), y1 = verts.Max(p => p.Y), z0 = verts.Min(p => p.Z), z1 = verts.Max(p => p.Z);
        double midZ = (z0 + z1) / 2;
        // sens de la volée = direction (en plan) de la plus longue barre
        XYZ d = XYZ.BasisX; double best = 0;
        foreach (var b in h.Bars)
        {
            try
            {
                foreach (var l in b.R.GetCenterlineCurves(false, false, false, MultiplanarOption.IncludeOnlyPlanarCurves, 0).OfType<Line>())
                    if (l.Length > best && new XYZ(l.Direction.X, l.Direction.Y, 0).GetLength() > 0.2) { best = l.Length; d = new XYZ(l.Direction.X, l.Direction.Y, 0).Normalize(); }
            }
            catch { }
        }
        XYZ n = XYZ.BasisZ.CrossProduct(d);
        Analyse(doc, h, d, midZ);
        var jobs = new List<Job>
        {
            MakePlan(doc, h, planType, baseViews, createdBase, (x0 + x1) / 2, (y0 + y1) / 2, -(x1 - x0) / 2, (x1 - x0) / 2, -(y1 - y0) / 2, (y1 - y0) / 2, midZ, z0 - 0.05, z1 + 0.05,
                     Dedupe(h.Bars, null, 0, 0), h.Label + " - plan de ferraillage", "Escaliers", textType, textSize, availW, availH, h.Bars)
        };
        if (h.Label.StartsWith("Volée"))
        {
            double a0 = verts.Min(p => p.DotProduct(d)), a1 = verts.Max(p => p.DotProduct(d)), w0 = verts.Min(p => p.DotProduct(n)), w1 = verts.Max(p => p.DotProduct(n));
            var f = new Frame { O = d.Multiply((a0 + a1) / 2) + n.Multiply((w0 + w1) / 2) + XYZ.BasisZ.Multiply(midZ), R = d, U = XYZ.BasisZ };
            jobs.Add(MakeSection(doc, h, sectionType, f, -(a1 - a0) / 2, (a1 - a0) / 2, -(z1 - z0) / 2, (z1 - z0) / 2, (w1 - w0) / 2 + 0.1, Dedupe(h.Bars, null, 0, 0),
                                 h.Label + " - coupe suivant la pente", "Escaliers", textType, textSize, availW, availH, h.Bars));
        }
        return jobs;
    }

    // ------------------------------------------------------------------ libellés retenus pour une vue (sans doublon)
    private static List<RInfo> Dedupe(List<RInfo> bars, XYZ? axis, double station, double tol)
    {
        var res = new List<RInfo>();
        var seen = new HashSet<string>();
        foreach (var b in bars)
        {
            if (axis != null && !b.Long && station != 0 && (b.AMin > station + tol || b.AMax < station - tol)) continue;      // jeu de cadres qui ne traverse pas la coupe
            if (axis != null && Math.Abs(axis.Z) > 0.9 && !b.Long && (b.ZMin > station + tol || b.ZMax < station - tol)) continue;
            string key = b.Text + "|" + Math.Round(b.Zc * 30.48);
            if (seen.Add(key)) res.Add(b);
        }
        return res;
    }

    // ------------------------------------------------------------------ création d'une coupe
    private static Job MakeSection(Document doc, Host h, ElementId sectionType, Frame f, double ex0, double ex1, double ey0, double ey1, double depth, List<RInfo> shown, string title,
                                   string group, ElementId textType, double textSize, double availW, double availH, List<RInfo> all)
    {
        double tagH = TagHeightPaper(shown.Select(s => s.Text), textSize);
        int S = PickScale(ex1 - ex0, ey1 - ey0, tagH, availW, availH);
        var job = LayOut(f, ex0, ex1, ey0, ey1, S, tagH, title, group, h.Lv.Name);
        var box = new BoundingBoxXYZ();
        var t = Transform.Identity;
        t.Origin = f.O; t.BasisX = f.R; t.BasisY = f.U; t.BasisZ = f.R.CrossProduct(f.U);
        box.Transform = t;
        box.Min = new XYZ(job.X0, job.Y0, -depth);
        box.Max = new XYZ(job.X1, job.Y1, depth);
        ViewSection vs = ViewSection.CreateSection(doc, sectionType, box);
        vs.Name = UniqueName(doc, Prefix + title);
        vs.Scale = S;
        job.View = vs;
        PrepareView(doc, vs, h, shown);
        if (_dims) AddDims(doc, job, ex0, ex1, ey0, ey1, textType, textSize, h, shown);
        AddNotes(doc, job, shown, ex1, textType, textSize);
        return job;
    }

    private static Job MakePlan(Document doc, Host h, ElementId planType, Dictionary<long, ViewPlan> baseViews, List<ElementId> createdBase, double cx, double cy,
                                double ex0, double ex1, double ey0, double ey1, double cutZ, double bottomZ, double topZ, List<RInfo> shown, string title, string group,
                                ElementId textType, double textSize, double availW, double availH, List<RInfo> all)
    {
        double tagH = TagHeightPaper(shown.Select(s => s.Text), textSize);
        int S = PickScale(ex1 - ex0, ey1 - ey0, tagH, availW, availH);
        var f = new Frame { O = new XYZ(cx, cy, h.Lv.Elevation), R = XYZ.BasisX, U = XYZ.BasisY };
        var job = LayOut(f, ex0, ex1, ey0, ey1, S, tagH, title, group, h.Lv.Name);

        if (!baseViews.TryGetValue(h.Lv.Id.Value, out var baseView))
        {
            baseView = new FilteredElementCollector(doc).OfClass(typeof(ViewPlan)).Cast<ViewPlan>()
                .FirstOrDefault(v => !v.IsTemplate && v.GenLevel != null && v.GenLevel.Id == h.Lv.Id && (v.ViewType == ViewType.EngineeringPlan || v.ViewType == ViewType.FloorPlan));
            if (baseView == null) { baseView = ViewPlan.Create(doc, planType, h.Lv.Id); createdBase.Add(baseView.Id); }
            baseViews[h.Lv.Id.Value] = baseView;
        }
        var dup = (ViewPlan)doc.GetElement(baseView.Duplicate(ViewDuplicateOption.Duplicate));
        dup.ViewTemplateId = ElementId.InvalidElementId;
        dup.Name = UniqueName(doc, Prefix + title);
        dup.Scale = S;

        // plan de coupe dans l'ouvrage : les fers de l'ouvrage sont dans la plage de vue
        var vr = dup.GetViewRange();
        double lz = h.Lv.Elevation;
        foreach (var pl in new[] { PlanViewPlane.TopClipPlane, PlanViewPlane.CutPlane, PlanViewPlane.BottomClipPlane, PlanViewPlane.ViewDepthPlane }) vr.SetLevelId(pl, h.Lv.Id);
        vr.SetOffset(PlanViewPlane.TopClipPlane, topZ - lz);
        vr.SetOffset(PlanViewPlane.CutPlane, cutZ - lz);
        vr.SetOffset(PlanViewPlane.BottomClipPlane, bottomZ - lz);
        vr.SetOffset(PlanViewPlane.ViewDepthPlane, bottomZ - lz);
        dup.SetViewRange(vr);

        dup.CropBoxActive = true;
        dup.CropBoxVisible = false;
        var cb = dup.CropBox;
        var inv = cb.Transform.Inverse;
        XYZ lo = inv.OfPoint(f.W(job.X0, job.Y0)), hi = inv.OfPoint(f.W(job.X1, job.Y1));
        cb.Min = new XYZ(Math.Min(lo.X, hi.X), Math.Min(lo.Y, hi.Y), cb.Min.Z);
        cb.Max = new XYZ(Math.Max(lo.X, hi.X), Math.Max(lo.Y, hi.Y), cb.Max.Z);
        dup.CropBox = cb;

        job.View = dup;
        PrepareView(doc, dup, h, shown);
        if (_dims) AddDims(doc, job, ex0, ex1, ey0, ey1, textType, textSize, h, shown);
        AddNotes(doc, job, shown, ex1, textType, textSize);
        return job;
    }

    /// <summary>Cadre de la vue : l'ouvrage + une marge + une colonne à droite pour les étiquettes (assez haute pour les empiler toutes).</summary>
    private static Job LayOut(Frame f, double ex0, double ex1, double ey0, double ey1, int S, double tagHPaper, string title, string group, string level)
    {
        double m = 6 * Mm * S, wt = 55 * Mm * S;
        double x0 = ex0 - 14 * Mm * S, x1 = ex1 + m + wt, y0 = ey0 - 12 * Mm * S, y1 = ey1 + m;
        double needed = tagHPaper * S + 2 * m;
        if (y1 - y0 < needed) { double cy = (ey0 + ey1) / 2; y0 = cy - needed / 2; y1 = cy + needed / 2; }
        return new Job
        {
            F = f, X0 = x0, X1 = x1, Y0 = y0, Y1 = y1, Scale = S, Group = group, Level = level, Title = title,
            WPaper = (x1 - x0) / S, HPaper = (y1 - y0) / S + 12 * Mm
        };
    }

    // ------------------------------------------------------------------ étiquettes : colonne à droite, repères vers les fers, jamais superposées
    private static void AddNotes(Document doc, Job job, List<RInfo> shown, double elemRight, ElementId textType, double textSize)
    {
        if (shown.Count == 0) return;
        int S = job.Scale;
        double wt = 55 * Mm;                                       // largeur du texte sur le papier
        int perLine = Math.Max(8, (int)(wt / (textSize * 0.85)));
        var items = new List<(RInfo B, XYZ Anchor, double Ay, double H)>();
        foreach (var b in shown)
        {
            double yc = job.F.Y(b.Center);
            XYZ target = job.F.W(elemRight, yc);
            XYZ? best = null; double bd = double.MaxValue;
            foreach (var c in b.Curves)
            {
                var ir = c.Project(target);
                if (ir != null && ir.Distance < bd) { bd = ir.Distance; best = ir.XYZPoint; }
            }
            double ax = best != null ? job.F.X(best) : elemRight, ay = best != null ? job.F.Y(best) : yc;
            XYZ anchor = job.F.W(ax, ay);
            double hNote = (Math.Ceiling(b.Text.Length / (double)perLine) * textSize * 1.3 + textSize * 0.8) * S;
            items.Add((b, anchor, ay, hNote));
        }
        items = items.OrderByDescending(i => i.Ay).ToList();
        double gap = textSize * 0.4 * S;
        var tops = new double[items.Count];
        for (int i = 0; i < items.Count; i++)
        {
            tops[i] = items[i].Ay + items[i].H / 2;
            if (i > 0) tops[i] = Math.Min(tops[i], tops[i - 1] - items[i - 1].H - gap);
        }
        double last = tops[^1] - items[^1].H;
        double shift = 0;
        if (last < job.Y0 + 3 * Mm * S) shift = job.Y0 + 3 * Mm * S - last;
        if (tops[0] + shift > job.Y1 - 3 * Mm * S) shift = job.Y1 - 3 * Mm * S - tops[0];
        double xText = elemRight + 4 * Mm * S;
        var opts = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Left, VerticalAlignment = VerticalTextAlignment.Top };
        for (int i = 0; i < items.Count; i++)
        {
            XYZ pos = job.F.W(xText, tops[i] + shift);
            var tn = TextNote.Create(doc, job.View.Id, pos, wt, items[i].B.Text, opts);
            try
            {
                tn.AddLeader(TextNoteLeaderTypes.TNLT_STRAIGHT_L);
                var ls = tn.GetLeaders();
                if (ls.Count > 0) ls[0].End = items[i].Anchor;
            }
            catch { /* repère impossible : le texte reste en place */ }
        }
        doc.Regenerate();
        ResolveOverlaps(doc, job);
    }

    // ------------------------------------------------------------------ contrôle des chevauchements (textes entre eux)
    private static List<(TextNote N, BoundingBoxXYZ B)> NotesOf(Document doc, Job job)
    {
        var res = new List<(TextNote, BoundingBoxXYZ)>();
        foreach (TextNote tn in new FilteredElementCollector(doc, job.View.Id).OfClass(typeof(TextNote)).Cast<TextNote>())
        {
            var bb = tn.get_BoundingBox(job.View);
            if (bb != null) res.Add((tn, bb));
        }
        return res;
    }

    private static bool Overlap(Job job, BoundingBoxXYZ a, BoundingBoxXYZ b)
    {
        // comparaison dans le repère de la vue (X vers la droite, Y vers le haut)
        double ax0 = job.F.X(a.Min), ax1 = job.F.X(a.Max), ay0 = job.F.Y(a.Min), ay1 = job.F.Y(a.Max);
        double bx0 = job.F.X(b.Min), bx1 = job.F.X(b.Max), by0 = job.F.Y(b.Min), by1 = job.F.Y(b.Max);
        double tol = 0.2 * Mm * job.Scale;
        return Math.Min(Math.Max(ax0, ax1), Math.Max(bx0, bx1)) - Math.Max(Math.Min(ax0, ax1), Math.Min(bx0, bx1)) > tol
            && Math.Min(Math.Max(ay0, ay1), Math.Max(by0, by1)) - Math.Max(Math.Min(ay0, ay1), Math.Min(by0, by1)) > tol;
    }

    private static void ResolveOverlaps(Document doc, Job job)
    {
        for (int pass = 0; pass < 6; pass++)
        {
            var notes = NotesOf(doc, job).OrderByDescending(n => job.F.Y(n.B.Max)).ToList();
            bool moved = false;
            for (int i = 1; i < notes.Count && !moved; i++)
                for (int k = 0; k < i; k++)
                    if (Overlap(job, notes[k].B, notes[i].B))
                    {
                        double bottomK = Math.Min(job.F.Y(notes[k].B.Min), job.F.Y(notes[k].B.Max));
                        double topI = Math.Max(job.F.Y(notes[i].B.Min), job.F.Y(notes[i].B.Max));
                        double dy = bottomK - topI - 0.6 * Mm * job.Scale;
                        var end = TryLeaderEnd(notes[i].N);
                        ElementTransformUtils.MoveElement(doc, notes[i].N.Id, job.F.U.Multiply(dy));
                        if (end != null) { try { var ls = notes[i].N.GetLeaders(); if (ls.Count > 0) ls[0].End = end; } catch { } }
                        moved = true; break;
                    }
            if (!moved) break;
            doc.Regenerate();
        }
    }

    private static XYZ? TryLeaderEnd(TextNote tn)
    {
        try { var ls = tn.GetLeaders(); return ls.Count > 0 ? ls[0].End : null; } catch { return null; }
    }

    private static int CountOverlaps(Document doc, Job job)
    {
        var notes = NotesOf(doc, job);
        int n = 0;
        for (int i = 0; i < notes.Count; i++) for (int k = i + 1; k < notes.Count; k++) if (Overlap(job, notes[i].B, notes[k].B)) n++;
        return n;
    }

    // ------------------------------------------------------------------ cotes (traits de cote et valeurs en cm, hors de l'ouvrage)
    private static void Faces(GeometryElement ge, List<PlanarFace> res)
    {
        foreach (GeometryObject go in ge)
        {
            if (go is Solid sd && sd.Volume > 1e-9) { foreach (Face f in sd.Faces) if (f is PlanarFace pf && pf.Reference != null) res.Add(pf); }
            else if (go is GeometryInstance gi) { try { Faces(gi.GetInstanceGeometry(), res); } catch { } }
        }
    }

    /// <summary>Vraies cotes Revit (associées aux faces du béton) : horizontale sous l'ouvrage et verticale à gauche. Renvoie quelles directions ont réussi.</summary>
    private static (bool H, bool V) RealDims(Document doc, Job job, Host h, double ex0, double ex1, double ey0, double ey1)
    {
        bool okH = false, okV = false;
        try
        {
            var faces = new List<PlanarFace>();
            var go = new Options { View = job.View, ComputeReferences = true, DetailLevel = ViewDetailLevel.Fine };
            var ge = h.E.get_Geometry(go);
            if (ge == null) return (false, false);
            Faces(ge, faces);
            int S = job.Scale;
            XYZ Rr = job.F.R, Uu = job.F.U;
            // sections : seules les faces perpendiculaires au plan de vue et orientées suivant R ou U conviennent
            var fh = faces.Where(f => Math.Abs(f.FaceNormal.DotProduct(Rr)) > 0.99).OrderBy(f => f.Origin.DotProduct(Rr)).ToList();
            var fv = faces.Where(f => Math.Abs(f.FaceNormal.DotProduct(Uu)) > 0.99).OrderBy(f => f.Origin.DotProduct(Uu)).ToList();
            if (fh.Count >= 2 && fh[^1].Origin.DotProduct(Rr) - fh[0].Origin.DotProduct(Rr) > 0.02)
            {
                try
                {
                    var ra = new ReferenceArray(); ra.Append(fh[0].Reference); ra.Append(fh[^1].Reference);
                    double yl = ey0 - 7 * Mm * S;
                    doc.Create.NewDimension(job.View, Line.CreateBound(job.F.W(job.F.X(fh[0].Origin), yl), job.F.W(job.F.X(fh[^1].Origin), yl)), ra);
                    okH = true;
                }
                catch { }
            }
            if (fv.Count >= 2 && fv[^1].Origin.DotProduct(Uu) - fv[0].Origin.DotProduct(Uu) > 0.02)
            {
                try
                {
                    var ra = new ReferenceArray(); ra.Append(fv[0].Reference); ra.Append(fv[^1].Reference);
                    double xl = ex0 - 7 * Mm * S;
                    doc.Create.NewDimension(job.View, Line.CreateBound(job.F.W(xl, job.F.Y(fv[0].Origin)), job.F.W(xl, job.F.Y(fv[^1].Origin))), ra);
                    okV = true;
                }
                catch { }
            }
        }
        catch { }
        return (okH, okV);
    }

    /// <summary>Enrobage mini lu sur le modèle : plus petite distance entre l'enveloppe des fers affichés et les bords de l'ouvrage dans la vue.</summary>
    private static string CoverText(Job job, List<RInfo> shown, double ex0, double ex1, double ey0, double ey1)
    {
        double min = double.MaxValue;
        foreach (var b in shown)
        {
            var bb = b.R.get_BoundingBox(null);
            if (bb == null) continue;
            var xs = new List<double>(); var ys = new List<double>();
            foreach (double x in new[] { bb.Min.X, bb.Max.X }) foreach (double y in new[] { bb.Min.Y, bb.Max.Y }) foreach (double z in new[] { bb.Min.Z, bb.Max.Z })
            { var q = new XYZ(x, y, z); xs.Add(job.F.X(q)); ys.Add(job.F.Y(q)); }
            foreach (double c in new[] { xs.Min() - ex0, ex1 - xs.Max(), ys.Min() - ey0, ey1 - ys.Max() }) if (c > 0.005 && c < min) min = c;
        }
        return min == double.MaxValue ? "" : " - enrobage mini " + (Math.Round(min * 30.48 * 2) / 2).ToString("0.#", CultureInfo.InvariantCulture) + " cm";
    }

    // ------------------------------------------------------------------ cotes
    private static void AddDims(Document doc, Job job, double ex0, double ex1, double ey0, double ey1, ElementId textType, double textSize, Host h, List<RInfo> shown)
    {
        int S = job.Scale;
        double tick = 1.0 * Mm * S;
        var (okH, okV) = RealDims(doc, job, h, ex0, ex1, ey0, ey1);
        void Line2(double ax, double ay, double bx, double by)
        {
            try
            {
                var a = job.F.W(ax, ay); var b = job.F.W(bx, by);
                if (a.DistanceTo(b) < 0.001) return;
                doc.Create.NewDetailCurve(job.View, Line.CreateBound(a, b));
            }
            catch { /* trait impossible dans cette vue */ }
        }
        string Cm(double ft) => Math.Round(ft * 30.48).ToString("0", CultureInfo.InvariantCulture);
        if (!okH)
        {   // repli : cote dessinée (traits + valeur) si Revit ne donne pas de références de faces dans cette vue
            double yl = ey0 - 4 * Mm * S;
            Line2(ex0, yl, ex1, yl);
            Line2(ex0, ey0 - 1 * Mm * S, ex0, yl - 1.5 * Mm * S); Line2(ex1, ey0 - 1 * Mm * S, ex1, yl - 1.5 * Mm * S);
            Line2(ex0 - tick / 2, yl - tick / 2, ex0 + tick / 2, yl + tick / 2); Line2(ex1 - tick / 2, yl - tick / 2, ex1 + tick / 2, yl + tick / 2);
            var oc = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Center, VerticalAlignment = VerticalTextAlignment.Top };
            try { TextNote.Create(doc, job.View.Id, job.F.W((ex0 + ex1) / 2, yl - 0.8 * Mm * S), 14 * Mm, Cm(ex1 - ex0), oc); } catch { }
        }
        if (!okV)
        {
            double xl = ex0 - 4 * Mm * S;
            Line2(xl, ey0, xl, ey1);
            Line2(ex0 - 1 * Mm * S, ey0, xl - 1.5 * Mm * S, ey0); Line2(ex0 - 1 * Mm * S, ey1, xl - 1.5 * Mm * S, ey1);
            Line2(xl - tick / 2, ey0 - tick / 2, xl + tick / 2, ey0 + tick / 2); Line2(xl - tick / 2, ey1 - tick / 2, xl + tick / 2, ey1 + tick / 2);
            var orr = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Right, VerticalAlignment = VerticalTextAlignment.Top };
            try { TextNote.Create(doc, job.View.Id, job.F.W(xl - 1.2 * Mm * S, (ey0 + ey1) / 2 + textSize * S / 2), 9 * Mm, Cm(ey1 - ey0), orr); } catch { }
        }
        var ol = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Left, VerticalAlignment = VerticalTextAlignment.Top };
        try { TextNote.Create(doc, job.View.Id, job.F.W(job.X0 + 0.5 * Mm * S, job.Y1 - 0.5 * Mm * S), 70 * Mm, "Cotes en cm" + CoverText(job, shown, ex0, ex1, ey0, ey1) + (shown.Any(b => _flags.ContainsKey(b.R.Id.Value)) ? " - (!) voir le contrôle des escaliers" : ""), ol); } catch { }
    }

    // ------------------------------------------------------------------ nomenclature des aciers et récapitulatif
    private static void BuildNomenclature(Document doc, List<Host> hosts, ElementId tbId, ElementId textType, double textSize, PlansOptions opt, double sheetW, double sheetH, Counters cnt)
    {
        double L = opt.LeftMm * Mm, R = sheetW - opt.RightMm * Mm, B = opt.BottomMm * Mm, T = sheetH - opt.TopMm * Mm;
        // 1) tableau Revit de tous les fers StructCalc
        var sh = ViewSheet.Create(doc, tbId);
        sh.SheetNumber = UniqueSheetNumber(doc, SheetPrefix + "NOM-01"); sh.Name = "Nomenclature des aciers";
        StampSheet(sh); cnt.Sheets++; cnt.SheetIds.Add(sh.Id);
        try
        {
            var sch = ViewSchedule.CreateSchedule(doc, new ElementId(BuiltInCategory.OST_Rebar));
            sch.Name = UniqueName(doc, Prefix + "Nomenclature des aciers");
            var def = sch.Definition;
            def.IsItemized = false;
            var fields = def.GetSchedulableFields();
            ScheduleField? Add(params string[] names)
            {
                foreach (var nm in names)
                {
                    if (!Enum.TryParse<BuiltInParameter>(nm, out var bip)) continue;
                    var sf = fields.FirstOrDefault(f => f.ParameterId == new ElementId(bip));
                    if (sf != null) return def.AddField(sf);
                }
                return null;
            }
            var fHost = Add("REBAR_ELEM_HOST_MARK", "REBAR_HOST_MARK");
            var fDia = Add("REBAR_BAR_DIAMETER");
            var fQty = Add("REBAR_ELEM_QUANTITY_OF_BARS", "REBAR_ELEM_QUANTITY");
            var fLen = Add("REBAR_ELEM_LENGTH", "REBAR_ELEM_TOTAL_LENGTH");
            var fMark = Add("ALL_MODEL_MARK");
            var fCom = Add("ALL_MODEL_INSTANCE_COMMENTS");
            if (fCom != null) { fCom.IsHidden = true; def.AddFilter(new ScheduleFilter(fCom.FieldId, ScheduleFilterType.Equal, ReinforceCommand.Tag)); }
            if (fHost != null) def.AddSortGroupField(new ScheduleSortGroupField(fHost.FieldId));
            if (fDia != null) def.AddSortGroupField(new ScheduleSortGroupField(fDia.FieldId));
            if (fMark != null) def.AddSortGroupField(new ScheduleSortGroupField(fMark.FieldId));
            try { if (fQty != null) fQty.DisplayType = ScheduleFieldDisplayType.Totals; if (fLen != null) fLen.DisplayType = ScheduleFieldDisplayType.Totals; def.ShowGrandTotal = true; } catch { }
            ScheduleSheetInstance.Create(doc, sh.Id, sch.Id, new XYZ(L, T, 0));
        }
        catch (Exception ex) { cnt.Notes.Add("Tableau de nomenclature : " + ex.Message); }

        // 1 bis) contrôle des ancrages, recouvrements et cintrages (escaliers) : colonnes issues des paramètres partagés écrits par « Créer armatures »
        try
        {
            var probe = ViewSchedule.CreateSchedule(doc, new ElementId(BuiltInCategory.OST_Rebar));
            var pf = probe.Definition.GetSchedulableFields();
            if (pf.Any(f => f.GetName(doc) == "SC_Escalier"))
            {
                var cs = ViewSheet.Create(doc, tbId);
                cs.SheetNumber = UniqueSheetNumber(doc, SheetPrefix + "CTRL-01"); cs.Name = "Contrôle des ancrages, recouvrements et cintrages";
                StampSheet(cs); cnt.Sheets++; cnt.SheetIds.Add(cs.Id);
                probe.Name = UniqueName(doc, Prefix + "Contrôle escaliers");
                var pd = probe.Definition; pd.IsItemized = true;
                var allF = pd.GetSchedulableFields();
                ScheduleField? AddF(string name, string heading)
                {
                    var sf = allF.FirstOrDefault(f => f.GetName(doc) == name);
                    if (sf == null) return null;
                    var fld = pd.AddField(sf); fld.ColumnHeading = heading; return fld;
                }
                if (Enum.TryParse<BuiltInParameter>("REBAR_ELEM_HOST_MARK", out var hm)) { var sf = allF.FirstOrDefault(f => f.ParameterId == new ElementId(hm)); if (sf != null) pd.AddField(sf).ColumnHeading = "Ouvrage"; }
                if (Enum.TryParse<BuiltInParameter>("ALL_MODEL_MARK", out var mk)) { var sf = allF.FirstOrDefault(f => f.ParameterId == new ElementId(mk)); if (sf != null) pd.AddField(sf).ColumnHeading = "Rôle"; }
                if (Enum.TryParse<BuiltInParameter>("REBAR_BAR_DIAMETER", out var bd)) { var sf = allF.FirstOrDefault(f => f.ParameterId == new ElementId(bd)); if (sf != null) pd.AddField(sf).ColumnHeading = "Ø"; }
                if (Enum.TryParse<BuiltInParameter>("REBAR_ELEM_LENGTH", out var bl)) { var sf = allF.FirstOrDefault(f => f.ParameterId == new ElementId(bl)); if (sf != null) pd.AddField(sf).ColumnHeading = "Longueur développée"; }
                var fEsc = AddF("SC_Escalier", "Escalier");
                AddF("SC_Ancrage_statut", "Ancrage / recouvrement"); AddF("SC_Ancrage_requis_mm", "Requis (mm)"); AddF("SC_Ancrage_disponible_mm", "Disponible (mm)");
                AddF("SC_Cintrage_rayon_reel_mm", "Contrôle cintrage - rayon réel (mm)"); AddF("SC_Cintrage_rayon_mini_mm", "Contrôle cintrage - rayon mini (mm)");
                AddF("SC_Cintrage_droit_reel_mm", "Contrôle cintrage - longueur droite réelle (mm)"); AddF("SC_Cintrage_droit_mini_mm", "Contrôle cintrage - longueur droite mini (mm)");
                AddF("SC_Cintrage_statut", "Contrôle cintrage - statut"); AddF("SC_Cintrage_commentaire", "Contrôle cintrage - commentaire");
                if (fEsc != null) pd.AddFilter(new ScheduleFilter(fEsc.FieldId, ScheduleFilterType.Equal, "1"));
                ScheduleSheetInstance.Create(doc, cs.Id, probe.Id, new XYZ(L, T, 0));
            }
            else doc.Delete(probe.Id);
        }
        catch (Exception ex) { cnt.Notes.Add("Tableau de contrôle des escaliers : " + ex.Message); }

        // 2) récapitulatif : acier, béton, ratio par ouvrage, puis par type
        var lines = new List<string>();
        foreach (var g in hosts.GroupBy(x => (Group: GroupName(x), x.Lv.Name)).OrderBy(g => g.Key.Group).ThenBy(g => g.Key.Name))
        {
            lines.Add($"{g.Key.Group} - {g.Key.Name}");
            foreach (var h in g.OrderBy(x => x.Label))
                lines.Add("    " + $"{h.Label} : acier {h.Kg.ToString("0", CultureInfo.InvariantCulture)} kg" + (h.Vol > 0.001 ? $", béton {h.Vol.ToString("0.00", CultureInfo.InvariantCulture)} m³, {(h.Kg / h.Vol).ToString("0", CultureInfo.InvariantCulture)} kg/m³" : ""));
            double kg = g.Sum(x => x.Kg), vol = g.Sum(x => x.Vol);
            lines.Add($"    Total : acier {kg.ToString("0", CultureInfo.InvariantCulture)} kg" + (vol > 0.001 ? $", béton {vol.ToString("0.0", CultureInfo.InvariantCulture)} m³, {(kg / vol).ToString("0", CultureInfo.InvariantCulture)} kg/m³" : ""));
            lines.Add("");
        }
        double kgAll = hosts.Sum(x => x.Kg), volAll = hosts.Sum(x => x.Vol);
        lines.Add($"TOTAL OUVRAGES ARMÉS : acier {kgAll.ToString("0", CultureInfo.InvariantCulture)} kg" + (volAll > 0.001 ? $", béton {volAll.ToString("0.0", CultureInfo.InvariantCulture)} m³, {(kgAll / volAll).ToString("0", CultureInfo.InvariantCulture)} kg/m³" : ""));
        try
        {
            string rf = System.IO.Path.Combine(StructCalc.Engine.RevitLink.Dir, "controle", "resume.txt");
            if (System.IO.File.Exists(rf)) { lines.Add(""); lines.AddRange(System.IO.File.ReadAllLines(rf)); }
        }
        catch { }
        lines.Add("Poids d'acier = longueur développée x nombre de barres x section x 7850 kg/m³ (hors crochets non modélisés).");

        double lineH = textSize * 1.4;
        int perSheet = Math.Max(10, (int)((T - B) / lineH) - 3);
        var opts = new TextNoteOptions(textType) { HorizontalAlignment = HorizontalTextAlignment.Left, VerticalAlignment = VerticalTextAlignment.Top };
        for (int i = 0, k = 1; i < lines.Count; i += perSheet, k++)
        {
            var rs = ViewSheet.Create(doc, tbId);
            rs.SheetNumber = UniqueSheetNumber(doc, SheetPrefix + "REC-" + k.ToString("00")); rs.Name = "Récapitulatif acier / béton" + (k > 1 ? $" ({k})" : "");
            StampSheet(rs); cnt.Sheets++; cnt.SheetIds.Add(rs.Id);
            string txt = string.Join("\r", lines.Skip(i).Take(perSheet).Select(l => l.Replace("    ", "      ")));
            TextNote.Create(doc, rs.Id, new XYZ(L, T, 0), Math.Min(R - L, 260 * Mm), txt, opts);
        }
        cnt.Extra = $"Récapitulatif : {kgAll.ToString("0", CultureInfo.InvariantCulture)} kg d'acier" + (volAll > 0.001 ? $", {volAll.ToString("0.0", CultureInfo.InvariantCulture)} m³ de béton ({(kgAll / volAll).ToString("0", CultureInfo.InvariantCulture)} kg/m³)." : ".");
    }

    private static string GroupName(Host h) => h.Kind switch { "Beam" => "Poutres", "Column" => "Poteaux", "Footing" or "Strip" => "Fondations", "Wall" => "Voiles", "Stair" => "Escaliers", _ => h.Label.StartsWith("Fondation") ? "Fondations" : "Dalles" };

    private static string UniqueSheetNumber(Document doc, string num)
    {
        var used = new HashSet<string>(new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Select(x => x.SheetNumber));
        string n = num; int u = 2;
        while (used.Contains(n)) n = num + "." + u++;
        return n;
    }

    /// <summary>Renseigne les champs du cartouche qui existent (date, dessinateur) ; ignore silencieusement les autres.</summary>
    private static void StampSheet(ViewSheet sh)
    {
        foreach (var (name, val) in new[] { ("SHEET_ISSUE_DATE", DateTime.Now.ToString("dd/MM/yyyy")), ("SHEET_DRAWN_BY", "StructCalc") })
        {
            try { if (Enum.TryParse<BuiltInParameter>(name, out var bip)) { var pr = sh.get_Parameter(bip); if (pr != null && !pr.IsReadOnly) pr.Set(val); } } catch { }
        }
    }

    // ------------------------------------------------------------------ exports PDF / DWG (hors transaction)
    private static void ExportSheets(Document doc, PlansOptions opt, Counters cnt)
    {
        if (cnt.SheetIds.Count == 0 || (!opt.ExportPdf && !opt.ExportDwg)) return;
        string dir = System.IO.Path.Combine(StructCalc.Engine.RevitLink.Dir, "plans");
        System.IO.Directory.CreateDirectory(dir);
        var ids = cnt.SheetIds.ToList();
        if (opt.ExportPdf)
        {
            try { doc.Export(dir, ids, new PDFExportOptions { FileName = "StructCalc_plans", Combine = true }); cnt.Extra += "\nPDF : " + dir; }
            catch (Exception ex) { cnt.Notes.Add("Export PDF : " + ex.Message); }
        }
        if (opt.ExportDwg)
        {
            try { doc.Export(dir, "StructCalc_plans", ids, new DWGExportOptions()); cnt.Extra += "\nDWG : " + dir; }
            catch (Exception ex) { cnt.Notes.Add("Export DWG : " + ex.Message); }
        }
    }

    // ------------------------------------------------------------------ feuilles : rangement par type et par niveau, sans chevauchement de vues
    private static void PlaceOnSheets(Document doc, List<Job> jobs, ElementId tbId, PlansOptions opt, double sheetW, double sheetH, Counters cnt)
    {
        double L = opt.LeftMm * Mm, R = sheetW - opt.RightMm * Mm, B = opt.BottomMm * Mm, T = sheetH - opt.TopMm * Mm, gap = 6 * Mm;
        foreach (var grp in jobs.GroupBy(j => (j.Group, j.Level)).OrderBy(g => g.Key.Group).ThenBy(g => g.Key.Level))
        {
            string code = (grp.Key.Group.Substring(0, 3) + "-" + Regex.Replace(grp.Key.Level, @"[^\w]", "")).ToUpperInvariant();
            int k = 0;
            ViewSheet? sheet = null;
            double x = L, yTop = T, rowH = 0;
            foreach (var j in grp.OrderByDescending(j => j.HPaper).ThenByDescending(j => j.WPaper))
            {
                if (sheet != null)
                {
                    if (x + j.WPaper > R && x > L) { x = L; yTop -= rowH + gap; rowH = 0; }
                    if (yTop - j.HPaper < B && (yTop < T - 1e-6)) sheet = null;           // plus de place : feuille suivante
                }
                if (sheet == null)
                {
                    sheet = ViewSheet.Create(doc, tbId);
                    k++;
                    string num = SheetPrefix + code + "-" + k.ToString("00");
                    int u = 2; while (new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Any(s => s.SheetNumber == num)) num = SheetPrefix + code + "-" + k.ToString("00") + "." + u++;
                    sheet.SheetNumber = num;
                    sheet.Name = $"{grp.Key.Group} - {grp.Key.Level}";
                    StampSheet(sheet);
                    cnt.SheetIds.Add(sheet.Id);
                    cnt.Sheets++;
                    x = L; yTop = T; rowH = 0;
                }
                if (j.WPaper > R - L + 1e-6 || j.HPaper > T - B + 1e-6) cnt.NoFit++;
                var center = new XYZ(x + j.WPaper / 2, yTop - (j.HPaper - 12 * Mm) / 2 - 0 * Mm, 0);
                try { Viewport.Create(doc, sheet.Id, j.View.Id, center); }
                catch (Exception ex) { cnt.Notes.Add($"{j.Title} : placement impossible ({ex.Message})"); continue; }
                x += j.WPaper + gap; rowH = Math.Max(rowH, j.HPaper);
            }
        }
    }
}
