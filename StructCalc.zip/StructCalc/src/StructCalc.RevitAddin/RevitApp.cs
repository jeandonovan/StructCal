using System.Reflection;
using Autodesk.Revit.UI;

namespace StructCalc.RevitAddin;

/// <summary>Crée le panneau StructCalc dans l'onglet Compléments (Add-Ins) de Revit.</summary>
public class RevitApp : IExternalApplication
{
    public Result OnStartup(UIControlledApplication app)
    {
        var panel = app.CreateRibbonPanel("StructCalc");
        string asm = Assembly.GetExecutingAssembly().Location;
        panel.AddItem(new PushButtonData("SC_Check", "Vérifier\nle modèle", asm, typeof(CheckCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("check", 32), Image = RibbonIcons.Make("check", 16),
            ToolTip = "Contrôle le modèle avant l'envoi : éléments ignorés, sections illisibles, familles sans paramètres b/h, couches sans « Structure »... Ne modifie rien."
        });
        panel.AddItem(new PushButtonData("SC_Export", "Envoyer vers\nStructCalc", asm, typeof(ExportCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("send", 32), Image = RibbonIcons.Make("send", 16),
            ToolTip = "Exporte niveaux, axes, poteaux, poutres et dalles (la sélection si vous en avez une, sinon tout le modèle) et ouvre StructCalc directement."
        });
        panel.AddItem(new PushButtonData("SC_Create", "Créer le\nmodèle", asm, typeof(CreateModelCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("create", 32), Image = RibbonIcons.Make("create", 16),
            ToolTip = "Crée dans Revit les poteaux, poutres et dalles béton du modèle envoyé par StructCalc (niveaux, sections, dalles). Ne recrée pas un élément déjà lié. Voiles, escaliers, fondations : non créés."
        });
        panel.AddItem(new PushButtonData("SC_Import", "Importer\nrésultats", asm, typeof(ImportCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("results", 32), Image = RibbonIcons.Make("results", 16),
            ToolTip = "Reprend les résultats envoyés par StructCalc : résumé dans le champ Commentaires et couleur vert / rouge dans la vue active."
        });
        panel.AddItem(new PushButtonData("SC_Plans", "Importer\nplans", asm, typeof(ImportPlansCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("plans", 32), Image = RibbonIcons.Make("plans", 16),
            ToolTip = "Crée dans Revit les plans d'exécution calculés par StructCalc (ferraillage, coffrage...) : une vue de dessin et une feuille par planche."
        });
        panel.AddItem(new PushButtonData("SC_Rebar", "Créer\narmatures", asm, typeof(ReinforceCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("rebar", 32), Image = RibbonIcons.Make("rebar", 16),
            ToolTip = "Crée dans Revit les vraies armatures calculées par StructCalc sur les poteaux et poutres béton (barres longitudinales et cadres)."
        });
        panel.AddItem(new PushButtonData("SC_ExecPlans", "Plans\nd'exécution", asm, typeof(ExecutionPlansCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("exec", 32), Image = RibbonIcons.Make("exec", 16),
            ToolTip = "Crée de vraies vues Revit (coupes, plans) des poutres, poteaux et dalles armés, avec fers cliquables et étiquettes sans chevauchement, rangées sur des feuilles avec cartouche. Faites d'abord « Créer armatures »."
        });
        panel.AddItem(new PushButtonData("SC_Open", "Ouvrir\nStructCalc", asm, typeof(OpenCommand).FullName)
        {
            LargeImage = RibbonIcons.Make("open", 32), Image = RibbonIcons.Make("open", 16),
            ToolTip = "Lance StructCalc sans exporter."
        });
        return Result.Succeeded;
    }

    public Result OnShutdown(UIControlledApplication app) => Result.Succeeded;
}
