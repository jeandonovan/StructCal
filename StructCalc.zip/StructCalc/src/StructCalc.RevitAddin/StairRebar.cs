using System.Globalization;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Associations explicites volée -> palier de départ / palier d'arrivée d'un escalier Revit (détectées par la géométrie, corrigeables par l'utilisateur).</summary>
internal sealed class StairPlan
{
    public List<Autodesk.Revit.DB.Architecture.StairsRun> Runs = new();
    public List<Autodesk.Revit.DB.Architecture.StairsLanding> Lands = new();
    public int[] Start = Array.Empty<int>(), End = Array.Empty<int>();          // indice de palier, -1 = aucun (sol, dalle)
    public List<string> RunNames = new(), LandNames = new();
}

/// <summary>Armatures 3D des escaliers à paillasse : nappe pliée en bas, barres croisées en haut (jamais pliées vers l'extérieur du béton), épingles et étriers fermés distincts, renfort d'angle.</summary>
internal static class StairRebar
{
    private const double MM = ReinforceCommand.MM;
    private const double Ft = 0.3048;

    public static StairPlan? Detect(Document doc, Element? el)
    {
        if (el is not Autodesk.Revit.DB.Architecture.Stairs st) return null;
        double ZMin(Element e) => e.get_BoundingBox(null)?.Min.Z ?? 0;
        var pl = new StairPlan
        {
            Runs = st.GetStairsRuns().Select(id => doc.GetElement(id)).OfType<Autodesk.Revit.DB.Architecture.StairsRun>().OrderBy(ZMin).ToList(),
            Lands = st.GetStairsLandings().Select(id => doc.GetElement(id)).OfType<Autodesk.Revit.DB.Architecture.StairsLanding>().OrderBy(ZMin).ToList()
        };
        if (pl.Runs.Count == 0) return null;
        pl.Start = Enumerable.Repeat(-1, pl.Runs.Count).ToArray();
        pl.End = Enumerable.Repeat(-1, pl.Runs.Count).ToArray();
        int NearestLanding(XYZ p, int exclude)
        {
            int best = -1; double bd = double.MaxValue;
            for (int k = 0; k < pl.Lands.Count; k++)
            {
                if (k == exclude) continue;
                var bb = pl.Lands[k].get_BoundingBox(null);
                if (bb == null) continue;
                double tol = 0.7;
                if (p.X < bb.Min.X - tol || p.X > bb.Max.X + tol || p.Y < bb.Min.Y - tol || p.Y > bb.Max.Y + tol || Math.Abs(p.Z - bb.Max.Z) > 1.2) continue;
                double d = new XYZ((bb.Min.X + bb.Max.X) / 2 - p.X, (bb.Min.Y + bb.Max.Y) / 2 - p.Y, 0).GetLength();
                if (d < bd) { bd = d; best = k; }
            }
            return best;
        }
        for (int i = 0; i < pl.Runs.Count; i++)
        {
            try
            {
                var path = pl.Runs[i].GetStairsPath().ToList();
                if (path.Count == 0) continue;
                XYZ a = path[0].GetEndPoint(0), b = path[^1].GetEndPoint(1);
                if (b.Z < a.Z) (a, b) = (b, a);
                pl.Start[i] = NearestLanding(a, -1);
                pl.End[i] = NearestLanding(b, pl.Start[i]);
            }
            catch { }
        }
        for (int i = 0; i < pl.Runs.Count; i++) pl.RunNames.Add($"Volée {i + 1} (z {ZMin(pl.Runs[i]) * Ft:0.00} m)");
        for (int k = 0; k < pl.Lands.Count; k++) pl.LandNames.Add($"Palier {k + 1} (z {ZMin(pl.Lands[k]) * Ft:0.00} m)");
        return pl;
    }

    private static string Cm(double ft) => (ft * Ft * 100).ToString("0", CultureInfo.InvariantCulture);

    public static int Reinforce(Document doc, StairPlan pl, RevitSummaryItem it, Dictionary<int, RebarBarType?> types, StairTransOptions opt, StairCheckSet chk, out string err)
    {
        err = "";
        var runs = pl.Runs; var lands = pl.Lands;
        int N = it.Extra.TryGetValue("N", out var ns) && int.TryParse(ns, out var nn) ? Math.Max(1, nn) : 1;
        double c = Math.Max(it.Cover, 0.02) / Ft, thick = it.H / Ft;
        var notes = new List<string>();
        int count = 0;
        var runU = new List<XYZ?>();                       // sens de la volée (en plan) pour chaque volée
        var runLeg = new List<double>(); var runDia = new List<int>();   // équerre de tête (pieds) et diamètre des principales de chaque volée
        double fc = it.Extra.TryGetValue("fc28", out var fcs) && double.TryParse(fcs, NumberStyles.Float, CultureInfo.InvariantCulture, out var fcv) ? fcv : 25;
        double fe = it.Extra.TryGetValue("fe", out var fes) && double.TryParse(fes, NumberStyles.Float, CultureInfo.InvariantCulture, out var fev) ? fev : 500;
        RebarHookType? hook135 = ReinforceCommand.GetHook(doc, 135.0, "135");
        bool transverse = (opt.Pins || opt.Closed);
        double coverMm = c * 304.8, coverMinMm = Math.Max(it.Cover, 0.02) * 1000;

        string? E(string k, int ei) => it.Extra.TryGetValue(k + "_" + (ei + 1), out var v) ? v : null;
        double BendDia(int dia) { try { return (ReinforceCommand.BarTypeFor(doc, types, dia)?.StandardBendDiameter) ?? 0; } catch { return 0; } }
        void Bends(string elem, string role, int dia, IList<XYZ> poly, XYZ nIn, bool top, bool tension, bool loop = false)
        {
            var r = ReinforceCommand.LastRebar; if (r == null) return;
            chk.AddBends(elem, role, r.Id.Value, dia, poly, top ? nIn : nIn.Negate(), BendDia(dia), coverMm, coverMinMm, tension, transverse, loop);
        }
        long LastId() => ReinforceCommand.LastRebar?.Id.Value ?? 0;

        // volée : barre principale pliée en bas / équerre en haut, répartition, chapeaux, étriers fermés ; renvoie le nombre de jeux créés
        int ArmRun(Autodesk.Revit.DB.Architecture.StairsRun host, XYZ o, XYZ nIn, XYZ u, List<XYZ> pts, int idx, bool linkedStart, bool linkedEnd)
        {
            string name = $"Volée {idx + 1}";
            if (!ReinforceCommand.EnsureConcreteHost(doc, host, notes, name)) { runU.Add(null); runLeg.Add(0); runDia.Add(0); return 0; }
            foreach (var old in RebarHostData.GetRebarHostData(host)!.GetRebarsInHost().ToList())
                if (old.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() == ReinforceCommand.Tag) doc.Delete(old.Id);
            int ei = Math.Min(idx, N - 1);
            XYZ v = XYZ.BasisZ.CrossProduct(u).Normalize();
            if (pts.Count < 3) { notes.Add($"{name} : géométrie illisible"); runU.Add(null); runLeg.Add(0); runDia.Add(0); return 0; }
            double u0 = pts.Min(p => (p - o).DotProduct(u)), u1 = pts.Max(p => (p - o).DotProduct(u));
            double v0 = pts.Min(p => (p - o).DotProduct(v)), v1 = pts.Max(p => (p - o).DotProduct(v));
            XYZ W(double a, double b, double h) => o + u.Multiply(a) + v.Multiply(b) + nIn.Multiply(h);
            int k = 0;
            bool okM = ReinforceCommand.ParseBars(E("Main", ei), out int dM, out double sM);
            bool okD = ReinforceCommand.ParseBars(E("Distr", ei), out int dD, out double sD);
            bool okA = ReinforceCommand.ParseBars(E("TopA", ei), out int dA, out double sA);
            bool okB = ReinforceCommand.ParseBars(E("TopB", ei), out int dB, out double sB);
            var tM = okM ? ReinforceCommand.BarTypeFor(doc, types, dM) : null;
            if (tM == null) { notes.Add($"{name} : pas d'armature principale exploitable"); runU.Add(null); runLeg.Add(0); runDia.Add(0); return 0; }
            double wv = v1 - v0 - 2 * c, room = Math.Max(thick - 2 * c, 0.1);
            double h1 = c + dM * MM / 2, legM = Math.Min(10 * dM * MM, room - dM * MM);
            XYZ f = new XYZ(u.X, u.Y, 0).GetLength() > 0.01 ? new XYZ(u.X, u.Y, 0).Normalize() : u;
            double before = it.Extra.TryGetValue("Before_" + (ei + 1), out var bq) && double.TryParse(bq, NumberStyles.Float, CultureInfo.InvariantCulture, out var bqv) ? bqv / Ft : 0;
            double zoneL = Math.Max(1.5 * thick, 0.30 / Ft);
            runU.Add(f); runLeg.Add(legM); runDia.Add(dM);

            double tJ = u.Z > 0.05 ? h1 * (1 - nIn.Z) / u.Z : 0;
            XYZ J0 = W(u0, v0 + c, h1) + u.Multiply(tJ);
            bool lowLand = linkedStart && before > 2 * c;
            var poly = new List<XYZ>();
            if (lowLand) { poly.Add(J0 - f.Multiply(before - c)); poly.Add(J0); } else { poly.Add(W(u0 + c, v0 + c, h1 + legM)); poly.Add(W(u0 + c, v0 + c, h1)); }
            poly.Add(W(u1 - c, v0 + c, h1)); poly.Add(W(u1 - c, v0 + c, h1 + legM));
            string role = lowLand ? "Principale pliée" : "Principale";
            if (ReinforceCommand.MakePoly(doc, host, tM, poly, v, wv, sM, role))
            {
                k++;
                long id = LastId();
                Bends(name, role, dM, poly, nIn, false, true);
                // ancrage du départ : prolongement dans le palier de départ (nappe pliée) ou équerre seule
                double availStart = lowLand ? (before - c) * 304.8 : legM * 304.8;
                chk.AddAnchor(false, name, role, id, dM, fe, fc, availStart, lowLand ? "départ : prolongée dans le palier de départ" : "départ : équerre vers l'intérieur", lowLand ? "" : "appui de départ non modélisé : ancrage réel à confirmer");
                // ancrage de l'arrivée : équerre vers l'intérieur (le recouvrement avec le palier est contrôlé côté palier)
                if (!linkedEnd) chk.AddAnchor(false, name, role, id, dM, fe, fc, legM * 304.8, "arrivée : équerre vers l'intérieur", "pas de palier d'arrivée associé : appui d'arrivée non modélisé");
            }
            double zTop = thick - 2 * c - dM * MM, half = Math.Max(0.4 / Ft, 40 * dM * MM);
            if (lowLand)
            {
                var corner = new List<XYZ> { J0 - f.Multiply(half) + XYZ.BasisZ.Multiply(zTop), J0 + f.Multiply(half) + XYZ.BasisZ.Multiply(zTop) };
                if (ReinforceCommand.MakeBar(doc, host, tM, corner[0], corner[1], v, wv, sM, "Renfort d'angle")) k++;
            }
            if (linkedEnd && opt.Closed && ReinforceCommand.BarTypeFor(doc, types, opt.DiaMm) is RebarBarType tS && u1 - zoneL > u0)
            {
                double a0 = u1 - zoneL;
                var rect = new List<XYZ> { W(a0, v0 + c, c), W(a0, v1 - c, c), W(a0, v1 - c, thick - c), W(a0, v0 + c, thick - c) };
                if (MakeClosed(doc, host, tS, hook135, rect, u, zoneL - c, opt.SpacingCm, "Étrier fermé")) { k++; Bends(name, "Étrier fermé", opt.DiaMm, new List<XYZ> { rect[0], rect[1], rect[2], rect[3], rect[0], rect[1] }, nIn, false, false, true); }
            }
            if (okD && ReinforceCommand.BarTypeFor(doc, types, dD) is RebarBarType tD)
            {
                double h2 = h1 + dM * MM / 2 + dD * MM / 2;
                if (ReinforceCommand.MakeBar(doc, host, tD, W(u0 + c, v0 + c, h2), W(u0 + c, v1 - c, h2), u, u1 - u0 - 2 * c, sD, "Répartition")) k++;
            }
            double span = it.Extra.TryGetValue("Span_" + (ei + 1), out var sp) && double.TryParse(sp, NumberStyles.Float, CultureInfo.InvariantCulture, out var spv) ? spv / Ft : (u1 - u0);
            double band = Math.Min(0.25 * Math.Max(span, 0.5), 0.45 * (u1 - u0));
            foreach (var (ok, dia, spc, atStart) in new[] { (okA, dA, sA, true), (okB, dB, sB, false) })
            {
                if (!ok || ReinforceCommand.BarTypeFor(doc, types, dia) is not RebarBarType tt) continue;
                double ht = thick - c - dia * MM / 2, leg = Math.Min(Math.Max(room - dia * MM, 0.05), 0.5 * thick);
                var cp = atStart ? new List<XYZ> { W(u0 + band, v0 + c, ht), W(u0 + c, v0 + c, ht), W(u0 + c, v0 + c, ht - leg) }
                                 : new List<XYZ> { W(u1 - band, v0 + c, ht), W(u1 - c, v0 + c, ht), W(u1 - c, v0 + c, ht - leg) };
                if (ReinforceCommand.MakePoly(doc, host, tt, cp, v, wv, spc, "Chapeau"))
                {
                    k++;
                    Bends(name, "Chapeau", dia, cp, nIn, true, true);
                    chk.AddAnchor(false, name, "Chapeau", LastId(), dia, fe, fc, (band - c) * 304.8 + leg * 304.8, atStart ? "appui de départ : chapeau" : "appui d'arrivée : chapeau", "appui non modélisé : longueur prise dans la volée + retour");
                }
            }
            return k;
        }

        // palier : relié explicitement à zéro, une ou plusieurs volées qui y aboutissent / en partent
        int ArmLanding(Autodesk.Revit.DB.Architecture.StairsLanding host, PlanarFace face, int kLand, List<int> arrivals, List<int> departs)
        {
            string name = $"Palier {kLand + 1}";
            if (!ReinforceCommand.EnsureConcreteHost(doc, host, notes, name)) return 0;
            foreach (var old in RebarHostData.GetRebarHostData(host)!.GetRebarsInHost().ToList())
                if (old.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() == ReinforceCommand.Tag) doc.Delete(old.Id);
            var pts = new List<XYZ>();
            foreach (CurveLoop cl in face.GetEdgesAsCurveLoops()) foreach (Curve cv in cl) { pts.Add(cv.GetEndPoint(0)); pts.Add(cv.GetEndPoint(1)); }
            if (pts.Count < 3) { notes.Add($"{name} : géométrie illisible"); return 0; }
            XYZ o = face.Origin, nIn = XYZ.BasisZ;
            int k = 0;
            var nearPts = new List<(int Run, XYZ P, XYZ Dir, double ZoneEnd)>();
            XYZ firstDir = arrivals.Count > 0 ? runU[arrivals[0]]! : (departs.Select(j => runU[j]).FirstOrDefault(x => x != null) ?? XYZ.BasisX);
            // une série de barres de recouvrement par volée qui aboutit (sens propre à chaque volée)
            foreach (int j in arrivals)
            {
                XYZ u = runU[j]!;
                XYZ v = XYZ.BasisZ.CrossProduct(u).Normalize();
                int ei = Math.Min(j, N - 1);
                double u0 = pts.Min(p => (p - o).DotProduct(u)), u1 = pts.Max(p => (p - o).DotProduct(u));
                double v0 = pts.Min(p => (p - o).DotProduct(v)), v1 = pts.Max(p => (p - o).DotProduct(v));
                XYZ W(double a, double b, double h) => o + u.Multiply(a) + v.Multiply(b) + nIn.Multiply(h);
                if (!ReinforceCommand.ParseBars(E("Main", ei), out int dM, out double sM) || ReinforceCommand.BarTypeFor(doc, types, dM) is not RebarBarType tM) { notes.Add($"{name} : pas d'armature principale pour la volée {j + 1}"); continue; }
                double wv = v1 - v0 - 2 * c, room = Math.Max(thick - 2 * c, 0.1);
                double hL = c + dM * MM / 2, legM = Math.Min(10 * dM * MM, room - dM * MM);
                double zoneL = Math.Max(1.5 * thick, 0.30 / Ft);
                double g0 = u0 + dM * MM * 1.5;
                string elem = $"{name} / volée {j + 1}";
                var poly = new List<XYZ> { W(g0, v0 + c, hL + legM), W(g0, v0 + c, hL), W(u1 - c, v0 + c, hL), W(u1 - c, v0 + c, hL + legM) };
                string roleL = "Principale palier (recouvrement)";
                if (ReinforceCommand.MakePoly(doc, host, tM, poly, v, wv, sM, roleL))
                {
                    k++;
                    long id = LastId();
                    Bends(elem, roleL, dM, poly, nIn, false, true);
                    // recouvrement avec les barres de la volée : équerres juxtaposées ; disponible = plus courte des deux équerres
                    double avail = Math.Min(legM, runLeg[j]) * 304.8;
                    var row = chk.AddAnchor(true, elem, roleL, id, dM, fe, fc, avail, $"zone de recouvrement à 0 - {zoneL * 304.8 / 10:0} cm du bord du palier côté volée {j + 1} (hauteur de béton {room * 304.8 / 10:0} cm)",
                                            "toutes les barres sont recouvertes dans la même section : à décaler (au moins 1,3 lr entre barres voisines) ou à renforcer par la couture et les étriers");
                    if (row.Status == "Vérifiée") row.Comment = "recouvrement non décalé entre barres voisines : à confirmer";
                    // ancrage de l'extrémité opposée du palier (appui non modélisé)
                    chk.AddAnchor(false, elem, roleL, id, dM, fe, fc, legM * 304.8, "extrémité opposée du palier : équerre", "appui non modélisé : ancrage réel à confirmer");
                }
                if (opt.Pins && ReinforceCommand.BarTypeFor(doc, types, opt.DiaMm) is RebarBarType tP)
                {
                    double xa = u0 - 3 * dM * MM, xb = u0 + 6 * dM * MM, zb = c, zt = thick - c;
                    var pin = new List<XYZ> { W(xa, v0 + c, zt), W(xa, v0 + c, zb), W(xb, v0 + c, zb), W(xb, v0 + c, zt) };
                    if (ReinforceCommand.MakePoly(doc, host, tP, pin, v, wv, opt.SpacingCm, "Épingle")) { k++; Bends(elem, "Épingle", opt.DiaMm, pin, nIn, false, false); }
                }
                if (opt.Closed && ReinforceCommand.BarTypeFor(doc, types, opt.DiaMm) is RebarBarType tS)
                {
                    var rect = new List<XYZ> { W(u0 + c, v0 + c, c), W(u0 + c, v1 - c, c), W(u0 + c, v1 - c, thick - c), W(u0 + c, v0 + c, thick - c) };
                    if (MakeClosed(doc, host, tS, hook135, rect, u, zoneL - c, opt.SpacingCm, "Étrier fermé")) { k++; Bends(elem, "Étrier fermé", opt.DiaMm, new List<XYZ> { rect[0], rect[1], rect[2], rect[3], rect[0], rect[1] }, nIn, false, false, true); }
                }
                double half = Math.Max(0.4 / Ft, 40 * dM * MM), zc = thick - 2 * c - dM * MM;
                if (ReinforceCommand.MakeBar(doc, host, tM, W(u0 - half, v0 + c, zc), W(u0 + half, v0 + c, zc), v, wv, sM, "Couture")) { k++; Bends(elem, "Couture", dM, new List<XYZ> { W(u0 - half, v0 + c, zc), W(u0 + half, v0 + c, zc) }, nIn, true, true); }
                nearPts.Add((j, W(u0, (v0 + v1) / 2, 0), u, zoneL));
            }
            // deux volées qui aboutissent au même endroit du palier avec des recouvrements superposés
            for (int a = 0; a < nearPts.Count; a++)
                for (int b = a + 1; b < nearPts.Count; b++)
                    if (new XYZ(nearPts[a].P.X - nearPts[b].P.X, nearPts[a].P.Y - nearPts[b].P.Y, 0).GetLength() < 0.6 / Ft * 1.0 + 0.5 && Math.Abs(nearPts[a].Dir.DotProduct(nearPts[b].Dir)) > 0.9)
                        chk.Warnings.Add($"{name} : les recouvrements des volées {nearPts[a].Run + 1} et {nearPts[b].Run + 1} se superposent au même endroit du palier - revoir la disposition (largeur, décalage).");
            // répartition du palier (perpendiculaire aux principales)
            {
                XYZ u = firstDir; XYZ v = XYZ.BasisZ.CrossProduct(u).Normalize();
                int ei = Math.Min(arrivals.Count > 0 ? arrivals[0] : (departs.Count > 0 ? departs[0] : Math.Min(kLand, N - 1)), N - 1);
                double u0 = pts.Min(p => (p - o).DotProduct(u)), u1 = pts.Max(p => (p - o).DotProduct(u));
                double v0 = pts.Min(p => (p - o).DotProduct(v)), v1 = pts.Max(p => (p - o).DotProduct(v));
                XYZ W(double a, double b, double h) => o + u.Multiply(a) + v.Multiply(b) + nIn.Multiply(h);
                if (ReinforceCommand.ParseBars(E("Distr", ei), out int dD, out double sD) && ReinforceCommand.BarTypeFor(doc, types, dD) is RebarBarType tL
                    && ReinforceCommand.MakeBar(doc, host, tL, W(u0 + c, v0 + c, c + dD * MM / 2), W(u0 + c, v1 - c, c + dD * MM / 2), u, u1 - u0 - 2 * c, sD, "Répartition")) k++;
            }
            chk.Warnings.Add($"Info {name} : volées qui y aboutissent = {(arrivals.Count == 0 ? "aucune" : string.Join(", ", arrivals.Select(a => a + 1)))} ; volées qui en partent = {(departs.Count == 0 ? "aucune" : string.Join(", ", departs.Select(a => a + 1)))}.");
            return k;
        }

        for (int i = 0; i < runs.Count; i++)
        {
            var face = ReinforceCommand.Underside(runs[i], true);
            XYZ u, nIn, o; List<XYZ> pts;
            if (face != null)
            {
                XYZ nb = face.FaceNormal;
                u = XYZ.BasisZ.Subtract(nb.Multiply(XYZ.BasisZ.DotProduct(nb))).Normalize();
                nIn = nb.Negate(); o = face.Origin;
                pts = new List<XYZ>();
                foreach (CurveLoop cl in face.GetEdgesAsCurveLoops()) foreach (Curve cv in cl) { pts.Add(cv.GetEndPoint(0)); pts.Add(cv.GetEndPoint(1)); }
            }
            else if (!ReinforceCommand.SoffitFromPath(runs[i], out o, out nIn, out u, out pts, out string why))
            {
                notes.Add($"Volée {i + 1} : {why}"); runU.Add(null); runLeg.Add(0); runDia.Add(0); continue;
            }
            else notes.Add($"Volée {i + 1} : sous-face à marches, plan de pose déduit de la pente (à vérifier)");
            if (pl.Start[i] < 0) { notes.Add($"Volée {i + 1} : aucun palier de départ associé (départ sur sol ou dalle ?)"); chk.Warnings.Add($"Volée {i + 1} : pas de palier de départ."); }
            if (pl.End[i] < 0) { notes.Add($"Volée {i + 1} : aucun palier d'arrivée associé (arrivée sur dalle ou poutre ?)"); chk.Warnings.Add($"Volée {i + 1} : pas de palier d'arrivée."); }
            count += ArmRun(runs[i], o, nIn, u, pts, i, pl.Start[i] >= 0, pl.End[i] >= 0);
        }
        for (int k = 0; k < lands.Count; k++)
        {
            var arrivals = Enumerable.Range(0, runs.Count).Where(j => pl.End[j] == k && runU[j] != null).ToList();
            var departs = Enumerable.Range(0, runs.Count).Where(j => pl.Start[j] == k).ToList();
            if (arrivals.Count == 0 && departs.Count == 0) { notes.Add($"Palier {k + 1} : associé à aucune volée (nappe de répartition seule, à compléter)"); chk.Warnings.Add($"Palier {k + 1} : associé à aucune volée."); }
            var face = ReinforceCommand.Underside(lands[k], false);
            if (face == null) { notes.Add($"Palier {k + 1} : sous-face horizontale introuvable"); continue; }
            count += ArmLanding(lands[k], face, k, arrivals, departs);
        }
        err = string.Join(" ; ", notes);
        if (count == 0 && err == "") err = "aucune armature créée";
        return count;
    }

    /// <summary>Étrier fermé : cadre fermé de 4 côtés, avec crochets de 135° si possible, en réseau le long de l'axe (norm).</summary>
    private static bool MakeClosed(Document doc, Element host, RebarBarType t, RebarHookType? hook, List<XYZ> rect, XYZ norm, double arrayLen, double spCm, string role)
    {
        var cur = new List<Curve>();
        for (int i = 0; i < 4; i++) cur.Add(Line.CreateBound(rect[i], rect[(i + 1) % 4]));
        Rebar? r = null;
        try { r = Rebar.CreateFromCurves(doc, RebarStyle.StirrupTie, t, hook, hook, host, norm, cur, RebarHookOrientation.Right, RebarHookOrientation.Right, true, true); } catch { }
        if (r == null) { try { r = Rebar.CreateFromCurves(doc, RebarStyle.StirrupTie, t, null, null, host, norm, cur, RebarHookOrientation.Right, RebarHookOrientation.Right, true, true); } catch { } }
        if (r == null) return false;
        r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.Set(ReinforceCommand.Tag);
        ReinforceCommand.SetRole(r, role);
        ReinforceCommand.LastRebar = r;
        double sp = spCm / 100.0 / Ft;
        if (arrayLen > sp * 0.5) r.GetShapeDrivenAccessor().SetLayoutAsMaximumSpacing(sp, arrayLen, true, true, true);
        return true;
    }
}
