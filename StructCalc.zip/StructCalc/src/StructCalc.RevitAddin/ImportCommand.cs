using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Microsoft.Win32;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Reprend les résultats envoyés par StructCalc dans le champ Commentaires des éléments (« SC [OK] ... »). L'aspect du modèle n'est pas modifié ;
/// les couleurs vert / rouge posées par les versions précédentes de cette commande sont retirées (aspect d'origine rétabli).</summary>
[Transaction(TransactionMode.Manual)]
public class ImportCommand : IExternalCommand
{
    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            Document doc = data.Application.ActiveUIDocument.Document;

            string? path = null;
            if (File.Exists(RevitLink.ToRevit))
            {
                var td = new TaskDialog("StructCalc") { MainInstruction = "Importer les derniers résultats de StructCalc ?" };
                td.MainContent = "Envoyés le " + File.GetLastWriteTime(RevitLink.ToRevit).ToString("dd/MM/yyyy HH:mm") + ".";
                td.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No | TaskDialogCommonButtons.Cancel;
                var r = td.Show();
                if (r == TaskDialogResult.Cancel) return Result.Cancelled;
                if (r == TaskDialogResult.Yes) path = RevitLink.ToRevit;
            }
            if (path == null)
            {
                var dlg = new OpenFileDialog { Filter = "Résumé StructCalc (*.json)|*.json" };
                if (dlg.ShowDialog() != true) return Result.Cancelled;
                path = dlg.FileName;
            }

            var items = ModelIO.LoadRevitSummary(path);
            // vues sur lesquelles d'anciennes versions ont pu poser des couleurs (vues modèle, hors gabarits)
            var views = new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
                .Where(v => !v.IsTemplate && v.ViewType != ViewType.Schedule && v.ViewType != ViewType.Legend && v.ViewType != ViewType.DrawingSheet
                            && v.ViewType != ViewType.ProjectBrowser && v.ViewType != ViewType.SystemBrowser && v.ViewType != ViewType.Internal).ToList();
            static bool IsOurs(Color? c) => c != null && c.IsValid && ((c.Red == 40 && c.Green == 160 && c.Blue == 70) || (c.Red == 210 && c.Green == 40 && c.Blue == 40));

            // dimensions calculées ou prédimensionnées dans StructCalc : sections b x h, épaisseurs, semelles
            bool updateSizes = false;
            {
                var td2 = new TaskDialog("StructCalc") { MainInstruction = "Reporter aussi les dimensions dans Revit ?" };
                td2.MainContent = "Sections des poteaux et poutres béton, épaisseurs des dalles, radiers, voiles et semelles filantes, dimensions des semelles isolées.\n\n" +
                                  "Les types d'origine ne sont pas modifiés : un type « SC ... » est créé (ou réutilisé) pour chaque dimension et affecté à l'élément. Annulable avec Ctrl+Z.";
                td2.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No;
                td2.DefaultButton = TaskDialogResult.Yes;
                updateSizes = td2.Show() == TaskDialogResult.Yes;
            }

            int done = 0, restored = 0;
            SectionUpdater.Report? sizes = null;
            using (var tx = new Transaction(doc, "StructCalc - résultats"))
            {
                tx.Start();
                foreach (var it in items)
                {
                    if (!long.TryParse(it.ExternalId, out long id)) continue;
                    Element? el = doc.GetElement(new ElementId(id));
                    if (el == null) continue;
                    Parameter? p = el.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                    if (p != null && !p.IsReadOnly)
                    {
                        string cur = p.AsString() ?? "";
                        string pre = cur.StartsWith(ReinforceCommand.FootingTag) ? cur.Split(new[] { " — " }, StringSplitOptions.None)[0] + " — " : "";   // une semelle garde son repère
                        p.Set($"{pre}SC [{it.Status}] {it.Summary}"); done++;
                    }

                    foreach (var v in views)
                    {
                        try
                        {
                            var ogs = v.GetElementOverrides(el.Id);
                            if (IsOurs(ogs.ProjectionLineColor) && IsOurs(ogs.SurfaceForegroundPatternColor))
                            {
                                v.SetElementOverrides(el.Id, new OverrideGraphicSettings());
                                restored++;
                            }
                        }
                        catch { /* vue sans surcharge possible : ignorée */ }
                    }
                }
                if (updateSizes) sizes = SectionUpdater.Apply(doc, items);
                tx.Commit();
            }
            string sz = sizes == null ? "" : $"\n\nDimensions : {sizes.Changed} élément(s) modifié(s), {sizes.Unchanged} déjà conformes." +
                                              (sizes.Notes.Count > 0 ? "\nNon reportés :\n- " + string.Join("\n- ", sizes.Notes.Take(8)) + (sizes.Notes.Count > 8 ? $"\n... et {sizes.Notes.Count - 8} autre(s)" : "") : "");
            TaskDialog.Show("StructCalc", $"{done} élément(s) mis à jour (champ Commentaires)." + (updateSizes ? "" : " L'aspect du modèle n'est pas modifié.") + (restored > 0 ? $"\n{restored} couleur(s) verte/rouge d'une ancienne version retirée(s) : aspect d'origine rétabli." : "") + sz);
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }
}
