using Autodesk.Revit.DB;

namespace StructCalc.RevitAddin;

/// <summary>Géométrie d'un mur droit lue dans Revit (pieds, repère du mur) : direction, normale, étendues le long du mur, dans l'épaisseur et en hauteur, et ouvertures
/// (portes, fenêtres) posées dans le mur. Toutes les valeurs sont en unités internes de Revit (pieds), en coordonnées absolues du projet :
/// u = point · Dir, v = point · N, z = point.Z.</summary>
internal sealed class WallGeo
{
    public XYZ Dir = XYZ.BasisX, N = XYZ.BasisY;
    public double UMin, UMax, VMin, VMax, ZMin, ZMax;
    public List<(double U0, double U1, double Z0, double Z1)> Openings = new();

    public double Length => UMax - UMin;
    public double Height => ZMax - ZMin;
    public double Thickness => VMax - VMin;

    private static double? Param(Element? e, params BuiltInParameter[] ps)
    {
        if (e == null) return null;
        foreach (var bp in ps)
        {
            try { var p = e.get_Parameter(bp); if (p != null && p.HasValue && p.StorageType == StorageType.Double && p.AsDouble() > 1e-6) return p.AsDouble(); } catch { }
        }
        return null;
    }

    public static WallGeo? Read(Wall w)
    {
        if (w.Location is not LocationCurve lc || lc.Curve is not Line ln) return null;
        XYZ d = ln.GetEndPoint(1) - ln.GetEndPoint(0);
        d = new XYZ(d.X, d.Y, 0);
        if (d.GetLength() < 1e-6) return null;
        var g = new WallGeo { Dir = d.Normalize() };
        g.N = new XYZ(-g.Dir.Y, g.Dir.X, 0);

        double u0 = double.MaxValue, u1 = double.MinValue, v0 = double.MaxValue, v1 = double.MinValue, z0 = double.MaxValue, z1 = double.MinValue;
        void Add(XYZ p)
        {
            double u = p.DotProduct(g.Dir), v = p.DotProduct(g.N);
            u0 = Math.Min(u0, u); u1 = Math.Max(u1, u); v0 = Math.Min(v0, v); v1 = Math.Max(v1, v); z0 = Math.Min(z0, p.Z); z1 = Math.Max(z1, p.Z);
        }
        var ge = w.get_Geometry(new Options { DetailLevel = ViewDetailLevel.Fine, ComputeReferences = false });
        if (ge != null)
            foreach (GeometryObject go in ge)
                if (go is Solid s && s.Volume > 1e-9)
                    foreach (Edge ed in s.Edges) { var c = ed.AsCurve(); Add(c.GetEndPoint(0)); Add(c.GetEndPoint(1)); }
        if (u0 > u1) return null;
        g.UMin = u0; g.UMax = u1; g.VMin = v0; g.VMax = v1; g.ZMin = z0; g.ZMax = z1;

        try
        {
            foreach (ElementId id in w.FindInserts(true, true, false, false))
            {
                if (w.Document.GetElement(id) is not FamilyInstance fi) continue;
                var bb = fi.get_BoundingBox(null);
                if (bb == null) continue;
                double oz0 = Math.Max(bb.Min.Z, z0), oz1 = Math.Min(bb.Max.Z, z1);
                double wd = Param(fi.Symbol, BuiltInParameter.FAMILY_WIDTH_PARAM, BuiltInParameter.DOOR_WIDTH, BuiltInParameter.WINDOW_WIDTH, BuiltInParameter.CASEWORK_WIDTH)
                            ?? Param(fi, BuiltInParameter.FAMILY_WIDTH_PARAM) ?? 0;
                double uc;
                if (fi.Location is LocationPoint lp) uc = lp.Point.DotProduct(g.Dir);
                else uc = (bb.Min.DotProduct(g.Dir) + bb.Max.DotProduct(g.Dir)) / 2;
                if (wd <= 0)
                {
                    double a = bb.Min.DotProduct(g.Dir), b = bb.Max.DotProduct(g.Dir), c2 = new XYZ(bb.Min.X, bb.Max.Y, 0).DotProduct(g.Dir), d2 = new XYZ(bb.Max.X, bb.Min.Y, 0).DotProduct(g.Dir);
                    wd = Math.Max(Math.Max(a, b), Math.Max(c2, d2)) - Math.Min(Math.Min(a, b), Math.Min(c2, d2));
                }
                double ou0 = Math.Max(uc - wd / 2, u0), ou1 = Math.Min(uc + wd / 2, u1);
                if (ou1 - ou0 > 0.2 && oz1 - oz0 > 0.2) g.Openings.Add((ou0, ou1, oz0, oz1));
            }
        }
        catch { /* ouvertures illisibles : le mur est pris plein */ }
        return g;
    }
}
