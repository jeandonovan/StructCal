using System.Windows;
using System.Windows.Controls;

namespace StructCalc.RevitAddin;

/// <summary>Armatures transversales de la rupture de pente : épingles (barres simples) et/ou étriers fermés (cadres), diamètre et espacement.</summary>
internal sealed class StairTransOptions
{
    public bool Pins = true, Closed = true;
    public int DiaMm = 8;
    public double SpacingCm = 10;
}

/// <summary>Associations palier-volée détectées dans le modèle Revit, à vérifier ou corriger avant la création des armatures.</summary>
internal static class StairLinksDialog
{
    /// <summary>start[i] / end[i] : indice du palier de départ / d'arrivée de la volée i (-1 = aucun). Modifiés en place. Retourne false si annulé.</summary>
    public static bool Ask(string title, List<string> runs, List<string> landings, int[] start, int[] end, StairTransOptions opt)
    {
        var w = new Window { Title = "StructCalc - " + title, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterScreen, MinWidth = 520 };
        var p = new StackPanel { Margin = new Thickness(16) };
        p.Children.Add(new TextBlock
        {
            Text = "Associations détectées entre volées et paliers. Vérifiez-les, corrigez-les si besoin : elles décident où les barres sont prolongées, recouvertes et renforcées. " +
                   "Un palier peut aboutir à zéro, une ou plusieurs volées.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10)
        });
        var items = new List<string> { "(aucun / sol)" };
        items.AddRange(landings);
        var g = new System.Windows.Controls.Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        void Cell(UIElement e, int r, int c) { System.Windows.Controls.Grid.SetRow(e, r); System.Windows.Controls.Grid.SetColumn(e, c); g.Children.Add(e); }
        g.RowDefinitions.Add(new RowDefinition());
        Cell(new TextBlock { Text = "Volée", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 12, 4) }, 0, 0);
        Cell(new TextBlock { Text = "Palier de départ", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 12, 4) }, 0, 1);
        Cell(new TextBlock { Text = "Palier d'arrivée", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 4) }, 0, 2);
        var cs = new List<ComboBox>(); var ce = new List<ComboBox>();
        for (int i = 0; i < runs.Count; i++)
        {
            g.RowDefinitions.Add(new RowDefinition());
            Cell(new TextBlock { Text = runs[i], Margin = new Thickness(0, 2, 12, 2), VerticalAlignment = VerticalAlignment.Center }, i + 1, 0);
            var a = new ComboBox { ItemsSource = items, SelectedIndex = start[i] + 1, MinWidth = 150, Margin = new Thickness(0, 2, 12, 2) };
            var b = new ComboBox { ItemsSource = items, SelectedIndex = end[i] + 1, MinWidth = 150, Margin = new Thickness(0, 2, 0, 2) };
            cs.Add(a); ce.Add(b); Cell(a, i + 1, 1); Cell(b, i + 1, 2);
        }
        p.Children.Add(g);
        p.Children.Add(new TextBlock { Text = "À la rupture de pente (volée -> palier), armatures transversales :", Margin = new Thickness(0, 12, 0, 4), FontWeight = FontWeights.Bold });
        var cPin = new CheckBox { Content = "Épingles (barres simples en U, ancrées dans la masse)", IsChecked = opt.Pins, Margin = new Thickness(0, 2, 0, 2) };
        var cClo = new CheckBox { Content = "Étriers fermés (cadres fermés, zone tendue / risque de poussée au vide)", IsChecked = opt.Closed, Margin = new Thickness(0, 2, 0, 6) };
        p.Children.Add(cPin); p.Children.Add(cClo);
        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 10) };
        row.Children.Add(new TextBlock { Text = "Diamètre HA", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) });
        var tDia = new TextBox { Text = opt.DiaMm.ToString(), Width = 40, Margin = new Thickness(0, 0, 14, 0) };
        row.Children.Add(tDia);
        row.Children.Add(new TextBlock { Text = "Espacement (cm)", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) });
        var tSp = new TextBox { Text = opt.SpacingCm.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture), Width = 40 };
        row.Children.Add(tSp);
        p.Children.Add(row);
        var btn = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var ok = new Button { Content = "Valider", Width = 100, Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        ok.Click += (s, e) => w.DialogResult = true;
        btn.Children.Add(ok); btn.Children.Add(new Button { Content = "Annuler", Width = 90, IsCancel = true });
        p.Children.Add(btn);
        w.Content = p;
        if (w.ShowDialog() != true) return false;
        for (int i = 0; i < runs.Count; i++) { start[i] = cs[i].SelectedIndex - 1; end[i] = ce[i].SelectedIndex - 1; }
        opt.Pins = cPin.IsChecked == true; opt.Closed = cClo.IsChecked == true;
        if (int.TryParse(tDia.Text, out int dia) && dia >= 6 && dia <= 16) opt.DiaMm = dia;
        if (double.TryParse(tSp.Text.Replace(',', '.'), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double sp) && sp >= 4 && sp <= 30) opt.SpacingCm = sp;
        return true;
    }
}
