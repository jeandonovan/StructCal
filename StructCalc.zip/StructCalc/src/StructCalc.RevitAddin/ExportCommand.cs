using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using StructuralMaterialType = Autodesk.Revit.DB.Structure.StructuralMaterialType;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.RevitAddin;

[Transaction(TransactionMode.ReadOnly)]
public class ExportCommand : IExternalCommand
{
    private static double M(double feet) => UnitUtils.ConvertFromInternalUnits(feet, UnitTypeId.Meters);

    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            StructCalc.Core.Licensing.LicenseManager.Require(0);
            Document doc = data.Application.ActiveUIDocument.Document;
            var model = new StructModel { Name = doc.Title };
            var nodeKeys = new Dictionary<string, int>();
            int nextMember = 1;

            int NodeId(XYZ p)
            {
                double x = M(p.X), y = M(p.Y), z = M(p.Z);
                string key = $"{Math.Round(x, 3).ToString(CultureInfo.InvariantCulture)}|{Math.Round(y, 3).ToString(CultureInfo.InvariantCulture)}|{Math.Round(z, 3).ToString(CultureInfo.InvariantCulture)}";
                if (nodeKeys.TryGetValue(key, out int id)) return id;
                id = model.Nodes.Count + 1;
                model.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
                nodeKeys[key] = id;
                return id;
            }

            // sélection active : on n'exporte qu'elle ; sinon tout le modèle
            var selIds = new HashSet<long>(data.Application.ActiveUIDocument.Selection.GetElementIds().Select(i => i.Value));
            bool onlySel = selIds.Count > 0;
            int skipped = 0;
            foreach (var (cat, type) in new[]
            {
                (BuiltInCategory.OST_StructuralColumns, MemberType.Column),
                (BuiltInCategory.OST_StructuralFraming, MemberType.Beam)
            })
            {
                var col = new FilteredElementCollector(doc).OfCategory(cat).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType();
                foreach (FamilyInstance fi in col.Cast<FamilyInstance>())
                {
                    if (onlySel && !selIds.Contains(fi.Id.Value)) continue;
                    XYZ? p0 = null, p1 = null;
                    if (fi.Location is LocationCurve lc)
                    {
                        p0 = lc.Curve.GetEndPoint(0); p1 = lc.Curve.GetEndPoint(1);
                    }
                    else if (fi.Location is LocationPoint lp)
                    {
                        BoundingBoxXYZ? bb = fi.get_BoundingBox(null);
                        if (bb != null)
                        {
                            p0 = new XYZ(lp.Point.X, lp.Point.Y, bb.Min.Z);
                            p1 = new XYZ(lp.Point.X, lp.Point.Y, bb.Max.Z);
                        }
                    }
                    if (p0 == null || p1 == null) { skipped++; continue; }

                    var (b, h) = ParseSection(fi);
                    bool steel = IsSteel(doc, fi);
                    int n0 = NodeId(p0), n1 = NodeId(p1);
                    if (n0 == n1) { skipped++; continue; }
                    model.Members.Add(new Member
                    {
                        Id = nextMember++, NodeI = n0, NodeJ = n1, Type = type,
                        Kind = steel ? MaterialKind.Steel : MaterialKind.ReinforcedConcrete,
                        B = b, H = h,
                        Cover = 0.041, CoverNomCm = 2.5,
                        Profile = steel ? ParseProfile(fi.Symbol.Name) : "",
                        ExternalId = fi.Id.Value.ToString(CultureInfo.InvariantCulture)
                    });
                }
            }

            // Appuis : encastrement des nœuds situés au niveau le plus bas.
            if (model.Nodes.Count > 0)
            {
                double zmin = model.Nodes.Min(n => n.Z);
                foreach (var n in model.Nodes.Where(n => Math.Abs(n.Z - zmin) < 0.001))
                    model.Supports.Add(new SupportDef { NodeId = n.Id });
            }

            var stairNotes = new List<string>();
            int nSlabs = ExportFloors(doc, model, selIds, onlySel, stairNotes);
            int nWalls = ExportWalls(doc, model, selIds, onlySel, stairNotes);
            int nFoot = ExportFootings(doc, model, selIds, onlySel, stairNotes);
            int nStairs = ExportStairs(doc, model, selIds, onlySel, stairNotes);
            string gradeTxt = ExportConcreteGrade(doc, model);
            int nLevels = ExportLevels(doc, model);
            int nGrids = ExportGrids(doc, model);

            // fichier d'échange commun avec StructCalc (ouverture directe) + copie nommée d'après le projet
            ModelIO.Save(model, RevitLink.FromRevit);
            string copy = System.IO.Path.Combine(RevitLink.Dir, Regex.Replace(doc.Title, @"[^\w\-. ]", "_") + AppInfo.FileExt);
            try { ModelIO.Save(model, copy); } catch { }
            string launch = AppLauncher.SendModel(RevitLink.FromRevit);
            TaskDialog.Show("StructCalc",
                $"Exporté{(onlySel ? " (sélection)" : "")} : {model.Members.Count} barres, {model.Nodes.Count} nœuds, {nSlabs} dalle(s), {nFoot} semelle(s), {model.Rafts.Count} radier(s), {nWalls} voile(s), {nStairs} escalier(s), {nLevels} niveau(x), {nGrids} axe(s) ({skipped} ignoré(s)).\n" +
                gradeTxt + (stairNotes.Count > 0 ? string.Join("\n", stairNotes) + "\n" : "") + "Appuis : nœuds du niveau le plus bas (encastrés). Ajoutez les charges dans StructCalc (les dalles portent déjà G et Q par défaut).\n\n" + launch);
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }

    // ------------------------------------------------------------------ niveaux, axes, dalles
    private static int ExportLevels(Document doc, StructModel model)
    {
        double zmin = model.Nodes.Count > 0 ? model.Nodes.Min(n => n.Z) : double.MinValue, zmax = model.Nodes.Count > 0 ? model.Nodes.Max(n => n.Z) : double.MaxValue;
        var lv = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>()
            .Select(l => (l.Name, Z: Math.Round(M(l.Elevation), 3))).Where(l => l.Z >= zmin - 0.05 && l.Z <= zmax + 0.05)
            .GroupBy(l => l.Z).Select(g => g.First()).OrderBy(l => l.Z).ToList();
        if (lv.Count < 2) return 0;
        foreach (var l in lv) model.Levels.Add(new StoreyDef { Name = l.Name, Elevation = l.Z });
        return lv.Count;
    }

    private static int ExportGrids(Document doc, StructModel model)
    {
        int n = 0;
        foreach (Grid g in new FilteredElementCollector(doc).OfClass(typeof(Grid)).Cast<Grid>())
        {
            if (g.Curve is not Line ln || !ln.IsBound) continue;
            XYZ a = ln.GetEndPoint(0), b = ln.GetEndPoint(1);
            double dx = Math.Abs(M(b.X - a.X)), dy = Math.Abs(M(b.Y - a.Y));
            if (dx < 0.01 && dy > 0.1) { model.Grid.XAxes.Add(new AxisDef { Name = g.Name, Pos = Math.Round(M(a.X), 3) }); n++; }       // ligne parallèle à Y : x = cste
            else if (dy < 0.01 && dx > 0.1) { model.Grid.YAxes.Add(new AxisDef { Name = g.Name, Pos = Math.Round(M(a.Y), 3) }); n++; }  // ligne parallèle à X : y = cste
        }
        model.Grid.XAxes = model.Grid.XAxes.OrderBy(a => a.Pos).ToList();
        model.Grid.YAxes = model.Grid.YAxes.OrderBy(a => a.Pos).ToList();
        return n;
    }

    /// <summary>Dalles structurelles : le contour réel (avec ses trémies) est lu sur la face supérieure, puis découpé en panneaux rectangulaires qui couvrent exactement
    /// la surface (les trémies restent vides). Cote du dessus et épaisseur du type. Un bord oblique ou courbe est suivi en escalier.</summary>
    private static int ExportFloors(Document doc, StructModel model, HashSet<long> sel, bool onlySel, List<string> notes)
    {
        int n = 0;
        foreach (Floor fl in new FilteredElementCollector(doc).OfClass(typeof(Floor)).WhereElementIsNotElementType().Cast<Floor>())
        {
            if (onlySel && !sel.Contains(fl.Id.Value)) continue;
            try
            {
                var isStruct = fl.get_Parameter(BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL);
                if (isStruct != null && isStruct.AsInteger() == 0 && !onlySel) continue;
                if ((fl.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() ?? "").StartsWith(ReinforceCommand.FootingTag)) continue;   // semelle créée par StructCalc
                BoundingBoxXYZ? bb = fl.get_BoundingBox(null);
                if (bb == null) continue;
                if (fl.Category != null && fl.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFoundation)
                {
                    // radier / dalle de fondation : contour (trous exclus) découpé en rectangles ; il porte les poteaux et voiles posés dessus
                    var rloops = TopLoops(fl);
                    var rrects = rloops.Count > 0 ? StructCalc.Engine.Geometry.RectDecomposer.Decompose(rloops) : new List<StructCalc.Engine.Geometry.RectDecomposer.Rect>();
                    if (rrects.Count == 0) rrects.Add(new StructCalc.Engine.Geometry.RectDecomposer.Rect(M(bb.Min.X), M(bb.Min.Y), M(bb.Max.X), M(bb.Max.Y)));
                    double rth = 0.40;
                    var rcs = fl.FloorType?.GetCompoundStructure();
                    if (rcs != null) rth = M(rcs.GetWidth());
                    int rk = model.Rafts.Count + 1;
                    var raft = new RaftDef { Name = "R" + rk, ExternalId = fl.Id.Value.ToString(CultureInfo.InvariantCulture), ZTop = Math.Round(M(bb.Max.Z), 3), H = Math.Round(rth, 3) };
                    foreach (var rr in rrects) raft.Panels.Add(new RaftPanel { X0 = rr.X0, Y0 = rr.Y0, Lx = Math.Round(rr.W, 3), Ly = Math.Round(rr.H, 3) });
                    model.Rafts.Add(raft);
                    notes.Add($"Radier {raft.Name} : {raft.Area:0.0} m², h = {raft.H * 100:0} cm, dessus à {raft.ZTop:0.00} m (calcul : poteaux et voiles posés dessus).");
                    continue;
                }
                double ztop = M(bb.Max.Z);
                double th = 0.16;
                var cs = fl.FloorType?.GetCompoundStructure();
                if (cs != null) th = M(cs.GetWidth());
                if (th < 0.05) continue;

                var rects = new List<StructCalc.Engine.Geometry.RectDecomposer.Rect>();
                var loops = TopLoops(fl);
                if (loops.Count > 0) rects = StructCalc.Engine.Geometry.RectDecomposer.Decompose(loops);
                if (rects.Count == 0)
                {
                    double bx0 = M(bb.Min.X), by0 = M(bb.Min.Y), bx1 = M(bb.Max.X), by1 = M(bb.Max.Y);
                    if (bx1 - bx0 >= 0.5 && by1 - by0 >= 0.5) rects.Add(new StructCalc.Engine.Geometry.RectDecomposer.Rect(bx0, by0, bx1, by1));
                }
                foreach (var r in rects)
                {
                    if (r.W < 0.5 || r.H < 0.5) continue;
                    int k = 1; while (model.Slabs.Any(q => q.Name == "D" + k)) k++;
                    var slab = new SlabPanel { Name = "D" + k, Placed = true, X0 = Math.Round(r.X0, 3), Y0 = Math.Round(r.Y0, 3), Lx = Math.Round(r.W, 3), Ly = Math.Round(r.H, 3), Z = Math.Round(ztop, 3), H = Math.Round(th, 3), Kind = SlabKind.Pleine, ExternalId = fl.Id.Value.ToString(CultureInfo.InvariantCulture) };
                    model.Slabs.Add(slab);
                    StoreyOps.SyncSlabLoads(model, slab);
                    n++;
                }
            }
            catch { /* dalle illisible : ignorée */ }
        }
        return n;
    }

    /// <summary>Contours (extérieur et trous) de la face supérieure d'une dalle, en mètres, arcs et courbes discrétisés.</summary>
    private static List<IList<(double X, double Y)>> TopLoops(Floor fl)
    {
        var res = new List<IList<(double X, double Y)>>();
        try
        {
            foreach (Reference rf in HostObjectUtils.GetTopFaces(fl))
            {
                if (fl.GetGeometryObjectFromReference(rf) is not PlanarFace pf) continue;
                foreach (CurveLoop cl in pf.GetEdgesAsCurveLoops())
                {
                    var pts = new List<(double X, double Y)>();
                    foreach (Curve c in cl)
                    {
                        var tess = c is Line ? new List<XYZ> { c.GetEndPoint(0) } : c.Tessellate().Take(c.Tessellate().Count - 1).ToList();
                        foreach (var p in tess) pts.Add((M(p.X), M(p.Y)));
                    }
                    if (pts.Count >= 3) res.Add(pts);
                }
            }
        }
        catch { res.Clear(); }
        return res;
    }

    // ------------------------------------------------------------------ voiles et murs de soutènement
    /// <summary>Murs droits structurels : emplacement exact (axe réel de la matière), longueur, hauteur, épaisseur, ouvertures (portes, fenêtres). Un mur de type fonction « soutènement » ou « fondation »
    /// reçoit la poussée des terres. Les charges en tête sont des valeurs par défaut à régler dans StructCalc.</summary>
    private static int ExportWalls(Document doc, StructModel model, HashSet<long> sel, bool onlySel, List<string> notes)
    {
        int n = 0;
        foreach (Wall wl in new FilteredElementCollector(doc).OfClass(typeof(Wall)).WhereElementIsNotElementType().Cast<Wall>())
        {
            if (onlySel && !sel.Contains(wl.Id.Value)) continue;
            try
            {
                var st = wl.get_Parameter(BuiltInParameter.WALL_STRUCTURAL_SIGNIFICANT);
                if (st != null && st.AsInteger() == 0 && !onlySel) continue;
                var fn = wl.WallType?.Function ?? WallFunction.Interior;
                var g = WallGeo.Read(wl);
                if (g == null) { if (st != null && st.AsInteger() == 1) notes.Add($"Voile #{wl.Id.Value} : mur courbe ou illisible, ignoré."); continue; }
                double len = M(g.Length), hgt = M(g.Height), th = M(g.Thickness);
                if (len < 0.5 || hgt < 0.5 || th < 0.08) continue;
                double vc = (g.VMin + g.VMax) / 2;
                var o = g.Dir * g.UMin + g.N * vc;           // pied de l'axe de la matière
                int k = 1; while (model.Walls.Any(q => q.Name == "V" + k)) k++;
                bool retaining = fn == WallFunction.Retaining || fn == WallFunction.Foundation;
                var wd = new WallDef
                {
                    Name = "V" + k, ExternalId = wl.Id.Value.ToString(CultureInfo.InvariantCulture),
                    X = Math.Round(M(o.X), 3), Y = Math.Round(M(o.Y), 3), Z = Math.Round(M(g.ZMin), 3),
                    AngleDeg = Math.Round(Math.Atan2(g.Dir.Y, g.Dir.X) * 180 / Math.PI, 2),
                    LengthM = Math.Round(len, 3), HeightM = Math.Round(hgt, 3), ThicknessM = Math.Round(th, 3),
                    Retaining = retaining, RetainedHeightM = retaining ? Math.Round(hgt, 2) : 0,
                    TopHeldOutOfPlane = fn != WallFunction.Retaining, Base = WallBase.Encastre
                };
                if (retaining) { wd.GTopKnPerM = 20; wd.QTopKnPerM = 5; }
                int j = 0;
                foreach (var op in g.Openings)
                {
                    double xm = Math.Max(0.1, M(op.U0 - g.UMin)), w2 = Math.Min(M(op.U1 - g.UMin), len - 0.1) - xm;
                    double zm = Math.Max(0, M(op.Z0 - g.ZMin)), h2 = Math.Min(M(op.Z1 - g.ZMin), hgt) - zm;
                    if (w2 < 0.2 || h2 < 0.2) continue;
                    wd.Openings.Add(new WallOpening { Name = "O" + (++j), XM = Math.Round(xm, 3), ZM = Math.Round(zm, 3), WidthM = Math.Round(w2, 3), HeightM = Math.Round(h2, 3) });
                }
                model.Walls.Add(wd);
                n++;
                if (retaining) notes.Add($"{wd.Name} : mur {(fn == WallFunction.Foundation ? "de fondation" : "de soutènement")} : poussée des terres sur toute la hauteur (K = 0,5, surcharge 10 kPa) à ajuster dans StructCalc.");
            }
            catch { /* mur illisible : ignoré */ }
        }
        if (n > 0) notes.Add($"{n} voile(s) : charges en tête par défaut (60 kN/m permanent, 20 kN/m exploitation) à régler dans StructCalc.");
        return n;
    }

    // ------------------------------------------------------------------ escaliers
    private static XYZ Flat(XYZ v) { var f = new XYZ(v.X, v.Y, 0); return f.GetLength() < 1e-9 ? XYZ.BasisX : f.Normalize(); }

    /// <summary>Escaliers Revit (par composants) : volées, paliers, emmarchement, hauteur de marche et giron sont lus ; le type StructCalc (parmi 8) est déduit de la
    /// forme du tracé des volées : 1 volée = droit ; 2 volées alignées + palier = droit avec palier ; 2 volées à 90° = quart tournant ; 2 volées opposées = demi-tournant ;
    /// 3 volées = double quart ; sans palier entre deux volées = balancé ; tracé courbe = hélicoïdal. Un cas non reconnu est posé en « droit » et signalé.</summary>
    private static int ExportStairs(Document doc, StructModel model, HashSet<long> sel, bool onlySel, List<string> notes)
    {
        int n = 0;
        IList<Element> all;
        try { all = new FilteredElementCollector(doc).OfClass(typeof(Autodesk.Revit.DB.Architecture.Stairs)).WhereElementIsNotElementType().ToList(); }
        catch { return 0; }
        foreach (Element el in all)
        {
            if (onlySel && !sel.Contains(el.Id.Value)) continue;
            try
            {
                var st = (Autodesk.Revit.DB.Architecture.Stairs)el;
                var runs = st.GetStairsRuns().Select(id => doc.GetElement(id)).OfType<Autodesk.Revit.DB.Architecture.StairsRun>().ToList();
                if (runs.Count == 0) { notes.Add($"Escalier {el.Id.Value} : aucune volée lisible (escalier par esquisse ?) - ignoré."); continue; }
                int nLand = st.GetStairsLandings().Count;

                // tracé de chaque volée : points de départ / arrivée, arcs éventuels
                var infos = new List<(XYZ P0, XYZ P1, double W, List<Arc> Arcs)>();
                foreach (var r in runs)
                {
                    var cur = r.GetStairsPath().ToList();
                    if (cur.Count == 0) continue;
                    infos.Add((cur[0].GetEndPoint(0), cur[^1].GetEndPoint(1), M(r.ActualRunWidth), cur.OfType<Arc>().ToList()));
                }
                if (infos.Count == 0) continue;
                infos = infos.OrderBy(i => i.P0.Z).ToList();
                double w = Math.Max(0.6, infos[0].W);

                // cotes : niveau de départ et d'arrivée (paramètres de l'escalier), sinon tracé et boîte englobante
                double z0 = M(infos[0].P0.Z), zTop = double.NaN;
                try
                {
                    var bl = doc.GetElement(el.get_Parameter(BuiltInParameter.STAIRS_BASE_LEVEL_PARAM)?.AsElementId() ?? ElementId.InvalidElementId) as Level;
                    if (bl != null) z0 = M(bl.Elevation) + M(el.get_Parameter(BuiltInParameter.STAIRS_BASE_OFFSET)?.AsDouble() ?? 0);
                    var tl = doc.GetElement(el.get_Parameter(BuiltInParameter.STAIRS_TOP_LEVEL_PARAM)?.AsElementId() ?? ElementId.InvalidElementId) as Level;
                    if (tl != null) zTop = M(tl.Elevation) + M(el.get_Parameter(BuiltInParameter.STAIRS_TOP_OFFSET)?.AsDouble() ?? 0);
                }
                catch { }
                if (double.IsNaN(zTop)) { var bb = el.get_BoundingBox(null); zTop = bb != null ? M(bb.Max.Z) : z0 + 3.06; }
                double height = zTop - z0 > 0.5 ? zTop - z0 : 3.06;

                int k = 1; while (model.Stairs.Any(q => q.Name == "E" + k)) k++;
                var d = new StairDef { Name = "E" + k, ExternalId = el.Id.Value.ToString(System.Globalization.CultureInfo.InvariantCulture), Placed = true, Z = Math.Round(z0, 3), HeightM = Math.Round(height, 3), WidthM = Math.Round(w, 2) };
                try
                {
                    double rh = M(st.ActualRiserHeight) * 100, td = M(st.ActualTreadDepth) * 100;
                    if (rh > 10 && rh < 25) d.TargetRiserCm = Math.Round(rh, 1);
                    if (td > 15 && td < 45) d.TargetTreadCm = Math.Round(td, 1);
                }
                catch { }

                var first = infos[0];
                // diagnostic (affiché dans le message d'export) : permet de vérifier la détection sur un vrai escalier
                string diag = $"[{infos.Count} volée(s), {nLand} palier(s), {infos.Sum(i => i.Arcs.Count)} arc(s), départ z = {z0:0.00} m, arrivée z = {zTop:0.00} m";
                if (infos.Count >= 2) { var a0 = Flat(infos[0].P1 - infos[0].P0); var a1 = Flat(infos[1].P1 - infos[1].P0); diag += $", angle volée 1 -> 2 = {Math.Atan2(a0.X * a1.Y - a0.Y * a1.X, a0.DotProduct(a1)) * 180 / Math.PI:0}°"; }
                diag += "]";
                if (first.Arcs.Count > 0)
                {
                    // hélicoïdal : centre, rayon intérieur, angle total, sens de rotation
                    var arc = first.Arcs[0];
                    double sweep = first.Arcs.Sum(a => a.Length / a.Radius) * 180 / Math.PI;
                    d.Layout = StairLayout.Helicoidal;
                    d.InnerRadiusM = Math.Round(Math.Max(0.05, M(arc.Radius) - w / 2), 3);
                    d.TurnAngleDeg = Math.Round(Math.Clamp(sweep, 90, 720), 1);
                    d.X = Math.Round(M(arc.Center.X), 3); d.Y = Math.Round(M(arc.Center.Y), 3);
                    d.AngleDeg = Math.Round(Math.Atan2(first.P0.Y - arc.Center.Y, first.P0.X - arc.Center.X) * 180 / Math.PI, 1);
                    d.Mirror = arc.Normal.Z < 0;
                    notes.Add($"Escalier {d.Name} (Revit {el.Id.Value}) : hélicoïdal, rayon intérieur {d.InnerRadiusM:0.00} m, {d.TurnAngleDeg:0}°" + (d.Mirror ? ", sens horaire. " : ". ") + diag);
                }
                else
                {
                    var d0 = Flat(first.P1 - first.P0);
                    var left = new XYZ(-d0.Y, d0.X, 0);
                    StairLayout lay = StairLayout.Droit; bool mirror = false; string why = "1 volée";
                    if (infos.Count >= 2)
                    {
                        var d1 = Flat(infos[1].P1 - infos[1].P0);
                        double dot = d0.DotProduct(d1), cross = d0.X * d1.Y - d0.Y * d1.X;
                        mirror = cross < 0 && Math.Abs(dot) < 0.8;
                        if (infos.Count == 2)
                        {
                            if (dot > 0.8) { lay = nLand > 0 ? StairLayout.DroitPalier : StairLayout.Droit; why = "2 volées alignées" + (nLand > 0 ? " + palier" : ""); }
                            else if (dot < -0.8)
                            {
                                lay = nLand > 0 ? StairLayout.DemiPalier : StairLayout.DemiBalance; why = "2 volées opposées" + (nLand > 0 ? " + palier" : " sans palier");
                                // côté du retour : à gauche de la 1re volée = demi-tour normal
                                var dv = infos[1].P0 - infos[0].P0; mirror = dv.X * left.X + dv.Y * left.Y < 0;
                            }
                            else { lay = nLand > 0 ? StairLayout.QuartPalier : StairLayout.QuartBalance; why = "2 volées à 90°" + (nLand > 0 ? " + palier" : " sans palier"); }
                        }
                        else if (infos.Count == 3) { lay = StairLayout.DoubleQuartPalier; why = "3 volées"; }
                        else { notes.Add($"Escalier {d.Name} (Revit {el.Id.Value}) : {infos.Count} volées, disposition non reconnue - posé en « droit », à corriger."); }
                    }
                    d.Layout = lay; d.Mirror = mirror;
                    if (lay is StairLayout.QuartPalier or StairLayout.DoubleQuartPalier) d.MidLandingM = d.WidthM;
                    if (lay is StairLayout.DroitPalier or StairLayout.DemiPalier)
                    {
                        // longueur du palier intermédiaire dans le sens de la volée
                        try
                        {
                            var lid = st.GetStairsLandings().First();
                            var bb = doc.GetElement(lid).get_BoundingBox(null);
                            if (bb != null)
                            {
                                var cs = new[] { new XYZ(bb.Min.X, bb.Min.Y, 0), new XYZ(bb.Max.X, bb.Min.Y, 0), new XYZ(bb.Min.X, bb.Max.Y, 0), new XYZ(bb.Max.X, bb.Max.Y, 0) }.Select(q => q.DotProduct(d0)).ToList();
                                d.MidLandingM = Math.Round(Math.Max(w, M(cs.Max() - cs.Min())), 2);
                            }
                        }
                        catch { }
                    }
                    if (lay == StairLayout.DemiPalier && infos.Count >= 2)
                    {
                        double between = Math.Abs((infos[1].P0 - infos[0].P0).DotProduct(left));
                        d.GapM = Math.Round(Math.Max(0.02, M(between) - w), 3);
                    }
                    // origine StructCalc = coin de départ de la volée, du côté gauche (ou droit si symétrique)
                    var p0 = first.P0; double hw = w / 2 / 0.3048;
                    var o = mirror ? p0 + left * hw : p0 - left * hw;
                    d.X = Math.Round(M(o.X), 3); d.Y = Math.Round(M(o.Y), 3);
                    d.AngleDeg = Math.Round(Math.Atan2(d0.Y, d0.X) * 180 / Math.PI, 1);
                    notes.Add($"Escalier {d.Name} (Revit {el.Id.Value}) : {why} -> type « {lay} »" + (mirror ? " (symétrique, virage à droite)" : "") + $", h = {d.HeightM:0.00} m, emmarchement {d.WidthM:0.00} m. " + diag);
                }
                model.Stairs.Add(d);
                n++;
            }
            catch (Exception ex) { notes.Add($"Escalier {el.Id.Value} illisible ({ex.Message}) - ignoré."); }
        }
        return n;
    }

    /// <summary>Semelles isolées (fondations structurelles de type famille) : dimensions en plan imposées, charges à renseigner dans StructCalc.</summary>
    private static int ExportFootings(Document doc, StructModel model, HashSet<long> sel, bool onlySel, List<string> notes)
    {
        int n = 0;
        foreach (FamilyInstance fi in new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFoundation).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType().Cast<FamilyInstance>())
        {
            if (onlySel && !sel.Contains(fi.Id.Value)) continue;
            try
            {
                BoundingBoxXYZ? bb = fi.get_BoundingBox(null);
                if (bb == null) continue;
                double a = M(bb.Max.X - bb.Min.X), b = M(bb.Max.Y - bb.Min.Y);
                if (a < 0.4 || b < 0.4 || a > 8 || b > 8) continue;
                n++;
                model.FootingDefs.Add(new FootingDef
                {
                    Name = "SR" + n, Kind = FootingKind.Isolee, ExternalId = fi.Id.Value.ToString(CultureInfo.InvariantCulture),
                    FixedA = Math.Round(a, 2), FixedB = Math.Round(b, 2), ColA = 0.30, ColB = 0.30
                });
            }
            catch { /* semelle illisible : ignorée */ }
        }
        // semelles filantes (fondations de mur) : axe, largeur, épaisseur ; charge par mètre lue sur le voile posé dessus
        int ns = 0;
        foreach (WallFoundation wf in new FilteredElementCollector(doc).OfClass(typeof(WallFoundation)).WhereElementIsNotElementType().Cast<WallFoundation>())
        {
            if (onlySel && !sel.Contains(wf.Id.Value)) continue;
            try
            {
                if (wf.Location is not LocationCurve lc || lc.Curve is not Line ln) { notes.Add($"Semelle filante #{wf.Id.Value} : tracé non rectiligne, ignorée."); continue; }
                XYZ p0 = ln.GetEndPoint(0), p1 = ln.GetEndPoint(1);
                double len = M(Math.Sqrt((p1.X - p0.X) * (p1.X - p0.X) + (p1.Y - p0.Y) * (p1.Y - p0.Y)));
                BoundingBoxXYZ? bb = wf.get_BoundingBox(null);
                if (bb == null || len < 0.5) continue;
                double width = 0, thick = 0;
                var wt = doc.GetElement(wf.GetTypeId());
                var pw = wt?.get_Parameter(BuiltInParameter.CONTINUOUS_FOOTING_WIDTH);
                if (pw != null && pw.HasValue) width = M(pw.AsDouble());
                Parameter? pt = null;   // pas de BuiltInParameter fiable pour l'épaisseur selon la version : recherche par nom (anglais / français), sinon hauteur de la boîte englobante
                foreach (string nm in new[] { "Foundation Thickness", "Thickness", "Épaisseur de la fondation", "Epaisseur de la fondation", "Épaisseur", "Epaisseur" })
                { pt = wt?.LookupParameter(nm); if (pt != null && pt.HasValue && pt.StorageType == StorageType.Double) break; pt = null; }
                if (pt != null && pt.HasValue) thick = M(pt.AsDouble());
                if (width < 0.2) width = Math.Min(M(bb.Max.X - bb.Min.X), M(bb.Max.Y - bb.Min.Y));
                if (width < 0.2) width = 0.8;
                if (thick < 0.1) thick = M(bb.Max.Z - bb.Min.Z);
                double ztop = M(bb.Max.Z);
                double ang = Math.Atan2(p1.Y - p0.Y, p1.X - p0.X) * 180 / Math.PI;
                var fd = new FootingDef
                {
                    Name = "F" + (++ns), Kind = FootingKind.Filante, ExternalId = wf.Id.Value.ToString(CultureInfo.InvariantCulture),
                    X0 = Math.Round(M(p0.X), 3), Y0 = Math.Round(M(p0.Y), 3), AngleDeg = Math.Round(ang, 2), LengthM = Math.Round(len, 3), ZTop = Math.Round(ztop, 3),
                    FixedA = Math.Round(width, 2), ThicknessM = Math.Round(thick, 3), ColA = 0.20
                };
                // voile posé sur la semelle : charge ELU/ELS par mètre et, pour un mur de soutènement, moment de poussée à la base
                double ux = (p1.X - p0.X), uy = (p1.Y - p0.Y), ul = Math.Sqrt(ux * ux + uy * uy);
                WallDef? above = model.Walls.FirstOrDefault(w =>
                {
                    double wa = w.AngleDeg * Math.PI / 180, mx = w.X + w.LengthM / 2 * Math.Cos(wa), my = w.Y + w.LengthM / 2 * Math.Sin(wa);
                    double du = ((mx - M(p0.X)) * ux + (my - M(p0.Y)) * uy) / ul, dv = Math.Abs(-(mx - M(p0.X)) * uy + (my - M(p0.Y)) * ux) / ul;
                    return Math.Abs(w.Z - ztop) < 0.5 && dv < Math.Max(width, 0.4) && du > -0.5 && du < len + 0.5;
                });
                if (above != null)
                {
                    var (nu, nser) = StructCalc.Engine.Structure.RaftDesigner.WallLine(above);
                    fd.NuKN = Math.Round(nu, 1); fd.NserKN = Math.Round(nser, 1); fd.ColA = above.ThicknessM;
                    if (above.Retaining)
                    {
                        double hh = above.RetainedHeightM > 0 ? above.RetainedHeightM : above.HeightM;
                        fd.MaKNm = Math.Round(above.KEarth * above.SoilGammaKnM3 * hh * hh * hh / 6 + above.KEarth * above.SurchargeKPa * hh * hh / 2, 1);
                    }
                }
                else { fd.NuKN = 150; fd.NserKN = 110; notes.Add($"Semelle filante {fd.Name} : aucun voile posé dessus trouvé, charge par défaut 150 kN/m (ELU) à corriger dans StructCalc."); }
                model.FootingDefs.Add(fd);
                n++;
            }
            catch { /* semelle illisible : ignorée */ }
        }
        // semelles créées dans Revit par StructCalc (dalles de fondation repérées par leur commentaire) : reprises avec leur identifiant Revit
        foreach (Floor fl in new FilteredElementCollector(doc).OfClass(typeof(Floor)).WhereElementIsNotElementType().Cast<Floor>())
        {
            if (onlySel && !sel.Contains(fl.Id.Value)) continue;
            try
            {
                string cm = fl.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() ?? "";
                if (!cm.StartsWith(ReinforceCommand.FootingTag)) continue;
                string name = cm.Substring(ReinforceCommand.FootingTag.Length).Split(' ')[0].Trim();
                BoundingBoxXYZ? bb = fl.get_BoundingBox(null);
                if (bb == null || name.Length == 0 || model.FootingDefs.Any(x => x.Name == name)) continue;
                n++;
                model.FootingDefs.Add(new FootingDef
                {
                    Name = name, Kind = FootingKind.Isolee, ExternalId = fl.Id.Value.ToString(CultureInfo.InvariantCulture),
                    FixedA = Math.Round(M(bb.Max.X - bb.Min.X), 2), FixedB = Math.Round(M(bb.Max.Y - bb.Min.Y), 2), ColA = 0.30, ColB = 0.30
                });
            }
            catch { /* semelle illisible : ignorée */ }
        }
        return n;
    }

    /// <summary>Classe de béton lue dans le nom des matériaux des éléments béton (C25/30, B25, fc28 = 25...) : la plus fréquente fixe fc28 du projet.</summary>
    private static string ExportConcreteGrade(Document doc, StructModel model)
    {
        var count = new Dictionary<double, int>();
        foreach (var cat in new[] { BuiltInCategory.OST_StructuralColumns, BuiltInCategory.OST_StructuralFraming, BuiltInCategory.OST_StructuralFoundation })
            foreach (FamilyInstance fi in new FilteredElementCollector(doc).OfCategory(cat).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType().Cast<FamilyInstance>())
            {
                try
                {
                    if (fi.StructuralMaterialId == ElementId.InvalidElementId || doc.GetElement(fi.StructuralMaterialId) is not Material mat) continue;
                    var m1 = Regex.Match(mat.Name, @"C\s*(\d{2})\s*/\s*\d{2}", RegexOptions.IgnoreCase);
                    if (!m1.Success) m1 = Regex.Match(mat.Name, @"\bB\s*(\d{2})\b", RegexOptions.IgnoreCase);
                    if (!m1.Success) m1 = Regex.Match(mat.Name, @"fc\s*28\s*[=:]?\s*(\d{2})", RegexOptions.IgnoreCase);
                    if (!m1.Success) continue;
                    double fc = double.Parse(m1.Groups[1].Value, CultureInfo.InvariantCulture);
                    if (fc < 12 || fc > 70) continue;
                    count[fc] = count.GetValueOrDefault(fc) + 1;
                }
                catch { /* matériau illisible */ }
            }
        if (count.Count == 0) return "";
        double best = count.OrderByDescending(kv => kv.Value).First().Key;
        model.Fc28 = best;
        return $"Béton lu dans les matériaux Revit : fc28 = {best:0} MPa.\n";
    }

    /// <summary>Acier si le type de matériau structurel est « Acier » ; sinon (type « Autre »/non défini) on regarde la classe du matériau
    /// puis le nom du type (IPE/HEA/HEB). Un matériau non reconnu est traité en béton armé.</summary>
    internal static bool IsSteel(Document doc, FamilyInstance fi)
    {
        try
        {
            var smt = fi.StructuralMaterialType;
            if (smt == StructuralMaterialType.Steel) return true;
            if (smt == StructuralMaterialType.Concrete || smt == StructuralMaterialType.PrecastConcrete) return false;
            if (fi.StructuralMaterialId != ElementId.InvalidElementId && doc.GetElement(fi.StructuralMaterialId) is Material mat)
            {
                string cls = (mat.MaterialClass ?? "") + " " + mat.Name;
                if (Regex.IsMatch(cls, @"steel|acier|metal|métal", RegexOptions.IgnoreCase)) return true;
                if (Regex.IsMatch(cls, @"concrete|béton|beton", RegexOptions.IgnoreCase)) return false;
            }
        }
        catch { /* matériau illisible : on retombe sur le nom du type */ }
        return ParseProfile(fi.Symbol.Name).Length > 0;
    }

    private static string ParseProfile(string typeName)
    {
        var m = Regex.Match(typeName, @"(IPE|HEA|HEB)\s*(\d{2,3})", RegexOptions.IgnoreCase);
        return m.Success ? (m.Groups[1].Value + m.Groups[2].Value).ToUpperInvariant() : "";
    }

    /// <summary>Dimensions b x h (m) lues dans le nom du type (ex. "30x50", "300 x 500") ou les paramètres b/h.</summary>
    private static (double b, double h) ParseSection(FamilyInstance fi)
    {
        var mt = Regex.Match(fi.Symbol.Name, @"(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)");
        if (mt.Success)
        {
            double a = double.Parse(mt.Groups[1].Value.Replace(',', '.'), CultureInfo.InvariantCulture);
            double c = double.Parse(mt.Groups[2].Value.Replace(',', '.'), CultureInfo.InvariantCulture);
            double k = Math.Max(a, c) >= 100 ? 0.001 : 0.01;      // mm ou cm
            return (a * k, c * k);
        }
        double? bb = Read(fi, "b", "B", "Width", "Largeur");
        double? hh = Read(fi, "h", "H", "Height", "Hauteur");
        if (bb.HasValue && hh.HasValue) return (M(bb.Value), M(hh.Value));
        return (0.30, 0.30);
    }

    private static double? Read(FamilyInstance fi, params string[] names)
    {
        foreach (var n in names)
        {
            Parameter? p = fi.Symbol.LookupParameter(n) ?? fi.LookupParameter(n);
            if (p != null && p.StorageType == StorageType.Double && p.AsDouble() > 0) return p.AsDouble();
        }
        return null;
    }
}
