using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using StructCalc.Engine;

namespace StructCalc.RevitAddin;

/// <summary>Vérifie le modèle Revit avant l'envoi vers StructCalc : chaque élément est lu comme le fait l'export, et tout ce qui sera ignoré, mal lu ou impossible à mettre à jour
/// au retour est signalé (avec l'identifiant Revit, sélectionnable). Ne modifie rien dans le modèle.</summary>
[Transaction(TransactionMode.ReadOnly)]
public class CheckCommand : IExternalCommand
{
    private enum Sev { Erreur, Attention, Info }
    private sealed record Issue(Sev Level, long Id, string Label, string Text);

    private static double M(double ft) => UnitUtils.ConvertFromInternalUnits(ft, UnitTypeId.Meters);

    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        try
        {
            UIDocument uidoc = data.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            var selIds = new HashSet<long>(uidoc.Selection.GetElementIds().Select(i => i.Value));
            bool onlySel = selIds.Count > 0;
            var issues = new List<Issue>();
            var counts = new Dictionary<string, int>();
            void Count(string k) { counts[k] = counts.GetValueOrDefault(k) + 1; }
            void Add(Sev s, Element e, string label, string text) => issues.Add(new Issue(s, e.Id.Value, label, text));
            bool Skip(Element e) => onlySel && !selIds.Contains(e.Id.Value);

            CheckFrames(doc, Skip, Count, Add);
            CheckFloors(doc, Skip, Count, Add);
            CheckWalls(doc, Skip, Count, Add);
            CheckFoundations(doc, Skip, Count, Add);

            int nLevels = new FilteredElementCollector(doc).OfClass(typeof(Level)).GetElementCount();
            if (nLevels < 2) issues.Add(new Issue(Sev.Attention, 0, "Niveaux", "Moins de 2 niveaux dans le projet : StructCalc ne pourra pas ranger les éléments par étage."));
            if (new FilteredElementCollector(doc).OfClass(typeof(Grid)).GetElementCount() == 0)
                issues.Add(new Issue(Sev.Info, 0, "Axes", "Aucun axe (grille) : le quadrillage de StructCalc sera vide."));
            int arch = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Columns).WhereElementIsNotElementType().GetElementCount();
            if (arch > 0 && !onlySel) issues.Add(new Issue(Sev.Info, 0, "Poteaux architecturaux", $"{arch} poteau(x) de catégorie « Poteaux » (architecturaux) ne sont pas exportés : seuls les « Poteaux porteurs » le sont."));

            int nErr = issues.Count(i => i.Level == Sev.Erreur), nWarn = issues.Count(i => i.Level == Sev.Attention), nInfo = issues.Count(i => i.Level == Sev.Info);
            var sb = new StringBuilder();
            sb.AppendLine($"Vérification du modèle « {doc.Title} »" + (onlySel ? " (sélection)" : "") + $" - {DateTime.Now:dd/MM/yyyy HH:mm}");
            sb.AppendLine("Éléments lus : " + (counts.Count == 0 ? "aucun" : string.Join(", ", counts.OrderBy(k => k.Key).Select(k => $"{k.Value} {k.Key}"))));
            sb.AppendLine($"Erreurs : {nErr}   Attentions : {nWarn}   Infos : {nInfo}");
            sb.AppendLine();
            foreach (var g in issues.OrderBy(i => i.Level).ThenBy(i => i.Label).ThenBy(i => i.Id))
                sb.AppendLine($"[{g.Level}] {g.Label}{(g.Id > 0 ? " #" + g.Id : "")} : {g.Text}");
            if (issues.Count == 0) sb.AppendLine("Aucun point à corriger : le modèle respecte les règles de modélisation pour StructCalc.");

            string head = nErr + nWarn == 0
                ? "Modèle conforme : prêt à être envoyé vers StructCalc."
                : $"{nErr} erreur(s) (élément ignoré ou mal lu), {nWarn} attention(s) (retour des dimensions ou calcul dégradé), {nInfo} info(s).";
            var lines = issues.Where(i => i.Level != Sev.Info).OrderBy(i => i.Level).ThenBy(i => i.Label).Take(10)
                .Select(i => $"- [{i.Level}] {i.Label}{(i.Id > 0 ? " #" + i.Id : "")} : {i.Text}").ToList();
            var td = new TaskDialog("StructCalc - vérification du modèle") { MainInstruction = head };
            td.MainContent = (counts.Count == 0 ? "Aucun élément structurel trouvé.\n\n" : "Lus : " + string.Join(", ", counts.OrderBy(k => k.Key).Select(k => $"{k.Value} {k.Key}")) + ".\n\n")
                             + string.Join("\n", lines) + (issues.Count(i => i.Level != Sev.Info) > lines.Count ? $"\n... et {issues.Count(i => i.Level != Sev.Info) - lines.Count} autre(s) dans le rapport." : "");
            td.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Enregistrer le rapport complet (texte)");
            if (nErr + nWarn > 0) td.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, "Sélectionner les éléments à corriger");
            td.CommonButtons = TaskDialogCommonButtons.Close;
            var r = td.Show();
            if (r == TaskDialogResult.CommandLink1)
            {
                Directory.CreateDirectory(RevitLink.Dir);
                string file = System.IO.Path.Combine(RevitLink.Dir, "verification_modele.txt");
                File.WriteAllText(file, sb.ToString(), new UTF8Encoding(true));
                TaskDialog.Show("StructCalc", "Rapport enregistré :\n" + file);
            }
            else if (r == TaskDialogResult.CommandLink2)
            {
                var ids = issues.Where(i => i.Level != Sev.Info && i.Id > 0).Select(i => new ElementId(i.Id)).Distinct().ToList();
                uidoc.Selection.SetElementIds(ids);
            }
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }

    private static Parameter? Find(Element? e, params string[] names)
    {
        if (e == null) return null;
        foreach (var n in names) { var p = e.LookupParameter(n); if (p != null && p.StorageType == StorageType.Double) return p; }
        return null;
    }

    // ------------------------------------------------------------------ poteaux et poutres
    private static void CheckFrames(Document doc, Func<Element, bool> skip, Action<string> count, Action<Sev, Element, string, string> add)
    {
        foreach (var (cat, label) in new[] { (BuiltInCategory.OST_StructuralColumns, "Poteau"), (BuiltInCategory.OST_StructuralFraming, "Poutre") })
        {
            foreach (FamilyInstance fi in new FilteredElementCollector(doc).OfCategory(cat).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType().Cast<FamilyInstance>())
            {
                if (skip(fi)) continue;
                if (fi.Location is not LocationCurve && fi.Location is not LocationPoint) { add(Sev.Erreur, fi, label, "ni tracé ni point de position : ignoré."); continue; }
                if (fi.Location is LocationCurve lc)
                {
                    double len = M(lc.Curve.Length);
                    if (len < 0.05) { add(Sev.Erreur, fi, label, "longueur nulle : ignoré."); continue; }
                    if (lc.Curve is not Line) add(Sev.Attention, fi, label, "tracé courbe : StructCalc le remplace par sa corde (ligne droite entre les extrémités).");
                }
                count(label.ToLowerInvariant() + "(s)");
                bool steel = ExportCommand.IsSteel(doc, fi);
                string tname = fi.Symbol.Name;
                if (steel)
                {
                    if (!Regex.IsMatch(tname, @"(IPE|HEA|HEB)\s*\d{2,3}", RegexOptions.IgnoreCase))
                        add(Sev.Attention, fi, label, $"acier : profilé non reconnu dans le nom du type « {tname} » (attendu IPE300, HEA240, HEB200...) : choix automatique.");
                    continue;
                }
                bool nameOk = Regex.IsMatch(tname, @"\d+(?:[.,]\d+)?\s*[xX×]\s*\d+(?:[.,]\d+)?");
                var pb = Find(fi.Symbol, "b", "B", "Width", "Largeur") ?? Find(fi, "b", "B", "Width", "Largeur");
                var ph = Find(fi.Symbol, "h", "H", "Height", "Hauteur") ?? Find(fi, "h", "H", "Height", "Hauteur");
                if (!nameOk && (pb == null || ph == null))
                    add(Sev.Erreur, fi, label, $"section illisible (type « {tname} » sans dimension dans le nom ni paramètres b/h) : 30x30 cm supposé.");
                if (Find(fi.Symbol, "b", "B", "Width", "Largeur") == null || Find(fi.Symbol, "h", "H", "Height", "Hauteur") == null)
                    add(Sev.Attention, fi, label, $"type « {tname} » sans paramètres de TYPE b / h : les dimensions calculées ne pourront pas être reportées dans Revit au retour.");
                var smt = fi.StructuralMaterialType;
                if (smt != Autodesk.Revit.DB.Structure.StructuralMaterialType.Concrete && smt != Autodesk.Revit.DB.Structure.StructuralMaterialType.PrecastConcrete && smt != Autodesk.Revit.DB.Structure.StructuralMaterialType.Steel && fi.StructuralMaterialId == ElementId.InvalidElementId)
                    add(Sev.Info, fi, label, "matériau structurel non défini : traité comme béton armé.");
            }
        }
    }

    // ------------------------------------------------------------------ dalles et radiers
    private static void CheckFloors(Document doc, Func<Element, bool> skip, Action<string> count, Action<Sev, Element, string, string> add)
    {
        foreach (Floor fl in new FilteredElementCollector(doc).OfClass(typeof(Floor)).WhereElementIsNotElementType().Cast<Floor>())
        {
            if (skip(fl)) continue;
            var isStruct = fl.get_Parameter(BuiltInParameter.FLOOR_PARAM_IS_STRUCTURAL);
            bool raft = fl.Category != null && fl.Category.Id.Value == (long)BuiltInCategory.OST_StructuralFoundation;
            string label = raft ? "Radier" : "Dalle";
            if (isStruct != null && isStruct.AsInteger() == 0 && !raft) { add(Sev.Info, fl, label, "case « Structurel » décochée : non exportée (cochez-la si elle porte)."); continue; }
            if ((fl.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() ?? "").StartsWith(ReinforceCommand.FootingTag)) continue;
            count(raft ? "radier(s)" : "dalle(s)");
            var cs = fl.FloorType?.GetCompoundStructure();
            if (cs == null) { add(Sev.Erreur, fl, label, "type sans structure composée : épaisseur illisible."); continue; }
            double th = M(cs.GetWidth());
            if (th < 0.05) { add(Sev.Erreur, fl, label, $"épaisseur {th * 100:0.#} cm trop faible : ignorée."); continue; }
            if (cs.LayerCount > 1 && cs.StructuralMaterialIndex < 0)
                add(Sev.Attention, fl, label, $"type « {fl.FloorType!.Name} » à plusieurs couches sans couche marquée « Structure » : l'épaisseur ne pourra pas être reportée au retour.");
            if (raft && fl.get_BoundingBox(null) == null) add(Sev.Erreur, fl, label, "géométrie illisible.");
        }
    }

    // ------------------------------------------------------------------ voiles
    private static void CheckWalls(Document doc, Func<Element, bool> skip, Action<string> count, Action<Sev, Element, string, string> add)
    {
        foreach (Wall wl in new FilteredElementCollector(doc).OfClass(typeof(Wall)).WhereElementIsNotElementType().Cast<Wall>())
        {
            if (skip(wl)) continue;
            var st = wl.get_Parameter(BuiltInParameter.WALL_STRUCTURAL_SIGNIFICANT);
            bool structural = st == null || st.AsInteger() != 0;
            if (!structural) continue;
            count("voile(s)");
            if (wl.WallType != null && wl.WallType.Kind != WallKind.Basic) { add(Sev.Attention, wl, "Voile", $"mur de type {wl.WallType.Kind} (rideau / empilé) : dimensions non reportables au retour."); }
            var g = WallGeo.Read(wl);
            if (g == null) { add(Sev.Erreur, wl, "Voile", "mur courbe ou illisible : ignoré."); continue; }
            double len = M(g.Length), hgt = M(g.Height), th = M(g.Thickness);
            if (len < 0.5 || hgt < 0.5 || th < 0.08) { add(Sev.Erreur, wl, "Voile", $"dimensions {len:0.##} x {hgt:0.##} x {th:0.##} m trop petites : ignoré."); continue; }
            var cs = wl.WallType?.GetCompoundStructure();
            if (cs != null && cs.LayerCount > 1 && cs.StructuralMaterialIndex < 0)
                add(Sev.Attention, wl, "Voile", $"type « {wl.WallType!.Name} » à plusieurs couches sans couche « Structure » : épaisseur non reportable au retour.");
        }
    }

    // ------------------------------------------------------------------ fondations
    private static void CheckFoundations(Document doc, Func<Element, bool> skip, Action<string> count, Action<Sev, Element, string, string> add)
    {
        foreach (WallFoundation wf in new FilteredElementCollector(doc).OfClass(typeof(WallFoundation)).WhereElementIsNotElementType().Cast<WallFoundation>())
        {
            if (skip(wf)) continue;
            count("semelle(s) filante(s)");
            if (wf.Location is not LocationCurve lc || lc.Curve is not Line) { add(Sev.Erreur, wf, "Semelle filante", "tracé non rectiligne : ignorée."); continue; }
            var t = doc.GetElement(wf.GetTypeId());
            if (t?.get_Parameter(BuiltInParameter.CONTINUOUS_FOOTING_WIDTH) == null) add(Sev.Attention, wf, "Semelle filante", "largeur du type illisible : largeur déduite de la géométrie.");
            if (Find(t, "Foundation Thickness", "Thickness", "Épaisseur de la fondation", "Epaisseur de la fondation", "Épaisseur", "Epaisseur") == null)
                add(Sev.Attention, wf, "Semelle filante", "épaisseur introuvable dans le type : déduite de la géométrie, non reportable au retour.");
        }
        foreach (FamilyInstance fi in new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFoundation).OfClass(typeof(FamilyInstance)).WhereElementIsNotElementType().Cast<FamilyInstance>())
        {
            if (skip(fi)) continue;
            count("semelle(s) isolée(s)");
            if (Find(fi.Symbol, "Length", "Longueur") == null || Find(fi.Symbol, "Width", "Largeur") == null)
                add(Sev.Attention, fi, "Semelle isolée", $"famille « {fi.Symbol.Family.Name} » sans paramètres de type Longueur / Largeur : dimensions non reportables au retour.");
            if (Find(fi.Symbol, "Foundation Thickness", "Thickness", "Épaisseur de la fondation", "Epaisseur de la fondation", "Épaisseur", "Epaisseur") == null)
                add(Sev.Info, fi, "Semelle isolée", "épaisseur introuvable dans le type : non reportable au retour.");
            var bb = fi.get_BoundingBox(null);
            if (bb == null) { add(Sev.Erreur, fi, "Semelle isolée", "géométrie illisible : ignorée."); continue; }
            double a = M(bb.Max.X - bb.Min.X), b = M(bb.Max.Y - bb.Min.Y);
            if (a < 0.4 || b < 0.4 || a > 8 || b > 8) add(Sev.Attention, fi, "Semelle isolée", $"emprise {a:0.##} x {b:0.##} m hors plage (0,4 à 8 m) : ignorée.");
        }
    }
}
