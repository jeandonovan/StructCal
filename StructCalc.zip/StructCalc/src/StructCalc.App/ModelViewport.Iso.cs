using System.Windows;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.UI;

/// <summary>Dessin des poutres et poteaux directement en vue 3D : accrochage aux nœuds, verticale d'un poteau (accrochée aux niveaux),
/// puis point sur le plan de travail horizontal (axes, alignement, pas de grille).</summary>
public sealed partial class ModelViewport
{
    /// <summary>Point du plan horizontal Z = z situé sous le point écran p (ortho ou perspective). False si le plan est vu de chant.</summary>
    private bool PlanePoint(Point p, double z, out double x, out double y)
    {
        x = _pivot.X; y = _pivot.Y;
        const double h = 0.5;
        for (int it = 0; it < 10; it++)
        {
            var s0 = S(x, y, z);
            double ex = p.X - s0.X, ey = p.Y - s0.Y;
            if (ex * ex + ey * ey < 1e-6) return true;
            var sx = S(x + h, y, z); var sy = S(x, y + h, z);
            double a = (sx.X - s0.X) / h, b = (sy.X - s0.X) / h, c = (sx.Y - s0.Y) / h, d = (sy.Y - s0.Y) / h;
            double det = a * d - b * c;
            if (Math.Abs(det) < 1e-3 * _scale * _scale) return false;      // plan vu presque de chant
            x += (ex * d - b * ey) / det; y += (a * ey - c * ex) / det;
            if (Math.Abs(x) > 1e5 || Math.Abs(y) > 1e5) return false;
        }
        var s1 = S(x, y, z);
        return (p.X - s1.X) * (p.X - s1.X) + (p.Y - s1.Y) * (p.Y - s1.Y) < 4;
    }

    private SnapHit? ComputeSnapIso(Point p)
    {
        if (Model == null) return null;
        var info = GetInfo();

        // 1. nœud existant sous le curseur
        if (SnapEnabled && SnapNodes)
        {
            int nd = NearestNode(p, SnapPixels);
            if (nd != -1)
            {
                var n = Model.Nodes.First(q => q.Id == nd);
                return new SnapHit { Kind = SnapKind.Node, NodeId = nd, Label = "Nœud " + nd, World = new Vec3(n.X, n.Y, n.Z) };
            }
        }

        // 2. poteau : verticale du point de départ, accrochée aux niveaux
        if (Tool == EditTool.Member && _pendingNodeId != -1)
        {
            var pn = Model.Nodes.FirstOrDefault(q => q.Id == _pendingNodeId);
            if (pn != null)
            {
                var a = S(pn.X, pn.Y, pn.Z); var b = S(pn.X, pn.Y, pn.Z + 1);
                double dx = b.X - a.X, dy = b.Y - a.Y, l2 = dx * dx + dy * dy;
                if (l2 > 1e-6)
                {
                    double t = ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / l2;          // hauteur (m) au-dessus du nœud de départ
                    double qx = a.X + t * dx, qy = a.Y + t * dy;
                    double dist = Math.Sqrt((p.X - qx) * (p.X - qx) + (p.Y - qy) * (p.Y - qy));
                    if (dist <= 10 && Math.Abs(t) > 0.1)
                    {
                        double z = pn.Z + t; string lab = "Poteau";
                        double tolZ = SnapPixels / Math.Sqrt(l2);
                        double bd = tolZ; bool lvl = false;
                        if (SnapEnabled && SnapLevels)
                            foreach (var lv in info.Levels)
                                if (Math.Abs(lv.Z - z) <= bd) { bd = Math.Abs(lv.Z - z); z = lv.Z; lab = "Poteau jusqu'à " + lv.Name; lvl = true; }
                        if (!lvl && SnapEnabled && SnapStep) z = Sn(z);
                        if (Math.Abs(z - pn.Z) > 1e-6)
                            return new SnapHit { Kind = lvl ? SnapKind.Level : SnapKind.Track, Label = $"{lab}  (z = {z:0.###})", World = new Vec3(pn.X, pn.Y, z) };
                    }
                }
            }
        }

        // 3. plan de travail horizontal (niveau courant)
        double z0 = WorkOffset;
        if (!PlanePoint(p, z0, out double x, out double y)) return null;
        var hit = new SnapHit { Kind = SnapKind.None };
        if (SnapEnabled)
        {
            double tol = SnapPixels / Math.Max(_scale, 1e-6);
            bool lx = false, ly = false; string nx = "", ny = "";
            if (SnapOnAxis || SnapGridInt)
            {
                double bx = tol; foreach (var ax in info.XAxes) if (Math.Abs(ax.Pos - x) <= bx) { bx = Math.Abs(ax.Pos - x); x = ax.Pos; lx = true; nx = ax.Name; }
                double by = tol; foreach (var ay in info.YAxes) if (Math.Abs(ay.Pos - y) <= by) { by = Math.Abs(ay.Pos - y); y = ay.Pos; ly = true; ny = ay.Name; }
            }
            if (SnapTrack && Tool == EditTool.Member && _pendingNodeId != -1)
            {
                var pn = Model.Nodes.FirstOrDefault(q => q.Id == _pendingNodeId);
                if (pn != null && Math.Abs(pn.Z - z0) < 1e-3)
                {
                    if (!lx && Math.Abs(pn.X - x) <= tol) { x = pn.X; lx = true; nx = "aligné"; }
                    if (!ly && Math.Abs(pn.Y - y) <= tol) { y = pn.Y; ly = true; ny = "aligné"; }
                }
            }
            if (!lx && SnapStep) x = Sn(x);
            if (!ly && SnapStep) y = Sn(y);
            if (lx && ly) { hit.Kind = SnapKind.GridCross; hit.Label = $"Axes {nx} × {ny}"; }
            else if (lx || ly) { hit.Kind = SnapKind.OnAxis; hit.Label = "Axe " + (lx ? nx : ny); }
            else if (SnapStep) hit.Kind = SnapKind.Step;
        }
        hit.World = new Vec3(Math.Round(x, 6), Math.Round(y, 6), z0);
        return hit;
    }
}
