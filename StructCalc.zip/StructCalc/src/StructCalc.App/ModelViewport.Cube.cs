using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace StructCalc.UI;

/// <summary>Cube de navigation (type ViewCube Autodesk) : faces, arêtes et coins cliquables, glisser = orbite, menu déroulant des vues.</summary>
public partial class ModelViewport
{
    private double CubeS => 22 * CubeSettings.Size;           // demi-arête en pixels
    private double CubeExt => CubeS * 1.8;                     // demi-étendue de la projection (diagonale du cube)
    private readonly List<(Point[] Poly, int Dx, int Dy, int Dz)> _cubeCells = new();
    private (int, int, int)? _cubeHot;
    private bool _cubeDown, _faceView;
    private Rect _cubeBtn;
    private Point _cubeC;
    private static double _cubeTextScale;     // échelle commune des textes (unités de face par unité de police)

    /// <summary>Demande de bascule perspective/orthographique depuis le menu du cube.</summary>
    public event Action<bool>? PerspectiveRequested;

    // (nom, normale, haut du texte) : le texte se lit de l'extérieur, droite = haut x normale
    private static readonly (string Name, int[] N, int[] T1, int[] T2, int[] Up)[] CubeFaces =
    {
        ("HAUT",   new[]{0,0,1},  new[]{1,0,0}, new[]{0,1,0}, new[]{0,1,0}),
        ("BAS",    new[]{0,0,-1}, new[]{1,0,0}, new[]{0,1,0}, new[]{0,1,0}),
        ("AVANT",  new[]{0,-1,0}, new[]{1,0,0}, new[]{0,0,1}, new[]{0,0,1}),
        ("ARRIÈRE",new[]{0,1,0},  new[]{1,0,0}, new[]{0,0,1}, new[]{0,0,1}),
        ("GAUCHE", new[]{-1,0,0}, new[]{0,1,0}, new[]{0,0,1}, new[]{0,0,1}),
        ("DROITE", new[]{1,0,0},  new[]{0,1,0}, new[]{0,0,1}, new[]{0,0,1}),
    };

    private static readonly double[] CubeCut = { -1, -0.5, 0.5, 1 };

    private Point CubeCenter()
    {
        double ext = CubeExt, m = 12, w = _c.ActualWidth, h = _c.ActualHeight;
        double cx = CubeSettings.Corner is 0 or 2 ? m + ext : w - m - ext;
        double cy = CubeSettings.Corner is 0 or 1 ? m + ext : h - m - 24 - ext;
        return new Point(cx, cy);
    }

    private static SolidColorBrush Rgba(double alpha, int r, int g, int b)
    {
        var br = new SolidColorBrush(Color.FromArgb((byte)Math.Clamp((int)Math.Round(alpha * 255), 0, 255), (byte)Math.Clamp(r, 0, 255), (byte)Math.Clamp(g, 0, 255), (byte)Math.Clamp(b, 0, 255)));
        br.Freeze(); return br;
    }

    private static TextBlock CubeLabel(string text)
        => new() { Text = text, FontFamily = new FontFamily("Segoe UI"), FontSize = 10, FontWeight = FontWeights.SemiBold, Padding = new Thickness(0), IsHitTestVisible = false };

    /// <summary>Échelle unique pour tous les textes : le plus long (« ARRIÈRE ») tient dans 78 % de la largeur de la face, la hauteur dans 34 %.</summary>
    private static double CubeTextScale()
    {
        if (_cubeTextScale > 0) return _cubeTextScale;
        double best = double.MaxValue;
        foreach (var f in CubeFaces)
        {
            var tb = CubeLabel(f.Name); tb.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            var ds = tb.DesiredSize;
            if (ds.Width < 1 || ds.Height < 1) continue;
            best = Math.Min(best, Math.Min(2 * 0.78 / ds.Width, 2 * 0.34 / ds.Height));
        }
        _cubeTextScale = best < double.MaxValue ? best : 0.02;
        return _cubeTextScale;
    }

    private void DrawCube()
    {
        _cubeCells.Clear();
        double w = _c.ActualWidth;
        if (w < 200 || _c.ActualHeight < 200) return;
        double R = CubeS, op = CubeSettings.Opacity;
        _cubeC = CubeCenter();
        double strokeA = 0.40 + 0.60 * op;
        foreach (var (name, n, t1, t2, up) in CubeFaces)
        {
            var vn = V3(n[0], n[1], n[2]);
            if (vn.D > -0.02) continue;                       // face tournée vers l'arrière
            double lit = Math.Min(1, 0.80 + 0.2 * (-vn.D));
            for (int i = -1; i <= 1; i++)
                for (int j = -1; j <= 1; j++)
                {
                    var poly = new Point[4];
                    double[] a = { CubeCut[i + 1], CubeCut[i + 2], CubeCut[i + 2], CubeCut[i + 1] };
                    double[] b = { CubeCut[j + 1], CubeCut[j + 1], CubeCut[j + 2], CubeCut[j + 2] };
                    for (int k = 0; k < 4; k++)
                    {
                        double x = n[0] + a[k] * t1[0] + b[k] * t2[0];
                        double y = n[1] + a[k] * t1[1] + b[k] * t2[1];
                        double z = n[2] + a[k] * t1[2] + b[k] * t2[2];
                        var v = V3(x, y, z);
                        poly[k] = new Point(_cubeC.X + v.U * R, _cubeC.Y - v.V * R);
                    }
                    int dx = n[0] + i * t1[0] + j * t2[0], dy = n[1] + i * t1[1] + j * t2[1], dz = n[2] + i * t1[2] + j * t2[2];
                    bool hot = _cubeHot.HasValue && _cubeHot.Value == (dx, dy, dz);
                    int kind = (i != 0 ? 1 : 0) + (j != 0 ? 1 : 0);          // 0 face, 1 arête, 2 coin
                    double baseG = kind == 0 ? 246 : kind == 1 ? 218 : 196;
                    int g = (int)(baseG * lit);
                    Brush fill = hot ? Rgba(Math.Max(op, 0.75), 255, 183, 77) : Rgba(op, g - 4, g, Math.Min(255, g + 8));
                    var pg = new Polygon { Fill = fill, Stroke = Rgba(strokeA, 96, 125, 139), StrokeThickness = 0.8, StrokeLineJoin = PenLineJoin.Round, IsHitTestVisible = false };
                    foreach (var p in poly) pg.Points.Add(p);
                    _c.Children.Add(pg);
                    _cubeCells.Add((poly, dx, dy, dz));
                }
            DrawCubeLabel(name, n, up, vn.D);
        }
        // bouton « liste déroulante »
        double ext = CubeExt;
        _cubeBtn = new Rect(_cubeC.X - 26, _cubeC.Y + ext + 3, 52, 16);
        bool hotBtn = _cubeHot.HasValue && _cubeHot.Value == (9, 9, 9);
        var rb = new Rectangle { Width = _cubeBtn.Width, Height = _cubeBtn.Height, RadiusX = 8, RadiusY = 8, Fill = hotBtn ? Rgba(1, 255, 183, 77) : Rgba(Math.Max(0.55, op), 236, 239, 241), Stroke = Rgba(strokeA, 96, 125, 139), StrokeThickness = 0.8, IsHitTestVisible = false };
        Canvas.SetLeft(rb, _cubeBtn.X); Canvas.SetTop(rb, _cubeBtn.Y);
        _c.Children.Add(rb);
        var bt = new TextBlock { Text = "Vues ▾", FontSize = 10, FontWeight = FontWeights.SemiBold, Foreground = Dark, IsHitTestVisible = false };
        bt.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        Canvas.SetLeft(bt, _cubeBtn.X + (_cubeBtn.Width - bt.DesiredSize.Width) / 2); Canvas.SetTop(bt, _cubeBtn.Y + (_cubeBtn.Height - bt.DesiredSize.Height) / 2);
        _c.Children.Add(bt);
    }

    /// <summary>Texte collé sur la face : transformation affine exacte (projection orthographique), donc il suit la face en rotation et ne déborde jamais.</summary>
    private void DrawCubeLabel(string name, int[] n, int[] up, double depth)
    {
        if (!CubeSettings.ShowText) return;
        double facing = -depth;                                   // 1 = face de plein fouet, 0 = de profil
        double fade = Math.Clamp((facing - 0.22) / 0.30, 0, 1);   // les textes disparaissent en douceur sur les faces très obliques
        double alpha = CubeSettings.TextOpacity * fade;
        if (alpha < 0.04) return;
        double R = CubeS, s = CubeTextScale();
        // repère de lecture : up = haut du texte, right = up x normale (lu depuis l'extérieur)
        double[] r = { up[1] * n[2] - up[2] * n[1], up[2] * n[0] - up[0] * n[2], up[0] * n[1] - up[1] * n[0] };
        var pc = V3(n[0], n[1], n[2]);
        var pr = V3(n[0] + r[0], n[1] + r[1], n[2] + r[2]);
        var pu = V3(n[0] + up[0], n[1] + up[1], n[2] + up[2]);
        double rx = (pr.U - pc.U) * R, ry = -(pr.V - pc.V) * R;      // un pas « droite » à l'écran
        double ux = (pu.U - pc.U) * R, uy = -(pu.V - pc.V) * R;      // un pas « haut » à l'écran
        var tb = CubeLabel(name);
        tb.Foreground = Rgba(alpha, 38, 50, 56);
        tb.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        double tw = tb.DesiredSize.Width, th = tb.DesiredSize.Height;
        double cx = _cubeC.X + pc.U * R, cy = _cubeC.Y - pc.V * R;
        // écran = centre + (px - tw/2) * s * right + (py - th/2) * (-s) * up
        var m = new Matrix(s * rx, s * ry, -s * ux, -s * uy,
            cx - tw / 2 * s * rx + th / 2 * s * ux,
            cy - tw / 2 * s * ry + th / 2 * s * uy);
        tb.RenderTransform = new MatrixTransform(m);
        Canvas.SetLeft(tb, 0); Canvas.SetTop(tb, 0);
        _c.Children.Add(tb);
    }

    private bool InCubeZone(Point p)
    {
        if (_c.ActualWidth < 200 || _c.ActualHeight < 200) return false;
        var c = CubeCenter(); double e = CubeExt + 4;
        return Math.Abs(p.X - c.X) <= e && p.Y >= c.Y - e && p.Y <= c.Y + e + 22;
    }

    private (int, int, int)? CubeHit(Point p)
    {
        if (_cubeBtn.Contains(p)) return (9, 9, 9);
        foreach (var cell in _cubeCells)
            if (InQuad(cell.Poly, p)) return (cell.Dx, cell.Dy, cell.Dz);
        return null;
    }

    private static bool InQuad(Point[] q, Point p)
    {
        bool pos = false, neg = false;
        for (int i = 0; i < q.Length; i++)
        {
            var a = q[i]; var b = q[(i + 1) % q.Length];
            double cr = (b.X - a.X) * (p.Y - a.Y) - (b.Y - a.Y) * (p.X - a.X);
            if (cr > 0) pos = true; else if (cr < 0) neg = true;
        }
        return !(pos && neg);
    }

    /// <summary>Met à jour le survol ; renvoie true si le pointeur est sur le cube.</summary>
    private bool CubeHover(Point p)
    {
        var h = InCubeZone(p) ? CubeHit(p) : null;
        if (h != _cubeHot) { _cubeHot = h; _c.Cursor = h.HasValue ? Cursors.Hand : null; Redraw(); }
        return h.HasValue;
    }

    private bool CubeLeftDown(Point p)
    {
        if (!InCubeZone(p)) return false;
        _down = _last = p; _moved = false; _cubeDown = true;
        _pivot = ComputePivot();
        _c.CaptureMouse();
        return true;
    }

    private bool CubeMove(Point p)
    {
        if (!_cubeDown) return false;
        if (!_moved && (Math.Abs(p.X - _down.X) > 4 || Math.Abs(p.Y - _down.Y) > 4)) _moved = true;
        if (_moved) { OrbitBy((p.X - _last.X) * 0.01, (p.Y - _last.Y) * 0.01); _last = p; Redraw(); }
        return true;
    }

    private bool CubeLeftUp(Point p)
    {
        if (!_cubeDown) return false;
        _cubeDown = false; _c.ReleaseMouseCapture();
        if (_moved) return true;
        var h = CubeHit(p);
        if (!h.HasValue) return true;
        if (h.Value == (9, 9, 9)) ShowViewMenu(new Point(_cubeBtn.X, _cubeBtn.Bottom));
        else GoToDirection(h.Value.Item1, h.Value.Item2, h.Value.Item3);
        return true;
    }

    private bool CubeRightDown(Point p)
    {
        if (!InCubeZone(p)) return false;
        ShowViewMenu(new Point(p.X, p.Y));
        return true;
    }

    /// <summary>Oriente la vue pour regarder le modèle depuis la direction (dx,dy,dz) du repère monde.</summary>
    public void GoToDirection(double dx, double dy, double dz)
    {
        double len = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-9) return;
        dx /= len; dy /= len; dz /= len;
        bool face = (Math.Abs(dx) > 0.999) || (Math.Abs(dy) > 0.999) || (Math.Abs(dz) > 0.999);
        if (Math.Abs(dz) > 0.999) { _yaw = 0; _pitch = dz > 0 ? Math.PI / 2 : -Math.PI / 2; Mode = dz > 0 ? ViewMode.Plan : ViewMode.Iso; }
        else
        {
            _pitch = Math.Asin(Math.Max(-1, Math.Min(1, dz)));
            _yaw = Math.Atan2(-dx, -dy);
            Mode = face && dy < -0.999 ? ViewMode.Elevation
                 : face && dx > 0.999 ? ViewMode.Side
                 : ViewMode.Iso;
        }
        _faceView = face && Mode == ViewMode.Iso;
        ZoomExtents();
    }

    private void ShowViewMenu(Point at)
    {
        var cm = new ContextMenu { PlacementTarget = _c, Placement = PlacementMode.RelativePoint, HorizontalOffset = at.X, VerticalOffset = at.Y };
        void Add(string header, Action act, bool check = false, bool isChecked = false)
        {
            var mi = new MenuItem { Header = header, IsCheckable = check, IsChecked = isChecked };
            mi.Click += (s, e) => act();
            cm.Items.Add(mi);
        }
        Add("Accueil (isométrique)", () => SetMode(ViewMode.Iso));
        cm.Items.Add(new Separator());
        Add("Haut (plan)", () => GoToDirection(0, 0, 1));
        Add("Bas", () => GoToDirection(0, 0, -1));
        Add("Avant (élévation)", () => GoToDirection(0, -1, 0));
        Add("Arrière", () => GoToDirection(0, 1, 0));
        Add("Gauche", () => GoToDirection(-1, 0, 0));
        Add("Droite (côté)", () => GoToDirection(1, 0, 0));
        cm.Items.Add(new Separator());
        Add("Isométrique sud-ouest", () => GoToDirection(-1, -1, 1));
        Add("Isométrique sud-est", () => GoToDirection(1, -1, 1));
        Add("Isométrique nord-est", () => GoToDirection(1, 1, 1));
        Add("Isométrique nord-ouest", () => GoToDirection(-1, 1, 1));
        cm.Items.Add(new Separator());
        Add("Perspective", () => { if (PerspectiveRequested != null) PerspectiveRequested(!Perspective); else { Perspective = !Perspective; Redraw(); } }, true, Perspective);
        Add("Ajuster à la fenêtre", ZoomExtents);
        cm.Items.Add(new Separator());
        Add("Paramètres du cube…", ShowCubeSettings);
        cm.IsOpen = true;
    }

    private Window? _cubeDlg;

    /// <summary>Fenêtre de réglage du cube : opacité, taille, textes, coin d'affichage (effet immédiat, mémorisé).</summary>
    private void ShowCubeSettings()
    {
        if (_cubeDlg != null) { _cubeDlg.Activate(); return; }
        var dlg = new Window
        {
            Title = "Cube de navigation", Width = 300, SizeToContent = SizeToContent.Height, ResizeMode = ResizeMode.NoResize,
            WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = Application.Current?.MainWindow, ShowInTaskbar = false,
        };
        var st = new StackPanel { Margin = new Thickness(14) };
        Slider AddSlider(string label, double min, double max, double val, Action<double> set, string unit = "%")
        {
            var head = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
            var val_t = new TextBlock { Text = $"{val * 100:0}{unit}", HorizontalAlignment = HorizontalAlignment.Right };
            DockPanel.SetDock(val_t, Dock.Right);
            head.Children.Add(val_t); head.Children.Add(new TextBlock { Text = label });
            var sl = new Slider { Minimum = min, Maximum = max, Value = val, TickFrequency = (max - min) / 10 };
            sl.ValueChanged += (a, b) => { set(sl.Value); val_t.Text = $"{sl.Value * 100:0}{unit}"; CubeSettings.Save(); Redraw(); };
            st.Children.Add(head); st.Children.Add(sl);
            return sl;
        }
        var s1 = AddSlider("Opacité des faces", 0.1, 1, CubeSettings.Opacity, v => CubeSettings.Opacity = v);
        var s2 = AddSlider("Opacité des textes", 0, 1, CubeSettings.TextOpacity, v => CubeSettings.TextOpacity = v);
        var s3 = AddSlider("Taille", 0.6, 2, CubeSettings.Size, v => CubeSettings.Size = v);
        var chk = new CheckBox { Content = "Afficher les textes sur les faces", IsChecked = CubeSettings.ShowText, Margin = new Thickness(0, 10, 0, 0) };
        chk.Click += (a, b) => { CubeSettings.ShowText = chk.IsChecked == true; CubeSettings.Save(); Redraw(); };
        st.Children.Add(chk);
        st.Children.Add(new TextBlock { Text = "Position", Margin = new Thickness(0, 10, 0, 2) });
        var cb = new ComboBox();
        foreach (var t in new[] { "Haut gauche", "Haut droite", "Bas gauche", "Bas droite" }) cb.Items.Add(t);
        cb.SelectedIndex = CubeSettings.Corner;
        cb.SelectionChanged += (a, b) => { CubeSettings.Corner = Math.Max(0, cb.SelectedIndex); CubeSettings.Save(); Redraw(); };
        st.Children.Add(cb);
        var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        var bReset = new Button { Content = "Réinitialiser", Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(0, 0, 8, 0) };
        bReset.Click += (a, b) =>
        {
            CubeSettings.Reset(); s1.Value = CubeSettings.Opacity; s2.Value = CubeSettings.TextOpacity; s3.Value = CubeSettings.Size;
            chk.IsChecked = CubeSettings.ShowText; cb.SelectedIndex = CubeSettings.Corner; Redraw();
        };
        var bOk = new Button { Content = "Fermer", Padding = new Thickness(14, 3, 14, 3), IsDefault = true };
        bOk.Click += (a, b) => dlg.Close();
        row.Children.Add(bReset); row.Children.Add(bOk);
        st.Children.Add(row);
        dlg.Content = st;
        dlg.Closed += (a, b) => _cubeDlg = null;
        _cubeDlg = dlg;
        dlg.Show();
    }
}
