using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Engine.Drawing;

namespace StructCalc.UI;

/// <summary>Hôte d'un Visual de dessin (affichage à l'écran).</summary>
public sealed class VisualHost : FrameworkElement
{
    private DrawingVisual? _v;
    private double _w, _h;
    public void SetVisual(DrawingVisual v, double w, double h)
    {
        if (_v != null) RemoveVisualChild(_v);
        _v = v; _w = w; _h = h;
        AddVisualChild(v);
        InvalidateMeasure();
    }
    protected override int VisualChildrenCount => _v == null ? 0 : 1;
    protected override Visual GetVisualChild(int index) => _v!;
    protected override Size MeasureOverride(Size availableSize) => new Size(_w, _h);
}

/// <summary>Rendu d'une planche (mm de papier -> pixels) pour l'écran et l'impression.</summary>
public static class SheetRenderer
{
    private static Brush ColorFor(int aci, bool color)
    {
        if (!color) return aci == 8 ? Brushes.Silver : Brushes.Black;
        string hex = aci switch
        {
            1 => "#D32F2F", 2 => "#B8860B", 3 => "#2E7D32", 4 => "#00838F", 5 => "#1565C0", 6 => "#AD1457", 8 => "#B0B0B0", 9 => "#8A8A8A", 30 => "#E65100", _ => "#111111"
        };
        var b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex)!;
        b.Freeze();
        return b;
    }

    public static DrawingVisual Render(Sheet s, double k, bool color, bool handle = false)
    {
        var dv = new DrawingVisual();
        double H = s.Height * k;
        var pens = new Dictionary<string, Pen>();
        Pen PenFor(string layer)
        {
            if (pens.TryGetValue(layer, out var p)) return p;
            double mm = layer switch { "CONTOUR" => 0.35, "BETON" => 0.35, "CARTOUCHE" => 0.5, "ARMATURES" => 0.5, "ARMATURES2" => 0.5, "ARMATURES_HAUTES" => 0.5, "ACIER" => 0.4, "CADRES" => 0.3, "COUPES" => 0.7, "REPERES" => 0.25, "TABLEAU" => 0.2, "HACHURES" => 0.1, _ => 0.2 };
            p = new Pen(ColorFor(Layers.ColorOf(layer), color), Math.Max(mm * k, 0.7));
            p.StartLineCap = PenLineCap.Round; p.EndLineCap = PenLineCap.Round;
            p.Freeze();
            pens[layer] = p;
            return p;
        }
        using (var dc = dv.RenderOpen())
        {
            dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, s.Width * k, H));
            foreach (var e in s.Items)
            {
                switch (e.Kind)
                {
                    case EntKind.Line:
                        dc.DrawLine(PenFor(e.Layer), new Point(e.X1 * k, H - e.Y1 * k), new Point(e.X2 * k, H - e.Y2 * k));
                        break;
                    case EntKind.Circle:
                        if (e.Fill) dc.DrawEllipse(ColorFor(Layers.ColorOf(e.Layer), color), null, new Point(e.X1 * k, H - e.Y1 * k), e.R * k, e.R * k);
                        else dc.DrawEllipse(null, PenFor(e.Layer), new Point(e.X1 * k, H - e.Y1 * k), e.R * k, e.R * k);
                        break;
                    case EntKind.Text:
                    {
                        var ft = new FormattedText(e.Text, CultureInfo.GetCultureInfo("fr-FR"), FlowDirection.LeftToRight,
                                                   new Typeface("Segoe UI"), Math.Max(e.H * k * 1.35, 3), ColorFor(Layers.ColorOf(e.Layer), color), 1.0);
                        double x = e.X1 * k, y = H - e.Y1 * k;
                        if (Math.Abs(e.Rot) > 1e-9) dc.PushTransform(new RotateTransform(-e.Rot, x, y));
                        dc.DrawText(ft, new Point(x, y - ft.Baseline));
                        if (Math.Abs(e.Rot) > 1e-9) dc.Pop();
                        break;
                    }
                }
            }
            // poignée d'étirement du dessin (écran seulement) : tirer le coin pour agrandir / réduire, l'échelle suit
            if (handle && SheetLayout.ContentBox(s) is { } box)
            {
                var dash = new Pen(Brushes.DodgerBlue, 1) { DashStyle = new DashStyle(new double[] { 4, 3 }, 0) };
                dc.DrawRectangle(null, dash, new Rect(box.X0 * k, H - box.Y1 * k, (box.X1 - box.X0) * k, (box.Y1 - box.Y0) * k));
                double hs = 1.6 * k;
                dc.DrawRectangle(Brushes.DodgerBlue, new Pen(Brushes.White, 1), new Rect(box.X1 * k - hs, H - box.Y0 * k - hs, 2 * hs, 2 * hs));
            }
        }
        return dv;
    }
}

/// <summary>Visionneuse des planches générées : zoom, export DXF, conversion DWG (ODA File Converter), impression.</summary>
public sealed class SheetViewerWindow : Window
{
    private readonly List<Sheet> _sheets;
    private readonly ListBox _list = new() { Width = 250 };
    private readonly Canvas _scroll = new() { ClipToBounds = true, Background = Brushes.DimGray, Focusable = true };
    private readonly VisualHost _host = new();
    private readonly MatrixTransform _mt = new(Matrix.Identity);
    private const double BaseK = 3.0;                       // pixels par mm de papier à l'échelle de base ; le zoom libre est une transformation
    private bool _pan; private Point _panStart; private Matrix _panMatrix;
    private readonly ComboBox _ver = new() { Width = 150 };
    private readonly ComboBox _scaleBox = new() { Width = 130 };
    private bool _updatingScale;
    private readonly string _project;

    public SheetViewerWindow(List<Sheet> sheets, string project)
    {
        _sheets = sheets; _project = project;
        Title = $"Plans d'exécution - {project} ({sheets.Count} planches) - {AppInfo.Name}";
        Width = 1400; Height = 860; WindowStartupLocation = WindowStartupLocation.CenterOwner;

        var bar = new WrapPanel { Margin = new Thickness(6) };
        bar.Children.Add(Btn("💾 Exporter cette planche (DXF)", (s, e) => ExportOne()));
        bar.Children.Add(Btn("📁 Exporter toutes (DXF)", (s, e) => ExportAll()));
        foreach (var v in new[] { "ACAD2018", "ACAD2013", "ACAD2010", "ACAD2007", "ACAD2004", "ACAD2000", "ACAD14", "ACAD12" }) _ver.Items.Add(v);
        _ver.SelectedIndex = 0;
        bar.Children.Add(Btn("🔄 Convertir en DWG...", (s, e) => ConvertDwg()));
        bar.Children.Add(new TextBlock { Text = "version :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 4, 0) });
        bar.Children.Add(_ver);
        bar.Children.Add(Btn("🖨 Imprimer cette planche", (s, e) => PrintSheets(new[] { Current() })));
        bar.Children.Add(Btn("🖨 Imprimer toutes", (s, e) => PrintSheets(_sheets)));
        bar.Children.Add(Btn("＋", (s, e) => ZoomAt(1.25, Center())));
        bar.Children.Add(Btn("－", (s, e) => ZoomAt(1 / 1.25, Center())));
        bar.Children.Add(Btn("Ajuster", (s, e) => Fit()));
        bar.Children.Add(Btn("100 %", (s, e) => Zoom100()));
        bar.Children.Add(new TextBlock { Text = "Échelle :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 4, 0), FontWeight = FontWeights.SemiBold });
        _scaleBox.SelectionChanged += (s, e) => ScaleBox_Changed();
        bar.Children.Add(_scaleBox);
        bar.Children.Add(new TextBlock { Text = "Molette : zoom · Ctrl + molette ou coin bleu du dessin : échelle · glisser : déplacer · double-clic : ajuster · tirer une ligne ou une colonne d'un tableau : redimensionner (le contenu s'adapte)", VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Gray, Margin = new Thickness(6, 0, 0, 0) });

        foreach (var sh in sheets) _list.Items.Add($"{sh.Number} - {sh.Title}");
        _list.SelectionChanged += (s, e) => { Fit(); RefreshScaleBox(); };
        _host.RenderTransform = _mt;
        _scroll.Children.Add(_host);
        _scroll.SizeChanged += (s, e) => { if (_first) { _first = false; Fit(); } };
        _scroll.MouseWheel += (s, e) =>
        {
            if (System.Windows.Input.Keyboard.Modifiers.HasFlag(System.Windows.Input.ModifierKeys.Control)) StepScale(e.Delta > 0);
            else ZoomAt(e.Delta > 0 ? 1.2 : 1 / 1.2, e.GetPosition(_scroll));
            e.Handled = true;
        };
        _scroll.MouseLeftButtonDown += (s, e) =>
        {
            if (TryBeginHandle(e.GetPosition(_scroll))) { e.Handled = true; return; }
            if (TryBeginTableDrag(e.GetPosition(_scroll))) { e.Handled = true; return; }
            if (e.ClickCount == 2) { Fit(); return; }
            _pan = true; _panStart = e.GetPosition(_scroll); _panMatrix = _mt.Matrix; _scroll.CaptureMouse(); _scroll.Cursor = System.Windows.Input.Cursors.SizeAll;
        };
        _scroll.MouseMove += (s, e) =>
        {
            if (_dragHandle) { DragHandle(e.GetPosition(_scroll)); return; }
            if (_dragTable != null) { DragTable(e.GetPosition(_scroll)); return; }
            if (!_pan) { UpdateTableCursor(e.GetPosition(_scroll)); return; }
            var d = e.GetPosition(_scroll) - _panStart;
            var m = _panMatrix; m.OffsetX += d.X; m.OffsetY += d.Y; _mt.Matrix = m;
        };
        _scroll.MouseLeftButtonUp += (s, e) => { if (EndHandle() || EndTableDrag()) return; EndPan(); };
        _scroll.MouseRightButtonUp += (s, e) => EndPan();
        _scroll.LostMouseCapture += (s, e) => { EndHandle(); EndTableDrag(); EndPan(); };
        _scroll.MouseDown += (s, e) =>
        {
            if (e.ChangedButton != System.Windows.Input.MouseButton.Middle) return;
            _pan = true; _panStart = e.GetPosition(_scroll); _panMatrix = _mt.Matrix; _scroll.CaptureMouse();
        };
        _scroll.MouseUp += (s, e) => { if (e.ChangedButton == System.Windows.Input.MouseButton.Middle) EndPan(); };
        PreviewKeyDown += (s, e) =>
        {
            if (e.Key == System.Windows.Input.Key.Home || e.Key == System.Windows.Input.Key.D0) { Fit(); e.Handled = true; }
            else if (e.Key == System.Windows.Input.Key.Add || e.Key == System.Windows.Input.Key.OemPlus) { ZoomAt(1.25, Center()); e.Handled = true; }
            else if (e.Key == System.Windows.Input.Key.Subtract || e.Key == System.Windows.Input.Key.OemMinus) { ZoomAt(1 / 1.25, Center()); e.Handled = true; }
        };

        var dock = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top); dock.Children.Add(bar);
        DockPanel.SetDock(_list, Dock.Left); dock.Children.Add(_list);
        dock.Children.Add(_scroll);
        Content = dock;
        _list.SelectedIndex = 0;
    }

    private bool _first = true;

    // ------------------------------------------------------------------ tableaux redimensionnables
    private SheetTable? _dragTable; private TableHit _dragHit; private Point _dragStart;

    private Point ToPaper(Point p)
    {
        var m = _mt.Matrix;
        return new Point((p.X - m.OffsetX) / m.M11 / BaseK, Current().Height - (p.Y - m.OffsetY) / m.M22 / BaseK);
    }

    private (SheetTable T, TableHit H)? FindTableHit(Point screen)
    {
        var s = Current();
        if (s.Tables.Count == 0) return null;
        var pp = ToPaper(screen);
        double tol = Math.Max(0.4, 4.5 / (_mt.Matrix.M11 * BaseK));
        foreach (var t in s.Tables)
        {
            var h = t.HitTest(pp.X, pp.Y, tol);
            if (h.HasValue) return (t, h.Value);
        }
        return null;
    }

    private void UpdateTableCursor(Point screen)
    {
        if (OverHandle(screen)) { _scroll.Cursor = System.Windows.Input.Cursors.SizeNWSE; return; }
        var f = FindTableHit(screen);
        _scroll.Cursor = f == null ? null
            : f.Value.H.Kind is TableHitKind.Column or TableHitKind.Left ? System.Windows.Input.Cursors.SizeWE : System.Windows.Input.Cursors.SizeNS;
    }

    private bool TryBeginTableDrag(Point screen)
    {
        var f = FindTableHit(screen);
        if (f == null) return false;
        _dragTable = f.Value.T; _dragHit = f.Value.H; _dragStart = ToPaper(screen);
        _dragTable.BeginDrag();
        _scroll.CaptureMouse();
        return true;
    }

    private void DragTable(Point screen)
    {
        if (_dragTable == null) return;
        var pp = ToPaper(screen);
        _dragTable.Drag(_dragHit, pp.X - _dragStart.X, pp.Y - _dragStart.Y);
        _dragTable.Rebuild(Current());
        SheetLayout.Update(Current());          // la zone libre a changé : le dessin se recentre et reste dans le cadre
        RenderCurrent();
    }

    private bool EndTableDrag()
    {
        if (_dragTable == null) return false;
        _dragTable.Remember();
        _dragTable = null;
        _scroll.ReleaseMouseCapture();
        RefreshScaleBox();
        return true;
    }

    // ------------------------------------------------------------------ échelle du dessin
    private static string Den(double d) => d.ToString(Math.Abs(d - Math.Round(d)) < 0.05 ? "0" : "0.#", CultureInfo.InvariantCulture);

    private void RefreshScaleBox()
    {
        _updatingScale = true;
        try
        {
            var s = Current();
            _scaleBox.Items.Clear();
            if (!SheetLayout.HasContent(s)) { _scaleBox.Items.Add("-"); _scaleBox.SelectedIndex = 0; _scaleBox.IsEnabled = false; return; }
            _scaleBox.IsEnabled = true;
            _scaleBox.Items.Add("Auto (ajusté)");
            foreach (var d in SheetLayout.Options(s)) _scaleBox.Items.Add("1:" + Den(d));
            if (s.AutoScale || s.BaseDen <= 0) { _scaleBox.SelectedIndex = 0; return; }
            string cur = "1:" + Den(SheetLayout.CurrentDen(s));
            int i = _scaleBox.Items.IndexOf(cur);
            if (i < 0) { _scaleBox.Items.Add(cur); i = _scaleBox.Items.Count - 1; }
            _scaleBox.SelectedIndex = i;
        }
        finally { _updatingScale = false; }
    }

    private void ScaleBox_Changed()
    {
        if (_updatingScale || _scaleBox.SelectedItem is not string t) return;
        var s = Current();
        if (!SheetLayout.HasContent(s)) return;
        if (t.StartsWith("Auto")) SheetLayout.SetAuto(s);
        else if (t.StartsWith("1:") && double.TryParse(t[2..], NumberStyles.Float, CultureInfo.InvariantCulture, out double d)) SheetLayout.SetDenominator(s, d);
        RenderCurrent();
        RefreshScaleBox();
    }

    /// <summary>Ctrl + molette : échelle normalisée suivante (agrandir = dénominateur plus petit), toujours dans la zone libre de la planche.</summary>
    private void StepScale(bool enlarge)
    {
        var s = Current();
        if (!SheetLayout.HasContent(s)) return;
        if (s.BaseDen > 0)
        {
            var opts = SheetLayout.Options(s);
            if (opts.Count == 0) return;
            double cur = SheetLayout.CurrentDen(s);
            int i = 0;
            for (int j = 0; j < opts.Count; j++) if (Math.Abs(Math.Log(opts[j] / cur)) < Math.Abs(Math.Log(opts[i] / cur))) i = j;
            int n = Math.Clamp(enlarge ? i - 1 : i + 1, 0, opts.Count - 1);
            SheetLayout.SetDenominator(s, opts[n]);
        }
        else SheetLayout.SetFactor(s, s.Factor * (enlarge ? 1.15 : 1 / 1.15));
        RenderCurrent();
        RefreshScaleBox();
    }

    // poignée d'étirement : tirer le coin bas-droit du dessin ; l'échelle normalisée la plus proche est appliquée (dans la limite de la zone libre)
    private bool _dragHandle; private Point _hCenter; private double _hR0, _hF0;

    private bool OverHandle(Point screen)
    {
        var s = Current();
        if (SheetLayout.ContentBox(s) is not { } box) return false;
        var pp = ToPaper(screen);
        double tol = Math.Max(2.2, 8.0 / (_mt.Matrix.M11 * BaseK));
        return Math.Abs(pp.X - box.X1) <= tol && Math.Abs(pp.Y - box.Y0) <= tol;
    }

    private bool TryBeginHandle(Point screen)
    {
        if (!OverHandle(screen)) return false;
        var s = Current();
        var box = SheetLayout.ContentBox(s)!.Value;
        _hCenter = new Point((box.X0 + box.X1) / 2, (box.Y0 + box.Y1) / 2);
        var pp = ToPaper(screen);
        _hR0 = Math.Max(1, Math.Sqrt(Math.Pow(pp.X - _hCenter.X, 2) + Math.Pow(pp.Y - _hCenter.Y, 2)));
        _hF0 = s.Factor;
        _dragHandle = true;
        _scroll.CaptureMouse();
        return true;
    }

    private void DragHandle(Point screen)
    {
        var s = Current();
        var pp = ToPaper(screen);
        double r = Math.Sqrt(Math.Pow(pp.X - _hCenter.X, 2) + Math.Pow(pp.Y - _hCenter.Y, 2));
        double desired = Math.Max(0.05, _hF0 * r / _hR0);
        if (s.BaseDen > 0)
        {
            var opts = SheetLayout.Options(s);
            if (opts.Count == 0) return;
            double den = s.BaseDen / desired;
            double best = opts[0];
            foreach (var o in opts) if (Math.Abs(Math.Log(o / den)) < Math.Abs(Math.Log(best / den))) best = o;
            SheetLayout.SetDenominator(s, best);
        }
        else SheetLayout.SetFactor(s, desired);
        RenderCurrent();
    }

    private bool EndHandle()
    {
        if (!_dragHandle) return false;
        _dragHandle = false;
        _scroll.ReleaseMouseCapture();
        RefreshScaleBox();
        return true;
    }

    private static Button Btn(string text, RoutedEventHandler h)
    {
        var b = new Button { Content = text, Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(0, 0, 6, 0) };
        b.Click += h;
        return b;
    }

    private Sheet Current() => _sheets[Math.Max(0, _list.SelectedIndex)];

    private void EndPan() { if (!_pan) return; _pan = false; _scroll.ReleaseMouseCapture(); _scroll.Cursor = null; }

    private Point Center() => new(_scroll.ActualWidth / 2, _scroll.ActualHeight / 2);

    /// <summary>Zoom libre : le point de la planche situé sous le curseur reste sous le curseur.</summary>
    private void ZoomAt(double factor, Point p)
    {
        var m = _mt.Matrix;
        double ns = m.M11 * factor;
        if (ns < 0.02 || ns > 80) return;
        m.M11 = ns; m.M22 = ns;
        m.OffsetX = p.X - (p.X - _mt.Matrix.OffsetX) * factor;
        m.OffsetY = p.Y - (p.Y - _mt.Matrix.OffsetY) * factor;
        _mt.Matrix = m;
    }

    private void Fit()
    {
        var s = Current();
        RenderCurrent();
        double vw = _scroll.ActualWidth > 50 ? _scroll.ActualWidth : 1100, vh = _scroll.ActualHeight > 50 ? _scroll.ActualHeight : 760;
        double w = s.Width * BaseK, h = s.Height * BaseK;
        double k = Math.Min((vw - 30) / w, (vh - 30) / h);
        _mt.Matrix = new Matrix(k, 0, 0, k, (vw - w * k) / 2, (vh - h * k) / 2);
    }

    private void Zoom100()
    {
        var s = Current();
        double vw = _scroll.ActualWidth, vh = _scroll.ActualHeight;
        double k = 96.0 / 25.4 / BaseK;                      // 1 mm de papier = 1 mm à l'écran (96 ppp)
        _mt.Matrix = new Matrix(k, 0, 0, k, (vw - s.Width * BaseK * k) / 2, (vh - s.Height * BaseK * k) / 2);
    }

    private void RenderCurrent()
    {
        var s = Current();
        _host.SetVisual(SheetRenderer.Render(s, BaseK, true, true), s.Width * BaseK, s.Height * BaseK);
    }

    private static string FileName(Sheet s) =>
        $"{s.Number}_{string.Concat(s.Title.Where(char.IsLetterOrDigit).Take(24))}.dxf";

    private void ExportOne()
    {
        var s = Current();
        var dlg = new SaveFileDialog { Filter = "AutoCAD DXF (*.dxf)|*.dxf", FileName = FileName(s) };
        if (dlg.ShowDialog() != true) return;
        DxfWriter.Save(s, dlg.FileName);
        MessageBox.Show("Planche exportée :\n" + dlg.FileName, "StructCalc", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void ExportAll()
    {
        var dlg = new OpenFolderDialog { Title = "Dossier d'export des planches DXF" };
        if (dlg.ShowDialog() != true) return;
        foreach (var s in _sheets) DxfWriter.Save(s, System.IO.Path.Combine(dlg.FolderName, FileName(s)));
        MessageBox.Show($"{_sheets.Count} planche(s) exportée(s) dans :\n{dlg.FolderName}\n\nRevit : Insérer > Importer CAO (ou Lier CAO), choisir le DXF.", "StructCalc", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private static string? FindOda()
    {
        foreach (var root in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) })
        {
            string oda = System.IO.Path.Combine(root, "ODA");
            if (!Directory.Exists(oda)) continue;
            foreach (var d in Directory.GetDirectories(oda, "ODAFileConverter*"))
            {
                string exe = System.IO.Path.Combine(d, "ODAFileConverter.exe");
                if (File.Exists(exe)) return exe;
            }
        }
        return null;
    }

    private void ConvertDwg()
    {
        string? exe = FindOda();
        if (exe == null)
        {
            MessageBox.Show("Le format DWG est propriétaire : StructCalc passe par l'outil gratuit « ODA File Converter » (Open Design Alliance), qui n'est pas installé sur ce poste.\n\n" +
                            "Deux solutions :\n1) installez ODA File Converter puis relancez cette commande ;\n2) exportez en DXF et, dans AutoCAD / BricsCAD, faites « Enregistrer sous » au format DWG voulu.",
                            "Conversion DWG", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var dlg = new OpenFolderDialog { Title = "Dossier de sortie des fichiers DWG" };
        if (dlg.ShowDialog() != true) return;
        string tmp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "StructCalc_dxf_" + Guid.NewGuid().ToString("N")[..8]);
        Directory.CreateDirectory(tmp);
        try
        {
            foreach (var s in _sheets) DxfWriter.Save(s, System.IO.Path.Combine(tmp, FileName(s)));
            var psi = new ProcessStartInfo(exe, $"\"{tmp}\" \"{dlg.FolderName}\" \"{_ver.SelectedItem}\" \"DWG\" \"0\" \"1\"") { UseShellExecute = false, CreateNoWindow = true };
            using var p = Process.Start(psi);
            p?.WaitForExit(180000);
            int n = Directory.GetFiles(dlg.FolderName, "*.dwg").Length;
            MessageBox.Show($"{n} fichier(s) DWG ({_ver.SelectedItem}) dans :\n{dlg.FolderName}", "Conversion DWG", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show("Erreur de conversion : " + ex.Message, "Conversion DWG", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { try { Directory.Delete(tmp, true); } catch { } }
    }

    private void PrintSheets(IEnumerable<Sheet> list)
    {
        var pd = new PrintDialog();
        try { pd.PrintTicket.PageOrientation = PageOrientation.Landscape; } catch { }
        if (pd.ShowDialog() != true) return;
        foreach (var s in list)
        {
            double k = Math.Min(pd.PrintableAreaWidth / s.Width, pd.PrintableAreaHeight / s.Height);
            pd.PrintVisual(SheetRenderer.Render(s, k, false), $"{AppInfo.Name} - {_project} - {s.Title}");
        }
    }
}
