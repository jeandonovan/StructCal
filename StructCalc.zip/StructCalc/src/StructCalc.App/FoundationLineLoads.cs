using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core.Loads;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Résultat de la saisie d'une charge linéaire de la bibliothèque (mur, cloison, façade...) sur une fondation.</summary>
public sealed record FoundationLine(string Text, double G, double Q, double X1, double Y1, double X2, double Y2);

/// <summary>Choix d'une charge dans la bibliothèque puis conversion en kN/m (G ou Q) pour une semelle filante ou un radier.</summary>
public static class FoundationLineLoads
{
    /// <summary>Ouvre la bibliothèque puis une fenêtre de précisions ; null si annulé. withGeometry : demande le segment en plan (radier).</summary>
    public static FoundationLine? Ask(Window owner, bool withGeometry)
    {
        var pick = LoadCatalogWindow.Pick(owner, 0);
        if (pick == null) return null;
        if (pick.Kind == "Point")
        {
            MessageBox.Show(owner, "Une force ponctuelle n'est pas une charge linéaire : choisissez un mur (kN/m) ou une charge surfacique (avec largeur d'influence).", "Charge de mur");
            return null;
        }
        var w = new Window { Title = "Charge sur la fondation", Owner = owner, WindowStartupLocation = WindowStartupLocation.CenterOwner, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize, MinWidth = 420 };
        var p = new StackPanel { Margin = new Thickness(16) };
        string unit = pick.Kind == "Linear" ? "kN/m" : "kN/m²";
        p.Children.Add(new TextBlock { Text = $"{pick.Text}\n= {pick.Value:0.###} {unit}", FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) });
        TextBox Field(string label, string val)
        {
            p.Children.Add(new TextBlock { Text = label });
            var t = new TextBox { Text = val, Margin = new Thickness(0, 2, 0, 6) };
            p.Children.Add(t); return t;
        }
        var cCase = new ComboBox { Margin = new Thickness(0, 2, 0, 6) };
        p.Children.Add(new TextBlock { Text = "Cas de charge :" });
        cCase.Items.Add("G - permanente (mur, revêtement)"); cCase.Items.Add("Q - exploitation");
        cCase.SelectedIndex = pick.Live ? 1 : 0; p.Children.Add(cCase);
        TextBox? tw = pick.Kind == "Surface" ? Field("Largeur d'influence portée par la fondation (m) :", "1") : null;
        TextBox? x1 = null, y1 = null, x2 = null, y2 = null;
        if (withGeometry)
        {
            p.Children.Add(new TextBlock { Text = "Position du mur en plan (m) :", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 4, 0, 2) });
            x1 = Field("Début X1 :", "0"); y1 = Field("Début Y1 :", "0"); x2 = Field("Fin X2 :", "5"); y2 = Field("Fin Y2 :", "0");
        }
        var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var ok = new Button { Content = "Ajouter", Width = 90, Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        ok.Click += (s, a) => w.DialogResult = true;
        row.Children.Add(ok); row.Children.Add(new Button { Content = "Annuler", Width = 90, IsCancel = true });
        p.Children.Add(row); w.Content = p;
        if (w.ShowDialog() != true) return null;

        static bool Num(TextBox? t, out double v) { v = 0; return t != null && double.TryParse(t.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v); }
        double infl = 1;
        if (tw != null && (!Num(tw, out infl) || infl <= 0)) { MessageBox.Show(owner, "Largeur d'influence invalide.", "Charge de mur"); return null; }
        double lin = pick.Kind == "Surface" ? pick.Value * infl : pick.Value;
        double a1 = 0, b1 = 0, a2 = 0, b2 = 0;
        if (withGeometry && !(Num(x1, out a1) && Num(y1, out b1) && Num(x2, out a2) && Num(y2, out b2)))
        { MessageBox.Show(owner, "Coordonnées invalides.", "Charge de mur"); return null; }
        bool live = cCase.SelectedIndex == 1;
        return new FoundationLine(pick.Text, live ? 0 : lin, live ? lin : 0, a1, b1, a2, b2);
    }
}
