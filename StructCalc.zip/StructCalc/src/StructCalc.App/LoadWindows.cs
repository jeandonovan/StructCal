using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

internal static class IdList
{
    /// <summary>« 1 2 5-9, 12 » -> {1,2,5,6,7,8,9,12}.</summary>
    public static List<int> Parse(string? text)
    {
        var res = new List<int>();
        foreach (var tok in (text ?? "").Split(new[] { ' ', ',', ';', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries))
        {
            var p = tok.Split('-');
            if (p.Length == 2 && int.TryParse(p[0], out int a) && int.TryParse(p[1], out int b) && b >= a && b - a < 5000) { for (int i = a; i <= b; i++) res.Add(i); }
            else if (int.TryParse(tok, out int v)) res.Add(v);
        }
        return res.Distinct().ToList();
    }
}

/// <summary>Assistant « Charges » façon Robot : choisissez le type de charge à gauche, saisissez les valeurs, choisissez les éléments chargés, puis « Appliquer ».
/// La fenêtre reste ouverte : vous pouvez changer la sélection dans la vue et appliquer d'autres charges.</summary>
public sealed class LoadAssistantWindow : Window
{
    private readonly Func<StructModel> _model;
    private readonly Func<List<int>> _selection;
    private readonly Func<Func<StructModel, string>, string> _apply;
    private readonly Action _manage;
    private readonly ListBox _types = new() { Width = 210 };
    private readonly Border _body = new() { Padding = new Thickness(14, 8, 14, 8) };
    private readonly ComboBox _case = new() { Width = 170 };
    private readonly ComboBox _target = new() { Width = 260 };
    private readonly ComboBox _level = new() { Width = 200 };
    private readonly TextBox _nodes = new() { Width = 200, Padding = new Thickness(3) };
    private readonly TextBlock _status = new() { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DarkGreen, Margin = new Thickness(0, 6, 0, 0) };
    private readonly TextBlock _selInfo = new() { Foreground = Brushes.Gray, Margin = new Thickness(10, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
    private readonly Dictionary<string, TextBox> _f = new();
    private readonly Dictionary<string, ComboBox> _c = new();
    private List<(string Label, double Z)> _levels = new();
    private int _kind = -1;

    private static readonly string[] Kinds =
    {
        "Charge nodale (force, moment)",
        "Charge répartie uniforme sur barre",
        "Charge linéaire / trapèze / partielle",
        "Force ponctuelle à une distance",
        "Moment ponctuel à une distance",
        "Température (ΔT, gradient)",
        "Charge surfacique (dalle)",
        "Effacer des charges",
    };

    public LoadAssistantWindow(Func<StructModel> model, Func<List<int>> selection, Func<Func<StructModel, string>, string> apply, Action manage)
    {
        _model = model; _selection = selection; _apply = apply; _manage = manage;
        Title = "Charges - assistant (comme Robot)";
        Width = 900; Height = 700; MinHeight = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        ShowInTaskbar = false;

        var root = new Grid { Margin = new Thickness(10) };
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        root.RowDefinitions.Add(new RowDefinition());
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        foreach (var k in Kinds) _types.Items.Add(k);
        _types.SelectionChanged += (s, e) => Build(_types.SelectedIndex);
        _types.Margin = new Thickness(0, 0, 8, 0);
        Grid.SetRow(_types, 0); root.Children.Add(_types);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _body };
        Grid.SetColumn(scroll, 1); root.Children.Add(scroll);

        foreach (var c in new[] { "G  permanente", "Q  exploitation", "W  vent", "S  neige" }) _case.Items.Add(c);
        _case.SelectedIndex = 1;
        _target.SelectionChanged += (s, e) => UpdateTargetUi();

        var bottom = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
        var bar = new StackPanel { Orientation = Orientation.Horizontal };
        bar.Children.Add(Ui.Btn("Appliquer", (s, e) => Apply(), true));
        bar.Children.Add(Ui.Btn("Gérer / supprimer les charges…", (s, e) => _manage()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_selInfo);
        bottom.Children.Add(bar);
        bottom.Children.Add(_status);
        Grid.SetRow(bottom, 1); Grid.SetColumnSpan(bottom, 2); root.Children.Add(bottom);
        Content = root;

        Activated += (s, e) => RefreshInfo();
        Loaded += (s, e) => { _types.SelectedIndex = 1; RefreshInfo(); };
    }

    // ------------------------------------------------------------------ utilitaires d'interface
    private void RefreshInfo()
    {
        int n = _selection().Count;
        _selInfo.Text = n == 0 ? "Aucune barre sélectionnée dans la vue." : $"{n} barre(s) sélectionnée(s) dans la vue.";
        var info = StructureAnalyzer.Analyze(_model());
        _levels = info.Levels.Select(l => (l.Name, l.Z)).ToList();
    }

    /// <summary>Bouton « Bibliothèque de charges » : le résultat du catalogue remplit les champs de la saisie.</summary>
    private void CatalogButton(StackPanel host, int tab, Action<CatalogPick> apply)
    {
        var b = Ui.Btn("Bibliothèque de charges (mur, planchers, toitures, usages...)", (s, e) =>
        {
            var r = LoadCatalogWindow.Pick(this, tab);
            if (r != null) apply(r);
        });
        b.Margin = new Thickness(0, 4, 0, 6); b.HorizontalAlignment = HorizontalAlignment.Left;
        host.Children.Add(b);
    }

    private void SetCase(bool live) { try { _case.SelectedIndex = live ? 1 : 0; } catch { } }

    private static TextBlock Title2(string t) => new() { Text = t, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 10, 0, 4), Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)) };
    private static TextBlock Hint(string t) => new() { Text = t, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 2, 0, 4) };

    private StackPanel Field(StackPanel host, string label, string key, string def, double labelWidth = 230)
    {
        var g = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        g.Children.Add(new TextBlock { Text = label, Width = labelWidth, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap });
        var t = new TextBox { Text = def, Width = 90, Padding = new Thickness(3) };
        g.Children.Add(t); _f[key] = t;
        host.Children.Add(g);
        return g;
    }

    private void Combo(StackPanel host, string label, string key, string[] items, int sel = 0, double labelWidth = 230)
    {
        var g = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        g.Children.Add(new TextBlock { Text = label, Width = labelWidth, VerticalAlignment = VerticalAlignment.Center });
        var c = new ComboBox { Width = 210 };
        foreach (var i in items) c.Items.Add(i);
        c.SelectedIndex = sel;
        g.Children.Add(c); _c[key] = c;
        host.Children.Add(g);
    }

    private void Row3(StackPanel host, string title, string[] keys, string[] labels, string[] defs)
    {
        host.Children.Add(Title2(title));
        var g = new Grid();
        for (int i = 0; i < keys.Length; i++) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        g.Width = 120 * keys.Length;
        g.HorizontalAlignment = HorizontalAlignment.Left;
        for (int i = 0; i < keys.Length; i++)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 8, 0) };
            sp.Children.Add(new TextBlock { Text = labels[i], FontSize = 11, Foreground = Brushes.Gray });
            var t = new TextBox { Text = defs[i], Padding = new Thickness(3) };
            sp.Children.Add(t); _f[keys[i]] = t;
            Grid.SetColumn(sp, i); g.Children.Add(sp);
        }
        host.Children.Add(g);
    }

    private string CaseText() => (_case.SelectedItem as string ?? "Q")[..1];
    private ActionType CaseOf() => Enum.TryParse<ActionType>(CaseText(), out var c) ? c : ActionType.Q;
    private double V(string key, double def = 0) => Ui.Num(_f.TryGetValue(key, out var t) ? t.Text : "", def);
    private int Sel(string key) => _c.TryGetValue(key, out var c) ? Math.Max(0, c.SelectedIndex) : 0;
    private LoadFrame FrameOf() => Sel("frame") == 1 ? LoadFrame.Local : LoadFrame.Global;

    private StackPanel TargetPanel(bool nodalMode)
    {
        var p = new StackPanel();
        p.Children.Add(Title2(nodalMode ? "Nœuds chargés" : "Barres chargées"));
        _target.Items.Clear();
        if (nodalMode)
        {
            _target.Items.Add("Nœuds des barres sélectionnées dans la vue");
            _target.Items.Add("Nœuds listés ci-dessous");
            _target.Items.Add("Tous les nœuds libres d'un niveau (hors appuis)");
        }
        else
        {
            _target.Items.Add("Barres sélectionnées dans la vue");
            _target.Items.Add("Toutes les poutres");
            _target.Items.Add("Tous les poteaux");
            _target.Items.Add("Toutes les barres");
            _target.Items.Add("Barres d'un niveau (poutres du plancher)");
        }
        _target.SelectedIndex = 0;
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(_target);
        p.Children.Add(row);
        var row2 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
        _level.Items.Clear();
        foreach (var l in _levels) _level.Items.Add($"{l.Label}  (Z = {l.Z:0.###} m)");
        if (_level.Items.Count > 0) _level.SelectedIndex = Math.Min(1, _level.Items.Count - 1);
        row2.Children.Add(new TextBlock { Text = "Niveau :", Width = 60, VerticalAlignment = VerticalAlignment.Center });
        row2.Children.Add(_level);
        if (nodalMode) { row2.Children.Add(new TextBlock { Text = "  Nœuds :", VerticalAlignment = VerticalAlignment.Center }); row2.Children.Add(_nodes); }
        p.Children.Add(row2);
        UpdateTargetUi();
        return p;
    }

    private bool _nodal;
    private void UpdateTargetUi()
    {
        int t = _target.SelectedIndex;
        _level.IsEnabled = _nodal ? t == 2 : t == 4;
        _nodes.IsEnabled = _nodal && t == 1;
    }

    private StackPanel CasePanel()
    {
        var p = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 4) };
        p.Children.Add(new TextBlock { Text = "Cas de charge :", Width = 110, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold });
        p.Children.Add(_case);
        return p;
    }

    private static string[] Frames => new[] { "Axes globaux (Z vers le haut)", "Axes locaux de la barre" };

    // ------------------------------------------------------------------ construction du formulaire
    private void Build(int kind)
    {
        if (kind < 0) return;
        _kind = kind; RefreshInfo();
        _f.Clear(); _c.Clear();
        // les listes / zones de saisie sont réutilisées d'un type de charge à l'autre : il faut les détacher de l'ancien formulaire,
        // sinon WPF lève « l'élément est déjà enfant d'un autre » et l'application se ferme au 2e clic
        _body.Child = null;
        foreach (FrameworkElement fe in new FrameworkElement[] { _case, _target, _level, _nodes }) Detach(fe);
        var p = new StackPanel();
        _nodal = kind == 0;
        p.Children.Add(new TextBlock { Text = Kinds[kind], FontSize = 16, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)) });
        string axes = "Axes globaux : X, Y horizontaux, Z vertical vers le haut. Une charge de gravité a donc une composante Z NÉGATIVE (ex. Wz = -10 kN/m).";
        switch (kind)
        {
            case 0:
                p.Children.Add(Hint("Force (kN) et moment (kN.m) appliqués au nœud. " + axes));
                p.Children.Add(CasePanel());
                CatalogButton(p, 2, r => { if (r.Kind == "Point") { SetCase(r.Live); _f["fz"].Text = Ui.Fmt(-r.Value); } else MessageBox.Show(this, "Cette valeur n'est pas une force (kN) : choisissez Qk (exploitation) ou un matériau par volume.", Title); });
                Row3(p, "Forces (kN)", new[] { "fx", "fy", "fz" }, new[] { "Fx", "Fy", "Fz" }, new[] { "0", "0", "-10" });
                Row3(p, "Moments (kN.m)", new[] { "mx", "my", "mz" }, new[] { "Mx", "My", "Mz" }, new[] { "0", "0", "0" });
                p.Children.Add(TargetPanel(true));
                break;
            case 1:
                p.Children.Add(Hint("Charge uniforme sur toute la longueur de la barre (kN par mètre de barre). " + axes));
                p.Children.Add(CasePanel());
                CatalogButton(p, 0, r => { if (r.Kind == "Linear") { SetCase(r.Live); _f["wx"].Text = "0"; _f["wy"].Text = "0"; _f["wz"].Text = Ui.Fmt(-r.Value); } else MessageBox.Show(this, "Cette valeur n'est pas une charge linéaire (kN/m) : choisissez un mur ou un matériau en section b × h.", Title); });
                Combo(p, "Repère", "frame", Frames);
                Row3(p, "Intensité (kN/m)", new[] { "wx", "wy", "wz" }, new[] { "Wx", "Wy", "Wz" }, new[] { "0", "0", "-10" });
                p.Children.Add(Hint("Vent sur un poteau : Wx (ou Wy) positif, Wz = 0. Charge perpendiculaire à une barre inclinée : repère « local », Wz local."));
                p.Children.Add(TargetPanel(false));
                break;
            case 2:
                p.Children.Add(Hint("Charge qui varie linéairement entre deux abscisses : trapèze, triangle (une intensité nulle), ou charge uniforme sur une partie de la barre. " + axes));
                p.Children.Add(CasePanel());
                Combo(p, "Repère", "frame", Frames);
                Combo(p, "Distances mesurées depuis", "from", new[] { "le nœud i (début de barre)", "le nœud j (fin de barre)" });
                Combo(p, "Unité des distances", "unit", new[] { "mètres", "% de la longueur" });
                Field(p, "Début a", "a", "0");
                Field(p, "Fin b", "b", "100");
                p.Children.Add(Hint("En %, 0 à 100. Exemple : triangle sur toute la barre, a = 0, b = 100 %, intensité nulle en a et maximale en b."));
                Row3(p, "Intensité en a (kN/m)", new[] { "x1", "y1", "z1" }, new[] { "Wx", "Wy", "Wz" }, new[] { "0", "0", "0" });
                Row3(p, "Intensité en b (kN/m)", new[] { "x2", "y2", "z2" }, new[] { "Wx", "Wy", "Wz" }, new[] { "0", "0", "-10" });
                p.Children.Add(TargetPanel(false));
                break;
            case 3:
            case 4:
                bool force = kind == 3;
                p.Children.Add(Hint((force ? "Force concentrée" : "Moment concentré") + " appliqué(e) à une distance choisie du nœud i ou j, sur une poutre comme sur un poteau. " + axes));
                p.Children.Add(CasePanel());
                Combo(p, "Repère", "frame", Frames);
                Combo(p, "Distance mesurée depuis", "from", new[] { "le nœud i (début de barre)", "le nœud j (fin de barre)" });
                Combo(p, "Unité", "unit", new[] { "mètres", "% de la longueur" });
                var dg = Field(p, "Distance", "d", "50");
                _c["unit"].SelectedIndex = 1;
                var mid = new Button { Content = "Milieu", Padding = new Thickness(8, 2, 8, 2), Margin = new Thickness(8, 0, 0, 0) };
                mid.Click += (s, e) => { _c["unit"].SelectedIndex = 1; _f["d"].Text = "50"; };
                dg.Children.Add(mid);
                if (force) Row3(p, "Force (kN)", new[] { "px", "py", "pz" }, new[] { "Fx", "Fy", "Fz" }, new[] { "0", "0", "-20" });
                else Row3(p, "Moment (kN.m)", new[] { "qx", "qy", "qz" }, new[] { "Mx (torsion)", "My", "Mz" }, new[] { "0", "20", "0" });
                p.Children.Add(TargetPanel(false));
                break;
            case 5:
                p.Children.Add(Hint("Variation uniforme de température (dilatation axiale, effort normal si la barre est bridée) et gradient thermique sur la hauteur de la section (flexion). " +
                                    "Gradient > 0 : face supérieure plus chaude que la face inférieure. Coefficients de dilatation : béton 1,0.10⁻⁵ ; acier 1,2.10⁻⁵ par °C."));
                p.Children.Add(CasePanel());
                Field(p, "Variation uniforme ΔT (°C)", "dt", "20");
                Field(p, "Gradient T haut - T bas (°C)", "dg", "0");
                p.Children.Add(TargetPanel(false));
                break;
            case 6:
                p.Children.Add(Hint("Charge surfacique en kN/m², positive vers le bas, sur un panneau horizontal rectangulaire délimité par des poutres. " +
                                    "StructCalc la répartit sur les poutres du contour : lignes de rupture à 45° (dalle portant dans les 2 sens) ou portée dans un sens."));
                p.Children.Add(CasePanel());
                CatalogButton(p, 1, r => { if (r.Kind == "Surface") { SetCase(r.Live); _f["q"].Text = Ui.Fmt(r.Value); } else MessageBox.Show(this, "Cette valeur n'est pas une charge surfacique (kN/m²) : utilisez l'onglet Couches ou Exploitation.", Title); });
                Field(p, "Charge q (kN/m², vers le bas)", "q", "5");
                Combo(p, "Répartition", "dist", new[] { "Dalle portant dans les 2 sens (45°)", "Portée dans le sens X (poutres parallèles à Y)", "Portée dans le sens Y (poutres parallèles à X)" });
                p.Children.Add(Title2("Panneaux chargés"));
                Combo(p, "Définition", "mode", new[] { "Détecter tous les panneaux fermés par des poutres", "Panneau défini par ses nœuds d'angle", "Panneau défini par coordonnées" });
                var lv = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
                _level.Items.Clear();
                _level.Items.Add("Tous les niveaux");
                foreach (var l in _levels) _level.Items.Add($"{l.Label}  (Z = {l.Z:0.###} m)");
                _level.SelectedIndex = 0;
                lv.Children.Add(new TextBlock { Text = "Niveau (détection) :", Width = 130, VerticalAlignment = VerticalAlignment.Center });
                lv.Children.Add(_level);
                p.Children.Add(lv);
                var nd = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
                nd.Children.Add(new TextBlock { Text = "Nœuds d'angle :", Width = 130, VerticalAlignment = VerticalAlignment.Center });
                nd.Children.Add(_nodes);
                p.Children.Add(nd);
                Row3(p, "Coordonnées du panneau (m)", new[] { "x0", "y0", "x1", "y1", "zz" }, new[] { "X min", "Y min", "X max", "Y max", "Z" }, new[] { "0", "0", "4", "5", "3" });
                p.Children.Add(Hint("Astuce : « Détecter » charge d'un coup tous les planchers du modèle ; la charge suit le panneau quand vous déplacez ou dupliquez un étage. " +
                                    "Les panneaux déjà chargés pour ce cas ne sont pas rechargés une 2e fois."));
                _nodal = false;
                break;
            case 7:
                p.Children.Add(Hint("Supprime les charges des barres choisies pour un cas donné. L'option « tout le modèle » supprime aussi les charges nodales et surfaciques."));
                p.Children.Add(CasePanel());
                _case.Items.Clear();
                foreach (var c in new[] { "G  permanente", "Q  exploitation", "W  vent", "S  neige", "*  tous les cas" }) _case.Items.Add(c);
                _case.SelectedIndex = 4;
                var all = new CheckBox { Content = "Tout le modèle (barres, nœuds et panneaux)", Margin = new Thickness(0, 8, 0, 0) };
                _chkAll = all;
                p.Children.Add(all);
                p.Children.Add(TargetPanel(false));
                break;
        }
        if (kind != 7 && _case.Items.Count != 4)
        {
            _case.Items.Clear();
            foreach (var c in new[] { "G  permanente", "Q  exploitation", "W  vent", "S  neige" }) _case.Items.Add(c);
            _case.SelectedIndex = 1;
        }
        _body.Child = p;
        _status.Text = "";
    }

    private static void Detach(FrameworkElement fe)
    {
        switch (fe.Parent)
        {
            case Panel pn: pn.Children.Remove(fe); break;
            case Decorator d: d.Child = null; break;
            case ContentControl cc: cc.Content = null; break;
        }
    }

    private CheckBox? _chkAll;

    // ------------------------------------------------------------------ cibles
    private List<int> MemberTargets(StructModel m)
    {
        int t = _target.SelectedIndex;
        var target = t switch { 1 => LoadTarget.AllBeams, 2 => LoadTarget.AllColumns, 3 => LoadTarget.AllMembers, 4 => LoadTarget.Level, _ => LoadTarget.Selection };
        double z = 0;
        if (target == LoadTarget.Level)
        {
            int li = _level.SelectedIndex;
            if (li < 0 || li >= _levels.Count) return new List<int>();
            z = _levels[li].Z;
        }
        return LoadBuilder.ResolveMembers(m, target, _selection(), z);
    }

    private List<int> NodeTargets(StructModel m)
    {
        switch (_target.SelectedIndex)
        {
            case 0: return SelectionTools.NodesOf(m, _selection());
            case 1: return IdList.Parse(_nodes.Text);
            default:
            {
                int li = _level.SelectedIndex;
                if (li < 0 || li >= _levels.Count) return new List<int>();
                double z = _levels[li].Z;
                var supp = new HashSet<int>(m.Supports.Select(s => s.NodeId));
                return m.Nodes.Where(n => Math.Abs(n.Z - z) < 0.05 && !supp.Contains(n.Id)).Select(n => n.Id).ToList();
            }
        }
    }

    // ------------------------------------------------------------------ application
    private void Apply()
    {
        RefreshInfo();
        var cas = CaseOf();
        string caseText = CaseText();
        Func<StructModel, string>? action = null;
        switch (_kind)
        {
            case 0:
            {
                double fx = V("fx"), fy = V("fy"), fz = V("fz"), mx = V("mx"), my = V("my"), mz = V("mz");
                action = m =>
                {
                    var ids = NodeTargets(m);
                    if (ids.Count == 0) return "Aucun nœud à charger : sélectionnez des barres dans la vue, ou listez des nœuds.";
                    if (Math.Abs(fx) + Math.Abs(fy) + Math.Abs(fz) + Math.Abs(mx) + Math.Abs(my) + Math.Abs(mz) < 1e-12) return "Aucune charge : toutes les valeurs sont nulles.";
                    int n = LoadBuilder.AddNodal(m, ids, cas, fx, fy, fz, mx, my, mz);
                    return $"Charge nodale (cas {caseText}) appliquée à {n} nœud(s).";
                };
                break;
            }
            case 1:
            {
                double wx = V("wx"), wy = V("wy"), wz = V("wz"); var fr = FrameOf();
                action = m =>
                {
                    var ids = MemberTargets(m);
                    if (ids.Count == 0) return "Aucune barre à charger : sélectionnez des barres dans la vue ou choisissez un autre groupe.";
                    if (Math.Abs(wx) + Math.Abs(wy) + Math.Abs(wz) < 1e-12) return "Aucune charge : toutes les valeurs sont nulles.";
                    int n = LoadBuilder.AddUniform(m, ids, cas, fr, wx, wy, wz);
                    return $"Charge répartie (cas {caseText}) appliquée à {n} barre(s).";
                };
                break;
            }
            case 2:
            {
                bool pct = Sel("unit") == 1, fromJ = Sel("from") == 1; var fr = FrameOf();
                double a = V("a"), b = V("b");
                var w1 = new[] { V("x1"), V("y1"), V("z1") }; var w2 = new[] { V("x2"), V("y2"), V("z2") };
                action = m =>
                {
                    var ids = MemberTargets(m);
                    if (ids.Count == 0) return "Aucune barre à charger : sélectionnez des barres dans la vue ou choisissez un autre groupe.";
                    if (pct && (a < 0 || b > 100 || a >= b)) return "Distances en % : il faut 0 ≤ a < b ≤ 100.";
                    if (!pct && (a < 0 || a >= b)) return "Distances : il faut 0 ≤ a < b.";
                    if (!pct)
                    {
                        foreach (int id in ids)
                        {
                            var mem = m.Members.First(x => x.Id == id);
                            var na = m.Nodes.First(x => x.Id == mem.NodeI); var nb = m.Nodes.First(x => x.Id == mem.NodeJ);
                            double L = Math.Sqrt(Math.Pow(na.X - nb.X, 2) + Math.Pow(na.Y - nb.Y, 2) + Math.Pow(na.Z - nb.Z, 2));
                            if (b > L + 1e-6) return $"La barre {id} ne mesure que {L:0.###} m : la fin b = {b:0.###} m dépasse. Utilisez des % pour des barres de longueurs différentes.";
                        }
                    }
                    int n = LoadBuilder.AddTrapezoid(m, ids, cas, fr, pct ? a / 100 : a, pct ? b / 100 : b, pct, fromJ, w1, w2);
                    return $"Charge linéaire (cas {caseText}) appliquée à {n} barre(s).";
                };
                break;
            }
            case 3:
            case 4:
            {
                bool pct = Sel("unit") == 1, fromJ = Sel("from") == 1; var fr = FrameOf(); double d = V("d");
                bool force = _kind == 3;
                double ax = force ? V("px") : V("qx"), ay = force ? V("py") : V("qy"), az = force ? V("pz") : V("qz");
                action = m =>
                {
                    var ids = MemberTargets(m);
                    if (ids.Count == 0) return "Aucune barre à charger : sélectionnez des barres dans la vue ou choisissez un autre groupe.";
                    if (Math.Abs(ax) + Math.Abs(ay) + Math.Abs(az) < 1e-12) return "Aucune charge : toutes les valeurs sont nulles.";
                    if (pct && (d < 0 || d > 100)) return "Distance en % : entre 0 et 100.";
                    if (!pct)
                    {
                        foreach (int id in ids)
                        {
                            var mem = m.Members.First(x => x.Id == id);
                            var na = m.Nodes.First(x => x.Id == mem.NodeI); var nb = m.Nodes.First(x => x.Id == mem.NodeJ);
                            double L = Math.Sqrt(Math.Pow(na.X - nb.X, 2) + Math.Pow(na.Y - nb.Y, 2) + Math.Pow(na.Z - nb.Z, 2));
                            if (d < 0 || d > L + 1e-6) return $"La barre {id} ne mesure que {L:0.###} m : la distance {d:0.###} m est hors de la barre.";
                        }
                    }
                    double dd = pct ? d / 100 : d;
                    int n = force ? LoadBuilder.AddPointForce(m, ids, cas, fr, dd, pct, fromJ, ax, ay, az)
                                  : LoadBuilder.AddPointMoment(m, ids, cas, fr, dd, pct, fromJ, ax, ay, az);
                    return $"{(force ? "Force" : "Moment")} ponctuel(le) (cas {caseText}) appliqué(e) à {n} barre(s).";
                };
                break;
            }
            case 5:
            {
                double dt = V("dt"), dg = V("dg");
                action = m =>
                {
                    var ids = MemberTargets(m);
                    if (ids.Count == 0) return "Aucune barre à charger : sélectionnez des barres dans la vue ou choisissez un autre groupe.";
                    if (Math.Abs(dt) + Math.Abs(dg) < 1e-12) return "Aucune charge : ΔT et gradient sont nuls.";
                    int n = LoadBuilder.AddThermal(m, ids, cas, dt, dg);
                    return $"Température (cas {caseText}) appliquée à {n} barre(s).";
                };
                break;
            }
            case 6:
            {
                double q = V("q"); int mode = Sel("mode");
                var dist = Sel("dist") switch { 1 => SurfaceDistribution.OneWayX, 2 => SurfaceDistribution.OneWayY, _ => SurfaceDistribution.TwoWay };
                double x0 = V("x0"), y0 = V("y0"), x1 = V("x1"), y1 = V("y1"), zz = V("zz");
                int li = _level.SelectedIndex;
                var nodeIds = IdList.Parse(_nodes.Text);
                action = m =>
                {
                    if (Math.Abs(q) < 1e-12) return "Aucune charge : q est nul.";
                    if (mode == 0)
                    {
                        IEnumerable<double>? zs = li <= 0 ? null : new[] { _levels[li - 1].Z };
                        int n = LoadBuilder.AddSurfaceAuto(m, cas, q, dist, zs);
                        if (n == 0) return "Aucun panneau nouveau trouvé : il faut des poutres sur les 4 côtés d'un rectangle horizontal (axes X et Y). Vérifiez aussi que le panneau n'est pas déjà chargé pour ce cas.";
                        return $"Charge surfacique {q:0.##} kN/m² (cas {caseText}) appliquée à {n} panneau(x).";
                    }
                    if (mode == 1)
                    {
                        var s = LoadBuilder.AddSurfaceFromNodes(m, nodeIds, cas, q, dist, out string msg);
                        return s == null ? msg : $"Charge surfacique {q:0.##} kN/m² (cas {caseText}) appliquée au panneau {s.X1 - s.X0:0.##} x {s.Y1 - s.Y0:0.##} m.";
                    }
                    if (x1 - x0 < 0.1 || y1 - y0 < 0.1) return "Panneau dégénéré : vérifiez les coordonnées.";
                    LoadBuilder.AddSurface(m, cas, q, dist, zz, x0, y0, x1, y1);
                    return $"Charge surfacique {q:0.##} kN/m² (cas {caseText}) appliquée au panneau défini.";
                };
                break;
            }
            case 7:
            {
                bool allModel = _chkAll?.IsChecked == true;
                ActionType? cs = CaseText() == "*" ? null : cas;
                action = m =>
                {
                    int n = allModel ? LoadBuilder.Clear(m, null, cs) : LoadBuilder.Clear(m, MemberTargets(m), cs);
                    return n == 0 ? "Aucune charge à supprimer." : $"{n} charge(s) supprimée(s).";
                };
                break;
            }
        }
        if (action == null) return;
        string res = _apply(action);
        _status.Foreground = res.StartsWith("Aucun") || res.StartsWith("La barre") || res.Contains("hors") || res.StartsWith("Distance") || res.StartsWith("Panneau") || res.StartsWith("Les ") || res.StartsWith("Erreur") || res.StartsWith("Choisissez")
            ? Brushes.Firebrick : Brushes.DarkGreen;
        _status.Text = res;
        RefreshInfo();
    }
}

/// <summary>Liste de toutes les charges du modèle (nodales, sur barre, surfaciques) : sélection, suppression.</summary>
public sealed class LoadManagerWindow : Window
{
    private sealed class Row
    {
        public string Type { get; set; } = "";
        public string Cas { get; set; } = "";
        public string Cible { get; set; } = "";
        public string Description { get; set; } = "";
        public object Ref { get; set; } = null!;
        public int MemberId { get; set; } = -1;
    }

    private readonly Func<StructModel> _model;
    private readonly Func<Func<StructModel, string>, string> _apply;
    private readonly Action<int> _select;
    private readonly DataGrid _grid = new() { AutoGenerateColumns = false, IsReadOnly = true, SelectionMode = DataGridSelectionMode.Extended, HeadersVisibility = DataGridHeadersVisibility.Column };
    private readonly ComboBox _filter = new() { Width = 150 };
    private readonly TextBlock _info = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Gray };

    public LoadManagerWindow(Func<StructModel> model, Func<Func<StructModel, string>, string> apply, Action<int> select)
    {
        _model = model; _apply = apply; _select = select;
        Title = "Toutes les charges du modèle";
        Width = 960; Height = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var dock = new DockPanel { Margin = new Thickness(10) };
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
        bar.Children.Add(new TextBlock { Text = "Cas :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
        foreach (var c in new[] { "Tous", "G", "Q", "W", "S" }) _filter.Items.Add(c);
        _filter.SelectedIndex = 0;
        _filter.SelectionChanged += (s, e) => Fill();
        bar.Children.Add(_filter);
        bar.Children.Add(new Border { Width = 12 });
        bar.Children.Add(Ui.Btn("Actualiser", (s, e) => Fill()));
        bar.Children.Add(Ui.Btn("Supprimer la sélection", (s, e) => DeleteSelected()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_info);
        DockPanel.SetDock(bar, Dock.Top); dock.Children.Add(bar);

        _grid.Columns.Add(new DataGridTextColumn { Header = "Type", Binding = new System.Windows.Data.Binding("Type"), Width = 130 });
        _grid.Columns.Add(new DataGridTextColumn { Header = "Cas", Binding = new System.Windows.Data.Binding("Cas"), Width = 50 });
        _grid.Columns.Add(new DataGridTextColumn { Header = "Cible", Binding = new System.Windows.Data.Binding("Cible"), Width = 150 });
        _grid.Columns.Add(new DataGridTextColumn { Header = "Description", Binding = new System.Windows.Data.Binding("Description"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        _grid.SelectionChanged += (s, e) =>
        {
            if (_grid.SelectedItem is Row r && r.MemberId >= 0) _select(r.MemberId);
        };
        dock.Children.Add(_grid);
        Content = dock;
        Activated += (s, e) => Fill();
        Loaded += (s, e) => Fill();
    }

    private void Fill()
    {
        var m = _model();
        string f = _filter.SelectedItem as string ?? "Tous";
        bool Ok(ActionType c) => f == "Tous" || c.ToString() == f;
        var rows = new List<Row>();
        foreach (var l in m.NodalLoads.Where(l => Ok(l.Case)))
            rows.Add(new Row { Type = "Nodale", Cas = l.Case.ToString(), Cible = "Nœud " + l.NodeId, Description = LoadDescriber.Describe(l), Ref = l });
        foreach (var l in m.MemberLoads.Where(l => Ok(l.Case)))
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == l.MemberId);
            string kind = l.Kind switch { MemberLoadKind.Uniform => "Répartie", MemberLoadKind.Trapezoid => "Linéaire", MemberLoadKind.Point => "Ponctuelle", MemberLoadKind.Moment => "Moment", _ => "Température" };
            rows.Add(new Row { Type = kind, Cas = l.Case.ToString(), Cible = (mem?.Type == MemberType.Column ? "Poteau " : "Barre ") + l.MemberId, Description = LoadDescriber.Describe(l), Ref = l, MemberId = l.MemberId });
        }
        foreach (var s in m.SurfaceLoads.Where(s => Ok(s.Case)))
            rows.Add(new Row { Type = "Surfacique", Cas = s.Case.ToString(), Cible = string.IsNullOrEmpty(s.Name) ? "Panneau" : s.Name, Description = LoadDescriber.Describe(s), Ref = s });
        _grid.ItemsSource = rows;
        _info.Text = $"{rows.Count} charge(s) affichée(s)";
    }

    private void DeleteSelected()
    {
        var refs = _grid.SelectedItems.Cast<Row>().Select(r => r.Ref).ToList();
        if (refs.Count == 0) return;
        _apply(m =>
        {
            int n = 0;
            foreach (var r in refs)
            {
                if (r is NodalLoad nl && m.NodalLoads.Remove(nl)) n++;
                else if (r is MemberLoad ml && m.MemberLoads.Remove(ml)) n++;
                else if (r is SurfaceLoad sl && m.SurfaceLoads.Remove(sl)) n++;
            }
            return n == 0 ? "Aucune charge supprimée." : $"{n} charge(s) supprimée(s).";
        });
        Fill();
    }
}
