using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Ligne de l'onglet Messages.</summary>
public sealed class MsgRow
{
    public string Id { get; set; } = "";
    public string Niveau { get; set; } = "";
    public int Gravite { get; set; }
    public string Source { get; set; } = "";
    public string Categorie { get; set; } = "";
    public string Element { get; set; } = "";
    public string Position { get; set; } = "";
    public string Message { get; set; } = "";
    public string Combinaison { get; set; } = "";
    public string Statut { get; set; } = "";
    public string Justification { get; set; } = "";
    public string Heure { get; set; } = "";
    public AppMessage Msg { get; set; } = new();
}

/// <summary>Onglet « Messages » : tous les messages du logiciel en une liste (modèle, calcul, dimensionnement, informations), triable et filtrable, avec un clic qui
/// sélectionne l'élément et un clic droit qui dépend de la famille : correction (modèle), diagnostic (calcul), solutions validées (dimensionnement), affichage seul.</summary>
public partial class MainWindow
{
    private readonly List<string> _journal = new();
    private List<ModelIssue>? _lastIssues;
    private List<AppMessage> _msgs = new();
    private readonly HashSet<string> _doneMsgs = new();
    private readonly Dictionary<string, string> _ignoreWhy = new();
    private readonly Dictionary<string, DateTime> _msgTimes = new();
    private readonly Dictionary<string, int> _msgIds = new();
    private bool _msgStale = true, _msgSync;
    private DateTime _msgFocusAt = DateTime.MinValue;

    private void InitMessages()
    {
        var menu = new ContextMenu();
        GridMsgs.ContextMenu = menu;
        GridMsgs.ToolTip = "Clic sur un message : sélectionne l'élément concerné  ·  Clic droit : correction, diagnostic ou solutions selon la famille du message";
        GridMsgs.ContextMenuOpening += (s, e) => { if (!BuildMsgMenu(menu)) e.Handled = true; };
        GridMsgs.PreviewMouseRightButtonDown += (s, e) =>
        {
            var row = IssueAncestor<DataGridRow>(e.OriginalSource as DependencyObject);
            if (row != null) { GridMsgs.SelectedItem = row.Item; row.IsSelected = true; }
        };
        GridMsgs.PreviewMouseLeftButtonUp += (s, e) =>
        {
            if ((DateTime.Now - _msgFocusAt).TotalMilliseconds < 400) return;
            var row = IssueAncestor<DataGridRow>(e.OriginalSource as DependencyObject);
            if (row?.Item is MsgRow r) FocusMessage(r.Msg);
        };
        // tableau RÉSULTATS : clic droit sur une barre = résultats détaillés, diagrammes, combinaison critique, solutions
        var rm = new ContextMenu();
        GridResults.ContextMenu = rm;
        GridResults.ContextMenuOpening += (s, e) =>
        {
            rm.Items.Clear();
            if (GridResults.SelectedItem is not ResultRow rr) { e.Handled = true; return; }
            BuildMemberAlertMenu(rm, rr.Barre);
        };
        GridResults.PreviewMouseRightButtonDown += (s, e) =>
        {
            var row = IssueAncestor<DataGridRow>(e.OriginalSource as DependencyObject);
            if (row != null) { GridResults.SelectedItem = row.Item; row.IsSelected = true; }
        };
        BottomTabs.SelectionChanged += (s, e) =>
        {
            if (ReferenceEquals(e.OriginalSource, BottomTabs) && ReferenceEquals(BottomTabs.SelectedItem, TabMsgs) && _msgStale) RebuildMessages();
        };
    }

    // ------------------------------------------------------------------ construction de la liste
    private void RebuildMessages()
    {
        if (GridMsgs == null) return;
        _msgStale = false;
        try
        {
            _lastIssues ??= ModelChecker.Check(_model);
            var advices = new List<string>();
            try { advices = SettingsAdvisor.Check(_model); } catch { }
            _msgs = MessageCenter.Build(_model, _out, _lastIssues, advices, _journal.Skip(Math.Max(0, _journal.Count - 300)).ToList());
        }
        catch { _msgs = new List<AppMessage>(); }
        _msgs.AddRange(_fileMsgs);
        ApplyMessageView();
    }

    private static bool KeepMessage(AppMessage am, string status, int filter) => filter switch
    {
        0 => am.Source != MsgSource.Journal && status != "Ignoré",   // Messages actifs (défaut) : jamais de lignes du journal
        1 => am.Source == MsgSource.Journal,
        2 => status != "Ignoré",                                      // Tous
        3 => am.Source == MsgSource.Modele && status != "Ignoré",
        4 => am.Source == MsgSource.Calcul && status != "Ignoré",
        5 => am.Source == MsgSource.Dimensionnement && status != "Ignoré",
        6 => am.Family == MsgFamily.Information && status != "Ignoré",
        7 => am.Blocking && status != "Ignoré",
        8 => am.Level == IssueLevel.Warning && status != "Ignoré",
        9 => status == "Traité",
        10 => status == "Ignoré",
        _ => true
    };

    private string StatusOf(AppMessage am) =>
        !am.Blocking && _ignoredIssues.Contains(am.Key) ? "Ignoré" : _doneMsgs.Contains(am.Key) ? "Traité" : "À traiter";

    private void ApplyMessageView()
    {
        if (GridMsgs == null || MsgFilter == null || MsgSearch == null) return;
        int filter = Math.Max(0, MsgFilter.SelectedIndex);
        string needle = (MsgSearch.Text ?? "").Trim();
        string? keep = (GridMsgs.SelectedItem as MsgRow)?.Msg.Key;
        var rows = new List<MsgRow>();
        int todo = 0;
        foreach (var am in _msgs)
        {
            if (!_msgTimes.TryGetValue(am.Key, out var stamp)) { stamp = am.Time; _msgTimes[am.Key] = stamp; }
            if (!_msgIds.TryGetValue(am.Key, out int num)) { num = _msgIds.Count + 1; _msgIds[am.Key] = num; }
            string st = StatusOf(am);
            if (st == "À traiter" && am.Level != IssueLevel.Info) todo++;
            if (!KeepMessage(am, st, filter)) continue;
            if (!MessageMatchesSelection(am)) continue;      // « Messages » de la barre de sélection : seulement ceux de la sélection
            if (needle.Length > 0 && !(am.Text + " " + am.ElementLabel + " " + am.Category + " " + am.SourceText + " " + am.Position + " " + am.LevelText).Contains(needle, StringComparison.OrdinalIgnoreCase)) continue;
            rows.Add(new MsgRow
            {
                Id = "M" + num.ToString("000"), Niveau = am.LevelText, Gravite = am.Blocking ? 4 : am.Level == IssueLevel.Error ? 3 : am.Level == IssueLevel.Warning ? 2 : 1,
                Source = am.SourceText, Categorie = am.Category, Element = am.ElementLabel, Position = am.Position, Message = am.Text, Combinaison = am.Combo,
                Statut = st, Justification = _ignoreWhy.TryGetValue(am.Key, out var why) ? why : "", Heure = stamp.ToString("dd/MM/yyyy HH:mm:ss"), Msg = am
            });
        }
        rows = rows.OrderByDescending(r => r.Gravite).ThenBy(r => r.Source).ThenBy(r => r.Element).ThenBy(r => r.Id).ToList();
        _msgSync = true;
        try
        {
            GridMsgs.ItemsSource = rows;
            if (keep != null) GridMsgs.SelectedItem = rows.FirstOrDefault(r => r.Msg.Key == keep);
        }
        finally { _msgSync = false; }
        TabMsgs.Header = todo > 0 ? $"Messages ({todo})" : "Messages";
        MsgCount.Text = $"{rows.Count} affiché(s) sur {_msgs.Count}  ·  {todo} à traiter" + (_msgKeyFilter != null ? $"  ·  filtrés sur la sélection ({_msgKeyFilter.Count} élément(s)) : Actualiser pour tout voir" : "");
    }

    private void MsgFilter_Changed(object sender, RoutedEventArgs e) { _msgKeyFilter = null; ApplyMessageView(); }
    private void MsgRefresh_Click(object sender, RoutedEventArgs e) { _msgKeyFilter = null; _lastIssues = null; RebuildMessages(); }
    private void MsgExport_Click(object sender, RoutedEventArgs e) => ExportMessages();
    private void MsgReshow_Click(object sender, RoutedEventArgs e) => ReshowIgnored();

    private void GridMsgs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_msgSync || GridMsgs.SelectedItem is not MsgRow r) return;
        _msgFocusAt = DateTime.Now;
        FocusMessage(r.Msg);
    }

    private void ReshowIgnored()
    {
        _ignoredIssues.Clear(); _ignoreWhy.Clear();
        SaveMessageStatuses();
        RunCheckNow();
    }

    /// <summary>Relit les statuts enregistrés dans le projet (ouverture, nouveau modèle, annulation).</summary>
    private void LoadMessageStatuses()
    {
        _doneMsgs.Clear(); _ignoredIssues.Clear(); _ignoreWhy.Clear();
        foreach (var r in _model.MessageStatuses ?? new List<MessageStatusRecord>())
        {
            if (string.IsNullOrEmpty(r.Key)) continue;
            if (r.Status == "Ignoré") { _ignoredIssues.Add(r.Key); if (r.Reason != "") _ignoreWhy[r.Key] = r.Reason; }
            else if (r.Status == "Traité") _doneMsgs.Add(r.Key);
            _msgTimes.TryAdd(r.Key, r.Date);
        }
    }

    /// <summary>Écrit les statuts dans le projet : date, utilisateur et justification conservés d'un enregistrement à l'autre.</summary>
    private void SaveMessageStatuses()
    {
        var old = (_model.MessageStatuses ?? new List<MessageStatusRecord>()).GroupBy(r => r.Key).ToDictionary(g => g.Key, g => g.First());
        var list = new List<MessageStatusRecord>();
        foreach (var k in _ignoredIssues.Concat(_doneMsgs.Where(d => !_ignoredIssues.Contains(d))).Distinct())
        {
            string st = _ignoredIssues.Contains(k) ? "Ignoré" : "Traité";
            string why = _ignoreWhy.TryGetValue(k, out var w) ? w : "";
            if (old.TryGetValue(k, out var prev) && prev.Status == st && prev.Reason == why) { list.Add(prev); continue; }
            string text = _msgs.FirstOrDefault(q => q.Key == k)?.Text ?? prev?.Text ?? "";
            list.Add(new MessageStatusRecord { Key = k, Status = st, Reason = why, User = Environment.UserName, Date = DateTime.Now, Text = text });
        }
        _model.MessageStatuses = list;
        _dirty = true;
    }

    // ------------------------------------------------------------------ clic : sélectionner l'élément concerné
    private object? FindModule(string title)
    {
        string Rest(string pre) => title.Length > pre.Length ? title[pre.Length..].Trim() : "";
        if (title.StartsWith("Escalier ")) return _model.Stairs.FirstOrDefault(q => q.Name == Rest("Escalier "));
        if (title.StartsWith("Voile ")) return _model.Walls.FirstOrDefault(q => q.Name == Rest("Voile "));
        if (title.StartsWith("Radier ")) return _model.Rafts.FirstOrDefault(q => q.Name == Rest("Radier "));
        if (title.StartsWith("Plancher ")) return _model.RibbedFloors.FirstOrDefault(q => q.Name == Rest("Plancher "));
        if (title.StartsWith("Semelle ")) return _model.FootingDefs.FirstOrDefault(q => title.StartsWith("Semelle " + q.Name));
        return null;
    }

    private void FocusMessage(AppMessage am)
    {
        if (am.Subject is ModelIssue iss) { FocusIssue(iss); return; }
        var mem = new List<int>(); var nodes = new List<int>(); SlabPanel? slab = null; object? obj = null;
        if (am.MemberId is int mid && _model.Members.Any(q => q.Id == mid)) mem.Add(mid);
        if (am.Subject is int[] ns) nodes.AddRange(ns.Where(n => FindNode(n) != null));
        else if (am.NodeId is int nid && FindNode(nid) != null) nodes.Add(nid);
        switch (am.Subject)
        {
            case PunchingResult pr:
            {
                slab = _model.Slabs.FirstOrDefault(q => q.Name == pr.Slab);
                var pn = _model.Nodes.FirstOrDefault(n => Math.Abs(n.X - pr.X) < 0.01 && Math.Abs(n.Y - pr.Y) < 0.01 && Math.Abs(n.Z - pr.Z) < 0.05);
                if (pn != null) nodes.Add(pn.Id);
                break;
            }
            case DesignResult when am.ElementKind == "Dalle":
                slab = _model.Slabs.FirstOrDefault(q => am.ElementLabel == "Dalle " + q.Name);
                break;
            case ExtraDesign ex:
                obj = FindModule(ex.Title);
                break;
        }
        StructCalc.Engine.Selection.ElementKey? msgKey = null;
        if (am.ElementKind == "Semelle" && am.NodeId is int fnode && FindNode(fnode) != null) msgKey = StructCalc.Engine.Selection.ElementKey.FootingAt(fnode);
        else if (am.ElementKind == "Coque" && _model.Shells.FirstOrDefault(q => "Coque " + q.Name == am.ElementLabel) is ShellPanel shp) msgKey = ModelViewport.KeyOf(shp);
        else if (obj != null) msgKey = ModelViewport.KeyOf(obj);
        if (msgKey is StructCalc.Engine.Selection.ElementKey mk && slab == null && mem.Count == 0)
        {
            var tgt = _vp.ObjectsOf(mk).ToList();
            if (tgt.Any(_vp.IsObjHidden)) _vp.Unhide(Array.Empty<int>(), Array.Empty<int>(), tgt);
            _vp.SelectKeys(new[] { mk }, 'n'); _vp.ZoomSelection();
            StatusLeft.Text = "Élément concerné sélectionné : " + _vp.DescribeElement(mk);
            return;
        }
        if (mem.Any(q => _vp.HiddenMembers.Contains(q)) || nodes.Any(q => _vp.HiddenNodes.Contains(q)) || (slab != null && _vp.IsObjHidden(slab)))
            _vp.Unhide(mem, nodes, slab != null ? new object[] { slab } : Array.Empty<object>());
        if (slab != null) { _vp.SelectSlab(slab); _vp.ZoomSlab(slab); }
        else if (mem.Count > 0) { _vp.SetSelection(mem); _vp.ZoomSelection(); }
        else if (nodes.Count > 0) { _vp.SelectNodesOnly(nodes); _vp.ZoomNodes(nodes); }
        else if (am.Family == MsgFamily.Information) { StatusLeft.Text = "Message d'information : pas d'élément associé."; return; }
        else { _vp.ClearSelection(); }
        StatusLeft.Text = "Élément concerné sélectionné  -  clic droit sur le message : " + (am.Family switch
        {
            MsgFamily.Dimensionnement => "résultats détaillés et solutions de dimensionnement.",
            MsgFamily.Calcul => "diagnostic.",
            MsgFamily.Modele => "corrections proposées.",
            _ => "options."
        });
    }

    // ------------------------------------------------------------------ clic droit
    private bool BuildMsgMenu(ContextMenu cm)
    {
        cm.Items.Clear();
        if (GridMsgs.SelectedItem is not MsgRow row)
        {
            cm.Items.Add(Mi("Actualiser la liste", () => { _lastIssues = null; RebuildMessages(); }));
            cm.Items.Add(Mi("Exporter la liste affichée...", ExportMessages));
            if (_ignoredIssues.Count > 0) cm.Items.Add(Mi($"Réafficher les {_ignoredIssues.Count} message(s) ignoré(s)", ReshowIgnored));
            return true;
        }
        var am = row.Msg;
        switch (am.Family)
        {
            case MsgFamily.Modele:
                if (am.Subject is ModelIssue iss) AppendIssueItems(cm, iss, FilterIssues(_lastIssues ?? new List<ModelIssue>()), false);
                break;
            case MsgFamily.Dimensionnement:
                BuildDesignMsgMenu(cm, am);
                break;
            case MsgFamily.Calcul:
                BuildCalcMenu(cm, am);
                break;
            default:
                BuildInfoMenu(cm, am);
                break;
        }
        cm.Items.Add(new Separator());
        AppendStatusItems(cm, am);
        return true;
    }

    private void BuildDesignMsgMenu(ContextMenu cm, AppMessage am)
    {
        switch (am.Subject)
        {
            case MemberDesignResult r: BuildMemberAlertMenu(cm, r.MemberId); break;
            case DeflectionRow d: BuildMemberAlertMenu(cm, d.MemberId, true); break;
            case PunchingResult p: BuildPunchingMenu(cm, p); break;
            case ExtraDesign x: BuildModuleMenu(cm, am, x); break;
            case DriftRow: BuildCalcMenu(cm, am); break;
            case DesignResult when am.ElementKind == "Dalle":
                BuildSlabAlertMenu(cm, am.ElementLabel.StartsWith("Dalle ") ? am.ElementLabel[6..] : am.ElementLabel);
                break;
            case DesignResult fd: BuildFootingMenu(cm, am, fd); break;
            default: cm.Items.Add(Mi("Sélectionner l'élément concerné", () => FocusMessage(am))); break;
        }
    }

    private void BuildInfoMenu(ContextMenu cm, AppMessage am)
    {
        cm.Items.Add(MenuTitle(Trunc(am.Text, 95)));
        cm.Items.Add(MenuTitle("Information : affichage seul, aucune correction"));
        cm.Items.Add(new Separator());
        bool hasEl = am.MemberId != null || am.NodeId != null || am.Subject != null;
        cm.Items.Add(Mi("Ouvrir l'élément concerné", () => FocusMessage(am), hasEl));
    }

    private void AppendStatusItems(ContextMenu cm, AppMessage am)
    {
        bool done = _doneMsgs.Contains(am.Key), ignored = _ignoredIssues.Contains(am.Key);
        cm.Items.Add(Mi(done ? "Marquer comme « à traiter »" : "Marquer comme traité", () => { if (!_doneMsgs.Remove(am.Key)) _doneMsgs.Add(am.Key); SaveMessageStatuses(); ApplyMessageView(); }));
        if (am.Blocking) cm.Items.Add(Mi("Ignorer (impossible : une erreur bloquante empêche le calcul)", () => { }, false));
        else if (ignored) cm.Items.Add(Mi("Réafficher ce message", () => { _ignoredIssues.Remove(am.Key); _ignoreWhy.Remove(am.Key); SaveMessageStatuses(); if (am.Subject is ModelIssue) RunCheckNow(); else ApplyMessageView(); }));
        else
        {
            bool justify = am.Level != IssueLevel.Info && (am.Family == MsgFamily.Dimensionnement || am.Family == MsgFamily.Calcul);
            cm.Items.Add(Mi(justify ? "Ignorer volontairement (justification obligatoire)..." : "Ignorer volontairement (masquer)", () => IgnoreMessage(am)));
        }
        cm.Items.Add(Mi("Copier le message", () => { try { Clipboard.SetText(am.Text); } catch { } }));
        cm.Items.Add(Mi("Exporter la liste affichée (CSV)...", ExportMessages));
        if (_ignoredIssues.Count > 0) cm.Items.Add(Mi($"Réafficher les {_ignoredIssues.Count} message(s) ignoré(s)", ReshowIgnored));
    }

    /// <summary>Ignorer un message : les erreurs bloquantes ne s'ignorent pas ; une alerte de dimensionnement ou de calcul demande une justification écrite.</summary>
    private void IgnoreMessage(AppMessage am)
    {
        if (am.Blocking) { MessageBox.Show(this, "Une erreur bloquante empêche le calcul : elle ne peut pas être ignorée. Corrigez-la.", "Messages", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        bool justify = am.Level != IssueLevel.Info && (am.Family == MsgFamily.Dimensionnement || am.Family == MsgFamily.Calcul);
        if (justify)
        {
            var v = PromptWindow.Ask(this, "Ignorer temporairement l'alerte",
                Trunc(am.Text, 200) + "\n\nUne justification est obligatoire : elle est conservée dans l'export de la liste. L'élément reste non conforme dans le calcul ; seule l'alerte est masquée.",
                ("Justification", ""));
            if (v == null) return;
            if (string.IsNullOrWhiteSpace(v[0])) { MessageBox.Show(this, "Justification vide : l'alerte reste affichée.", "Messages", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            _ignoreWhy[am.Key] = v[0].Trim();
        }
        _ignoredIssues.Add(am.Key);
        SaveMessageStatuses();
        if (am.Subject is ModelIssue) RunCheckNow(); else RebuildMessages();
        Say("Message ignoré et enregistré dans le projet (date, utilisateur, justification). Onglet Messages, filtre « Messages ignorés » pour le retrouver."); 
    }

    // ------------------------------------------------------------------ calcul : menu de diagnostic
    private List<int> NodesOfMsg(AppMessage am)
    {
        var l = new List<int>();
        if (am.Subject is int[] ns) l.AddRange(ns);
        if (am.NodeId is int nid) l.Add(nid);
        if (am.MemberId is int mid)
        {
            var mem = _model.Members.FirstOrDefault(q => q.Id == mid);
            if (mem != null) { l.Add(mem.NodeI); l.Add(mem.NodeJ); }
        }
        return l.Where(id => FindNode(id) != null).Distinct().ToList();
    }

    private List<int> ConnectedMembers(IEnumerable<int> nodes)
    {
        var set = new HashSet<int>(nodes);
        return _model.Members.Where(q => set.Contains(q.NodeI) || set.Contains(q.NodeJ)).Select(q => q.Id).ToList();
    }

    private void BuildCalcMenu(ContextMenu cm, AppMessage am)
    {
        var nodes = NodesOfMsg(am);
        var conn = ConnectedMembers(nodes);
        bool res = _out != null;
        cm.Items.Add(MenuTitle(Trunc(am.Text, 95)));
        cm.Items.Add(MenuTitle("Diagnostic : comprendre le message, sans rien modifier"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Sélectionner l'élément concerné", () => FocusMessage(am)));
        cm.Items.Add(Mi("Afficher la déformée", () => ShowDeformedFor(am.Combo), res));
        cm.Items.Add(Mi("Afficher les déplacements des nœuds concernés...", () => MessageBox.Show(this, NodeResultsText(nodes, false), "Déplacements", MessageBoxButton.OK, MessageBoxImage.Information), res && nodes.Count > 0));
        cm.Items.Add(Mi("Afficher les rotations des nœuds concernés...", () => MessageBox.Show(this, NodeResultsText(nodes, true), "Rotations", MessageBoxButton.OK, MessageBoxImage.Information), res && nodes.Count > 0));
        cm.Items.Add(Mi("Afficher les appuis (les sélectionne tous dans la vue)", SelectAllSupports, _model.Supports.Count > 0));
        cm.Items.Add(Mi("Afficher les liaisons (appuis et barres reliées)...", () => MessageBox.Show(this, NodeReport(nodes, false), "Liaisons", MessageBoxButton.OK, MessageBoxImage.Information), nodes.Count > 0));
        cm.Items.Add(Mi("Afficher les charges", () => { ChkLoads.IsChecked = true; ViewOption_Changed(this, new RoutedEventArgs()); }));
        cm.Items.Add(Mi("Afficher les éléments connectés", () =>
        {
            if (conn.Count > 0) { _vp.SetSelection(conn); _vp.ZoomSelection(); } else { _vp.SelectNodesOnly(nodes); _vp.ZoomNodes(nodes); }
        }, nodes.Count > 0));
        cm.Items.Add(Mi("Isoler la partie concernée (masque tout le reste)", () => { FocusMessage(am); IsolateSelection(); }));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Vérifier les libérations aux nœuds...", () => MessageBox.Show(this, NodeReport(nodes, true), "Libérations et appuis", MessageBoxButton.OK, MessageBoxImage.Information), nodes.Count > 0));
        cm.Items.Add(Mi("Vérifier le maillage...", () => MessageBox.Show(this, MeshReport(), "Maillage", MessageBoxButton.OK, MessageBoxImage.Information)));
        cm.Items.Add(Mi("Vérifier les propriétés de l'élément", () =>
        {
            FocusMessage(am);
            if (am.MemberId is int mid) ShowMember(mid);
            else if (_vp.SelectedSlab is SlabPanel sl) SlabProps(sl);
        }));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Relancer le calcul après correction (F5)", () => Run_Click(this, new RoutedEventArgs()), true, "F5"));
    }

    private void SelectAllSupports()
    {
        var ids = _model.Supports.Select(s => s.NodeId).Where(id => FindNode(id) != null).Distinct().ToList();
        if (ids.Count == 0) return;
        _vp.SelectNodesOnly(ids); _vp.ZoomNodes(ids);
    }

    private string NodeResultsText(IEnumerable<int> nodes, bool rotations)
    {
        var g = _out?.Global;
        if (g == null) return "Résultats indisponibles : relancez le calcul.";
        var sb = new StringBuilder();
        foreach (int id in nodes.Take(8))
        {
            var n = FindNode(id);
            string where = n == null ? "" : $" ({F2(n.X)} ; {F2(n.Y)} ; {F2(n.Z)})";
            var d = g.Displacements.FirstOrDefault(q => q.NodeId == id);
            g.Deformed.TryGetValue(id, out var def);
            if (!rotations)
                sb.AppendLine(d == null ? $"Nœud {id}{where} : pas de déplacement calculé." : $"Nœud {id}{where} : Ux = {d.Ux:0.0}, Uy = {d.Uy:0.0}, Uz = {d.Uz:0.0} mm (total {d.Total:0.0} mm), combinaison {d.Combo}");
            else
                sb.AppendLine(def == null || def.Length < 6 ? $"Nœud {id}{where} : pas de rotation calculée." : $"Nœud {id}{where} : Rx = {def[3]:0.0000}, Ry = {def[4]:0.0000}, Rz = {def[5]:0.0000} rad (combinaison {g.DeformedCombo})");
        }
        return sb.Length == 0 ? "Aucun nœud concerné." : sb.ToString().TrimEnd();
    }

    private string NodeReport(IEnumerable<int> nodes, bool releases)
    {
        var sb = new StringBuilder();
        int blockedTotal = _model.Supports.Sum(s => (s.Ux ? 1 : 0) + (s.Uy ? 1 : 0) + (s.Uz ? 1 : 0) + (s.Rx ? 1 : 0) + (s.Ry ? 1 : 0) + (s.Rz ? 1 : 0));
        foreach (int id in nodes.Take(6))
        {
            var n = FindNode(id); if (n == null) continue;
            var conn = _model.Members.Where(q => q.NodeI == id || q.NodeJ == id).ToList();
            var sup = _model.Supports.FirstOrDefault(q => q.NodeId == id);
            sb.AppendLine($"Nœud {id} ({F2(n.X)} ; {F2(n.Y)} ; {F2(n.Z)})");
            sb.AppendLine($"  Barres reliées : {conn.Count}" + (conn.Count > 0 ? " (" + string.Join(", ", conn.Take(8).Select(q => (q.Type == MemberType.Column ? "poteau " : "poutre ") + q.Id)) + (conn.Count > 8 ? ", ..." : "") + ")" : ""));
            if (sup == null) sb.AppendLine("  Appui : aucun (nœud libre dans l'espace)");
            else
            {
                var blocked = new List<string>(); var free = new List<string>();
                void Dof(bool b, string name) { if (b) blocked.Add(name); else free.Add(name); }
                Dof(sup.Ux, "Ux"); Dof(sup.Uy, "Uy"); Dof(sup.Uz, "Uz"); Dof(sup.Rx, "Rx"); Dof(sup.Ry, "Ry"); Dof(sup.Rz, "Rz");
                sb.AppendLine("  Appui : bloqué " + (blocked.Count > 0 ? string.Join(" ", blocked) : "rien") + (free.Count > 0 ? " ; libre " + string.Join(" ", free) : " (encastrement)"));
            }
            if (!releases) continue;
            if (conn.Count == 0 && sup == null) sb.AppendLine("  À vérifier : nœud isolé, sans barre ni appui.");
            else if (conn.Count == 1 && sup == null) sb.AppendLine("  À vérifier : extrémité libre d'une seule barre (console voulue, ou nœud mal relié au reste ?).");
            else if (sup != null && (!sup.Rx || !sup.Ry || !sup.Rz)) sb.AppendLine("  Rotations libres à l'appui : normal pour une articulation, mais vérifiez que la structure reste stable.");
        }
        if (releases) sb.AppendLine($"\nAu total, les appuis du modèle bloquent {blockedTotal} degré(s) de liberté (6 au minimum en 3D, sinon la structure peut bouger comme un corps rigide).");
        return sb.Length == 0 ? "Aucun nœud concerné." : sb.ToString().TrimEnd();
    }

    private string MeshReport()
    {
        var cells = _model.Shells;
        var sb = new StringBuilder();
        if (cells.Count == 0) sb.AppendLine("Aucune coque (voile, dalle maillée) dans le modèle : rien à vérifier.");
        else
        {
            int missing = 0, bad = 0; double minE = double.MaxValue, maxE = 0, worst = 0; string worstName = "";
            foreach (var c in cells)
            {
                var p = new[] { FindNode(c.N1), FindNode(c.N2), FindNode(c.N3), FindNode(c.N4) };
                if (p.Any(q => q == null)) { missing++; continue; }
                double lo = double.MaxValue, hi = 0;
                for (int k = 0; k < 4; k++)
                {
                    var a = p[k]!; var b = p[(k + 1) % 4]!;
                    double e = Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
                    if (e < 1e-6) continue;
                    lo = Math.Min(lo, e); hi = Math.Max(hi, e);
                }
                if (hi <= 0 || lo == double.MaxValue) { bad++; continue; }
                minE = Math.Min(minE, lo); maxE = Math.Max(maxE, hi);
                if (hi / lo > worst) { worst = hi / lo; worstName = c.Name; }
            }
            sb.AppendLine($"{cells.Count} maille(s) de coque.");
            if (missing > 0) sb.AppendLine($"- {missing} maille(s) référencent un nœud inexistant (message « maille de coque » du vérificateur).");
            if (bad > 0) sb.AppendLine($"- {bad} maille(s) dégénérée(s) (côtés nuls).");
            if (maxE > 0) sb.AppendLine($"Côtés des mailles : de {minE:0.000} m à {maxE:0.000} m. Plus mauvais rapport d'aspect : {worst:0.0} (coque « {worstName} »)" + (worst > 4 ? " - mailles trop allongées, affinez ou régularisez le maillage." : " - correct."));
        }
        int overlaps = (_lastIssues ?? new List<ModelIssue>()).Count(i => i.Code == "NODE_OVERLAP");
        if (overlaps > 0) sb.AppendLine($"- {overlaps} paire(s) de nœuds superposés non reliés : un maillage raccordé doit partager ses nœuds (outil « Fusionner les nœuds »).");
        if (_out != null && _out.SlabFields.Count > 0) sb.AppendLine($"Dalles maillées calculées : {_out.SlabFields.Count}.");
        return sb.ToString().TrimEnd();
    }

    // ------------------------------------------------------------------ export
    private static string Csv(string s) => "\"" + (s ?? "").Replace("\"", "\"\"").Replace("\r", " ").Replace("\n", " ") + "\"";

    private void ExportMessages()
    {
        if (GridMsgs.ItemsSource is not List<MsgRow> rows || rows.Count == 0)
        {
            MessageBox.Show(this, "La liste affichée est vide : rien à exporter.", "Messages", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var dlg = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "Messages_StructCalc.csv" };
        if (dlg.ShowDialog() != true) return;
        var sb = new StringBuilder();
        sb.AppendLine("Id;Niveau;Source;Catégorie;Élément;Position;Message;Combinaison;Statut;Justification;Date et heure");
        foreach (var r in rows)
            sb.AppendLine(string.Join(";", new[] { r.Id, r.Niveau, r.Source, r.Categorie, r.Element, r.Position, r.Message, r.Combinaison, r.Statut, r.Justification, r.Heure }.Select(Csv)));
        File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
        Say($"Liste des messages exportée ({rows.Count} ligne(s)) : {dlg.FileName}");
    }
}
