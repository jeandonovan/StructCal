using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

/// <summary>Dalles dessinées sur le modèle : affichage (plan et 3D), aperçu élastique à la saisie, suppression.</summary>
public sealed partial class ModelViewport
{
    private (double U, double V)? _slabA;

    /// <summary>Mode « dans une trame » : un seul clic entre quatre axes (ou lignes de nœuds) dessine la dalle de cette trame.</summary>
    public bool SlabByBay { get; set; }

    /// <summary>Rectangle de trame autour du point (u, v) du plan de travail : axes de la grille et nœuds au niveau de travail.</summary>
    private bool BayAt(double u, double v, out double x0, out double x1, out double y0, out double y1)
    {
        x0 = x1 = y0 = y1 = 0;
        if (Model == null) return false;
        var info = GetInfo();
        var xs = info.XAxes.Select(a => a.Pos).Concat(Model.Nodes.Where(n => Math.Abs(n.Z - WorkOffset) < 1e-3).Select(n => n.X)).Distinct().OrderBy(q => q).ToList();
        var ys = info.YAxes.Select(a => a.Pos).Concat(Model.Nodes.Where(n => Math.Abs(n.Z - WorkOffset) < 1e-3).Select(n => n.Y)).Distinct().OrderBy(q => q).ToList();
        var xl = xs.Where(q => q <= u + 1e-9).DefaultIfEmpty(double.NaN).Last(); var xh = xs.FirstOrDefault(q => q > u + 1e-9, double.NaN);
        var yl = ys.Where(q => q <= v + 1e-9).DefaultIfEmpty(double.NaN).Last(); var yh = ys.FirstOrDefault(q => q > v + 1e-9, double.NaN);
        if (double.IsNaN(xl) || double.IsNaN(xh) || double.IsNaN(yl) || double.IsNaN(yh)) return false;
        x0 = xl; x1 = xh; y0 = yl; y1 = yh;
        return x1 - x0 >= 0.5 && y1 - y0 >= 0.5;
    }

    /// <summary>Dalle sélectionnée quand c'est la seule dalle de la sélection (clic dans la vue ou dans l'arborescence), null sinon.</summary>
    public SlabPanel? SelectedSlab => OnlyOne(ElementKind.Slab) is ElementKey k ? ObjectOf(k) as SlabPanel : null;
    /// <summary>Déclenché quand la dalle sélectionnée change (null = désélection).</summary>
    public event Action<SlabPanel?>? SlabSelected;

    public void SelectSlab(SlabPanel? s, bool notify = true)
    {
        // remplace la sélection par cette dalle (null = tout désélectionner)
        SelectKeys(s == null ? Array.Empty<ElementKey>() : new[] { ElementKey.Named(ElementKind.Slab, s.Name) }, 'n', notify);
    }

    /// <summary>Zoom sur une dalle.</summary>
    public void ZoomSlab(SlabPanel s)
    {
        var pts = new List<StructCalc.Engine.Geometry.Vec3>();
        foreach (double x in new[] { s.X0, s.X0 + s.Lx }) foreach (double y in new[] { s.Y0, s.Y0 + s.Ly }) foreach (double z in new[] { s.Z - 0.5, s.Z + 0.5 })
            pts.Add(new StructCalc.Engine.Geometry.Vec3(x, y, z));
        var (mn, mx) = BoundsOf(pts);
        _pivot = new StructCalc.Engine.Geometry.Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, 70);
    }

    /// <summary>Une dalle vient d'être dessinée : x0, y0, x1, y1 (m) et cote du dessus z (m).</summary>
    public event Action<double, double, double, double, double>? SlabDrawn;

    private void DrawPlacedSlabs()
    {
        if (Model == null) return;
        var slabC = ElementPalette.Get("Slab");
        var fill = new SolidColorBrush(ElementPalette.WithAlpha(slabC, 70)); fill.Freeze();
        var edge = Theme.Fixed(ElementPalette.Shade(slabC, 0.35));
        var side = new SolidColorBrush(ElementPalette.WithAlpha(ElementPalette.Shade(slabC, 0.45), 90)); side.Freeze();
        if (!Attr.Slabs) return;
        foreach (var s in Model.Slabs)
        {
            if (!s.Placed || IsObjHidden(s)) continue;
            var skey = ElementKey.Named(ElementKind.Slab, s.Name);
            var pts = new PointCollection
            {
                S(s.X0, s.Y0, s.Z), S(s.X0 + s.Lx, s.Y0, s.Z), S(s.X0 + s.Lx, s.Y0 + s.Ly, s.Z), S(s.X0, s.Y0 + s.Ly, s.Z)
            };
            if (Mode != ViewMode.Plan && s.H > 0.01 && Attr.SlabThickness)
            {
                // épaisseur de la dalle : dessous et quatre rives
                double zb = s.Z - s.H;
                var bot = new[] { S(s.X0, s.Y0, zb), S(s.X0 + s.Lx, s.Y0, zb), S(s.X0 + s.Lx, s.Y0 + s.Ly, zb), S(s.X0, s.Y0 + s.Ly, zb) };
                var top = new[] { pts[0], pts[1], pts[2], pts[3] };
                _c.Children.Add(new Polygon { Points = new PointCollection(bot), Fill = side, Stroke = edge, StrokeThickness = 0.8, IsHitTestVisible = false });
                for (int k = 0; k < 4; k++)
                {
                    int k2 = (k + 1) % 4;
                    _c.Children.Add(new Polygon { Points = new PointCollection { top[k], top[k2], bot[k2], bot[k] }, Fill = side, Stroke = edge, StrokeThickness = 0.8, IsHitTestVisible = false });
                }
                AddFaceHit(skey, new[] { new Vec3(s.X0, s.Y0, zb), new Vec3(s.X0 + s.Lx, s.Y0, zb), new Vec3(s.X0 + s.Lx, s.Y0 + s.Ly, zb), new Vec3(s.X0, s.Y0 + s.Ly, zb) });
                double xa = s.X0, xb = s.X0 + s.Lx, ya = s.Y0, yb = s.Y0 + s.Ly;
                AddFaceHit(skey, new[] { new Vec3(xa, ya, s.Z), new Vec3(xb, ya, s.Z), new Vec3(xb, ya, zb), new Vec3(xa, ya, zb) });
                AddFaceHit(skey, new[] { new Vec3(xb, ya, s.Z), new Vec3(xb, yb, s.Z), new Vec3(xb, yb, zb), new Vec3(xb, ya, zb) });
                AddFaceHit(skey, new[] { new Vec3(xb, yb, s.Z), new Vec3(xa, yb, s.Z), new Vec3(xa, yb, zb), new Vec3(xb, yb, zb) });
                AddFaceHit(skey, new[] { new Vec3(xa, yb, s.Z), new Vec3(xa, ya, s.Z), new Vec3(xa, ya, zb), new Vec3(xa, yb, zb) });
            }
            _c.Children.Add(new Polygon { Points = pts, Fill = fill, Stroke = edge, StrokeThickness = 1.4, IsHitTestVisible = false });
            AddFaceHit(skey, new[] { new Vec3(s.X0, s.Y0, s.Z), new Vec3(s.X0 + s.Lx, s.Y0, s.Z), new Vec3(s.X0 + s.Lx, s.Y0 + s.Ly, s.Z), new Vec3(s.X0, s.Y0 + s.Ly, s.Z) });
            var c = S(s.X0 + s.Lx / 2, s.Y0 + s.Ly / 2, s.Z);
            DrawSlabSymbols(s);
            if (Attr.SlabNames) Text($"{s.Name}  h={s.H * 100:0} cm", c.X - 32, c.Y - 7, 11, edge, null, true);
        }
    }

    private void DrawSlabRubber()
    {
        if (Tool != EditTool.Slab || !_cursorValid || Mode != ViewMode.Plan) return;
        if (SlabByBay)
        {
            if (!ToWorld(_cursor, out double wx, out double wy, out double wz)) return;
            var (cu, cv) = PlaneOf(wx, wy, wz);
            if (!BayAt(cu, cv, out double bx0, out double bx1, out double by0, out double by1)) return;
            var q1 = S(bx0, by0, WorkOffset); var q2 = S(bx1, by0, WorkOffset); var q3 = S(bx1, by1, WorkOffset); var q4 = S(bx0, by1, WorkOffset);
            var bf = new SolidColorBrush(Color.FromArgb(50, 0xE6, 0x51, 0x00)); bf.Freeze();
            _c.Children.Add(new Polygon { Points = new PointCollection { q1, q2, q3, q4 }, Fill = bf, Stroke = Br("#E65100"), StrokeThickness = 1.5, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false });
            Text($"{bx1 - bx0:0.00} x {by1 - by0:0.00} m", (q1.X + q3.X) / 2 - 28, (q1.Y + q3.Y) / 2 - 7, 11, Br("#E65100"), null, true);
            return;
        }
        if (_slabA == null) return;
        var hit = ComputeSnap(_cursor);
        if (hit == null) return;
        var a = _slabA.Value;
        var p1 = S(a.U, a.V, WorkOffset); var p2 = S(hit.U, a.V, WorkOffset); var p3 = S(hit.U, hit.V, WorkOffset); var p4 = S(a.U, hit.V, WorkOffset);
        var fill = new SolidColorBrush(Color.FromArgb(50, 0xE6, 0x51, 0x00)); fill.Freeze();
        _c.Children.Add(new Polygon { Points = new PointCollection { p1, p2, p3, p4 }, Fill = fill, Stroke = Br("#E65100"), StrokeThickness = 1.5, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false });
        Text($"{Math.Abs(hit.U - a.U):0.00} x {Math.Abs(hit.V - a.V):0.00} m", (p1.X + p3.X) / 2 - 28, (p1.Y + p3.Y) / 2 - 7, 11, Br("#E65100"), null, true);
    }

    private SlabPanel? SlabAt(Point p)
    {
        if (Model == null) return null;
        if (Mode == ViewMode.Plan && ToWorld(p, out double x, out double y, out double z))
            return Model.Slabs.FirstOrDefault(s => s.Placed && !IsObjHidden(s) && Math.Abs(s.Z - z) < 1e-3 && x >= s.X0 && x <= s.X0 + s.Lx && y >= s.Y0 && y <= s.Y0 + s.Ly);
        // 3D / élévation : test du point dans le quadrilatère projeté (la dalle la plus haute l'emporte)
        SlabPanel? best = null;
        foreach (var s in Model.Slabs)
        {
            if (!s.Placed || IsObjHidden(s)) continue;
            var q = new[] { S(s.X0, s.Y0, s.Z), S(s.X0 + s.Lx, s.Y0, s.Z), S(s.X0 + s.Lx, s.Y0 + s.Ly, s.Z), S(s.X0, s.Y0 + s.Ly, s.Z) };
            bool inside = false;
            for (int i = 0, j = 3; i < 4; j = i++)
                if ((q[i].Y > p.Y) != (q[j].Y > p.Y) && p.X < (q[j].X - q[i].X) * (p.Y - q[i].Y) / (q[j].Y - q[i].Y) + q[i].X) inside = !inside;
            if (inside && (best == null || s.Z > best.Z)) best = s;
        }
        return best;
    }

    private void DeleteSlab(SlabPanel s)
    {
        if (Model == null) return;
        StructCalc.Engine.Structure.StoreyOps.RemoveSlabLoads(Model, s.Name);
        Model.Slabs.Remove(s);
        _selKeys.Remove(ElementKey.Named(ElementKind.Slab, s.Name));
    }
}
