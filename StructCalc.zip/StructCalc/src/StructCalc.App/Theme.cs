using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;

namespace StructCalc.UI;

/// <summary>
/// Thème clair / sombre. Les couleurs posées dans le code ou le XAML (Background, Foreground, Stroke...) sont
/// converties automatiquement (inversion de luminosité) lorsque le mode sombre est actif ; les valeurs d'origine
/// sont mémorisées pour revenir au mode clair sans redémarrer.
/// </summary>
public static class Theme
{
    public static bool Dark { get; private set; }
    public static event Action? Changed;

    private enum Kind { Back, Fore, Stroke, Fill }

    private sealed class Entry { public Brush? Orig; public bool Local; public Brush Mapped = null!; }
    private static readonly ConditionalWeakTable<DependencyObject, Dictionary<DependencyProperty, Entry>> Tab = new();
    private static readonly ConditionalWeakTable<Brush, object> Own = new();
    private static readonly Dictionary<(Color, Kind), SolidColorBrush> Cache = new();
    private static readonly object Tag = new();
    private static bool _hooked;

    private static string FilePath => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "theme.txt");

    public static void Init()
    {
        bool dark = true;      // sombre par défaut ; le choix enregistré de l'utilisateur prime
        try { if (File.Exists(FilePath)) dark = File.ReadAllText(FilePath).Trim() == "dark"; } catch { }
        if (!_hooked)
        {
            _hooked = true;
            EventManager.RegisterClassHandler(typeof(FrameworkElement), FrameworkElement.LoadedEvent, new RoutedEventHandler(OnLoaded));
        }
        Set(dark, false);
    }

    public static void Set(bool dark, bool save = true)
    {
        Dark = dark;
        SetResources();
        if (Application.Current != null)
        {
            foreach (Window w in Application.Current.Windows) Refresh(w);
        }
        if (save)
        {
            try
            {
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(FilePath)!);
                File.WriteAllText(FilePath, dark ? "dark" : "light");
            }
            catch { }
        }
        Changed?.Invoke();
    }

    // ------------------------------------------------------------------ ressources
    /// <summary>Brosse « fixe » : n'est pas convertie par l'inversion du mode sombre (couleur choisie par l'utilisateur).</summary>
    public static Brush Fixed(Color c)
    {
        var b = new SolidColorBrush(c);
        b.Freeze();
        Own.AddOrUpdate(b, Tag);
        return b;
    }

    private static SolidColorBrush Mk(string hex)
    {
        var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)!);
        b.Freeze();
        Own.AddOrUpdate(b, Tag);
        return b;
    }

    private static void SetResources()
    {
        var r = Application.Current?.Resources;
        if (r == null) return;
        if (Dark)
        {
            r["ThemeFg"] = Mk("#E6E9EE"); r["ThemeBg"] = Mk("#202226"); r["ThemeButton"] = Mk("#2D3036");
            r["ThemeHover"] = Mk("#3A4150"); r["ThemeBorder"] = Mk("#444A55"); r["ThemeMenuBg"] = Mk("#25272C");
            r["PanelBg"] = Mk("#17181B"); r["LineBrush"] = Mk("#444A55");
            r[SystemColors.WindowBrushKey] = Mk("#202226"); r[SystemColors.WindowTextBrushKey] = Mk("#E6E9EE");
            r[SystemColors.ControlBrushKey] = Mk("#2A2D33"); r[SystemColors.ControlTextBrushKey] = Mk("#E6E9EE");
            r[SystemColors.ControlLightBrushKey] = Mk("#33363D"); r[SystemColors.ControlLightLightBrushKey] = Mk("#3A3E46");
            r[SystemColors.ControlDarkBrushKey] = Mk("#555B66"); r[SystemColors.ControlDarkDarkBrushKey] = Mk("#6B7280");
            r[SystemColors.MenuBrushKey] = Mk("#25272C"); r[SystemColors.MenuTextBrushKey] = Mk("#E6E9EE");
            r[SystemColors.MenuBarBrushKey] = Mk("#25272C"); r[SystemColors.GrayTextBrushKey] = Mk("#8A919C");
            r[SystemColors.InfoBrushKey] = Mk("#2A2D33"); r[SystemColors.InfoTextBrushKey] = Mk("#E6E9EE");
            r[SystemColors.HighlightBrushKey] = Mk("#2B6CB0"); r[SystemColors.HighlightTextBrushKey] = Mk("#FFFFFF");
            r[SystemColors.InactiveSelectionHighlightBrushKey] = Mk("#3A4A5E");
            r[SystemColors.InactiveSelectionHighlightTextBrushKey] = Mk("#E6E9EE");
        }
        else
        {
            r["ThemeFg"] = Mk("#1F2937"); r["ThemeBg"] = Mk("#FFFFFF"); r["ThemeButton"] = Mk("#F3F5F8");
            r["ThemeHover"] = Mk("#DCE9F5"); r["ThemeBorder"] = Mk("#C9D1DB"); r["ThemeMenuBg"] = Mk("#FFFFFF");
            r["PanelBg"] = Mk("#EEF1F5"); r["LineBrush"] = Mk("#C9D1DB");
            foreach (var k in new object[]
            {
                SystemColors.WindowBrushKey, SystemColors.WindowTextBrushKey, SystemColors.ControlBrushKey, SystemColors.ControlTextBrushKey,
                SystemColors.ControlLightBrushKey, SystemColors.ControlLightLightBrushKey, SystemColors.ControlDarkBrushKey,
                SystemColors.ControlDarkDarkBrushKey, SystemColors.MenuBrushKey, SystemColors.MenuTextBrushKey, SystemColors.MenuBarBrushKey,
                SystemColors.GrayTextBrushKey, SystemColors.InfoBrushKey, SystemColors.InfoTextBrushKey, SystemColors.HighlightBrushKey,
                SystemColors.HighlightTextBrushKey, SystemColors.InactiveSelectionHighlightBrushKey, SystemColors.InactiveSelectionHighlightTextBrushKey,
            })
                r.Remove(k);
        }
    }

    // ------------------------------------------------------------------ couleurs
    private static void ToHsl(Color c, out double h, out double s, out double l)
    {
        double r = c.R / 255.0, g = c.G / 255.0, b = c.B / 255.0;
        double mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b));
        l = (mx + mn) / 2; h = 0; s = 0;
        double d = mx - mn;
        if (d < 1e-9) return;
        s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
        if (mx == r) h = (g - b) / d + (g < b ? 6 : 0);
        else if (mx == g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h /= 6;
    }
    private static double Hue2Rgb(double p, double q, double t)
    {
        if (t < 0) t += 1; if (t > 1) t -= 1;
        if (t < 1.0 / 6) return p + (q - p) * 6 * t;
        if (t < 0.5) return q;
        if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
        return p;
    }
    private static Color FromHsl(double h, double s, double l, byte a)
    {
        double r, g, b;
        if (s < 1e-9) r = g = b = l;
        else
        {
            double q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
            r = Hue2Rgb(p, q, h + 1.0 / 3); g = Hue2Rgb(p, q, h); b = Hue2Rgb(p, q, h - 1.0 / 3);
        }
        return Color.FromArgb(a, (byte)Math.Round(r * 255), (byte)Math.Round(g * 255), (byte)Math.Round(b * 255));
    }

    private static Color MapColor(Color c, Kind k)
    {
        ToHsl(c, out double h, out double s, out double l);
        switch (k)
        {
            case Kind.Back:
                if (l > 0.5) return FromHsl(h, s > 0.25 ? s * 0.6 : s, 0.11 + (1 - l) * 0.6, c.A);
                return c;
            case Kind.Fill:
                if (s < 0.25) return FromHsl(h, s, Math.Clamp(0.11 + (1 - l) * 0.82, 0.11, 0.93), c.A);
                if (l > 0.8) return FromHsl(h, s * 0.6, 0.11 + (1 - l) * 0.6, c.A);
                return c;
            case Kind.Fore:
                if (l > 0.85) return c;                       // blanc sur fond coloré : inchangé
                if (s < 0.25) return FromHsl(h, s, Math.Clamp(0.11 + (1 - l) * 0.82, 0.5, 0.93), c.A);
                if (l < 0.45) return FromHsl(h, s, Math.Clamp(1 - l, 0.6, 0.8), c.A);
                return c;
            default: // Stroke
                if (s < 0.25) return FromHsl(h, s, Math.Clamp(0.11 + (1 - l) * 0.82, 0.11, 0.93), c.A);
                if (l < 0.4) return FromHsl(h, s, Math.Clamp(1 - l, 0.6, 0.8), c.A);
                return c;
        }
    }

    private static Brush? MapBrush(Brush b, Kind k)
    {
        if (b is not SolidColorBrush sb || sb.Color.A < 20) return null;
        if (Own.TryGetValue(b, out _)) return null;
        var key = (sb.Color, k);
        if (!Cache.TryGetValue(key, out var nb))
        {
            nb = new SolidColorBrush(MapColor(sb.Color, k));
            nb.Freeze();
            Own.AddOrUpdate(nb, Tag);
            Cache[key] = nb;
        }
        return nb.Color == sb.Color ? null : nb;
    }

    // ------------------------------------------------------------------ éléments
    private static void OnLoaded(object sender, RoutedEventArgs e)
    {
        if (Dark && sender is FrameworkElement fe) MapElement(fe);
    }

    private static void One(DependencyObject d, DependencyProperty p, Kind k)
    {
        var cur = d.GetValue(p) as Brush;
        if (cur == null) return;
        var bvs = DependencyPropertyHelper.GetValueSource(d, p).BaseValueSource;
        if (bvs != BaseValueSource.Local && bvs != BaseValueSource.Style && bvs != BaseValueSource.ImplicitStyleReference) return;
        var dict = Tab.GetOrCreateValue(d);
        if (dict.TryGetValue(p, out var en) && ReferenceEquals(cur, en.Mapped)) return;
        var nb = MapBrush(cur, k);
        if (nb == null) return;
        dict[p] = new Entry { Orig = cur, Local = bvs == BaseValueSource.Local, Mapped = nb };
        d.SetValue(p, nb);
    }

    public static void MapElement(FrameworkElement fe)
    {
        if (!Dark) return;
        if (fe.TemplatedParent is Control) return;
        if (fe is Window w)
        {
            var dict = Tab.GetOrCreateValue(w);
            if (!dict.ContainsKey(Control.ForegroundProperty))
            {
                var fg = (Brush)Application.Current!.Resources["ThemeFg"];
                dict[Control.ForegroundProperty] = new Entry { Orig = null, Local = false, Mapped = fg };
                w.SetValue(Control.ForegroundProperty, fg);
            }
            One(w, Control.BackgroundProperty, Kind.Back);
            return;
        }
        One(fe, TextElement.ForegroundProperty, Kind.Fore);
        switch (fe)
        {
            case Control c:
                One(c, Control.BackgroundProperty, Kind.Back);
                One(c, Control.ForegroundProperty, Kind.Fore);
                One(c, Control.BorderBrushProperty, Kind.Back);
                if (c is DataGrid dg)
                {
                    One(dg, DataGrid.RowBackgroundProperty, Kind.Back);
                    One(dg, DataGrid.AlternatingRowBackgroundProperty, Kind.Back);
                    One(dg, DataGrid.HorizontalGridLinesBrushProperty, Kind.Back);
                    One(dg, DataGrid.VerticalGridLinesBrushProperty, Kind.Back);
                }
                break;
            case Panel p:
                One(p, Panel.BackgroundProperty, Kind.Back);
                break;
            case Border b:
                One(b, Border.BackgroundProperty, Kind.Back);
                One(b, Border.BorderBrushProperty, Kind.Back);
                break;
            case TextBlock t:
                One(t, TextBlock.ForegroundProperty, Kind.Fore);
                One(t, TextBlock.BackgroundProperty, Kind.Back);
                break;
            case Shape s:
                One(s, Shape.StrokeProperty, Kind.Stroke);
                One(s, Shape.FillProperty, Kind.Fill);
                break;
        }
    }

    /// <summary>Convertit tout de suite un sous-arbre (à appeler après un tracé pour éviter un éclair clair).</summary>
    public static void MapTree(DependencyObject root)
    {
        if (!Dark) return;
        Walk(root, 0);
    }

    private static void Walk(DependencyObject d, int depth)
    {
        if (depth > 60) return;
        if (d is FrameworkElement fe) MapElement(fe);
        int n = 0;
        try { n = VisualTreeHelper.GetChildrenCount(d); } catch { }
        if (n > 0)
        {
            for (int i = 0; i < n; i++) Walk(VisualTreeHelper.GetChild(d, i), depth + 1);
        }
        else if (d is FrameworkElement or FrameworkContentElement)
        {
            foreach (var ch in LogicalTreeHelper.GetChildren(d))
                if (ch is DependencyObject dc) Walk(dc, depth + 1);
        }
    }

    private static void Refresh(Window w)
    {
        if (Dark) { Walk(w, 0); return; }
        // retour au clair : restaure toutes les valeurs mémorisées
        foreach (var kv in Tab)
        {
            var d = kv.Key;
            foreach (var pe in kv.Value)
            {
                try
                {
                    if (pe.Value.Orig != null && pe.Value.Local) d.SetValue(pe.Key, pe.Value.Orig);
                    else d.ClearValue(pe.Key);
                }
                catch { }
            }
            kv.Value.Clear();
        }
        w.InvalidateVisual();
    }
}
