using System.Windows;
using System.Windows.Controls;

namespace StructCalc.UI;

/// <summary>Menu « Cotation » : options d'affichage des cotes, unités, décimales, taille du texte, cote manuelle.</summary>
public partial class MainWindow
{
    private bool _dimInit;

    private MenuItem DimCheck(string header, bool on, Action<bool> set, string? tip = null)
    {
        var mi = new MenuItem { Header = header, IsCheckable = true, IsChecked = on, StaysOpenOnClick = true };
        if (tip != null) mi.ToolTip = tip;
        RoutedEventHandler h = (s, e) => { if (!_dimInit) return; set(mi.IsChecked); _vp.Redraw(); };
        mi.Checked += h; mi.Unchecked += h;
        return mi;
    }

    private void DimRadioGroup<T>(MenuItem parent, IEnumerable<(string Text, T Value)> items, Func<T> get, Action<T> set)
    {
        var list = new List<MenuItem>();
        foreach (var (text, value) in items)
        {
            var mi = new MenuItem { Header = text, IsCheckable = true, IsChecked = EqualityComparer<T>.Default.Equals(get(), value), StaysOpenOnClick = true };
            var captured = value;
            mi.Click += (s, e) =>
            {
                set(captured);
                foreach (var o in list) o.IsChecked = ReferenceEquals(o, mi);
                _vp.Redraw();
            };
            list.Add(mi); parent.Items.Add(mi);
        }
    }

    private void InitDims()
    {
        var d = _vp.Dims;
        var m = MenuDims;
        m.Items.Clear();
        m.Items.Add(DimCheck("Afficher les cotes", d.Show, v => d.Show = v));
        m.Items.Add(new Separator());
        m.Items.Add(DimCheck("Cotes automatiques (masquer = seules les cotes manuelles restent)", d.ShowAuto, v => d.ShowAuto = v));
        m.Items.Add(DimCheck("Entraxes (chaîne de cotes entre axes)", d.Chain, v => d.Chain = v, "Plan : axes X et Y ; élévation et côté : axes horizontaux"));
        m.Items.Add(DimCheck("Cotes cumulées depuis le premier axe", d.Cumul, v => d.Cumul = v));
        m.Items.Add(DimCheck("Cote totale hors-tout", d.Overall, v => d.Overall = v));
        m.Items.Add(DimCheck("Hauteurs d'étage et cotes de niveau (élévation, côté)", d.Levels, v => d.Levels = v));
        m.Items.Add(DimCheck("Cotes automatiques en 3D (entraxes, hauteurs d'étage, hors-tout)", d.Auto3D, v => d.Auto3D = v));
        m.Items.Add(new Separator());
        m.Items.Add(DimCheck("Longueur de chaque barre", d.Members, v => d.Members = v));
        m.Items.Add(DimCheck("Dimensions des dalles (plan)", d.Slabs, v => d.Slabs = v));
        m.Items.Add(DimCheck("Coordonnées des nœuds (x ; y ; z)", d.Nodes, v => d.Nodes = v));
        m.Items.Add(new Separator());
        var unit = new MenuItem { Header = "Unité" };
        DimRadioGroup(unit, new[] { ("mètres (m)", "m"), ("centimètres (cm)", "cm"), ("millimètres (mm)", "mm") }, () => d.Unit, v => d.Unit = v);
        m.Items.Add(unit);
        var dec = new MenuItem { Header = "Décimales" };
        DimRadioGroup(dec, new[] { ("0", 0), ("1", 1), ("2", 2), ("3", 3) }, () => d.Decimals, v => d.Decimals = v);
        m.Items.Add(dec);
        var size = new MenuItem { Header = "Taille du texte" };
        DimRadioGroup(size, new[] { ("petit", 9.0), ("moyen", 10.0), ("grand", 12.0), ("très grand", 14.0) }, () => d.Font, v => d.Font = v);
        m.Items.Add(size);
        m.Items.Add(new Separator());
        var tool = new MenuItem { Header = "Cote manuelle entre deux points (outil Cote)" };
        tool.Click += (s, e) => RbDim.IsChecked = true;
        m.Items.Add(tool);
        var delSel = new MenuItem { Header = "Supprimer la cote manuelle sélectionnée (clic sur la cote puis Suppr)" };
        delSel.Click += (s, e) => { if (_vp.SelectedDim == null) { StatusLeft.Text = "Cliquez d'abord une cote manuelle (outil Sélection)."; return; } StatusLeft.Text = _vp.DeleteSelectedObject(); };
        m.Items.Add(delSel);
        var clear = new MenuItem { Header = "Effacer les cotes manuelles" };
        clear.Click += (s, e) => { _vp.ClearManualDims(); StatusLeft.Text = "Cotes manuelles effacées."; };
        m.Items.Add(clear);
        _dimInit = true;
    }
}
