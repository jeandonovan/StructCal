using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Fenêtre « Dalle à dessiner » : choix du type de dalle (liste déroulante) et de ses paramètres (épaisseur, sens de portée, charges...).
/// Après validation, l'outil Dalle dessine les panneaux avec ces paramètres.</summary>
public sealed class SlabDrawWindow : Window
{
    public SlabPanel Proto { get; }
    /// <summary>Préfixe du nom des dalles (D → D1, D2...).</summary>
    public string Prefix { get; private set; } = "D";
    /// <summary>Dessin d'une dalle par clic dans une trame (entre axes) au lieu de deux coins.</summary>
    public bool ByBay { get; private set; }
    /// <summary>Cote imposée par le niveau choisi (null = niveau de travail courant).</summary>
    public double? LevelZ { get; private set; }
    private readonly List<(string Name, double Z)> _levels;
    private double _rev, _clo;
    private const double NoLevel = -9999;
    private readonly ContentControl _host = new();
    private readonly TextBlock _info = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(12, 0, 12, 6), FontSize = 11 };

    public SlabDrawWindow(SlabPanel? like, IEnumerable<(string Name, double Z)> levels, string prefix, bool byBay, double? levelZ)
    {
        _levels = levels.ToList(); Prefix = string.IsNullOrWhiteSpace(prefix) ? "D" : prefix; ByBay = byBay; LevelZ = levelZ;
        Proto = new SlabPanel
        {
            Kind = like?.Kind ?? SlabKind.Pleine, H = like?.H ?? 0.16, Gamma = like?.Gamma ?? 25, GExtra = like?.GExtra ?? 1.5, Q = like?.Q ?? 2.5,
            CalcMode = like?.CalcMode ?? SlabCalcMode.Bidirectional, Continuity = like?.Continuity ?? SlabContinuity.Interieure,
            Crack = like?.Crack ?? CrackingClass.PeuPrejudiciable, HourdisCm = like?.HourdisCm ?? 16, ToppingCm = like?.ToppingCm ?? 4,
            VolumeFactor = like?.VolumeFactor ?? 1, CoverCm = like?.CoverCm ?? 0
        };
        _rev = Proto.GExtra; _clo = 0;
        Title = "Dalle à dessiner - type et paramètres";
        Width = 580; Height = 720; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var root = new DockPanel();
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12) };
        bar.Children.Add(Ui.Btn("Valider et dessiner", (s, e) => { SlabPresets.Apply(Proto); DialogResult = true; }, true));
        bar.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(12, 5, 12, 5), IsCancel = true });
        DockPanel.SetDock(bar, Dock.Bottom); root.Children.Add(bar);
        DockPanel.SetDock(_info, Dock.Bottom); root.Children.Add(_info);
        root.Children.Add(new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _host });
        Content = root;
        Build();
    }

    private void Build()
    {
        var p = Proto; var f = new FormKit();
        f.Section("Type de dalle", "Choisissez le type puis réglez ses paramètres ; vous dessinerez ensuite la dalle en vue Plan (2 clics).");
        var kinds = Enum.GetValues<SlabKind>().Select(k => (SlabPresets.Name(k), k)).ToList();
        var cb = f.Combo("Type", kinds, () => p.Kind, v =>
        {
            if (v == p.Kind) return;
            p.Kind = v; p.H = SlabPresets.DefaultThicknessCm(v) / 100.0; p.CalcMode = SlabPresets.DefaultMode(v);
            if (v == SlabKind.Pleine || v == SlabKind.Predalle || v == SlabKind.Champignon) p.Gamma = 25;
            SlabPresets.Apply(p);
            Dispatcher.BeginInvoke(new Action(Build));
        });
        if (p.Kind == SlabKind.CorpsCreux)
        {
            f.Combo("Hauteur du hourdis", new[] { 12.0, 16, 20, 25, 30 }.Select(h => ($"{h:0} cm", h)).ToList(), () => p.HourdisCm, v => { p.HourdisCm = v; Refresh(); });
            f.Num("Dalle de compression", () => p.ToppingCm, v => { p.ToppingCm = v; Refresh(); }, "4 cm minimum", "cm");
        }
        else f.Num("Épaisseur totale h", () => p.H * 100, v => { p.H = v / 100.0; Refresh(); }, null, "cm");
        f.Combo("Sens de portée", new (string, SlabCalcMode)[]
        {
            ("Deux sens (selon Lx/Ly)", SlabCalcMode.Bidirectional), ("Un sens : portée selon X (charge sur les poutres // Y)", SlabCalcMode.OneWayX),
            ("Un sens : portée selon Y (charge sur les poutres // X)", SlabCalcMode.OneWayY), ("Masse seule (pas de charge transmise)", SlabCalcMode.MassOnly)
        }, () => p.CalcMode, v => { p.CalcMode = v; Refresh(); });
        if (p.Kind != SlabKind.CorpsCreux)
            f.Num("Poids volumique béton γ", () => p.Gamma, v => { p.Gamma = v; Refresh(); }, "25 kN/m³ pour le béton armé", "kN/m³");
        f.Num("Revêtement et enduit", () => _rev, v => { _rev = v; p.GExtra = _rev + _clo; Refresh(); }, "Chape, carrelage, faux-plafond (sans le poids propre)", "kN/m²");
        f.Num("Cloisons légères", () => _clo, v => { _clo = v; p.GExtra = _rev + _clo; Refresh(); }, "Environ 1,0 kN/m² pour des cloisons en briques creuses de 10 cm", "kN/m²");
        f.Num("Charge d'exploitation Q", () => p.Q, v => { p.Q = v; Refresh(); }, "1,5 habitation ; 2,5 bureaux", "kN/m²");
        f.Section("Dessin", "Dessiner par deux coins, ou d'un seul clic dans une trame fermée par des axes ou des nœuds.");
        f.Text("Préfixe du nom", () => Prefix, v => Prefix = string.IsNullOrWhiteSpace(v) ? "D" : v.Trim());
        f.Combo("Méthode de dessin", new (string, bool)[] { ("Deux coins opposés", false), ("Un clic dans une trame", true) }, () => ByBay, v => ByBay = v);
        var lv = new List<(string, double)> { ("Niveau de travail courant", NoLevel) };
        lv.AddRange(_levels.Select(l => ($"{l.Name}  (z = {l.Z:0.##} m)", l.Z)));
        f.Combo("Niveau de la dalle", lv, () => LevelZ ?? NoLevel, v => LevelZ = v == NoLevel ? null : v, "Le niveau devient le plan de travail ; la dalle y est rattachée");
        f.Section("Dimensionnement");
        f.Num("Enrobage des armatures", () => p.CoverCm, v => p.CoverCm = v, "0 = valeur générale du projet", "cm");
        f.Combo("Continuité", new (string, SlabContinuity)[] { ("Intérieure", SlabContinuity.Interieure), ("Rive", SlabContinuity.Rive), ("Simplement appuyée", SlabContinuity.Simple) }, () => p.Continuity, v => p.Continuity = v);
        f.Combo("Fissuration", new (string, CrackingClass)[] { ("Peu préjudiciable", CrackingClass.PeuPrejudiciable), ("Préjudiciable", CrackingClass.Prejudiciable), ("Très préjudiciable", CrackingClass.TresPrejudiciable) }, () => p.Crack, v => p.Crack = v);
        _host.Content = f.Root;
        Refresh();
    }

    private void Refresh()
    {
        var p = Proto;
        var c = new SlabPanel { Kind = p.Kind, H = p.H, Gamma = p.Gamma, HourdisCm = p.HourdisCm, ToppingCm = p.ToppingCm, VolumeFactor = p.VolumeFactor };
        SlabPresets.Apply(c);
        _info.Text = SlabPresets.Hint(p.Kind) + $"\nÉpaisseur {c.H * 100:0} cm · poids propre {c.H * c.Gamma:0.00} kN/m² · béton {c.VolumeFactor * c.H:0.000} m³/m²"
            + (SlabPresets.DesignedAsSolid(p.Kind) ? "" : "\nCe type n'est pas ferraillé par le programme : il compte pour les charges et le métré.");
    }
}
