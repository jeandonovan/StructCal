using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Sélection multiple (Ctrl = ajouter, Maj = retirer, rectangle) et opérations sur la sélection : copie, symétrie, déplacement, suppression, charges.</summary>
public partial class MainWindow
{
    private List<int> Sel() => _vp.Selection.ToList();

    private void UpdateSelectionStatus()
    {
        int n = _vp.Selection.Count;
        if (n == 0) { StatusMid.Text = BaseStatusMid(); return; }
        if (n == 1) return;
        var mems = _model.Members.Where(m => _vp.IsSelected(m.Id)).ToList();
        int cols = mems.Count(m => m.Type == MemberType.Column), beams = mems.Count - cols;
        StatusMid.Text = $"{n} barres sélectionnées ({beams} poutre(s), {cols} poteau(x))  ·  Ctrl+clic : ajouter  ·  Maj+clic : retirer  ·  Échap : tout désélectionner";
    }

    /// <summary>Panneau de droite pour une sélection de plusieurs barres.</summary>
    private void ShowGroup()
    {
        var mems = _model.Members.Where(m => _vp.IsSelected(m.Id)).ToList();
        if (mems.Count == 0) { ShowMember(-1); return; }
        var nodes = _model.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        double total = 0;
        foreach (var m in mems)
            if (nodes.TryGetValue(m.NodeI, out var a) && nodes.TryGetValue(m.NodeJ, out var b))
                total += Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
        int prim = _vp.SelectedId >= 0 ? _vp.SelectedId : mems[0].Id;
        var primary = mems.FirstOrDefault(m => m.Id == prim) ?? mems[0];
        FillEditor(primary);
        DetailTitle.Text = $"{mems.Count} barres sélectionnées";
        DetailSub.Text = "Les modifications du panneau « Modifier la barre » s'appliquent à toutes les barres sélectionnées.";
        var props = new List<object>
        {
            new { Parametre = "Poutres / poteaux", Valeur = $"{mems.Count(m => m.Type == MemberType.Beam)} / {mems.Count(m => m.Type == MemberType.Column)}" },
            new { Parametre = "Béton armé / acier", Valeur = $"{mems.Count(m => m.Kind == MaterialKind.ReinforcedConcrete)} / {mems.Count(m => m.Kind == MaterialKind.Steel)}" },
            new { Parametre = "Longueur totale", Valeur = $"{total:0.00} m" },
        };
        foreach (var g in mems.GroupBy(m => m.Kind == MaterialKind.Steel ? m.Profile : $"{m.B * 100:0}x{m.H * 100:0}").OrderByDescending(g => g.Count()).Take(6))
            props.Add(new { Parametre = "Section " + (string.IsNullOrEmpty(g.Key) ? "?" : g.Key), Valeur = $"{g.Count()} barre(s)" });
        if (_out != null)
        {
            var res = _out.Members.Where(r => _vp.IsSelected(r.MemberId) && !r.Skipped).ToList();
            if (res.Count > 0)
            {
                props.Add(new { Parametre = "Taux max", Valeur = $"{res.Max(r => r.Utilization) * 100:0} %" });
                props.Add(new { Parametre = "Barres NON OK", Valeur = res.Count(r => !r.Ok).ToString() });
            }
        }
        GridProps.ItemsSource = props;
        var pr = _out?.Members.FirstOrDefault(r => r.MemberId == primary.Id);
        SectionDrawing.MountingDiaMm = _model.Settings.MountingBarDiaMm;
        SectionDrawing.Draw(SectionCanvas, primary, pr);
        NotesBox.Text = "Barres : " + string.Join(", ", mems.Select(m => m.Id).Take(60)) + (mems.Count > 60 ? " ..." : "") +
                        Environment.NewLine + Environment.NewLine +
                        "Ctrl + clic : ajoute ou retire une barre" + Environment.NewLine +
                        "Maj + clic : retire une barre de la sélection" + Environment.NewLine +
                        "Ctrl + glisser : rectangle d'ajout (de gauche à droite = barres entièrement dedans ; de droite à gauche = barres touchées)" + Environment.NewLine +
                        "Maj + glisser : rectangle de retrait" + Environment.NewLine +
                        "Ctrl + A : tout sélectionner   ·   Suppr : supprimer la sélection   ·   Échap : désélectionner";
    }

    // ------------------------------------------------------------------ menu Sélection
    private void SelectAll_Click(object sender, RoutedEventArgs e)
    {
        _vp.SelectAll();
        StatusLeft.Text = _vp.SelectedCount == 0 ? "Rien de visible à sélectionner." : "Tout le visible est sélectionné : " + _vp.Report().Text + "  (les nœuds : menu Sélection > Tous les nœuds).";
    }

    private void SelectNone_Click(object sender, RoutedEventArgs e) { _vp.ClearAllSelection(); StatusLeft.Text = "Sélection effacée."; }

    private void SelectInvert_Click(object sender, RoutedEventArgs e)
    {
        // inverse parmi les éléments visibles : barres et éléments surfaciques (ou seulement les nœuds si seuls des nœuds sont sélectionnés)
        if (_vp.SelectedNodes.Count > 0 && _vp.Selection.Count == 0 && _vp.SelectedElementKeys.Count == 0)
            _vp.InvertSelection(new[] { StructCalc.Engine.Selection.ElementKind.Node });
        else _vp.InvertSelection();
        StatusLeft.Text = "Sélection inversée : " + _vp.Report().Text;
    }

    private void SelectRule_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem mi || mi.Tag is not string rule) return;
        if ((rule == "sameSection" || rule == "sameLevel") && _vp.SelectedId < 0)
        {
            StatusLeft.Text = "Sélectionnez d'abord une barre de référence, puis relancez cette commande.";
            return;
        }
        if (rule == "failing")
        {
            if (_out == null) { StatusLeft.Text = "Lancez d'abord le calcul (F5)."; return; }
            var bad = _out.Members.Where(r => !r.Skipped && !r.Ok).Select(r => r.MemberId).ToList();
            _vp.SetSelection(bad);
            StatusLeft.Text = $"{bad.Count} barre(s) non conforme(s) sélectionnée(s).";
            return;
        }
        var ids = SelectionTools.SelectWhere(_model, rule, _vp.SelectedId);
        _vp.SetSelection(ids);
        StatusLeft.Text = $"{ids.Count} barre(s) sélectionnée(s).";
    }

    private bool NeedSelection(string what)
    {
        if (_vp.Selection.Count > 0) return true;
        MessageBox.Show($"Sélectionnez d'abord des barres dans la vue (clic, Ctrl+clic, Ctrl+glisser) pour {what}.", "StructCalc", MessageBoxButton.OK, MessageBoxImage.Information);
        return false;
    }

    private void DeleteSelection_Click(object sender, RoutedEventArgs e)
    {
        if (_vp.Selection.Count == 0) { StatusLeft.Text = "Rien n'est sélectionné."; return; }
        int n = _vp.Selection.Count;
        if (n > 5 && MessageBox.Show($"Supprimer {n} barres (et leurs charges) ?\nVous pourrez annuler avec Ctrl+Z.", "Supprimer la sélection", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        CommitGrids();
        PushUndo();
        SelectionTools.Delete(_model, Sel());
        _vp.ClearSelection();
        OnModelEdited();
        ShowMember(-1);
        Log($"{n} barre(s) supprimée(s).");
    }

    private void CopySelection_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les copier")) return;
        var v = PromptWindow.Ask(this, "Copier la sélection", $"Copie {_vp.Selection.Count} barre(s) avec décalage. Les nœuds communs sont fusionnés avec l'existant ; les charges sont copiées.",
            ("Décalage dX (m)", "0"), ("Décalage dY (m)", "5"), ("Décalage dZ (m)", "0"), ("Nombre de copies", "1"), ("Copier aussi les appuis (oui/non)", "non"));
        if (v == null) return;
        double dx = Ui.Num(v[0], 0), dy = Ui.Num(v[1], 0), dz = Ui.Num(v[2], 0); int count = (int)Ui.Num(v[3], 1);
        bool sup = v[4].Trim().ToLowerInvariant().StartsWith("o");
        if (count < 1 || count > 100 || (Math.Abs(dx) + Math.Abs(dy) + Math.Abs(dz) < 1e-9)) { MessageBox.Show("Décalage nul ou nombre de copies invalide.", "Copier", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        CommitGrids();
        PushUndo();
        var created = SelectionTools.Copy(_model, Sel(), dx, dy, dz, count, true, sup);
        OnModelEdited();
        _vp.SetSelection(created);
        Log($"{created.Count} barre(s) créée(s) par copie.");
    }

    private void MirrorSelection_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("faire une symétrie")) return;
        var v = PromptWindow.Ask(this, "Symétrie de la sélection", "Plan de symétrie : « x » = plan x = c (miroir gauche/droite), « y » = plan y = c (miroir avant/arrière).",
            ("Axe du plan (x ou y)", "x"), ("Coordonnée c du plan (m)", "0"), ("Conserver les barres d'origine (oui/non)", "oui"));
        if (v == null) return;
        char axis = v[0].Trim().ToLowerInvariant().StartsWith("y") ? 'y' : 'x';
        double c = Ui.Num(v[1], 0); bool keep = !v[2].Trim().ToLowerInvariant().StartsWith("n");
        CommitGrids();
        PushUndo();
        var created = SelectionTools.Mirror(_model, Sel(), axis, c, keep);
        OnModelEdited();
        _vp.SetSelection(created);
        Log($"Symétrie : {created.Count} barre(s) créée(s).");
    }

    private void MoveSelection_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les déplacer")) return;
        var v = PromptWindow.Ask(this, "Déplacer la sélection", "Déplace les nœuds des barres sélectionnées (les barres voisines qui partagent ces nœuds suivent).",
            ("dX (m)", "0"), ("dY (m)", "0"), ("dZ (m)", "0"));
        if (v == null) return;
        double dx = Ui.Num(v[0], 0), dy = Ui.Num(v[1], 0), dz = Ui.Num(v[2], 0);
        CommitGrids();
        PushUndo();
        int n = SelectionTools.Move(_model, Sel(), dx, dy, dz);
        OnModelEdited();
        Log($"{n} nœud(s) déplacé(s).");
    }

    private void ZoomSelectionAll_Click(object sender, RoutedEventArgs e) => _vp.ZoomSelection();
}
