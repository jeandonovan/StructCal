using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Options (apparence, couleurs, raccourcis), enregistrement direct, projet modifié, propriétés du projet.</summary>
public partial class MainWindow
{
    private string? _filePath;
    private bool _dirty;
    private List<ShortcutAction>? _shortcutList;

    // ---------------------------------------------------------------- raccourcis clavier
    private static RoutedEventArgs Ev => new RoutedEventArgs();

    private List<ShortcutAction> Shortcuts => _shortcutList ??= new List<ShortcutAction>
    {
        new() { Id = "file.new", Group = "Fichier", Label = "Nouveau projet", Run = () => New_Click(this, Ev) },
        new() { Id = "file.close", Group = "Fichier", Label = "Fermer le projet", Run = () => CloseProject_Click(this, Ev) },
        new() { Id = "file.open", Group = "Fichier", Label = "Ouvrir...", Default = "Ctrl+O", Builtin = true, Run = () => Open_Click(this, Ev) },
        new() { Id = "file.save", Group = "Fichier", Label = "Enregistrer", Default = "Ctrl+S", Builtin = true, Run = () => Save_Click(this, Ev) },
        new() { Id = "file.saveas", Group = "Fichier", Label = "Enregistrer sous...", Default = "Ctrl+Maj+S", Run = () => SaveAs_Click(this, Ev) },
        new() { Id = "file.print", Group = "Fichier", Label = "Imprimer la vue", Default = "Ctrl+P", Builtin = true, Run = () => PrintView_Click(this, Ev) },
        new() { Id = "file.import", Group = "Fichier", Label = "Importer un fond de plan", Default = "Ctrl+Maj+I", Run = () => ImportUnderlay_Click(this, Ev) },
        new() { Id = "file.pdf", Group = "Fichier", Label = "Exporter la note de calcul (PDF)", Run = () => ExportPdf_Click(this, Ev) },
        new() { Id = "file.png", Group = "Fichier", Label = "Exporter l'image de la vue (PNG)", Run = () => ExportPng_Click(this, Ev) },
        new() { Id = "file.info", Group = "Fichier", Label = "Propriétés du projet", Run = () => ProjectInfo_Click(this, Ev) },
        new() { Id = "edit.undo", Group = "Édition", Label = "Annuler", Default = "Ctrl+Z", Builtin = true, Run = () => Undo_Click(this, Ev) },
        new() { Id = "edit.redo", Group = "Édition", Label = "Rétablir", Default = "Ctrl+Y", Builtin = true, Run = () => Redo_Click(this, Ev) },
        new() { Id = "edit.all", Group = "Édition", Label = "Tout sélectionner", Default = "Ctrl+A", Builtin = true, Run = () => SelectAll_Click(this, Ev) },
        new() { Id = "edit.delete", Group = "Édition", Label = "Supprimer la sélection", Default = "Delete", Builtin = true, Run = () => { if (_vp.HasAnySelection) DeleteAnySelection(); } },
        new() { Id = "edit.filter", Group = "Sélection", Label = "Filtre de sélection", Default = "Ctrl+F", Builtin = true, Run = () => Filter_Click(this, Ev) },
        new() { Id = "mod.move", Group = "Modifier", Label = "Déplacer (2 points)", Default = "M", Builtin = true, Run = () => { if (_vp.Selection.Count > 0) MovePick_Click(this, Ev); } },
        new() { Id = "mod.copy", Group = "Modifier", Label = "Copier (2 points)", Default = "C", Builtin = true, Run = () => { if (_vp.Selection.Count > 0) CopyPick_Click(this, Ev); } },
        new() { Id = "mod.rotate", Group = "Modifier", Label = "Rotation", Default = "R", Builtin = true, Run = () => { if (_vp.Selection.Count > 0) Rotate_Click(this, Ev); } },
        new() { Id = "mod.hide", Group = "Modifier", Label = "Masquer la sélection", Default = "H", Run = () => HideSelection() },
        new() { Id = "mod.isolate", Group = "Modifier", Label = "Isoler la sélection", Default = "I", Run = () => IsolateSelection() },
        new() { Id = "mod.showall", Group = "Modifier", Label = "Tout afficher", Default = "Ctrl+H", Run = () => ShowAllHidden() },
        new() { Id = "load.assist", Group = "Charges", Label = "Assistant de charges", Default = "Ctrl+L", Builtin = true, Run = () => LoadAssistant_Click(this, Ev) },
        new() { Id = "view.snap", Group = "Vue", Label = "Accrochage (activer / désactiver)", Default = "F3", Builtin = true, Run = () => ToggleSnap() },
        new() { Id = "view.zoomsel", Group = "Vue", Label = "Zoom sur la sélection", Default = "Z", Builtin = true, Run = () => _vp.ZoomSelection() },
        new() { Id = "view.zoomall", Group = "Vue", Label = "Zoom étendu (tout voir)", Default = "Home", Builtin = true, Run = () => _vp.ZoomExtents() },
        new() { Id = "view.plan", Group = "Vue", Label = "Vue en plan", Run = () => _vp.SetMode(ViewMode.Plan) },
        new() { Id = "view.iso", Group = "Vue", Label = "Vue 3D", Run = () => _vp.SetMode(ViewMode.Iso) },
        new() { Id = "calc.run", Group = "Calcul", Label = "Lancer le calcul", Default = "F5", Builtin = true, Run = () => Run_Click(this, Ev) },
        new() { Id = "calc.global", Group = "Calcul", Label = "Résultats globaux", Default = "F6", Builtin = true, Run = () => GlobalResults_Click(this, Ev) },
        new() { Id = "calc.check", Group = "Calcul", Label = "Vérifier le modèle", Run = () => Check_Click(this, Ev) },
        new() { Id = "tools.palette", Group = "Outils", Label = "Palette de commandes (rechercher)", Default = "Ctrl+K", Run = () => Palette_Click(this, Ev) },
        new() { Id = "tools.profiles", Group = "Outils", Label = "Mes profilés acier personnalisés", Run = () => CustomProfiles_Click(this, Ev) },
        new() { Id = "calc.modal", Group = "Calcul", Label = "Analyse modale", Run = () => Modal_Click(this, Ev) },
        new() { Id = "calc.variants", Group = "Calcul", Label = "Comparer des variantes", Run = () => Variants_Click(this, Ev) },
        new() { Id = "tools.combos", Group = "Calcul", Label = "Combinaisons d'actions", Run = () => Combos_Click(this, Ev) },
        new() { Id = "file.versions", Group = "Fichier", Label = "Historique des versions", Run = () => Versions_Click(this, Ev) },
        new() { Id = "tools.options", Group = "Outils", Label = "Options", Default = "Ctrl+Maj+O", Run = () => Options_Click(this, Ev) },
    };

    /// <summary>Appelé en premier par la gestion des touches : exécute un raccourci personnalisé et neutralise l'ancien raccourci d'une commande dont la touche a été changée.</summary>
    private bool HandleCustomShortcut(KeyEventArgs e)
    {
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        if (ShortcutAction.IsModifierKey(key) || key == Key.Escape) return false;
        var mods = Keyboard.Modifiers;
        string g = ShortcutAction.Format(key, mods);
        bool typing = InEditField() || Keyboard.FocusedElement is ComboBox;
        // une touche sans Ctrl/Alt ne doit jamais voler la saisie de texte
        bool plain = (mods & (ModifierKeys.Control | ModifierKeys.Alt)) == 0 && key is not (Key.F1 or Key.F2 or Key.F3 or Key.F4 or Key.F5 or Key.F6 or Key.F7 or Key.F8 or Key.F9 or Key.F10 or Key.F11 or Key.F12);
        if (plain && typing) return false;

        var hit = Shortcuts.FirstOrDefault(a => a.Current == g && (!a.Builtin || a.Modified));
        if (hit != null)
        {
            e.Handled = true;
            try { hit.Run(); } catch (Exception ex) { Say("Commande impossible : " + ex.Message); }
            return true;
        }
        // l'ancien raccourci d'une commande modifiée ne doit plus rien faire
        if (Shortcuts.Any(a => a.Builtin && a.Modified && a.Default == g)) { e.Handled = true; return true; }
        return false;
    }

    // ---------------------------------------------------------------- options
    private void ElementColors_Click(object sender, RoutedEventArgs e) => new ElementColorsWindow(this, () => _vp.Redraw()).ShowDialog();

    private void Options_Click(object sender, RoutedEventArgs e)
    {
        int tab = sender is FrameworkElement fe && fe.Tag is string s && int.TryParse(s, out var t) ? t : 0;
        new OptionsWindow(this, Shortcuts, UiScales, _uiScale, Theme.Dark, (dark, scale) =>
        {
            if (dark != Theme.Dark) { Theme.Set(dark); DarkMenu.IsChecked = dark; }
            if (Math.Abs(scale - _uiScale) > 1e-9) SetUiScale(scale);
            ApplyAppearance();
        }, tab) { }.ShowDialog();
    }

    /// <summary>Applique les options : couleur d'accentuation, fond et couleurs de la vue, sauvegarde automatique.</summary>
    private void ApplyAppearance()
    {
        var o = AppOptions.Current;
        if (AppOptions.TryColor(o.Accent, out var ac))
        {
            SetBrush("Accent", ac);
            SetBrush("AccentHover", Lighten(ac, 0.18));
        }
        _vp.SetPaletteAndRedraw(o.ColorOk, o.ColorKo, o.ColorBar);
        ApplyViewBack();
        if (_autoSave != null)
        {
            _autoSave.Stop();
            if (o.AutoSaveMinutes > 0) { _autoSave.Interval = TimeSpan.FromMinutes(o.AutoSaveMinutes); _autoSave.Start(); }
        }
    }

    private static Color Lighten(Color c, double f) =>
        Color.FromRgb((byte)(c.R + (255 - c.R) * f), (byte)(c.G + (255 - c.G) * f), (byte)(c.B + (255 - c.B) * f));

    private static void SetBrush(string key, Color c)
    {
        var r = Application.Current.Resources;
        if (r[key] is SolidColorBrush b && !b.IsFrozen) b.Color = c;
        else r[key] = new SolidColorBrush(c);
    }

    private void ApplyViewBack()
    {
        var o = AppOptions.Current;
        if (AppOptions.TryColor(o.ViewBack, out var c)) ViewCanvas.Background = Theme.Fixed(c);
        else ViewCanvas.Background = Theme.Fixed(Theme.Dark ? Color.FromRgb(0x1B, 0x1D, 0x21) : Colors.White);
        _vp.Redraw();
    }

    // ---------------------------------------------------------------- enregistrement direct, projet modifié
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrEmpty(_filePath) && !_filePath.Contains("from_revit", StringComparison.OrdinalIgnoreCase) && Directory.Exists(Path.GetDirectoryName(_filePath)!)) SaveTo(_filePath);
        else SaveAs_Click(sender, e);
    }

    private void SaveAs_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var dlg = new SaveFileDialog { Filter = AppInfo.SaveFilter, DefaultExt = AppInfo.FileExt, AddExtension = true, FileName = _model.Name + AppInfo.FileExt };
        if (dlg.ShowDialog() != true) return;
        SaveTo(dlg.FileName);
    }

    private void SaveTo(string path)
    {
        ReadParams();
        try
        {
            ModelIO.Save(_model, path);
            _filePath = path; _dirty = false;
            SnapshotVersion();
            AddRecent(path);
            Say("Enregistré : " + path);
        }
        catch (Exception ex) { Log("Erreur d'enregistrement : " + ex.Message); MessageBox.Show("Enregistrement impossible : " + ex.Message, AppInfo.Name, MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private bool ConfirmClose()
    {
        if (!_dirty || !AppOptions.Current.ConfirmOnClose || (_model.Members.Count == 0 && _model.Nodes.Count == 0)) return true;
        var r = MessageBox.Show($"Enregistrer les modifications de « {_model.Name} » avant de quitter ?", AppInfo.Name, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        if (r == MessageBoxResult.Cancel) return false;
        if (r == MessageBoxResult.Yes) { Save_Click(this, Ev); return !_dirty; }
        return true;
    }

    // ---------------------------------------------------------------- propriétés du projet
    private void ProjectInfo_Click(object sender, RoutedEventArgs e)
    {
        var i = _model.Info;
        var v = PromptWindow.Ask(this, "Propriétés du projet", "Ces informations figurent en tête de la note de calcul.",
            ("Nom du projet", _model.Name), ("Maître d'ouvrage / client", i.Client), ("Adresse / site", i.Site),
            ("Bureau d'études / ingénieur", i.Designer), ("Référence / affaire", i.Reference), ("Indice de révision", i.Revision), ("Remarques", i.Notes));
        if (v == null) return;
        PushUndo();
        _model.Name = string.IsNullOrWhiteSpace(v[0]) ? _model.Name : v[0].Trim();
        i.Client = v[1].Trim(); i.Site = v[2].Trim(); i.Designer = v[3].Trim(); i.Reference = v[4].Trim(); i.Revision = v[5].Trim(); i.Notes = v[6].Trim();
        _dirty = true;
        Say("Propriétés du projet mises à jour.");
    }
}

public partial class MainWindow
{
    private void Variants_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        if (_model.Members.Count == 0) { Say("Dessinez ou ouvrez d'abord un modèle."); return; }
        var w = new VariantsWindow(this, _model);
        if (w.ShowDialog() != true || w.Chosen == null) return;
        var v = w.Chosen;
        PushUndo();
        FcBox.Text = v.Fc28.ToString(System.Globalization.CultureInfo.CurrentCulture);
        FeBox.Text = v.Fe.ToString(System.Globalization.CultureInfo.CurrentCulture);
        foreach (var mem in _model.Members.Where(x => x.Kind == StructCalc.Core.MaterialKind.ReinforcedConcrete))
        {
            mem.B = Math.Max(0.15, Math.Round(mem.B * v.SectionFactor / 0.025) * 0.025);
            mem.H = Math.Max(0.15, Math.Round(mem.H * v.SectionFactor / 0.025) * 0.025);
        }
        ReadParams();
        OnModelEdited();
        Say($"Variante appliquée ({v.Name}) : lancez le calcul (F5).");
    }

    private void Modal_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        if (_model.Members.Count == 0) { Say("Dessinez ou ouvrez d'abord un modèle."); return; }
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            var r = ModalAnalysis.Compute(_model, 12);
            Mouse.OverrideCursor = null;
            var w = new Window { Title = "Analyse modale - " + _model.Name, Width = 780, Height = 460, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
            w.Content = new TextBox { Text = r.Report, IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, Margin = new Thickness(8), VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto };
            w.Show();
        }
        catch (Exception ex) { Mouse.OverrideCursor = null; Say("Analyse modale impossible : " + ex.Message); }
    }

    private void ModalPeriod_Click(object sender, RoutedEventArgs e)
    {
        PushUndo();
        _model.Seismic.UseModalPeriod = !_model.Seismic.UseModalPeriod;
        OnModelEdited();
        Say(_model.Seismic.UseModalPeriod
            ? "Séisme : la période de l'analyse modale sera utilisée (limitée à 1,3 x la période empirique en RPA 99). Relancez le calcul (F5)."
            : "Séisme : la période empirique sera utilisée. Relancez le calcul (F5).");
    }

    private void Spectral_Click(object sender, RoutedEventArgs e)
    {
        PushUndo();
        _model.Seismic.UseResponseSpectrum = !_model.Seismic.UseResponseSpectrum;
        if (_model.Seismic.UseResponseSpectrum && !_model.Seismic.Enabled) _model.Seismic.Enabled = true;
        OnModelEdited();
        Say(_model.Seismic.UseResponseSpectrum
            ? "Séisme : analyse modale spectrale (CQC) activée à la place de la force statique équivalente. Relancez le calcul (F5)."
            : "Séisme : force statique équivalente rétablie. Relancez le calcul (F5).");
    }

    private void CustomProfiles_Click(object sender, RoutedEventArgs e)
    {
        if (new CustomProfilesWindow(this).ShowDialog() == true) Say("Profilés personnalisés enregistrés : utilisables dans la liste des profilés (famille PERSO).");
    }

    private void Combos_Click(object sender, RoutedEventArgs e)
    {
        var w = new CombosWindow(this, _model, () =>
        {
            try
            {
                var code = DesignCodeRegistry.Get(_model.RcCodeId);
                return (code as IReinforcedConcreteCode)?.Combinations;
            }
            catch { return null; }
        });
        if (w.ShowDialog() != true) return;
        PushUndo();
        _model.UseCustomCombos = w.UseCustom;
        _model.CustomCombos = w.Result;
        _model.BaseFriction = w.Friction;
        OnModelEdited();
        Say(w.UseCustom ? $"{_model.CustomCombos.Count} combinaison(s) personnalisée(s) : relancez le calcul (F5)." : "Combinaisons de la norme utilisées.");
    }
}
