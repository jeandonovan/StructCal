using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Palette de commandes, modèles de projet, historique des versions.</summary>
public partial class MainWindow
{
    // ---------------------------------------------------------------- palette Ctrl+K
    private void Palette_Click(object sender, RoutedEventArgs e)
    {
        var list = new List<PaletteWindow.Entry>();
        var menu = FindMenu(this);
        if (menu != null) foreach (var top in menu.Items.OfType<MenuItem>()) Collect(top, Clean(top.Header), list);
        // commandes écrites de la barre de commande
        foreach (var (t, cmd) in new[]
        {
            ("Commande : fond (importer un fond de plan)", "fond"), ("Commande : fond pdf", "fond pdf"), ("Commande : fond dxf", "fond dxf"),
            ("Commande : exporter png", "exporter png"), ("Commande : exporter ifc", "exporter ifc"), ("Commande : imprimer", "imprimer"),
            ("Commande : étages", "etages"), ("Commande : aide", "aide")
        })
        {
            string c = cmd;
            list.Add(new PaletteWindow.Entry(t, t, () => RunLevelCommand(c)));
        }
        new PaletteWindow(this, list).Show();
    }

    private static Menu? FindMenu(DependencyObject d)
    {
        if (d is Menu m) return m;
        foreach (var c in LogicalTreeHelper.GetChildren(d))
            if (c is DependencyObject dd) { var r = FindMenu(dd); if (r != null) return r; }
        return null;
    }

    private static string Clean(object? header) => (header as string ?? "").Replace("_", "").Trim();

    private void Collect(MenuItem mi, string path, List<PaletteWindow.Entry> into)
    {
        var subs = mi.Items.OfType<MenuItem>().ToList();
        if (subs.Count == 0)
        {
            if (!mi.IsEnabled || path.Length == 0) return;
            string title = Clean(mi.Header);
            var item = mi;
            into.Add(new PaletteWindow.Entry(path, title, () =>
            {
                if (item.IsCheckable) item.IsChecked = !item.IsChecked;
                item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
            }));
            return;
        }
        foreach (var s in subs) Collect(s, path + "  ›  " + Clean(s.Header), into);
    }

    // ---------------------------------------------------------------- modèles de projet
    private void Templates_Click(object sender, RoutedEventArgs e)
    {
        var items = new (string Name, string Desc, Func<StructModel> Make)[]
        {
            ("Villa R+1 (béton armé)", "3 travées de 4,50 m, 2 niveaux de 3,00 m, portique plan.", () => Make(new FrameSpec { BaysX = 3, Storeys = 2, SpanX = 4.5, StoreyHeight = 3.0, ColB = 0.25, ColH = 0.25, BeamB = 0.25, BeamH = 0.40, G = 16, Q = 4 }, "Villa R+1")),
            ("Immeuble R+4 (béton armé)", "3 travées de 5,00 m, 5 niveaux de 3,06 m, poteaux 30x30.", () => Make(new FrameSpec { BaysX = 3, Storeys = 5, SpanX = 5.0, StoreyHeight = 3.06, ColB = 0.30, ColH = 0.30, BeamB = 0.25, BeamH = 0.45, G = 20, Q = 6 }, "Immeuble R+4")),
            ("Bâtiment 3D R+2 (béton armé)", "3 x 3 travées de 5,00 m, 3 niveaux : ossature spatiale.", () => Make(new FrameSpec { BaysX = 3, BaysY = 3, Storeys = 3, SpanX = 5.0, SpanY = 5.0, StoreyHeight = 3.06, ColB = 0.30, ColH = 0.30, BeamB = 0.25, BeamH = 0.45, G = 18, Q = 5 }, "Bâtiment 3D R+2")),
            ("Hangar / portique acier", "2 travées de 10 m, hauteur 6 m, HEA 300 / IPE 400.", () => Make(new FrameSpec { BaysX = 2, Storeys = 1, SpanX = 10, StoreyHeight = 6, Steel = true, ColProfile = "HEA300", BeamProfile = "IPE400", G = 6, Q = 4 }, "Hangar acier")),
            ("Portique béton (exemple)", "Exemple du logiciel : portique 2 travées / 2 niveaux.", () => ExampleModels.Portal()),
            ("Projet vide", "Repartir de zéro.", () => new StructModel())
        };
        var w = new Window { Title = "Nouveau projet depuis un modèle", Width = 520, Height = 380, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        var lb = new ListBox { Margin = new Thickness(8) };
        foreach (var it in items) lb.Items.Add(new TextBlock { Text = it.Name + "\n" + it.Desc, Margin = new Thickness(4), Tag = it.Make });
        lb.SelectedIndex = 0;
        var ok = new Button { Content = "Créer", IsDefault = true, Padding = new Thickness(18, 4, 18, 4), Margin = new Thickness(8), HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "Annuler", IsCancel = true, Padding = new Thickness(14, 4, 14, 4), Margin = new Thickness(0, 8, 0, 8) };
        Func<StructModel>? chosen = null;
        ok.Click += (s, a) => { if (lb.SelectedItem is TextBlock tb) { chosen = (Func<StructModel>)tb.Tag; w.DialogResult = true; } };
        lb.MouseDoubleClick += (s, a) => ok.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        bar.Children.Add(cancel); bar.Children.Add(ok);
        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Bottom);
        root.Children.Add(bar); root.Children.Add(lb);
        w.Content = root;
        if (w.ShowDialog() != true || chosen == null) return;
        if (!ConfirmClose()) return;
        try
        {
            _model = chosen();
            BindModel();
            _filePath = null; _dirty = true;
            _vp.ZoomExtents();
            Say("Projet créé depuis un modèle : adaptez les sections et les charges, puis F5.");
        }
        catch (Exception ex) { Say("Création impossible : " + ex.Message); }
    }

    private static StructModel Make(FrameSpec spec, string name)
    {
        var m = FrameGenerator.Generate(spec);
        m.Name = name;
        return m;
    }

    // ---------------------------------------------------------------- historique des versions
    private static string HistoryDir(string project)
    {
        string safe = string.Concat(project.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        string d = Path.Combine(DataDir, "versions", safe.Length == 0 ? "projet" : safe);
        Directory.CreateDirectory(d);
        return d;
    }

    /// <summary>Garde une copie datée du projet à chaque enregistrement (les 30 dernières).</summary>
    private void SnapshotVersion(string? label = null)
    {
        try
        {
            string d = HistoryDir(_model.Name);
            string f = Path.Combine(d, DateTime.Now.ToString("yyyyMMdd_HHmmss") + (string.IsNullOrWhiteSpace(label) ? "" : "_" + label) + AppInfo.FileExt);
            ModelIO.Save(_model, f);
            foreach (var old in Directory.GetFiles(d, "*" + AppInfo.FileExt).OrderByDescending(x => x).Skip(30)) File.Delete(old);
        }
        catch { }
    }

    private void Versions_Click(object sender, RoutedEventArgs e)
    {
        string d = HistoryDir(_model.Name);
        var files = Directory.GetFiles(d, "*" + AppInfo.FileExt).OrderByDescending(x => x).ToList();
        var w = new Window { Title = "Historique des versions - " + _model.Name, Width = 520, Height = 420, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        var lb = new ListBox { Margin = new Thickness(8) };
        foreach (var f in files)
        {
            var t = File.GetLastWriteTime(f);
            lb.Items.Add(new TextBlock { Text = $"{t:dd/MM/yyyy HH:mm:ss}   ({new FileInfo(f).Length / 1024} Ko)", Tag = f, Margin = new Thickness(3) });
        }
        if (files.Count == 0) lb.Items.Add(new TextBlock { Text = "Aucune version : une copie est gardée à chaque enregistrement (Ctrl+S).", Foreground = System.Windows.Media.Brushes.Gray });
        var save = new Button { Content = "Garder une version maintenant", Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(8, 8, 0, 8) };
        var restore = new Button { Content = "Restaurer cette version", Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(8), IsDefault = true };
        var close = new Button { Content = "Fermer", IsCancel = true, Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 8, 8, 8) };
        save.Click += (s, a) => { ReadParams(); SnapshotVersion("manuel"); w.DialogResult = false; Say("Version enregistrée dans l'historique."); };
        string? pick = null;
        restore.Click += (s, a) => { if (lb.SelectedItem is TextBlock tb && tb.Tag is string p) { pick = p; w.DialogResult = true; } };
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        bar.Children.Add(save); bar.Children.Add(restore); bar.Children.Add(close);
        var root = new DockPanel();
        DockPanel.SetDock(bar, Dock.Bottom);
        root.Children.Add(bar); root.Children.Add(lb);
        w.Content = root;
        if (w.ShowDialog() != true || pick == null) return;
        if (MessageBox.Show("Restaurer cette version ?\nLe modèle actuel sera remplacé (Ctrl+Z pour revenir).", AppInfo.Name, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        string keepPath = _filePath ?? "";
        PushUndo();
        if (OpenModelFile(pick)) { _filePath = string.IsNullOrEmpty(keepPath) ? null : keepPath; _dirty = true; Say("Version restaurée : enregistrez (Ctrl+S) pour la conserver."); }
    }
}
