using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

public enum ViewTargetKind { None, Node, Member, Slab, Load, Dim, Shell, Element, Selection }

/// <summary>Élément visé par un clic droit dans la vue (nœud, barre, dalle ou zone vide) et position écran du clic.</summary>
public sealed class ViewTarget
{
    public ViewTargetKind Kind { get; init; }
    public int Id { get; init; }
    public SlabPanel? Slab { get; init; }
    public ShellPanel? Shell { get; init; }
    /// <summary>Élément surfacique visé (escalier, semelle, voile, radier, plancher nervuré...), ou clé de la sélection multiple.</summary>
    public StructCalc.Engine.Selection.ElementKey? Key { get; init; }
    /// <summary>Charge (MemberLoad, SurfaceLoad, NodalLoad) ou cote (ManualDim) visée.</summary>
    public object? Obj { get; init; }
    public Point At { get; init; }
}

/// <summary>Sélection des nœuds (clic, Ctrl+clic, rectangle) et clic droit contextuel façon Robot / Advance Design.</summary>
public sealed partial class ModelViewport
{
    private readonly HashSet<int> _selNodes = new();
    private int _hoverNode = -1;
    private Point _rightDown;
    private bool _rightMoved, _rightArmed;

    public IReadOnlyCollection<int> SelectedNodes => _selNodes;
    public int PrimaryNode { get; private set; } = -1;
    public bool HasAnySelection => SelectedCount > 0 || SelectedLoad != null || SelectedDim != null;
    public UIElement Surface => _c;

    /// <summary>Déclenché quand l'ensemble de nœuds sélectionnés change.</summary>
    public event Action? NodeSelectionChanged;
    /// <summary>Clic droit (sans glisser) : l'élément visé est déjà sélectionné ; la fenêtre principale construit le menu.</summary>
    public event Action<ViewTarget>? ContextRequested;

    public void SetNodeSelection(IEnumerable<int> ids, bool notify = true)
    {
        bool hadMembers = _sel.Count > 0;
        bool hadSlab = _selKeys.Any(k => k.Kind == StructCalc.Engine.Selection.ElementKind.Slab); _selKeys.Clear();
        _selNodes.Clear();
        foreach (int i in ids) _selNodes.Add(i);
        PrimaryNode = _selNodes.Count > 0 ? _selNodes.Last() : -1;
        if (_selNodes.Count > 0 && hadMembers) { _sel.Clear(); _primary = -1; }
        Redraw();
        if (!notify) return;
        NodeSelectionChanged?.Invoke();
        if (hadSlab) SlabSelected?.Invoke(null);
        if (hadMembers && _selNodes.Count > 0) { SelectionChanged?.Invoke(); MemberSelected?.Invoke(-1); }
        ElementSelectionChanged?.Invoke();
    }

    /// <summary>Sélectionne les nœuds donnés sans toucher aux barres (utilisé après une barre dessinée à partir d'un nœud...).</summary>
    public void SelectNodesOnly(IEnumerable<int> ids) => SetNodeSelection(ids);

    // ------------------------------------------------------------------ désignation d'un nœud à l'écran
    private int NodeAt(Point p, double tol = 9)
    {
        if (Model == null) return -1;
        var info = GetInfo();
        int best = -1; double bd = tol;
        foreach (var n in Model.Nodes)
        {
            if (NodeHidden(n.Id, info)) continue;
            var q = S(n);
            double d = Math.Sqrt((q.X - p.X) * (q.X - p.X) + (q.Y - p.Y) * (q.Y - p.Y));
            if (d < bd) { bd = d; best = n.Id; }
        }
        return best;
    }

    private List<int> NodesInBox(Point a, Point b)
    {
        var r = new List<int>();
        if (Model == null) return r;
        double x0 = Math.Min(a.X, b.X), x1 = Math.Max(a.X, b.X), y0 = Math.Min(a.Y, b.Y), y1 = Math.Max(a.Y, b.Y);
        var info = GetInfo();
        foreach (var n in Model.Nodes)
        {
            if (NodeHidden(n.Id, info)) continue;
            var q = S(n);
            if (q.X >= x0 && q.X <= x1 && q.Y >= y0 && q.Y <= y1 && !r.Contains(n.Id)) r.Add(n.Id);
        }
        return r;
    }

    private string DescribeNode(int id)
    {
        if (Model == null) return "";
        var n = Model.Nodes.FirstOrDefault(x => x.Id == id);
        if (n == null) return "";
        string axes = GetInfo().AxisRef(n.X, n.Y);
        string sup = Model.Supports.Any(s => s.NodeId == id) ? "  ·  appui" : "";
        int nb = Model.Members.Count(m => m.NodeI == id || m.NodeJ == id);
        return $"Nœud {id}  ·  X = {n.X:0.###}  Y = {n.Y:0.###}  Z = {n.Z:0.###} m" + (axes != "" ? $"  ·  axes {axes}" : "") + sup + $"  ·  {nb} barre(s)" + ReactionHint(id) + "  ·  clic droit : menu";
    }

    /// <summary>Halo autour d'un nœud sélectionné ou survolé (appelé depuis le dessin des nœuds).</summary>
    private bool DrawNodeHalo(Point p, int id)
    {
        bool sel = _selNodes.Contains(id);
        if (!sel && id != _hoverNode) return false;
        if (sel)
        {
            // sélection : liseré sombre + cercle cyan (lisible sur fond clair comme sur fond sombre, distinct des erreurs rouges)
            var cas = new Ellipse { Width = 24, Height = 24, Stroke = SelCasingSoftBr, StrokeThickness = 5, IsHitTestVisible = false };
            Canvas.SetLeft(cas, p.X - 12); Canvas.SetTop(cas, p.Y - 12);
            _c.Children.Add(cas);
            var ring = new Ellipse { Width = 22, Height = 22, Stroke = SelLineBr, StrokeThickness = 2.6, Fill = SelFillBr, IsHitTestVisible = false };
            Canvas.SetLeft(ring, p.X - 11); Canvas.SetTop(ring, p.Y - 11);
            _c.Children.Add(ring);
            return true;
        }
        var col = Color.FromRgb(0xFF, 0xB3, 0x00);
        var el = new Ellipse
        {
            Width = 16, Height = 16,
            Stroke = new SolidColorBrush(col), StrokeThickness = 1.6,
            Fill = new SolidColorBrush(Color.FromArgb(45, col.R, col.G, col.B)), IsHitTestVisible = false
        };
        Canvas.SetLeft(el, p.X - el.Width / 2); Canvas.SetTop(el, p.Y - el.Height / 2);
        _c.Children.Add(el);
        return false;
    }

    /// <summary>Zoom sur les nœuds sélectionnés (ou le nœud donné).</summary>
    public void ZoomNodes(IEnumerable<int>? ids = null)
    {
        if (Model == null) return;
        var set = new HashSet<int>(ids ?? _selNodes);
        var pts = new List<Vec3>();
        const double r = 1.2;
        foreach (var n in Model.Nodes.Where(x => set.Contains(x.Id)))
            foreach (double dx in new[] { -r, r }) foreach (double dy in new[] { -r, r }) foreach (double dz in new[] { -r, r })
                pts.Add(new Vec3(n.X + dx, n.Y + dy, n.Z + dz));
        if (pts.Count == 0) { ZoomExtents(); return; }
        var (mn, mx) = BoundsOf(pts);
        _pivot = new Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, set.Count == 1 ? Math.Min(_c.ActualWidth, _c.ActualHeight) * 0.2 : 70);
    }

    // ------------------------------------------------------------------ clic droit
    private void HandleRightClick(Point pos)
    {
        if (Model == null) return;
        // commande en cours (point de départ posé, désignation, dalle...) : le clic droit l'annule, comme Échap
        if (Picking || _pendingNodeId != -1 || _slabA != null)
        {
            CancelPending();
            Hint?.Invoke("Commande annulée (clic droit). Clic droit sans commande en cours = menu contextuel.");
            return;
        }
        ViewTarget t;
        int nd = NodeAt(pos, 10);
        if (nd != -1)
        {
            if (!_selNodes.Contains(nd)) SetNodeSelection(new[] { nd });
            t = new ViewTarget { Kind = ViewTargetKind.Node, Id = nd, At = pos };
        }
        else if (PickObject(pos) is object ob)
        {
            SelectObject(ob);
            t = new ViewTarget { Kind = ob is ManualDim ? ViewTargetKind.Dim : ViewTargetKind.Load, Obj = ob, At = pos };
        }
        else
        {
            var ordered = CandidatesAt(pos);
            var first = ordered.Count > 0 ? ordered[0] : (ElementKey?)null;
            if (first == null) t = new ViewTarget { Kind = ViewTargetKind.None, At = pos };
            else
            {
                var key = first.Value;
                // un clic droit sur un élément déjà sélectionné garde toute la sélection (menu commun) ; sinon il devient la sélection
                if (!IsKeySelected(key)) SelectKeys(new[] { key }, 'n');
                if (SelectedCount > 1 && (_selKeys.Count > 0 || _selNodes.Count > 0)) t = new ViewTarget { Kind = ViewTargetKind.Selection, Key = key, At = pos };
                else if (key.Kind == ElementKind.Bar) t = new ViewTarget { Kind = ViewTargetKind.Member, Id = key.Id, At = pos };
                else if (key.Kind == ElementKind.Slab) t = new ViewTarget { Kind = ViewTargetKind.Slab, Slab = ObjectOf(key) as SlabPanel, At = pos };
                else if (key.Kind == ElementKind.Shell) t = new ViewTarget { Kind = ViewTargetKind.Shell, Shell = ObjectOf(key) as ShellPanel, At = pos };
                else t = new ViewTarget { Kind = ViewTargetKind.Element, Key = key, Obj = ObjectOf(key), At = pos };
            }
        }
        ContextRequested?.Invoke(t);
    }

    // ------------------------------------------------------------------ actions appelées par le menu
    /// <summary>Pose un nœud sous le point écran donné (accroché), comme l'outil Nœud. Retourne son numéro ou -1.</summary>
    public int AddNodeAtScreen(Point p)
    {
        if (Model == null) return -1;
        BeforeEdit?.Invoke();
        int id = GetOrCreateNode(p);
        ModelEdited?.Invoke();
        Redraw();
        return id;
    }

    /// <summary>Outil Barre actif avec ce nœud comme point de départ : le clic suivant pose l'autre extrémité.</summary>
    public void StartMemberFrom(int nodeId)
    {
        _pendingNodeId = nodeId;
        Redraw();
    }

    /// <summary>Supprime ces nœuds avec leurs barres, appuis et charges (l'appelant gère annuler/rétablir et l'affichage).</summary>
    public void DeleteNodes(IEnumerable<int> ids)
    {
        foreach (int n in ids.ToList()) DeleteNode(n);
        _selNodes.Clear(); PrimaryNode = -1;
    }

    /// <summary>Supprime une dalle dessinée (et ses charges surfaciques G/Q).</summary>
    public void RemoveSlab(SlabPanel s) => DeleteSlab(s);
}
