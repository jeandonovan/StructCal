using System.Windows;
using System.Windows.Controls;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Assistant de charges (façon Robot), gestionnaire de charges et commandes « Ferraillage 3D ».</summary>
public partial class MainWindow
{
    private LoadAssistantWindow? _loadWin;
    private LoadManagerWindow? _loadMgr;

    /// <summary>Applique une modification de charges sur le modèle courant avec annulation possible. Retourne le message de résultat.</summary>
    private string ApplyLoadEdit(Func<StructModel, string> action)
    {
        CommitGrids();
        string before;
        try { before = ModelIO.ToJson(_model); } catch { before = ""; }
        string msg;
        try { msg = action(_model); }
        catch (Exception ex) { return "Erreur : " + ex.Message; }
        string after = "";
        try { after = ModelIO.ToJson(_model); } catch { }
        if (before != after && before.Length > 0)
        {
            _undo.Add(before);
            if (_undo.Count > 80) _undo.RemoveAt(0);
            _redo.Clear();
            UpdateUndoUi();
            BindModel();
            OnModelEdited();
            StatusLeft.Text = msg + "  (Ctrl+Z pour annuler)";
        }
        return msg;
    }

    private void LoadAssistant_Click(object sender, RoutedEventArgs e)
    {
        if (_loadWin != null) { _loadWin.Activate(); return; }
        _loadWin = new LoadAssistantWindow(() => _model, Sel, ApplyLoadEdit, () => LoadManager_Click(this, new RoutedEventArgs())) { Owner = this };
        _loadWin.Closed += (s, a) => _loadWin = null;
        _loadWin.Show();
    }

    private void LoadManager_Click(object sender, RoutedEventArgs e)
    {
        if (_loadMgr != null) { _loadMgr.Activate(); return; }
        _loadMgr = new LoadManagerWindow(() => _model, ApplyLoadEdit, id => _vp.SetSelection(new[] { id })) { Owner = this };
        _loadMgr.Closed += (s, a) => _loadMgr = null;
        _loadMgr.Show();
    }

    private void GlobalResults_Click(object sender, RoutedEventArgs e)
    {
        if (_out == null) { MessageBox.Show("Lancez d'abord le calcul (F5).", "Résultats globaux", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        new ResultsWindow(_model, _out, _ => { }) { Owner = this }.Show();
    }

    // ------------------------------------------------------------------ ferraillage 3D
    private void Rebar3D_Click(object sender, RoutedEventArgs e)
    {
        if (_out == null)
        {
            if (MessageBox.Show("Le ferraillage 3D s'affiche après le calcul. Lancer le calcul maintenant ?", "Ferraillage 3D", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            Run_Click(sender, e);
            if (_out == null) return;
        }
        ComboStyle.SelectedIndex = (int)DisplayStyle.Ferraille;
        ViewIso_Click(sender, e);
        _vp.ZoomSelection();
        var st = _vp.RebarStats();
        StatusLeft.Text = string.IsNullOrEmpty(st) ? "Aucune armature à afficher (aucune barre béton armé calculée)." : st;
    }

    private void RebarOption_Changed(object sender, RoutedEventArgs e)
    {
        if (_vp == null || ChkStirrups == null || ChkRebarSel == null || ChkDeformed == null) return;
        _vp.ShowStirrups = ChkStirrups.IsChecked == true;
        _vp.RebarOnlySelection = ChkRebarSel.IsChecked == true;
        _vp.ShowDeformed = ChkDeformed.IsChecked == true;
        _vp.Redraw();
    }
}
