using System.IO;
using System.Windows;
using System.Windows.Media.Animation;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Écran d'accueil : bouton « Nouveau », démarrage du logiciel, application du choix de l'utilisateur (créer, ouvrir, importer).</summary>
public partial class MainWindow
{
    private readonly RecentProjects _recents = new(Path.Combine(DataDir, "recent.json"), RecentFile);

    /// <summary>Fichier > Fermer le projet : ferme le projet en cours (propose d'enregistrer) sans quitter le logiciel, puis rouvre l'accueil.</summary>
    private void CloseProject_Click(object sender, RoutedEventArgs e)
    {
        if (!ConfirmClose()) return;
        string name = _model.Name;
        _model = new StructModel(); _vp.ResetHidden(); BindModel();
        _filePath = null; _dirty = false;
        _undo.Clear(); _redo.Clear(); UpdateUndoUi();
        Log("Projet fermé : " + name);
        StatusLeft.Text = "Projet « " + name + " » fermé.";
        ShowWelcome();
    }

    /// <summary>Messages de la session sur des fichiers non ouverts (affichés dans la liste des messages actifs).</summary>
    private readonly List<AppMessage> _fileMsgs = new();

    /// <summary>Affiche l'accueil. Le choix est appliqué pendant que l'accueil s'estompe (fondu enchaîné) ; rien ne change si l'utilisateur ferme l'accueil sans choisir.</summary>
    private void ShowWelcome()
    {
        var host = new WelcomeHost
        {
            Recents = _recents,
            Report = s => { Log(s); StatusLeft.Text = s; },
            ReportError = ReportFileError,
            CurrentFile = () => _filePath,
            Apply = ApplyWelcome
        };
        var w = new WelcomeWindow(host) { Owner = this };
        w.ShowDialog();
        if (w.Result?.Kind == WelcomeKind.Options) Options_Click(this, Ev);
    }

    private void ApplyWelcome(WelcomeResult r)
    {
        switch (r.Kind)
        {
            case WelcomeKind.Opened when r.Model != null:
                ApplyLoaded(r.Path, r.Model);
                StatusLeft.Text = "Projet ouvert : " + r.Path + (r.Path.Contains("from_revit") ? "  (envoyé par Revit : ajoutez les charges, puis F5)" : "");
                break;
            case WelcomeKind.Created when r.Model != null:
                ApplyCreated(r);
                break;
            case WelcomeKind.Underlay:
                _model = new StructModel(); _vp.ResetHidden(); BindModel(); _filePath = null; _dirty = false;
                Log("Nouveau projet pour le fond de plan : " + Path.GetFileName(r.Path));
                _ = ImportUnderlayAsync(null, r.Path);
                break;
        }
    }

    /// <summary>Fichier non ouvert : ligne du journal, message d'erreur dans la liste des messages, texte dans la barre d'état. Le logiciel continue normalement.</summary>
    private void ReportFileError(string file, string reason)
    {
        string text = $"Fichier non ouvert « {file} » : {reason}";
        Log(text);
        StatusLeft.Text = text;
        string key = "FILE|" + file + "|" + reason;
        _fileMsgs.RemoveAll(m => m.Key == key);
        _fileMsgs.Add(new AppMessage
        {
            Key = key, Family = MsgFamily.Information, Source = MsgSource.Modele, Level = IssueLevel.Error,
            Category = "Ouverture de fichier", ElementKind = "Fichier", ElementLabel = file, Text = reason
        });
        RebuildMessages();
    }

    private void ApplyCreated(WelcomeResult r)
    {
        _model = r.Model!; _vp.ResetHidden(); BindModel();
        AddRecent(r.Path);
        OnModelEdited();
        _vp.ZoomExtents();
        if (r.Options?.StructuralSystem == "Acier") RbNewSteel.IsChecked = true;
        _filePath = r.Path; _dirty = false;
        Log("Projet créé : " + r.Path);
        StatusLeft.Text = $"Projet « {_model.Name} » créé et enregistré : {r.Path}";
    }

    /// <summary>Au démarrage : accueil si aucun fichier n'est demandé, que la préférence est active et que rien n'a été restauré.</summary>
    private void StartupWelcome()
    {
        if (!WelcomePrefs.ShowAtStartup) return;
        if (_filePath != null || _model.Members.Count > 0 || _model.Nodes.Count > 0) return;
        ShowWelcome();
    }
}
