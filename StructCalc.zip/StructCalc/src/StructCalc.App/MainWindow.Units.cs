using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Convertisseur d'unités pour les tableaux de saisie : le modèle reste en m / kN, l'utilisateur voit et saisit dans l'unité du projet.</summary>
public sealed class UnitConverter : IValueConverter
{
    private readonly string _kind;
    public UnitConverter(string kind) { _kind = kind; }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is double d)
        {
            double v = Math.Round(d * Units.FactorOf(_kind), 6);
            return v.ToString("0.######", CultureInfo.InvariantCulture);
        }
        return value ?? "";
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        string t = (value?.ToString() ?? "").Trim().Replace(',', '.');
        if (double.TryParse(t, NumberStyles.Float, CultureInfo.InvariantCulture, out double v))
        {
            double f = Units.FactorOf(_kind);
            return f == 0 ? v : v / f;
        }
        return DependencyProperty.UnsetValue;
    }
}

public sealed partial class MainWindow
{
    /// <summary>Grandeur affichée par une colonne de tableau (null = pas d'unité à convertir).</summary>
    private string? UnitKindOf(object grid, string prop)
    {
        bool members = ReferenceEquals(grid, GridMembers), slabs = ReferenceEquals(grid, GridSlabs), mloads = ReferenceEquals(grid, GridMemberLoads);
        return prop switch
        {
            "X" or "Y" or "Z" => "len",
            "Lx" or "Ly" when slabs => "len",
            "B" or "H" when members || slabs => "sec",
            "Cover" when members => "sec",
            "A" or "B" when mloads => "len",
            "Fx" or "Fy" or "Fz" => "force",
            "Mx" or "My" or "Mz" => "moment",
            "Wx" or "Wy" or "Wz" => "lin",
            "GExtra" or "Q" when slabs => "surf",
            _ => null,
        };
    }

    private void ApplyUnitToColumn(object grid, DataGridAutoGeneratingColumnEventArgs e)
    {
        string? kind = UnitKindOf(grid, e.PropertyName);
        if (kind == null) return;
        if (e.Column is DataGridTextColumn tc && tc.Binding is Binding bd)
        {
            tc.Binding = new Binding(bd.Path.Path)
            {
                Mode = bd.Mode == BindingMode.Default ? BindingMode.TwoWay : bd.Mode,
                UpdateSourceTrigger = bd.UpdateSourceTrigger,
                Converter = new UnitConverter(kind),
            };
            string baseName = e.Column.Header?.ToString() ?? e.PropertyName;
            baseName = Regex.Replace(baseName, @"\s*\(.*\)\s*$", "");
            e.Column.Header = $"{baseName} ({Units.LabelOf(kind)})";
        }
    }

    private void UpdateUnitHeaders()
    {
        if (GridResults.Columns.Count < 8) return;
        GridResults.Columns[2].Header = $"Section ({Units.Section})";
        GridResults.Columns[3].Header = $"L ({Units.Length})";
        GridResults.Columns[4].Header = $"Mu trav. / M max ({Units.MomentUnit})";
        GridResults.Columns[5].Header = $"Mu appui ({Units.MomentUnit})";
        GridResults.Columns[6].Header = $"Vu ({Units.Force})";
        GridResults.Columns[7].Header = $"Nu ({Units.Force})";
    }

    /// <summary>Texte de section d'une barre dans l'unité de section du projet (« 30x50 » ou nom du profil).</summary>
    private static string SecText(MemberDesignResult r) =>
        r.Kind == MaterialKind.Steel ? r.Profile : $"{Units.SecS(r.B)}x{Units.SecS(r.H)}";

    /// <summary>Réaffiche tous les tableaux, résultats et dessins dans les unités courantes.</summary>
    private void RefreshUnits()
    {
        foreach (var g in new[] { GridNodes, GridMembers, GridSupports, GridNodalLoads, GridMemberLoads, GridSlabs })
        {
            var src = g.ItemsSource;
            g.ItemsSource = null;
            g.ItemsSource = src;
        }
        UpdateUnitHeaders();
        FillResults();
        if (_vp.SelectedId >= 0) ShowMember(_vp.SelectedId);
        _vp.Redraw();
        StatusLeft.Text = "Unités du projet : " + Units.Describe() + ".";
    }

    private void Units_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new UnitsWindow { Owner = this };
        if (dlg.ShowDialog() != true) return;
        PushUndo();
        Units.Set(dlg.LengthUnit, dlg.SectionUnit, dlg.ForceUnit, dlg.StressUnit);
        Units.Store(_model.Settings);
        RefreshUnits();
    }
}

/// <summary>Fenêtre de choix des unités du projet.</summary>
public sealed class UnitsWindow : Window
{
    private readonly ComboBox _cl = new(), _cs = new(), _cf = new(), _cc = new(), _cp = new();
    public string LengthUnit => _cl.SelectedItem as string ?? "m";
    public string SectionUnit => _cs.SelectedItem as string ?? "cm";
    public string ForceUnit => _cf.SelectedItem as string ?? "kN";
    public string StressUnit => _cc.SelectedItem as string ?? "MPa";

    public UnitsWindow()
    {
        Title = "Unités du projet";
        Width = 520; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var sp = new StackPanel { Margin = new Thickness(16) };
        sp.Children.Add(new TextBlock
        {
            Text = "Choisissez les unités d'affichage et de saisie. Elles s'appliquent à tout le projet : tableaux, résultats, fiche des éléments, plans d'exécution et nomenclatures. Le calcul reste identique (conversion automatique).",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 12)
        });
        Row(sp, "Jeu prédéfini", _cp);
        _cp.ItemsSource = Units.Presets.Select(p => p.Name).ToList();
        _cp.SelectionChanged += (s, e) =>
        {
            if (_cp.SelectedIndex < 0) return;
            var p = Units.Presets[_cp.SelectedIndex];
            _cl.SelectedItem = p.L; _cs.SelectedItem = p.S; _cf.SelectedItem = p.F; _cc.SelectedItem = p.C;
        };
        Row(sp, "Longueurs (portées, coordonnées, barres)", _cl); _cl.ItemsSource = Units.Lengths; _cl.SelectedItem = Units.Length;
        Row(sp, "Sections (dimensions, espacements, enrobages)", _cs); _cs.ItemsSource = Units.Sections; _cs.SelectedItem = Units.Section;
        Row(sp, "Forces", _cf); _cf.ItemsSource = Units.Forces; _cf.SelectedItem = Units.Force;
        Row(sp, "Contraintes", _cc); _cc.ItemsSource = Units.Stresses; _cc.SelectedItem = Units.Stress;
        sp.Children.Add(new TextBlock
        {
            Text = "Moment = force x longueur ; charge répartie = force / longueur ; charge surfacique = force / longueur².\nLes assistants (escaliers, planchers, sol, voiles) gardent leurs unités habituelles (m, cm, kN).",
            TextWrapping = TextWrapping.Wrap, Foreground = System.Windows.Media.Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 10, 0, 0)
        });
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        var ok = new Button { Content = "Appliquer", Padding = new Thickness(18, 5, 18, 5), Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        ok.Click += (s, e) => DialogResult = true;
        var cancel = new Button { Content = "Annuler", Padding = new Thickness(18, 5, 18, 5), IsCancel = true };
        bar.Children.Add(ok); bar.Children.Add(cancel);
        sp.Children.Add(bar);
        Content = sp;
    }

    private static void Row(StackPanel sp, string label, ComboBox cb)
    {
        var g = new Grid { Margin = new Thickness(0, 3, 0, 3) };
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(250) });
        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.Children.Add(new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center });
        Grid.SetColumn(cb, 1);
        g.Children.Add(cb);
        sp.Children.Add(g);
    }
}
