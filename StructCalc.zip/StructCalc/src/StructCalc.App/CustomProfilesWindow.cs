using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using StructCalc.Core;
using StructCalc.Core.Steel;

namespace StructCalc.UI;

public sealed class CustomProfileRow
{
    public string Name { get; set; } = "PERSO1";
    public double H { get; set; } = 300;
    public double B { get; set; } = 150;
    public double Tw { get; set; } = 7;
    public double Tf { get; set; } = 10;
    public double R { get; set; } = 12;
}

/// <summary>Profilés en I / H personnalisés (dimensions en mm) : ils rejoignent le catalogue (famille PERSO) et se choisissent comme n'importe quel profilé.</summary>
public static class CustomProfiles
{
    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppInfo.Name, "profils_perso.csv");

    public static List<CustomProfileRow> Load()
    {
        var res = new List<CustomProfileRow>();
        try
        {
            if (!File.Exists(FilePath)) return res;
            foreach (var line in File.ReadAllLines(FilePath).Skip(1))
            {
                var p = line.Split(';');
                if (p.Length < 6) continue;
                double D(int i) => double.Parse(p[i].Replace(',', '.'), CultureInfo.InvariantCulture);
                res.Add(new CustomProfileRow { Name = p[0].Trim(), H = D(1), B = D(2), Tw = D(3), Tf = D(4), R = D(5) });
            }
        }
        catch { }
        return res;
    }

    public static void Save(IEnumerable<CustomProfileRow> rows)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            var inv = CultureInfo.InvariantCulture;
            var lines = new List<string> { "Nom;h;b;tw;tf;r" };
            lines.AddRange(rows.Select(r => string.Join(";", r.Name, r.H.ToString(inv), r.B.ToString(inv), r.Tw.ToString(inv), r.Tf.ToString(inv), r.R.ToString(inv))));
            File.WriteAllLines(FilePath, lines);
        }
        catch { }
    }

    /// <summary>Charge les profilés enregistrés dans le catalogue de calcul.</summary>
    public static void Apply(IEnumerable<CustomProfileRow> rows)
    {
        var list = new List<SteelProfile>();
        foreach (var r in rows)
        {
            if (string.IsNullOrWhiteSpace(r.Name) || r.H <= 0 || r.B <= 0 || r.Tw <= 0 || r.Tf <= 0) continue;
            if (2 * r.Tf >= r.H) continue;
            list.Add(new SteelProfile(r.Name.Trim().ToUpperInvariant().Replace(" ", ""), "PERSO", r.H, r.B, r.Tw, r.Tf, Math.Max(0, r.R)));
        }
        SteelCatalog.SetCustom(list);
    }
}

public sealed class CustomProfilesWindow : Window
{
    private readonly ObservableCollection<CustomProfileRow> _rows;
    private readonly DataGrid _grid = new() { AutoGenerateColumns = false, CanUserAddRows = false, Margin = new Thickness(8) };

    public CustomProfilesWindow(Window owner)
    {
        Owner = owner;
        Title = "Mes profilés acier personnalisés";
        Width = 640; Height = 440; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        _rows = new ObservableCollection<CustomProfileRow>(CustomProfiles.Load());
        _grid.Columns.Add(new DataGridTextColumn { Header = "Nom", Binding = new Binding("Name"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        foreach (var (h, p) in new[] { ("h (mm)", "H"), ("b (mm)", "B"), ("tw (mm)", "Tw"), ("tf (mm)", "Tf"), ("r (mm)", "R") })
            _grid.Columns.Add(new DataGridTextColumn { Header = h, Binding = new Binding(p) { Mode = BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.LostFocus }, Width = 70 });
        _grid.ItemsSource = _rows;

        var top = new TextBlock
        {
            Text = "Profilé en I ou en H défini par ses dimensions : hauteur h, largeur b, épaisseur d'âme tw, de semelle tf, rayon de congé r. " +
                   "Les caractéristiques (aire, inertie, modules) sont calculées à partir de ces dimensions. Le nom s'utilise ensuite comme n'importe quel profilé.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(10, 8, 10, 0), Foreground = System.Windows.Media.Brushes.Gray
        };
        var bar = new WrapPanel { Margin = new Thickness(8) };
        bar.Children.Add(B("Ajouter", (s, e) => _rows.Add(new CustomProfileRow { Name = "PERSO" + (_rows.Count + 1) })));
        bar.Children.Add(B("Supprimer la ligne", (s, e) => { if (_grid.SelectedItem is CustomProfileRow r) _rows.Remove(r); }));
        var ok = B("Enregistrer", (s, e) => { _grid.CommitEdit(DataGridEditingUnit.Row, true); CustomProfiles.Save(_rows); CustomProfiles.Apply(_rows); DialogResult = true; });
        ok.IsDefault = true;
        var cancel = B("Annuler", (s, e) => DialogResult = false); cancel.IsCancel = true;
        bar.Children.Add(ok); bar.Children.Add(cancel);
        var root = new DockPanel();
        DockPanel.SetDock(top, Dock.Top); DockPanel.SetDock(bar, Dock.Bottom);
        root.Children.Add(top); root.Children.Add(bar); root.Children.Add(_grid);
        Content = root;
    }

    private static Button B(string t, RoutedEventHandler h)
    {
        var b = new Button { Content = t, Padding = new Thickness(12, 3, 12, 3), Margin = new Thickness(0, 0, 6, 0) };
        b.Click += h;
        return b;
    }
}
