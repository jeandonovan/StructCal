using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Options de cotation affichées dans les vues.</summary>
public sealed class DimOptions
{
    public bool Show = true;
    public bool Chain = true;          // entraxes consécutifs
    public bool Cumul = false;         // cotes cumulées depuis le premier axe
    public bool Overall = true;        // cote totale
    public bool Levels = true;         // hauteurs d'étage et cotes de niveau (élévation, côté)
    public bool Members = false;       // longueur de chaque barre
    public bool Slabs = false;         // dimensions des dalles (plan)
    public bool Nodes = false;         // coordonnées des nœuds
    public bool ShowManual = true;     // cotes manuelles (outil Cote)
    public bool ShowAuto = true;       // cotes automatiques (entraxes, hauteurs, hors-tout) ; faux = seules les cotes manuelles restent
    public bool Auto3D = true;         // cotation automatique en 3D (entraxes, hauteurs d'étage, hors-tout)
    public int Decimals = 2;
    public string Unit = "m";          // m, cm ou mm
    public double Font = 10;
}

/// <summary>Cotation : chaînes d'entraxes, cotes cumulées et totale, hauteurs d'étage, longueurs de barres, dimensions de dalles, coordonnées des nœuds, cotes manuelles.</summary>
public sealed partial class ModelViewport
{
    public DimOptions Dims { get; } = new();
    private Vec3? _dimA;

    private string FmtDim(double meters)
    {
        double k = Dims.Unit == "mm" ? 1000 : Dims.Unit == "cm" ? 100 : 1;
        return (meters * k).ToString("F" + Math.Clamp(Dims.Decimals, 0, 4), System.Globalization.CultureInfo.GetCultureInfo("fr-FR"));
    }

    private Point PP(double u, double v) => Mode switch
    {
        ViewMode.Plan => S(u, v, WorkOffset),
        ViewMode.Side => S(WorkOffset, u, v),
        _ => S(u, WorkOffset, v)
    };

    private Vec3 PlaneTo3D(double u, double v) => Mode switch
    {
        ViewMode.Plan => new Vec3(u, v, WorkOffset),
        ViewMode.Side => new Vec3(WorkOffset, u, v),
        _ => new Vec3(u, WorkOffset, v)
    };

    private static List<double> Uniq(IEnumerable<double> values)
    {
        var r = new List<double>();
        foreach (var x in values.OrderBy(q => q)) if (r.Count == 0 || x - r[^1] > 1e-3) r.Add(x);
        return r;
    }

    private static Vector Unit2(Vector v) { double l = v.Length; return l < 1e-9 ? new Vector(0, 0) : new Vector(v.X / l, v.Y / l); }

    /// <summary>Ligne de cote : lignes de rappel, ligne de cote avec traits obliques, texte parallèle à la ligne.</summary>
    private void DimLine(Point a, Point b, string text, Vector off, bool small = false)
    {
        var dir = Unit2(b - a);
        if ((b - a).Length < 4) return;
        var a2 = a + off; var b2 = b + off;
        var o = Unit2(off);
        var pen = Br("#546E7A");
        double ext = small ? 0 : 4;
        Ln(a.X + o.X * ext, a.Y + o.Y * ext, a2.X + o.X * 5, a2.Y + o.Y * 5, Br("#90A4AE"), 0.8);
        Ln(b.X + o.X * ext, b.Y + o.Y * ext, b2.X + o.X * 5, b2.Y + o.Y * 5, Br("#90A4AE"), 0.8);
        Ln(a2.X, a2.Y, b2.X, b2.Y, pen, 1.1);
        var t = new Vector((dir.X - dir.Y) / Math.Sqrt(2) * 5, (dir.Y + dir.X) / Math.Sqrt(2) * 5);
        Ln(a2.X - t.X, a2.Y - t.Y, a2.X + t.X, a2.Y + t.Y, pen, 1.6);
        Ln(b2.X - t.X, b2.Y - t.Y, b2.X + t.X, b2.Y + t.Y, pen, 1.6);
        if ((b - a).Length < 22 || string.IsNullOrEmpty(text)) return;
        var mid = new Point((a2.X + b2.X) / 2, (a2.Y + b2.Y) / 2);
        double ang = Math.Atan2(dir.Y, dir.X) * 180 / Math.PI;
        if (ang > 90) ang -= 180; else if (ang < -90) ang += 180;
        var tb = new TextBlock { Text = text, FontSize = Dims.Font, Foreground = Br("#263238"), Background = Br("#B3FFFFFF"), Padding = new Thickness(2, 0, 2, 0), RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = new RotateTransform(ang), IsHitTestVisible = false };
        tb.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        var c = new Point(mid.X - o.X * (Dims.Font * 0.9 + 2), mid.Y - o.Y * (Dims.Font * 0.9 + 2));
        Canvas.SetLeft(tb, c.X - tb.DesiredSize.Width / 2); Canvas.SetTop(tb, c.Y - tb.DesiredSize.Height / 2);
        _c.Children.Add(tb);
    }

    private void HChain(List<double> us, double vEdge, double dir)
    {
        if (us.Count < 2) return;
        var pts = us.Select(u => PP(u, vEdge)).ToList();
        int row = 0;
        if (Dims.Chain) { for (int i = 0; i < us.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(us[i + 1] - us[i]), new Vector(0, dir * (30 + 24 * row))); row++; }
        if (Dims.Cumul) { for (int i = 0; i < us.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(us[i + 1] - us[0]), new Vector(0, dir * (30 + 24 * row))); row++; }
        if (Dims.Overall && us.Count > 2 || (Dims.Overall && !Dims.Chain && !Dims.Cumul)) DimLine(pts[0], pts[^1], FmtDim(us[^1] - us[0]), new Vector(0, dir * (30 + 24 * row)));
    }

    private void VChain(List<double> vs, double uEdge, double dir)
    {
        if (vs.Count < 2) return;
        var pts = vs.Select(v => PP(uEdge, v)).ToList();
        int row = 0;
        if (Dims.Chain || Dims.Levels) { for (int i = 0; i < vs.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(vs[i + 1] - vs[i]), new Vector(dir * (30 + 24 * row), 0)); row++; }
        if (Dims.Cumul) { for (int i = 0; i < vs.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(vs[i + 1] - vs[0]), new Vector(dir * (30 + 24 * row), 0)); row++; }
        if (Dims.Overall && vs.Count > 2 || (Dims.Overall && !Dims.Chain && !Dims.Cumul)) DimLine(pts[0], pts[^1], FmtDim(vs[^1] - vs[0]), new Vector(dir * (30 + 24 * row), 0));
    }

    private void DrawDims(Dictionary<int, Node> nodes, StructureInfo info)
    {
        if (Model == null) return;
        if (Dims.Show && Dims.ShowManual) DrawManualDims();
        if (!Dims.Show || !Dims.ShowAuto || nodes.Count == 0) return;
        if (Mode == ViewMode.Iso)
        {
            if (Dims.Auto3D) DrawDims3D(nodes, info);
            DimExtras(nodes, info);
            Text($"cotes en {Dims.Unit}", 10, (_c.ActualHeight > 40 ? _c.ActualHeight : 600) - 22, 10, Gray);
            return;
        }

        List<double> us, vs;
        if (Mode == ViewMode.Plan)
        {
            us = Uniq(info.XAxes.Count > 0 ? info.XAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.X));
            vs = Uniq(info.YAxes.Count > 0 ? info.YAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.Y));
        }
        else
        {
            var hs = Mode == ViewMode.Side ? (info.YAxes.Count > 0 ? info.YAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.Y)) : (info.XAxes.Count > 0 ? info.XAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.X));
            us = Uniq(hs);
            vs = Uniq(info.Levels.Count > 0 ? info.Levels.Select(l => l.Z) : nodes.Values.Select(n => n.Z));
        }
        if (us.Count == 0 || vs.Count == 0) return;

        // côté « bas » et côté « gauche » de la vue
        double vBot = PP(us[0], vs[0]).Y >= PP(us[0], vs[^1]).Y ? vs[0] : vs[^1];
        double uLeft = PP(us[0], vs[0]).X <= PP(us[^1], vs[0]).X ? us[0] : us[^1];
        if (Dims.Chain || Dims.Cumul || Dims.Overall) HChain(us.ToList(), vBot, 1);
        bool vertical = Mode != ViewMode.Plan;
        if (vertical ? Dims.Levels : (Dims.Chain || Dims.Cumul || Dims.Overall)) VChain(vs, uLeft, -1);

        // cotes de niveau (élévation, côté)
        if (vertical && Dims.Levels)
        {
            double uRight = uLeft == us[0] ? us[^1] : us[0];
            foreach (var l in info.Levels)
            {
                var p = PP(uRight, l.Z);
                var tri = new System.Windows.Shapes.Polygon { Points = new PointCollection { new Point(p.X + 14, p.Y), new Point(p.X + 22, p.Y - 7), new Point(p.X + 6, p.Y - 7) }, Fill = Br("#455A64"), IsHitTestVisible = false };
                _c.Children.Add(tri);
                Ln(p.X + 2, p.Y, p.X + 70, p.Y, Br("#78909C"), 0.9);
                Text($"{(l.Z >= 0 ? "+" : "-")}{FmtDim(Math.Abs(l.Z))}  {l.Name}", p.X + 26, p.Y - 17, Dims.Font, Br("#263238"));
            }
        }

        DimExtras(nodes, info);
        Text($"cotes en {Dims.Unit}", 10, (_c.ActualHeight > 40 ? _c.ActualHeight : 600) - 22, 10, Gray);
    }

    /// <summary>Dimensions des dalles, longueur des barres et coordonnées des nœuds (toutes vues, 3D comprise).</summary>
    private void DimExtras(Dictionary<int, Node> nodes, StructureInfo info)
    {
        if (Model == null) return;
        if (Dims.Slabs)
            foreach (var s in Model.Slabs.Where(q => q.Placed && !IsObjHidden(q) && (Mode != ViewMode.Plan || Math.Abs(q.Z - WorkOffset) < 0.05)))
            {
                if (Mode != ViewMode.Plan && Mode != ViewMode.Iso) continue;
                var c = S(s.X0 + s.Lx / 2, s.Y0 + s.Ly / 2, s.Z);
                var b0 = S(s.X0, s.Y0, s.Z); var b1 = S(s.X0 + s.Lx, s.Y0, s.Z); var l0 = S(s.X0, s.Y0, s.Z); var l1 = S(s.X0, s.Y0 + s.Ly, s.Z);
                DimLine(b0, b1, FmtDim(s.Lx), Unit2(new Vector(c.X - (b0.X + b1.X) / 2, c.Y - (b0.Y + b1.Y) / 2)) * 16, true);
                DimLine(l0, l1, FmtDim(s.Ly), Unit2(new Vector(c.X - (l0.X + l1.X) / 2, c.Y - (l0.Y + l1.Y) / 2)) * 16, true);
            }

        if (Dims.Members)
            foreach (var mem in Model.Members)
            {
                if (MemberHidden(mem.Id, info)) continue;
                if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                double len = Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y) + (a.Z - b.Z) * (a.Z - b.Z));
                var pa = S(a); var pb = S(b);
                if ((pb - pa).Length < 30) continue;
                Text(FmtDim(len), (pa.X + pb.X) / 2 + 4, (pa.Y + pb.Y) / 2 - 14, Dims.Font - 1, Br("#00695C"), Br("#CCFFFFFF"));
            }

        if (Dims.Nodes)
            foreach (var n in nodes.Values)
            {
                if (NodeHidden(n.Id, info)) continue;
                var p = S(n);
                Text($"({FmtDim(n.X)} ; {FmtDim(n.Y)} ; {FmtDim(n.Z)})", p.X + 6, p.Y + 6, Dims.Font - 2, Br("#6A1B9A"), Br("#CCFFFFFF"));
            }
    }

    /// <summary>Chaîne de cotes le long d'une arête de l'emprise en 3D : entraxes, cumul, hors-tout ; la ligne est décalée vers l'extérieur du modèle.</summary>
    private void Chain3D(List<double> vals, Func<double, Point> pt, Point center, bool levels)
    {
        if (vals.Count < 2) return;
        var pts = vals.Select(pt).ToList();
        var dir = Unit2(pts[^1] - pts[0]);
        if (dir.Length < 0.5) return;
        var perp = new Vector(-dir.Y, dir.X);
        var mid = new Point((pts[0].X + pts[^1].X) / 2, (pts[0].Y + pts[^1].Y) / 2);
        if (Vector.Multiply(perp, mid - center) < 0) perp = -perp;
        int row = 0;
        bool chain = levels ? Dims.Levels : Dims.Chain;
        if (chain) { for (int i = 0; i < vals.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(vals[i + 1] - vals[i]), perp * (30 + 24 * row)); row++; }
        if (Dims.Cumul) { for (int i = 0; i < vals.Count - 1; i++) DimLine(pts[i], pts[i + 1], FmtDim(vals[i + 1] - vals[0]), perp * (30 + 24 * row)); row++; }
        if (Dims.Overall && (vals.Count > 2 || (!chain && !Dims.Cumul))) DimLine(pts[0], pts[^1], FmtDim(vals[^1] - vals[0]), perp * (30 + 24 * row));
    }

    /// <summary>Cotation automatique en 3D : entraxes en X et en Y sur les arêtes basses de l'emprise, hauteurs d'étage sur l'arête verticale la plus à gauche.</summary>
    private void DrawDims3D(Dictionary<int, Node> nodes, StructureInfo info)
    {
        var xs = Uniq(info.XAxes.Count > 0 ? info.XAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.X));
        var ys = Uniq(info.YAxes.Count > 0 ? info.YAxes.Select(a => a.Pos) : nodes.Values.Select(n => n.Y));
        var zs = Uniq(info.Levels.Count > 0 ? info.Levels.Select(l => l.Z) : nodes.Values.Select(n => n.Z));
        if (xs.Count == 0 || ys.Count == 0 || zs.Count == 0) return;
        double xm = (xs[0] + xs[^1]) / 2, ym = (ys[0] + ys[^1]) / 2, zm = (zs[0] + zs[^1]) / 2, z0 = zs[0];
        var center = S(xm, ym, zm);
        double yE = S(xm, ys[0], z0).Y >= S(xm, ys[^1], z0).Y ? ys[0] : ys[^1];       // arête la plus basse à l'écran
        double xE = S(xs[0], ym, z0).Y >= S(xs[^1], ym, z0).Y ? xs[0] : xs[^1];
        Chain3D(xs, x => S(x, yE, z0), center, false);
        Chain3D(ys, y => S(xE, y, z0), center, false);
        if (zs.Count >= 2)
        {
            double xz = xs[0], yz = ys[0], best = double.MaxValue;                       // coin le plus à gauche à l'écran
            foreach (double cx in new[] { xs[0], xs[^1] })
                foreach (double cy in new[] { ys[0], ys[^1] })
                {
                    double sx = S(cx, cy, z0).X;
                    if (sx < best) { best = sx; xz = cx; yz = cy; }
                }
            Chain3D(zs, z => S(xz, yz, z), center, true);
        }
    }

    // ------------------------------------------------------------------ cotes manuelles
    private void DrawManualDims()
    {
        if (Model == null) return;
        foreach (var d in Model.ManualDims)
        {
            var a = S(d.X1, d.Y1, d.Z1); var b = S(d.X2, d.Y2, d.Z2);
            var dir = Unit2(b - a);
            var n = new Vector(-dir.Y, dir.X);
            if (n.Y > 0) n = -n;
            double len = Math.Sqrt(Math.Pow(d.X2 - d.X1, 2) + Math.Pow(d.Y2 - d.Y1, 2) + Math.Pow(d.Z2 - d.Z1, 2));
            DimLine(a, b, FmtDim(len), n * d.OffsetPx);
            var off = n * d.OffsetPx;
            AddHit(d, a + off, b + off);
            AddHit(d, a, a + off); AddHit(d, b, b + off);
        }
    }

    private void DrawDimRubber()
    {
        if (Tool != EditTool.Dim || _dimA == null || !_cursorValid) return;
        if (!SnapWorld(_cursor, out var w)) return;
        var a = S(_dimA.Value.X, _dimA.Value.Y, _dimA.Value.Z); var b = S(w.X, w.Y, w.Z);
        _c.Children.Add(new System.Windows.Shapes.Line { X1 = a.X, Y1 = a.Y, X2 = b.X, Y2 = b.Y, Stroke = Br("#E65100"), StrokeThickness = 1.5, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false });
        double len = Math.Sqrt(Math.Pow(w.X - _dimA.Value.X, 2) + Math.Pow(w.Y - _dimA.Value.Y, 2) + Math.Pow(w.Z - _dimA.Value.Z, 2));
        Text(FmtDim(len) + " " + Dims.Unit, (a.X + b.X) / 2 + 6, (a.Y + b.Y) / 2 - 16, 11, Br("#E65100"), Br("#CCFFFFFF"), true);
    }

    /// <summary>Point de l'espace sous le curseur (accrochages actifs), dans n'importe quelle vue.</summary>
    private bool SnapWorld(Point p, out Vec3 w)
    {
        w = default;
        var hit = ComputeSnap(p);
        if (hit == null) return false;
        if (hit.World is Vec3 hw) { w = hw; return true; }
        if (Mode == ViewMode.Iso) return false;
        if (hit.NodeId != -1 && Model != null)
        {
            var n = Model.Nodes.FirstOrDefault(q => q.Id == hit.NodeId);
            if (n != null) { w = new Vec3(n.X, n.Y, n.Z); return true; }
        }
        w = PlaneTo3D(hit.U, hit.V);
        return true;
    }

    private void HandleDimClick(Point p)
    {
        if (Model == null) return;
        if (!SnapWorld(p, out var w)) return;
        if (_dimA == null) { _dimA = w; Hint?.Invoke("Cote : cliquez le deuxième point (Échap pour annuler)."); Redraw(); return; }
        var a = _dimA.Value; _dimA = null;
        if (Math.Abs(a.X - w.X) + Math.Abs(a.Y - w.Y) + Math.Abs(a.Z - w.Z) < 1e-4) { Redraw(); return; }
        BeforeEdit?.Invoke();
        Model.ManualDims.Add(new ManualDim { X1 = a.X, Y1 = a.Y, Z1 = a.Z, X2 = w.X, Y2 = w.Y, Z2 = w.Z, OffsetPx = 32 });
        Redraw();
    }

    public void ClearManualDims()
    {
        if (Model == null || Model.ManualDims.Count == 0) return;
        BeforeEdit?.Invoke();
        Model.ManualDims.Clear();
        Redraw();
    }
}
