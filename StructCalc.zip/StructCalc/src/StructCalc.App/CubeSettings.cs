using System.IO;

namespace StructCalc.UI;

/// <summary>Réglages du cube de navigation (mémorisés d'une session à l'autre dans %APPDATA%\StructCalc\viewcube.txt).</summary>
public static class CubeSettings
{
    public static double Opacity = 0.92;        // opacité des faces (0,10 à 1)
    public static double TextOpacity = 1.0;     // opacité des textes
    public static double Size = 1.0;            // échelle (0,6 à 2)
    public static bool ShowText = true;
    public static int Corner = 1;               // 0 haut-gauche, 1 haut-droite, 2 bas-gauche, 3 bas-droite

    private static string FilePath => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "viewcube.txt");

    static CubeSettings() { Load(); }

    public static void Reset() { Opacity = 0.92; TextOpacity = 1.0; Size = 1.0; ShowText = true; Corner = 1; Save(); }

    public static void Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return;
            foreach (var line in File.ReadAllLines(FilePath))
            {
                var kv = line.Split('=');
                if (kv.Length != 2) continue;
                var v = kv[1].Trim();
                double D() => double.Parse(v, System.Globalization.CultureInfo.InvariantCulture);
                switch (kv[0].Trim())
                {
                    case "opacity": Opacity = Math.Clamp(D(), 0.1, 1); break;
                    case "textopacity": TextOpacity = Math.Clamp(D(), 0, 1); break;
                    case "size": Size = Math.Clamp(D(), 0.6, 2); break;
                    case "showtext": ShowText = v == "1"; break;
                    case "corner": Corner = Math.Clamp((int)D(), 0, 3); break;
                }
            }
        }
        catch { /* valeurs par défaut */ }
    }

    public static void Save()
    {
        try
        {
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(FilePath)!);
            var ci = System.Globalization.CultureInfo.InvariantCulture;
            File.WriteAllLines(FilePath, new[]
            {
                $"opacity={Opacity.ToString(ci)}", $"textopacity={TextOpacity.ToString(ci)}", $"size={Size.ToString(ci)}",
                $"showtext={(ShowText ? 1 : 0)}", $"corner={Corner}",
            });
        }
        catch { }
    }
}
