using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace StructCalc.UI;

internal sealed class PaneState
{
    public string Side { get; set; } = "Left";
    public int Order { get; set; }
    public bool Visible { get; set; } = true;
}

internal sealed class DockState
{
    public double Scale { get; set; } = 1.0;
    public Dictionary<string, PaneState> Panes { get; set; } = new();
    public Dictionary<string, double> Sizes { get; set; } = new();
}

/// <summary>Interface ancrable façon Twinmotion / Visual Studio : barres d'outils (rubans) et panneaux déplaçables par glisser-déposer
/// vers les 4 côtés de la fenêtre, tailles ajustables, affichage/masquage, mémorisation de la disposition, échelle de l'interface 60 à 150 %.</summary>
public partial class MainWindow
{
    private enum DockSide { Left, Right, Top, Bottom }

    private sealed class DockPane
    {
        public string Id = "", Title = "";
        public FrameworkElement Element = null!;
        public Panel? Inner;
        public bool IsStrip;
        public DockSide Side, DefSide;
        public int Order, DefOrder;
        public bool Visible = true;
        public Border? Root;
    }

    private static readonly double[] UiScales = { 0.75, 0.85, 0.95, 1.00, 1.25, 1.50 };
    private readonly List<DockPane> _panes = new();
    private readonly Grid _dockGrid = new();
    private readonly Canvas _dockOverlay = new() { IsHitTestVisible = false };
    private readonly Dictionary<DockSide, double> _regionSize = new() { [DockSide.Left] = 310, [DockSide.Right] = 340, [DockSide.Top] = 180, [DockSide.Bottom] = 300 };
    private ColumnDefinition? _cdLeft, _cdRight;
    private RowDefinition? _rdTop, _rdBottom;
    private double _uiScale = 1.0;
    private bool _scaleBusy, _dockReady;
    private DockPane? _dragPane;
    private Point _dragStart;
    private bool _dragActive;
    private (DockSide Side, int Index)? _dropTarget;
    private Rectangle? _dropRect;
    private TextBlock? _dropLabel;

    private static string DockFile => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "layout.json");

    private void InitDock()
    {
        // 1. détacher les éléments de l'ancienne disposition fixe
        RootDock.Children.Remove(MainToolbar);
        RootDock.Children.Remove(MainGrid);
        MainGrid.Children.Clear();
        CenterGrid.Children.Clear();
        foreach (FrameworkElement e in new FrameworkElement[] { MainToolbar, CenterBorder, LeftTabs, RightPanel, BottomTabs })
        {
            e.ClearValue(Grid.RowProperty); e.ClearValue(Grid.ColumnProperty); e.ClearValue(DockPanel.DockProperty);
        }

        // 2. panneaux et rubans
        void Add(string id, string title, FrameworkElement el, Panel? inner, bool strip, DockSide side, int order) =>
            _panes.Add(new DockPane { Id = id, Title = title, Element = el, Inner = inner, IsStrip = strip, Side = side, DefSide = side, Order = order, DefOrder = order });
        Add("main", "Ruban (fichier, dessin, vues, résultats...)", MainToolbar, MainToolbarPanel, true, DockSide.Top, 0);
        Add("left", "Projet / Structure", LeftTabs, null, false, DockSide.Left, 0);
        Add("right", "Propriétés de l'élément", RightPanel, null, false, DockSide.Right, 0);
        Add("bottom", "Tableaux et résultats", BottomTabs, null, false, DockSide.Bottom, 0);

        LoadDockState();

        // 3. hôte
        var host = new Grid();
        host.Children.Add(_dockGrid);
        host.Children.Add(_dockOverlay);
        RootDock.Children.Add(host);
        host.SizeChanged += (s, e) => { if (_dockReady) UpdateStripLimits(); };

        // échelle
        _scaleBusy = true;
        foreach (var sc in UiScales)
        {
            ComboScale.Items.Add($"{sc * 100:0} %");
            var mi = new MenuItem { Header = $"{sc * 100:0} %", IsCheckable = false, Tag = sc };
            mi.Click += (s, e) => SetUiScale((double)((MenuItem)s).Tag);
            MenuScale.Items.Add(mi);
        }
        _scaleBusy = false;
        foreach (var p in _panes)
        {
            var pane = p;
            var mi = new MenuItem { Header = pane.Title, IsCheckable = true, IsChecked = pane.Visible };
            mi.Click += (s, e) => { pane.Visible = mi.IsChecked; RebuildDock(); SaveDockState(); };
            MenuPanels.Items.Add(mi);
        }
        ApplyScale(_uiScale);
        _dockReady = true;
        RebuildDock();
        Closing += (s, e) => SaveDockState();
    }

    private void MenuPanels_Opened(object sender, RoutedEventArgs e)
    {
        for (int i = 0; i < _panes.Count && i < MenuPanels.Items.Count; i++)
            if (MenuPanels.Items[i] is MenuItem mi) mi.IsChecked = _panes[i].Visible;
    }

    private void DockReset_Click(object sender, RoutedEventArgs e)
    {
        foreach (var p in _panes) { p.Side = p.DefSide; p.Order = p.DefOrder; p.Visible = true; }
        _regionSize[DockSide.Left] = 310; _regionSize[DockSide.Right] = 340; _regionSize[DockSide.Top] = 180; _regionSize[DockSide.Bottom] = 300;
        RebuildDock(); SaveDockState();
        StatusLeft.Text = "Disposition de l'interface réinitialisée.";
    }

    // ------------------------------------------------------------------ échelle
    private void ComboScale_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_scaleBusy || ComboScale.SelectedIndex < 0) return;
        SetUiScale(UiScales[ComboScale.SelectedIndex]);
    }

    private void SetUiScale(double s)
    {
        ApplyScale(s);
        SaveDockState();
        StatusLeft.Text = $"Échelle de l'interface : {_uiScale * 100:0} %";
    }

    private void ApplyScale(double s)
    {
        _uiScale = UiScales.OrderBy(x => Math.Abs(x - s)).First();
        RootDock.LayoutTransform = Math.Abs(_uiScale - 1) < 1e-9 ? Transform.Identity : new ScaleTransform(_uiScale, _uiScale);
        _scaleBusy = true;
        ComboScale.SelectedIndex = Array.IndexOf(UiScales, _uiScale);
        foreach (var o in MenuScale.Items) if (o is MenuItem mi) { mi.IsChecked = Math.Abs((double)mi.Tag - _uiScale) < 1e-9; }
        _scaleBusy = false;
    }

    // ------------------------------------------------------------------ persistance
    private void LoadDockState()
    {
        try
        {
            if (!File.Exists(DockFile)) return;
            var st = JsonSerializer.Deserialize<DockState>(File.ReadAllText(DockFile));
            if (st == null) return;
            _uiScale = st.Scale;
            foreach (var p in _panes)
                if (st.Panes.TryGetValue(p.Id, out var ps) && Enum.TryParse<DockSide>(ps.Side, out var sd)) { p.Side = sd; p.Order = ps.Order; p.Visible = ps.Visible; }
            foreach (var kv in st.Sizes) if (Enum.TryParse<DockSide>(kv.Key, out var sd2) && kv.Value >= 60) _regionSize[sd2] = kv.Value;
        }
        catch { }
    }

    private void SaveDockState()
    {
        try
        {
            CaptureSizes();
            var st = new DockState { Scale = _uiScale };
            foreach (var p in _panes) st.Panes[p.Id] = new PaneState { Side = p.Side.ToString(), Order = p.Order, Visible = p.Visible };
            foreach (var kv in _regionSize) st.Sizes[kv.Key.ToString()] = kv.Value;
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(DockFile)!);
            File.WriteAllText(DockFile, JsonSerializer.Serialize(st, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void CaptureSizes()
    {
        if (_cdLeft != null && _cdLeft.Width.IsAbsolute && _cdLeft.ActualWidth > 60) _regionSize[DockSide.Left] = _cdLeft.ActualWidth;
        if (_cdRight != null && _cdRight.Width.IsAbsolute && _cdRight.ActualWidth > 60) _regionSize[DockSide.Right] = _cdRight.ActualWidth;
        if (_rdTop != null && _rdTop.Height.IsAbsolute && _rdTop.ActualHeight > 40) _regionSize[DockSide.Top] = _rdTop.ActualHeight;
        if (_rdBottom != null && _rdBottom.Height.IsAbsolute && _rdBottom.ActualHeight > 40) _regionSize[DockSide.Bottom] = _rdBottom.ActualHeight;
    }

    // ------------------------------------------------------------------ construction de la disposition
    private static void Detach(FrameworkElement e)
    {
        switch (e.Parent)
        {
            case Panel p: p.Children.Remove(e); break;
            case ContentControl c: c.Content = null; break;
            case Decorator d: d.Child = null; break;
        }
    }

    private List<DockPane> PanesOf(DockSide side) => _panes.Where(p => p.Visible && p.Side == side).OrderBy(p => p.Order).ToList();

    private static GridSplitter Splitter(bool vertical) => new()
    {
        HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch,
        Background = new SolidColorBrush(Color.FromRgb(0xD5, 0xDC, 0xE5)), ShowsPreview = false,
        ResizeDirection = vertical ? GridResizeDirection.Columns : GridResizeDirection.Rows,
        ResizeBehavior = GridResizeBehavior.PreviousAndNext,
    };

    private void RebuildDock()
    {
        if (!_dockReady) return;
        CaptureSizes();
        _dockGrid.Children.Clear(); _dockGrid.RowDefinitions.Clear(); _dockGrid.ColumnDefinitions.Clear();
        var L = PanesOf(DockSide.Left); var R = PanesOf(DockSide.Right); var T = PanesOf(DockSide.Top); var B = PanesOf(DockSide.Bottom);
        bool hl = L.Any(p => !p.IsStrip), hr = R.Any(p => !p.IsStrip), ht = T.Any(p => !p.IsStrip), hb = B.Any(p => !p.IsStrip);

        _cdLeft = new ColumnDefinition { Width = L.Count == 0 ? new GridLength(0) : hl ? new GridLength(_regionSize[DockSide.Left]) : GridLength.Auto, MinWidth = hl ? 120 : 0 };
        var cdLs = new ColumnDefinition { Width = new GridLength(hl ? 5 : 0) };
        var cdC = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 150 };
        var cdRs = new ColumnDefinition { Width = new GridLength(hr ? 5 : 0) };
        _cdRight = new ColumnDefinition { Width = R.Count == 0 ? new GridLength(0) : hr ? new GridLength(_regionSize[DockSide.Right]) : GridLength.Auto, MinWidth = hr ? 120 : 0 };
        foreach (var c in new[] { _cdLeft, cdLs, cdC, cdRs, _cdRight }) _dockGrid.ColumnDefinitions.Add(c);

        _rdTop = new RowDefinition { Height = T.Count == 0 ? new GridLength(0) : ht ? new GridLength(_regionSize[DockSide.Top]) : GridLength.Auto, MinHeight = ht ? 60 : 0 };
        var rdTs = new RowDefinition { Height = new GridLength(ht ? 5 : 0) };
        var rdC = new RowDefinition { Height = new GridLength(1, GridUnitType.Star), MinHeight = 120 };
        var rdBs = new RowDefinition { Height = new GridLength(hb ? 5 : 0) };
        _rdBottom = new RowDefinition { Height = B.Count == 0 ? new GridLength(0) : hb ? new GridLength(_regionSize[DockSide.Bottom]) : GridLength.Auto, MinHeight = hb ? 60 : 0 };
        foreach (var r in new[] { _rdTop, rdTs, rdC, rdBs, _rdBottom }) _dockGrid.RowDefinitions.Add(r);

        // centre
        Detach(CenterBorder);
        Grid.SetRow(CenterBorder, 2); Grid.SetColumn(CenterBorder, 2);
        _dockGrid.Children.Add(CenterBorder);

        void Place(UIElement e, int row, int col, int rowSpan = 1, int colSpan = 1)
        {
            Grid.SetRow(e, row); Grid.SetColumn(e, col); Grid.SetRowSpan(e, rowSpan); Grid.SetColumnSpan(e, colSpan);
            _dockGrid.Children.Add(e);
        }
        if (T.Count > 0) { Place(BuildRegion(DockSide.Top, T), 0, 0, 1, 5); if (ht) { var sp = Splitter(false); sp.Height = 5; Place(sp, 1, 0, 1, 5); } }
        if (L.Count > 0) { Place(BuildRegion(DockSide.Left, L), 2, 0, 3, 1); if (hl) Place(Splitter(true), 2, 1, 3, 1); }
        if (R.Count > 0) { Place(BuildRegion(DockSide.Right, R), 2, 4, 3, 1); if (hr) Place(Splitter(true), 2, 3, 3, 1); }
        if (B.Count > 0) { Place(BuildRegion(DockSide.Bottom, B), 4, 2); if (hb) { var sp = Splitter(false); sp.Height = 5; Place(sp, 3, 2); } }
        _dockGrid.UpdateLayout();
        UpdateStripLimits();
    }

    private Grid BuildRegion(DockSide side, List<DockPane> list)
    {
        var g = new Grid();
        int row = 0;
        for (int i = 0; i < list.Count; i++)
        {
            var p = list[i];
            if (i > 0 && !list[i - 1].IsStrip && !p.IsStrip)
            {
                g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(5) });
                var sp = Splitter(false); sp.Height = 5; Grid.SetRow(sp, row++); g.Children.Add(sp);
            }
            g.RowDefinitions.Add(new RowDefinition { Height = p.IsStrip ? GridLength.Auto : new GridLength(1, GridUnitType.Star), MinHeight = p.IsStrip ? 0 : 60 });
            var root = BuildPaneRoot(p, side);
            Grid.SetRow(root, row++); g.Children.Add(root);
        }
        return g;
    }

    private Border BuildPaneRoot(DockPane p, DockSide side)
    {
        Detach(p.Element);
        var root = new Border { BorderBrush = (Brush)FindResource("LineBrush"), BorderThickness = new Thickness(1), Background = Brushes.White };
        var dp = new DockPanel { LastChildFill = true };
        if (p.IsStrip)
        {
            bool vertical = side is DockSide.Left or DockSide.Right;
            var grip = BuildGrip(p, vertical);
            DockPanel.SetDock(grip, vertical ? Dock.Top : Dock.Left);
            dp.Children.Add(grip);
            SetStripOrientation(p, vertical);
        }
        else
        {
            var hdr = BuildHeader(p);
            DockPanel.SetDock(hdr, Dock.Top);
            dp.Children.Add(hdr);
        }
        dp.Children.Add(p.Element);
        root.Child = dp; p.Root = root;
        return root;
    }

    private void SetStripOrientation(DockPane p, bool vertical)
    {
        if (p.Inner is WrapPanel w)
        {
            w.Orientation = vertical ? Orientation.Vertical : Orientation.Horizontal;
            foreach (var r in w.Children.OfType<Rectangle>())
            {
                if (vertical) { r.Width = double.NaN; r.Height = 1; r.Margin = new Thickness(2, 8, 2, 8); }
                else { r.Height = double.NaN; r.Width = 1; r.Margin = new Thickness(8, 2, 8, 2); }
            }
        }
    }

    private void UpdateStripLimits()
    {
        foreach (var p in _panes.Where(x => x.IsStrip))
            p.Element.MaxHeight = p.Side is DockSide.Left or DockSide.Right ? Math.Max(120, _dockGrid.ActualHeight - 40) : double.PositiveInfinity;
    }

    // ------------------------------------------------------------------ poignées et menus
    private Border BuildGrip(DockPane p, bool vertical)
    {
        var grip = new Border
        {
            Background = new SolidColorBrush(Color.FromRgb(0xE4, 0xEA, 0xF2)), Cursor = Cursors.SizeAll,
            Width = vertical ? double.NaN : 14, Height = vertical ? 13 : double.NaN,
            ToolTip = p.Title + "\nGlisser vers un bord de la fenêtre pour ancrer. Clic droit : menu.",
            Child = new TextBlock { Text = vertical ? "· · · · ·" : "⋮", FontWeight = FontWeights.Bold, Foreground = Brushes.SlateGray, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontSize = vertical ? 9 : 12 },
        };
        AttachDrag(grip, p);
        grip.ContextMenu = BuildPaneMenu(p);
        return grip;
    }

    private Border BuildHeader(DockPane p)
    {
        var hdr = new Border { Background = new SolidColorBrush(Color.FromRgb(0xE4, 0xEA, 0xF2)), Height = 22, Cursor = Cursors.SizeAll, ToolTip = "Glisser vers un bord de la fenêtre pour ancrer ce panneau" };
        var dp = new DockPanel();
        Button Small(string t, string tip, RoutedEventHandler h)
        {
            var b = new Button { Content = t, ToolTip = tip, Padding = new Thickness(5, 0, 5, 0), BorderThickness = new Thickness(0), Background = Brushes.Transparent, Focusable = false, Cursor = Cursors.Hand, FontSize = 11 };
            b.Click += h; return b;
        }
        var close = Small("✕", "Masquer ce panneau (réafficher par le menu Affichage)", (s, e) => { p.Visible = false; RebuildDock(); SaveDockState(); });
        DockPanel.SetDock(close, Dock.Right); dp.Children.Add(close);
        var menu = Small("▾", "Ancrer à...", (s, e) => { var cm = BuildPaneMenu(p); cm.PlacementTarget = (UIElement)s; cm.IsOpen = true; });
        DockPanel.SetDock(menu, Dock.Right); dp.Children.Add(menu);
        dp.Children.Add(new TextBlock { Text = p.Title, FontWeight = FontWeights.SemiBold, FontSize = 11, Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 0, 0) });
        hdr.Child = dp;
        AttachDrag(hdr, p);
        hdr.ContextMenu = BuildPaneMenu(p);
        return hdr;
    }

    private ContextMenu BuildPaneMenu(DockPane p)
    {
        var cm = new ContextMenu();
        MenuItem Item(string header, DockSide side)
        {
            var mi = new MenuItem { Header = header, IsChecked = p.Side == side };
            mi.Click += (s, e) => MovePane(p, side, int.MaxValue);
            return mi;
        }
        cm.Items.Add(Item("Ancrer à gauche", DockSide.Left));
        cm.Items.Add(Item("Ancrer à droite", DockSide.Right));
        cm.Items.Add(Item("Ancrer en haut", DockSide.Top));
        cm.Items.Add(Item("Ancrer en bas", DockSide.Bottom));
        cm.Items.Add(new Separator());
        var hide = new MenuItem { Header = "Masquer" };
        hide.Click += (s, e) => { p.Visible = false; RebuildDock(); SaveDockState(); };
        cm.Items.Add(hide);
        var reset = new MenuItem { Header = "Réinitialiser toute la disposition" };
        reset.Click += DockReset_Click;
        cm.Items.Add(reset);
        return cm;
    }

    // ------------------------------------------------------------------ glisser-déposer
    private void AttachDrag(UIElement handle, DockPane p)
    {
        handle.MouseLeftButtonDown += (s, e) =>
        {
            if (e.OriginalSource is DependencyObject d && FindAncestor<Button>(d) != null) return;
            _dragPane = p; _dragStart = e.GetPosition(_dockGrid); _dragActive = false; _dropTarget = null;
            handle.CaptureMouse();
        };
        handle.MouseMove += (s, e) =>
        {
            if (_dragPane != p || e.LeftButton != MouseButtonState.Pressed) return;
            var pt = e.GetPosition(_dockGrid);
            if (!_dragActive)
            {
                if (Math.Abs(pt.X - _dragStart.X) + Math.Abs(pt.Y - _dragStart.Y) < 10) return;
                _dragActive = true;
                _dropRect = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(70, 0x2E, 0x75, 0xB6)), Stroke = new SolidColorBrush(Color.FromRgb(0x2E, 0x75, 0xB6)), StrokeThickness = 2 };
                _dropLabel = new TextBlock { Foreground = Brushes.White, Background = new SolidColorBrush(Color.FromRgb(0x2E, 0x75, 0xB6)), Padding = new Thickness(6, 2, 6, 2), FontWeight = FontWeights.SemiBold };
                _dockOverlay.Children.Clear(); _dockOverlay.Children.Add(_dropRect); _dockOverlay.Children.Add(_dropLabel);
            }
            UpdateDropTarget(pt);
        };
        handle.MouseLeftButtonUp += (s, e) =>
        {
            if (_dragPane != p) return;
            handle.ReleaseMouseCapture();
            var target = _dropTarget;
            bool active = _dragActive;
            _dragPane = null; _dragActive = false; _dropTarget = null;
            _dockOverlay.Children.Clear();
            if (active && target.HasValue) MovePane(p, target.Value.Side, target.Value.Index);
        };
    }

    private static T? FindAncestor<T>(DependencyObject d) where T : DependencyObject
    {
        while (d != null) { if (d is T t) return t; d = (d is Visual || d is System.Windows.Media.Media3D.Visual3D) ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d); }
        return null;
    }

    private void UpdateDropTarget(Point pt)
    {
        double W = Math.Max(_dockGrid.ActualWidth, 1), H = Math.Max(_dockGrid.ActualHeight, 1);
        double zone = 0.22;
        var cands = new List<(DockSide Side, double Dist)>();
        if (pt.X / W < zone) cands.Add((DockSide.Left, pt.X / W));
        if ((W - pt.X) / W < zone) cands.Add((DockSide.Right, (W - pt.X) / W));
        if (pt.Y / H < zone) cands.Add((DockSide.Top, pt.Y / H));
        if ((H - pt.Y) / H < zone) cands.Add((DockSide.Bottom, (H - pt.Y) / H));
        if (cands.Count == 0 || _dragPane == null) { _dropTarget = null; if (_dropRect != null) _dropRect.Visibility = Visibility.Collapsed; if (_dropLabel != null) _dropLabel.Visibility = Visibility.Collapsed; return; }
        var side = cands.OrderBy(c => c.Dist).First().Side;
        int index = 0;
        foreach (var q in PanesOf(side).Where(x => x != _dragPane))
        {
            if (q.Root == null) continue;
            try
            {
                var c = q.Root.TranslatePoint(new Point(0, q.Root.ActualHeight / 2), _dockGrid);
                if (c.Y < pt.Y) index++;
            }
            catch { }
        }
        _dropTarget = (side, index);
        double tw = Math.Min(W * 0.25, 360), th = Math.Min(H * 0.25, 260);
        var r = side switch
        {
            DockSide.Left => new Rect(0, 0, tw, H),
            DockSide.Right => new Rect(W - tw, 0, tw, H),
            DockSide.Top => new Rect(0, 0, W, th),
            _ => new Rect(0, H - th, W, th),
        };
        if (_dropRect != null)
        {
            _dropRect.Visibility = Visibility.Visible; _dropRect.Width = r.Width; _dropRect.Height = r.Height;
            Canvas.SetLeft(_dropRect, r.X); Canvas.SetTop(_dropRect, r.Y);
        }
        if (_dropLabel != null)
        {
            _dropLabel.Visibility = Visibility.Visible;
            _dropLabel.Text = $"Ancrer « {_dragPane.Title} » {side switch { DockSide.Left => "à gauche", DockSide.Right => "à droite", DockSide.Top => "en haut", _ => "en bas" }}";
            Canvas.SetLeft(_dropLabel, r.X + 8); Canvas.SetTop(_dropLabel, r.Y + 8);
        }
    }

    private void MovePane(DockPane p, DockSide side, int index)
    {
        var others = PanesOf(side).Where(x => x != p).ToList();
        index = Math.Max(0, Math.Min(index, others.Count));
        others.Insert(index, p);
        p.Side = side; p.Visible = true;
        for (int i = 0; i < others.Count; i++) others[i].Order = i;
        RebuildDock();
        SaveDockState();
    }
}
