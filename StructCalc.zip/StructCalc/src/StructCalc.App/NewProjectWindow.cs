using System.IO;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;
using Microsoft.Win32;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Fenêtre de création d'un projet : nom, emplacement, type, unité, système structurel, norme et modèle de départ. Crée et enregistre réellement le fichier.</summary>
internal sealed class NewProjectWindow : Window
{
    private readonly Pal _p;
    private readonly string _templateName;
    private TextBox _name = null!, _folder = null!;
    private Chips _type = null!, _unit = null!, _system = null!, _norm = null!, _start = null!;
    private TextBlock _filePreview = null!;
    private Border _errorBox = null!;
    private TextBlock _errorText = null!;
    private Button _create = null!;
    private FrameworkElement _createContent = null!;
    private FrameworkElement _form = null!;
    private bool _busy, _normTouched;

    public StructModel? CreatedModel { get; private set; }
    public string CreatedPath { get; private set; } = "";
    public NewProjectOptions? Options { get; private set; }

    public NewProjectWindow(Pal pal, string templateName = "")
    {
        _p = pal; _templateName = templateName;
        Title = "StructCalc - Nouveau projet";
        WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize; ShowInTaskbar = false;
        Width = 660; SizeToContent = SizeToContent.Height; MaxHeight = 760;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FontFamily = Wk.Font; UseLayoutRounding = true; SnapsToDevicePixels = true;
        Background = _p.BBg;
        TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
        WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 0, ResizeBorderThickness = new Thickness(0), GlassFrameThickness = new Thickness(0), CornerRadius = new CornerRadius(0), UseAeroCaptionButtons = false });
        PreviewKeyDown += (s, ev) => { if (ev.Key == Key.Escape && !_busy) { DialogResult = false; ev.Handled = true; } };
        Closing += (s, ev) => { if (_busy) ev.Cancel = true; };
        MaxHeight = Math.Max(520, SystemParameters.WorkArea.Height - 40);
        Build();
        Loaded += (s, ev) => { Wk.Appear((UIElement)Content, 0, 200, 0); _name.Focus(); _name.SelectAll(); };
    }

    private TextBlock Cap(string t)
    {
        var l = Wk.Txt(t, 12.5, _p.BMuted, FontWeights.Medium); l.Margin = new Thickness(0, 0, 0, 7);
        return l;
    }

    private void Build()
    {
        var root = new Border { Background = _p.BBg, BorderBrush = _p.BLine, BorderThickness = new Thickness(1) };
        var dock = new DockPanel();

        // en-tête (zone de déplacement)
        var head = new Grid { Background = _p.BSide, Height = 82 };
        head.MouseLeftButtonDown += (s, ev) => { if (ev.ClickCount == 1 && ev.LeftButton == MouseButtonState.Pressed) { try { DragMove(); } catch { } } };
        var headRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(28, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, IsHitTestVisible = false };
        var badge = new Border { Width = 42, Height = 42, CornerRadius = new CornerRadius(12), Background = _p.BAccent };
        var bi = Wk.Icon("plus", 22, _p.BOnAccent, 2.2); bi.HorizontalAlignment = HorizontalAlignment.Center; bi.VerticalAlignment = VerticalAlignment.Center;
        badge.Child = bi;
        headRow.Children.Add(badge);
        var tt = new StackPanel { Margin = new Thickness(16, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        tt.Children.Add(Wk.Txt("Nouveau projet", 20, _p.BText, FontWeights.SemiBold));
        string sub = _templateName == "" ? "Choisissez les réglages de départ de votre projet." : "Modèle choisi : " + _templateName;
        tt.Children.Add(Wk.Txt(sub, 13, _p.BMuted));
        headRow.Children.Add(tt);
        head.Children.Add(headRow);
        var close = Wk.Btn(_p, BtnKind.Quiet, null, "x", (s, ev) => { if (!_busy) DialogResult = false; }, 32, 14, 9);
        close.HorizontalAlignment = HorizontalAlignment.Right; close.VerticalAlignment = VerticalAlignment.Top; close.Margin = new Thickness(0, 12, 12, 0);
        head.Children.Add(close);
        DockPanel.SetDock(head, Dock.Top);
        dock.Children.Add(head);
        var sep = new Border { Height = 1, Background = _p.BLine };
        DockPanel.SetDock(sep, Dock.Top);
        dock.Children.Add(sep);

        // pied : erreur + boutons
        var foot = new StackPanel { Background = _p.BSide };
        foot.Children.Add(new Border { Height = 1, Background = _p.BLine });
        _errorBox = new Border { Background = _p.BErrSoft, CornerRadius = new CornerRadius(10), Margin = new Thickness(28, 14, 28, 0), Padding = new Thickness(14, 10, 14, 10), Visibility = Visibility.Collapsed };
        var er = new StackPanel { Orientation = Orientation.Horizontal };
        var ei = Wk.Icon("alert", 17, _p.BErr); ei.VerticalAlignment = VerticalAlignment.Center; ei.Margin = new Thickness(0, 0, 10, 0);
        er.Children.Add(ei);
        _errorText = Wk.Txt("", 13, _p.BErr, FontWeights.Medium, false, true); _errorText.MaxWidth = 540; _errorText.VerticalAlignment = VerticalAlignment.Center;
        er.Children.Add(_errorText);
        _errorBox.Child = er;
        foot.Children.Add(_errorBox);
        var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(28, 16, 28, 18) };
        var cancel = Wk.Btn(_p, BtnKind.Secondary, "Annuler", null, (s, ev) => { if (!_busy) DialogResult = false; }, 46, 14, 12);
        cancel.Margin = new Thickness(0, 0, 12, 0);
        _create = Wk.Btn(_p, BtnKind.Primary, "Créer le projet", "check", (s, ev) => CreateClick(), 46, 14.5, 12);
        _create.MinWidth = 190;
        _createContent = (FrameworkElement)_create.Content!;
        btns.Children.Add(cancel); btns.Children.Add(_create);
        foot.Children.Add(btns);
        DockPanel.SetDock(foot, Dock.Bottom);
        dock.Children.Add(foot);

        // formulaire
        var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        sv.Resources.Add(typeof(System.Windows.Controls.Primitives.ScrollBar), Wk.ScrollBarStyle(_p));
        var f = new StackPanel { Margin = new Thickness(28, 22, 28, 12) };
        _form = f;

        // nom
        f.Children.Add(Cap("Nom du projet"));
        var nameBox = Wk.Input(_p, UniqueName(), out _name);
        nameBox.Margin = new Thickness(0, 0, 0, 18);
        _name.TextChanged += (s, ev) => { HideError(); UpdatePreview(); };
        f.Children.Add(nameBox);

        // emplacement
        f.Children.Add(Cap("Emplacement d'enregistrement"));
        var fg = new Grid();
        fg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        fg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var folderBox = Wk.Input(_p, ProjectFactory.DefaultFolder(), out _folder);
        _folder.TextChanged += (s, ev) => { HideError(); UpdatePreview(); };
        var browse = Wk.Btn(_p, BtnKind.Secondary, "Parcourir", "folder", (s, ev) => Browse(), 44, 13.5, 10);
        browse.Margin = new Thickness(10, 0, 0, 0);
        Grid.SetColumn(browse, 1);
        fg.Children.Add(folderBox); fg.Children.Add(browse);
        f.Children.Add(fg);
        _filePreview = Wk.Txt("", 12, _p.BFaint, null, true); _filePreview.Margin = new Thickness(2, 7, 0, 18);
        f.Children.Add(_filePreview);

        // type de projet
        f.Children.Add(Cap("Type de projet"));
        _type = new Chips(_p, ProjectFactory.ProjectTypes.Select(t => (t, t)), ProjectFactory.ProjectTypes[0]);
        f.Children.Add(_type);

        // unité + système
        f.Children.Add(Cap("Unité de longueur"));
        _unit = new Chips(_p, new[] { ("m", "Mètre (m)"), ("cm", "Centimètre (cm)"), ("mm", "Millimètre (mm)") }, "m");
        f.Children.Add(_unit);

        f.Children.Add(Cap("Système structurel"));
        _system = new Chips(_p, ProjectFactory.Systems.Select(t => (t, t)), "Béton armé");
        _system.Changed += v => { if (!_normTouched) _norm.Select(ProjectFactory.DefaultNormFor(v), false); };
        f.Children.Add(_system);

        f.Children.Add(Cap("Norme de calcul par défaut"));
        _norm = new Chips(_p, new[] { ("BAEL91", "BAEL 91"), ("EC2", "Eurocode 2"), ("CM66", "CM66 (acier)") }, "BAEL91");
        _norm.Changed += v => _normTouched = true;
        f.Children.Add(_norm);

        f.Children.Add(Cap("Modèle de départ"));
        if (_templateName == "")
        {
            _start = new Chips(_p, new[] { ("Vierge", "Projet vierge"), ("Exemple", "Modèle exemple (portique)") }, "Vierge");
            f.Children.Add(_start);
        }
        else
        {
            _start = new Chips(_p, new[] { ("T", _templateName) }, "T");
            f.Children.Add(_start);
            var tpl = ProjectTemplates.All.FirstOrDefault(t => t.Name == _templateName);
            if (tpl != null)
            {
                // le système du modèle choisi règle le système et la norme proposés
                _system.Select(tpl.System, false);
                _norm.Select(ProjectFactory.DefaultNormFor(tpl.System), false);
                var d = Wk.Txt(tpl.Description, 12.5, _p.BMuted, null, false, true); d.Margin = new Thickness(2, -2, 0, 4);
                f.Children.Add(d);
            }
        }
        sv.Content = f;
        dock.Children.Add(sv);
        root.Child = dock;
        Content = root;
        UpdatePreview();
    }

    private string UniqueName()
    {
        string folder = ProjectFactory.DefaultFolder();
        string baseName = _templateName == "" ? "Nouveau projet" : _templateName;
        string name = baseName;
        try
        {
            for (int i = 2; File.Exists(ProjectFactory.PathOf(new NewProjectOptions { Name = name, Folder = folder })); i++) name = baseName + " " + i;
        }
        catch { }
        return name;
    }

    private void Browse()
    {
        var dlg = new OpenFolderDialog { Title = "Choisir le dossier du projet" };
        try { if (Directory.Exists(_folder.Text)) dlg.InitialDirectory = _folder.Text; } catch { }
        if (dlg.ShowDialog(this) == true && !string.IsNullOrWhiteSpace(dlg.FolderName)) _folder.Text = dlg.FolderName;
    }

    private NewProjectOptions ReadOptions() => new()
    {
        Name = _name.Text.Trim(), Folder = _folder.Text.Trim(), ProjectType = _type.Value, Unit = _unit.Value, StructuralSystem = _system.Value, Norm = _norm.Value,
        Template = _templateName != "" ? "Vierge" : _start.Value, TemplateName = _templateName
    };

    private void UpdatePreview()
    {
        if (_filePreview == null || _name == null || _folder == null) return;
        try
        {
            var o = new NewProjectOptions { Name = _name.Text, Folder = _folder.Text };
            _filePreview.Text = string.IsNullOrWhiteSpace(_name.Text) || string.IsNullOrWhiteSpace(_folder.Text) ? "" : "Fichier créé : " + ProjectFactory.PathOf(o);
        }
        catch { _filePreview.Text = ""; }
    }

    private void ShowError(string msg)
    {
        _errorText.Text = msg;
        _errorBox.Visibility = Visibility.Visible;
        Wk.Appear(_errorBox, 0, 170, 6);
    }

    private void HideError() { if (_errorBox != null && _errorBox.Visibility == Visibility.Visible) _errorBox.Visibility = Visibility.Collapsed; }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        _form.IsEnabled = !busy;
        _form.Opacity = busy ? 0.55 : 1;
        _create.IsEnabled = !busy;
        if (busy)
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            row.Children.Add(Wk.Spinner(_p.BOnAccent, 18));
            var t = Wk.Txt("Création en cours…", 14.5, _p.BOnAccent, FontWeights.SemiBold); t.Margin = new Thickness(10, 0, 0, 0);
            row.Children.Add(t);
            _create.Content = row;
        }
        else _create.Content = _createContent;
    }

    private async void CreateClick()
    {
        if (_busy) return;
        var o = ReadOptions();
        string? err = ProjectFactory.Validate(o);
        if (err != null) { ShowError(err); return; }
        HideError();
        SetBusy(true);
        var sw = Stopwatch.StartNew();
        try
        {
            var (model, path) = await Task.Run(() => ProjectFactory.Create(o));
            long wait = 520 - sw.ElapsedMilliseconds;
            if (wait > 0) await Task.Delay((int)wait);
            CreatedModel = model; CreatedPath = path; Options = o;
            _busy = false;
            DialogResult = true;
        }
        catch (Exception ex)
        {
            SetBusy(false);
            ShowError("Création impossible : " + ex.Message);
        }
    }
}
