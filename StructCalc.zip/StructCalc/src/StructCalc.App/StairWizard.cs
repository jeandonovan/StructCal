using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Stairs;

namespace StructCalc.UI;

/// <summary>Assistant de création et de calcul d'escaliers en béton armé : droit, avec palier, quart ou demi-tournant, double quart, balancé, hélicoïdal.
/// Les résultats (géométrie de Blondel, charges, sollicitations, ferraillage, plan et coupe) se mettent à jour à chaque modification.</summary>
public sealed class StairWizardWindow : Window
{
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<Func<StructModel, string>, string> _apply;
    private StairDef _work = new();
    private readonly ComboBox _list = new() { Width = 200 };
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, TextWrapping = TextWrapping.NoWrap, Padding = new Thickness(8) };
    private readonly SheetPreview _preview = new();
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private FormKit _form = null!;
    private ScrollViewer _formHost = null!;
    private bool _busy;

    public StairWizardWindow(Func<StructModel> model, Func<Func<StructModel, string>, string> apply)
    {
        _get = model; _apply = apply;
        Title = "Assistant escaliers";
        Width = 1350; Height = 820; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _work = NewDef();

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(480) });
        root.ColumnDefinitions.Add(new ColumnDefinition());

        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Escalier :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        bar.Children.Add(_list);
        bar.Children.Add(new Border { Width = 10 });
        bar.Children.Add(Ui.Btn("➕ Nouveau", (s, e) => { _work = NewDef(); FillList(); RebuildForm(); Recompute(); }));
        bar.Children.Add(Ui.Btn("💾 Enregistrer dans le projet", (s, e) => Save(), true));
        bar.Children.Add(Ui.Btn("🗑 Supprimer du projet", (s, e) => Delete()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);

        _formHost = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);

        var tabs = new TabControl { Margin = new Thickness(4) };
        tabs.Items.Add(new TabItem { Header = "Plan et coupe ferraillée", Content = _preview });
        tabs.Items.Add(new TabItem { Header = "Note de calcul", Content = _report });
        Grid.SetRow(tabs, 1); Grid.SetColumn(tabs, 1); root.Children.Add(tabs);
        Content = root;

        _list.SelectionChanged += (s, e) =>
        {
            if (_busy) return;
            int i = _list.SelectedIndex;
            if (i < 0) return;
            if (i < _model.Stairs.Count) { _work = _model.Stairs[i].Clone(); RebuildForm(); Recompute(); }
        };
        FillList();
        if (_model.Stairs.Count > 0) { _work = _model.Stairs[0].Clone(); _busy = true; _list.SelectedIndex = 0; _busy = false; }
        RebuildForm();
        Loaded += (s, e) => Recompute();
    }

    internal static readonly (string, StairLayout)[] LayoutItems =
    {
        ("Droit (une volée)", StairLayout.Droit),
        ("Droit avec palier intermédiaire", StairLayout.DroitPalier),
        ("Quart tournant avec palier d'angle", StairLayout.QuartPalier),
        ("Demi-tournant (U) avec palier", StairLayout.DemiPalier),
        ("Double quart tournant (3 volées)", StairLayout.DoubleQuartPalier),
        ("Quart tournant balancé", StairLayout.QuartBalance),
        ("Demi-tournant balancé", StairLayout.DemiBalance),
        ("Hélicoïdal / colimaçon", StairLayout.Helicoidal),
    };

    internal static readonly string[] LayoutShort = { "Droit", "Droit + palier", "Quart tournant", "Demi-tournant (U)", "Double quart", "Quart balancé", "Demi balancé", "Hélicoïdal" };

    internal static void ApplyLayout(StairDef d, StairLayout v)
    {
        d.Layout = v;
        if (v is StairLayout.QuartPalier or StairLayout.DoubleQuartPalier) d.MidLandingM = d.WidthM;
    }

    /// <summary>Galerie des 8 types d'escalier avec pictogrammes ; le type courant est entouré.</summary>
    private UIElement BuildLayoutGallery(StairDef d)
    {
        var wrap = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
        for (int i = 0; i < LayoutItems.Length; i++)
        {
            var (text, lay) = LayoutItems[i];
            bool sel = d.Layout == lay;
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(Picto(lay));
            sp.Children.Add(new TextBlock { Text = LayoutShort[i], FontSize = 11, TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0), FontWeight = sel ? FontWeights.Bold : FontWeights.Normal });
            var card = new Border
            {
                Width = 100, Height = 82, Margin = new Thickness(0, 0, 5, 5), Padding = new Thickness(3), Cursor = System.Windows.Input.Cursors.Hand,
                BorderThickness = new Thickness(sel ? 2.5 : 1), CornerRadius = new CornerRadius(4), Child = sp, ToolTip = text,
            };
            card.SetResourceReference(Border.BorderBrushProperty, sel ? "Accent" : "ThemeBorder");
            card.SetResourceReference(Border.BackgroundProperty, sel ? "ThemeHover" : "ThemeBg");
            var chosen = lay;
            card.MouseLeftButtonUp += (s, e) =>
            {
                if (_work.Layout == chosen) return;
                ApplyLayout(_work, chosen);
                RebuildForm(); Recompute();
            };
            wrap.Children.Add(card);
        }
        return wrap;
    }

    /// <summary>Pictogramme (vue en plan schématique, 84 x 50) d'une disposition d'escalier.</summary>
    internal static Canvas Picto(StairLayout lay)
    {
        var c = new Canvas { Width = 84, Height = 50 };
        void L(double x1, double y1, double x2, double y2, double th = 1.2)
        {
            var ln = new System.Windows.Shapes.Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, StrokeThickness = th, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round };
            ln.SetResourceReference(System.Windows.Shapes.Shape.StrokeProperty, "ThemeFg");
            c.Children.Add(ln);
        }
        void R(double x, double y, double w, double h, double th = 1.4)
        {
            L(x, y, x + w, y, th); L(x + w, y, x + w, y + h, th); L(x + w, y + h, x, y + h, th); L(x, y + h, x, y, th);
        }
        void RunX(double x, double y, double w, double h, double step = 5)        // volée horizontale : marches verticales
        {
            R(x, y, w, h);
            for (double xx = x + step; xx < x + w - 0.5; xx += step) L(xx, y, xx, y + h, 0.7);
        }
        void RunY(double x, double y, double w, double h, double step = 5)        // volée verticale : marches horizontales
        {
            R(x, y, w, h);
            for (double yy = y + step; yy < y + h - 0.5; yy += step) L(x, yy, x + w, yy, 0.7);
        }
        void Arrow(double x1, double y1, double x2, double y2)
        {
            L(x1, y1, x2, y2, 1.0);
            double a = Math.Atan2(y2 - y1, x2 - x1), d = 4;
            L(x2, y2, x2 - d * Math.Cos(a - 0.5), y2 - d * Math.Sin(a - 0.5), 1.0);
            L(x2, y2, x2 - d * Math.Cos(a + 0.5), y2 - d * Math.Sin(a + 0.5), 1.0);
        }
        switch (lay)
        {
            case StairLayout.Droit:
                RunX(4, 17, 76, 16); Arrow(8, 25, 76, 25); break;
            case StairLayout.DroitPalier:
                RunX(3, 17, 32, 16); R(35, 17, 14, 16); RunX(49, 17, 32, 16); Arrow(7, 25, 77, 25); break;
            case StairLayout.QuartPalier:
                RunX(3, 32, 30, 15); R(33, 32, 15, 15); RunY(33, 3, 15, 29); Arrow(7, 39, 40, 39); Arrow(40, 39, 40, 7); break;
            case StairLayout.DemiPalier:
                RunX(3, 4, 52, 15); R(55, 4, 16, 41); RunX(3, 30, 52, 15); Arrow(8, 11, 62, 11); Arrow(62, 11, 62, 37); Arrow(62, 37, 8, 37); break;
            case StairLayout.DoubleQuartPalier:
                RunX(3, 36, 24, 12); R(27, 36, 12, 12); RunY(27, 14, 12, 22, 4.4); R(27, 2, 12, 12); RunX(39, 2, 42, 12); break;
            case StairLayout.QuartBalance:
                RunX(3, 32, 30, 15); R(33, 32, 15, 15);
                for (int k = 1; k < 3; k++) { double a = Math.PI / 2 * k / 3; L(33, 47, 33 + 15 * Math.Cos(a) * 1.0, 47 - 15 * Math.Sin(a) * 1.0, 0.7); }
                RunY(33, 3, 15, 29); Arrow(7, 39, 40, 39); Arrow(40, 39, 40, 7); break;
            case StairLayout.DemiBalance:
                RunX(3, 4, 52, 15); R(55, 4, 16, 41); RunX(3, 30, 52, 15);
                for (int k = 1; k < 5; k++) L(55, 4 + 41.0 * k / 5 * 0.5 + 10, 71, 4 + 41.0 * k / 5, 0.7);
                Arrow(8, 11, 62, 11); Arrow(62, 11, 62, 37); Arrow(62, 37, 8, 37); break;
            default:
            {
                double cx = 42, cy = 25, ro = 22, ri = 8;
                var o = new System.Windows.Shapes.Ellipse { Width = 2 * ro, Height = 2 * ro, StrokeThickness = 1.4 };
                o.SetResourceReference(System.Windows.Shapes.Shape.StrokeProperty, "ThemeFg");
                Canvas.SetLeft(o, cx - ro); Canvas.SetTop(o, cy - ro); c.Children.Add(o);
                var i2 = new System.Windows.Shapes.Ellipse { Width = 2 * ri, Height = 2 * ri, StrokeThickness = 1.4 };
                i2.SetResourceReference(System.Windows.Shapes.Shape.StrokeProperty, "ThemeFg");
                Canvas.SetLeft(i2, cx - ri); Canvas.SetTop(i2, cy - ri); c.Children.Add(i2);
                for (int k = 0; k < 12; k++) { double a = Math.PI * 2 * k / 12; L(cx + ri * Math.Cos(a), cy + ri * Math.Sin(a), cx + ro * Math.Cos(a), cy + ro * Math.Sin(a), 0.7); }
                break;
            }
        }
        return c;
    }

    private StairDef NewDef()
    {
        int n = 1; while (_model.Stairs.Any(x => x.Name == "E" + n)) n++;
        double h = 3.06;
        var lv = StructureAnalyzer_Levels();
        if (lv.Count >= 2) h = lv[1] - lv[0];
        return new StairDef { Name = "E" + n, HeightM = Math.Round(h, 3), CoverCm = _model.Settings.CoverSlabCm };
    }

    private List<double> StructureAnalyzer_Levels()
    {
        try { return Engine_Levels(); } catch { return new List<double>(); }
    }
    private List<double> Engine_Levels() => StructCalc.Engine.Structure.StructureAnalyzer.Analyze(_model).Levels.Select(l => l.Z).OrderBy(z => z).ToList();

    private void FillList()
    {
        _busy = true;
        _list.Items.Clear();
        foreach (var s in _model.Stairs) _list.Items.Add($"{s.Name} - {Layouts.Name(s.Layout)}");
        if (!_model.Stairs.Any(x => x.Name == _work.Name)) _list.Items.Add($"{_work.Name} (nouveau)");
        int idx = _model.Stairs.FindIndex(x => x.Name == _work.Name);
        _list.SelectedIndex = idx >= 0 ? idx : _list.Items.Count - 1;
        _busy = false;
    }

    private void RebuildForm()
    {
        _form = new FormKit();
        var d = _work;
        _form.Section("Type d'escalier");
        _form.Text("Nom", () => d.Name, v => d.Name = v);
        _form.Add(new TextBlock { Text = "Choisissez le type d'escalier :", Margin = new Thickness(0, 4, 0, 4), FontWeight = FontWeights.SemiBold });
        _form.Add(BuildLayoutGallery(d));
        _form.Combo("Disposition", LayoutItems, () => d.Layout, v => { ApplyLayout(d, v); Dispatcher.BeginInvoke(new Action(() => { RebuildForm(); Recompute(); })); });
        _form.Combo("Usage (charge d'exploitation)", new (string, StairUsage)[]
        {
            ("Habitation (2,5 kN/m²)", StairUsage.Habitation), ("Bureaux / administration (3,0)", StairUsage.Bureaux),
            ("Recevant du public (4,0)", StairUsage.Public), ("Industriel / stockage (5,0)", StairUsage.Industrie),
        }, () => d.Usage, v => d.Usage = v);
        _form.Num("Charge d'exploitation imposée", () => d.QKnPerM2, v => d.QKnPerM2 = v, "0 = selon l'usage", "kN/m²");

        _form.Section("Géométrie", "Sol fini à sol fini. Les contremarches sont calculées pour rester entre 14 et 20 cm et la formule de Blondel 59 ≤ 2h + g ≤ 64 cm est contrôlée.");
        _form.Num("Hauteur à franchir", () => d.HeightM, v => d.HeightM = v, "Distance verticale entre les sols finis de départ et d'arrivée", "m");
        _form.Num("Emmarchement (largeur)", () => d.WidthM, v => d.WidthM = v, null, "m");
        _form.Num("Contremarche visée", () => d.TargetRiserCm, v => d.TargetRiserCm = v, "16 à 18 cm en habitation", "cm");
        _form.Num("Giron visé (0 = Blondel)", () => d.TargetTreadCm, v => d.TargetTreadCm = v, "0 : le giron est déduit de 2h + g = 63 cm", "cm");
        _form.Num("Reculée disponible (0 = libre)", () => d.RunM, v => d.RunM = v, "Longueur horizontale disponible : impose le giron", "m");
        _form.Num("Palier de départ attenant", () => d.StartLandingM, v => d.StartLandingM = v, "Dalle prolongeant la volée côté départ", "m");
        if (d.Layout is StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier or StairLayout.DoubleQuartPalier)
            _form.Num("Palier intermédiaire (dans le sens de la volée)", () => d.MidLandingM, v => d.MidLandingM = v, null, "m");
        _form.Num("Palier d'arrivée", () => d.EndLandingM, v => d.EndLandingM = v, null, "m");
        if (d.Layout is StairLayout.DemiPalier or StairLayout.DemiBalance)
            _form.Num("Jour entre volées (demi-tournant)", () => d.GapM, v => d.GapM = v, null, "m");
        if (d.Layout == StairLayout.Helicoidal)
        {
            _form.Num("Hélicoïdal : rayon intérieur (noyau)", () => d.InnerRadiusM, v => d.InnerRadiusM = v, null, "m");
            _form.Num("Hélicoïdal : angle total", () => d.TurnAngleDeg, v => d.TurnAngleDeg = v, "270° = trois quarts de tour ; 360° = un tour complet", "°");
        }
        _form.Num("Épaisseur de la paillasse (0 = auto)", () => d.SlabThicknessCm, v => d.SlabThicknessCm = v, "Automatique : L/25 arrondi au cm (L/30 ≤ e ≤ L/20)", "cm");
        _form.Check("Marches pleines en béton (poids des marches)", () => d.StepsFilled, v => d.StepsFilled = v);

        _form.Section("Revêtements et charges permanentes");
        _form.Num("Carrelage / marbre sur marche", () => d.TreadCoverCm, v => d.TreadCoverCm = v, null, "cm");
        _form.Num("Revêtement de contremarche", () => d.RiserCoverCm, v => d.RiserCoverCm = v, null, "cm");
        _form.Num("Densité du revêtement", () => d.CoverDensity, v => d.CoverDensity = v, null, "kN/m³");
        _form.Num("Mortier de pose", () => d.MortarCm, v => d.MortarCm = v, null, "cm");
        _form.Num("Enduit sous paillasse", () => d.PlasterCm, v => d.PlasterCm = v, null, "cm");
        _form.Num("Densité des marches (béton)", () => d.StepDensity, v => d.StepDensity = v, "22 béton banché ; 24-25 béton armé", "kN/m³");
        _form.Num("Garde-corps", () => d.RailingKnPerM, v => d.RailingKnPerM = v, "Poids linéaire des garde-corps", "kN/m");

        _form.Section("Appuis et béton armé", "Appui simple : pas d'encastrement (chapeaux minimaux 15 % de M0). Semi-encastré : moment d'appui = facteur x M0. Encastré : calcul par la méthode des forces.");
        var ends = new (string, StairEnd)[] { ("Appui simple", StairEnd.Simple), ("Semi-encastré", StairEnd.SemiEncastre), ("Encastré", StairEnd.Encastre) };
        _form.Combo("Appui de départ", ends, () => d.StartSupport, v => d.StartSupport = v);
        _form.Combo("Appui d'arrivée", ends, () => d.EndSupport, v => d.EndSupport = v);
        _form.Num("Facteur de semi-encastrement", () => d.SemiFactor, v => d.SemiFactor = v, "0,2 à 0,5", "x M0");
        _form.Num("Enrobage (axe des aciers)", () => d.CoverCm, v => d.CoverCm = v, null, "cm");
        _form.Combo("Fissuration", new (string, CrackingClass)[] { ("Peu préjudiciable", CrackingClass.PeuPrejudiciable), ("Préjudiciable", CrackingClass.Prejudiciable), ("Très préjudiciable", CrackingClass.TresPrejudiciable) }, () => d.Crack, v => d.Crack = v);

        _form.Section("Position dans le projet (pour les plans)");
        _form.Num("X de départ", () => d.X, v => d.X = v, null, "m");
        _form.Num("Y de départ", () => d.Y, v => d.Y = v, null, "m");
        _form.Num("Z du départ", () => d.Z, v => d.Z = v, null, "m");
        _form.Changed += Recompute;
        _formHost.Content = _form.Root;
    }

    private void Recompute()
    {
        try
        {
            var rc = (DesignCodeRegistry.Get(_model.RcCodeId) as IReinforcedConcreteCode) ?? (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
            var r = StairDesigner.Design(_work, rc, _model.Fc28, _model.Fe, _model.Settings);
            _report.Text = r.Report;
            var o = new AnalysisOutput(); o.Stairs.Add(r);
            var sh = StairSheets.Build(o).FirstOrDefault();
            if (sh != null) { sh.Number = "-"; _preview.Show(sh); }
            _status.Text = r.Ok ? $"✔ Conforme ({rc.Id})" : "⚠ À vérifier : " + (r.Warnings.FirstOrDefault() ?? r.Elements.SelectMany(e => e.Notes).FirstOrDefault() ?? "");
            _status.Foreground = r.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
        }
        catch (Exception ex) { _status.Text = "Erreur : " + ex.Message; _status.Foreground = Brushes.Firebrick; }
    }

    private void Save()
    {
        var copy = _work.Clone();
        string msg = _apply(m =>
        {
            int i = m.Stairs.FindIndex(x => x.Name == copy.Name);
            if (i >= 0) m.Stairs[i] = copy; else m.Stairs.Add(copy);
            return $"Escalier {copy.Name} enregistré dans le projet (calcul avec F5, plans avec « PLANS »).";
        });
        _status.Text = msg; _status.Foreground = Brushes.DarkGreen;
        FillList();
    }

    private void Delete()
    {
        string name = _work.Name;
        if (!_model.Stairs.Any(x => x.Name == name)) return;
        if (MessageBox.Show($"Supprimer l'escalier {name} du projet ?", "Escaliers", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        _apply(m => { m.Stairs.RemoveAll(x => x.Name == name); return $"Escalier {name} supprimé."; });
        _work = _model.Stairs.Count > 0 ? _model.Stairs[0].Clone() : NewDef();
        FillList(); RebuildForm(); Recompute();
    }
}
