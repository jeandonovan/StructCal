using System.Windows;
using System.Windows.Media;
using StructCalc.Engine;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

/// <summary>Semelles dimensionnées par le calcul, dessinées en 3D sous leurs poteaux : bloc rectangulaire ou semelle à glacis.</summary>
/// <summary>Semelle sous un nœud d'appui, désignée dans la vue (sélection, clic droit).</summary>
public sealed class FootingRef
{
    public int NodeId;
    public string Name = "";
}

public sealed partial class ModelViewport
{
    /// <summary>Afficher les semelles dimensionnées (visibles après le calcul).</summary>
    public bool ShowFootings { get; set; } = true;

    private readonly Dictionary<int, FootingRef> _footRefs = new();
    /// <summary>Objet sélectionnable représentant la semelle sous un nœud (instance stable d'un dessin à l'autre).</summary>
    private FootingRef FootingRefOf(int node)
    {
        if (!_footRefs.TryGetValue(node, out var r)) _footRefs[node] = r = new FootingRef { NodeId = node, Name = "S" + node };
        return r;
    }

    private static Color FootingC => ElementPalette.Get("Footing");

    private void DrawFootings(DrawingContext dc, StructureInfo info)
    {
        if (!ShowFootings || Model == null || Output == null) return;
        var list = FootingPlacement.From(Model, Output);
        if (list.Count == 0) return;
        bool persp = UsePersp;
        var g = ViewDir();
        var cam = CameraPos();
        double near = 0.08 * _camDist;
        bool cull = Solid;
        var items = new List<(Point[] Pts, double Depth, Vec3 N, Color C, int Mask, int Node)>();
        foreach (var pf in list)
        {
            if (NodeHidden(pf.NodeId, info) || FootingHidden(pf.NodeId)) continue;
            var baseC = pf.Ok ? FootingC : Mix(FootingC, Color.FromRgb(0xD3, 0x2F, 0x2F), 0.45);
            foreach (var f in FootingSolids.Build(pf.X, pf.Y, pf.ZTop, pf.A, pf.B, pf.H, pf.ColA, pf.ColB, pf.Glacis, pf.EdgeCm, Model.FootingAlignX, Model.FootingAlignY))
            {
                bool front = persp ? f.N.Dot(f.P[0] - cam) < 0 : f.N.Dot(g) < 0;
                if (cull && !front) continue;
                var pts = new Point[f.P.Length];
                double dsum = 0; bool bad = false;
                for (int i = 0; i < pts.Length; i++)
                {
                    pts[i] = Proj(f.P[i], out double d);
                    dsum += d;
                    if (persp && d < near) { bad = true; break; }
                }
                if (bad) continue;
                items.Add((pts, dsum / pts.Length, f.N, baseC, f.EdgeMask, pf.NodeId));
                AddElemHit(ElementKey.FootingAt(pf.NodeId), pts, dsum / pts.Length, Solid);
            }
        }
        if (cull) items.Sort((a, b) => b.Depth.CompareTo(a.Depth));          // du plus loin au plus proche
        foreach (var it in items)
        {
            Brush? fill; Pen? seam; Pen edge;
            switch (RenderStyle)
            {
                case DisplayStyle.Fil:
                case DisplayStyle.Trait:
                    fill = null; seam = null; edge = PenOf(Mix(it.C, Color.FromRgb(0x10, 0x20, 0x30), 0.4), 1.1); break;
                case DisplayStyle.Cache:
                    fill = BrushOf(Colors.White); seam = PenOf(Colors.White, 0.8); edge = PenOf(Color.FromRgb(0x10, 0x10, 0x10), 1.0); break;
                case DisplayStyle.Ferraille:
                case DisplayStyle.RayonsX:
                    fill = BrushOf(Color.FromArgb(46, it.C.R, it.C.G, it.C.B)); seam = null; edge = PenOf(Mix(it.C, Color.FromRgb(0x10, 0x20, 0x30), 0.5), 0.9); break;
                default:
                {
                    var c = Shade(it.C, it.N);
                    fill = BrushOf(c); seam = PenOf(c, 0.8);
                    edge = PenOf(Color.FromArgb(190, 0x20, 0x28, 0x30), 0.7);
                    break;
                }
            }
            if (fill != null) dc.DrawGeometry(fill, seam, Geo(it.Pts));
            int n = it.Pts.Length;
            for (int i = 0; i < n; i++) dc.DrawLine(edge, it.Pts[i], it.Pts[(i + 1) % n]);
        }
    }

    private void DrawFootingLabels(StructureInfo info)
    {
        if (!ShowFootings || !ShowLabels || Model == null || Output == null) return;
        foreach (var pf in FootingPlacement.From(Model, Output))
        {
            if (NodeHidden(pf.NodeId, info) || FootingHidden(pf.NodeId)) continue;
            var (ox, oy) = FootingSolids.Shift(pf.A, pf.B, pf.ColA, pf.ColB, pf.Glacis, Model.FootingAlignX, Model.FootingAlignY);
            var p = S(pf.X + ox + pf.A / 2, pf.Y + oy - pf.B / 2, pf.ZTop - pf.H);
            Text($"{pf.Name}  {pf.A:0.00} x {pf.B:0.00} x {pf.H:0.00} m" + (pf.Glacis ? "  glacis" : "") + (pf.FromAssistant ? "  (assistant)" : ""), p.X + 4, p.Y + 2, 10, Dark, Br("#CCFFFFFF"), true);
        }
    }
}
