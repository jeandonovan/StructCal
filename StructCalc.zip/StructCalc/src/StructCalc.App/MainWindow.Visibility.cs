using System.Windows;
using System.Windows.Controls;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Masquer / isoler / tout afficher : menu Modifier, raccourcis (H, I, Ctrl+H) et clic droit sur tous les éléments.
/// Ces états ne changent ni le modèle ni le calcul : ils servent seulement à y voir clair dans la vue.</summary>
public partial class MainWindow
{
    private static readonly (string Key, string Label)[] VisCats =
    {
        ("columns", "Poteaux"), ("beams", "Poutres"), ("concrete", "Barres en béton armé"), ("steel", "Barres en acier"),
        ("slabs", "Dalles"), ("walls", "Voiles et murs"), ("stairs", "Escaliers"), ("footings", "Semelles, radiers et semelles filantes"),
    };

    private void InitVisibility()
    {
        _vp.VisibilityChanged += () => { StatusMid.Text = BaseStatusMid(); };
        FillCategoryMenus(MenuHideCats.Items, false);
        FillCategoryMenus(MenuIsoCats.Items, true);
    }

    private void FillCategoryMenus(ItemCollection items, bool isolate)
    {
        items.Clear();
        foreach (var (key, label) in VisCats)
        {
            string k = key;
            items.Add(Mi(label, () => CategoryCommand(k, isolate)));
        }
    }

    /// <summary>Masque (ou réaffiche si tout est déjà masqué) une catégorie, ou l'isole.</summary>
    private void CategoryCommand(string key, bool isolate)
    {
        var cat = _vp.Category(key);
        int total = cat.Members.Count + cat.Nodes.Count + cat.Objs.Count;
        string label = VisCats.First(c => c.Key == key).Label.ToLowerInvariant();
        if (total == 0) { Say($"Il n'y a pas de {label} dans le modèle."); return; }
        if (isolate)
        {
            _vp.Isolate(cat.Members, cat.Nodes, cat.Objs);
            Say($"Isolé : {label} seulement ({total} élément(s)). Ctrl+H ou Modifier > Tout afficher pour tout réafficher.");
            return;
        }
        bool allHidden = cat.Members.All(_vp.HiddenMembers.Contains) && cat.Nodes.All(_vp.HiddenNodes.Contains) && cat.Objs.All(_vp.IsObjHidden);
        if (allHidden) { _vp.Unhide(cat.Members, cat.Nodes, cat.Objs); Say($"{char.ToUpper(label[0])}{label[1..]} : de nouveau visibles."); }
        else { _vp.Hide(cat.Members, cat.Nodes, cat.Objs); Say($"{char.ToUpper(label[0])}{label[1..]} masqué(s) ({total}). Même commande pour les réafficher, ou Ctrl+H pour tout afficher."); }
    }

    private static List<object> ExpandShells(IEnumerable<object> objs, StructModel m)
    {
        var res = new List<object>();
        foreach (var o in objs)
        {
            if (o is ShellPanel sh) res.AddRange(m.Shells.Where(q => q.Name == sh.Name));   // un voile ou une dalle maillée = toutes ses mailles
            else res.Add(o);
        }
        return res;
    }

    private bool _levelsHiddenNow => _panel != null && _panel.Hidden.Count > 0;

    /// <summary>Masque la sélection de la vue (plus les éléments donnés, par ex. le nœud ou la coque visés par le clic droit).</summary>
    private void HideSelection(IEnumerable<int>? nodes = null, IEnumerable<object>? objs = null)
    {
        var sel = _vp.SelectionForVisibility();
        var n = sel.Nodes.Concat(nodes ?? Array.Empty<int>()).Distinct().ToList();
        var o = ExpandShells(sel.Objs.Concat(objs ?? Array.Empty<object>()).Distinct(), _model);
        if (sel.Members.Count + n.Count + o.Count == 0)
        {
            Say("Rien à masquer : sélectionnez d'abord des barres, des nœuds, une dalle, un escalier ou une semelle (clic, Ctrl+clic, rectangle), puis Masquer (touche H).");
            return;
        }
        int added = _vp.Hide(sel.Members, n, o);
        Say(added == 0 ? "Ces éléments sont déjà masqués." : $"{added} élément(s) masqué(s). Ctrl+H (ou Modifier > Tout afficher) pour les réafficher ; le modèle et le calcul ne changent pas.");
    }

    private void IsolateSelection(IEnumerable<int>? nodes = null, IEnumerable<object>? objs = null)
    {
        var sel = _vp.SelectionForVisibility();
        var n = sel.Nodes.Concat(nodes ?? Array.Empty<int>()).Distinct().ToList();
        var o = ExpandShells(sel.Objs.Concat(objs ?? Array.Empty<object>()).Distinct(), _model);
        if (sel.Members.Count + n.Count + o.Count == 0)
        {
            Say("Rien à isoler : sélectionnez d'abord ce que vous voulez garder à l'écran, puis Isoler (touche I).");
            return;
        }
        _vp.Isolate(sel.Members, n, o);
        Say($"Isolé : {sel.Members.Count + n.Count + o.Count} élément(s) gardé(s), le reste est masqué. Ctrl+H pour tout réafficher.");
    }

    private void ShowAllHidden()
    {
        if (!_vp.HasHidden && !_levelsHiddenNow) { Say("Rien n'est masqué."); return; }
        _vp.ShowAll();
        if (_levelsHiddenNow) _panel!.ShowAllLevels();
        StatusMid.Text = BaseStatusMid();
        Say("Tout est de nouveau affiché.");
    }

    private void InvertVisibility()
    {
        _vp.InvertVisibility();
        StatusMid.Text = BaseStatusMid();
        Say("Affichage inversé : ce qui était masqué est visible et inversement.");
    }

    // ------------------------------------------------------------------ menu Modifier
    private void HideSel_Click(object sender, RoutedEventArgs e) => HideSelection();
    private void IsolateSel_Click(object sender, RoutedEventArgs e) => IsolateSelection();
    private void ShowAllHidden_Click(object sender, RoutedEventArgs e) => ShowAllHidden();
    private void InvertVis_Click(object sender, RoutedEventArgs e) => InvertVisibility();

    // ------------------------------------------------------------------ clic droit : mêmes commandes dans tous les menus
    /// <summary>Ajoute en bas d'un menu contextuel : Masquer, Isoler, Tout afficher, et les catégories.</summary>
    private void AddVisibilityItems(ContextMenu cm, IEnumerable<int>? nodes = null, object? obj = null)
    {
        var objs = obj == null ? null : new[] { obj };
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Masquer", () => HideSelection(nodes, objs), true, "H"));
        cm.Items.Add(Mi("Isoler (masquer tout le reste)", () => IsolateSelection(nodes, objs), true, "I"));
        cm.Items.Add(Mi("Tout afficher", ShowAllHidden, _vp.HasHidden || _levelsHiddenNow, "Ctrl+H"));
        var hide = new MenuItem { Header = "Masquer / réafficher une catégorie" };
        FillCategoryMenus(hide.Items, false);
        var iso = new MenuItem { Header = "Isoler une catégorie" };
        FillCategoryMenus(iso.Items, true);
        cm.Items.Add(hide); cm.Items.Add(iso);
        cm.Items.Add(Mi("Inverser l'affichage (masqué ↔ visible)", InvertVisibility, _vp.HasHidden));
    }
}
