using System.Windows;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Résultats en 3D : modèle ferraillé (barres, chapeaux, cadres) et déformée de la structure.</summary>
public sealed partial class ModelViewport
{
    // ---- ferraillage 3D
    public bool RebarOnlySelection { get; set; }
    public bool ShowStirrups { get; set; } = true;
    private List<RebarPath>? _rebars;
    private AnalysisOutput? _rebarFor;
    private StructModel? _rebarModel;

    /// <summary>Ferraillage 3D du résultat courant (mis en cache tant que le résultat ne change pas).</summary>
    public List<RebarPath> Rebars
    {
        get
        {
            if (Model == null || Output == null) return new List<RebarPath>();
            if (_rebars == null || !ReferenceEquals(_rebarFor, Output) || !ReferenceEquals(_rebarModel, Model))
            {
                try { _rebars = RebarModel.Build(Model, Output); }
                catch { _rebars = new List<RebarPath>(); }
                _rebarFor = Output; _rebarModel = Model;
            }
            return _rebars;
        }
    }

    private static Color RebarColor(RebarRole r) => r switch
    {
        RebarRole.Bottom => Color.FromRgb(0xD3, 0x2F, 0x2F),
        RebarRole.Top => Color.FromRgb(0x15, 0x65, 0xC0),
        RebarRole.Mounting => Color.FromRgb(0x7B, 0x1F, 0xA2),
        RebarRole.ColumnBar => Color.FromRgb(0xE6, 0x51, 0x00),
        RebarRole.Stirrup => Color.FromRgb(0x2E, 0x7D, 0x32),
        _ => Color.FromRgb(0x00, 0x83, 0x8F),
    };

    private static Color Shade(Color c, double k)
    {
        // k > 1 éclaircit, k < 1 assombrit
        byte f(byte v) => (byte)Math.Clamp(k >= 1 ? v + (255 - v) * (k - 1) : v * k, 0, 255);
        return Color.FromRgb(f(c.R), f(c.G), f(c.B));
    }

    private static readonly DashStyle RibDash = new(new double[] { 0.45, 1.15 }, 0);

    private readonly Dictionary<int, Pen> _ribPens = new();
    private Pen RibPen(double th)
    {
        int key = (int)(th * 10);
        if (!_ribPens.TryGetValue(key, out var p))
        {
            if (_ribPens.Count > 300) _ribPens.Clear();
            p = new Pen(BrushOf(Color.FromArgb(120, 0, 0, 0)), th * 0.85)
            { DashStyle = RibDash, DashCap = PenLineCap.Flat, StartLineCap = PenLineCap.Flat, EndLineCap = PenLineCap.Flat, LineJoin = PenLineJoin.Round };
            p.Freeze();
            _ribPens[key] = p;
        }
        return p;
    }

    private sealed class RebarDraw { public StreamGeometry G = null!; public double Th; public RebarRole Role; public double Depth; }

    /// <summary>Barres dessinées en volume : contour sombre, corps coloré, reflet clair d'un côté, ombre de l'autre et nervures (acier HA).
    /// Les barres sont triées de la plus lointaine à la plus proche pour que les proches recouvrent les lointaines.</summary>
    private void DrawRebar(DrawingContext dc, StructureInfo info)
    {
        if (Model == null || Output == null) return;
        bool onlySel = RebarOnlySelection && _sel.Count > 0;
        var items = new List<RebarDraw>();
        foreach (var rb in Rebars)
        {
            bool stir = rb.Role == RebarRole.Stirrup || rb.Role == RebarRole.Tie;
            if (stir && !ShowStirrups) continue;
            if (onlySel && !_sel.Contains(rb.MemberId)) continue;
            if (MemberHidden(rb.MemberId, info)) continue;
            // diamètre réel à l'échelle de la vue (au moins 2,2 px pour rester visible, 16 px au plus)
            double th = Math.Clamp(rb.DiaMm / 1000.0 * _scale, 2.2, 16.0);
            var pts = new List<Point>(rb.Pts.Length + 1);
            bool bad = false;
            double near = 0.08 * _camDist, dsum = 0;
            foreach (var p in rb.Pts)
            {
                var q = Proj(p, out double d);
                if (UsePersp && d < near) { bad = true; break; }
                pts.Add(q); dsum += d;
            }
            if (bad || pts.Count < 2) continue;
            if (rb.Closed && pts.Count > 2) pts.Add(pts[0]);
            var sg = new StreamGeometry();
            using (var ctx = sg.Open())
            {
                ctx.BeginFigure(pts[0], false, false);
                for (int i = 1; i < pts.Count; i++) ctx.LineTo(pts[i], true, false);
            }
            sg.Freeze();
            items.Add(new RebarDraw { G = sg, Th = th, Role = rb.Role, Depth = dsum / rb.Pts.Length });
        }
        items.Sort((x, y) => y.Depth.CompareTo(x.Depth));     // loin d'abord

        foreach (var it in items)
        {
            var col = RebarColor(it.Role);
            double th = it.Th;
            if (th < 3.0)
            {
                // trop fin pour un relief : contour + trait
                dc.DrawGeometry(null, PenOf(Shade(col, 0.55), th + 1.0), it.G);
                dc.DrawGeometry(null, PenOf(col, th), it.G);
                continue;
            }
            dc.DrawGeometry(null, PenOf(Shade(col, 0.40), th + 1.6), it.G);                 // contour / ombre portée
            dc.DrawGeometry(null, PenOf(Shade(col, 0.72), th), it.G);                        // flanc ombré
            dc.DrawGeometry(null, PenOf(col, th * 0.72), it.G);                              // corps
            dc.DrawGeometry(null, RibPen(th), it.G);                                         // nervures transversales du HA
            dc.PushTransform(new TranslateTransform(-th * 0.17, -th * 0.17));                // reflet décalé vers la lumière
            dc.DrawGeometry(null, PenOf(Color.FromArgb(185, 255, 255, 255), Math.Max(0.9, th * 0.22)), it.G);
            dc.Pop();
        }
    }

    public string RebarStats()
    {
        var rb = Rebars;
        if (rb.Count == 0) return "";
        double kg = RebarModel.MassKg(rb);
        int bars = rb.Count(x => x.Role != RebarRole.Stirrup && x.Role != RebarRole.Tie);
        int stir = rb.Count - bars;
        return $"Ferraillage 3D : {bars} barres, {stir} cadres/épingles, {kg:0} kg d'acier";
    }

    // ---- déformée
    public bool ShowDeformed { get; set; }
    public double DeformScale { get; set; } = 0;     // 0 = automatique

    /// <summary>Amplification automatique : le plus grand déplacement dessiné vaut environ 6 % de la taille de la structure.</summary>
    public double AutoDeformScale()
    {
        var map = DeformMap();
        var sb = SceneBounds(false);
        if (map == null || sb == null || map.Count == 0) return 1;
        double umax = map.Values.Select(v => v.Length < 3 ? 0 : Math.Sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])).DefaultIfEmpty(0).Max();
        if (umax < 1e-9) return 1;
        var d = sb.Value.Max - sb.Value.Min;
        double size = Math.Max(Math.Max(d.X, d.Y), Math.Max(d.Z, 1));
        return Math.Max(1, 0.06 * size / umax);
    }

    private void DrawDeformed(DrawingContext dc, StructureInfo info)
    {
        var defMap = DeformMap();
        if (Model == null || defMap == null || defMap.Count == 0) return;
        double k = (DeformScale > 0 ? DeformScale : AutoDeformScale()) * DeformPhase;
        var nodes = Model.Nodes.GroupBy(n => n.Id).ToDictionary(x => x.Key, x => x.First());
        var pen = PenOf(Color.FromRgb(0xE0, 0x30, 0x80), 2.2);
        var ghost = PenOf(Color.FromArgb(90, 0x60, 0x60, 0x60), 1.0);
        foreach (var mem in Model.Members)
        {
            if (MemberHidden(mem.Id, info)) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
            if (!defMap.TryGetValue(na.Id, out var di) || !defMap.TryGetValue(nb.Id, out var dj) || di.Length < 6 || dj.Length < 6) continue;
            var a = new Vec3(na.X, na.Y, na.Z); var b = new Vec3(nb.X, nb.Y, nb.Z);
            double L = (b - a).Length; if (L < 1e-6) continue;
            var ex = (b - a) * (1.0 / L);
            var ti = new Vec3(di[3], di[4], di[5]).Cross(ex) * L;      // pente de la déformée à chaque extrémité (rotation x tangente)
            var tj = new Vec3(dj[3], dj[4], dj[5]).Cross(ex) * L;
            var ui = new Vec3(di[0], di[1], di[2]); var uj = new Vec3(dj[0], dj[1], dj[2]);
            const int N = 16;
            var pts = new Point[N + 1];
            for (int i = 0; i <= N; i++)
            {
                double t = (double)i / N, t2 = t * t, t3 = t2 * t;
                double h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
                var u = ui * h00 + ti * h10 + uj * h01 + tj * h11;
                var p = a + (b - a) * t + u * k;
                pts[i] = Proj(p, out _);
            }
            var sg = new StreamGeometry();
            using (var ctx = sg.Open())
            {
                ctx.BeginFigure(pts[0], false, false);
                for (int i = 1; i <= N; i++) ctx.LineTo(pts[i], true, false);
            }
            sg.Freeze();
            dc.DrawLine(ghost, Proj(a, out _), Proj(b, out _));
            dc.DrawGeometry(null, pen, sg);
        }
    }
}
