using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using Shapes = System.Windows.Shapes;

namespace StructCalc.UI;

/// <summary>Palette de l'écran d'accueil (sombre premium ou claire). Toutes les brosses sont « fixes » : le thème automatique de l'application ne les inverse pas.</summary>
internal sealed class Pal
{
    public bool Dark;
    public Color Bg, Side, Card, Surface, Line, Text, Muted, Faint, Accent, AccentHover, OnAccent, Ok, Warn, Err;
    public Brush BBg = null!, BSide = null!, BCard = null!, BSurface = null!, BLine = null!, BLineHover = null!, BText = null!, BMuted = null!, BFaint = null!,
        BAccent = null!, BOnAccent = null!, BOk = null!, BWarn = null!, BErr = null!, BAccentSoft = null!, BAccentLine = null!, BScrim = null!, BHover = null!, BErrSoft = null!, BTransparent = null!;

    private static Color C(string h) => (Color)ColorConverter.ConvertFromString(h)!;
    public static Color Alpha(Color c, byte a) => Color.FromArgb(a, c.R, c.G, c.B);
    public static Color Mix(Color a, Color b, double t) =>
        Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));

    public static Pal Get(bool dark)
    {
        var p = dark
            ? new Pal
            {
                Dark = true, Bg = C("#0B0F14"), Side = C("#0D1218"), Card = C("#121821"), Surface = C("#161D27"), Line = C("#1F2937"),
                Text = C("#F8FAFC"), Muted = C("#94A3B8"), Faint = C("#64748B"), Accent = C("#38BDF8"), AccentHover = C("#7DD3FC"), OnAccent = C("#06141F"),
                Ok = C("#22C55E"), Warn = C("#F59E0B"), Err = C("#EF4444")
            }
            : new Pal
            {
                Dark = false, Bg = C("#F4F6FA"), Side = C("#FFFFFF"), Card = C("#FFFFFF"), Surface = C("#EEF2F7"), Line = C("#E2E8F0"),
                Text = C("#0F172A"), Muted = C("#5B6B82"), Faint = C("#8794A8"), Accent = C("#0284C7"), AccentHover = C("#0369A1"), OnAccent = C("#FFFFFF"),
                Ok = C("#16A34A"), Warn = C("#D97706"), Err = C("#DC2626")
            };
        p.Seal();
        return p;
    }

    private void Seal()
    {
        Brush F(Color c) => Theme.Fixed(c);
        BBg = F(Bg); BSide = F(Side); BCard = F(Card); BSurface = F(Surface); BLine = F(Line); BLineHover = F(Alpha(Muted, 0x90));
        BText = F(Text); BMuted = F(Muted); BFaint = F(Faint); BAccent = F(Accent); BOnAccent = F(OnAccent);
        BOk = F(Ok); BWarn = F(Warn); BErr = F(Err);
        BAccentSoft = F(Alpha(Accent, 0x26)); BAccentLine = F(Alpha(Accent, 0x8C)); BErrSoft = F(Alpha(Err, 0x1F));
        BScrim = F(Dark ? Color.FromArgb(0xC0, 0x04, 0x07, 0x0B) : Color.FromArgb(0x99, 0x0F, 0x17, 0x2A));
        BHover = F(Alpha(Text, (byte)(Dark ? 0x0F : 0x0B)));
        BTransparent = F(Colors.Transparent);
    }
}

internal enum BtnKind { Primary, Secondary, Ghost, Quiet, Danger }

/// <summary>Briques visuelles de l'écran d'accueil : textes, icônes vectorielles, boutons à survol animé, cartes, animations courtes (150 à 250 ms).</summary>
internal static class Wk
{
    public static readonly FontFamily Font = new("Segoe UI Variable Text, Segoe UI, Arial");
    private static readonly IEasingFunction EaseOut = new CubicEase { EasingMode = EasingMode.EaseOut };

    private static Duration Ms(double ms) => new(TimeSpan.FromMilliseconds(ms));

    // ------------------------------------------------------------------ texte
    public static TextBlock Txt(string s, double size, Brush fg, FontWeight? w = null, bool trim = false, bool wrap = false)
    {
        var t = new TextBlock { Text = s, FontSize = size, Foreground = fg, FontWeight = w ?? FontWeights.Normal, FontFamily = Font };
        if (trim) t.TextTrimming = TextTrimming.CharacterEllipsis;
        if (wrap) t.TextWrapping = TextWrapping.Wrap;
        return t;
    }

    // ------------------------------------------------------------------ icônes vectorielles (grille 24 x 24, traits arrondis)
    private static readonly Dictionary<string, string> IconPaths = new()
    {
        ["plus"] = "M12,5 V19 M5,12 H19",
        ["folder"] = "M3,7 a2,2 0 0 1 2,-2 h4 l2,2 h8 a2,2 0 0 1 2,2 v8 a2,2 0 0 1 -2,2 H5 a2,2 0 0 1 -2,-2 Z",
        ["import"] = "M12,3 V15 M7,10 L12,15 L17,10 M4,17 V19 a2,2 0 0 0 2,2 H18 a2,2 0 0 0 2,-2 V17",
        ["home"] = "M3,11 L12,3 L21,11 M5,9.5 V20 H10 V14 H14 V20 H19 V9.5",
        ["clock"] = "M3,12 a9,9 0 1 0 18,0 a9,9 0 1 0 -18,0 M12,7 V12 L15.5,14",
        ["layers"] = "M12,3 L21,8 L12,13 L3,8 Z M3,12 L12,17 L21,12 M3,16 L12,21 L21,16",
        ["sliders"] = "M4,7 H11 M15,7 H20 M4,17 H8 M12,17 H20 M13,4.5 V9.5 M10,14.5 V19.5",
        ["help"] = "M3,12 a9,9 0 1 0 18,0 a9,9 0 1 0 -18,0 M9.5,9.5 a2.5,2.5 0 1 1 3.5,2.3 c-0.7,0.4 -1,0.9 -1,1.7 M12,17 V17.01",
        ["sun"] = "M8,12 a4,4 0 1 0 8,0 a4,4 0 1 0 -8,0 M12,2.5 V4.5 M12,19.5 V21.5 M4.9,4.9 L6.3,6.3 M17.7,17.7 L19.1,19.1 M2.5,12 H4.5 M19.5,12 H21.5 M4.9,19.1 L6.3,17.7 M17.7,6.3 L19.1,4.9",
        ["moon"] = "M20,14.5 A8,8 0 1 1 9.5,4 A6.5,6.5 0 0 0 20,14.5 Z",
        ["frame"] = "M5,21 V6 H19 V21 M5,13 H19 M2.5,21 H21.5 M12,6 V13",
        ["dots"] = "M5,12 H5.01 M12,12 H12.01 M19,12 H19.01",
        ["trash"] = "M4,7 H20 M10,11 V17 M14,11 V17 M6,7 L7,20 H17 L18,7 M9,7 V4 H15 V7",
        ["copy"] = "M9,9 H20 V21 H9 Z M5,15 V3 H15",
        ["edit"] = "M4,20 L8,19 L19.5,7.5 L16.5,4.5 L5,16 Z M14.5,6.5 L17.5,9.5",
        ["x"] = "M6,6 L18,18 M18,6 L6,18",
        ["alert"] = "M12,3.5 L21.5,20 H2.5 Z M12,10 V14 M12,17 V17.01",
        ["check"] = "M5,12.5 L10,17.5 L19,7",
        ["mail"] = "M3,6 H21 V18 H3 Z M3,6 L12,13 L21,6",
        ["book"] = "M5,4 H18 V20 H7 a2,2 0 0 1 -2,-2 Z M5,18 a2,2 0 0 1 2,-2 H18",
        ["info"] = "M3,12 a9,9 0 1 0 18,0 a9,9 0 1 0 -18,0 M12,11 V16.5 M12,7.5 V7.51",
        ["building"] = "M6,21 V4 H18 V21 M3,21 H21 M10,8 H14 M10,12 H14 M10,16 H14",
        ["revit"] = "M4,6 H20 V18 H4 Z M4,10 H20 M9,10 V18",
        ["file"] = "M6,3 H14 L19,8 V21 H6 Z M14,3 V8 H19",
    };

    public static FrameworkElement Icon(string key, double size, Brush stroke, double thickness = 1.7)
    {
        var path = new Shapes.Path
        {
            Data = Geometry.Parse(IconPaths.TryGetValue(key, out var d) ? d : IconPaths["file"]),
            Stroke = stroke, StrokeThickness = thickness, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, StrokeLineJoin = PenLineJoin.Round
        };
        var canvas = new Canvas { Width = 24, Height = 24 };
        canvas.Children.Add(path);
        return new Viewbox { Width = size, Height = size, Child = canvas, IsHitTestVisible = false };
    }

    /// <summary>Change la couleur d'une icône créée par <see cref="Icon"/>.</summary>
    public static void Tint(FrameworkElement icon, Brush b)
    {
        if (icon is Viewbox { Child: Canvas { Children.Count: > 0 } c } && c.Children[0] is Shapes.Path p) p.Stroke = b;
    }

    // ------------------------------------------------------------------ boutons
    private static readonly Dictionary<string, ControlTemplate> Templates = new();

    private static string Hex(Color c) => c.ToString(CultureInfo.InvariantCulture);

    private static ControlTemplate Template(string key, Color n, Color h, Color pr, Color b, Color bh, Color focus, double radius)
    {
        if (Templates.TryGetValue(key, out var t)) return t;
        string r = radius.ToString(CultureInfo.InvariantCulture);
        string Anim(string name, Color to) => $"<ColorAnimation Storyboard.TargetName='{name}' Storyboard.TargetProperty='Color' To='{Hex(to)}' Duration='0:0:0.15'/>";
        string xaml = $@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='Button'>
  <Border x:Name='bd' CornerRadius='{r}' BorderThickness='1' Padding='{{TemplateBinding Padding}}' SnapsToDevicePixels='True'>
    <Border.Background><SolidColorBrush x:Name='bg' Color='{Hex(n)}'/></Border.Background>
    <Border.BorderBrush><SolidColorBrush x:Name='bb' Color='{Hex(b)}'/></Border.BorderBrush>
    <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/>
  </Border>
  <ControlTemplate.Triggers>
    <Trigger Property='IsMouseOver' Value='True'>
      <Trigger.EnterActions><BeginStoryboard><Storyboard>{Anim("bg", h)}{Anim("bb", bh)}</Storyboard></BeginStoryboard></Trigger.EnterActions>
      <Trigger.ExitActions><BeginStoryboard><Storyboard>{Anim("bg", n)}{Anim("bb", b)}</Storyboard></BeginStoryboard></Trigger.ExitActions>
    </Trigger>
    <Trigger Property='IsPressed' Value='True'>
      <Trigger.EnterActions><BeginStoryboard><Storyboard>{Anim("bg", pr)}</Storyboard></BeginStoryboard></Trigger.EnterActions>
      <Trigger.ExitActions><BeginStoryboard><Storyboard>{Anim("bg", h)}</Storyboard></BeginStoryboard></Trigger.ExitActions>
    </Trigger>
    <Trigger Property='IsKeyboardFocused' Value='True'>
      <Setter TargetName='bd' Property='BorderBrush' Value='{Hex(focus)}'/>
    </Trigger>
    <Trigger Property='IsEnabled' Value='False'>
      <Setter TargetName='bd' Property='Opacity' Value='0.45'/>
    </Trigger>
  </ControlTemplate.Triggers>
</ControlTemplate>";
        t = (ControlTemplate)XamlReader.Parse(xaml);
        Templates[key] = t;
        return t;
    }

    /// <summary>Bouton arrondi à survol animé. text ou icon peuvent être nuls (bouton icône seule).</summary>
    public static Button Btn(Pal p, BtnKind kind, string? text, string? icon, RoutedEventHandler click, double height = 44, double fontSize = 14, double radius = 12)
    {
        radius = Math.Max(10, radius);
        Color n, h, pr, b, bh; Brush fg;
        switch (kind)
        {
            case BtnKind.Primary:
                n = p.Accent; h = p.AccentHover; pr = Pal.Mix(p.Accent, Colors.Black, 0.18); b = p.Accent; bh = p.AccentHover; fg = p.BOnAccent; break;
            case BtnKind.Secondary:
                n = p.Card; h = p.Surface; pr = p.Line; b = p.Line; bh = Pal.Alpha(p.Muted, 0x90); fg = p.BText; break;
            case BtnKind.Ghost:
                n = p.Surface; h = Pal.Alpha(p.Accent, 0x30); pr = Pal.Alpha(p.Accent, 0x48); b = p.Surface; bh = Pal.Alpha(p.Accent, 0x66); fg = p.BAccent; break;
            case BtnKind.Danger:
                n = Pal.Alpha(p.Err, 0x1A); h = Pal.Alpha(p.Err, 0x33); pr = Pal.Alpha(p.Err, 0x4D); b = Pal.Alpha(p.Err, 0x44); bh = Pal.Alpha(p.Err, 0x99); fg = p.BErr; break;
            default:
                n = Colors.Transparent; h = Pal.Alpha(p.Text, 0x14); pr = Pal.Alpha(p.Text, 0x22); b = Colors.Transparent; bh = Colors.Transparent; fg = p.BMuted; break;
        }
        var content = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        if (icon != null)
        {
            var ic = Icon(icon, text == null ? fontSize + 4 : fontSize + 3, fg, kind == BtnKind.Primary ? 2.2 : 1.8);
            ic.Margin = new Thickness(0, 0, text == null ? 0 : 9, 0);
            content.Children.Add(ic);
        }
        if (text != null)
        {
            var t = Txt(text, fontSize, fg, FontWeights.SemiBold);
            t.VerticalAlignment = VerticalAlignment.Center;
            content.Children.Add(t);
        }
        var btn = new Button
        {
            Style = null, Template = Template($"{kind}|{p.Dark}|{radius}", n, h, pr, b, bh, p.Accent, radius),
            Height = height, Padding = new Thickness(text == null ? 0 : (kind == BtnKind.Primary ? 30 : 20), 0, text == null ? 0 : (kind == BtnKind.Primary ? 30 : 20), 0),
            Cursor = Cursors.Hand, Content = content, FocusVisualStyle = null, Foreground = fg, FontFamily = Font
        };
        if (text == null) btn.Width = height;
        btn.Click += click;
        if (kind == BtnKind.Primary) AddGlow(btn, p);
        return btn;
    }

    /// <summary>Halo doux du bouton principal et léger agrandissement au survol.</summary>
    private static void AddGlow(Button btn, Pal p)
    {
        var fx = new DropShadowEffect { Color = p.Accent, BlurRadius = 24, ShadowDepth = 0, Opacity = p.Dark ? 0.22 : 0.28, RenderingBias = RenderingBias.Performance };
        btn.Effect = fx;
        var sc = new ScaleTransform(1, 1);
        btn.RenderTransformOrigin = new Point(0.5, 0.5);
        btn.RenderTransform = sc;
        double rest = fx.Opacity;
        btn.MouseEnter += (s, e) =>
        {
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1.025, Ms(160)) { EasingFunction = EaseOut });
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1.025, Ms(160)) { EasingFunction = EaseOut });
            fx.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(Math.Min(1, rest * 2.0), Ms(160)));
        };
        btn.MouseLeave += (s, e) =>
        {
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1, Ms(160)) { EasingFunction = EaseOut });
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1, Ms(160)) { EasingFunction = EaseOut });
            fx.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(rest, Ms(160)));
        };
    }

    // ------------------------------------------------------------------ cartes et animations
    public static Border Card(Pal p, double radius = 14, bool shadow = true)
    {
        var b = new Border { Background = p.BCard, BorderBrush = p.BLine, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(radius), SnapsToDevicePixels = true };
        if (shadow) b.Effect = new DropShadowEffect { Color = Colors.Black, BlurRadius = 22, ShadowDepth = 5, Direction = 270, Opacity = p.Dark ? 0.34 : 0.07, RenderingBias = RenderingBias.Performance };
        return b;
    }

    /// <summary>Apparition douce : fondu et léger glissement vers le haut. delayMs permet l'apparition en cascade.</summary>
    public static void Appear(UIElement el, int delayMs = 0, int ms = 220, double dy = 10)
    {
        var tt = el.RenderTransform as TranslateTransform;
        if (tt == null) { tt = new TranslateTransform(); el.RenderTransform = tt; }
        el.Opacity = 0;
        var begin = TimeSpan.FromMilliseconds(delayMs);
        el.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, Ms(ms)) { BeginTime = begin, EasingFunction = EaseOut });
        tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(dy, 0, Ms(ms)) { BeginTime = begin, EasingFunction = EaseOut });
    }

    public static void FadeTo(UIElement el, double to, int ms, Action? done = null)
    {
        var a = new DoubleAnimation(to, Ms(ms)) { EasingFunction = EaseOut };
        if (done != null) a.Completed += (s, e) => done();
        el.BeginAnimation(UIElement.OpacityProperty, a);
    }

    /// <summary>Carte qui se soulève légèrement au survol (ombre un peu plus marquée, bordure d'accent).</summary>
    public static void Lift(Border card, Pal p, double dy = -3)
    {
        var tt = card.RenderTransform as TranslateTransform;
        if (tt == null) { tt = new TranslateTransform(); card.RenderTransform = tt; }
        var fx = card.Effect as DropShadowEffect;
        double rest = fx?.Opacity ?? 0;
        card.MouseEnter += (s, e) =>
        {
            tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(dy, Ms(160)) { EasingFunction = EaseOut });
            fx?.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(Math.Min(1, rest * 1.8), Ms(160)));
            card.BorderBrush = p.BAccentLine;
        };
        card.MouseLeave += (s, e) =>
        {
            tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, Ms(160)) { EasingFunction = EaseOut });
            fx?.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(rest, Ms(160)));
            card.BorderBrush = p.BLine;
        };
    }

    // ------------------------------------------------------------------ menu contextuel
    /// <summary>Menu contextuel arrondi, ombré et aux couleurs de l'accueil (à la place du menu Windows standard).</summary>
    public static ContextMenu Menu(Pal p)
    {
        string shadow = p.Dark ? "0.55" : "0.20";
        var m = new ContextMenu { Template = (ControlTemplate)XamlReader.Parse($@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='ContextMenu'>
  <Border Margin='10,6,10,14' Background='{Hex(p.Card)}' BorderBrush='{Hex(p.Line)}' BorderThickness='1' CornerRadius='12' Padding='6' SnapsToDevicePixels='True'>
    <Border.Effect><DropShadowEffect BlurRadius='20' ShadowDepth='4' Direction='270' Opacity='{shadow}' Color='Black'/></Border.Effect>
    <StackPanel IsItemsHost='True' KeyboardNavigation.DirectionalNavigation='Cycle'/>
  </Border>
</ControlTemplate>") };
        var item = (Style)XamlReader.Parse($@"<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='MenuItem'>
  <Setter Property='FontSize' Value='13.5'/>
  <Setter Property='Template'>
    <Setter.Value>
      <ControlTemplate TargetType='MenuItem'>
        <Border x:Name='bd' Background='Transparent' CornerRadius='10' Padding='12,8,26,8' MinWidth='230' SnapsToDevicePixels='True'>
          <ContentPresenter ContentSource='Header' RecognizesAccessKey='True' VerticalAlignment='Center'/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property='IsHighlighted' Value='True'><Setter TargetName='bd' Property='Background' Value='{Hex(Pal.Alpha(p.Accent, 0x26))}'/></Trigger>
          <Trigger Property='IsEnabled' Value='False'><Setter TargetName='bd' Property='Opacity' Value='0.45'/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate>
    </Setter.Value>
  </Setter>
</Style>");
        m.Resources.Add(typeof(MenuItem), item);
        return m;
    }

    public static MenuItem MenuEntry(Pal p, string header, Action act, bool danger = false)
    {
        var mi = new MenuItem { Header = header, Foreground = danger ? p.BErr : p.BText, FontFamily = Font, Cursor = Cursors.Hand };
        mi.Click += (s, ev) => act();
        return mi;
    }

    public static Border MenuSeparator(Pal p) => new() { Height = 1, Background = p.BLine, Margin = new Thickness(8, 5, 8, 5), IsHitTestVisible = false };

    // ------------------------------------------------------------------ indicateurs
    public static FrameworkElement Spinner(Brush brush, double size = 20)
    {
        var track = new Shapes.Path { Data = Geometry.Parse("M3,12 a9,9 0 1 0 18,0 a9,9 0 1 0 -18,0"), Stroke = brush, StrokeThickness = 2.4, Opacity = 0.22 };
        var rot = new RotateTransform(0, 12, 12);
        var arc = new Shapes.Path
        {
            Data = Geometry.Parse("M12,3 a9,9 0 0 1 9,9"), Stroke = brush, StrokeThickness = 2.4,
            StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, RenderTransform = rot
        };
        var c = new Canvas { Width = 24, Height = 24 };
        c.Children.Add(track); c.Children.Add(arc);
        rot.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(0, 360, Ms(900)) { RepeatBehavior = RepeatBehavior.Forever });
        return new Viewbox { Width = size, Height = size, Child = c, IsHitTestVisible = false };
    }

    /// <summary>Style fin des barres de défilement verticales.</summary>
    public static Style ScrollBarStyle(Pal p)
    {
        string thumb = Hex(Pal.Alpha(p.Muted, 0x55));
        string xaml = $@"<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ScrollBar'>
  <Setter Property='Background' Value='Transparent'/>
  <Setter Property='Width' Value='10'/>
  <Setter Property='Template'>
    <Setter.Value>
      <ControlTemplate TargetType='ScrollBar'>
        <Grid Background='Transparent'>
          <Track x:Name='PART_Track' IsDirectionReversed='True'>
            <Track.DecreaseRepeatButton><RepeatButton Command='ScrollBar.PageUpCommand' Opacity='0' Focusable='False'/></Track.DecreaseRepeatButton>
            <Track.IncreaseRepeatButton><RepeatButton Command='ScrollBar.PageDownCommand' Opacity='0' Focusable='False'/></Track.IncreaseRepeatButton>
            <Track.Thumb>
              <Thumb><Thumb.Template><ControlTemplate TargetType='Thumb'><Border Margin='2,0' CornerRadius='3' Background='{thumb}'/></ControlTemplate></Thumb.Template></Thumb>
            </Track.Thumb>
          </Track>
        </Grid>
      </ControlTemplate>
    </Setter.Value>
  </Setter>
</Style>";
        return (Style)XamlReader.Parse(xaml);
    }

    /// <summary>Champ de saisie arrondi (bordure d'accent quand il a le focus).</summary>
    public static Border Input(Pal p, string text, out TextBox box, double height = 44)
    {
        var tb = new TextBox
        {
            Style = null, Text = text, Background = p.BTransparent, Foreground = p.BText, CaretBrush = p.BText, SelectionBrush = p.BAccentLine,
            BorderThickness = new Thickness(0), FontSize = 14, FontFamily = Font, VerticalContentAlignment = VerticalAlignment.Center,
            Padding = new Thickness(12, 0, 12, 0), Height = height - 2
        };
        var wrap = new Border { Background = p.BSurface, BorderBrush = p.BLine, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Child = tb };
        tb.GotKeyboardFocus += (s, ev) => wrap.BorderBrush = p.BAccent;
        tb.LostKeyboardFocus += (s, ev) => wrap.BorderBrush = p.BLine;
        box = tb;
        return wrap;
    }

    // ------------------------------------------------------------------ dates
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");

    public static string FriendlyDate(DateTime d)
    {
        if (d == DateTime.MinValue) return "inconnue";
        var today = DateTime.Today;
        if (d.Date == today) return "aujourd'hui, " + d.ToString("HH:mm", Fr);
        if (d.Date == today.AddDays(-1)) return "hier, " + d.ToString("HH:mm", Fr);
        return d.ToString(d.Year == today.Year ? "d MMM" : "d MMM yyyy", Fr);
    }

    /// <summary>Miniature filaire d'un projet (barres en coordonnées 0..1) dans une zone w x h ; null si le projet n'a pas de barres.</summary>
    public static FrameworkElement? Thumbnail(double[] t, Pal p, double w, double h, double pad = 16)
    {
        if (t.Length < 6) return null;
        double tw = Math.Max(t[0], 0.02), th = Math.Max(t[1], 0.02);
        double s = Math.Min((w - 2 * pad) / tw, (h - 2 * pad) / th);
        double ox = (w - tw * s) / 2, oy = (h - th * s) / 2;
        var g = new StreamGeometry();
        using (var ctx = g.Open())
        {
            for (int i = 2; i + 3 < t.Length; i += 4)
            {
                ctx.BeginFigure(new Point(ox + t[i] * s, oy + t[i + 1] * s), false, false);
                ctx.LineTo(new Point(ox + t[i + 2] * s, oy + t[i + 3] * s), true, false);
            }
        }
        g.Freeze();
        var path = new Shapes.Path
        {
            Data = g, Stroke = p.BAccent, StrokeThickness = 1.6, Opacity = 0.9, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, IsHitTestVisible = false
        };
        var c = new Canvas { Width = w, Height = h, IsHitTestVisible = false };
        c.Children.Add(path);
        return c;
    }
}

/// <summary>Barre de progression fine, à remplissage animé.</summary>
internal sealed class SoftProgress : Border
{
    private readonly ScaleTransform _sc = new(0, 1);

    public SoftProgress(Pal p, double height = 6)
    {
        Height = height; CornerRadius = new CornerRadius(height / 2); Background = p.BSurface; ClipToBounds = true;
        Child = new Border { Background = p.BAccent, CornerRadius = new CornerRadius(height / 2), RenderTransformOrigin = new Point(0, 0.5), RenderTransform = _sc };
    }

    public void Set(double v) =>
        _sc.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(Math.Clamp(v, 0, 1), new Duration(TimeSpan.FromMilliseconds(160))));
}

/// <summary>Sélecteur à pastilles (unité, système, norme...) : une seule valeur choisie.</summary>
internal sealed class Chips : WrapPanel
{
    private readonly Pal _p;
    private readonly List<(string Value, Border Box, TextBlock Label)> _items = new();
    public string Value { get; private set; } = "";
    public event Action<string>? Changed;

    public Chips(Pal p, IEnumerable<(string Value, string Label)> items, string selected)
    {
        _p = p;
        foreach (var (v, l) in items)
        {
            var t = Wk.Txt(l, 13, p.BText, FontWeights.Medium);
            var box = new Border
            {
                CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1), Padding = new Thickness(14, 8, 14, 8),
                Margin = new Thickness(0, 0, 8, 8), Cursor = Cursors.Hand, Child = t, Focusable = true, FocusVisualStyle = null
            };
            string val = v;
            box.MouseLeftButtonUp += (s, e) => Select(val, true);
            box.KeyDown += (s, e) => { if (e.Key is Key.Space or Key.Enter) { Select(val, true); e.Handled = true; } };
            box.MouseEnter += (s, e) => { if (Value != val) box.BorderBrush = p.BLineHover; };
            box.MouseLeave += (s, e) => { if (Value != val) box.BorderBrush = p.BLine; };
            _items.Add((v, box, t));
            Children.Add(box);
        }
        Select(selected, false);
    }

    public void Select(string v, bool raise)
    {
        Value = v;
        foreach (var (val, box, label) in _items)
        {
            bool on = val == v;
            box.Background = on ? _p.BAccentSoft : _p.BSurface;
            box.BorderBrush = on ? _p.BAccent : _p.BLine;
            label.Foreground = on ? _p.BAccent : _p.BText;
        }
        if (raise) Changed?.Invoke(v);
    }

    public void SetEnabled(bool on) { IsEnabled = on; Opacity = on ? 1 : 0.6; }
}
