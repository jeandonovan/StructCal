using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Steel;

namespace StructCalc.UI;

/// <summary>Dessin à l'échelle de la section du profilé (I/H, U, cornière, T), sans congés.</summary>
public sealed class ProfileDrawing : FrameworkElement
{
    private LibrarySection? _s;
    public void Set(LibrarySection? s) { _s = s; InvalidateVisual(); }

    private static List<(double X, double Y)> Outline(LibrarySection s)
    {
        double h = s.H, b = s.B, tw = s.Tw, tf = s.Tf;
        switch (s.Shape)
        {
            case ProfileShape.U:
                return new() { (0, 0), (b, 0), (b, tf), (tw, tf), (tw, h - tf), (b, h - tf), (b, h), (0, h) };
            case ProfileShape.L:
                return new() { (0, 0), (tw, 0), (tw, h - tw), (b, h - tw), (b, h), (0, h) };
            case ProfileShape.T:
                return new() { (0, 0), (b, 0), (b, tf), ((b + tw) / 2, tf), ((b + tw) / 2, h), ((b - tw) / 2, h), ((b - tw) / 2, tf), (0, tf) };
            default:
                double x0 = (b - tw) / 2, x1 = (b + tw) / 2;
                return new() { (0, 0), (b, 0), (b, tf), (x1, tf), (x1, h - tf), (b, h - tf), (b, h), (0, h), (0, h - tf), (x0, h - tf), (x0, tf), (0, tf) };
        }
    }

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, ActualWidth, ActualHeight));
        if (_s == null || ActualWidth < 60 || ActualHeight < 60) return;
        var s = _s; var pts = Outline(s);
        double w = s.B, h = s.H;
        double k = Math.Min((ActualWidth - 110) / w, (ActualHeight - 90) / h);
        if (k <= 0) return;
        double ox = (ActualWidth - w * k) / 2, oy = (ActualHeight - h * k) / 2;
        Point P(double x, double y) => new(ox + x * k, oy + y * k);
        var geo = new StreamGeometry();
        using (var c = geo.Open()) { c.BeginFigure(P(pts[0].X, pts[0].Y), true, true); foreach (var q in pts.Skip(1)) c.LineTo(P(q.X, q.Y), true, false); }
        geo.Freeze();
        var fill = new SolidColorBrush(Color.FromRgb(0xCF, 0xD8, 0xDC)); fill.Freeze();
        var edge = new Pen(new SolidColorBrush(Color.FromRgb(0x37, 0x47, 0x4F)), 2); edge.Freeze();
        dc.DrawGeometry(fill, edge, geo);
        var tf = new Typeface("Segoe UI");
        void Txt(string t, double x, double y, bool center = true, bool vertical = false)
        {
            var ft = new FormattedText(t, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, tf, 12, Brushes.DimGray, 1.0);
            if (vertical) { dc.PushTransform(new RotateTransform(-90, x, y)); dc.DrawText(ft, new Point(x - ft.Width / 2, y)); dc.Pop(); }
            else dc.DrawText(ft, new Point(center ? x - ft.Width / 2 : x, y));
        }
        var dim = new Pen(Brushes.Gray, 0.8); dim.Freeze();
        // cotes h et b
        double xl = ox - 18, yb = oy + h * k + 14;
        dc.DrawLine(dim, new Point(xl, oy), new Point(xl, oy + h * k));
        Txt($"h = {s.H:0.#}", xl - 6, oy + h * k / 2 + 24, true, true);
        dc.DrawLine(dim, new Point(ox, yb), new Point(ox + w * k, yb));
        Txt($"b = {s.B:0.#}", ox + w * k / 2, yb + 3);
        Txt(s.Label, ActualWidth / 2, 6);
    }
}

/// <summary>Bibliothèque de profilés métalliques (catalogue ArcelorMittal) : recherche, tableau des caractéristiques, dessin, fiche, application aux barres.</summary>
public sealed class SteelLibraryWindow : Window
{
    private readonly Func<string, int> _apply;
    private readonly ComboBox _series = new() { MinWidth = 120, Margin = new Thickness(0, 0, 10, 0) };
    private readonly TextBox _search = new() { MinWidth = 140, Margin = new Thickness(0, 0, 10, 0) };
    private readonly TextBox _wel = new() { Width = 70, Margin = new Thickness(0, 0, 4, 0) };
    private readonly DataGrid _grid = new() { AutoGenerateColumns = false, IsReadOnly = true, SelectionMode = DataGridSelectionMode.Single, CanUserAddRows = false, HeadersVisibility = DataGridHeadersVisibility.Column };
    private readonly ProfileDrawing _draw = new() { MinHeight = 220 };
    private readonly TextBox _sheet = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, BorderThickness = new Thickness(0), TextWrapping = TextWrapping.NoWrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly TextBlock _count = new() { Margin = new Thickness(10, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
    private readonly TextBlock _msg = new() { Margin = new Thickness(12, 4, 12, 8), TextWrapping = TextWrapping.Wrap, FontSize = 11 };
    private List<LibrarySection> _shown = new();
    private bool _init;

    public SteelLibraryWindow(Func<string, int> applyToSelection)
    {
        _apply = applyToSelection;
        Title = "Bibliothèque de profilés métalliques (ArcelorMittal)"; Width = 1180; Height = 720; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new DockPanel();

        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(12, 10, 12, 6) };
        top.Children.Add(new TextBlock { Text = "Série ", VerticalAlignment = VerticalAlignment.Center });
        _series.ItemsSource = new[] { "Toutes" }.Concat(SteelLibrary.Series).ToList(); _series.SelectedIndex = 0;
        _series.SelectionChanged += (s, e) => Refresh();
        top.Children.Add(_series);
        top.Children.Add(new TextBlock { Text = "Recherche ", VerticalAlignment = VerticalAlignment.Center });
        _search.ToolTip = "Ex. : « 240 », « HEA 200 », « IPE A »";
        _search.TextChanged += (s, e) => Refresh();
        top.Children.Add(_search);
        top.Children.Add(new TextBlock { Text = "Wel,y requis ≥ ", VerticalAlignment = VerticalAlignment.Center });
        _wel.ToolTip = "Module élastique minimal en cm³ : le profil le plus léger de la série choisie est sélectionné";
        _wel.TextChanged += (s, e) => PickByWel();
        top.Children.Add(_wel);
        top.Children.Add(new TextBlock { Text = "cm³", VerticalAlignment = VerticalAlignment.Center });
        top.Children.Add(_count);
        DockPanel.SetDock(top, Dock.Top); root.Children.Add(top);

        DockPanel.SetDock(_msg, Dock.Bottom); root.Children.Add(_msg);
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12, 0, 12, 4) };
        bar.Children.Add(Ui.Btn("Appliquer aux barres sélectionnées", (s, e) => Apply(), true));
        bar.Children.Add(Ui.Btn("Copier la fiche", (s, e) => { if (Current != null) { Clipboard.SetText(Sheet(Current)); _msg.Text = "Fiche copiée dans le presse-papiers."; } }));
        bar.Children.Add(Ui.Btn("Exporter le tableau (CSV)...", (s, e) => ExportCsv()));
        bar.Children.Add(new Button { Content = "Fermer", Padding = new Thickness(12, 5, 12, 5), IsCancel = true });
        DockPanel.SetDock(bar, Dock.Bottom); root.Children.Add(bar);

        // panneau de droite : dessin + fiche
        var right = new Grid { Width = 420, Margin = new Thickness(0, 0, 12, 0) };
        right.RowDefinitions.Add(new RowDefinition { Height = new GridLength(2, GridUnitType.Star) });
        right.RowDefinitions.Add(new RowDefinition { Height = new GridLength(3, GridUnitType.Star) });
        Grid.SetRow(_draw, 0); right.Children.Add(_draw);
        var sb = new Border { BorderThickness = new Thickness(1), BorderBrush = Brushes.LightGray, Margin = new Thickness(0, 6, 0, 0), Child = _sheet };
        Grid.SetRow(sb, 1); right.Children.Add(sb);
        DockPanel.SetDock(right, Dock.Right); root.Children.Add(right);

        Col("Désignation", "Label", 120, "@"); Col("G kg/m", "G", 62, "0.0##"); Col("h mm", "H", 56, "0.#"); Col("b mm", "B", 56, "0.#");
        Col("tw", "Tw", 46, "0.#"); Col("tf", "Tf", 46, "0.#"); Col("A cm²", "A", 62, "0.0#"); Col("Iy cm⁴", "Iy", 78, "0.#");
        Col("Wel,y cm³", "Wely", 76, "0.#"); Col("Wpl,y cm³", "WplyCm3", 76, "0.#"); Col("Iz cm⁴", "Iz", 72, "0.#"); Col("Wel,z cm³", "Welz", 72, "0.#");
        Col("It cm⁴", "ItCm4", 66, "0.##"); Col("Iw cm⁶", "Iw", 84, "0");
        _grid.SelectionChanged += (s, e) => ShowCurrent();
        _grid.MouseDoubleClick += (s, e) => Apply();
        root.Children.Add(_grid);
        Content = root;
        _init = true;
        Refresh();
    }

    private void Col(string header, string path, double width, string fmt)
    {
        var b = new System.Windows.Data.Binding(path) { StringFormat = fmt == "@" ? null : fmt, ConverterCulture = CultureInfo.InvariantCulture };
        _grid.Columns.Add(new DataGridTextColumn { Header = header, Binding = b, Width = width });
    }

    private LibrarySection? Current => _grid.SelectedItem as LibrarySection;

    private void Refresh()
    {
        if (!_init) return;
        string ser = _series.SelectedItem as string ?? "Toutes";
        IEnumerable<LibrarySection> q = string.IsNullOrWhiteSpace(_search.Text) ? SteelLibrary.All : SteelLibrary.Search(_search.Text);
        if (ser != "Toutes") q = q.Where(s => s.Series == ser);
        _shown = q.ToList();
        _grid.ItemsSource = _shown;
        _count.Text = $"{_shown.Count} profilé(s) sur {SteelLibrary.All.Count}";
        if (_shown.Count > 0) _grid.SelectedIndex = 0; else { _draw.Set(null); _sheet.Text = ""; }
    }

    private void PickByWel()
    {
        if (!double.TryParse(_wel.Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double w) || w <= 0) return;
        var hit = _shown.Where(s => s.Wely >= w).OrderBy(s => s.G).FirstOrDefault();
        if (hit == null) { _msg.Text = "Aucun profilé de la liste affichée n'atteint ce module élastique."; return; }
        _grid.SelectedItem = hit; _grid.ScrollIntoView(hit);
        _msg.Text = $"Profil le plus léger avec Wel,y ≥ {w:0.#} cm³ : {hit.Label} ({hit.G:0.0} kg/m, Wel,y = {hit.Wely:0.#} cm³).";
    }

    private void ShowCurrent()
    {
        var s = Current;
        _draw.Set(s);
        _sheet.Text = s == null ? "" : Sheet(s);
    }

    private void Apply()
    {
        var s = Current;
        if (s == null) return;
        if (s.Shape != ProfileShape.I || !SteelCatalog.TryGet(s.Name, out _))
        {
            _msg.Text = "Ce profilé (U, cornière ou T) figure dans la bibliothèque à titre de consultation : le solveur n'utilise que les profils en I/H.";
            return;
        }
        int n = _apply(s.Name);
        _msg.Text = n > 0 ? $"{s.Label} appliqué à {n} barre(s) - relancez le calcul (F5)." : "Sélectionnez d'abord une ou plusieurs barres dans le modèle.";
    }

    private static string F(double v, string fmt = "0.##") => double.IsNaN(v) ? "-" : v.ToString(fmt, CultureInfo.InvariantCulture);

    public static string Sheet(LibrarySection s)
    {
        var sb = new StringBuilder();
        void L(string k, string v, string u = "") => sb.AppendLine($"{k,-12}{v,12} {u}");
        sb.AppendLine($"{s.Label}   ({s.Series})"); sb.AppendLine(new string('-', 34));
        L("G", F(s.G, "0.0#"), "kg/m"); L("h", F(s.H, "0.#"), "mm"); L("b", F(s.B, "0.#"), "mm");
        L("tw", F(s.Tw, "0.#"), "mm"); L("tf", F(s.Tf, "0.#"), "mm");
        L(s.R2 > 0 ? "r1" : "r", F(s.R, "0.#"), "mm"); if (!double.IsNaN(s.R2)) L("r2", F(s.R2, "0.#"), "mm");
        L("A", F(s.A, "0.0#"), "cm²");
        sb.AppendLine("axe fort y-y");
        L("Iy", F(s.Iy, "0.#"), "cm⁴"); L("Wel,y", F(s.Wely, "0.#"), "cm³"); L("Wpl,y", F(s.WplyCm3, "0.#"), "cm³");
        L("iy", F(s.iy, "0.##"), "cm"); if (!double.IsNaN(s.Avz)) L("Avz", F(s.Avz, "0.##"), "cm²");
        if (!double.IsNaN(s.Iz))
        {
            sb.AppendLine("axe faible z-z");
            L("Iz", F(s.Iz, "0.#"), "cm⁴"); L("Wel,z", F(s.Welz, "0.#"), "cm³"); if (!double.IsNaN(s.Wplz)) L("Wpl,z", F(s.Wplz, "0.#"), "cm³");
            L("iz", F(s.iz, "0.##"), "cm");
        }
        sb.AppendLine("torsion / gauchissement");
        L("It", F(s.ItCm4, "0.##"), "cm⁴" + (double.IsNaN(s.It) ? " (estimé)" : "")); if (!double.IsNaN(s.Iw)) L("Iw", F(s.Iw, "0"), "cm⁶");
        if (!double.IsNaN(s.Iu)) { sb.AppendLine("axes principaux"); L("Iu", F(s.Iu, "0.#"), "cm⁴"); L("Iv", F(s.Iv, "0.#"), "cm⁴"); L("iu / iv", $"{F(s.iu)} / {F(s.iv)}", "cm"); }
        if (!double.IsNaN(s.Alpha)) L("α", F(s.Alpha, "0.##"), "°");
        if (!double.IsNaN(s.Zs)) L("zs", F(s.Zs, "0.###"), "cm");
        if (!double.IsNaN(s.Ys)) L("ys", F(s.Ys, "0.###"), "cm");
        if (!double.IsNaN(s.Ym)) L("ym", F(s.Ym, "0.###"), "cm");
        sb.AppendLine("surfaces");
        L("AL", F(s.AL, "0.###"), "m²/m"); L("AG", F(s.AG, "0.##"), "m²/t");
        return sb.ToString();
    }

    private void ExportCsv()
    {
        var dlg = new Microsoft.Win32.SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "profiles_acier.csv" };
        if (dlg.ShowDialog(this) != true) return;
        var sb = new StringBuilder("Designation;Serie;G kg/m;h;b;tw;tf;r;A cm2;Iy cm4;Wel_y cm3;Wpl_y cm3;iy cm;Avz cm2;Iz cm4;Wel_z cm3;Wpl_z cm3;iz cm;It cm4;Iw cm6\n");
        string C(double v) => double.IsNaN(v) ? "" : v.ToString("0.####", CultureInfo.GetCultureInfo("fr-FR"));
        foreach (var s in _shown)
            sb.AppendLine(string.Join(";", s.Label, s.Series, C(s.G), C(s.H), C(s.B), C(s.Tw), C(s.Tf), C(s.R), C(s.A), C(s.Iy), C(s.Wely), C(s.WplyCm3),
                C(s.iy), C(s.Avz), C(s.Iz), C(s.Welz), C(s.Wplz), C(s.iz), C(s.ItCm4), C(s.Iw)));
        System.IO.File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
        _msg.Text = $"{_shown.Count} lignes exportées : {dlg.FileName}";
    }
}
