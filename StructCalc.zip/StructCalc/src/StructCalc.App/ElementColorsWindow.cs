using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;

namespace StructCalc.UI;

/// <summary>Fenêtre « Couleurs des éléments » (menu Options) : une couleur par famille d'éléments, jeux prêts à l'emploi, retour aux couleurs d'origine.</summary>
public sealed class ElementColorsWindow : Window
{
    private readonly Dictionary<string, TextBox> _boxes = new();
    private readonly CheckBox _byResult = new() { Content = "Colorer les barres selon le résultat du calcul (vert = conforme, rouge = non conforme) quand il existe", Margin = new Thickness(0, 0, 0, 8) };
    private readonly Action _redraw;

    private static readonly (string Name, string Hex)[] Swatches =
    {
        ("Noir", "#000000"), ("Gris foncé", "#455A64"), ("Gris", "#9E9E9E"), ("Blanc", "#FFFFFF"), ("Bleu", "#1565C0"), ("Turquoise", "#00838F"),
        ("Vert", "#2E7D32"), ("Jaune", "#F9A825"), ("Orange", "#E65100"), ("Rouge", "#C62828"), ("Violet", "#6A1B9A"), ("Brun", "#8D6E63"),
    };

    public ElementColorsWindow(Window owner, Action redraw)
    {
        Owner = owner; _redraw = redraw;
        Title = "Couleurs des éléments";
        Width = 760; Height = 640; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _byResult.IsChecked = AppOptions.Current.ColorByResult;

        var root = new DockPanel();
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12) };
        bar.Children.Add(Ui.Btn("Appliquer", (s, e) => ApplyNow()));
        bar.Children.Add(Ui.Btn("OK", (s, e) => { ApplyNow(); DialogResult = true; }, true));
        bar.Children.Add(new Button { Content = "Fermer", Padding = new Thickness(12, 5, 12, 5), Margin = new Thickness(6, 0, 0, 0), IsCancel = true });
        DockPanel.SetDock(bar, Dock.Bottom); root.Children.Add(bar);

        var p = new StackPanel { Margin = new Thickness(14) };
        p.Children.Add(new TextBlock { Text = "Choisissez la couleur de chaque famille d'éléments : tapez un code (#RRGGBB) ou cliquez une pastille. Les modifications sont enregistrées et retrouvées à chaque ouverture.", TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, Margin = new Thickness(0, 0, 0, 8) });

        var presets = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        presets.Children.Add(new TextBlock { Text = "Jeux de couleurs :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) });
        foreach (var (name, map) in ElementPalette.Presets)
        {
            var m = map;
            presets.Children.Add(Ui.Btn(name, (s, e) => { Fill(m); ApplyNow(); }));
        }
        p.Children.Add(presets);
        p.Children.Add(_byResult);

        string group = "";
        foreach (var d in ElementPalette.All)
        {
            if (d.Group != group)
            {
                group = d.Group;
                p.Children.Add(new TextBlock { Text = group, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 10, 0, 2) });
            }
            p.Children.Add(Row(d));
        }
        p.Children.Add(new TextBlock
        {
            Text = "Les poteaux et poutres béton en vue « fil de fer » gardent le bleu des options tant que vous ne leur donnez pas une couleur ici. "
                 + "Une couleur de résultat (vert / rouge) l'emporte sur la couleur de l'élément si la case ci-dessus est cochée.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, Margin = new Thickness(0, 12, 0, 0), FontSize = 11
        });
        root.Children.Add(new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = p });
        Content = root;
    }

    private UIElement Row(ElementColorDef d)
    {
        var sp = new WrapPanel { Margin = new Thickness(0, 3, 0, 3) };
        sp.Children.Add(new TextBlock { Text = d.Label, Width = 250, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap });
        var tb = new TextBox { Width = 84, Text = Hex(ElementPalette.Get(d.Id)) };
        _boxes[d.Id] = tb;
        sp.Children.Add(tb);
        var preview = new Border { Width = 28, Height = 20, Margin = new Thickness(6, 0, 8, 0), BorderBrush = Brushes.Gray, BorderThickness = new Thickness(1) };
        void Upd() => preview.Background = AppOptions.TryColor(tb.Text, out var c) ? Theme.Fixed(c) : Brushes.Transparent;
        tb.TextChanged += (s, e) => Upd();
        Upd();
        sp.Children.Add(preview);
        foreach (var (name, hex) in Swatches)
        {
            var b = new Button { Width = 20, Height = 20, Margin = new Thickness(1, 0, 1, 0), ToolTip = name, Padding = new Thickness(0) };
            if (AppOptions.TryColor(hex, out var c)) b.Background = Theme.Fixed(c);
            string h = hex;
            b.Click += (s, e) => tb.Text = h;
            sp.Children.Add(b);
        }
        var reset = new Button { Content = "↺", Width = 24, Height = 20, Margin = new Thickness(6, 0, 0, 0), ToolTip = "Couleur d'origine", Padding = new Thickness(0) };
        string def = d.Default;
        reset.Click += (s, e) => tb.Text = def;
        sp.Children.Add(reset);
        if (d.Note != "") sp.Children.Add(new TextBlock { Text = d.Note, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(250 + 8, 0, 0, 0), Width = 440, TextWrapping = TextWrapping.Wrap });
        return sp;
    }

    private static string Hex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";

    /// <summary>Remplit les champs avec un jeu de couleurs ; les familles absentes reprennent leur couleur d'origine.</summary>
    private void Fill(Dictionary<string, string> map)
    {
        foreach (var d in ElementPalette.All)
            _boxes[d.Id].Text = map.TryGetValue(d.Id, out var h) ? h : d.Default;
    }

    private void ApplyNow()
    {
        var map = new Dictionary<string, string>();
        foreach (var (id, tb) in _boxes) if (AppOptions.TryColor(tb.Text, out var c)) map[id] = Hex(c);
        ElementPalette.Apply(map, _byResult.IsChecked == true);
        _redraw();
    }
}
