using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Results;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

public enum ViewMode { Elevation, Plan, Side, Iso }
public enum DiagramKind { None, Moment, Shear, Normal, NSigned, Vy, Vz, Torsion, My, Mz, Reactions }
public enum EditTool { Select, Node, Member, Support, Delete, Slab, Dim, Stair }

/// <summary>Styles d'affichage : Fil = axes des barres ; Trait = arêtes des sections ; Caché = lignes cachées supprimées ; Ombré = faces éclairées (couleur selon le résultat) ; Réaliste = matériaux, ombres, ciel ; Rayons X = transparence.</summary>
public enum DisplayStyle { Fil, Trait, Cache, Ombre, Realiste, RayonsX, Ferraille }

/// <summary>Vue graphique du modèle (projection orthographique 2D/3D sur un Canvas) : barres colorées selon le résultat, appuis, charges,
/// diagrammes d'enveloppe, sélection à la souris. Molette = zoom, clic droit glissé = déplacer, clic gauche glissé = tourner (3D) ou déplacer.</summary>
public sealed partial class ModelViewport
{
    private readonly Canvas _c;
    private double _yaw, _pitch, _scale = 40, _ox = 100, _oy = 300;
    private bool _panning, _rotating, _moved;
    private Point _last, _down;
    private readonly List<(int Id, Point A, Point B)> _hit = new();
    private bool _orbiting, _midPanning, _suppressUp;
    private Vec3 _pivot, _focus;                 // _pivot : centre de rotation de l'orbite ; _focus : point de référence de la perspective
    private double _focusD, _camDist = 30;
    private int _hoverId = -1;
    private DateTime _lastIsoRedraw = DateTime.MinValue;

    public StructModel? Model { get; set; }
    public AnalysisOutput? Output { get; set; }
    public ViewMode Mode { get; private set; } = ViewMode.Elevation;
    public bool ShowLabels { get; set; } = true;
    public bool ShowLoads { get; set; } = true;
    public DiagramKind Diagram { get; set; } = DiagramKind.None;
    // ---- sélection (multiple) : SelectedId = barre « principale » (celle montrée dans l'éditeur)
    private readonly HashSet<int> _sel = new();
    private int _primary = -1;
    public IReadOnlyCollection<int> Selection => _sel;
    public bool IsSelected(int id) => _sel.Contains(id);
    public int SelectedId
    {
        get => _primary;
        set { _sel.Clear(); _primary = value; if (value >= 0) { _sel.Add(value); _selNodes.Clear(); PrimaryNode = -1; _selKeys.Clear(); } }
    }
    public event Action<int>? MemberSelected;
    /// <summary>Déclenché quand l'ensemble sélectionné change (clic avec Ctrl/Maj, rectangle, Ctrl+A...).</summary>
    public event Action? SelectionChanged;
    public void SetSelection(IEnumerable<int> ids, bool notify = true)
    {
        _sel.Clear();
        foreach (int i in ids) _sel.Add(i);
        if (!_sel.Contains(_primary)) _primary = _sel.Count > 0 ? _sel.First() : -1;
        bool hadNodes = _selNodes.Count > 0, hadSlab = _selKeys.Any(k => k.Kind == ElementKind.Slab);
        _selNodes.Clear(); PrimaryNode = -1; _selKeys.Clear();
        Redraw();
        if (notify)
        {
            if (hadNodes) NodeSelectionChanged?.Invoke();
            if (hadSlab) SlabSelected?.Invoke(null);
            SelectionChanged?.Invoke(); MemberSelected?.Invoke(_primary);
            ElementSelectionChanged?.Invoke();
        }
    }
    /// <summary>Sélectionne tout ce qui est visible : barres et éléments surfaciques (les nœuds se prennent par « Tous les nœuds »).</summary>
    public void SelectAll() { if (Model != null) SelectKeys(VisibleKeys().Where(k => k.Kind != ElementKind.Node), 'n'); }
    public void ClearSelection()
    {
        bool had = SelectedLoad != null || SelectedDim != null;
        SelectedLoad = null; SelectedDim = null;
        SetSelection(Array.Empty<int>());
        if (had) { ObjectSelected?.Invoke(null); ElementSelectionChanged?.Invoke(); }
    }

    // rectangle de sélection (Ctrl+glisser = ajouter, Maj+glisser = retirer)
    private bool _box, _boxArmed; private char _boxMode = 'a'; private Point _boxA, _boxB;
    private void Mod(out bool ctrl, out bool shift)
    {
        ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0; shift = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
    }
    private void ApplyIds(IEnumerable<int> ids, char mode)
    {
        var set = new HashSet<int>(_sel);
        foreach (int i in ids) { if (mode == 'r') set.Remove(i); else set.Add(i); }
        int prim = mode == 'r' ? (set.Contains(_primary) ? _primary : -1) : (ids.Any() ? ids.Last() : _primary);
        _primary = prim;
        SetSelection(set);
    }
    private List<int> IdsInBox(Point a, Point b)
    {
        double x0 = Math.Min(a.X, b.X), x1 = Math.Max(a.X, b.X), y0 = Math.Min(a.Y, b.Y), y1 = Math.Max(a.Y, b.Y);
        bool crossing = b.X < a.X;   // de droite à gauche : tout ce qui touche le rectangle
        bool In(Point q) => q.X >= x0 && q.X <= x1 && q.Y >= y0 && q.Y <= y1;
        var r = new List<int>();
        foreach (var h in _hit)
        {
            bool ok;
            if (!crossing) ok = In(h.A) && In(h.B);
            else ok = In(h.A) || In(h.B) || SegHitsRect(h.A, h.B, x0, y0, x1, y1);
            if (ok && !r.Contains(h.Id)) r.Add(h.Id);
        }
        return r;
    }
    private static bool SegHitsRect(Point a, Point b, double x0, double y0, double x1, double y1)
    {
        // Liang-Barsky
        double t0 = 0, t1 = 1, dx = b.X - a.X, dy = b.Y - a.Y;
        double[] p = { -dx, dx, -dy, dy }, q = { a.X - x0, x1 - a.X, a.Y - y0, y1 - a.Y };
        for (int i = 0; i < 4; i++)
        {
            if (Math.Abs(p[i]) < 1e-12) { if (q[i] < 0) return false; }
            else
            {
                double t = q[i] / p[i];
                if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
                else { if (t < t0) return false; if (t < t1) t1 = t; }
            }
        }
        return true;
    }
    private Rectangle? _boxRect;

    private void StyleBoxRect(Rectangle rc)
    {
        bool crossing = _boxB.X < _boxA.X;
        var col = _boxMode == 'r' ? Color.FromRgb(0xC6, 0x28, 0x28) : (crossing ? Color.FromRgb(0x2E, 0x7D, 0x32) : Color.FromRgb(0x15, 0x65, 0xC0));
        rc.Width = Math.Abs(_boxB.X - _boxA.X); rc.Height = Math.Abs(_boxB.Y - _boxA.Y);
        rc.Stroke = new SolidColorBrush(col); rc.StrokeThickness = 1.2;
        rc.StrokeDashArray = crossing ? new DoubleCollection { 4, 3 } : null;
        rc.Fill = new SolidColorBrush(Color.FromArgb(40, col.R, col.G, col.B)); rc.IsHitTestVisible = false;
        Canvas.SetLeft(rc, Math.Min(_boxA.X, _boxB.X)); Canvas.SetTop(rc, Math.Min(_boxA.Y, _boxB.Y));
    }

    private void DrawBox()
    {
        if (!_box) return;
        _boxRect = new Rectangle();
        StyleBoxRect(_boxRect);
        _c.Children.Add(_boxRect);
    }

    /// <summary>Pendant le tracé du rectangle de sélection : on déplace seulement le rectangle (pas de redessin complet de la scène à chaque mouvement de souris).</summary>
    private void MoveBox(Point p)
    {
        _box = true; _boxB = p;
        if (_boxRect != null && ReferenceEquals(_boxRect.Parent, _c)) StyleBoxRect(_boxRect);
        else Redraw();
    }

    // ---- outils de modélisation
    private EditTool _tool = EditTool.Select;
    private int _pendingNodeId = -1;
    private Point _cursor;
    private bool _cursorValid;
    public EditTool Tool
    {
        get => _tool;
        set { _tool = value; _pendingNodeId = -1; _slabA = null; _stairA = null; _dimA = null; _c.Cursor = value == EditTool.Select ? Cursors.Arrow : Cursors.Cross; Redraw(); }
    }
    public double GridStep { get; set; } = 0.25;
    public double WorkOffset { get; set; } = 0;
    public bool SupportFixed { get; set; } = true;
    public bool NewSteel { get; set; }
    public double NewB { get; set; } = 0.25;
    public double NewH { get; set; } = 0.45;
    public string NewProfile { get; set; } = "IPE300";
    public List<ModelIssue>? Issues { get; set; }
    public event Action? BeforeEdit;
    public event Action? ModelEdited;
    public event Action<string>? Hint;
    public void CancelPending() { _pendingNodeId = -1; _slabA = null; _stairA = null; _dimA = null; if (Picking) CancelPick(); Redraw(); }

    private static Brush Br(string hex)
    {
        var b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex)!;
        b.Freeze();
        return b;
    }
    private static Brush Ok = Br("#2E7D32"), Ko = Br("#C62828"), Plain = Br("#1F4E79");
    private static readonly Brush Skip = Br("#9E9E9E");
    /// <summary>Couleurs choisies dans les options (barre conforme, non conforme, non calculée) ; null ou invalide = inchangé.</summary>
    public void SetPaletteAndRedraw(string ok, string ko, string plain)
    {
        AppOptions_TryParse(ok, out var a); AppOptions_TryParse(ko, out var b); AppOptions_TryParse(plain, out var c);
        SetPalette(a, b, c);
        Redraw();
    }
    private static void AppOptions_TryParse(string hex, out Color? c)
    {
        c = AppOptions.TryColor(hex, out var x) ? x : null;
    }
    public static void SetPalette(Color? ok, Color? ko, Color? plain)
    {
        if (ok.HasValue) Ok = Theme.Fixed(ok.Value);
        if (ko.HasValue) Ko = Theme.Fixed(ko.Value);
        if (plain.HasValue) Plain = Theme.Fixed(plain.Value);
    }
    private static readonly Brush Dark = Br("#37474F"), Gray = Br("#6B7280"), LoadBlue = Br("#1E88E5");

    public ModelViewport(Canvas canvas)
    {
        _c = canvas;
        _c.SizeChanged += (s, e) => Redraw();
        _c.MouseWheel += OnWheel;
        _c.MouseLeftButtonDown += OnLeftDown;
        _c.MouseLeftButtonUp += OnLeftUp;
        _c.MouseRightButtonDown += OnRightDown;
        _c.MouseRightButtonUp += OnRightUp;
        _c.MouseMove += OnMove;
        _c.MouseDown += OnMidDown;
        _c.MouseUp += OnMidUp;
        _c.MouseLeave += (s, e) =>
        {
            _cursorValid = false;
            if (_hoverId != -1 || _hoverNode != -1) { _hoverId = -1; _hoverNode = -1; HoverChanged?.Invoke(""); Redraw(); }
            else if (Tool != EditTool.Select || Picking) Redraw();
        };
    }

    // ------------------------------------------------------------------ projection
    private (double X, double Y) W(double x, double y, double z)
    {
        double cy = Math.Cos(_yaw), sy = Math.Sin(_yaw), cp = Math.Cos(_pitch), sp = Math.Sin(_pitch);
        double x1 = x * cy - y * sy, y1 = x * sy + y * cy;
        return (x1, y1 * sp + z * cp);
    }
    private bool UsePersp => Perspective && Mode == ViewMode.Iso && !_faceView;

    /// <summary>Coordonnées de vue : U = droite, V = haut, D = profondeur (croît en s'éloignant de l'observateur).</summary>
    private (double U, double V, double D) V3(double x, double y, double z)
    {
        double cy = Math.Cos(_yaw), sy = Math.Sin(_yaw), cp = Math.Cos(_pitch), sp = Math.Sin(_pitch);
        double x1 = x * cy - y * sy, y1 = x * sy + y * cy;
        return (x1, y1 * sp + z * cp, y1 * cp - z * sp);
    }

    private Point S(double x, double y, double z)
    {
        var v = V3(x, y, z);
        double k = 1;
        if (UsePersp)
        {
            double dc = _camDist + v.D - _focusD;
            k = dc > 0.08 * _camDist ? _camDist / dc : 12.5;
        }
        return new Point(_ox + v.U * k * _scale, _oy - v.V * k * _scale);
    }
    private Point S(Node n) => S(n.X, n.Y, n.Z);

    public void SetMode(ViewMode m)
    {
        Mode = m; _faceView = false;
        switch (m)
        {
            case ViewMode.Elevation: _yaw = 0; _pitch = 0; break;
            case ViewMode.Plan: _yaw = 0; _pitch = Math.PI / 2; break;
            case ViewMode.Side: _yaw = -Math.PI / 2; _pitch = 0; break;
            default: _yaw = -0.6; _pitch = 0.45; break;
        }
        ZoomExtents();
    }

    public void ZoomExtents()
    {
        var sb = SceneBounds(false);
        if (Model == null || sb == null || _c.ActualWidth < 10 || _c.ActualHeight < 10) { Redraw(); return; }
        var pts = new List<Vec3>();
        double x0 = sb.Value.Min.X - 0.35, x1 = sb.Value.Max.X + 0.35;
        double y0 = sb.Value.Min.Y - 0.35, y1 = sb.Value.Max.Y + 0.35;
        double z0 = sb.Value.Min.Z - 0.35, z1 = sb.Value.Max.Z + 0.35;
        foreach (double x in new[] { x0, x1 }) foreach (double y in new[] { y0, y1 }) foreach (double z in new[] { z0, z1 }) pts.Add(new Vec3(x, y, z));
        double rad = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0) + (z1 - z0) * (z1 - z0)) / 2;
        _camDist = Math.Max(3.0 * rad, 8);
        _pivot = new Vec3((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
        FitScreen(pts, 70);
    }

    // ------------------------------------------------------------------ dessin
    private void Text(string s, double x, double y, double size, Brush fg, Brush? bg = null, bool bold = false)
    {
        var t = new TextBlock { Text = s, FontSize = size, Foreground = fg, Padding = new Thickness(2, 0, 2, 0) };
        if (bg != null) t.Background = bg;
        if (bold) t.FontWeight = FontWeights.SemiBold;
        Canvas.SetLeft(t, x); Canvas.SetTop(t, y);
        _c.Children.Add(t);
    }

    private void Ln(double x1, double y1, double x2, double y2, Brush b, double th)
    {
        _c.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, Stroke = b, StrokeThickness = th, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round });
    }

    private void Arrow(Point tail, Point tip, Brush b, double th = 1.5)
    {
        Ln(tail.X, tail.Y, tip.X, tip.Y, b, th);
        double dx = tip.X - tail.X, dy = tip.Y - tail.Y, len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 4) return;
        dx /= len; dy /= len;
        var head = new Polygon { Fill = b, Points = new PointCollection
        {
            tip,
            new Point(tip.X - dx * 8 + dy * 3.5, tip.Y - dy * 8 - dx * 3.5),
            new Point(tip.X - dx * 8 - dy * 3.5, tip.Y - dy * 8 + dx * 3.5)
        } };
        _c.Children.Add(head);
    }

    private Brush StatusBrush(Member mem)
    {
        var r = Output?.Members.FirstOrDefault(x => x.MemberId == mem.Id);
        if (r == null || !ElementPalette.ByResult)
        {
            string key = ElementPalette.KeyOf(mem);
            return ElementPalette.IsSet(key) ? ElementPalette.BrushOf(key) : Plain;        // couleur choisie pour cette famille, sinon le bleu des options
        }
        if (r.Skipped) return Skip;
        return r.Ok ? Ok : Ko;
    }

    private static Brush CaseBrush(ActionType a) => a switch
    {
        ActionType.G => Br("#1E88E5"), ActionType.Q => Br("#00ACC1"), ActionType.W => Br("#FB8C00"),
        ActionType.S => Br("#7E57C2"), _ => Br("#8E24AA"),
    };

    public void Redraw()
    {
        RedrawCore();
        Theme.MapTree(_c);
        ScheduleSelectionRefresh();
    }

    private void RedrawCore()
    {
        _c.Children.Clear();
        _hit.Clear(); _objHits.Clear(); _elemHits.Clear(); _barDepth.Clear();
        if (Model == null || (Model.Nodes.Count == 0 && Model.Grid.IsEmpty && Model.Levels.Count == 0 && Model.Underlays.Count == 0))
        {
            Text("Aucun modèle : chargez un exemple (menu Modèle) ou ajoutez des nœuds et des barres dans les tableaux.", 20, 20, 13, Gray);
            return;
        }
        var nodes = Model.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var info = GetInfo();
        UpdateFocusDepth();
        DrawSlabFields();
        DrawScene(nodes, info);
        DrawFoundationsAndWalls();
        DrawStairs();
        DrawShells(nodes);
        DrawRibbedFloors();
        DrawPlacedSlabs();      // après la scène : la dalle reste visible quel que soit le style 3D (fil, ombré, réaliste, modèle analytique...)
        DrawFootingLabels(info);
        DrawDims(nodes, info);

        // échelle des diagrammes
        double maxVal = 0;
        if (Output != null && IsStoreDiagram(Diagram)) maxVal = StoreDiagramMax();
        else if (Output != null && Diagram != DiagramKind.None)
            foreach (var r in Output.Members.Where(q => MemberShown(q.Type)))
            {
                foreach (var arr in SeriesOf(r)) foreach (var v in arr) maxVal = Math.Max(maxVal, v);
            }
        double k = maxVal > 1e-9 ? 55.0 / maxVal : 0;

        // barres
        foreach (var mem in Model.Members)
        {
            if (MemberHidden(mem.Id, info)) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
            Point a = S(na), b = S(nb);
            _hit.Add((mem.Id, a, b));
            _barDepth[mem.Id] = ViewDepth((V3(na.X, na.Y, na.Z).D + V3(nb.X, nb.Y, nb.Z).D) / 2);
            if (RenderStyle != DisplayStyle.Fil) continue;
            if (mem.Id == _hoverId && !IsSelected(mem.Id)) Ln(a.X, a.Y, b.X, b.Y, Br("#66FFB300"), 9);
            Ln(a.X, a.Y, b.X, b.Y, StatusBrush(mem), mem.Type == MemberType.Column ? 4.5 : 3.5);
        }

        // diagrammes
        if (Output != null && Diagram != DiagramKind.None && k > 0)
            foreach (var mem in Model.Members)
            {
                if (MemberHidden(mem.Id, info)) continue;
                if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
                if (!MemberShown(mem.Type)) continue;
                if (IsStoreDiagram(Diagram)) { DrawStoreDiagram(mem, S(na), S(nb), k); continue; }
                var r = Output.Members.FirstOrDefault(x => x.MemberId == mem.Id);
                if (r != null) DrawDiagram(r, S(na), S(nb), k);
            }

        DrawMemberAttrs(nodes, info);

        // charges
        if (ShowLoads) DrawLoads(nodes);

        if (Output != null && Diagram == DiagramKind.Reactions) DrawReactionLabels(nodes);

        // appuis
        var supB = ElementPalette.BrushOf("Support"); var nodeB = ElementPalette.BrushOf("Node");
        foreach (var s in Model.Supports)
        {
            if (!Attr.Supports) break;
            if (!nodes.TryGetValue(s.NodeId, out var n) || NodeHidden(s.NodeId, info)) continue;
            var p = S(n);
            _c.Children.Add(new Polygon { Fill = supB, Points = new PointCollection { p, new Point(p.X - 9, p.Y + 15), new Point(p.X + 9, p.Y + 15) } });
            if (s.Rx && s.Ry && s.Rz)
            {
                Ln(p.X - 14, p.Y + 16, p.X + 14, p.Y + 16, supB, 3);
                for (int i = -2; i <= 2; i++) Ln(p.X + i * 6, p.Y + 18, p.X + i * 6 - 5, p.Y + 24, supB, 1);
            }
        }

        // noeuds + étiquettes
        foreach (var n in nodes.Values)
        {
            if (NodeHidden(n.Id, info)) continue;
            var p = S(n);
            DrawNodeHalo(p, n.Id);
            if (Attr.NodeSymbols)
            {
                var e = new Ellipse { Width = 7, Height = 7, Fill = nodeB };
                Canvas.SetLeft(e, p.X - 3.5); Canvas.SetTop(e, p.Y - 3.5);
                _c.Children.Add(e);
            }
            if (ShowLabels && Attr.NodeNumbers) Text(n.Id.ToString(), p.X + 4, p.Y - 16, 9, Gray);
        }
        if (ShowLabels && Attr.MemberLabels)
            foreach (var mem in Model.Members)
            {
                if (MemberHidden(mem.Id, info)) continue;
                if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
                Point a = S(na), b = S(nb), m = new Point((a.X + b.X) / 2, (a.Y + b.Y) / 2);
                var r = Output?.Members.FirstOrDefault(x => x.MemberId == mem.Id);
                string sec = r != null ? r.SectionText : (mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}");
                bool col = mem.Type == MemberType.Column;
                Text($"{(col ? "P" : "B")}{mem.Id}  {sec}", col ? m.X + 7 : m.X - 22, col ? m.Y - 7 : m.Y + 6, 10, Dark, Br("#CCFFFFFF"), true);
            }

        DrawGridBubbles(info);
        DrawLevelTags(info);
        DrawElementHighlights();      // sélection : par-dessus toute la scène, identique dans toutes les vues
        DrawEditOverlay(nodes);
        DrawOverlay();
        DrawCube();
    }

    private IEnumerable<double[]> SeriesOf(MemberDesignResult r)
    {
        switch (Diagram)
        {
            case DiagramKind.Moment: yield return r.StMsag; yield return r.StMhog; break;
            case DiagramKind.Shear: yield return r.StV; break;
            case DiagramKind.Normal: yield return r.StNc; break;
        }
    }

    private void DrawDiagram(MemberDesignResult r, Point a, Point b, double k)
    {
        if (r.StX.Length < 2) return;
        double dx = b.X - a.X, dy = b.Y - a.Y, len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 6) return;
        double nx = -dy / len, ny = dx / len;
        if (Math.Abs(ny) < 0.3) { if (nx < 0) { nx = -nx; ny = -ny; } }
        else if (ny < 0) { nx = -nx; ny = -ny; }
        int n = r.StX.Length;

        void Poly(double[] vals, double sign, Brush fill, Brush stroke, string unit)
        {
            if (vals.Length != n || vals.Max() < 1e-6) return;
            var pts = new PointCollection();
            for (int i = 0; i < n; i++) pts.Add(new Point(a.X + dx * i / (n - 1), a.Y + dy * i / (n - 1)));
            for (int i = n - 1; i >= 0; i--)
                pts.Add(new Point(a.X + dx * i / (n - 1) + nx * sign * vals[i] * k, a.Y + dy * i / (n - 1) + ny * sign * vals[i] * k));
            _c.Children.Add(new Polygon { Points = pts, Fill = fill, Stroke = stroke, StrokeThickness = 1 });
            int imax = Array.IndexOf(vals, vals.Max());
            Text(vals[imax].ToString("0") + unit, a.X + dx * imax / (n - 1) + nx * sign * (vals[imax] * k + 6) - 8,
                 a.Y + dy * imax / (n - 1) + ny * sign * (vals[imax] * k + 6) - 7, 9, Dark, Br("#CCFFFFFF"));
        }

        switch (Diagram)
        {
            case DiagramKind.Moment:
                Poly(r.StMsag, 1, Br("#664A90E2"), Br("#1565C0"), "");
                Poly(r.StMhog, -1, Br("#66F5A623"), Br("#E65100"), "");
                break;
            case DiagramKind.Shear: Poly(r.StV, 1, Br("#6643A047"), Br("#2E7D32"), ""); break;
            case DiagramKind.Normal: Poly(r.StNc, 1, Br("#66AB47BC"), Br("#6A1B9A"), ""); break;
        }
    }

    private void DrawLoads(Dictionary<int, Node> nodes)
    {
        if (Model == null) return;
        if (Attr.SurfaceLoads) DrawSurfaceLoads();
        if (Attr.MemberLoads) DrawMemberLoads(nodes);

        if (Attr.NodalLoads)
        foreach (var l in Model.NodalLoads)
        {
            if (!nodes.TryGetValue(l.NodeId, out var n) || NodeHidden(l.NodeId, GetInfo())) continue;
            double fx = l.Fx, fy = l.Fy, fz = l.Fz;
            double mag = Math.Sqrt(fx * fx + fy * fy + fz * fz);
            if (mag < 1e-9) continue;
            var w = W(fx / mag, fy / mag, fz / mag);
            double sx = w.X, sy = -w.Y, sl = Math.Sqrt(sx * sx + sy * sy);
            if (sl < 0.1) continue;
            sx /= sl; sy /= sl;
            var tip = S(n);
            var tail = new Point(tip.X - sx * 38, tip.Y - sy * 38);
            var br = CaseBrush(l.Case);
            Arrow(tail, tip, br, 2.2);
            AddHit(l, tail, new Point(tail.X + (tip.X - tail.X) * 0.75, tail.Y + (tip.Y - tail.Y) * 0.75));
            LoadText(l, $"{l.Case} {mag:0.#} kN", tail.X - 10, tail.Y - 14, br, null);
        }
    }

    private void DrawOverlay()
    {
        // trièdre
        double ox = 40, oy = _c.ActualHeight - 40;
        foreach (var (vx, vy, vz, name, col) in new[] { (1.0, 0.0, 0.0, "X", "#D32F2F"), (0.0, 1.0, 0.0, "Y", "#388E3C"), (0.0, 0.0, 1.0, "Z", "#1976D2") })
        {
            var w = W(vx, vy, vz);
            double sx = w.X * 30, sy = -w.Y * 30;
            if (Math.Sqrt(sx * sx + sy * sy) < 4) continue;
            Arrow(new Point(ox, oy), new Point(ox + sx, oy + sy), Br(col), 1.8);
            Text(name, ox + sx * 1.2 - 4, oy + sy * 1.2 - 8, 10, Br(col), null, true);
        }
        string vue = Mode switch { ViewMode.Elevation => "Élévation (XZ)", ViewMode.Plan => "Plan (XY)", ViewMode.Side => "Côté (YZ)", _ => "3D" };
        Text("Vue : " + vue + "   ·   Style : " + StyleName + (UsePersp ? "   ·   perspective" : ""), 10, 8, 11, Dark, null, true);
        if (Output != null)
        {
            double x = 10, y = 28;
            foreach (var (txt, br) in new[] { ("OK", Ok), ("NON OK", Ko), ("non traité", Skip) })
            {
                _c.Children.Add(new Rectangle { Width = 22, Height = 5, Fill = br, Margin = new Thickness(x, y + 6, 0, 0) });
                Text(txt, x + 26, y, 10, Dark);
                x += 26 + txt.Length * 6.5 + 14;
            }
            if (Diagram == DiagramKind.Moment) Text("Moment : bleu = travée (fibre inf. tendue), orange = appui", 10, 46, 10, Dark);
            else if (Diagram == DiagramKind.Shear) Text("Effort tranchant |V| max (kN)", 10, 46, 10, Dark);
            else if (Diagram == DiagramKind.Normal) Text("Effort normal de compression max (kN)", 10, 46, 10, Dark);
            else if (IsStoreDiagram(Diagram)) Text($"{ResultsStore.QtyName(QtyOf(Diagram))} ({ResultsStore.QtyUnit(QtyOf(Diagram))}) - {DiagramSource}" + (Diagram == DiagramKind.NSigned ? " : rouge = traction, bleu = compression" : (Diagram is DiagramKind.My or DiagramKind.Mz) ? " : My > 0 = fibre supérieure tendue" : ""), 10, 46, 10, Dark);
            else if (Diagram == DiagramKind.Reactions) Text($"Réactions d'appui - {DiagramSource} (min / max, kN)", 10, 46, 10, Dark);
        }
        Text("Molette : zoom   |   Clic : sélectionner (2e clic au même endroit : l'élément derrière)   |   Ctrl+clic : ajouter / retirer   |   Maj+clic : retirer   |   Glisser (plan, élévation, côté) ou Ctrl/Maj+glisser : rectangle   |   Échap : vider   |   Bouton milieu : orbite (Maj = déplacer)   |   Clic droit glissé : déplacer   |   Double-clic : zoom"
             + (Mode == ViewMode.Iso ? "   |   Glisser : tourner" : ""), 10, _c.ActualHeight - 20, 10, Gray);
    }

    // ------------------------------------------------------------------ outils de modélisation
    private bool ToWorld(Point p, out double x, out double y, out double z)
    {
        double u = (p.X - _ox) / _scale, v = (_oy - p.Y) / _scale;
        x = y = z = 0;
        switch (Mode)
        {
            case ViewMode.Elevation: x = u; z = v; y = WorkOffset; return true;
            case ViewMode.Plan: x = u; y = v; z = WorkOffset; return true;
            case ViewMode.Side: y = u; z = v; x = WorkOffset; return true;
            default: return false;
        }
    }

    private double Sn(double v) => Math.Round(Math.Round(v / GridStep) * GridStep, 6);

    private int NearestNode(Point p, double tol)
    {
        if (Model == null) return -1;
        int best = -1; double bd = tol;
        foreach (var n in Model.Nodes)
        {
            var q = S(n);
            double d = Math.Sqrt((q.X - p.X) * (q.X - p.X) + (q.Y - p.Y) * (q.Y - p.Y));
            if (d < bd) { bd = d; best = n.Id; }
        }
        return best;
    }

    private int GetOrCreateNode(Point p)
    {
        if (Model == null) return -1;
        var hit = ComputeSnap(p);
        if (hit == null) return -1;
        if (hit.NodeId != -1) return hit.NodeId;
        double x, y, z;
        if (hit.World is Vec3 w) { x = w.X; y = w.Y; z = w.Z; } else PlaneWorld(hit.U, hit.V, out x, out y, out z);
        x = Math.Round(x, 6); y = Math.Round(y, 6); z = Math.Round(z, 6);
        var same = Model.Nodes.FirstOrDefault(n => Math.Abs(n.X - x) < 1e-6 && Math.Abs(n.Y - y) < 1e-6 && Math.Abs(n.Z - z) < 1e-6);
        if (same != null) return same.Id;
        int id = Model.Nodes.Count == 0 ? 1 : Model.Nodes.Max(n => n.Id) + 1;
        Model.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
        return id;
    }

    private void AddMember(int a, int b)
    {
        if (Model == null) return;
        var na = Model.Nodes.First(x => x.Id == a); var nb = Model.Nodes.First(x => x.Id == b);
        double dx = nb.X - na.X, dy = nb.Y - na.Y, dz = nb.Z - na.Z, L = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        bool vertical = L > 0 && Math.Abs(dz) > 0.7 * L;
        if (vertical && dz < 0) (a, b) = (b, a);
        if (Model.Members.Any(m => (m.NodeI == a && m.NodeJ == b) || (m.NodeI == b && m.NodeJ == a))) return;
        int id = Model.Members.Count == 0 ? 1 : Model.Members.Max(m => m.Id) + 1;
        Model.Members.Add(new Member
        {
            Id = id, NodeI = a, NodeJ = b,
            Type = vertical ? MemberType.Column : MemberType.Beam,
            Kind = NewSteel ? MaterialKind.Steel : MaterialKind.ReinforcedConcrete,
            B = NewB, H = NewH, Cover = (vertical ? Model.Settings.CoverColumnCm : Model.Settings.CoverBeamCm) / 100.0,
            CoverNomCm = vertical ? Model.Settings.CoverNomColumnCm : Model.Settings.CoverNomBeamCm,
            Profile = NewSteel ? NewProfile : "", LfFactor = NewSteel ? 1.0 : (vertical ? 0.7 : 1.0)
        });
    }

    private void DeleteMember(int id)
    {
        if (Model == null) return;
        foreach (var l in Model.MemberLoads.Where(x => x.MemberId == id).ToList()) Model.MemberLoads.Remove(l);
        var mem = Model.Members.FirstOrDefault(x => x.Id == id);
        if (mem != null) Model.Members.Remove(mem);
        _sel.Remove(id); if (_primary == id) _primary = _sel.Count > 0 ? _sel.First() : -1;
    }

    private void DeleteNode(int n)
    {
        if (Model == null) return;
        foreach (var mem in Model.Members.Where(x => x.NodeI == n || x.NodeJ == n).ToList()) DeleteMember(mem.Id);
        foreach (var s in Model.Supports.Where(x => x.NodeId == n).ToList()) Model.Supports.Remove(s);
        foreach (var l in Model.NodalLoads.Where(x => x.NodeId == n).ToList()) Model.NodalLoads.Remove(l);
        var node = Model.Nodes.FirstOrDefault(x => x.Id == n);
        if (node != null) Model.Nodes.Remove(node);
        if (_pendingNodeId == n) _pendingNodeId = -1;
    }

    private void HandleEditClick(Point p)
    {
        if (Model == null) return;
        switch (Tool)
        {
            case EditTool.Slab:
            {
                if (Mode != ViewMode.Plan) { Hint?.Invoke("Dalle : passez en vue Plan (le niveau de travail donne la cote de la dalle)."); return; }
                if (SlabByBay)
                {
                    if (!ToWorld(p, out double bwx, out double bwy, out double bwz)) return;
                    var (bu, bv) = PlaneOf(bwx, bwy, bwz);
                    if (!BayAt(bu, bv, out double bx0, out double bx1, out double by0, out double by1)) { Hint?.Invoke("Pas de trame fermée ici : il faut des axes ou des nœuds de chaque côté (ou dessinez par deux coins)."); return; }
                    SlabDrawn?.Invoke(bx0, by0, bx1, by1, WorkOffset);
                    Redraw();
                    break;
                }
                var hit = ComputeSnap(p);
                if (hit == null) return;
                if (_slabA == null) { _slabA = (hit.U, hit.V); Hint?.Invoke("Dalle : cliquez le coin opposé (Échap pour annuler)."); Redraw(); return; }
                var a = _slabA.Value; _slabA = null;
                double x0 = Math.Min(a.U, hit.U), x1 = Math.Max(a.U, hit.U), y0 = Math.Min(a.V, hit.V), y1 = Math.Max(a.V, hit.V);
                if (x1 - x0 < 0.5 || y1 - y0 < 0.5) { Hint?.Invoke("Dalle trop petite (0,50 m minimum dans chaque sens) : recommencez."); Redraw(); return; }
                SlabDrawn?.Invoke(x0, y0, x1, y1, WorkOffset);
                Redraw();
                break;
            }
            case EditTool.Stair:
                HandleStairClick(p);
                break;
            case EditTool.Dim:
                HandleDimClick(p);
                break;
            case EditTool.Node:
                BeforeEdit?.Invoke();
                GetOrCreateNode(p);
                ModelEdited?.Invoke();
                break;
            case EditTool.Member:
            {
                BeforeEdit?.Invoke();
                int n = GetOrCreateNode(p);
                if (n == -1) return;
                if (_pendingNodeId != -1 && _pendingNodeId != n) AddMember(_pendingNodeId, n);
                _pendingNodeId = n;
                ModelEdited?.Invoke();
                if (Mode == ViewMode.Iso) Hint?.Invoke($"3D : cliquez le point suivant - sur le plan de travail (Z = {WorkOffset:0.##} m) pour une poutre, ou sur la verticale du nœud (accrochée aux niveaux) pour un poteau.");
                Redraw();
                break;
            }
            case EditTool.Support:
            {
                int n = NearestNode(p, 14);
                if (n == -1) { Hint?.Invoke("Cliquez sur un nœud existant pour poser ou retirer un appui."); return; }
                BeforeEdit?.Invoke();
                var ex = Model.Supports.FirstOrDefault(s => s.NodeId == n);
                if (ex != null) Model.Supports.Remove(ex);
                else Model.Supports.Add(SupportFixed ? new SupportDef { NodeId = n } : new SupportDef { NodeId = n, Rx = false, Ry = false, Rz = false });
                ModelEdited?.Invoke();
                Redraw();
                break;
            }
            case EditTool.Delete:
            {
                int n = NearestNode(p, 9);
                int mid = n == -1 ? HitTest(p) : -1;
                if (n == -1 && mid == -1)
                {
                    var ob = PickObject(p);
                    if (ob != null) { SelectObject(ob, false); var msg = DeleteSelectedObject(); if (msg != "") Hint?.Invoke(msg); return; }
                    var el = CandidatesAt(p).Where(k => k.Kind != ElementKind.Bar && k.Kind != ElementKind.Node).Cast<ElementKey?>().FirstOrDefault();
                    if (el is ElementKey ek && ek.Kind == ElementKind.Slab && ObjectOf(ek) is SlabPanel sl) { BeforeEdit?.Invoke(); DeleteSlab(sl); ModelEdited?.Invoke(); Redraw(); }
                    else if (el is ElementKey ek2)
                    {
                        // les autres éléments (escalier, voile, radier, plancher, coque...) passent par la sélection centrale : Suppr, avec confirmation
                        SelectKeys(new[] { ek2 }, 'n');
                        Hint?.Invoke(DescribeElement(ek2) + "  ·  sélectionné : Suppr pour le supprimer (avec confirmation, annulable par Ctrl+Z).");
                    }
                    return;
                }
                BeforeEdit?.Invoke();
                if (n != -1) DeleteNode(n); else DeleteMember(mid);
                ModelEdited?.Invoke();
                Redraw();
                break;
            }
        }
    }

    private void DrawEditOverlay(Dictionary<int, Node> nodes)
    {
        if (Issues != null)
        {
            var red = Br("#C62828");
            foreach (var iss in Issues)
            {
                if (iss.NodeId is int nid && nodes.TryGetValue(nid, out var nd))
                {
                    var q = S(nd);
                    var el = new Ellipse { Width = 26, Height = 26, Stroke = red, StrokeThickness = 2.5 };
                    Canvas.SetLeft(el, q.X - 13); Canvas.SetTop(el, q.Y - 13);
                    _c.Children.Add(el);
                }
                if (iss.MemberId is int mid)
                {
                    foreach (var h in _hit.Where(x => x.Id == mid)) Ln(h.A.X, h.A.Y, h.B.X, h.B.Y, Br("#80C62828"), 10);
                }
            }
        }
        DrawSnapOverlay(nodes);
        DrawSlabRubber();
        DrawStairRubber();
        DrawDimRubber();
        DrawBox();
    }

    // ------------------------------------------------------------------ souris
    private static double DistToSegment(Point p, Point a, Point b)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-9 ? 0 : Math.Max(0, Math.Min(1, ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / l2));
        double qx = a.X + t * dx, qy = a.Y + t * dy;
        return Math.Sqrt((p.X - qx) * (p.X - qx) + (p.Y - qy) * (p.Y - qy));
    }

    private int HitTest(Point p)
    {
        int f = HitFaces(p);
        if (f != -1) return f;
        int best = -1; double bd = 10;
        foreach (var h in _hit)
        {
            double d = DistToSegment(p, h.A, h.B);
            if (d < bd) { bd = d; best = h.Id; }
        }
        return best;
    }

    private void OnWheel(object sender, MouseWheelEventArgs e)
    {
        var p = e.GetPosition(_c);
        double f = e.Delta > 0 ? 1.15 : 1 / 1.15;
        _ox = p.X - (p.X - _ox) * f; _oy = p.Y - (p.Y - _oy) * f; _scale *= f;
        Redraw();
    }

    private void OnLeftDown(object sender, MouseButtonEventArgs e)
    {
        if (CubeLeftDown(e.GetPosition(_c))) return;
        _down = e.GetPosition(_c); _last = _down; _moved = false; _rotating = Mode == ViewMode.Iso;
        _c.CaptureMouse();
        _box = false; _boxArmed = false;
        if (Tool == EditTool.Select && !Picking && e.ClickCount == 1)
        {
            Mod(out bool cc, out bool ss);
            if (cc || ss) { _rotating = false; _boxMode = ss && !cc ? 'r' : 'a'; _boxA = _boxB = _down; _boxArmed = true; return; }
            // plan, élévation, côté : glisser = rectangle de sélection (déplacer la vue : clic droit ou bouton milieu glissé) ; en 3D, glisser = tourner
            if (Mode != ViewMode.Iso) { _rotating = false; _boxMode = 'n'; _boxA = _boxB = _down; _boxArmed = true; return; }
        }
        if (e.ClickCount == 2 && Tool == EditTool.Select && !Picking)
        {
            _suppressUp = true;
            var dbl = CandidatesAt(_down);
            if (dbl.Count > 0) { SelectKeys(new[] { dbl[0] }, 'n'); ZoomSelection(); }
            else ZoomExtents();
            return;
        }
        if (_rotating) _pivot = ComputePivot();
    }

    private void OnLeftUp(object sender, MouseButtonEventArgs e)
    {
        if (CubeLeftUp(e.GetPosition(_c))) return;
        _c.ReleaseMouseCapture(); _rotating = false;
        if (_suppressUp) { _suppressUp = false; return; }
        if (_box)
        {
            _box = false; _boxArmed = false;
            var inBox = KeysInBox(_boxA, _boxB);
            if (inBox.Count > 0) { SelectKeys(inBox, _boxMode); Hint?.Invoke($"{inBox.Count} élément(s) dans le rectangle ({(_boxB.X < _boxA.X ? "tout ce qui touche" : "entièrement dedans")})."); }
            else Redraw();
            return;
        }
        if (_moved) return;
        if (Picking) { HandlePickClick(e.GetPosition(_c)); return; }
        if (Tool != EditTool.Select) { HandleEditClick(e.GetPosition(_c)); return; }
        var pos = e.GetPosition(_c);
        Mod(out bool ctrl, out bool shift);
        SelectClick(pos, ctrl, shift);
    }

    private void OnRightDown(object sender, MouseButtonEventArgs e)
    {
        if (CubeRightDown(e.GetPosition(_c))) return;
        _panning = true; _last = e.GetPosition(_c); _c.CaptureMouse();
        _rightDown = _last; _rightMoved = false; _rightArmed = true;
    }

    private void OnRightUp(object sender, MouseButtonEventArgs e)
    {
        bool click = _rightArmed && !_rightMoved;
        _rightArmed = false; _panning = false; _c.ReleaseMouseCapture();
        if (click) HandleRightClick(e.GetPosition(_c));    // clic droit sans glisser = menu contextuel (glisser = déplacer la vue)
    }

    private void OnMove(object sender, MouseEventArgs e)
    {
        var p = e.GetPosition(_c);
        _cursor = p; _cursorValid = true;
        if (CubeMove(p)) return;
        if (e.LeftButton != MouseButtonState.Pressed && !_panning && !_orbiting && !_midPanning && CubeHover(p)) return;
        if (_orbiting) { OrbitBy((p.X - _last.X) * 0.008, (p.Y - _last.Y) * 0.008); _last = p; Redraw(); return; }
        if (_midPanning) { _ox += p.X - _last.X; _oy += p.Y - _last.Y; _last = p; Redraw(); return; }
        if (Tool == EditTool.Select && !_panning && e.LeftButton != MouseButtonState.Pressed && e.RightButton != MouseButtonState.Pressed)
        {
            int hn = NodeAt(p, 7);
            int hv = hn == -1 ? HitTest(p) : -1;
            if (hv != _hoverId || hn != _hoverNode) { _hoverId = hv; _hoverNode = hn; HoverChanged?.Invoke(hn != -1 ? DescribeNode(hn) : DescribeHover(hv)); Redraw(); }
        }
        if ((Tool != EditTool.Select || Picking) && !_panning && e.LeftButton != MouseButtonState.Pressed)
        {
            // en 3D le redessin est plus lourd : au plus un toutes les 30 ms
            if (Mode != ViewMode.Iso || (DateTime.UtcNow - _lastIsoRedraw).TotalMilliseconds > 30) { _lastIsoRedraw = DateTime.UtcNow; Redraw(); }
        }
        if (_panning)
        {
            if (_rightArmed && (Math.Abs(p.X - _rightDown.X) > 4 || Math.Abs(p.Y - _rightDown.Y) > 4)) _rightMoved = true;
            _ox += p.X - _last.X; _oy += p.Y - _last.Y; _last = p; Redraw();
        }
        else if (e.LeftButton == MouseButtonState.Pressed)
        {
            // en dessin (barre, nœud, appui, dalle...) ou pendant une désignation, le bouton gauche ne déplace JAMAIS la vue :
            // un clic légèrement tremblant posait avant un « glissement » de caméra au lieu du point (pan = clic droit / molette)
            if (Tool != EditTool.Select || Picking) return;
            if (!_moved && (Math.Abs(p.X - _down.X) > 6 || Math.Abs(p.Y - _down.Y) > 6)) _moved = true;
            if (_moved && Tool == EditTool.Select && !Picking && _boxArmed)
            {
                MoveBox(p); return;
            }
            if (_moved)
            {
                if (_rotating) OrbitBy((p.X - _last.X) * 0.01, (p.Y - _last.Y) * 0.01);
                else { _ox += p.X - _last.X; _oy += p.Y - _last.Y; }
                _last = p; Redraw();
            }
        }
    }
}
