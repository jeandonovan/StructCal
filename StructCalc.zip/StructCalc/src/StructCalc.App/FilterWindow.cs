using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

/// <summary>Filtre de sélection : choisir les familles d'éléments (barres, nœuds, dalles, escaliers, semelles, voiles, radiers, planchers nervurés, coques),
/// puis pour les barres : type, matériau, direction, niveau, section, longueur, charge, résultat du calcul. Deux filtres communs à toutes les familles :
/// « NON OK après calcul » et « avec messages ». La fenêtre reste ouverte pour enchaîner des filtres (remplacer, ajouter, retirer, restreindre).</summary>
public sealed class FilterWindow : Window
{
    private readonly Func<StructModel> _model;
    private readonly Func<AnalysisOutput?> _out;
    private readonly Func<List<ElementKey>> _sel;
    private readonly Action<IEnumerable<ElementKey>, char> _set;
    private readonly Func<IReadOnlyCollection<AppMessage>> _msgs;
    private readonly Func<ElementKey, bool> _hidden;
    private readonly Dictionary<ElementKind, CheckBox> _kinds = new();
    private readonly CheckBox _nonOk = new() { Content = "NON OK après calcul (toutes les familles cochées)" };
    private readonly CheckBox _withMsg = new() { Content = "avec messages (toutes les familles cochées)" };
    private readonly CheckBox _beams = new() { Content = "Poutres", IsChecked = true }, _cols = new() { Content = "Poteaux", IsChecked = true };
    private readonly CheckBox _rc = new() { Content = "Béton armé", IsChecked = true }, _steel = new() { Content = "Acier", IsChecked = true };
    private readonly CheckBox _ax = new() { Content = "Parallèles à X", IsChecked = true }, _ay = new() { Content = "Parallèles à Y", IsChecked = true };
    private readonly CheckBox _vert = new() { Content = "Verticales", IsChecked = true }, _inc = new() { Content = "Inclinées", IsChecked = true };
    private readonly CheckBox _fail = new() { Content = "Seulement les barres NON conformes (après calcul)" };
    private readonly ListBox _levels = new() { SelectionMode = SelectionMode.Multiple, Height = 110 };
    private readonly TextBox _section = new() { Padding = new Thickness(3) }, _minL = new() { Text = "0", Padding = new Thickness(3) }, _maxL = new() { Text = "0", Padding = new Thickness(3) };
    private readonly TextBox _util = new() { Text = "0", Padding = new Thickness(3) }, _ids = new() { Padding = new Thickness(3) };
    private readonly ComboBox _loads = new(), _mode = new();
    private readonly TextBlock _res = new() { Margin = new Thickness(0, 8, 0, 0), Foreground = Brushes.DarkGreen, TextWrapping = TextWrapping.Wrap };
    private List<int> _levelIdx = new();

    public FilterWindow(Func<StructModel> model, Func<AnalysisOutput?> output, Func<IReadOnlyCollection<AppMessage>> messages,
                        Func<List<ElementKey>> selection, Action<IEnumerable<ElementKey>, char> set, Func<ElementKey, bool> isHidden)
    {
        _model = model; _out = output; _msgs = messages; _sel = selection; _set = set; _hidden = isHidden;
        Title = "Filtre de sélection";
        Width = 560; Height = 900; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var sp = new StackPanel { Margin = new Thickness(14) };
        sp.Children.Add(Head("Éléments à sélectionner (une case décochée = cette famille n'est pas touchée ; (n) = nombre dans le modèle)"));
        foreach (var k in ElementKinds.Order)
        {
            var cb = new CheckBox { Content = Capital(ElementKinds.Plural(k)), IsChecked = k == ElementKind.Bar };
            _kinds[k] = cb;
        }
        sp.Children.Add(Row(_kinds.Values.Cast<UIElement>().ToArray()));
        sp.Children.Add(Head("Filtres communs à toutes les familles cochées"));
        sp.Children.Add(_nonOk);
        sp.Children.Add(_withMsg);
        sp.Children.Add(Head("Critères des barres (ne s'appliquent qu'aux barres)"));
        sp.Children.Add(Head("Type et matériau"));
        sp.Children.Add(Row(_beams, _cols, _rc, _steel));
        sp.Children.Add(Head("Direction"));
        sp.Children.Add(Row(_ax, _ay, _vert, _inc));
        sp.Children.Add(Head("Niveau (barres dont le nœud bas est à ce niveau) - rien de choisi = tous"));
        sp.Children.Add(_levels);
        sp.Children.Add(Head("Section / profilé / longueur"));
        sp.Children.Add(Labeled("Section contient (ex. 30x50, IPE, HEA) :", _section));
        sp.Children.Add(Labeled("Longueur minimale (m) :", _minL));
        sp.Children.Add(Labeled("Longueur maximale (m, 0 = illimitée) :", _maxL));
        sp.Children.Add(Labeled("N° de barres (ex. 1-12, 20, 25) :", _ids));
        sp.Children.Add(Head("Charges et résultats"));
        foreach (var t in new[] { "Indifférent", "Avec charge(s)", "Sans aucune charge" }) _loads.Items.Add(t);
        _loads.SelectedIndex = 0;
        sp.Children.Add(Labeled("Charges sur la barre :", _loads));
        sp.Children.Add(_fail);
        sp.Children.Add(Labeled("Taux de travail minimal (0 à 1, ex. 0,8) :", _util));
        sp.Children.Add(Head("Résultat du filtre"));
        foreach (var t in new[] { "Remplacer la sélection", "Ajouter à la sélection", "Retirer de la sélection", "Restreindre la sélection actuelle" }) _mode.Items.Add(t);
        _mode.SelectedIndex = 0;
        sp.Children.Add(_mode);
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 0) };
        bar.Children.Add(Ui.Btn("Appliquer le filtre", (s, e) => Apply(), true));
        bar.Children.Add(Ui.Btn("Réinitialiser", (s, e) => Reset()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        sp.Children.Add(bar);
        sp.Children.Add(_res);
        Content = new ScrollViewer { Content = sp, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        Activated += (s, e) => FillLevels();
        Loaded += (s, e) => FillLevels();
    }

    private static TextBlock Head(string t) => new() { Text = t, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 10, 0, 4), Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), TextWrapping = TextWrapping.Wrap };
    private static WrapPanel Row(params UIElement[] c) { var w = new WrapPanel(); foreach (var x in c) { ((FrameworkElement)x).Margin = new Thickness(0, 2, 14, 2); w.Children.Add(x); } return w; }
    private static Grid Labeled(string label, UIElement ctl)
    {
        var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(290) }); g.ColumnDefinitions.Add(new ColumnDefinition());
        g.Children.Add(new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center });
        Grid.SetColumn(ctl, 1); g.Children.Add(ctl);
        return g;
    }

    private static string Capital(string t) => t.Length == 0 ? t : char.ToUpper(t[0]) + t[1..];

    /// <summary>Nombre d'éléments de chaque famille dans le modèle : une famille absente n'est pas cochable (la commande ne pourrait rien faire).</summary>
    private void FillCounts()
    {
        var m = _model(); var o = _out();
        foreach (var k in ElementKinds.Order)
        {
            int n = ElementCatalog.All(m, o, k).Count;
            var cb = _kinds[k];
            string name = Capital(ElementKinds.Plural(k));
            cb.Content = $"{name} ({n})";
            cb.IsEnabled = n > 0;
            if (n == 0) cb.IsChecked = false;
            cb.ToolTip = n == 0 ? (k == ElementKind.Footing ? "Aucune semelle : elles apparaissent après le calcul (semelles sous appuis) ou par une semelle filante posée." : "Aucun élément de cette famille dans le modèle.") : null;
        }
    }

    private int _levelCount = -1;
    private void FillLevels()
    {
        FillCounts();
        var info = StructureAnalyzer.Analyze(_model());
        if (info.Levels.Count == _levelCount) return;
        _levelCount = info.Levels.Count;
        _levels.Items.Clear(); _levelIdx = new();
        for (int i = 0; i < info.Levels.Count; i++) { _levels.Items.Add($"{info.Levels[i].Name}  (Z = {info.Levels[i].Z:0.##} m)"); _levelIdx.Add(i); }
    }

    private void Reset()
    {
        foreach (var c in new[] { _beams, _cols, _rc, _steel, _ax, _ay, _vert, _inc }) c.IsChecked = true;
        foreach (var kv in _kinds) kv.Value.IsChecked = kv.Key == ElementKind.Bar;
        _nonOk.IsChecked = false; _withMsg.IsChecked = false;
        _fail.IsChecked = false; _levels.UnselectAll(); _section.Text = ""; _minL.Text = "0"; _maxL.Text = "0"; _util.Text = "0"; _ids.Text = ""; _loads.SelectedIndex = 0; _mode.SelectedIndex = 0;
        _res.Text = "";
    }

    private void Apply()
    {
        var spec = new SelectionFilterSpec
        {
            Beams = _beams.IsChecked == true, Columns = _cols.IsChecked == true, Concrete = _rc.IsChecked == true, Steel = _steel.IsChecked == true,
            AlongX = _ax.IsChecked == true, AlongY = _ay.IsChecked == true, Vertical = _vert.IsChecked == true, Inclined = _inc.IsChecked == true,
            Section = _section.Text, MinLength = Ui.Num(_minL.Text, 0), MaxLength = Ui.Num(_maxL.Text, 0), FailingOnly = _fail.IsChecked == true,
            MinUtilization = Ui.Num(_util.Text, 0), Ids = _ids.Text, Loads = Math.Max(0, _loads.SelectedIndex),
        };
        if (_levels.SelectedItems.Count > 0) spec.Levels = new HashSet<int>(_levels.SelectedItems.Cast<object>().Select(o => _levels.Items.IndexOf(o)));
        var espec = new ElementFilterSpec { NonOkOnly = _nonOk.IsChecked == true, WithMessagesOnly = _withMsg.IsChecked == true };
        foreach (var kv in _kinds) espec.Set(kv.Key, kv.Value.IsChecked == true && kv.Value.IsEnabled);
        if (!ElementKinds.Order.Any(espec.Has)) { _res.Foreground = Brushes.Firebrick; _res.Text = "Cochez au moins une famille d'éléments."; return; }
        if ((spec.FailingOnly || spec.MinUtilization > 0 || espec.NonOkOnly) && _out() == null) { _res.Foreground = Brushes.Firebrick; _res.Text = "Lancez d'abord le calcul (F5) pour filtrer sur les résultats."; return; }
        var cur = _sel();
        int mode = _mode.SelectedIndex;
        var found = ElementFilter.Apply(_model(), _out(), _msgs(), spec, espec, _hidden, mode == 3 ? cur : null);
        _set(found, mode == 1 ? 'a' : mode == 2 ? 'r' : 'n');
        _res.Foreground = Brushes.DarkGreen;
        _res.Text = found.Count == 0
            ? "Aucun élément ne correspond au filtre."
            : "Correspondent au filtre : " + SelectionSummary.Describe(found) + ". Les éléments masqués sont ignorés.";
    }
}
