using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Niveaux (étages) : liste nommable dans la barre du bas, invite de commande (niveau, renommer, copier, aller, etages) et actions de l'arborescence.</summary>
public partial class MainWindow
{
    private bool _cmdBusy;
    private readonly List<string> _cmdHistory = new();
    private int _cmdPos;

    private StructureInfo LevelInfoNow() => StructureAnalyzer.Analyze(_model, _panel?.Tolerance ?? 0.05);

    /// <summary>Recharge la liste des niveaux de la barre de commande (conserve le niveau de travail courant).</summary>
    private void RefreshLevelCombo()
    {
        if (CmdLevels == null) return;
        var info = LevelInfoNow();
        int keep = CmdLevels.SelectedIndex;
        _cmdBusy = true;
        CmdLevels.Items.Clear();
        foreach (var lv in info.Levels) CmdLevels.Items.Add($"{lv.Index} · {lv.Label}");
        int sel = info.Levels.FindIndex(l => Math.Abs(l.Z - _vp.WorkOffset) < 1e-3);
        CmdLevels.SelectedIndex = sel >= 0 ? sel : Math.Min(keep, info.Levels.Count - 1);
        _cmdBusy = false;
    }

    private void CmdLevels_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_cmdBusy || CmdLevels.SelectedIndex < 0) return;
        GoToLevel(CmdLevels.SelectedIndex, false);
    }

    private void GoToLevel(int idx, bool zoom)
    {
        var info = LevelInfoNow();
        if (idx < 0 || idx >= info.Levels.Count) { Say($"Niveau {idx} inexistant (0 à {info.Levels.Count - 1})."); return; }
        var lv = info.Levels[idx];
        WorkBox.Text = lv.Z.ToString("0.###", CultureInfo.InvariantCulture);
        _vp.WorkOffset = lv.Z;
        if (zoom) _vp.ZoomToLevel(idx);
        _vp.Redraw();
        _cmdBusy = true; if (CmdLevels.SelectedIndex != idx && idx < CmdLevels.Items.Count) CmdLevels.SelectedIndex = idx; _cmdBusy = false;
        Say($"Plan de travail : {lv.Label}.");
    }

    private void Say(string msg) { StatusLeft.Text = msg; Log(msg); }

    // ------------------------------------------------------------------ actions
    private void DoAddLevel(string name, double z)
    {
        if (double.IsNaN(z) || double.IsInfinity(z)) { Say("Cote invalide."); return; }
        PushUndo();
        if (!LevelOps.AddLevel(_model, LevelInfoNow(), name, z, out string msg)) { Say(msg); return; }
        OnModelEdited(); RefreshLevelCombo(); Say(msg);
    }

    private void DoRename(int idx, string name)
    {
        PushUndo();
        if (!LevelOps.Rename(_model, LevelInfoNow(), idx, name, out string msg)) { Say(msg); return; }
        OnModelEdited(); RefreshLevelCombo(); Say(msg);
    }

    private void DoCopy(int src, int dst, string cat)
    {
        bool all = cat is "all" or "tout", c = all || cat is "columns" or "poteaux", b = all || cat is "beams" or "poutres", s = all || cat is "slabs" or "dalles";
        if (!c && !b && !s) { Say($"Contenu « {cat} » inconnu : tout, poteaux, poutres ou dalles."); return; }
        PushUndo();
        var rep = LevelOps.Copy(_model, LevelInfoNow(), src, dst, c, b, s);
        OnModelEdited(); RefreshLevelCombo();
        Say($"Copie du niveau {src} vers {dst} : {rep.Summary}");
    }

    private void DoFloors(int count, double height)
    {
        if (count < 1 || count > 80 || height < 1.5 || height > 10) { Say("etages : nombre de 1 à 80 et hauteur de 1,5 à 10 m."); return; }
        PushUndo();
        LevelOps.BuildFloors(_model, count, height);
        OnModelEdited(); RefreshLevelCombo();
        Say($"{count} étage(s) de {height:0.##} m créés : Base, RDC, R+1... (renommables).");
    }

    // ------------------------------------------------------------------ boutons
    private void CmdAddLevel_Click(object sender, RoutedEventArgs e) => AskAddLevel();

    private void AskAddLevel()
    {
        var info = LevelInfoNow();
        double top = info.Levels.Count > 0 ? info.Levels[^1].Z : 0;
        double h = info.Levels.Count > 1 ? info.Levels[^1].Z - info.Levels[^2].Z : 3.0;
        var v = PromptWindow.Ask(this, "Ajouter un niveau", "Donnez un nom (RDC, R+3, Terrasse...) et la cote du plancher en mètres.",
            ("Nom du niveau", info.Levels.Count == 0 ? "Base" : $"Niveau {info.Levels.Count}"), ("Cote (m)", Math.Round(top + h, 3).ToString("0.###", CultureInfo.InvariantCulture)));
        if (v == null) return;
        DoAddLevel(v[0], Nm(v[1], double.NaN));
    }

    private void CmdRename_Click(object sender, RoutedEventArgs e) => AskRename(CmdLevels.SelectedIndex);

    private void AskRename(int idx)
    {
        var info = LevelInfoNow();
        if (idx < 0 || idx >= info.Levels.Count) { Say("Choisissez d'abord un niveau dans la liste."); return; }
        var v = PromptWindow.Ask(this, "Renommer le niveau", $"Niveau {idx} actuel : {info.Levels[idx].Label}", ("Nouveau nom", info.Levels[idx].Name));
        if (v == null) return;
        DoRename(idx, v[0]);
    }

    private void CmdCopy_Click(object sender, RoutedEventArgs e) => AskCopy(CmdLevels.SelectedIndex, "all");

    private void AskCopy(int src, string cat)
    {
        var info = LevelInfoNow();
        if (info.Levels.Count < 2) { Say("Il faut au moins deux niveaux : ajoutez-en un (＋ Niveau)."); return; }
        if (src < 0 || src >= info.Levels.Count) src = Math.Max(0, info.Levels.Count - 1);
        string list = string.Join("\n", info.Levels.Select(l => $"  {l.Index} = {l.Label}"));
        string catFr = cat switch { "columns" => "poteaux", "beams" => "poutres", "slabs" => "dalles", _ => "tout" };
        var v = PromptWindow.Ask(this, "Copier le contenu d'un niveau",
            "Copie vers le niveau de destination (les éléments déjà présents ne sont pas dupliqués).\nPoteaux : recréés entre le niveau inférieur de la destination et la destination.\nNiveaux :\n" + list,
            ("Niveau source (n°)", src.ToString()), ("Niveau destination (n°)", Math.Min(src + 1, info.Levels.Count - 1).ToString()), ("Contenu : tout / poteaux / poutres / dalles", catFr));
        if (v == null) return;
        DoCopy((int)Nm(v[0], -1), (int)Nm(v[1], -1), v[2].Trim().ToLowerInvariant());
    }

    // ------------------------------------------------------------------ invite de commande
    private static readonly Regex Tok = new("\"([^\"]*)\"|(\\S+)", RegexOptions.Compiled);

    private void CmdBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            string text = CmdBox.Text.Trim();
            CmdBox.Clear();
            e.Handled = true;
            if (text.Length == 0) return;
            _cmdHistory.Add(text); _cmdPos = _cmdHistory.Count;
            Log("› " + text);
            try { RunLevelCommand(text); } catch (Exception ex) { Say("Commande impossible : " + ex.Message); }
        }
        else if (e.Key == Key.Up && _cmdHistory.Count > 0) { _cmdPos = Math.Max(0, _cmdPos - 1); CmdBox.Text = _cmdHistory[_cmdPos]; CmdBox.CaretIndex = CmdBox.Text.Length; e.Handled = true; }
        else if (e.Key == Key.Down && _cmdHistory.Count > 0) { _cmdPos = Math.Min(_cmdHistory.Count, _cmdPos + 1); CmdBox.Text = _cmdPos < _cmdHistory.Count ? _cmdHistory[_cmdPos] : ""; CmdBox.CaretIndex = CmdBox.Text.Length; e.Handled = true; }
    }

    private void RunLevelCommand(string text)
    {
        var t = Tok.Matches(text).Select(m => m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value).ToList();
        if (t.Count == 0) return;
        string cmd = t[0].ToLowerInvariant().Replace("é", "e").Replace("è", "e");
        double N(int i, double def = double.NaN) => i < t.Count ? Nm(t[i], def) : def;
        switch (cmd)
        {
            case "aide": case "help": case "?":
                Say("Commandes : niveau <nom> <cote> | renommer <n°> <nom> | copier <src> <dst> [tout|poteaux|poutres|dalles] | aller <n°> | etages <nombre> <hauteur> | liste | fond [dxf|pdf|image|gerer] | revit | imprimer [note] | exporter pdf|png|ifc|csv|html|metre|plans | sauver.");
                Log("  niveau R+2 9.18     ajoute le niveau « R+2 » à 9,18 m\n  renommer 1 RDC      renomme le niveau n°1\n  copier 1 2 poutres  copie les poutres du niveau 1 vers le niveau 2\n  aller 2             prend le niveau 2 comme plan de travail et zoome\n  etages 5 3.06       crée Base, RDC, R+1... R+4 (remplace les niveaux définis)\n  liste               affiche les niveaux\n  fond                importe un fond de plan (DXF, DWG, PDF ou image) ; « fond pdf », « fond dxf », « fond image » limitent le choix ; « fond gerer » ouvre la gestion\n  imprimer [note]     imprime la vue (ou la note de calcul)\n  exporter <type>     pdf, png, ifc, csv, html, metre, plans\n  sauver              enregistre le projet\n  revit               ouvre le dernier modèle envoyé par Revit");
                break;
            case "liste": case "list": case "ls":
                Say(string.Join("  |  ", LevelInfoNow().Levels.Select(l => $"{l.Index}: {l.Label}")));
                break;
            case "niveau": case "n": case "level": case "ajouter":
            {
                if (t.Count < 3) { Say("Syntaxe : niveau <nom> <cote>   ex. niveau R+2 9.18"); return; }
                double z = N(t.Count - 1);
                if (double.IsNaN(z)) { Say("Cote invalide."); return; }
                DoAddLevel(string.Join(" ", t.Skip(1).Take(t.Count - 2)), z);
                break;
            }
            case "renommer": case "ren": case "rename":
            {
                if (t.Count < 3) { Say("Syntaxe : renommer <n°> <nouveau nom>   ex. renommer 1 RDC"); return; }
                DoRename((int)N(1, -1), string.Join(" ", t.Skip(2)));
                break;
            }
            case "copier": case "cp": case "copy":
            {
                if (t.Count < 3) { Say("Syntaxe : copier <source> <destination> [tout|poteaux|poutres|dalles]"); return; }
                DoCopy((int)N(1, -1), (int)N(2, -1), t.Count > 3 ? t[3].ToLowerInvariant() : "tout");
                break;
            }
            case "aller": case "go":
                GoToLevel((int)N(1, -1), true);
                break;
            case "etages": case "etage": case "floors":
                DoFloors((int)N(1, 0), N(2, 3.06));
                break;
            case "fond": case "fonds": case "importer": case "import": case "underlay":
            {
                string kind = t.Count > 1 ? t[1].ToLowerInvariant() : "";
                if (kind is "gerer" or "liste" or "list") { Underlays_Click(this, new RoutedEventArgs()); break; }
                string? mode = kind switch { "dxf" or "dwg" or "cad" or "autocad" => "cad", "pdf" => "pdf", "image" or "img" or "png" or "jpg" => "img", _ => null };
                _ = ImportUnderlayAsync(mode);
                break;
            }
            case "imprimer": case "print":
                if (t.Count > 1 && t[1].ToLowerInvariant() is "note" or "rapport") PrintReport_Click(this, new RoutedEventArgs());
                else PrintView_Click(this, new RoutedEventArgs());
                break;
            case "exporter": case "export":
            {
                string what = t.Count > 1 ? t[1].ToLowerInvariant() : "";
                switch (what)
                {
                    case "png": case "image": ExportPng_Click(this, new RoutedEventArgs()); break;
                    case "ifc": Ifc_Click(this, new RoutedEventArgs()); break;
                    case "csv": Csv_Click(this, new RoutedEventArgs()); break;
                    case "pdf": ExportPdf_Click(this, new RoutedEventArgs()); break;
                    case "html": case "note": Html_Click(this, new RoutedEventArgs()); break;
                    case "metre": case "métré": case "quantites": ExportQty_Click(this, new RoutedEventArgs()); break;
                    case "plans": Plans_Click(this, new RoutedEventArgs()); break;
                    default: Say("Syntaxe : exporter pdf | png | ifc | csv | html | metre | plans"); break;
                }
                break;
            }
            case "combinaisons": case "combos":
                Combos_Click(this, new RoutedEventArgs());
                break;
            case "variantes": case "variante":
                Variants_Click(this, new RoutedEventArgs());
                break;
            case "voilemaille": case "coquevoile":
                ShellWall_Click(this, new RoutedEventArgs());
                break;
            case "dallemaillee": case "coquedalle":
                ShellSlab_Click(this, new RoutedEventArgs());
                break;
            case "spectre": case "spectral":
                Spectral_Click(this, new RoutedEventArgs());
                break;
            case "modal": case "modale":
                Modal_Click(this, new RoutedEventArgs());
                break;
            case "palette": case "chercher": case "rechercher":
                Palette_Click(this, new RoutedEventArgs());
                break;
            case "modeles": case "modele": case "template":
                Templates_Click(this, new RoutedEventArgs());
                break;
            case "versions": case "historique":
                Versions_Click(this, new RoutedEventArgs());
                break;
            case "options": case "option": case "raccourcis":
                Options_Click(new FrameworkElement { Tag = cmd == "raccourcis" ? "2" : "0" }, new RoutedEventArgs());
                break;
            case "projet": case "proprietes":
                ProjectInfo_Click(this, new RoutedEventArgs());
                break;
            case "sauver": case "enregistrer": case "save":
                Save_Click(this, new RoutedEventArgs());
                break;
            case "revit":
                OpenRevitModel_Click(this, new RoutedEventArgs());
                break;
            default:
                Say($"Commande « {t[0]} » inconnue. Tapez « aide ».");
                break;
        }
    }
}
