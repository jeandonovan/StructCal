using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Comparaison de variantes (béton, acier, sections) : quantités, coût et conformité de chaque combinaison.</summary>
public sealed class VariantsWindow : Window
{
    private readonly StructModel _model;
    private readonly TextBox _fc = new() { Width = 130 }, _fe = new() { Width = 130 }, _k = new() { Width = 130 };
    private readonly CheckBox _opt = new() { Content = "Dimensionner automatiquement les sections de chaque variante", IsChecked = true, Margin = new Thickness(0, 6, 0, 0) };
    private readonly ListView _list = new() { Margin = new Thickness(8) };
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 8, 4), Foreground = System.Windows.Media.Brushes.Gray };
    private readonly Button _run = new() { Content = "Comparer", Padding = new Thickness(16, 4, 16, 4), Margin = new Thickness(8, 0, 0, 0), IsDefault = true };
    private readonly Button _apply = new() { Content = "Appliquer la variante choisie au projet", Padding = new Thickness(12, 4, 12, 4), Margin = new Thickness(8), IsEnabled = false };
    public VariantResult? Chosen { get; private set; }

    public sealed class Row
    {
        public VariantResult V { get; init; } = null!;
        public string Name => V.Name;
        public string State => V.Error != "" ? "erreur" : V.Ok ? "OK" : $"{V.Failing} barre(s) NON OK";
        public string Concrete => V.ConcreteM3.ToString("0.0", CultureInfo.CurrentCulture);
        public string Steel => V.SteelKg.ToString("0", CultureInfo.CurrentCulture);
        public string Ratio => V.ConcreteM3 > 0 ? (V.SteelKg / V.ConcreteM3).ToString("0", CultureInfo.CurrentCulture) : "-";
        public string Form => V.FormworkM2.ToString("0", CultureInfo.CurrentCulture);
        public string Cost => V.Error != "" ? V.Error : V.Cost.ToString("N0", CultureInfo.CurrentCulture) + " " + V.Currency;
    }

    public VariantsWindow(Window owner, StructModel m)
    {
        Owner = owner; _model = m;
        Title = "Comparer des variantes - " + AppInfo.Name;
        Width = 900; Height = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        _fc.Text = FormatList(new[] { m.Fc28, m.Fc28 + 5 });
        _fe.Text = FormatList(new[] { m.Fe });
        _k.Text = "1; 0,9";

        var p = new WrapPanel { Margin = new Thickness(8, 8, 8, 0) };
        p.Children.Add(new TextBlock { Text = "fc28 (MPa) :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) }); p.Children.Add(_fc);
        p.Children.Add(new TextBlock { Text = "   fe (MPa) :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) }); p.Children.Add(_fe);
        p.Children.Add(new TextBlock { Text = "   Sections de départ x :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) }); p.Children.Add(_k);
        p.Children.Add(_run);
        var top = new StackPanel();
        top.Children.Add(p);
        top.Children.Add(new StackPanel { Margin = new Thickness(8, 0, 8, 0), Children = { _opt } });
        top.Children.Add(new TextBlock { Text = "Séparez plusieurs valeurs par « ; » (ex. 25; 30; 35). 12 variantes au maximum. Le projet n'est pas modifié tant que vous n'appliquez pas une variante.", Foreground = System.Windows.Media.Brushes.Gray, Margin = new Thickness(8, 4, 8, 4), TextWrapping = TextWrapping.Wrap });

        var gv = new GridView();
        void Col(string h, string b, double w) => gv.Columns.Add(new GridViewColumn { Header = h, Width = w, DisplayMemberBinding = new System.Windows.Data.Binding(b) });
        Col("Variante", nameof(Row.Name), 290); Col("Conformité", nameof(Row.State), 120); Col("Béton (m³)", nameof(Row.Concrete), 80);
        Col("Acier (kg)", nameof(Row.Steel), 80); Col("kg/m³", nameof(Row.Ratio), 55); Col("Coffrage (m²)", nameof(Row.Form), 90); Col("Coût estimé", nameof(Row.Cost), 140);
        _list.View = gv;
        _list.SelectionChanged += (s, e) => _apply.IsEnabled = _list.SelectedItem is Row r && r.V.Error == "";

        _run.Click += async (s, e) => await RunAsync();
        _apply.Click += (s, e) => { if (_list.SelectedItem is Row r) { Chosen = r.V; DialogResult = true; } };
        var close = new Button { Content = "Fermer", IsCancel = true, Padding = new Thickness(12, 4, 12, 4), Margin = new Thickness(0, 8, 8, 8) };
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        bar.Children.Add(_apply); bar.Children.Add(close);

        var root = new DockPanel();
        DockPanel.SetDock(top, Dock.Top); DockPanel.SetDock(bar, Dock.Bottom); DockPanel.SetDock(_status, Dock.Bottom);
        root.Children.Add(top); root.Children.Add(bar); root.Children.Add(_status); root.Children.Add(_list);
        Content = root;
    }

    private static string FormatList(IEnumerable<double> v) => string.Join("; ", v.Select(x => x.ToString("0.##", CultureInfo.CurrentCulture)));

    private static List<double> Parse(string t)
    {
        var res = new List<double>();
        foreach (var part in t.Split(new[] { ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            if (double.TryParse(part.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var d) && d > 0) res.Add(d);
        return res;
    }

    private async Task RunAsync()
    {
        var fcs = Parse(_fc.Text); var fes = Parse(_fe.Text); var ks = Parse(_k.Text);
        if (fcs.Count == 0 || fes.Count == 0 || ks.Count == 0) { MessageBox.Show("Entrez au moins une valeur par champ.", Title); return; }
        if (fcs.Count * fes.Count * ks.Count > 12) { MessageBox.Show("12 variantes au maximum : réduisez le nombre de valeurs.", Title); return; }
        _run.IsEnabled = false; _list.ItemsSource = null;
        _status.Text = "Calcul des variantes en cours...";
        bool opt = _opt.IsChecked == true;
        var dispatcher = Dispatcher;
        try
        {
            var res = await Task.Run(() => VariantComparer.Run(_model, fcs, fes, ks, opt, n => dispatcher.BeginInvoke(new Action(() => _status.Text = "Calcul : " + n))));
            _list.ItemsSource = res.Select(v => new Row { V = v }).ToList();
            var best = res.Where(r => r.Ok && r.Error == "").OrderBy(r => r.Cost > 0 ? r.Cost : r.SteelKg).FirstOrDefault();
            _status.Text = best != null ? $"Variante conforme la moins chère : {best.Name}." : "Aucune variante entièrement conforme : élargissez les valeurs (béton plus résistant, sections plus grandes).";
        }
        catch (Exception ex) { _status.Text = "Erreur : " + ex.Message; }
        finally { _run.IsEnabled = true; }
    }
}
