using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Impression, exports d'image et de métré, fichiers récents, sauvegarde automatique et récupération après plantage.</summary>
public partial class MainWindow
{
    private static string DataDir
    {
        get
        {
            string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppInfo.Name);
            Directory.CreateDirectory(d);
            return d;
        }
    }
    private static string RecentFile => Path.Combine(DataDir, "recent.txt");
    private static string RecoveryFile => Path.Combine(DataDir, "recovery" + AppInfo.FileExt);
    private DispatcherTimer? _autoSave;

    // ---------------------------------------------------------------- image de la vue
    private BitmapSource? RenderView(double scale = 2.0)
    {
        var el = _vp.Surface as FrameworkElement;
        if (el == null || el.ActualWidth < 10 || el.ActualHeight < 10) return null;
        int w = (int)(el.ActualWidth * scale), h = (int)(el.ActualHeight * scale);
        var rtb = new RenderTargetBitmap(w, h, 96 * scale, 96 * scale, PixelFormats.Pbgra32);
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen()) dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, el.ActualWidth, el.ActualHeight));
        rtb.Render(dv);
        rtb.Render(el);
        rtb.Freeze();
        return rtb;
    }

    private void ExportPng_Click(object sender, RoutedEventArgs e)
    {
        var bmp = RenderView(2.0);
        if (bmp == null) { MessageBox.Show("La vue n'est pas affichée.", AppInfo.Name, MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var dlg = new SaveFileDialog { Filter = "Image PNG (*.png)|*.png", FileName = _model.Name + "_vue.png" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var enc = new PngBitmapEncoder();
            enc.Frames.Add(BitmapFrame.Create(bmp));
            using var fs = File.Create(dlg.FileName);
            enc.Save(fs);
            Say("Image de la vue enregistrée : " + dlg.FileName);
        }
        catch (Exception ex) { Say("Erreur d'export de l'image : " + ex.Message); }
    }

    private void PrintView_Click(object sender, RoutedEventArgs e)
    {
        var bmp = RenderView(2.0);
        if (bmp == null) { MessageBox.Show("La vue n'est pas affichée.", AppInfo.Name, MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var pd = new PrintDialog();
        try { pd.PrintTicket.PageOrientation = System.Printing.PageOrientation.Landscape; } catch { }
        if (pd.ShowDialog() != true) return;
        double pw = pd.PrintableAreaWidth, ph = pd.PrintableAreaHeight, m = 30, head = 36;
        double iw = pw - 2 * m, ih = ph - 2 * m - head;
        double f = Math.Min(iw / bmp.PixelWidth, ih / bmp.PixelHeight);
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen())
        {
            var tf = new Typeface("Segoe UI");
            dc.DrawText(new FormattedText($"{AppInfo.Name} - {_model.Name}   ({DateTime.Now:dd/MM/yyyy})", System.Globalization.CultureInfo.CurrentCulture,
                FlowDirection.LeftToRight, tf, 14, Brushes.Black, 1.0), new Point(m, m - 4));
            dc.DrawImage(bmp, new Rect(m, m + head, bmp.PixelWidth * f, bmp.PixelHeight * f));
            dc.DrawRectangle(null, new Pen(Brushes.Gray, 0.8), new Rect(m, m + head, bmp.PixelWidth * f, bmp.PixelHeight * f));
        }
        pd.PrintVisual(dv, $"{AppInfo.Name} - {_model.Name}");
        Say("Vue envoyée à l'imprimante.");
    }

    /// <summary>Note de calcul : ouverte dans le navigateur (Ctrl+P pour imprimer ou « Enregistrer en PDF »).</summary>
    private void PrintReport_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        try
        {
            string tmp = Path.Combine(Path.GetTempPath(), AppInfo.Name + "_note_de_calcul.html");
            File.WriteAllText(tmp, ReportWriter.ToHtml(_model, _out!));
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(tmp) { UseShellExecute = true });
            Say("Note de calcul ouverte dans le navigateur : Ctrl+P pour imprimer ou choisir « Enregistrer au format PDF ».");
        }
        catch (Exception ex) { Say("Impression impossible : " + ex.Message); }
    }

    // ---------------------------------------------------------------- PDF
    private static byte[]? LoadLogoJpeg()
    {
        try
        {
            string path = AppOptions.Current.LogoPath;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return null;
            var img = new BitmapImage();
            img.BeginInit(); img.UriSource = new Uri(path); img.CacheOption = BitmapCacheOption.OnLoad; img.EndInit();
            double k = Math.Min(1.0, 600.0 / Math.Max(img.PixelWidth, img.PixelHeight));
            int w = Math.Max(1, (int)(img.PixelWidth * k)), h = Math.Max(1, (int)(img.PixelHeight * k));
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, w, h));     // fond blanc : le JPEG n'a pas de transparence
                dc.DrawImage(img, new Rect(0, 0, w, h));
            }
            var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            var enc = new JpegBitmapEncoder { QualityLevel = 90 };
            enc.Frames.Add(BitmapFrame.Create(rtb));
            using var ms = new MemoryStream();
            enc.Save(ms);
            return ms.ToArray();
        }
        catch { return null; }
    }

    private void ExportPdf_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        var dlg = new SaveFileDialog { Filter = "Document PDF (*.pdf)|*.pdf", FileName = "Note_de_calcul_" + _model.Name + ".pdf" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var pdf = PdfReport.Build(_model, _out!, LoadLogoJpeg(), AppOptions.Current.CompanyName);
            File.WriteAllBytes(dlg.FileName, pdf);
            Say("Note de calcul PDF : " + dlg.FileName);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
        }
        catch (Exception ex) { Say("Export PDF impossible : " + ex.Message); }
    }

    // ---------------------------------------------------------------- métré
    private void ExportQty_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        var dlg = new SaveFileDialog { Filter = "Texte (*.txt)|*.txt", FileName = _model.Name + "_metre.txt" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var q = Quantities.Compute(_model, _out!);
            string cost;
            try { cost = CostEstimator.Compute(q, _model.Prices).ToText(); } catch (Exception ex) { cost = "Estimation du coût impossible : " + ex.Message; }
            File.WriteAllText(dlg.FileName, $"{AppInfo.Name} - {_model.Name} - {DateTime.Now:dd/MM/yyyy}\r\n\r\n{q.ToText()}\r\n\r\n{cost}\r\n", new System.Text.UTF8Encoding(true));
            Say("Métré enregistré : " + dlg.FileName);
        }
        catch (Exception ex) { Say("Erreur d'export du métré : " + ex.Message); }
    }

    // ---------------------------------------------------------------- fichiers récents
    private List<string> LoadRecent() => _recents.Load().Select(e => e.Path).Take(10).ToList();

    private void AddRecent(string path)
    {
        try { _recents.Add(path, _model); } catch { }
        RefreshRecentMenu();
    }

    private void RefreshRecentMenu()
    {
        if (RecentMenu == null) return;
        RecentMenu.Items.Clear();
        var l = LoadRecent();
        if (l.Count == 0) { RecentMenu.Items.Add(new MenuItem { Header = "(aucun)", IsEnabled = false }); return; }
        foreach (var p in l)
        {
            string path = p;
            var mi = new MenuItem { Header = Path.GetFileName(path), ToolTip = path };
            mi.Click += (s, a) => { PushUndo(); OpenModelFile(path); };
            RecentMenu.Items.Add(mi);
        }
    }

    // ---------------------------------------------------------------- sauvegarde automatique
    private void StartAutoSave()
    {
        RefreshRecentMenu();
        _autoSave = new DispatcherTimer { Interval = TimeSpan.FromMinutes(Math.Max(1, AppOptions.Current.AutoSaveMinutes)) };
        _autoSave.Tick += (s, a) =>
        {
            try { if (_model.Members.Count > 0) ModelIO.Save(_model, RecoveryFile); } catch { }
        };
        if (AppOptions.Current.AutoSaveMinutes > 0) _autoSave.Start();
    }

    /// <summary>Si la session précédente s'est mal terminée (fichier de récupération présent), propose de la restaurer.</summary>
    private void OfferRecovery()
    {
        try
        {
            if (!File.Exists(RecoveryFile)) return;
            var when = File.GetLastWriteTime(RecoveryFile);
            if (MessageBox.Show($"StructCalc ne s'est pas fermé normalement la dernière fois.\nUne sauvegarde automatique du {when:dd/MM/yyyy à HH:mm} existe.\n\nLa restaurer ?",
                    "Récupération", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                if (OpenModelFile(RecoveryFile)) Say("Sauvegarde automatique restaurée : pensez à l'enregistrer (Ctrl+S).");
            }
            else File.Delete(RecoveryFile);
        }
        catch { }
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        if (!ConfirmClose()) { e.Cancel = true; return; }
        base.OnClosing(e);
        if (e.Cancel) return;
        try { _autoSave?.Stop(); if (File.Exists(RecoveryFile)) File.Delete(RecoveryFile); } catch { }
    }
}
