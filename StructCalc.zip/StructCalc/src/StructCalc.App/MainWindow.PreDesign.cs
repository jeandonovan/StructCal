using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Prédimensionnement depuis les menus clic droit : poutres (continues), poteaux (superposés), dalles, semelles, escaliers.</summary>
public partial class MainWindow
{
    private bool ConfirmPre(string title, string text, string question)
    {
        var lines = text.Split('\n');
        if (lines.Length > 26) text = string.Join("\n", lines.Take(25)) + $"\n... ({lines.Length - 25} ligne(s) de plus)";
        return MessageBox.Show(this, text + "\n\n" + question, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    }

    /// <summary>Prédimensionne les barres désignées (chaînes : poutres continues, poteaux superposés regroupés).</summary>
    private void PreDesignMembers(List<int> ids, bool chains)
    {
        if (ids.Count == 0) return;
        CommitGrids();
        var rep = PreDesign.Members(_model, ids, _out, chains);
        if (rep.Items.Count == 0) { Say(rep.Text); MessageBox.Show(this, rep.Text, "Prédimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (!rep.AnyChange) { Say("Prédimensionnement : les sections actuelles conviennent déjà."); MessageBox.Show(this, rep.Text + "\n\nLes sections actuelles sont déjà suffisantes : rien à modifier.", "Prédimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (!ConfirmPre("Prédimensionnement", rep.Text, $"Appliquer ces sections à {rep.Items.Count(i => i.Changes)} barre(s) ? (annulable par Ctrl+Z)")) return;
        PushUndo();
        foreach (var it in rep.Items.Where(i => i.Changes))
        {
            var mem = _model.Members.FirstOrDefault(x => x.Id == it.MemberId);
            if (mem == null) continue;
            mem.B = it.NewB; mem.H = it.NewH;
        }
        OnModelEdited();
        Say($"Prédimensionnement appliqué à {rep.Items.Count(i => i.Changes)} barre(s). Relancez le calcul (F5) pour vérifier.");
    }

    private void PreDesignSlab(SlabPanel s)
    {
        var r = PreDesign.Slab(_model, s);
        double h = r.V["H"];
        if (!ConfirmPre("Prédimensionnement", r.Text, $"Passer la dalle {s.Name} à {h * 100:0} cm ? (annulable par Ctrl+Z)")) return;
        CommitGrids(); PushUndo();
        s.H = h;
        if (r.V.TryGetValue("HourdisCm", out double hd)) { s.HourdisCm = hd; s.ToppingCm = r.V["ToppingCm"]; }
        OnModelEdited();
        Say($"Dalle {s.Name} : épaisseur {h * 100:0} cm. Relancez le calcul (F5).");
    }

    private void PreDesignStair(StairDef d)
    {
        var r = PreDesign.Stair(d);
        if (!ConfirmPre("Prédimensionnement", r.Text, $"Appliquer à l'escalier {d.Name} (contremarche, giron, paillasse, emmarchement) ? (annulable par Ctrl+Z)")) return;
        CommitGrids(); PushUndo();
        d.TargetRiserCm = r.V["RiserCm"]; d.TargetTreadCm = r.V["TreadCm"];
        d.SlabThicknessCm = r.V["SlabCm"]; d.WidthM = r.V["WidthM"];
        OnModelEdited();
        Say($"Escalier {d.Name} prédimensionné ({(int)r.V["Steps"]} marches, paillasse {r.V["SlabCm"]:0} cm).");
    }

    private void PreDesignFooting(int nodeId)
    {
        var r = PreDesign.Footing(_model, nodeId, _out);
        if (r.V.GetValueOrDefault("Valid") < 0.5)
        {
            Say(r.Text);
            MessageBox.Show(this, r.Text, "Prédimensionnement", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (!ConfirmPre("Prédimensionnement", r.Text, "Ouvrir l'assistant Sol et semelles avec ces dimensions ?")) return;
        var seed = BuildFootingSeed(nodeId, out string note);
        seed.FixedA = r.V["A"]; seed.FixedB = r.V["B"];
        _soilWin?.Close();
        _soilWin = new SoilFootingWizardWindow(() => _model, ApplyLoadEdit, seed) { Owner = this };
        _soilWin.Closed += (s, a) => _soilWin = null;
        _soilWin.Show();
        Say($"Semelle S{nodeId} : {r.V["A"]:0.00} x {r.V["B"]:0.00} m proposées dans l'assistant (à enregistrer pour les garder).");
    }

    /// <summary>Entrées « Prédimensionner » du menu d'une barre (clic droit).</summary>
    private void AddMemberPreDesignItems(ContextMenu cm, Member mem)
    {
        var sel = Sel();
        if (!sel.Contains(mem.Id)) sel = new List<int> { mem.Id };
        string kind = mem.Type == MemberType.Column ? "poteau" : "poutre";
        cm.Items.Add(new Separator());
        if (sel.Count > 1)
            cm.Items.Add(Mi($"Prédimensionner la sélection ({sel.Count} barres, poutres continues et poteaux superposés regroupés)...", () => PreDesignMembers(sel, true)));
        else
        {
            var group = mem.Type == MemberType.Column ? PreDesign.ColumnStack(_model, mem.Id) : PreDesign.BeamChain(_model, mem.Id);
            if (group.Count > 1)
            {
                string txt = mem.Type == MemberType.Column ? $"Prédimensionner les {group.Count} poteaux superposés (même file)..." : $"Prédimensionner la poutre continue ({group.Count} travées)...";
                cm.Items.Add(Mi(txt, () => PreDesignMembers(new List<int> { mem.Id }, true)));
                cm.Items.Add(Mi($"Prédimensionner ce {kind} seul...", () => PreDesignMembers(new List<int> { mem.Id }, false)));
            }
            else cm.Items.Add(Mi($"Prédimensionner ce {kind}...", () => PreDesignMembers(new List<int> { mem.Id }, false)));
        }
    }

    private void FillShellMenu(ContextMenu cm, ShellPanel sh)
    {
        cm.Items.Clear();
        int n = _model.Shells.Count(x => x.Name == sh.Name);
        cm.Items.Add(MenuTitle($"{sh.Kind} {sh.Name}   e = {sh.T * 100:0.#} cm   ({n} maille(s))"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi($"Prédimensionner l'épaisseur ({sh.Kind.ToLowerInvariant()} {sh.Name})...", () => PreDesignShell(sh.Name)));
        AddVisibilityItems(cm, null, sh);
    }

    private void PreDesignShell(string name)
    {
        var r = PreDesign.Shell(_model, name);
        if (r.V.GetValueOrDefault("Valid") < 0.5) { Say(r.Text); return; }
        double t = r.V["T"];
        if (!ConfirmPre("Prédimensionnement", r.Text, $"Passer {name} à {t * 100:0.#} cm sur toutes ses mailles ? (annulable par Ctrl+Z)")) return;
        CommitGrids(); PushUndo();
        foreach (var x in _model.Shells.Where(q => q.Name == name)) x.T = t;
        OnModelEdited();
        Say($"{name} : épaisseur {t * 100:0.#} cm. Relancez le calcul (F5).");
    }
}
