using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace StructCalc.UI;

/// <summary>Fenêtre « Attributs d'affichage » (façon Robot Structural Analysis) : cases à cocher par famille d'objets, effet immédiat dans la vue.</summary>
public sealed class AttributesWindow : Window
{
    private readonly List<(CheckBox Box, Func<bool> Get)> _boxes = new();
    private readonly ModelViewport _vp;
    private readonly Action _sync;

    public AttributesWindow(ModelViewport vp, Action syncToolbar)
    {
        _vp = vp; _sync = syncToolbar;
        Title = "Attributs d'affichage";
        Width = 470; Height = 720; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var a = vp.Attr;
        var root = new DockPanel { Margin = new Thickness(10) };

        var bottom = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        bottom.Children.Add(Ui.Btn("Tout afficher", (s, e) => SetAll(true)));
        bottom.Children.Add(Ui.Btn("Tout masquer", (s, e) => SetAll(false)));
        bottom.Children.Add(Ui.Btn("Par défaut", (s, e) => Preset(Default)));
        bottom.Children.Add(Ui.Btn("Fermer", (s, e) => Close(), true));
        DockPanel.SetDock(bottom, Dock.Bottom); root.Children.Add(bottom);

        var presets = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
        presets.Children.Add(new TextBlock { Text = "Préréglages :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0), FontWeight = FontWeights.SemiBold });
        presets.Children.Add(Ui.Btn("Géométrie", (s, e) => Preset(GeometryOnly)));
        presets.Children.Add(Ui.Btn("Charges", (s, e) => Preset(LoadsOnly)));
        presets.Children.Add(Ui.Btn("Dalles et ferraillage", (s, e) => Preset(SlabsRebar)));
        DockPanel.SetDock(presets, Dock.Top); root.Children.Add(presets);

        var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var st = new StackPanel();
        void Group(string title, params (string Text, Func<bool> Get, Action<bool> Set, string Tip)[] items)
        {
            var gb = new GroupBox { Header = title, Margin = new Thickness(0, 0, 0, 8), Padding = new Thickness(6) };
            var p = new StackPanel();
            foreach (var (text, get, set, tip) in items)
            {
                var cb = new CheckBox { Content = text, IsChecked = get(), Margin = new Thickness(0, 2, 0, 2), ToolTip = tip };
                var setter = set;
                cb.Click += (s, e) => { setter(cb.IsChecked == true); Apply(); };
                p.Children.Add(cb); _boxes.Add((cb, get));
            }
            gb.Content = p; st.Children.Add(gb);
        }

        Group("Nœuds",
            ("Points des nœuds", () => a.NodeSymbols, v => a.NodeSymbols = v, "Petit disque à chaque nœud"),
            ("Numéros des nœuds", () => a.NodeNumbers, v => a.NodeNumbers = v, "Numéro à côté du nœud (nécessite « Étiquettes » dans la barre d'outils)"),
            ("Symboles d'appuis", () => a.Supports, v => a.Supports = v, "Triangles d'appui et encastrements"));
        Group("Barres",
            ("Étiquettes : numéro et section", () => a.MemberLabels, v => a.MemberLabels = v, "P12 30x40 / B5 IPE300"),
            ("Sens des barres (nœud i → nœud j)", () => a.MemberDirection, v => a.MemberDirection = v, "Flèche au milieu de chaque barre"),
            ("Axes locaux x, y, z", () => a.LocalAxes, v => a.LocalAxes = v, "Triède local au milieu de chaque barre : x rouge (axe), y vert, z bleu"));
        Group("Dalles",
            ("Contour et remplissage des dalles", () => a.Slabs, v => a.Slabs = v, "Affiche ou masque toutes les dalles dessinées"),
            ("Nom et épaisseur (D1  h = 16 cm)", () => a.SlabNames, v => a.SlabNames = v, ""),
            ("Épaisseur visible en 3D (rives et sous-face)", () => a.SlabThickness, v => a.SlabThickness = v, "Dalle dessinée comme un volume en vue 3D, élévation et côté"),
            ("Symbole du sens de portée", () => a.SlabSpanSymbol, v => a.SlabSpanSymbol = v, "Flèches doubles : deux sens (croix), sens X ou sens Y selon le mode de calcul de la dalle"),
            ("Symbole du ferraillage (nappes inf. et sup.)", () => a.SlabRebarSymbol, v => a.SlabRebarSymbol = v, "Barres principales (trait plein bleu et vert), répartition (pointillés), chapeaux sur appuis (rouge)"));
        Group("Charges",
            ("Charges réparties, ponctuelles et moments sur barres", () => a.MemberLoads, v => a.MemberLoads = v, ""),
            ("Charges surfaciques (dalles)", () => a.SurfaceLoads, v => a.SurfaceLoads = v, ""),
            ("Charges nodales", () => a.NodalLoads, v => a.NodalLoads = v, ""),
            ("Valeurs et cas à côté des charges", () => a.LoadValues, v => a.LoadValues = v, "Masquer les textes laisse les flèches (toujours sélectionnables)"),
            ("Toutes les charges (interrupteur général)", () => vp.ShowLoads, v => vp.ShowLoads = v, "Même case que « Charges » de la barre d'outils"));
        Group("Cotes",
            ("Afficher les cotes", () => vp.Dims.Show, v => vp.Dims.Show = v, ""),
            ("Cotes automatiques (entraxes, hauteurs, hors-tout)", () => vp.Dims.ShowAuto, v => vp.Dims.ShowAuto = v, ""),
            ("Cotes manuelles", () => vp.Dims.ShowManual, v => vp.Dims.ShowManual = v, "Cotes posées avec l'outil Cote (sélectionnables et supprimables)"));
        Group("Fondations",
            ("Semelles dimensionnées sous les poteaux (après calcul)", () => vp.ShowFootings, v => vp.ShowFootings = v, "Cliquables : clic droit pour ouvrir l'assistant Sol et semelles"));
        Group("Escaliers",
            ("Escaliers posés dans le modèle", () => a.Stairs, v => a.Stairs = v, "Assistants > Escaliers > Placer dans le modèle"),
            ("Nom des escaliers", () => a.StairNames, v => a.StairNames = v, ""));
        Group("Repères de la scène",
            ("Axes de la grille", () => vp.ShowGrid, v => vp.ShowGrid = v, ""),
            ("Niveaux (étages)", () => vp.ShowLevels, v => vp.ShowLevels = v, ""),
            ("Étiquettes (interrupteur général des numéros et sections)", () => vp.ShowLabels, v => vp.ShowLabels = v, ""));
        sv.Content = st; root.Children.Add(sv);
        Content = root;
    }

    private void Refresh() { foreach (var (box, get) in _boxes) box.IsChecked = get(); }

    private void Apply()
    {
        _vp.Attr.Save();
        _sync();
        _vp.Redraw();
    }

    private void SetAll(bool on)
    {
        _vp.Attr.SetAll(on);
        _vp.ShowLoads = on; _vp.Dims.Show = on; _vp.Dims.ShowAuto = on; _vp.Dims.ShowManual = on;
        Refresh(); Apply();
    }

    private void Preset(Action<ModelViewport> p) { p(_vp); Refresh(); Apply(); }

    private static void Default(ModelViewport v)
    {
        var d = new ViewAttributes();
        v.Attr.SetAll(true); v.Attr.MemberDirection = d.MemberDirection; v.Attr.LocalAxes = d.LocalAxes; v.Attr.SlabSpanSymbol = d.SlabSpanSymbol; v.Attr.SlabRebarSymbol = d.SlabRebarSymbol;
        v.ShowLoads = true; v.Dims.Show = true; v.Dims.ShowAuto = true; v.Dims.ShowManual = true; v.ShowGrid = true; v.ShowLevels = true; v.ShowLabels = true;
    }

    private static void GeometryOnly(ModelViewport v)
    {
        Default(v);
        v.Attr.MemberLoads = v.Attr.SurfaceLoads = v.Attr.NodalLoads = false; v.ShowLoads = false;
        v.Attr.MemberLabels = true; v.Attr.NodeNumbers = true;
    }

    private static void LoadsOnly(ModelViewport v)
    {
        Default(v);
        v.ShowLoads = true; v.Attr.MemberLabels = false; v.Attr.NodeNumbers = false; v.Attr.SlabNames = false; v.Dims.Show = false;
    }

    private static void SlabsRebar(ModelViewport v)
    {
        Default(v);
        v.Attr.SlabSpanSymbol = true; v.Attr.SlabRebarSymbol = true; v.Attr.MemberLabels = false; v.Attr.NodeNumbers = false;
        v.Attr.MemberLoads = false; v.Attr.NodalLoads = false; v.Attr.SurfaceLoads = false; v.ShowLoads = false;
    }
}
