using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Loads;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Application directe d'une charge de la bibliothèque sur l'élément choisi : poutre, poteau (barres), dalle ou nœud, avec conversion d'unité automatique.</summary>
public partial class MainWindow
{
    /// <summary>Choisit une charge dans la bibliothèque puis l'applique à la sélection : cible = "members", "slab" ou "nodes" (null = au choix).</summary>
    private void ApplyCatalog(int tab, string? only)
    {
        var memIds = _vp.Selection.ToList();
        if (memIds.Count == 0 && _vp.SelectedId >= 0) memIds.Add(_vp.SelectedId);
        var members = _model.Members.Where(m => memIds.Contains(m.Id)).ToList();
        var slab = _vp.SelectedSlab;
        var nodes = _vp.SelectedNodes.ToList();

        var targets = new List<(string Key, string Label)>();
        if (members.Count > 0 && (only == null || only == "members"))
        {
            int nc = members.Count(m => m.Type == MemberType.Column);
            targets.Add(("members", $"{members.Count} barre(s) sélectionnée(s) : {members.Count - nc} poutre(s), {nc} poteau(x)"));
        }
        if (slab != null && (only == null || only == "slab")) targets.Add(("slab", $"Dalle {slab.Name}"));
        if (nodes.Count > 0 && (only == null || only == "nodes")) targets.Add(("nodes", $"{nodes.Count} nœud(s) sélectionné(s)"));
        if (targets.Count == 0)
        {
            MessageBox.Show(this, "Sélectionnez d'abord l'élément porteur à charger (poutre, poteau, dalle ou nœud) dans la vue, puis relancez.", "Appliquer une charge");
            return;
        }

        var pick = LoadCatalogWindow.Pick(this, tab);
        if (pick == null) return;

        string unit = pick.Kind == "Linear" ? "kN/m" : pick.Kind == "Surface" ? "kN/m²" : "kN";
        var w = new Window
        {
            Title = "Appliquer la charge", Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, SizeToContent = SizeToContent.WidthAndHeight,
            ResizeMode = ResizeMode.NoResize, MinWidth = 440
        };
        var p = new StackPanel { Margin = new Thickness(16) };
        p.Children.Add(new TextBlock { Text = $"{pick.Text}\n= {pick.Value:0.###} {unit}", FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });
        p.Children.Add(new TextBlock { Text = "Appliquer sur :" });
        var cTarget = new ComboBox { Margin = new Thickness(0, 2, 0, 8) };
        foreach (var t in targets) cTarget.Items.Add(t.Label);
        cTarget.SelectedIndex = 0; p.Children.Add(cTarget);
        p.Children.Add(new TextBlock { Text = "Cas de charge :" });
        var cCase = new ComboBox { Margin = new Thickness(0, 2, 0, 8) };
        cCase.Items.Add("G - permanente"); cCase.Items.Add("Q - exploitation");
        cCase.SelectedIndex = pick.Live ? 1 : 0; p.Children.Add(cCase);
        var lblInf = new TextBlock(); p.Children.Add(lblInf);
        var tInf = new TextBox { Text = "1", Margin = new Thickness(0, 2, 0, 4) }; p.Children.Add(tInf);
        var note = new TextBlock { TextWrapping = TextWrapping.Wrap, Foreground = System.Windows.Media.Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 0, 0, 8) };
        p.Children.Add(note);
        var chkAdd = new CheckBox { Content = "Ajouter à la valeur déjà saisie (dalle)", IsChecked = true, Margin = new Thickness(0, 0, 0, 8) };
        p.Children.Add(chkAdd);

        void Refresh()
        {
            string key = targets[Math.Max(0, cTarget.SelectedIndex)].Key;
            chkAdd.Visibility = key == "slab" ? Visibility.Visible : Visibility.Collapsed;
            string k = pick.Kind;
            tInf.IsEnabled = true; tInf.Visibility = Visibility.Visible; lblInf.Visibility = Visibility.Visible;
            if (key == "members")
            {
                if (k == "Linear") { tInf.Visibility = lblInf.Visibility = Visibility.Collapsed; note.Text = "Charge linéaire uniforme sur toute la barre (poutre : mur, cloison, garde-corps ; poteau : charge répartie sur la hauteur)."; }
                else if (k == "Surface") { lblInf.Text = "Largeur d'influence portée par la barre (m) :"; note.Text = "kN/m² × largeur = kN/m sur la barre (revêtement, plancher, toiture)."; }
                else { tInf.Visibility = lblInf.Visibility = Visibility.Collapsed; note.Text = "Force concentrée : à mi-portée d'une poutre ; en tête d'un poteau."; }
            }
            else if (key == "slab")
            {
                if (k == "Surface") { tInf.Visibility = lblInf.Visibility = Visibility.Collapsed; note.Text = "Charge surfacique : G supplémentaire (revêtement, chape, cloisons) ou Q (exploitation) de la dalle."; }
                else if (k == "Linear") { tInf.Visibility = lblInf.Visibility = Visibility.Collapsed; note.Text = "Mur sur dalle : cloison légère (<= 3 kN/m) = surcharge équivalente forfaitaire ; au-delà, chargez la poutre ou la bande sous le mur."; }
                else { lblInf.Text = "Aire sur laquelle répartir la force (m²) :"; tInf.Text = (slab!.Lx * slab.Ly).ToString("0.##", CultureInfo.InvariantCulture); note.Text = "Force répartie sur l'aire indiquée (par défaut toute la dalle)."; }
            }
            else
            {
                if (k == "Point") { tInf.Visibility = lblInf.Visibility = Visibility.Collapsed; note.Text = "Force verticale au nœud."; }
                else if (k == "Linear") { lblInf.Text = "Longueur d'influence (m) :"; note.Text = "kN/m × longueur = kN au nœud."; }
                else { lblInf.Text = "Aire d'influence (m²) :"; note.Text = "kN/m² × aire = kN au nœud (ex. charge de plancher reprise par le poteau)."; }
            }
        }
        cTarget.SelectionChanged += (s, a) => Refresh();
        Refresh();

        var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var ok = new Button { Content = "Appliquer", Width = 100, Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        var cancel = new Button { Content = "Annuler", Width = 90, IsCancel = true };
        ok.Click += (s, a) => w.DialogResult = true;
        row.Children.Add(ok); row.Children.Add(cancel); p.Children.Add(row);
        w.Content = p;
        if (w.ShowDialog() != true) return;

        string tkey = targets[Math.Max(0, cTarget.SelectedIndex)].Key;
        bool live = cCase.SelectedIndex == 1;
        var act = live ? ActionType.Q : ActionType.G;
        double inf = 1;
        if (tInf.Visibility == Visibility.Visible)
        {
            if (!double.TryParse(tInf.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out inf) || inf <= 0)
            { MessageBox.Show(this, "Dimension d'influence invalide.", "Appliquer la charge"); return; }
        }
        double v = pick.Value;
        string label = "Biblio : " + pick.Text;
        CommitGrids(); PushUndo();
        string done;
        if (tkey == "members")
        {
            int nb = 0, nn = 0;
            foreach (var m in members)
            {
                if (pick.Kind == "Point")
                {
                    if (m.Type == MemberType.Column)
                    {
                        var ni = FindNode(m.NodeI); var nj = FindNode(m.NodeJ);
                        int top = ni != null && nj != null && nj.Z >= ni.Z ? m.NodeJ : m.NodeI;
                        _model.NodalLoads.Add(new NodalLoad { NodeId = top, Case = act, Fz = -v }); nn++;
                    }
                    else
                        { _model.MemberLoads.Add(new MemberLoad { MemberId = m.Id, Case = act, Kind = MemberLoadKind.Point, Frame = LoadFrame.Global, A = 0.5, Relative = true, Pz = -v, Label = label }); nb++; }
                }
                else
                {
                    double w1 = pick.Kind == "Surface" ? v * inf : v;
                    _model.MemberLoads.Add(new MemberLoad { MemberId = m.Id, Case = act, Kind = MemberLoadKind.Uniform, Frame = LoadFrame.Global, Wz = -w1, Label = label }); nb++;
                }
            }
            done = $"{nb} charge(s) de barre" + (nn > 0 ? $" et {nn} charge(s) nodale(s) en tête de poteau" : "");
        }
        else if (tkey == "slab")
        {
            double q;
            if (pick.Kind == "Surface") q = v;
            else if (pick.Kind == "Linear")
            {
                q = LoadCatalog.PartitionEquivalent(v);
                if (double.IsNaN(q)) { MessageBox.Show(this, $"{v:0.##} kN/m dépasse 3 kN/m : une cloison lourde ne se réduit pas à une charge surfacique. Appliquez-la à la poutre porteuse ou au nœud.", "Appliquer la charge"); return; }
            }
            else q = v / inf;
            if (live) slab!.Q = (chkAdd.IsChecked == true ? slab.Q : 0) + q;
            else slab!.GExtra = (chkAdd.IsChecked == true ? slab.GExtra : 0) + q;
            StoreyOps.SyncSlabLoads(_model, slab);
            try { GridSlabs.Items.Refresh(); } catch { }
            OnSlabSelected(slab);
            done = $"dalle {slab.Name} : {(live ? "Q" : "G supplémentaire")} {(chkAdd.IsChecked == true ? "+= " : "= ")}{q:0.###} kN/m²";
        }
        else
        {
            double f = pick.Kind == "Point" ? v : v * inf;
            foreach (int id in nodes) _model.NodalLoads.Add(new NodalLoad { NodeId = id, Case = act, Fz = -f });
            done = $"{nodes.Count} charge(s) nodale(s) de {f:0.###} kN";
        }
        OnModelEdited();
        Say($"Charge appliquée ({pick.Text}) : {done} - cas {act}. Relancez le calcul (F5).");
    }
}
