using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Quels éléments montrent leurs efforts : tout, poteaux seuls, poutres seules ou dalles seules.</summary>
public enum ResultFilter { Tous, Poteaux, Poutres, Dalles }

/// <summary>Maillage des dalles et cartes de résultats (flèche, moments, tranchants, armatures) colorées sur la dalle.</summary>
public sealed partial class ModelViewport
{
    /// <summary>Grandeur de dalle affichée en couleurs (None = aucune).</summary>
    public SlabFieldKind SlabView { get; set; } = SlabFieldKind.None;
    /// <summary>Affiche les lignes du maillage des dalles.</summary>
    public bool SlabMesh { get; set; }
    /// <summary>Filtre d'affichage des efforts par type d'élément.</summary>
    public ResultFilter Filter { get; set; } = ResultFilter.Tous;

    private bool MemberShown(MemberType t) => Filter switch
    {
        ResultFilter.Tous => true,
        ResultFilter.Poteaux => t == MemberType.Column,
        ResultFilter.Poutres => t != MemberType.Column,
        _ => false
    };

    private static Color Jet(double t)
    {
        t = Math.Clamp(t, 0, 1);
        double r, g, b;
        if (t < 0.25) { r = 0; g = 4 * t; b = 1; }
        else if (t < 0.5) { r = 0; g = 1; b = 1 - 4 * (t - 0.25); }
        else if (t < 0.75) { r = 4 * (t - 0.5); g = 1; b = 0; }
        else { r = 1; g = 1 - 4 * (t - 0.75); b = 0; }
        return Color.FromRgb((byte)(255 * r), (byte)(255 * g * 0.9), (byte)(255 * b));
    }

    private void DrawSlabFields()
    {
        if (Model == null || Filter == ResultFilter.Poteaux || Filter == ResultFilter.Poutres) return;
        var fields = Output?.SlabFields;
        bool colors = SlabView != SlabFieldKind.None && fields != null && fields.Count > 0;
        if (!colors && !SlabMesh) return;
        bool plan = Mode == ViewMode.Plan;
        var slabs = Model.Slabs.Where(s => s.Placed && !IsObjHidden(s) && (!plan || Math.Abs(s.Z - WorkOffset) < 0.05)).ToList();
        if (slabs.Count == 0) return;

        double gmin = double.MaxValue, gmax = double.MinValue;
        if (colors)
            foreach (var s in slabs)
            {
                foreach (var f in fields!.Where(q => q.Name == s.Name))
                {
                    var (a, b) = f.Range(SlabView);
                    gmin = Math.Min(gmin, a); gmax = Math.Max(gmax, b);
                }
            }
        if (gmin > gmax) colors = false;
        if (!colors && !SlabMesh) return;
        double span = Math.Max(gmax - gmin, 1e-9);

        var dv = new DrawingVisual();
        var meshPen = new Pen(new SolidColorBrush(Color.FromArgb((byte)(colors ? 90 : 190), 0x30, 0x40, 0x50)), 0.6); meshPen.Freeze();
        var edgePen = new Pen(Br("#00838F"), 1.4);
        using (var dc = dv.RenderOpen())
        {
            foreach (var s in slabs)
                foreach (var cell in SlabCells.Of(Model, s))
                {
                    var f = colors ? fields!.FirstOrDefault(q => q.Name == s.Name && Math.Abs(q.X0 - cell.X0) < 1e-6 && Math.Abs(q.Y0 - cell.Y0) < 1e-6) : null;
                    int nx, ny;
                    if (f != null) { nx = f.Nx; ny = f.Ny; } else (nx, ny) = StructCalc.Core.MeshPresets.SlabCounts(Model.Settings, cell.Lx, cell.Ly);
                    double hx = cell.Lx / nx, hy = cell.Ly / ny;
                    double[,]? v = null;
                    if (f != null) f.Values.TryGetValue(SlabView, out v);
                    for (int i = 0; i < nx; i++)
                        for (int j = 0; j < ny; j++)
                        {
                            double x0 = cell.X0 + i * hx, y0 = cell.Y0 + j * hy;
                            var p1 = S(x0, y0, s.Z); var p2 = S(x0 + hx, y0, s.Z); var p3 = S(x0 + hx, y0 + hy, s.Z); var p4 = S(x0, y0 + hy, s.Z);
                            Brush? fill = null;
                            if (v != null)
                            {
                                double val = (v[i, j] + v[i + 1, j] + v[i + 1, j + 1] + v[i, j + 1]) / 4;
                                var col = Jet((val - gmin) / span);
                                var br = new SolidColorBrush(Color.FromArgb(205, col.R, col.G, col.B)); br.Freeze();
                                fill = br;
                            }
                            var geo = new StreamGeometry();
                            using (var g = geo.Open()) { g.BeginFigure(p1, true, true); g.LineTo(p2, true, false); g.LineTo(p3, true, false); g.LineTo(p4, true, false); }
                            geo.Freeze();
                            dc.DrawGeometry(fill, SlabMesh || fill == null ? meshPen : null, geo);
                        }
                    var q1 = S(cell.X0, cell.Y0, s.Z); var q2 = S(cell.X0 + cell.Lx, cell.Y0, s.Z); var q3 = S(cell.X0 + cell.Lx, cell.Y0 + cell.Ly, s.Z); var q4 = S(cell.X0, cell.Y0 + cell.Ly, s.Z);
                    dc.DrawLine(edgePen, q1, q2); dc.DrawLine(edgePen, q2, q3); dc.DrawLine(edgePen, q3, q4); dc.DrawLine(edgePen, q4, q1);
                }
        }
        _c.Children.Add(new VisualHost(dv));

        if (!colors) return;
        // valeurs extrêmes sur chaque dalle
        foreach (var s in slabs)
        {
            foreach (var f in fields!.Where(q => q.Name == s.Name))
            {
                if (!f.Values.TryGetValue(SlabView, out var v)) continue;
                int bi = 0, bj = 0; double bestAbs = -1;
                for (int i = 0; i <= f.Nx; i++) for (int j = 0; j <= f.Ny; j++) if (Math.Abs(v[i, j]) > bestAbs) { bestAbs = Math.Abs(v[i, j]); bi = i; bj = j; }
                var pt = S(f.X0 + bi * f.Lx / f.Nx, f.Y0 + bj * f.Ly / f.Ny, s.Z);
                Text($"{v[bi, bj]:0.0} {SlabField.Unit(SlabView)}", pt.X + 3, pt.Y - 8, 10, Dark, Br("#CCFFFFFF"), true);
            }
        }

        // légende
        double w = Math.Max(_c.ActualWidth, 300), hh = Math.Max(_c.ActualHeight, 260), top = hh - 150;   // coin inférieur droit
        var bar = new Rectangle { Width = 16, Height = 120 };
        var gb = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(0, 1) };
        for (int k = 0; k <= 8; k++) gb.GradientStops.Add(new GradientStop(Jet(1 - k / 8.0), k / 8.0));
        bar.Fill = gb; bar.Stroke = Dark; bar.StrokeThickness = 0.6; bar.IsHitTestVisible = false;
        Canvas.SetLeft(bar, w - 118); Canvas.SetTop(bar, top);
        _c.Children.Add(bar);
        Text(SlabField.Title(SlabView) + $" [{SlabField.Unit(SlabView)}]", w - 250, top - 22, 11, Dark, Br("#CCFFFFFF"), true);
        Text($"{gmax:0.00}", w - 98, top - 4, 10, Dark, Br("#CCFFFFFF"));
        Text($"{(gmin + gmax) / 2:0.00}", w - 98, top + 53, 10, Dark, Br("#CCFFFFFF"));
        Text($"{gmin:0.00}", w - 98, top + 112, 10, Dark, Br("#CCFFFFFF"));
    }
}
