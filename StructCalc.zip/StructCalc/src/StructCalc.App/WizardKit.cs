using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using StructCalc.Engine.Drawing;

namespace StructCalc.UI;

/// <summary>Constructeur de formulaires pour les assistants : champs numériques, listes, cases à cocher, titres ; chaque modification
/// met à jour l'objet édité puis déclenche <see cref="Changed"/> (avec un court délai pour ne recalculer qu'une fois).</summary>
public sealed class FormKit
{
    public StackPanel Root { get; } = new() { Margin = new Thickness(12) };
    public event Action? Changed;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(350) };
    private bool _loading;
    private readonly List<Action> _refreshers = new();

    public FormKit()
    {
        _timer.Tick += (s, e) => { _timer.Stop(); Changed?.Invoke(); };
    }

    private void Fire() { if (_loading) return; _timer.Stop(); _timer.Start(); }

    /// <summary>Recharge tous les champs depuis l'objet (sans déclencher de recalcul intermédiaire).</summary>
    public void Refresh()
    {
        _loading = true;
        try { foreach (var r in _refreshers) r(); }
        finally { _loading = false; }
    }

    public void Section(string title, string? hint = null)
    {
        Root.Children.Add(new TextBlock { Text = title, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 12, 0, 4), Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), FontSize = 13 });
        if (hint != null) Root.Children.Add(new TextBlock { Text = hint, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 0, 0, 4) });
    }

    private Grid Row(string label, UIElement ctl, string? tip)
    {
        var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(175) });
        g.ColumnDefinitions.Add(new ColumnDefinition());
        var t = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 8, 0) };
        if (tip != null) { t.ToolTip = tip; ((FrameworkElement)ctl).ToolTip = tip; }
        g.Children.Add(t); Grid.SetColumn((UIElement)ctl, 1); g.Children.Add(ctl);
        Root.Children.Add(g);
        return g;
    }

    public TextBox Num(string label, Func<double> get, Action<double> set, string? tip = null, string unit = "")
    {
        var tb = new TextBox { Padding = new Thickness(3), Width = 100, HorizontalAlignment = HorizontalAlignment.Left };
        var sp = new StackPanel { Orientation = Orientation.Horizontal };
        sp.Children.Add(tb);
        if (unit.Length > 0) sp.Children.Add(new TextBlock { Text = " " + unit, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Gray });
        void Load() => tb.Text = Ui.Fmt(get());
        _refreshers.Add(Load); Load();
        tb.TextChanged += (s, e) =>
        {
            if (_loading) return;
            double v = Ui.Num(tb.Text, double.NaN);
            if (double.IsNaN(v)) { tb.Background = Brushes.MistyRose; return; }
            tb.Background = Brushes.White;
            set(v); Fire();
        };
        Row(label, sp, tip);
        return tb;
    }

    public ComboBox Combo<T>(string label, IList<(string Text, T Value)> items, Func<T> get, Action<T> set, string? tip = null) where T : notnull
    {
        var cb = new ComboBox { MaxWidth = 320, MinWidth = 150, HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var it in items) cb.Items.Add(it.Text);
        void Load() { int i = -1; for (int k = 0; k < items.Count; k++) if (EqualityComparer<T>.Default.Equals(items[k].Value, get())) i = k; cb.SelectedIndex = i; }
        _refreshers.Add(Load); Load();
        cb.SelectionChanged += (s, e) => { if (_loading || cb.SelectedIndex < 0) return; set(items[cb.SelectedIndex].Value); Fire(); };
        Row(label, cb, tip);
        return cb;
    }

    public CheckBox Check(string label, Func<bool> get, Action<bool> set, string? tip = null)
    {
        var c = new CheckBox { Content = label, Margin = new Thickness(0, 3, 0, 3) };
        void Load() => c.IsChecked = get();
        _refreshers.Add(Load); Load();
        c.Checked += (s, e) => { if (_loading) return; set(true); Fire(); };
        c.Unchecked += (s, e) => { if (_loading) return; set(false); Fire(); };
        if (tip != null) c.ToolTip = tip;
        Root.Children.Add(c);
        return c;
    }

    public TextBox Text(string label, Func<string> get, Action<string> set)
    {
        var tb = new TextBox { Padding = new Thickness(3), MaxWidth = 320, MinWidth = 150, HorizontalAlignment = HorizontalAlignment.Stretch };
        void Load() => tb.Text = get();
        _refreshers.Add(Load); Load();
        tb.TextChanged += (s, e) => { if (_loading) return; set(tb.Text); Fire(); };
        Row(label, tb, null);
        return tb;
    }

    public void Add(UIElement e) => Root.Children.Add(e);
}

/// <summary>Aperçu d'une planche de dessin (zoom molette, glisser pour déplacer) pour les assistants.</summary>
public sealed class SheetPreview : Border
{
    private readonly Canvas _view = new() { ClipToBounds = true, Background = Brushes.DimGray };
    private readonly VisualHost _host = new();
    private readonly MatrixTransform _mt = new(Matrix.Identity);
    private Sheet? _sheet;
    private bool _pan; private Point _p0; private Matrix _m0;
    private const double K = 3.0;

    public SheetPreview()
    {
        Child = _view; _host.RenderTransform = _mt; _view.Children.Add(_host);
        _view.SizeChanged += (s, e) => { if (_sheet != null && _fitNext) Fit(); };
        _view.MouseWheel += (s, e) =>
        {
            var m = _mt.Matrix; double f = e.Delta > 0 ? 1.2 : 1 / 1.2; var p = e.GetPosition(_view);
            double ns = m.M11 * f; if (ns < 0.02 || ns > 60) return;
            m.OffsetX = p.X - (p.X - m.OffsetX) * f; m.OffsetY = p.Y - (p.Y - m.OffsetY) * f; m.M11 = ns; m.M22 = ns; _mt.Matrix = m; e.Handled = true;
        };
        _view.MouseLeftButtonDown += (s, e) => { if (e.ClickCount == 2) { Fit(); return; } _pan = true; _p0 = e.GetPosition(_view); _m0 = _mt.Matrix; _view.CaptureMouse(); };
        _view.MouseMove += (s, e) => { if (!_pan) return; var d = e.GetPosition(_view) - _p0; var m = _m0; m.OffsetX += d.X; m.OffsetY += d.Y; _mt.Matrix = m; };
        _view.MouseLeftButtonUp += (s, e) => { _pan = false; _view.ReleaseMouseCapture(); };
    }

    private bool _fitNext = true;
    public void Show(Sheet s, bool fit = true)
    {
        _sheet = s;
        _host.SetVisual(SheetRenderer.Render(s, K, true), s.Width * K, s.Height * K);
        if (fit) Fit();
    }

    public void Fit()
    {
        if (_sheet == null) return;
        double vw = _view.ActualWidth > 20 ? _view.ActualWidth : 700, vh = _view.ActualHeight > 20 ? _view.ActualHeight : 500;
        double w = _sheet.Width * K, h = _sheet.Height * K, k = Math.Min((vw - 10) / w, (vh - 10) / h);
        _mt.Matrix = new Matrix(k, 0, 0, k, (vw - w * k) / 2, (vh - h * k) / 2);
        _fitNext = false;
    }
}
