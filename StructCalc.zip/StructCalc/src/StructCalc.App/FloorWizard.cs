using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Floors;

namespace StructCalc.UI;

/// <summary>Assistant planchers : plancher à corps creux (poutrelles + hourdis) ou dalle pleine (panneau BAEL/EC2), avec création des charges surfaciques.</summary>
public sealed class FloorWizardWindow : Window
{
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<Func<StructModel, string>, string> _apply;
    private RibbedFloorDef _rf = new();
    private SlabPanel _sp = new();
    private bool _slabMode;
    private string _spansText = "";
    private bool _createSlabLoad = true;
    private readonly ComboBox _kind = new() { Width = 220 };
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(8) };
    private readonly SheetPreview _preview = new();
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private readonly ScrollViewer _formHost = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private FormKit _form = null!;

    public FloorWizardWindow(Func<StructModel> model, Func<Func<StructModel, string>, string> apply, SlabPanel? seed = null)
    {
        _get = model; _apply = apply;
        Title = "Assistant planchers : corps creux et dalle pleine";
        Width = 1300; Height = 800; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _rf = _model.RibbedFloors.FirstOrDefault()?.Clone() ?? NewRib();
        _sp = _model.Slabs.FirstOrDefault() ?? new SlabPanel();
        _spansText = string.Join("; ", _rf.Spans.Select(x => x.ToString("0.00")));
        if (seed != null)
        {
            // ouverture depuis une dalle dessinée : mode « dalle pleine » avec ses dimensions, sa cote et ses charges
            _sp = new SlabPanel { Name = seed.Name, Lx = seed.Lx, Ly = seed.Ly, H = seed.H, GExtra = seed.GExtra, Q = seed.Q, Continuity = seed.Continuity, Crack = seed.Crack, Gamma = seed.Gamma, CalcMode = seed.CalcMode };
            _slabMode = true; _rf.Z = seed.Z; _rf.X0 = seed.X0; _rf.Y0 = seed.Y0;
        }

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(480) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Type :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        _kind.Items.Add("Plancher à corps creux (poutrelles + hourdis)"); _kind.Items.Add("Dalle pleine (panneau)");
        _kind.Width = 330; _kind.SelectedIndex = _slabMode ? 1 : 0;
        _kind.SelectionChanged += (s, e) => { _slabMode = _kind.SelectedIndex == 1; RebuildForm(); Recompute(); };
        bar.Children.Add(_kind);
        bar.Children.Add(new Border { Width = 10 });
        bar.Children.Add(Ui.Btn("💾 Enregistrer dans le projet", (s, e) => Save(), true));
        bar.Children.Add(Ui.Btn("🗑 Retirer du projet", (s, e) => Delete()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);
        var tabs = new TabControl { Margin = new Thickness(4) };
        tabs.Items.Add(new TabItem { Header = "Plan ferraillé", Content = _preview });
        tabs.Items.Add(new TabItem { Header = "Note de calcul", Content = _report });
        Grid.SetRow(tabs, 1); Grid.SetColumn(tabs, 1); root.Children.Add(tabs);
        Content = root;
        RebuildForm();
        Loaded += (s, e) => Recompute();
    }

    private RibbedFloorDef NewRib()
    {
        int n = 1; while (_model.RibbedFloors.Any(x => x.Name == "PL" + n)) n++;
        return new RibbedFloorDef { Name = "PL" + n, CoverCm = _model.Settings.CoverSlabCm };
    }

    private static readonly double[] Hourdis = { 12, 16, 20, 25, 30 };

    private void RebuildForm()
    {
        _form = new FormKit();
        if (!_slabMode)
        {
            var d = _rf;
            _form.Section("Plancher à corps creux", "Poids propre selon le tableau usuel (12+4 : 2,60 ; 16+4 : 2,85 ; 20+4 : 3,30 ; 25+5 : 4,00 ...). Méthode forfaitaire si ses conditions sont remplies, sinon poutre continue (trois moments) à charges alternées.");
            _form.Text("Nom", () => d.Name, v => d.Name = v);
            _form.Combo("Hauteur du hourdis", Hourdis.Select(h => ($"{h:0} cm", h)).ToList(), () => d.HourdisCm, v => d.HourdisCm = v);
            _form.Num("Dalle de compression", () => d.ToppingCm, v => d.ToppingCm = v, "4 cm minimum", "cm");
            _form.Num("Entraxe des poutrelles", () => d.SpacingM, v => d.SpacingM = v, "0,60 à 0,65 m usuel", "m");
            _form.Num("Largeur de nervure b0", () => d.WebCm, v => d.WebCm = v, null, "cm");
            _form.Text("Portées (m), séparées par des « ; »", () => _spansText, v => { _spansText = v; ParseSpans(); });
            _form.Num("Charges permanentes ajoutées (revêtement, cloisons)", () => d.GExtraKnM2, v => d.GExtraKnM2 = v, "Sans le poids du plancher", "kN/m²");
            _form.Num("Charge d'exploitation Q", () => d.QKnM2, v => d.QKnM2 = v, "1,5 habitation ; 2,5 bureaux", "kN/m²");
            _form.Num("Enrobage", () => d.CoverCm, v => d.CoverCm = v, null, "cm");
            _form.Check("Appuis de rive solidaires (chapeaux 0,15 M0)", () => d.EdgeRestrained, v => d.EdgeRestrained = v);
            _form.Combo("Fissuration", new (string, CrackingClass)[] { ("Peu préjudiciable", CrackingClass.PeuPrejudiciable), ("Préjudiciable", CrackingClass.Prejudiciable), ("Très préjudiciable", CrackingClass.TresPrejudiciable) }, () => d.Crack, v => d.Crack = v);
            _form.Section("Charges sur la structure", "Crée une charge surfacique permanente (G) et d'exploitation (Q) répartie sur les poutres porteuses (sens des poutrelles).");
            _form.Check("Créer les charges surfaciques sur les poutres", () => d.CreateLoads, v => d.CreateLoads = v);
            _form.Combo("Sens des poutrelles", new (string, char)[] { ("Selon X", 'X'), ("Selon Y", 'Y') }, () => d.RibDirection, v => d.RibDirection = v);
            _form.Num("Niveau Z", () => d.Z, v => d.Z = v, null, "m");
            _form.Num("X min", () => d.X0, v => d.X0 = v, null, "m"); _form.Num("X max", () => d.X1, v => d.X1 = v, null, "m");
            _form.Num("Y min", () => d.Y0, v => d.Y0 = v, null, "m"); _form.Num("Y max", () => d.Y1, v => d.Y1 = v, null, "m");
        }
        else
        {
            var s = _sp;
            _form.Section("Dalle pleine", "Dalle rectangulaire sur appuis : portant dans un ou deux sens selon Lx/Ly (BAEL B.7 / EC2). Poids propre ajouté automatiquement (25 kN/m³ x h).");
            _form.Text("Nom", () => s.Name, v => s.Name = v);
            _form.Num("Portée Lx (petit côté)", () => s.Lx, v => s.Lx = v, null, "m");
            _form.Num("Portée Ly (grand côté)", () => s.Ly, v => s.Ly = v, null, "m");
            _form.Num("Épaisseur h", () => s.H, v => s.H = v, "Ex. 0,16 (Lx/30 à Lx/35 pour panneau continu)", "m");
            _form.Num("Charges permanentes ajoutées", () => s.GExtra, v => s.GExtra = v, "Revêtements, cloisons", "kN/m²");
            _form.Num("Charge d'exploitation Q", () => s.Q, v => s.Q = v, null, "kN/m²");
            _form.Combo("Continuité", new (string, SlabContinuity)[] { ("Simplement appuyée", SlabContinuity.Simple), ("Panneau de rive", SlabContinuity.Rive), ("Panneau intérieur (continu)", SlabContinuity.Interieure) }, () => s.Continuity, v => s.Continuity = v);
            _form.Combo("Fissuration", new (string, CrackingClass)[] { ("Peu préjudiciable", CrackingClass.PeuPrejudiciable), ("Préjudiciable", CrackingClass.Prejudiciable), ("Très préjudiciable", CrackingClass.TresPrejudiciable) }, () => s.Crack, v => s.Crack = v);
            _form.Check("Créer aussi les charges surfaciques G et Q sur la structure", () => _createSlabLoad, v => _createSlabLoad = v);
            _form.Num("Niveau Z", () => _rf.Z, v => _rf.Z = v, null, "m");
            _form.Num("X min", () => _rf.X0, v => _rf.X0 = v, null, "m"); _form.Num("Y min", () => _rf.Y0, v => _rf.Y0 = v, null, "m");
        }
        _form.Changed += Recompute;
        _formHost.Content = _form.Root;
    }

    private void ParseSpans()
    {
        var l = new List<double>();
        foreach (var t in _spansText.Split(new[] { ';', ' ', '/' }, StringSplitOptions.RemoveEmptyEntries))
            if (double.TryParse(t.Replace(',', '.'), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double v) && v > 0.3) l.Add(v);
        if (l.Count > 0) _rf.Spans = l;
    }

    private IReinforcedConcreteCode Rc() => (DesignCodeRegistry.Get(_model.RcCodeId) as IReinforcedConcreteCode) ?? (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");

    private void Recompute()
    {
        try
        {
            var rc = Rc();
            if (!_slabMode)
            {
                var r = RibbedFloorDesigner.Design(_rf, rc, _model.Fc28, _model.Fe, _model.Settings);
                _report.Text = r.Report;
                var o = new AnalysisOutput(); o.RibbedFloors.Add(r);
                var sh = FloorSheets.Build(o).FirstOrDefault();
                if (sh != null) { sh.Number = "-"; _preview.Show(sh); }
                _status.Text = r.Ok ? $"✔ Conforme ({rc.Id})" : "⚠ " + (r.Warnings.FirstOrDefault() ?? "À vérifier");
                _status.Foreground = r.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
            }
            else
            {
                var s = _sp;
                var res = rc.DesignSlab(new SlabInput(s.Lx, s.Ly, s.H, s.GExtra, s.Q, s.Continuity, _model.Fc28, _model.Fe, s.Crack, _model.Settings.CoverSlabCm / 100.0, _model.Settings));
                var sb = new System.Text.StringBuilder();
                sb.AppendLine($"DALLE PLEINE {s.Name} : {s.Lx:0.00} x {s.Ly:0.00} m, h = {s.H * 100:0} cm");
                foreach (var kv in res.Values) sb.AppendLine($"  {kv.Key} = {kv.Value:0.###}");
                foreach (var n in res.Notes) sb.AppendLine("  " + n);
                foreach (var w in res.Warnings) sb.AppendLine("ATTENTION : " + w);
                _report.Text = sb.ToString();
                res.Element = $"Dalle {s.Name} ({s.Lx:F2} x {s.Ly:F2} m, h={s.H * 100:F0} cm)";
                Sheet? slabSheet = null;
                try
                {
                    var tmp = new StructModel { Settings = _model.Settings };
                    tmp.Slabs.Add(new SlabPanel { Name = s.Name, Lx = s.Lx, Ly = s.Ly, H = s.H, GExtra = s.GExtra, Q = s.Q, Continuity = s.Continuity, Crack = s.Crack });
                    var so = new AnalysisOutput(); so.Slabs.Add(res);
                    slabSheet = RcSheets.Slabs(tmp, so, new List<BarLine>()).FirstOrDefault();
                }
                catch { slabSheet = null; }
                if (slabSheet != null) { slabSheet.Number = "-"; _preview.Show(slabSheet); }
                else _preview.Show(new Sheet { Name = "-", Title = "Dalle pleine : plan de ferraillage indisponible (voir note de calcul)" });
                _status.Text = res.Ok ? $"✔ Conforme ({rc.Id})" : "⚠ " + (res.Warnings.FirstOrDefault() ?? "À vérifier");
                _status.Foreground = res.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
            }
        }
        catch (Exception ex) { _status.Text = "Erreur : " + ex.Message; _status.Foreground = Brushes.Firebrick; }
    }

    private void Save()
    {
        if (!_slabMode)
        {
            var c = _rf.Clone();
            _status.Text = _apply(m =>
            {
                int i = m.RibbedFloors.FindIndex(x => x.Name == c.Name);
                if (i >= 0) m.RibbedFloors[i] = c; else m.RibbedFloors.Add(c);
                if (c.CreateLoads && c.X1 > c.X0 && c.Y1 > c.Y0)
                {
                    m.SurfaceLoads.RemoveAll(x => x.Name == c.Name + "-G" || x.Name == c.Name + "-Q");
                    var dist = c.RibDirection == 'Y' ? SurfaceDistribution.OneWayY : SurfaceDistribution.OneWayX;
                    double g = RibbedFloorDesigner.SelfWeight(c.HourdisCm, c.ToppingCm) + c.GExtraKnM2;
                    foreach (var (nm, cs, q) in new[] { ("-G", ActionType.G, g), ("-Q", ActionType.Q, c.QKnM2) })
                        m.SurfaceLoads.Add(new SurfaceLoad { Name = c.Name + nm, Case = cs, Q = q, Distribution = dist, Z = c.Z, X0 = c.X0, Y0 = c.Y0, X1 = c.X1, Y1 = c.Y1 });
                }
                return $"Plancher {c.Name} enregistré (calcul avec F5, plans avec « PLANS »).";
            });
        }
        else
        {
            var s = new SlabPanel { Name = _sp.Name, Lx = _sp.Lx, Ly = _sp.Ly, H = _sp.H, GExtra = _sp.GExtra, Q = _sp.Q, Continuity = _sp.Continuity, Crack = _sp.Crack, Gamma = _sp.Gamma, CalcMode = _sp.CalcMode };
            double z = _rf.Z, x0 = _rf.X0, y0 = _rf.Y0; bool loads = _createSlabLoad;
            _status.Text = _apply(m =>
            {
                var old = m.Slabs.FirstOrDefault(x => x.Name == s.Name); int i = old == null ? -1 : m.Slabs.IndexOf(old);
                if (old != null && old.Placed) { s.Placed = true; s.X0 = old.X0; s.Y0 = old.Y0; s.Z = old.Z; }   // une dalle dessinée garde son emplacement
                if (i >= 0) m.Slabs[i] = s; else m.Slabs.Add(s);
                if (loads && s.Placed) StructCalc.Engine.Structure.StoreyOps.SyncSlabLoads(m, s);
                else if (loads)
                {
                    StructCalc.Engine.Structure.StoreyOps.RemoveSlabLoads(m, s.Name);
                    m.SurfaceLoads.Add(new SurfaceLoad { Name = s.Name + "-G", Case = ActionType.G, Q = 25 * s.H + s.GExtra, Distribution = SurfaceDistribution.TwoWay, Z = z, X0 = x0, Y0 = y0, X1 = x0 + s.Lx, Y1 = y0 + s.Ly });
                    m.SurfaceLoads.Add(new SurfaceLoad { Name = s.Name + "-Q", Case = ActionType.Q, Q = s.Q, Distribution = SurfaceDistribution.TwoWay, Z = z, X0 = x0, Y0 = y0, X1 = x0 + s.Lx, Y1 = y0 + s.Ly });
                }
                return $"Dalle {s.Name} enregistrée dans le projet.";
            });
        }
        _status.Foreground = Brushes.DarkGreen;
    }

    private void Delete()
    {
        if (_slabMode) { string n = _sp.Name; _apply(m => { foreach (var sl in m.Slabs.Where(x => x.Name == n).ToList()) m.Slabs.Remove(sl); StructCalc.Engine.Structure.StoreyOps.RemoveSlabLoads(m, n); return $"Dalle {n} retirée."; }); }
        else { string n = _rf.Name; _apply(m => { m.RibbedFloors.RemoveAll(x => x.Name == n); m.SurfaceLoads.RemoveAll(x => x.Name == n + "-G" || x.Name == n + "-Q"); return $"Plancher {n} retiré."; }); }
    }
}
