using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Ligne du tableau des solutions : une solution, ce qu'elle change, et le résultat d'un vrai recalcul sur une copie du modèle.</summary>
public sealed class SolutionRow : INotifyPropertyChanged
{
    public FixOption Opt { get; }
    private readonly FixTarget _t;
    public SolutionRow(FixOption o, FixTarget t) { Opt = o; _t = t; }

    public event PropertyChangedEventHandler? PropertyChanged;
    public void Refresh() => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));

    public string Solution => Opt.Label;
    public string Portee => Opt.Scope;
    public string Modification => !Opt.Computed ? "calcul en cours…" : Opt.Step == null ? "-" : Opt.Change;
    public string Avant => _t.HasUtil ? $"{_t.Before * 100:0} %" : (_t.BeforeOk ? "OK" : "NON OK");
    public string Apres => !Opt.Computed ? "…" : Opt.Step == null ? "-"
        : _t.HasUtil ? $"{Opt.After * 100:0} % {(Opt.Reached ? "✔" : "✖")}" : (Opt.Reached ? "OK ✔" : "NON OK ✖");
    public string Resultat => !Opt.Computed ? "" : Opt.Result;
    public bool Atteint => Opt.Computed && Opt.Reached;
    public bool Insuffisant => Opt.Computed && Opt.Step != null && !Opt.Reached;
}

/// <summary>Fenêtre « Solutions de dimensionnement » : pour une alerte NON OK, chaque solution est essayée par un recalcul réel sur une copie du modèle
/// (le modèle de l'utilisateur n'est pas touché) ; on voit le taux avant / après et le nombre d'alertes du projet, puis on applique ou on annule.</summary>
public sealed class SolutionsWindow : Window
{
    private readonly CancellationTokenSource _cts = new();
    private readonly ObservableCollection<SolutionRow> _rows = new();
    private readonly DataGrid _grid;
    private readonly TextBlock _status, _note;
    private readonly ProgressBar _bar;
    private readonly Button _apply;
    public FixOption? Chosen { get; private set; }

    public SolutionsWindow(Window? owner, FixTarget target, IReadOnlyList<FixOption> options, string modelJson, int nonOkBefore, string title)
    {
        Title = title; Owner = owner; Width = 1020; Height = 640; MinWidth = 760; MinHeight = 460;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        foreach (var o in options) _rows.Add(new SolutionRow(o, target));

        var root = new Grid { Margin = new Thickness(14) };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        string head = target.Title + (target.HasUtil ? $"   -   taux actuel : {target.Before * 100:0} % (limite 100 %)" : target.BeforeOk ? "   -   conforme" : "   -   NON OK") +
                      $"   -   alertes dans le projet : {nonOkBefore}";
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        top.Children.Add(new TextBlock { Text = head, FontWeight = FontWeights.SemiBold, FontSize = 14, TextWrapping = TextWrapping.Wrap });
        top.Children.Add(new ScrollViewer
        {
            MaxHeight = 150, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Margin = new Thickness(0, 6, 0, 0),
            Content = new TextBlock { Text = "Valeurs calculées actuelles :\n" + target.Detail, TextWrapping = TextWrapping.Wrap, FontFamily = new FontFamily("Consolas"), FontSize = 12 }
        });
        Grid.SetRow(top, 0); root.Children.Add(top);

        _grid = new DataGrid { AutoGenerateColumns = false, IsReadOnly = true, SelectionMode = DataGridSelectionMode.Single, ItemsSource = _rows, CanUserAddRows = false, HeadersVisibility = DataGridHeadersVisibility.Column };
        void Col(string header, string path, DataGridLength width) => _grid.Columns.Add(new DataGridTextColumn
        {
            Header = header, Binding = new Binding(path), Width = width,
            ElementStyle = new Style(typeof(TextBlock)) { Setters = { new Setter(TextBlock.TextWrappingProperty, TextWrapping.Wrap), new Setter(TextBlock.MarginProperty, new Thickness(3)) } }
        });
        Col("Solution", nameof(SolutionRow.Solution), new DataGridLength(1.3, DataGridLengthUnitType.Star));
        Col("Portée", nameof(SolutionRow.Portee), new DataGridLength(120));
        Col("Modification proposée", nameof(SolutionRow.Modification), new DataGridLength(1.6, DataGridLengthUnitType.Star));
        Col("Taux avant", nameof(SolutionRow.Avant), new DataGridLength(80));
        Col("Taux estimé après", nameof(SolutionRow.Apres), new DataGridLength(110));
        Col("Résultat du recalcul", nameof(SolutionRow.Resultat), new DataGridLength(1.6, DataGridLengthUnitType.Star));
        var style = new Style(typeof(DataGridRow));
        var ok = new DataTrigger { Binding = new Binding(nameof(SolutionRow.Atteint)), Value = true };
        ok.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0xE8, 0xF5, 0xE9))));
        var ko = new DataTrigger { Binding = new Binding(nameof(SolutionRow.Insuffisant)), Value = true };
        ko.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(0xFD, 0xEC, 0xEA))));
        style.Triggers.Add(ok); style.Triggers.Add(ko);
        _grid.RowStyle = style;
        _grid.SelectionChanged += (s, e) => UpdateApply();
        Grid.SetRow(_grid, 1); root.Children.Add(_grid);

        var mid = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
        _note = new TextBlock { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, MinHeight = 34 };
        _bar = new ProgressBar { IsIndeterminate = true, Height = 6, Margin = new Thickness(0, 6, 0, 2) };
        _status = new TextBlock { Text = "Recalcul réel de chaque solution sur une copie du modèle (votre modèle n'est pas modifié)...", TextWrapping = TextWrapping.Wrap };
        mid.Children.Add(_note); mid.Children.Add(_bar); mid.Children.Add(_status);
        Grid.SetRow(mid, 2); root.Children.Add(mid);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        _apply = Ui.Btn("Appliquer la solution sélectionnée", (s, e) => ApplySelected(), true);
        _apply.IsEnabled = false;
        var cancel = new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true };
        buttons.Children.Add(_apply); buttons.Children.Add(cancel);
        Grid.SetRow(buttons, 3); root.Children.Add(buttons);
        Content = root;

        Closing += (s, e) => _cts.Cancel();
        Loaded += async (s, e) =>
        {
            try
            {
                await Task.Run(() => DesignFixes.EvaluateAll(modelJson, options, target, nonOkBefore, _cts.Token, done =>
                    Dispatcher.BeginInvoke(new Action(() => { _rows.FirstOrDefault(q => ReferenceEquals(q.Opt, done))?.Refresh(); UpdateApply(); }))));
                _status.Text = _rows.Any(r => r.Atteint)
                    ? "Calcul terminé. Les lignes vertes vérifient l'élément ; les lignes rouges ne suffisent pas seules. Rien n'est appliqué tant que vous ne cliquez pas sur « Appliquer ». Ces résultats sont des estimations : le calcul est relancé après application pour confirmer."
                    : "Calcul terminé. Aucune solution ne vérifie l'élément à elle seule : combinez-en plusieurs (appliquez-en une, puis relancez) ou revoyez le modèle (portées, charges).";
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { _status.Text = "Calcul interrompu : " + ex.Message; }
            finally
            {
                _bar.Visibility = Visibility.Collapsed;
                foreach (var r in _rows) r.Refresh();
                var best = _rows.FirstOrDefault(r => r.Atteint) ?? _rows.FirstOrDefault(r => r.Opt.Step != null);
                if (best != null && _grid.SelectedItem == null) _grid.SelectedItem = best;
                UpdateApply();
            }
        };
    }

    private void UpdateApply()
    {
        var r = _grid.SelectedItem as SolutionRow;
        _apply.IsEnabled = r != null && r.Opt.Computed && r.Opt.Step != null;
        _note.Text = r == null ? "" : (r.Opt.Note != "" ? r.Opt.Note + "\n" : "") + (r.Opt.Computed ? r.Opt.Result : "");
    }

    private void ApplySelected()
    {
        if (_grid.SelectedItem is not SolutionRow r || r.Opt.Step == null) return;
        if (!r.Opt.Reached &&
            MessageBox.Show(this, "Cette solution ne suffit pas à elle seule (l'élément reste NON OK après recalcul). L'appliquer quand même ?", "Solution insuffisante", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        Chosen = r.Opt;
        _cts.Cancel();
        DialogResult = true;
    }
}
