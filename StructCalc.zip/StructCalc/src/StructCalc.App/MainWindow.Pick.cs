using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Charges et cotes sélectionnables dans la vue (3D comprise) : menu clic droit, modification par formulaire, suppression.</summary>
public partial class MainWindow
{
    private void FillLoadMenu(ContextMenu cm, object o)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.DescribeObject(o)));
        cm.Items.Add(new Separator());
        if (o is SurfaceLoad sl && _vp.IsSlabGenerated(sl))
        {
            var slab = _model.Slabs.FirstOrDefault(d => sl.Name == d.Name + "-G" || sl.Name == d.Name + "-Q" || sl.Name.StartsWith(d.Name + "-G#") || sl.Name.StartsWith(d.Name + "-Q#"));
            if (slab != null) cm.Items.Add(Mi($"Modifier G / Q dans les propriétés de la dalle {slab.Name}...", () => SlabProps(slab)));
            cm.Items.Add(Mi("Supprimer (impossible : charge générée par la dalle)", () => { }, false, "Suppr"));
        }
        else
        {
            cm.Items.Add(Mi("Modifier la charge...", () => EditObject(o)));
            cm.Items.Add(Mi("Supprimer la charge", () => StatusLeft.Text = _vp.DeleteSelectedObject(), true, "Suppr"));
        }
        if (o is MemberLoad ml) cm.Items.Add(Mi($"Sélectionner la barre {ml.MemberId}", () => _vp.SetSelection(new[] { ml.MemberId })));
        if (o is NodalLoad nl) cm.Items.Add(Mi($"Sélectionner le nœud {nl.NodeId}", () => _vp.SelectNodesOnly(new[] { nl.NodeId })));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Gestionnaire de charges (liste complète)...", () => LoadManager_Click(this, new RoutedEventArgs())));
        cm.Items.Add(Mi("Assistant de charges...", () => LoadAssistant_Click(this, new RoutedEventArgs())));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Tout afficher", ShowAllHidden, _vp.HasHidden || _levelsHiddenNow, "Ctrl+H"));
    }

    private void FillDimMenu(ContextMenu cm, ManualDim d)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.DescribeObject(d)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Modifier la position de la ligne de cote...", () => EditObject(d)));
        cm.Items.Add(Mi("Supprimer la cote", () => StatusLeft.Text = _vp.DeleteSelectedObject(), true, "Suppr"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Masquer toutes les cotes automatiques", () => { _vp.Dims.ShowAuto = false; _vp.Redraw(); InitDims(); StatusLeft.Text = "Cotes automatiques masquées (menu Cotation pour les réafficher)."; }));
    }

    private static ActionType ParseCase(string s, ActionType def) => Enum.TryParse<ActionType>((s ?? "").Trim(), true, out var c) ? c : def;
    private static string N(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);

    private sealed class FieldSpec
    {
        public string Label = ""; public Func<string> Get = () => ""; public Action<string> Set = _ => { };
    }

    private static FieldSpec Fld(string label, Func<double> get, Action<double> set) =>
        new() { Label = label, Get = () => N(get()), Set = s => { double v = Ui.Num(s, double.NaN); if (!double.IsNaN(v)) set(v); } };

    private void EditObject(object o)
    {
        var f = new List<FieldSpec>();
        string title, intro = "Valeurs en kN, kN/m, kN/m² ou kN.m ; les efforts sont positifs selon les axes globaux (Z vers le haut : une charge descendante est négative en Wz / Pz).";
        switch (o)
        {
            case MemberLoad m:
                title = $"Charge sur la barre {m.MemberId}";
                f.Add(new FieldSpec { Label = "Cas (G, Q, W, S...)", Get = () => m.Case.ToString(), Set = s => m.Case = ParseCase(s, m.Case) });
                switch (m.Kind)
                {
                    case MemberLoadKind.Uniform:
                        f.Add(Fld("Wx (kN/m)", () => m.Wx, v => m.Wx = v)); f.Add(Fld("Wy (kN/m)", () => m.Wy, v => m.Wy = v)); f.Add(Fld("Wz (kN/m)", () => m.Wz, v => m.Wz = v)); break;
                    case MemberLoadKind.Trapezoid:
                        f.Add(Fld("Wx début (kN/m)", () => m.Wx, v => m.Wx = v)); f.Add(Fld("Wy début", () => m.Wy, v => m.Wy = v)); f.Add(Fld("Wz début", () => m.Wz, v => m.Wz = v));
                        f.Add(Fld("Wx fin (kN/m)", () => m.Wx2, v => m.Wx2 = v)); f.Add(Fld("Wy fin", () => m.Wy2, v => m.Wy2 = v)); f.Add(Fld("Wz fin", () => m.Wz2, v => m.Wz2 = v));
                        f.Add(Fld(m.Relative ? "Début A (0 à 1 de la longueur)" : "Début A (m)", () => m.A, v => m.A = v)); f.Add(Fld(m.Relative ? "Fin B (0 à 1)" : "Fin B (m)", () => m.B, v => m.B = v)); break;
                    case MemberLoadKind.Point:
                        f.Add(Fld("Px (kN)", () => m.Px, v => m.Px = v)); f.Add(Fld("Py (kN)", () => m.Py, v => m.Py = v)); f.Add(Fld("Pz (kN)", () => m.Pz, v => m.Pz = v));
                        f.Add(Fld(m.Relative ? "Position A (0 à 1 de la longueur)" : "Position A (m)", () => m.A, v => m.A = v)); break;
                    case MemberLoadKind.Moment:
                        f.Add(Fld("Mx (kN.m)", () => m.Mx, v => m.Mx = v)); f.Add(Fld("My (kN.m)", () => m.My, v => m.My = v)); f.Add(Fld("Mz (kN.m)", () => m.Mz, v => m.Mz = v));
                        f.Add(Fld(m.Relative ? "Position A (0 à 1)" : "Position A (m)", () => m.A, v => m.A = v)); break;
                    case MemberLoadKind.Thermal:
                        f.Add(Fld("ΔT uniforme (°C)", () => m.Dt, v => m.Dt = v)); f.Add(Fld("Gradient haut - bas (°C)", () => m.Dg, v => m.Dg = v)); break;
                }
                break;
            case SurfaceLoad s:
                title = $"Charge surfacique {s.Name}";
                f.Add(new FieldSpec { Label = "Cas (G, Q, W, S...)", Get = () => s.Case.ToString(), Set = x => s.Case = ParseCase(x, s.Case) });
                f.Add(Fld("q (kN/m², positif vers le bas)", () => s.Q, v => s.Q = v));
                f.Add(new FieldSpec { Label = "Répartition : 1 = deux sens, 2 = sens X, 3 = sens Y", Get = () => ((int)s.Distribution + 1).ToString(), Set = x => { int k = (int)Ui.Num(x, (int)s.Distribution + 1); s.Distribution = k == 2 ? SurfaceDistribution.OneWayX : k == 3 ? SurfaceDistribution.OneWayY : SurfaceDistribution.TwoWay; } });
                break;
            case NodalLoad n:
                title = $"Charge nodale au nœud {n.NodeId}";
                f.Add(new FieldSpec { Label = "Cas (G, Q, W, S...)", Get = () => n.Case.ToString(), Set = x => n.Case = ParseCase(x, n.Case) });
                f.Add(Fld("Fx (kN)", () => n.Fx, v => n.Fx = v)); f.Add(Fld("Fy (kN)", () => n.Fy, v => n.Fy = v)); f.Add(Fld("Fz (kN)", () => n.Fz, v => n.Fz = v));
                f.Add(Fld("Mx (kN.m)", () => n.Mx, v => n.Mx = v)); f.Add(Fld("My (kN.m)", () => n.My, v => n.My = v)); f.Add(Fld("Mz (kN.m)", () => n.Mz, v => n.Mz = v));
                break;
            case ManualDim d:
                title = "Cote manuelle";
                intro = "Éloignement de la ligne de cote par rapport aux points cotés (en pixels). Pour la supprimer : clic droit > Supprimer, ou touche Suppr.";
                f.Add(Fld("Décalage de la ligne de cote (px)", () => d.OffsetPx, v => d.OffsetPx = v));
                break;
            default: return;
        }
        var vals = PromptWindow.Ask(this, title, intro, f.Select(q => (q.Label, q.Get())).ToArray());
        if (vals == null) return;
        CommitGrids(); PushUndo();
        for (int i = 0; i < f.Count && i < vals.Length; i++) f[i].Set(vals[i]);
        if (o is ManualDim) { _vp.Redraw(); StatusLeft.Text = "Cote modifiée  (Ctrl+Z pour annuler)"; }
        else { OnModelEdited(); StatusLeft.Text = "Charge modifiée : relancez le calcul (F5)  (Ctrl+Z pour annuler)"; }
    }
}
