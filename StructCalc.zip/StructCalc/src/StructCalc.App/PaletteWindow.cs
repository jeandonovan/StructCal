using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace StructCalc.UI;

/// <summary>Palette de commandes (Ctrl+K) : on tape quelques mots et on retrouve n'importe quelle commande des menus.</summary>
public sealed class PaletteWindow : Window
{
    public sealed record Entry(string Path, string Title, Action Run);

    private readonly List<Entry> _all;
    private readonly TextBox _box = new() { FontSize = 16, Padding = new Thickness(8, 6, 8, 6), Margin = new Thickness(8, 8, 8, 4) };
    private readonly ListBox _list = new() { Margin = new Thickness(8, 0, 8, 8), BorderThickness = new Thickness(1) };

    public PaletteWindow(Window owner, List<Entry> all)
    {
        Owner = owner; _all = all;
        Title = "Rechercher une commande";
        Width = 640; Height = 430; WindowStartupLocation = WindowStartupLocation.Manual;
        Left = owner.Left + (owner.ActualWidth - Width) / 2; Top = owner.Top + 90;
        ResizeMode = ResizeMode.NoResize; ShowInTaskbar = false;

        var root = new DockPanel();
        var hint = new TextBlock { Text = "Tapez des mots (ex. « fond pdf », « imprimer », « combinaisons »)  ·  ↑ ↓ pour choisir  ·  Entrée pour lancer  ·  Échap pour fermer", Foreground = System.Windows.Media.Brushes.Gray, Margin = new Thickness(10, 0, 10, 4), FontSize = 11 };
        DockPanel.SetDock(_box, Dock.Top); DockPanel.SetDock(hint, Dock.Top);
        root.Children.Add(_box); root.Children.Add(hint); root.Children.Add(_list);
        Content = root;

        _list.DisplayMemberPath = nameof(Entry.Path);
        _box.TextChanged += (s, e) => Refresh();
        _box.PreviewKeyDown += OnKey;
        _list.MouseDoubleClick += (s, e) => Run();
        Loaded += (s, e) => { _box.Focus(); Refresh(); };
        Deactivated += (s, e) => { try { Close(); } catch { } };
    }

    private static string Norm(string s)
    {
        var d = s.ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var c in d) if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return sb.ToString();
    }

    private void Refresh()
    {
        var words = Norm(_box.Text).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var found = words.Length == 0
            ? _all.Take(60)
            : _all.Where(e => { var n = Norm(e.Path); return words.All(w => n.Contains(w)); })
                  .OrderBy(e => Norm(e.Title).StartsWith(words[0]) ? 0 : Norm(e.Title).Contains(words[0]) ? 1 : 2).ThenBy(e => e.Path.Length).Take(60);
        _list.ItemsSource = found.ToList();
        if (_list.Items.Count > 0) _list.SelectedIndex = 0;
    }

    private void OnKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape) { Close(); e.Handled = true; }
        else if (e.Key == Key.Down) { if (_list.SelectedIndex < _list.Items.Count - 1) _list.SelectedIndex++; _list.ScrollIntoView(_list.SelectedItem); e.Handled = true; }
        else if (e.Key == Key.Up) { if (_list.SelectedIndex > 0) _list.SelectedIndex--; _list.ScrollIntoView(_list.SelectedItem); e.Handled = true; }
        else if (e.Key == Key.Enter) { Run(); e.Handled = true; }
    }

    private void Run()
    {
        if (_list.SelectedItem is not Entry en) return;
        var owner = Owner;
        Close();
        owner.Dispatcher.BeginInvoke(new Action(() => { try { en.Run(); } catch (Exception ex) { MessageBox.Show(ex.Message, "StructCalc"); } }), System.Windows.Threading.DispatcherPriority.Background);
    }
}
