using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Assistant de configuration en 7 pages : normes et préréglage, séisme, enrobages, choix des armatures, dispositions constructives et
/// parasismiques, plans et cartouche, contrôle de cohérence. Travaille sur une copie du modèle : « Annuler » ne change rien.</summary>
public sealed class SettingsWizardWindow : Window
{
    private readonly StructModel _m;
    private readonly List<Action> _commits = new();
    private readonly ListBox _steps = new() { BorderThickness = new Thickness(0), FontSize = 13, Background = Brushes.Transparent };
    private readonly ScrollViewer _host = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Background = Brushes.White };
    private readonly List<(string Title, Func<UIElement> Build)> _defs = new();
    private readonly Dictionary<int, UIElement> _built = new();
    private readonly Button _prev = new(), _next = new();
    private bool _applyCovers = true;

    public StructModel? Result { get; private set; }

    public SettingsWizardWindow(StructModel source)
    {
        _m = ModelIO.FromJson(ModelIO.ToJson(source));
        Title = "StructCalc - Assistant de configuration";
        Width = 1020; Height = 780; MinWidth = 820; MinHeight = 560;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;

        _defs.Add(("1. Normes et préréglage", PageNorms));
        _defs.Add(("2. Séisme", PageSeismic));
        _defs.Add(("3. Matériaux et enrobages", PageCovers));
        _defs.Add(("4. Maillage et flèches", PageMeshDeflection));
        _defs.Add(("5. Armatures : choix", PageRebars));
        _defs.Add(("6. Dispositions constructives", PageDetailing));
        _defs.Add(("7. Plans et cartouche", PagePlans));
        _defs.Add(("8. Contrôle et résumé", PageSummary));
        foreach (var d in _defs) _steps.Items.Add(new TextBlock { Text = d.Title, Padding = new Thickness(14, 9, 10, 9) });
        _steps.SelectionChanged += (s, e) => ShowStep(_steps.SelectedIndex);

        var head = new Border
        {
            Background = AccentBrush(), Padding = new Thickness(20, 12, 20, 12),
            Child = new StackPanel
            {
                Children =
                {
                    new TextBlock { Text = "Assistant de configuration", FontSize = 19, FontWeight = FontWeights.Bold, Foreground = Brushes.White },
                    new TextBlock { Text = "Normes, séisme, enrobages, armatures, dispositions constructives et plans - par projet", Foreground = new SolidColorBrush(Color.FromRgb(0xCF, 0xE0, 0xF1)) }
                }
            }
        };
        var left = new Border { Background = new SolidColorBrush(Color.FromRgb(0xEE, 0xF1, 0xF5)), Width = 250, Child = _steps };

        _prev.Content = "◀ Précédent"; _next.Content = "Suivant ▶";
        StyleBtn(_prev, false); StyleBtn(_next, false);
        _prev.Click += (s, e) => { if (_steps.SelectedIndex > 0) _steps.SelectedIndex--; };
        _next.Click += (s, e) => { if (_steps.SelectedIndex < _defs.Count - 1) _steps.SelectedIndex++; };
        var apply = new Button { Content = "✔ Appliquer et fermer" }; StyleBtn(apply, true);
        apply.Click += (s, e) =>
        {
            CommitAll();
            _m.Settings.SyncAxisCovers();
            if (_applyCovers) SettingsApplier.ApplyCovers(_m);
            Result = _m; DialogResult = true;
        };
        var cancel = new Button { Content = "Annuler" }; StyleBtn(cancel, false);
        cancel.Click += (s, e) => { DialogResult = false; };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12) };
        buttons.Children.Add(_prev); buttons.Children.Add(_next); buttons.Children.Add(apply); buttons.Children.Add(cancel);
        var bottom = new Border { BorderBrush = new SolidColorBrush(Color.FromRgb(0xC9, 0xD1, 0xDB)), BorderThickness = new Thickness(0, 1, 0, 0), Background = Brushes.White, Child = buttons };

        var dock = new DockPanel();
        DockPanel.SetDock(head, Dock.Top); dock.Children.Add(head);
        DockPanel.SetDock(bottom, Dock.Bottom); dock.Children.Add(bottom);
        DockPanel.SetDock(left, Dock.Left); dock.Children.Add(left);
        dock.Children.Add(_host);
        Content = dock;
        _steps.SelectedIndex = 0;
    }

    // ------------------------------------------------------------------ navigation
    private void StyleBtn(Button b, bool primary)
    {
        b.Padding = new Thickness(14, 6, 14, 6); b.Margin = new Thickness(6, 0, 0, 0); b.MinWidth = 90;
        if (primary && TryFindResource("PrimaryBtn") is Style st) b.Style = st;
    }

    private void CommitAll() { foreach (var a in _commits.ToList()) a(); }

    private void ShowStep(int i)
    {
        if (i < 0 || i >= _defs.Count) return;
        if (i == _defs.Count - 1) { CommitAll(); _built.Remove(i); }
        if (!_built.TryGetValue(i, out var ui)) { ui = _defs[i].Build(); _built[i] = ui; }
        _host.Content = ui;
        _host.ScrollToTop();
        _prev.IsEnabled = i > 0; _next.IsEnabled = i < _defs.Count - 1;
    }

    private void LoadPreset(string name)
    {
        CommitAll();
        SettingsPresets.Apply(name, _m);
        _built.Clear(); _commits.Clear();
        ShowStep(_steps.SelectedIndex);
    }

    // ------------------------------------------------------------------ briques de formulaire
    private static Brush AccentBrush() => Application.Current?.TryFindResource("Accent") as Brush ?? Brushes.SteelBlue;

    private static StackPanel Page(string title, string intro)
    {
        var p = new StackPanel { Margin = new Thickness(26, 18, 26, 22) };
        p.Children.Add(new TextBlock { Text = title, FontSize = 21, FontWeight = FontWeights.Bold, Foreground = AccentBrush() });
        if (intro != "")
            p.Children.Add(new TextBlock { Text = intro, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, Margin = new Thickness(0, 4, 0, 10) });
        return p;
    }

    private static void Section(StackPanel p, string text) =>
        p.Children.Add(new TextBlock { Text = text, FontSize = 14, FontWeight = FontWeights.SemiBold, Foreground = AccentBrush(), Margin = new Thickness(0, 16, 0, 4) });

    private static void Note(StackPanel p, string text) =>
        p.Children.Add(new TextBlock { Text = text, FontSize = 11.5, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 6, 0, 2) });

    private static void Row(StackPanel p, string label, UIElement ctl, string? hint)
    {
        var g = new Grid { Margin = new Thickness(0, 3, 0, 3) };
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(370) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var t = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 12, 0) };
        Grid.SetColumn(ctl, 1);
        g.Children.Add(t); g.Children.Add(ctl);
        p.Children.Add(g);
        if (!string.IsNullOrEmpty(hint))
            p.Children.Add(new TextBlock { Text = hint, FontSize = 11, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 4) });
    }

    private static bool TryNum(string s, out double v) =>
        double.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v);

    private void Txt(StackPanel p, string label, Func<string> get, Action<string> set, string? hint = null)
    {
        var tb = new TextBox { Text = get(), Width = 300, HorizontalAlignment = HorizontalAlignment.Left };
        Row(p, label, tb, hint);
        _commits.Add(() => set(tb.Text));
    }

    private void Num(StackPanel p, string label, Func<double> get, Action<double> set, string? hint = null)
    {
        var tb = new TextBox { Text = get().ToString("0.####", CultureInfo.InvariantCulture), Width = 110, HorizontalAlignment = HorizontalAlignment.Left };
        Row(p, label, tb, hint);
        _commits.Add(() => { if (TryNum(tb.Text, out double v)) set(v); });
    }

    private void NumI(StackPanel p, string label, Func<int> get, Action<int> set, string? hint = null)
    {
        var tb = new TextBox { Text = get().ToString(CultureInfo.InvariantCulture), Width = 110, HorizontalAlignment = HorizontalAlignment.Left };
        Row(p, label, tb, hint);
        _commits.Add(() => { if (TryNum(tb.Text, out double v)) set((int)Math.Round(v)); });
    }

    private void Ints(StackPanel p, string label, Func<int[]> get, Action<int[]> set, string? hint = null)
    {
        var tb = new TextBox { Text = DesignSettings.IntsToText(get()), Width = 300, HorizontalAlignment = HorizontalAlignment.Left };
        Row(p, label, tb, hint);
        _commits.Add(() => { var v = DesignSettings.TextToInts(tb.Text); if (v.Length > 0) set(v); });
    }

    private void Chk(StackPanel p, string label, Func<bool> get, Action<bool> set, string? hint = null)
    {
        var cb = new CheckBox { IsChecked = get(), VerticalAlignment = VerticalAlignment.Center };
        Row(p, label, cb, hint);
        _commits.Add(() => set(cb.IsChecked == true));
    }

    private void Pick(StackPanel p, string label, string[] items, Func<string> get, Action<string> set, string? hint = null)
    {
        var cb = new ComboBox { Width = 220, HorizontalAlignment = HorizontalAlignment.Left, ItemsSource = items };
        string cur = get();
        cb.SelectedItem = items.Contains(cur) ? cur : items[0];
        Row(p, label, cb, hint);
        _commits.Add(() => { if (cb.SelectedItem is string v) set(v); });
    }

    private void CodePick(StackPanel p, string label, MaterialKind kind, Func<string> get, Action<string> set, string? hint = null)
    {
        var items = DesignCodeRegistry.Available(kind)
            .Select(c => new CodeItem(c.Id, c.DisplayName + (c.IsImplemented ? "" : "  (à venir)"))).ToList();
        var cb = new ComboBox { Width = 400, HorizontalAlignment = HorizontalAlignment.Left, ItemsSource = items, DisplayMemberPath = "Label", SelectedValuePath = "Id" };
        cb.SelectedValue = get();
        Row(p, label, cb, hint);
        _commits.Add(() => { if (cb.SelectedValue is string v) set(v); });
    }

    // ------------------------------------------------------------------ pages
    private UIElement PageNorms()
    {
        var p = Page("Normes et préréglage",
            "Choisissez un préréglage (norme et dispositions usuelles du pays) puis ajustez chaque valeur dans les pages suivantes. Rien n'est figé : c'est vous qui décidez de la norme.");
        Section(p, "Préréglage");
        var cb = new ComboBox { Width = 520, HorizontalAlignment = HorizontalAlignment.Left, ItemsSource = SettingsPresets.Names };
        if (SettingsPresets.Names.Contains(_m.Settings.Preset)) cb.SelectedItem = _m.Settings.Preset;
        var btn = new Button { Content = "Charger ce préréglage", Padding = new Thickness(14, 6, 14, 6), Margin = new Thickness(0, 8, 0, 0), HorizontalAlignment = HorizontalAlignment.Left };
        btn.Click += (s, e) => { if (cb.SelectedItem is string n) LoadPreset(n); };
        p.Children.Add(cb); p.Children.Add(btn);
        Note(p, "Un préréglage remplace : les normes BA / CM, le séisme (activé ou non), les recouvrements et ancrages, les zones critiques et les pourcentages d'armatures. Vos sections, vos charges et vos enrobages ne sont pas touchés.");
        Section(p, "Normes de calcul");
        CodePick(p, "Norme béton armé", MaterialKind.ReinforcedConcrete, () => _m.RcCodeId, v => _m.RcCodeId = v,
                 "BAEL91 / CBA93 / EC2 : non sismiques. RPA99 et EC8 : ajoutent les dispositions parasismiques.");
        CodePick(p, "Norme charpente métallique", MaterialKind.Steel, () => _m.SteelCodeId, v => _m.SteelCodeId = v);
        Section(p, "Matériaux et sol");
        Num(p, "fc28 : résistance du béton à 28 jours (MPa)", () => _m.Fc28, v => _m.Fc28 = v);
        Num(p, "fe : limite d'élasticité des aciers HA (MPa)", () => _m.Fe, v => _m.Fe = v);
        Num(p, "fy : limite d'élasticité de l'acier de construction (MPa)", () => _m.SteelFy, v => _m.SteelFy = v);
        Num(p, "Contrainte admissible du sol à l'ELS (kPa)", () => _m.SigmaSolKPa, v => _m.SigmaSolKPa = v, "0 = pas de calcul des semelles.");
        return p;
    }

    private UIElement PageSeismic()
    {
        var z = _m.Seismic;
        var p = Page("Séisme", "Méthode statique équivalente : les forces sont réparties sur les niveaux puis combinées aux autres actions (combinaisons accidentelles de la norme).");
        Chk(p, "Activer le calcul sismique", () => z.Enabled, v => z.Enabled = v);
        Pick(p, "Norme sismique (spectre)", new[] { "RPA99", "EC8" }, () => z.Norm, v => z.Norm = v);
        Pick(p, "Direction du séisme", new[] { "X", "Y" }, () => z.Direction.ToString(), v => z.Direction = v == "Y" ? SeismicDirection.Y : SeismicDirection.X,
             "Pour un portique plan dans XZ, choisissez X.");
        Section(p, "RPA 99 version 2003");
        Pick(p, "Zone sismique", new[] { "I", "IIa", "IIb", "III" }, () => z.Zone, v => z.Zone = v);
        Pick(p, "Groupe d'usage", new[] { "1A", "1B", "2", "3" }, () => z.Group, v => z.Group = v);
        Pick(p, "Catégorie de site", new[] { "S1", "S2", "S3", "S4" }, () => z.Site, v => z.Site = v);
        Num(p, "R : coefficient de comportement", () => z.R, v => z.R = v);
        Num(p, "Q : facteur de qualité", () => z.Q, v => z.Q = v);
        Num(p, "β : pondération de la charge d'exploitation", () => z.Beta, v => z.Beta = v, "Usage d'habitation / bureaux : 0,20.");
        Num(p, "ξ : amortissement (%)", () => z.XiPercent, v => z.XiPercent = v);
        Section(p, "Eurocode 8");
        Num(p, "ag/g : accélération de calcul sur sol rocheux", () => z.AgOverG, v => z.AgOverG = v);
        Pick(p, "Type de sol", new[] { "A", "B", "C", "D", "E" }, () => z.Ground, v => z.Ground = v);
        Num(p, "q : coefficient de comportement", () => z.BehaviorQ, v => z.BehaviorQ = v);
        Num(p, "γI : coefficient d'importance", () => z.ImportanceGamma, v => z.ImportanceGamma = v);
        Num(p, "ψE : coefficient de combinaison sismique", () => z.PsiE, v => z.PsiE = v);
        Section(p, "Commun");
        Num(p, "Ct : période fondamentale T = Ct × H^(3/4)", () => z.Ct, v => z.Ct = v, "Portiques en béton armé : 0,075 ; en acier : 0,085 (valeurs usuelles).");
        Note(p, "Valeurs indicatives de R (RPA 99) à confirmer dans votre exemplaire : portiques autostables en béton armé sans remplissage rigide : 5 ; avec remplissage en maçonnerie rigide : 3,5 ; voiles porteurs : 3,5 ; ossature mixte portiques/voiles : 5 ; portiques acier autostables ductiles : 6.");
        return p;
    }

    /// <summary>Liste déroulante dont les éléments ont un identifiant stocké et un libellé affiché ; la description du choix courant est montrée dessous.</summary>
    private void PickMap(StackPanel p, string label, (string Id, string Label, string Desc)[] items, Func<string> get, Action<string> set, string? hint = null)
    {
        var cb = new ComboBox { Width = 520, HorizontalAlignment = HorizontalAlignment.Left, ItemsSource = items.Select(i => i.Label).ToList() };
        int idx = Array.FindIndex(items, i => i.Id == get()); cb.SelectedIndex = idx >= 0 ? idx : 0;
        var desc = new TextBlock { FontSize = 11.5, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 6), MaxWidth = 700, HorizontalAlignment = HorizontalAlignment.Left };
        void Show() => desc.Text = cb.SelectedIndex >= 0 ? items[cb.SelectedIndex].Desc : "";
        cb.SelectionChanged += (s, e) => Show(); Show();
        Row(p, label, cb, hint);
        p.Children.Add(desc);
        _commits.Add(() => { if (cb.SelectedIndex >= 0) set(items[cb.SelectedIndex].Id); });
    }

    private UIElement PageMeshDeflection()
    {
        var s = _m.Settings;
        var p = Page("Maillage et flèches", "Maillage éléments finis des dalles (plaque, différences finies) et des voiles (coques), et mode de vérification de la flèche des poutres, consoles et dalles.");
        Section(p, "Maillage éléments finis");
        PickMap(p, "Type de maillage", MeshPresets.All.Select(m => (m.Id, m.Label, m.Calc)).ToArray(), () => s.MeshPreset, v => s.MeshPreset = v,
                "S'applique aux dalles et aux voiles ; chaque voile peut avoir son propre maillage dans son assistant.");
        PickMap(p, "Type d'éléments", new (string, string, string)[]
        {
            ("Quad", "Quadrangles (dalles : différences finies ; voiles : coques MITC4 / QM6)", "Maillage rectangulaire classique : précis, rapide ; le quadrillage suit les ouvertures des voiles."),
            ("Tri", "Triangulé (dalles : triangles DKT ; voiles : triangles CST + DKT)", "Chaque maille est coupée en deux triangles (diagonale alternée). Dalles : plaque de Kirchhoff à éléments DKT. Voiles : membrane CST + plaque DKT, à mailler plus finement que les quadrangles pour les voiles élancés chargés dans leur plan.")
        }, () => s.MeshElement, v => s.MeshElement = v);
        Num(p, "Taille de maille en mode Manuel (m)", () => s.MeshManualM, v => s.MeshManualM = v, "Dalles et voiles : 0,05 à 1 m.");
        NumI(p, "Dalles, mode Manuel : nombre de mailles en X (0 = déduit de la taille)", () => s.MeshManualNx, v => s.MeshManualNx = v, "3 à 40. Renseigner X et Y ensemble.");
        NumI(p, "Dalles, mode Manuel : nombre de mailles en Y (0 = déduit de la taille)", () => s.MeshManualNy, v => s.MeshManualNy = v);
        Note(p, "Plus le maillage est fin, plus les moments d'encastrement et les concentrations sont captés, mais plus le calcul est long. Les dalles sont plafonnées à 40 mailles par côté, les voiles à environ 6000 éléments.");

        Section(p, "Méthode de calcul des dalles pleines");
        PickMap(p, "Méthode", StructCalc.Engine.Structure.SlabMethods.All, () => s.SlabMethod, v => s.SlabMethod = v,
                "Réglage du projet ; chaque dalle peut avoir sa propre méthode (clic droit sur la dalle > propriétés).");
        Num(p, "Lignes de rupture : rapport moment d'appui / moment de travée", () => s.SlabYieldSupportRatio, v => s.SlabYieldSupportRatio = v, "1,0 à 2,0 ; 1,0 = armatures d'appui égales à celles de travée.");
        Num(p, "Direct design : largeur d'appui retranchée de la portée (m)", () => s.SlabSupportWidthM, v => s.SlabSupportWidthM = v, "Largeur de la poutre ou du poteau d'appui.");
        Chk(p, "Ajouter au calcul une note « comparaison des méthodes » pour chaque dalle", () => s.SlabCompareMethods, v => s.SlabCompareMethods = v);
        Note(p, "Forfaitaire, Caquot et Caquot minorée sont des méthodes de poutre continue : appliquées aux dalles, la charge est partagée entre les deux sens selon la rigidité. Le calcul par éléments finis suit le type de maillage choisi plus haut.");

        Section(p, "Vérification de la flèche");
        PickMap(p, "Mode de vérification", new (string, string, string)[]
        {
            ("Auto", "Automatique : flèche calculée selon la norme du projet", "BAEL / CBA / RPA : flèche calculée BAEL B.6.5,2 ; EC2 / EC8 : flèche calculée EC2 7.4.3."),
            ("Forfaitaire", "Forfaitaire (BAEL B.6.5,1 / EC2 7.4.2 : élancement)", "Vérifie seulement h/L, Mt/10M0 et le pourcentage d'armatures : dispense de calcul si les conditions sont remplies, sinon un avertissement demande le calcul."),
            ("ForfPuisCalc", "Forfaitaire, puis calculée si non satisfaite", "Calcul de la flèche uniquement quand les conditions forfaitaires ne sont pas remplies (démarche réglementaire usuelle)."),
            ("CalcBael", "Calculée BAEL B.6.5,2 (Ifi / Ifv, long terme)", "Inerties fissurées instantanée et différée (λi, λv = 0,4 λi, μ), module Ei et Ev = Ei/3, charges permanentes et totales."),
            ("CalcEc2", "Calculée EC2 7.4.3 (interpolation fissurée / non fissurée)", "Flèche = ζ·αII + (1-ζ)·αI avec fluage (module efficace Ecm/(1+φ)), ζ = 1 - β(Mcr/M)²."),
            ("CalcMax", "Calculée BAEL et EC2 (la plus défavorable)", "Les deux calculs sont faits et la flèche la plus grande est comparée à la limite."),
            ("Aucune", "Aucune vérification de flèche", "À réserver aux études où la flèche est justifiée par ailleurs.")
        }, () => s.DeflectionMethod, v => s.DeflectionMethod = v);
        PickMap(p, "Limite de flèche", new (string, string, string)[]
        {
            ("Norme", "Selon la norme du projet", "BAEL : L/500 si L ≤ 5 m, sinon 0,5 cm + L/1000 ; EC2 : L/250 (flèche totale). Console : portée prise égale à 2 L."),
            ("EC2", "L/250 (flèche totale, EC2)", "Limite de flèche à long terme sous charges quasi permanentes."),
            ("L500", "L/500 (éléments fragiles, cloisons)", "Limite sévère pour les poutres supportant des cloisons ou des revêtements fragiles."),
            ("Manuel", "Saisie : L / valeur ci-dessous", "Utilise le dénominateur saisi plus bas.")
        }, () => s.DeflectionLimitMode, v => s.DeflectionLimitMode = v);
        Num(p, "Dénominateur de la limite en mode Saisie (L / ...)", () => s.DeflectionManualDenominator, v => s.DeflectionManualDenominator = v, "Exemple : 300 pour L/300.");
        Num(p, "Part permanente des charges de service", () => s.DeflectionPermanentShare, v => s.DeflectionPermanentShare = v, "0 à 1 ; 0,70 usuel (habitation).");
        Num(p, "Coefficient de fluage φ (EC2)", () => s.CreepPhi, v => s.CreepPhi = v, "2 usuel (humidité moyenne) ; 1,5 à 3 selon l'âge au chargement.");
        Note(p, "Les dalles ne se calculent pas comme les poutres : leur flèche est estimée à partir du calcul élastique du maillage, multipliée par un facteur de fissuration et de fluage.");
        return p;
    }

    private UIElement PageCovers()
    {
        var s = _m.Settings;
        var p = Page("Matériaux et enrobages", "Enrobage nominal : distance du bord de la pièce à la face extérieure du cadre. L'axe des barres longitudinales est calculé automatiquement après le choix des barres : enrobage + diamètre du cadre + demi-diamètre de la barre.");
        Section(p, "Enrobages nominaux (cm)");
        Num(p, "Poutres", () => s.CoverNomBeamCm, v => s.CoverNomBeamCm = v, "Exemple : enrobage 2,5 cm, poutre 15 x 25 cm : le cadre mesure 10 x 20 cm.");
        Num(p, "Poteaux", () => s.CoverNomColumnCm, v => s.CoverNomColumnCm = v);
        Num(p, "Dalles", () => s.CoverNomSlabCm, v => s.CoverNomSlabCm = v);
        Num(p, "Semelles", () => s.CoverNomFootingCm, v => s.CoverNomFootingCm = v, "Au contact du sol : 5 cm minimum.");
        Chk(p, "Appliquer ces enrobages à toutes les barres existantes en validant", () => _applyCovers, v => _applyCovers = v,
            "Les barres que vous dessinez ensuite reçoivent automatiquement ces valeurs.");
        return p;
    }

    private UIElement PageRebars()
    {
        var s = _m.Settings;
        var p = Page("Armatures : choix", "Diamètres que le logiciel a le droit d'employer et règles de choix des barres et des cadres.");
        Section(p, "Diamètres disponibles (mm, séparés par des virgules)");
        Ints(p, "Poutres : barres longitudinales", () => s.BeamDiameters, v => s.BeamDiameters = v);
        Ints(p, "Poteaux : barres longitudinales", () => s.ColumnDiameters, v => s.ColumnDiameters = v);
        Ints(p, "Cadres, étriers et épingles", () => s.StirrupDiameters, v => s.StirrupDiameters = v);
        Ints(p, "Dalles et semelles", () => s.SlabDiameters, v => s.SlabDiameters = v);
        NumI(p, "Barres de montage des poutres (mm)", () => s.MountingBarDiaMm, v => s.MountingBarDiaMm = v);
        Section(p, "Règles de disposition");
        Num(p, "Espacement libre minimal entre barres (mm)", () => s.MinClearSpacingMm, v => s.MinClearSpacingMm = v);
        NumI(p, "Poutres : nombre maximal de barres par lit", () => s.MaxBarsPerLayer, v => s.MaxBarsPerLayer = v);
        NumI(p, "Poteaux : nombre maximal de barres longitudinales", () => s.MaxColumnBars, v => s.MaxColumnBars = v);
        Num(p, "Cadres : diamètre >= diamètre longitudinal / ", () => s.StirrupDiaRatio, v => s.StirrupDiaRatio = v, "Règle usuelle : 3.");
        Num(p, "Cadres : arrondi des espacements (cm)", () => s.SpacingStepCm, v => s.SpacingStepCm = v, "1 = au centimètre ; 5 = par pas de 5 cm.");
        Num(p, "Cadres : espacement minimal (cm)", () => s.MinStirrupSpacingCm, v => s.MinStirrupSpacingCm = v);
        Num(p, "Poteaux : espacement maximal des cadres (cm)", () => s.MaxStirrupSpacingColumnCm, v => s.MaxStirrupSpacingColumnCm = v);
        Num(p, "Dalles : espacement maximal, armatures principales (cm)", () => s.SlabMaxMainSpacingCm, v => s.SlabMaxMainSpacingCm = v, "Au plus min(3h ; 33 cm) selon BAEL.");
        Num(p, "Dalles : espacement maximal, armatures de répartition (cm)", () => s.SlabMaxDistribSpacingCm, v => s.SlabMaxDistribSpacingCm = v);
        Num(p, "Dalles : espacement en dessous duquel on augmente le diamètre (cm)", () => s.SlabMinSpacingCm, v => s.SlabMinSpacingCm = v);
        return p;
    }

    private UIElement PageDetailing()
    {
        var s = _m.Settings;
        var p = Page("Dispositions constructives et parasismiques", "Une valeur 0 pour un espacement ou un pourcentage signifie : appliquer la règle de la norme choisie (RPA 99, EC8...).");
        Section(p, "Zones critiques et cadres");
        Num(p, "Poutres : longueur de zone critique = facteur × h", () => s.BeamCriticalZoneFactor, v => s.BeamCriticalZoneFactor = v, "RPA 99 : 2 h. EC8 (DCM) : 1,5 h.");
        Num(p, "Poteaux : zone nodale = max(h ; he/6 ; cette valeur en cm)", () => s.ColumnCriticalZoneMinCm, v => s.ColumnCriticalZoneMinCm = v, "RPA 99 : 60 cm.");
        Num(p, "Poutres : espacement des cadres en zone critique (cm)", () => s.BeamNodalSpacingCm, v => s.BeamNodalSpacingCm = v, "0 = selon la norme.");
        Num(p, "Poteaux : espacement des cadres en zone nodale (cm)", () => s.ColumnNodalSpacingCm, v => s.ColumnNodalSpacingCm = v, "0 = selon la norme.");
        Section(p, "Pourcentages d'armatures longitudinales (% de la section de béton)");
        Num(p, "Poteaux : minimum", () => s.ColumnMinPercent, v => s.ColumnMinPercent = v, "0 = selon la norme (RPA 99 : 0,7 % à 0,9 % selon la zone).");
        Num(p, "Poteaux : maximum", () => s.ColumnMaxPercent, v => s.ColumnMaxPercent = v, "RPA 99 : 4 % en zone courante, 6 % en recouvrement. Si dépassé : la section est augmentée à l'optimisation.");
        Num(p, "Poutres : minimum (inférieur + supérieur)", () => s.BeamMinPercent, v => s.BeamMinPercent = v, "RPA 99 : 0,5 %.");
        Num(p, "Poutres : maximum (inférieur + supérieur)", () => s.BeamMaxPercent, v => s.BeamMaxPercent = v, "RPA 99 : 4 % en zone courante.");
        Section(p, "Ancrages, recouvrements et crochets (multiples du diamètre φ)");
        Num(p, "Recouvrement des barres", () => s.LapFactor, v => s.LapFactor = v, "Environ 40 φ (HA400) à 50 φ (HA500) ; RPA 99 : 40 φ (zones I, IIa) ou 50 φ (IIb, III).");
        Num(p, "Ancrage droit", () => s.AnchorageFactor, v => s.AnchorageFactor = v);
        Num(p, "Retour des crochets de cadres", () => s.HookFactor, v => s.HookFactor = v, "10 φ minimum, crochets à 135°.");
        Num(p, "Chapeaux de poutre : longueur = facteur × portée", () => s.BeamTopBarFactor, v => s.BeamTopBarFactor = v, "0,25 (appui de rive ou travée de rive) ; 0,20 en appui intermédiaire.");
        Num(p, "Chapeaux de dalle : longueur = facteur × petite portée", () => s.SlabTopBarFactor, v => s.SlabTopBarFactor = v);
        return p;
    }

    private UIElement PagePlans()
    {
        var s = _m.Settings;
        var p = Page("Plans et cartouche", "Informations imprimées dans le cartouche de chaque planche et options de dessin.");
        Section(p, "Cartouche");
        Txt(p, "Société / bureau d'études", () => s.Company, v => s.Company = v);
        Txt(p, "Ingénieur responsable", () => s.Engineer, v => s.Engineer = v);
        Txt(p, "Maître d'ouvrage / client", () => s.Client, v => s.Client = v);
        Txt(p, "Site / opération", () => s.SiteName, v => s.SiteName = v);
        Txt(p, "Indice de révision", () => s.Revision, v => s.Revision = v);
        Section(p, "Dessin");
        Chk(p, "Repères de coupe (A-A, B-B) avec flèches", () => s.ShowCutMarks, v => s.ShowCutMarks = v);
        Chk(p, "Bulles de repères des barres (1, 2, 3...)", () => s.ShowBarMarks, v => s.ShowBarMarks = v);
        Chk(p, "Nomenclature des aciers sur chaque planche", () => s.ShowBarSchedule, v => s.ShowBarSchedule = v);
        Chk(p, "Regrouper les éléments identiques (une seule planche pour P1, P3, P5...)", () => s.GroupIdenticalElements, v => s.GroupIdenticalElements = v);
        return p;
    }

    private UIElement PageSummary()
    {
        var p = Page("Contrôle et résumé", "Le logiciel contrôle la cohérence de votre configuration avant de l'appliquer.");
        var advice = SettingsAdvisor.Check(_m);
        Section(p, "Contrôle de cohérence");
        if (advice.Count == 0)
            p.Children.Add(new TextBlock { Text = "✔ Aucune incohérence détectée.", Foreground = Brushes.DarkGreen, FontSize = 14, Margin = new Thickness(0, 4, 0, 4) });
        else
            foreach (var a in advice)
                p.Children.Add(new TextBlock { Text = "⚠ " + a, Foreground = Brushes.DarkOrange, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 0, 3) });
        var s = _m.Settings; var z = _m.Seismic;
        Section(p, "Résumé de la configuration");
        var lines = new List<string>
        {
            $"Préréglage : {s.Preset}",
            $"Norme béton armé : {_m.RcCodeId}   -   Norme charpente métallique : {_m.SteelCodeId}",
            $"fc28 = {_m.Fc28:0.#} MPa ; fe = {_m.Fe:0.#} MPa ; fy = {_m.SteelFy:0.#} MPa ; sol = {_m.SigmaSolKPa:0.#} kPa",
            z.Enabled ? $"Séisme : {z.Norm}, direction {z.Direction}" + (z.Norm == "RPA99" ? $", zone {z.Zone}, groupe {z.Group}, site {z.Site}, R = {z.R:0.##}" : $", ag/g = {z.AgOverG:0.##}, sol {z.Ground}, q = {z.BehaviorQ:0.##}") : "Séisme : désactivé",
            $"Enrobages nominaux (cm) : poutres {s.CoverNomBeamCm:0.#} ; poteaux {s.CoverNomColumnCm:0.#} ; dalles {s.CoverNomSlabCm:0.#} ; semelles {s.CoverNomFootingCm:0.#}",
            "Diamètres poutres : " + DesignSettings.IntsToText(s.BeamDias()) + "   -   poteaux : " + DesignSettings.IntsToText(s.ColumnDias()),
            "Diamètres cadres : " + DesignSettings.IntsToText(s.StirrupDias()) + "   -   dalles : " + DesignSettings.IntsToText(s.SlabDias()),
            $"Recouvrement {s.LapFactor:0.#} φ ; ancrage {s.AnchorageFactor:0.#} φ ; crochets {s.HookFactor:0.#} φ ; chapeaux de poutre {s.BeamTopBarFactor:0.##} L",
            $"Zones critiques : poutres {s.BeamCriticalZoneFactor:0.##} h ; poteaux max(h, he/6, {s.ColumnCriticalZoneMinCm:0} cm)",
            $"Pourcentages : poteaux {s.ColumnMinPercent:0.##} à {s.ColumnMaxPercent:0.##} % ; poutres {s.BeamMinPercent:0.##} à {s.BeamMaxPercent:0.##} % (0 = selon la norme)",
        };
        foreach (var l in lines) p.Children.Add(new TextBlock { Text = "•  " + l, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 2) });
        var btn = new Button { Content = "Actualiser le contrôle", Padding = new Thickness(14, 6, 14, 6), Margin = new Thickness(0, 16, 0, 0), HorizontalAlignment = HorizontalAlignment.Left };
        btn.Click += (sd, ev) => ShowStep(_defs.Count - 1);
        p.Children.Add(btn);
        Note(p, "Après « Appliquer et fermer », relancez le calcul (F5) puis régénérez les plans pour tenir compte de cette configuration.");
        return p;
    }
}
