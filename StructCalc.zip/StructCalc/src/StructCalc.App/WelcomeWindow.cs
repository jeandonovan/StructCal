using System.IO;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using Shapes = System.Windows.Shapes;

namespace StructCalc.UI;

internal enum WelcomeKind { None, Opened, Created, Underlay, Options }

/// <summary>Choix fait dans l'écran d'accueil, appliqué ensuite par la fenêtre principale.</summary>
internal sealed class WelcomeResult
{
    public WelcomeKind Kind;
    public string Path = "";
    public StructModel? Model;
    public NewProjectOptions? Options;
}

/// <summary>Ce que l'écran d'accueil demande à la fenêtre principale.</summary>
internal sealed class WelcomeHost
{
    public RecentProjects Recents = null!;
    /// <summary>Écrit un message dans le journal / la liste des messages de la fenêtre principale.</summary>
    public Action<string> Report = _ => { };
    /// <summary>Signale un fichier non ouvert : message structuré dans la liste des messages (et ligne du journal).</summary>
    public Action<string, string> ReportError = (_, _) => { };
    /// <summary>Met en place le choix (créer, ouvrir, importer) pendant que l'accueil s'estompe : vrai fondu enchaîné vers l'espace de travail.</summary>
    public Action<WelcomeResult> Apply = _ => { };
    /// <summary>Fichier du projet actuellement ouvert (null si aucun) : il ne peut être ni renommé ni supprimé depuis l'accueil.</summary>
    public Func<string?> CurrentFile = () => null;
}

/// <summary>Préférence « afficher l'accueil au démarrage » (fichier marqueur dans le dossier de données).</summary>
internal static class WelcomePrefs
{
    private static string Marker => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "welcome.off");

    public static bool ShowAtStartup
    {
        get { try { return !File.Exists(Marker); } catch { return true; } }
        set
        {
            try
            {
                if (value) { if (File.Exists(Marker)) File.Delete(Marker); }
                else { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Marker)!); File.WriteAllText(Marker, "off"); }
            }
            catch { }
        }
    }
}

/// <summary>Écran d'accueil : navigation à gauche, actions et projets récents au centre.</summary>
internal sealed class WelcomeWindow : Window
{
    private readonly WelcomeHost _host;
    private Pal _p = Pal.Get(false);
    private string _page = "home";
    private readonly ContentControl _pageHost = new();
    private Grid _overlay = new();
    private StackPanel _toasts = new();
    private List<RecentEntry> _recents = new();
    private bool _busy, _closing, _built;
    private int _ovVer;
    private Action? _onEsc;
    private readonly Dictionary<string, NavParts> _nav = new();

    public WelcomeResult? Result { get; private set; }

    private sealed class NavParts { public Border Item = null!, Hover = null!, Sel = null!, Bar = null!; public FrameworkElement Icon = null!; public TextBlock Text = null!; }

    public WelcomeWindow(WelcomeHost host)
    {
        _host = host;
        Title = "StructCalc - Accueil";
        WindowStyle = WindowStyle.None; AllowsTransparency = true; ResizeMode = ResizeMode.CanResize; ShowInTaskbar = false;
        MinWidth = 980; MinHeight = 640; Width = 1180; Height = 720;
        WindowStartupLocation = WindowStartupLocation.Manual;
        FontFamily = Wk.Font; UseLayoutRounding = true; SnapsToDevicePixels = true;
        TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
        WindowChrome.SetWindowChrome(this, new WindowChrome
        {
            CaptionHeight = 0, ResizeBorderThickness = new Thickness(5), GlassFrameThickness = new Thickness(0), CornerRadius = new CornerRadius(0), UseAeroCaptionButtons = false
        });
        Background = Brushes.Transparent;
        Loaded += (s, ev) => { if (!_built) { _built = true; Build(); Wk.Appear((UIElement)Content, 0, 240, 0); } };
        PreviewKeyDown += OnKey;
        Closing += (s, ev) => { if (_busy && !_closing) ev.Cancel = true; };
    }

    /// <summary>Couvre exactement la fenêtre principale : l'accueil se présente comme la page d'ouverture du logiciel.</summary>
    protected override void OnSourceInitialized(EventArgs ev)
    {
        base.OnSourceInitialized(ev);
        if (Owner == null) return;
        if (Owner.WindowState == WindowState.Maximized)
        {
            var wa = SystemParameters.WorkArea;
            Left = wa.Left; Top = wa.Top; Width = wa.Width; Height = wa.Height;
        }
        else
        {
            Left = Owner.Left; Top = Owner.Top; Width = Math.Max(MinWidth, Owner.ActualWidth); Height = Math.Max(MinHeight, Owner.ActualHeight);
        }
    }

    private void OnKey(object sender, KeyEventArgs ev)
    {
        if (ev.Key != Key.Escape) return;
        ev.Handled = true;
        if (_overlay.Visibility == Visibility.Visible)
        {
            if (_busy) return;
            if (_onEsc != null) _onEsc(); else HideCard();
        }
        else if (!_busy) CloseWith(null);
    }

    // ------------------------------------------------------------------ construction
    private void Build()
    {
        _p = Pal.Get(Theme.Dark);
        _recents = _host.Recents.Load();
        _nav.Clear();
        var root = new Border { Background = _p.BBg, BorderBrush = _p.BLine, BorderThickness = new Thickness(1) };
        var layers = new Grid();
        var main = new Grid();
        main.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(276) });
        main.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var side = BuildSidebar();
        Grid.SetColumn(side, 0); main.Children.Add(side);

        var right = new Grid();
        right.RowDefinitions.Add(new RowDefinition { Height = new GridLength(40) });
        right.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        Grid.SetColumn(right, 1);
        var strip = new Grid { Background = _p.BTransparent };
        strip.MouseLeftButtonDown += Drag;
        var close = Wk.Btn(_p, BtnKind.Quiet, null, "x", (s, ev) => { if (!_busy) CloseWith(null); }, 32, 14, 9);
        close.HorizontalAlignment = HorizontalAlignment.Right; close.VerticalAlignment = VerticalAlignment.Center; close.Margin = new Thickness(0, 0, 10, 0);
        close.ToolTip = "Fermer l'accueil (Échap)";
        strip.Children.Add(close);
        right.Children.Add(strip);
        var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = _pageHost, Focusable = false };
        sv.Resources.Add(typeof(ScrollBar), Wk.ScrollBarStyle(_p));
        Grid.SetRow(sv, 1); right.Children.Add(sv);
        _toasts = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 0, 0, 26), IsHitTestVisible = false };
        Grid.SetRow(_toasts, 1); right.Children.Add(_toasts);
        main.Children.Add(right);

        _overlay = new Grid { Visibility = Visibility.Collapsed, Background = _p.BScrim };
        _overlay.MouseLeftButtonDown += (s, ev) => { if (ReferenceEquals(ev.OriginalSource, _overlay) && !_busy) { if (_onEsc != null) _onEsc(); else HideCard(); } };
        layers.Children.Add(main); layers.Children.Add(_overlay);
        root.Child = layers;
        Content = root;
        ShowPage(_page, false);
    }

    private void Drag(object sender, MouseButtonEventArgs ev)
    {
        if (ev.ClickCount == 1 && ev.LeftButton == MouseButtonState.Pressed) { try { DragMove(); } catch { } }
    }

    // ------------------------------------------------------------------ barre latérale
    private FrameworkElement BuildSidebar()
    {
        var side = new Border { Background = _p.BSide, BorderBrush = _p.BLine, BorderThickness = new Thickness(0, 0, 1, 0) };
        var g = new Grid();
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(40) });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var strip = new Border { Background = _p.BTransparent };
        strip.MouseLeftButtonDown += Drag;
        g.Children.Add(strip);

        var brand = new StackPanel { Margin = new Thickness(26, 8, 20, 28) };
        var logo = new Border
        {
            Width = 46, Height = 46, CornerRadius = new CornerRadius(13), Background = _p.BAccent, HorizontalAlignment = HorizontalAlignment.Left,
            Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = _p.Accent, BlurRadius = 18, ShadowDepth = 0, Opacity = _p.Dark ? 0.28 : 0.3 }
        };
        var logoIcon = Wk.Icon("frame", 26, _p.BOnAccent, 1.9);
        logoIcon.HorizontalAlignment = HorizontalAlignment.Center; logoIcon.VerticalAlignment = VerticalAlignment.Center;
        logo.Child = logoIcon;
        brand.Children.Add(logo);
        var name = Wk.Txt("StructCalc", 21, _p.BText, FontWeights.SemiBold); name.Margin = new Thickness(0, 16, 0, 0);
        brand.Children.Add(name);
        brand.Children.Add(Wk.Txt("Version " + AppInfo.Version, 12.5, _p.BMuted));
        var dev = Wk.Txt("Développé par jeandonovan33", 12, _p.BFaint); dev.Margin = new Thickness(0, 3, 0, 0);
        brand.Children.Add(dev);
        Grid.SetRow(brand, 1); g.Children.Add(brand);

        var nav = new StackPanel { Margin = new Thickness(14, 0, 14, 0) };
        nav.Children.Add(NavItem("home", "Accueil", "home"));
        nav.Children.Add(NavItem("recent", "Projets récents", "clock"));
        nav.Children.Add(NavItem("models", "Modèles", "layers"));
        nav.Children.Add(NavItem("settings", "Paramètres", "sliders"));
        nav.Children.Add(NavItem("help", "Aide", "help"));
        Grid.SetRow(nav, 2); g.Children.Add(nav);

        var bottom = new StackPanel { Margin = new Thickness(20, 0, 20, 22) };
        var lbl = Wk.Txt("Thème", 11.5, _p.BFaint, FontWeights.Medium); lbl.Margin = new Thickness(2, 0, 0, 7);
        bottom.Children.Add(lbl);
        bottom.Children.Add(ThemeSwitch());
        Grid.SetRow(bottom, 3); g.Children.Add(bottom);
        side.Child = g;
        return side;
    }

    private Border NavItem(string key, string label, string icon)
    {
        var hover = new Border { Background = _p.BHover, CornerRadius = new CornerRadius(10), Opacity = 0, IsHitTestVisible = false };
        var sel = new Border { Background = _p.BSurface, CornerRadius = new CornerRadius(10), Opacity = 0, IsHitTestVisible = false };
        var bar = new Border
        {
            Width = 3, Height = 18, CornerRadius = new CornerRadius(2), Background = _p.BAccent, HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 0, 0), Opacity = 0, IsHitTestVisible = false
        };
        var ic = Wk.Icon(icon, 19, _p.BMuted);
        var tx = Wk.Txt(label, 14, _p.BMuted, FontWeights.Medium); tx.Margin = new Thickness(13, 0, 0, 0); tx.VerticalAlignment = VerticalAlignment.Center;
        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(16, 0, 12, 0), VerticalAlignment = VerticalAlignment.Center, IsHitTestVisible = false };
        row.Children.Add(ic); row.Children.Add(tx);
        var g = new Grid { Height = 42, Background = _p.BTransparent };
        g.Children.Add(hover); g.Children.Add(sel); g.Children.Add(bar); g.Children.Add(row);
        var item = new Border { Child = g, Margin = new Thickness(0, 0, 0, 4), Cursor = Cursors.Hand, Focusable = true, FocusVisualStyle = null };
        item.MouseEnter += (s, ev) => { if (_page != key) Wk.FadeTo(hover, 1, 150); };
        item.MouseLeave += (s, ev) => Wk.FadeTo(hover, 0, 150);
        item.MouseLeftButtonUp += (s, ev) => { if (!_busy) ShowPage(key); };
        item.KeyDown += (s, ev) => { if (ev.Key is Key.Enter or Key.Space) { if (!_busy) ShowPage(key); ev.Handled = true; } };
        _nav[key] = new NavParts { Item = item, Hover = hover, Sel = sel, Bar = bar, Icon = ic, Text = tx };
        return item;
    }

    private void UpdateNav()
    {
        foreach (var (key, n) in _nav)
        {
            bool on = key == _page;
            Wk.FadeTo(n.Sel, on ? 1 : 0, 150); Wk.FadeTo(n.Bar, on ? 1 : 0, 150); Wk.FadeTo(n.Hover, 0, 100);
            Wk.Tint(n.Icon, on ? _p.BAccent : _p.BMuted);
            n.Text.Foreground = on ? _p.BText : _p.BMuted;
        }
    }

    private FrameworkElement ThemeSwitch()
    {
        var frame = new Border { Background = _p.BSurface, BorderBrush = _p.BLine, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(11), Padding = new Thickness(3) };
        var g = new Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition()); g.ColumnDefinitions.Add(new ColumnDefinition());
        void Seg(int col, string text, string icon, bool dark)
        {
            bool on = Theme.Dark == dark;
            var content = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            var ic = Wk.Icon(icon, 16, on ? _p.BAccent : _p.BMuted);
            var t = Wk.Txt(text, 13, on ? _p.BAccent : _p.BMuted, FontWeights.Medium); t.Margin = new Thickness(7, 0, 0, 0);
            content.Children.Add(ic); content.Children.Add(t);
            var b = new Border { Height = 34, CornerRadius = new CornerRadius(8), Background = on ? _p.BAccentSoft : _p.BTransparent, Child = content, Cursor = Cursors.Hand };
            b.MouseLeftButtonUp += (s, ev) => SetTheme(dark);
            Grid.SetColumn(b, col); g.Children.Add(b);
        }
        Seg(0, "Sombre", "moon", true);
        Seg(1, "Clair", "sun", false);
        frame.Child = g;
        return frame;
    }

    private void SetTheme(bool dark)
    {
        if (Theme.Dark == dark || _busy) return;
        Theme.Set(dark);
        Build();
        Wk.Appear((UIElement)Content, 0, 200, 0);
    }

    // ------------------------------------------------------------------ pages
    private void ShowPage(string key, bool animate = true)
    {
        _page = key;
        UpdateNav();
        FrameworkElement page = key switch
        {
            "recent" => RecentPage(),
            "models" => ModelsPage(),
            "settings" => SettingsPage(),
            "help" => HelpPage(),
            _ => HomePage()
        };
        _pageHost.Content = page;
        if (animate && key != "home") Wk.Appear(page, 0, 190, 8);
    }

    private void RefreshPage() { _recents = _host.Recents.Load(); ShowPage(_page, false); }

    private StackPanel PageShell()
    {
        return new StackPanel { Margin = new Thickness(56, 20, 56, 52), MaxWidth = 1060, HorizontalAlignment = HorizontalAlignment.Left };
    }

    private FrameworkElement SectionTitle(string title, string? sub = null)
    {
        var st = new StackPanel { Margin = new Thickness(0, 0, 0, 22) };
        st.Children.Add(Wk.Txt(title, 28, _p.BText, FontWeights.SemiBold));
        if (sub != null) { var t = Wk.Txt(sub, 14.5, _p.BMuted, null, false, true); t.Margin = new Thickness(0, 6, 0, 0); st.Children.Add(t); }
        return st;
    }

    // ---- Accueil
    private FrameworkElement HomePage()
    {
        var sp = PageShell();
        sp.Margin = new Thickness(56, 28, 56, 52);
        var title = Wk.Txt("StructCalc", 46, _p.BText, FontWeights.SemiBold);
        var sub = Wk.Txt("Modélisation, calcul et dimensionnement de structures.", 16.5, _p.BMuted); sub.Margin = new Thickness(0, 6, 0, 0);
        sp.Children.Add(title); sp.Children.Add(sub);
        Wk.Appear(title, 0, 240); Wk.Appear(sub, 50, 240);

        var actions = new WrapPanel { Margin = new Thickness(0, 34, 0, 0) };
        var bNew = Wk.Btn(_p, BtnKind.Primary, "Nouveau projet", "plus", (s, ev) => NewProject(), 56, 16, 14);
        bNew.MinWidth = 236; bNew.Margin = new Thickness(0, 0, 14, 12); bNew.ToolTip = "Créer un projet (nom, emplacement, unités, norme...)";
        var bOpen = Wk.Btn(_p, BtnKind.Secondary, "Ouvrir un projet", "folder", (s, ev) => _ = OpenDialogAsync(), 48, 14.5, 12);
        bOpen.Margin = new Thickness(0, 4, 12, 12);
        var bImp = Wk.Btn(_p, BtnKind.Secondary, "Importer un modèle", "import", (s, ev) => ShowImport(), 48, 14.5, 12);
        bImp.Margin = new Thickness(0, 4, 0, 12);
        actions.Children.Add(bNew); actions.Children.Add(bOpen); actions.Children.Add(bImp);
        sp.Children.Add(actions);
        Wk.Appear(actions, 110, 240);

        var head = new Grid { Margin = new Thickness(0, 40, 0, 16) };
        head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        head.Children.Add(Wk.Txt("Projets récents", 20, _p.BText, FontWeights.SemiBold));
        if (_recents.Count > 6)
        {
            var all = Wk.Txt("Voir tout (" + _recents.Count + ")", 13.5, _p.BAccent, FontWeights.Medium);
            all.Cursor = Cursors.Hand; all.VerticalAlignment = VerticalAlignment.Center;
            all.MouseLeftButtonUp += (s, ev) => ShowPage("recent");
            Grid.SetColumn(all, 1); head.Children.Add(all);
        }
        sp.Children.Add(head);
        Wk.Appear(head, 150, 240);

        if (_recents.Count == 0)
        {
            var empty = EmptyState();
            sp.Children.Add(empty);
            Wk.Appear(empty, 200, 260);
        }
        else
        {
            var wrap = new WrapPanel();
            int i = 0;
            foreach (var en in _recents.Take(6)) wrap.Children.Add(RecentCard(en, i++));
            sp.Children.Add(wrap);
        }
        return sp;
    }

    private FrameworkElement EmptyState()
    {
        var box = new Grid { MinHeight = 250 };
        var dash = new Shapes.Rectangle
        {
            RadiusX = 16, RadiusY = 16, Stroke = _p.BLine, StrokeThickness = 1.4, StrokeDashArray = new DoubleCollection { 4, 4 },
            Fill = _p.BCard, SnapsToDevicePixels = true
        };
        box.Children.Add(dash);
        var st = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(24, 32, 24, 32) };
        var circle = new Border { Width = 68, Height = 68, CornerRadius = new CornerRadius(34), Background = _p.BSurface, HorizontalAlignment = HorizontalAlignment.Center };
        var ic = Wk.Icon("folder", 30, _p.BFaint, 1.5); ic.HorizontalAlignment = HorizontalAlignment.Center; ic.VerticalAlignment = VerticalAlignment.Center;
        circle.Child = ic;
        st.Children.Add(circle);
        var t = Wk.Txt("Aucun projet récent", 18, _p.BText, FontWeights.SemiBold); t.Margin = new Thickness(0, 18, 0, 0); t.HorizontalAlignment = HorizontalAlignment.Center;
        st.Children.Add(t);
        var d = Wk.Txt("Les projets que vous créez ou ouvrez apparaîtront ici.", 13.5, _p.BMuted); d.Margin = new Thickness(0, 6, 0, 18); d.HorizontalAlignment = HorizontalAlignment.Center;
        st.Children.Add(d);
        var b = Wk.Btn(_p, BtnKind.Primary, "Créer votre premier projet", "plus", (s, ev) => NewProject(), 46, 14.5, 12);
        b.HorizontalAlignment = HorizontalAlignment.Center;
        st.Children.Add(b);
        box.Children.Add(st);
        return box;
    }

    // ---- Projets récents
    private FrameworkElement RecentPage()
    {
        var sp = PageShell();
        sp.Children.Add(SectionTitle("Projets récents", _recents.Count == 0 ? null : $"{_recents.Count} projet{(_recents.Count > 1 ? "s" : "")}, du plus récent au plus ancien."));
        if (_recents.Count == 0) { sp.Children.Add(EmptyState()); return sp; }
        var wrap = new WrapPanel();
        int i = 0;
        foreach (var en in _recents) wrap.Children.Add(RecentCard(en, i++));
        sp.Children.Add(wrap);
        return sp;
    }

    private Border RecentCard(RecentEntry en, int idx)
    {
        var card = Wk.Card(_p, 14);
        card.Width = 292; card.Margin = new Thickness(0, 0, 18, 18); card.Cursor = Cursors.Hand;
        Wk.Lift(card, _p);
        var st = new StackPanel();

        var thumbBox = new Border { Height = 120, Background = _p.BSurface, CornerRadius = new CornerRadius(13, 13, 0, 0) };
        var tg = new Grid();
        var thumb = Wk.Thumbnail(en.Thumb, _p, 290, 120, 20);
        if (thumb != null) tg.Children.Add(thumb);
        else
        {
            var ph = Wk.Icon("frame", 40, _p.BFaint, 1.2); ph.HorizontalAlignment = HorizontalAlignment.Center; ph.VerticalAlignment = VerticalAlignment.Center;
            tg.Children.Add(ph);
        }
        if (en.SystemType != "")
        {
            var tag = new Border { Background = _p.BCard, CornerRadius = new CornerRadius(10), Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(12), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
            tag.Child = Wk.Txt(en.SystemType, 11.5, _p.BAccent, FontWeights.Medium);
            tg.Children.Add(tag);
        }
        thumbBox.Child = tg;
        st.Children.Add(thumbBox);

        var info = new StackPanel { Margin = new Thickness(16, 14, 16, 14) };
        info.Children.Add(Wk.Txt(en.Name, 15.5, _p.BText, FontWeights.SemiBold, true));
        string meta = (en.ProjectType != "" ? en.ProjectType + "  ·  " : "") + (en.Elements == 0 ? "aucun élément" : en.Elements + (en.Elements > 1 ? " éléments" : " élément"));
        var m = Wk.Txt(meta, 12.5, _p.BMuted, null, true); m.Margin = new Thickness(0, 3, 0, 10);
        info.Children.Add(m);
        info.Children.Add(Wk.Txt("Ouvert " + Wk.FriendlyDate(en.LastOpened), 12, _p.BMuted, null, true));
        var mod = Wk.Txt("Modifié " + Wk.FriendlyDate(en.LastModified), 12, _p.BMuted, null, true); mod.Margin = new Thickness(0, 2, 0, 0);
        info.Children.Add(mod);
        var path = Wk.Txt(en.Path, 11.5, _p.BFaint, null, true); path.Margin = new Thickness(0, 9, 0, 14); path.ToolTip = en.Path;
        info.Children.Add(path);

        var foot = new Grid();
        foot.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        foot.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var open = Wk.Btn(_p, BtnKind.Ghost, "Ouvrir", "folder", (s, ev) => _ = OpenPathAsync(en.Path), 34, 13, 9);
        open.Margin = new Thickness(0, 0, 8, 0);
        var more = Wk.Btn(_p, BtnKind.Quiet, null, "dots", (s, ev) => { }, 34, 14, 9);
        var menu = BuildMenu(en);
        more.Click += (s, ev) => { menu.PlacementTarget = more; menu.Placement = PlacementMode.Bottom; menu.IsOpen = true; };
        more.ToolTip = "Plus d'actions";
        Grid.SetColumn(more, 1);
        foot.Children.Add(open); foot.Children.Add(more);
        info.Children.Add(foot);
        st.Children.Add(info);
        card.Child = st;
        card.ContextMenu = menu;
        card.MouseLeftButtonUp += (s, ev) => _ = OpenPathAsync(en.Path);
        Wk.Appear(card, 190 + idx * 55, 240, 14);
        return card;
    }

    private ContextMenu BuildMenu(RecentEntry en)
    {
        var m = Wk.Menu(_p);
        m.Items.Add(Wk.MenuEntry(_p, "Ouvrir", () => _ = OpenPathAsync(en.Path)));
        m.Items.Add(Wk.MenuEntry(_p, "Ouvrir l'emplacement du fichier", () => ShowInFolder(en.Path)));
        m.Items.Add(Wk.MenuSeparator(_p));
        m.Items.Add(Wk.MenuEntry(_p, "Renommer", () => _ = RenameAsync(en)));
        m.Items.Add(Wk.MenuEntry(_p, "Dupliquer", () => Duplicate(en)));
        m.Items.Add(Wk.MenuSeparator(_p));
        m.Items.Add(Wk.MenuEntry(_p, "Supprimer de la liste des récents", () => { _host.Recents.Remove(en.Path); RefreshPage(); Toast("Retiré de la liste (le fichier est conservé)."); }));
        m.Items.Add(Wk.MenuEntry(_p, "Supprimer définitivement…", () => _ = DeleteAsync(en), true));
        return m;
    }

    private static void ShowInFolder(string path)
    {
        try { Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + path + "\"") { UseShellExecute = true }); }
        catch { }
    }

    private bool IsCurrent(string path)
    {
        var cur = _host.CurrentFile();
        return cur != null && string.Equals(System.IO.Path.GetFullPath(cur), System.IO.Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase);
    }

    private async Task RenameAsync(RecentEntry en)
    {
        if (IsCurrent(en.Path)) { await MessageAsync("Projet en cours d'édition", "Ce projet est actuellement ouvert dans l'espace de travail. Ouvrez-en un autre avant de le renommer.", "info"); return; }
        var r = await AskAsync("Renommer le projet", "Le nom du fichier sera modifié, dans le même dossier.", "edit", false, BtnKind.Primary, "Renommer", System.IO.Path.GetFileNameWithoutExtension(en.Path));
        if (!r.Ok || string.IsNullOrWhiteSpace(r.Text)) return;
        try { _host.Recents.RenameFile(en.Path, r.Text); RefreshPage(); Toast("Projet renommé."); }
        catch (Exception ex) { await MessageAsync("Renommage impossible", ex.Message, "alert", true); }
    }

    private void Duplicate(RecentEntry en)
    {
        try { string dst = _host.Recents.Duplicate(en.Path); RefreshPage(); Toast("Copie créée : " + System.IO.Path.GetFileName(dst)); }
        catch (Exception ex) { _ = MessageAsync("Duplication impossible", ex.Message, "alert", true); }
    }

    private async Task DeleteAsync(RecentEntry en)
    {
        if (IsCurrent(en.Path)) { await MessageAsync("Projet en cours d'édition", "Ce projet est actuellement ouvert dans l'espace de travail. Ouvrez-en un autre avant de le supprimer.", "info"); return; }
        var r = await AskAsync("Supprimer définitivement ?", $"Le fichier « {System.IO.Path.GetFileName(en.Path)} » sera supprimé de votre disque. Cette action est irréversible.", "trash", true, BtnKind.Danger, "Supprimer");
        if (!r.Ok) return;
        try { _host.Recents.DeleteFile(en.Path); RefreshPage(); Toast("Projet supprimé."); }
        catch (Exception ex) { await MessageAsync("Suppression impossible", ex.Message, "alert", true); }
    }

    // ---- Modèles
    private FrameworkElement ModelsPage()
    {
        var sp = PageShell();
        sp.Children.Add(SectionTitle("Modèles", "Démarrez d'une structure type : le projet est créé, enregistré et prêt à être modifié."));
        var wrap = new WrapPanel();
        int i = 0;
        foreach (var t in ProjectTemplates.All)
        {
            var tpl = t;
            var card = Wk.Card(_p, 14); card.Width = 292; card.Margin = new Thickness(0, 0, 18, 18); card.Cursor = Cursors.Hand;
            Wk.Lift(card, _p);
            var st = new StackPanel { Margin = new Thickness(20) };
            var badge = new Border { Width = 44, Height = 44, CornerRadius = new CornerRadius(12), Background = _p.BAccentSoft, HorizontalAlignment = HorizontalAlignment.Left };
            var ic = Wk.Icon(tpl.System == "Acier" ? "frame" : tpl.Name.Contains("vierge") ? "file" : "building", 22, _p.BAccent);
            ic.HorizontalAlignment = HorizontalAlignment.Center; ic.VerticalAlignment = VerticalAlignment.Center;
            badge.Child = ic;
            st.Children.Add(badge);
            var n = Wk.Txt(tpl.Name, 16, _p.BText, FontWeights.SemiBold, true); n.Margin = new Thickness(0, 16, 0, 0);
            st.Children.Add(n);
            var sys = Wk.Txt(tpl.System, 12, _p.BAccent, FontWeights.Medium); sys.Margin = new Thickness(0, 3, 0, 0);
            st.Children.Add(sys);
            var d = Wk.Txt(tpl.Description, 13, _p.BMuted, null, false, true); d.Margin = new Thickness(0, 8, 0, 18); d.MinHeight = 54;
            st.Children.Add(d);
            var use = Wk.Btn(_p, BtnKind.Ghost, "Utiliser ce modèle", "plus", (s, ev) => NewProject(tpl.Name), 36, 13, 9);
            st.Children.Add(use);
            card.Child = st;
            card.MouseLeftButtonUp += (s, ev) => NewProject(tpl.Name);
            Wk.Appear(card, i++ * 55, 230, 12);
            wrap.Children.Add(card);
        }
        sp.Children.Add(wrap);
        return sp;
    }

    // ---- Paramètres
    private int _pd;

    private Border Section(string title, string? sub, FrameworkElement body)
    {
        var card = Wk.Card(_p, 14);
        card.Margin = new Thickness(0, 0, 0, 16);
        var st = new StackPanel { Margin = new Thickness(24, 20, 24, 22) };
        st.Children.Add(Wk.Txt(title, 16, _p.BText, FontWeights.SemiBold));
        if (sub != null) { var t = Wk.Txt(sub, 13, _p.BMuted, null, false, true); t.Margin = new Thickness(0, 4, 0, 0); st.Children.Add(t); }
        body.Margin = new Thickness(0, 16, 0, 0);
        st.Children.Add(body);
        card.Child = st;
        Wk.Appear(card, _pd++ * 60, 220, 10);
        return card;
    }

    private FrameworkElement SettingsPage()
    {
        var sp = PageShell();
        sp.Children.Add(SectionTitle("Paramètres", "Apparence et démarrage de StructCalc."));
        _pd = 0;
        var theme = new Chips(_p, new[] { ("dark", "Sombre"), ("light", "Clair") }, Theme.Dark ? "dark" : "light");
        theme.Changed += v => SetTheme(v == "dark");
        sp.Children.Add(Section("Thème", "Le thème sombre est celui par défaut. Le choix est conservé pour tout le logiciel.", theme));

        var startup = new Chips(_p, new[] { ("yes", "Afficher l'accueil"), ("no", "Ouvrir directement l'espace de travail") }, WelcomePrefs.ShowAtStartup ? "yes" : "no");
        startup.Changed += v => { WelcomePrefs.ShowAtStartup = v == "yes"; Toast("Préférence enregistrée."); };
        sp.Children.Add(Section("Au lancement", "Ce que StructCalc affiche à son ouverture. Le bouton « Nouveau » rouvre toujours l'accueil.", startup));

        var folder = new StackPanel();
        var fp = Wk.Txt(ProjectFactory.DefaultFolder(), 13.5, _p.BText, null, true); fp.ToolTip = ProjectFactory.DefaultFolder();
        folder.Children.Add(fp);
        var fb = Wk.Btn(_p, BtnKind.Secondary, "Ouvrir le dossier", "folder", (s, ev) =>
        {
            try { Directory.CreateDirectory(ProjectFactory.DefaultFolder()); Process.Start(new ProcessStartInfo("explorer.exe", "\"" + ProjectFactory.DefaultFolder() + "\"") { UseShellExecute = true }); } catch { }
        }, 38, 13, 10);
        fb.Margin = new Thickness(0, 12, 0, 0); fb.HorizontalAlignment = HorizontalAlignment.Left;
        folder.Children.Add(fb);
        sp.Children.Add(Section("Dossier des projets", "Emplacement proposé par défaut pour les nouveaux projets.", folder));

        var other = new WrapPanel();
        var opt = Wk.Btn(_p, BtnKind.Secondary, "Options du logiciel…", "sliders", (s, ev) => CloseWith(new WelcomeResult { Kind = WelcomeKind.Options }), 40, 13.5, 10);
        opt.Margin = new Thickness(0, 0, 12, 0);
        var clear = Wk.Btn(_p, BtnKind.Danger, "Vider la liste des projets récents", "trash", (s, ev) => _ = ClearRecentAsync(), 40, 13.5, 10);
        other.Children.Add(opt); other.Children.Add(clear);
        sp.Children.Add(Section("Autres réglages", "Les options de calcul, d'affichage et de rapports sont dans les options du logiciel.", other));
        return sp;
    }

    private async Task ClearRecentAsync()
    {
        if (_recents.Count == 0) { Toast("La liste est déjà vide."); return; }
        var r = await AskAsync("Vider la liste ?", "Les projets seront retirés de la liste des récents. Les fichiers ne sont pas supprimés.", "trash", true, BtnKind.Danger, "Vider la liste");
        if (!r.Ok) return;
        foreach (var en in _host.Recents.Load()) _host.Recents.Remove(en.Path);
        RefreshPage(); Toast("Liste des récents vidée.");
    }

    // ---- Aide
    private FrameworkElement HelpPage()
    {
        var sp = PageShell();
        _pd = 0;
        sp.Children.Add(SectionTitle("Aide", "Pour bien démarrer, et comment joindre l'auteur."));

        var steps = new StackPanel();
        void Step(string n, string text)
        {
            var row = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var b = new Border { Width = 24, Height = 24, CornerRadius = new CornerRadius(12), Background = _p.BAccentSoft, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
            var num = Wk.Txt(n, 12.5, _p.BAccent, FontWeights.SemiBold); num.HorizontalAlignment = HorizontalAlignment.Center; num.VerticalAlignment = VerticalAlignment.Center;
            b.Child = num;
            var t = Wk.Txt(text, 13.5, _p.BText, null, false, true); t.VerticalAlignment = VerticalAlignment.Center; t.Margin = new Thickness(0, 2, 0, 0);
            Grid.SetColumn(t, 1);
            row.Children.Add(b); row.Children.Add(t);
            steps.Children.Add(row);
        }
        Step("1", "Créez un projet (nom, unités, système structurel, norme) ou ouvrez un fichier .stcx.");
        Step("2", "Dessinez poteaux, poutres, dalles et semelles, ou importez la structure depuis Revit avec le complément StructCalc.");
        Step("3", "Définissez les charges, lancez le calcul (F5), puis consultez le dimensionnement, les messages et la note de calcul.");
        Step("4", "Les résultats doivent être vérifiés par l'ingénieur responsable avant exécution.");
        sp.Children.Add(Section("Bien démarrer", null, steps));

        var about = new StackPanel();
        about.Children.Add(Wk.Txt("StructCalc " + AppInfo.Version + "  ·  " + AppInfo.Copyright, 13.5, _p.BText));
        var dev = Wk.Txt("Développé par jeandonovan33  ·  " + AppInfo.Author, 13, _p.BMuted); dev.Margin = new Thickness(0, 4, 0, 0);
        about.Children.Add(dev);
        string lic = "";
        try { lic = StructCalc.Core.Licensing.LicenseManager.Current.Message; } catch { }
        if (lic != "") { var l = Wk.Txt("Licence : " + lic, 13, _p.BMuted, null, false, true); l.Margin = new Thickness(0, 4, 0, 0); about.Children.Add(l); }
        sp.Children.Add(Section("À propos", "Dimensionnement béton armé (BAEL 91, Eurocode 2) et charpente métallique (CM66).", about));

        var contact = new WrapPanel();
        var mail = Wk.Btn(_p, BtnKind.Secondary, "Écrire à l'auteur", "mail", (s, ev) => OpenUrl("mailto:" + AppInfo.Email), 40, 13.5, 10);
        mail.Margin = new Thickness(0, 0, 12, 0);
        var wa = Wk.Btn(_p, BtnKind.Secondary, "WhatsApp", "mail", (s, ev) => OpenUrl("https://wa.me/" + AppInfo.WhatsAppNumber), 40, 13.5, 10);
        contact.Children.Add(mail); contact.Children.Add(wa);
        var body = new StackPanel();
        body.Children.Add(contact);
        var ph = Wk.Txt(AppInfo.Email + "  ·  " + AppInfo.Phones, 12.5, _p.BFaint, null, false, true); ph.Margin = new Thickness(0, 12, 0, 0);
        body.Children.Add(ph);
        sp.Children.Add(Section("Contact et assistance", "Une question, une anomalie, une idée d'amélioration ?", body));
        return sp;
    }

    private static void OpenUrl(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch { }
    }

    // ------------------------------------------------------------------ superposition (boîtes de dialogue, chargement)
    private void ShowCard(FrameworkElement card)
    {
        _ovVer++;
        _onEsc = null;
        card.HorizontalAlignment = HorizontalAlignment.Center; card.VerticalAlignment = VerticalAlignment.Center; card.Margin = new Thickness(24);
        _overlay.Children.Clear(); _overlay.Children.Add(card);
        _overlay.Visibility = Visibility.Visible;
        Wk.Appear(_overlay, 0, 150, 0);
        Wk.Appear(card, 0, 210, 12);
    }

    private void HideCard()
    {
        if (_overlay.Visibility != Visibility.Visible) return;
        int ver = ++_ovVer;
        _onEsc = null;
        Wk.FadeTo(_overlay, 0, 130, () => { if (ver == _ovVer) { _overlay.Visibility = Visibility.Collapsed; _overlay.Children.Clear(); } });
    }

    private Task<(bool Ok, string Text)> AskAsync(string title, string message, string icon, bool danger, BtnKind okKind, string okText, string? input = null, bool showCancel = true)
    {
        var tcs = new TaskCompletionSource<(bool Ok, string Text)>();
        TextBox? tb = null;
        var card = Wk.Card(_p, 16); card.Width = 468;
        var st = new StackPanel { Margin = new Thickness(28, 26, 28, 24) };
        var head = new StackPanel { Orientation = Orientation.Horizontal };
        var badge = new Border { Width = 42, Height = 42, CornerRadius = new CornerRadius(12), Background = danger ? _p.BErrSoft : _p.BAccentSoft };
        var ic = Wk.Icon(icon, 21, danger ? _p.BErr : _p.BAccent); ic.HorizontalAlignment = HorizontalAlignment.Center; ic.VerticalAlignment = VerticalAlignment.Center;
        badge.Child = ic;
        head.Children.Add(badge);
        var tt = Wk.Txt(title, 18, _p.BText, FontWeights.SemiBold, true); tt.VerticalAlignment = VerticalAlignment.Center; tt.Margin = new Thickness(14, 0, 0, 0);
        head.Children.Add(tt);
        st.Children.Add(head);
        var msg = Wk.Txt(message, 13.5, _p.BMuted, null, false, true); msg.Margin = new Thickness(0, 16, 0, 0);
        st.Children.Add(msg);
        if (input != null)
        {
            var field = Wk.Input(_p, input, out tb);
            field.Margin = new Thickness(0, 16, 0, 0);
            st.Children.Add(field);
        }
        void Done(bool accepted)
        {
            if (tcs.Task.IsCompleted) return;
            string text = tb?.Text ?? "";
            HideCard();
            tcs.TrySetResult((accepted, text));
        }
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 24, 0, 0) };
        if (showCancel)
        {
            var cancel = Wk.Btn(_p, BtnKind.Secondary, "Annuler", null, (s, ev) => Done(false), 40, 13.5, 10);
            cancel.Margin = new Thickness(0, 0, 10, 0);
            buttons.Children.Add(cancel);
        }
        var okBtn = Wk.Btn(_p, okKind, okText, null, (s, ev) => Done(true), 40, 13.5, 10);
        buttons.Children.Add(okBtn);
        st.Children.Add(buttons);
        card.Child = st;
        if (tb != null) tb.KeyDown += (s, ev) => { if (ev.Key == Key.Enter) { Done(true); ev.Handled = true; } };
        ShowCard(card);
        _onEsc = () => Done(false);
        Dispatcher.BeginInvoke(new Action(() => { if (tb != null) { tb.Focus(); tb.SelectAll(); } else okBtn.Focus(); }), System.Windows.Threading.DispatcherPriority.Loaded);
        return tcs.Task;
    }

    private Task MessageAsync(string title, string message, string icon, bool danger = false) =>
        AskAsync(title, message, icon, danger, BtnKind.Secondary, "Fermer", null, false);

    private async void Toast(string text)
    {
        var b = Wk.Card(_p, 12);
        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(16, 11, 18, 11) };
        var ic = Wk.Icon("check", 16, _p.BOk, 2.2); ic.VerticalAlignment = VerticalAlignment.Center; ic.Margin = new Thickness(0, 0, 10, 0);
        row.Children.Add(ic);
        var t = Wk.Txt(text, 13.5, _p.BText); t.VerticalAlignment = VerticalAlignment.Center;
        row.Children.Add(t);
        b.Child = row;
        b.Margin = new Thickness(0, 6, 0, 0);
        _toasts.Children.Add(b);
        Wk.Appear(b, 0, 200, 10);
        await Task.Delay(2600);
        Wk.FadeTo(b, 0, 220, () => _toasts.Children.Remove(b));
    }

    // ------------------------------------------------------------------ actions
    private void NewProject(string templateName = "")
    {
        if (_busy) return;
        var w = new NewProjectWindow(_p, templateName) { Owner = this };
        if (w.ShowDialog() != true || w.CreatedModel == null) return;
        Finish(new WelcomeResult { Kind = WelcomeKind.Created, Path = w.CreatedPath, Model = w.CreatedModel, Options = w.Options });
    }

    private async Task OpenDialogAsync()
    {
        if (_busy) return;
        var dlg = new OpenFileDialog { Filter = AppInfo.OpenFilter, DefaultExt = AppInfo.FileExt, Title = "Ouvrir un projet StructCalc", InitialDirectory = SafeDir(ProjectFactory.DefaultFolder()) };
        if (dlg.ShowDialog(this) != true) return;
        await TransferAsync("Ouverture du projet", dlg.FileName, WelcomeKind.Opened);
    }

    private static string SafeDir(string d) { try { return Directory.Exists(d) ? d : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); } catch { return ""; } }

    private async Task OpenPathAsync(string path)
    {
        if (_busy) return;
        if (!File.Exists(path))
        {
            _host.ReportError(System.IO.Path.GetFileName(path), "le fichier n'existe plus à cet emplacement.");
            _host.Recents.Remove(path); RefreshPage();
            await MessageAsync("Projet introuvable", "Le fichier n'existe plus à cet emplacement ; il a été retiré de la liste.", "alert", true);
            return;
        }
        await TransferAsync("Ouverture du projet", path, WelcomeKind.Opened);
    }

    private void ShowImport()
    {
        if (_busy) return;
        var card = Wk.Card(_p, 16); card.Width = 560;
        var st = new StackPanel { Margin = new Thickness(28, 26, 28, 24) };
        st.Children.Add(Wk.Txt("Importer un modèle", 20, _p.BText, FontWeights.SemiBold));
        var sub = Wk.Txt("Choisissez la source du modèle à importer.", 13.5, _p.BMuted); sub.Margin = new Thickness(0, 4, 0, 18);
        st.Children.Add(sub);

        Border Source(string icon, string title, string desc, Action act)
        {
            var b = new Border { Background = _p.BSurface, BorderBrush = _p.BLine, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12), Margin = new Thickness(0, 0, 0, 10), Cursor = Cursors.Hand, Focusable = true, FocusVisualStyle = null };
            var g = new Grid { Margin = new Thickness(16, 14, 16, 14) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(48) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var badge = new Border { Width = 38, Height = 38, CornerRadius = new CornerRadius(10), Background = _p.BAccentSoft, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center };
            var ic = Wk.Icon(icon, 19, _p.BAccent); ic.HorizontalAlignment = HorizontalAlignment.Center; ic.VerticalAlignment = VerticalAlignment.Center;
            badge.Child = ic;
            var tx = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            tx.Children.Add(Wk.Txt(title, 14.5, _p.BText, FontWeights.SemiBold));
            var dd = Wk.Txt(desc, 12.5, _p.BMuted, null, false, true); dd.Margin = new Thickness(0, 2, 0, 0);
            tx.Children.Add(dd);
            Grid.SetColumn(tx, 1);
            g.Children.Add(badge); g.Children.Add(tx);
            b.Child = g;
            b.MouseEnter += (s, ev) => b.BorderBrush = _p.BAccentLine;
            b.MouseLeave += (s, ev) => b.BorderBrush = _p.BLine;
            b.MouseLeftButtonUp += (s, ev) => act();
            b.KeyDown += (s, ev) => { if (ev.Key is Key.Enter or Key.Space) { act(); ev.Handled = true; } };
            return b;
        }

        st.Children.Add(Source("revit", "Depuis Revit 2025", "Ouvre le dernier modèle envoyé par le complément StructCalc (« Envoyer vers StructCalc » dans Revit).", () => _ = ImportRevitAsync()));
        st.Children.Add(Source("file", "Fichier de projet StructCalc", "Un projet .stcx ou .json créé par StructCalc.", () => _ = ImportFileAsync("Projet StructCalc (*.stcx;*.json)|*.stcx;*.json")));
        st.Children.Add(Source("layers", "IFC, modèle 3D ou plan", "Les plans DXF, DWG, PDF et images sont importés comme fond de plan. L'IFC et les modèles 3D ne sont pas encore pris en charge.", () => _ = ImportFileAsync(
            "Tous les formats|*.ifc;*.obj;*.stl;*.fbx;*.dxf;*.dwg;*.pdf;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|IFC (*.ifc)|*.ifc|Plans (DXF, DWG, PDF, images)|*.dxf;*.dwg;*.pdf;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|Tous les fichiers|*.*")));

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
        buttons.Children.Add(Wk.Btn(_p, BtnKind.Secondary, "Annuler", null, (s, ev) => HideCard(), 40, 13.5, 10));
        st.Children.Add(buttons);
        card.Child = st;
        ShowCard(card);
    }

    private async Task ImportRevitAsync()
    {
        if (!File.Exists(RevitLink.FromRevit))
        {
            _host.ReportError("Import depuis Revit", "aucun modèle reçu pour l'instant. Dans Revit : onglet Compléments > StructCalc > « Envoyer vers StructCalc ».");
            HideCard();
            await Task.Delay(160);
            await MessageAsync("Aucun modèle reçu de Revit", "Dans Revit 2025, ouvrez l'onglet Compléments > StructCalc et cliquez sur « Envoyer vers StructCalc », puis revenez ici.", "info");
            return;
        }
        await TransferAsync("Import depuis Revit", RevitLink.FromRevit, WelcomeKind.Opened);
    }

    private async Task ImportFileAsync(string filter)
    {
        var dlg = new OpenFileDialog { Filter = filter, Title = "Importer un modèle" };
        if (dlg.ShowDialog(this) != true) return;
        string ext = System.IO.Path.GetExtension(dlg.FileName).ToLowerInvariant();
        bool plan = Array.IndexOf(new[] { ".dxf", ".dwg", ".pdf", ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff" }, ext) >= 0;
        await TransferAsync("Import du fichier", dlg.FileName, plan ? WelcomeKind.Underlay : WelcomeKind.Opened);
    }

    /// <summary>Carte de chargement (nom, taille, barre de progression), lecture du fichier hors du fil d'interface, puis fermeture de l'accueil ; en cas d'erreur, message clair.</summary>
    private async Task TransferAsync(string title, string path, WelcomeKind kind)
    {
        if (_busy) return;
        _busy = true;
        string fname = System.IO.Path.GetFileName(path), sizeText = "";
        try { sizeText = ProjectFile.SizeText(new FileInfo(path).Length); } catch { }

        var card = Wk.Card(_p, 16); card.Width = 500;
        var st = new StackPanel { Margin = new Thickness(28, 26, 28, 26) };
        var head = new StackPanel { Orientation = Orientation.Horizontal };
        head.Children.Add(Wk.Spinner(_p.BAccent, 24));
        var tt = Wk.Txt(title, 18, _p.BText, FontWeights.SemiBold); tt.Margin = new Thickness(14, 0, 0, 0); tt.VerticalAlignment = VerticalAlignment.Center;
        head.Children.Add(tt);
        st.Children.Add(head);
        var file = new Border { Background = _p.BSurface, CornerRadius = new CornerRadius(10), Margin = new Thickness(0, 20, 0, 0), Padding = new Thickness(14, 11, 14, 11) };
        var fg = new Grid();
        fg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(32) });
        fg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var fic = Wk.Icon("file", 20, _p.BMuted); fic.HorizontalAlignment = HorizontalAlignment.Left; fic.VerticalAlignment = VerticalAlignment.Center;
        var ft = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        ft.Children.Add(Wk.Txt(fname, 14, _p.BText, FontWeights.Medium, true));
        ft.Children.Add(Wk.Txt(sizeText, 12.5, _p.BMuted));
        Grid.SetColumn(ft, 1);
        fg.Children.Add(fic); fg.Children.Add(ft);
        file.Child = fg; file.ToolTip = path;
        st.Children.Add(file);
        var bar = new SoftProgress(_p, 6) { Margin = new Thickness(0, 20, 0, 0) };
        st.Children.Add(bar);
        var status = Wk.Txt("Préparation…", 12.5, _p.BMuted); status.Margin = new Thickness(0, 9, 0, 0);
        st.Children.Add(status);
        card.Child = st;
        ShowCard(card);

        var sw = Stopwatch.StartNew();
        try
        {
            if (kind == WelcomeKind.Underlay)
            {
                status.Text = "Préparation du fond de plan…"; bar.Set(0.5);
                await Task.Delay(260); bar.Set(1);
                await Task.Delay(220);
                Finish(new WelcomeResult { Kind = WelcomeKind.Underlay, Path = path });
                return;
            }
            string? bad = ProjectFile.CheckExtension(path);
            if (bad != null) { await Task.Delay(250); throw new NotSupportedException(bad); }
            var prog = new Progress<double>(v => { bar.Set(v); status.Text = v < 0.74 ? "Lecture du fichier…" : v < 0.99 ? "Analyse du projet…" : "Terminé"; });
            var model = await Task.Run(() => ProjectFile.Read(path, v => ((IProgress<double>)prog).Report(v)));
            long wait = 450 - sw.ElapsedMilliseconds;
            if (wait > 0) await Task.Delay((int)wait);
            bar.Set(1);
            await Task.Delay(120);
            Finish(new WelcomeResult { Kind = WelcomeKind.Opened, Path = path, Model = model });
        }
        catch (Exception ex)
        {
            _busy = false;
            string msg = ex is FileNotFoundException ? "Le fichier est introuvable." : ex.Message;
            _host.ReportError(fname, msg);
            await MessageAsync(kind == WelcomeKind.Underlay ? "Import impossible" : "Impossible d'ouvrir ce fichier", $"{fname}\n\n{msg}", "alert", true);
        }
    }

    private void Finish(WelcomeResult r)
    {
        _busy = false;
        CloseWith(r);
    }

    private void CloseWith(WelcomeResult? r)
    {
        if (_closing) return;
        _closing = true;
        Result = r;
        if (r != null && r.Kind != WelcomeKind.Options) { try { _host.Apply(r); } catch (Exception ex) { _host.ReportError("Accueil", ex.Message); } }
        Wk.FadeTo((UIElement)Content, 0, 180, () =>
        {
            try { DialogResult = r != null; }
            catch { Close(); }
        });
    }
}
