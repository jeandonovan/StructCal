using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Masquer / isoler / tout afficher, élément par élément (barres, nœuds, dalles, voiles, escaliers, semelles, radiers, murs) :
/// ces états ne touchent pas au modèle (ni au calcul), seulement à l'affichage et à la désignation à l'écran, comme dans Revit ou Robot.</summary>
public sealed partial class ModelViewport
{
    /// <summary>Barres masquées (numéros).</summary>
    public HashSet<int> HiddenMembers { get; } = new();
    /// <summary>Nœuds masqués explicitement (un nœud dont toutes les barres sont masquées l'est aussi, automatiquement).</summary>
    public HashSet<int> HiddenNodes { get; } = new();
    private readonly HashSet<object> _hiddenObjs = new(ReferenceEqualityComparer.Instance);
    private HashSet<int> _autoNodes = new();
    private long _autoSig = long.MinValue;
    private int _hidVer;

    /// <summary>Déclenché après chaque changement de visibilité.</summary>
    public event Action? VisibilityChanged;

    /// <summary>Nombre d'éléments masqués (barres, nœuds masqués explicitement, autres objets).</summary>
    public int HiddenCount => HiddenMembers.Count + HiddenNodes.Count + _hiddenObjs.Count;
    public bool HasHidden => HiddenCount > 0;

    /// <summary>Objet (dalle, coque, escalier, semelle, mur, radier, semelle filante) masqué ?</summary>
    public bool IsObjHidden(object? o) => o != null && _hiddenObjs.Count > 0 && _hiddenObjs.Contains(o);

    /// <summary>Objet masqué par son contenu : la semelle d'un nœud est masquée si on l'a masquée elle-même.</summary>
    private bool FootingHidden(int node) => _hiddenObjs.Count > 0 && _hiddenObjs.Contains(FootingRefOf(node));

    private bool AutoNodeHidden(int id)
    {
        if (HiddenMembers.Count == 0 || Model == null) return false;
        long s = _hidVer * 1000003L + Model.Members.Count * 8191L + Model.Nodes.Count + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(Model);   // clé légère : appelée pour chaque nœud à chaque dessin
        if (s != _autoSig)
        {
            var visible = new HashSet<int>(); var any = new HashSet<int>();
            foreach (var m in Model.Members)
            {
                any.Add(m.NodeI); any.Add(m.NodeJ);
                if (!HiddenMembers.Contains(m.Id)) { visible.Add(m.NodeI); visible.Add(m.NodeJ); }
            }
            _autoNodes = new HashSet<int>(any.Where(n => !visible.Contains(n)));
            _autoSig = s;
        }
        return _autoNodes.Contains(id);
    }

    private void Touch() { _hidVer++; _autoSig = long.MinValue; }

    private void NotifyVisibility()
    {
        Touch();
        // un élément masqué reste sélectionné (barre de sélection : « masqué ») ; il n'est ni dessiné ni désignable au clic
        Redraw();
        VisibilityChanged?.Invoke();
        ElementSelectionChanged?.Invoke();
    }

    /// <summary>Tout ce qui est sélectionné (barres, nœuds, dalles, escaliers, semelles, voiles, radiers, planchers, coques), sous forme de clés de visibilité.</summary>
    public (List<int> Members, List<int> Nodes, List<object> Objs) SelectionForVisibility()
    {
        var objs = new List<object>();
        foreach (var k in _selKeys)
            foreach (var o in ObjectsOf(k)) objs.Add(o);
        return (_sel.ToList(), _selNodes.ToList(), objs);
    }

    /// <summary>Masque ces éléments. Retourne le nombre d'éléments masqués en plus.</summary>
    public int Hide(IEnumerable<int> members, IEnumerable<int> nodes, IEnumerable<object> objs)
    {
        int before = HiddenCount;
        foreach (int m in members) HiddenMembers.Add(m);
        foreach (int n in nodes) HiddenNodes.Add(n);
        foreach (var o in objs) _hiddenObjs.Add(o);
        int added = HiddenCount - before;
        if (added > 0) NotifyVisibility();
        return added;
    }

    /// <summary>Réaffiche ces éléments.</summary>
    public void Unhide(IEnumerable<int> members, IEnumerable<int> nodes, IEnumerable<object> objs)
    {
        foreach (int m in members) HiddenMembers.Remove(m);
        foreach (int n in nodes) HiddenNodes.Remove(n);
        foreach (var o in objs) _hiddenObjs.Remove(o);
        NotifyVisibility();
    }

    /// <summary>Réaffiche tout (les niveaux masqués par l'arborescence restent gérés par elle).</summary>
    public void ShowAll()
    {
        if (!HasHidden) return;
        HiddenMembers.Clear(); HiddenNodes.Clear(); _hiddenObjs.Clear();
        NotifyVisibility();
    }

    /// <summary>Ensemble de tous les éléments masquables du modèle.</summary>
    public (List<int> Members, List<int> Nodes, List<object> Objs) AllHideable()
    {
        var objs = new List<object>();
        if (Model == null) return (new List<int>(), new List<int>(), objs);
        objs.AddRange(Model.Slabs.Where(s => s.Placed)); objs.AddRange(Model.Shells); objs.AddRange(Model.Stairs.Where(s => s.Placed)); objs.AddRange(Model.RibbedFloors);
        objs.AddRange(Model.Walls); objs.AddRange(Model.Rafts); objs.AddRange(Model.FootingDefs.Where(f => f.Kind == FootingKind.Filante));
        foreach (int nid in Model.Nodes.Select(q => q.Id).Where(q => Model.Supports.Any(s => s.NodeId == q))) objs.Add(FootingRefOf(nid));
        return (Model.Members.Select(m => m.Id).ToList(), Model.Nodes.Select(n => n.Id).ToList(), objs);
    }

    /// <summary>Isole : masque tout sauf ces éléments (les nœuds des barres conservées et des semelles conservées restent visibles).</summary>
    public int Isolate(IEnumerable<int> members, IEnumerable<int> nodes, IEnumerable<object> objs)
    {
        if (Model == null) return 0;
        var keepM = new HashSet<int>(members); var keepN = new HashSet<int>(nodes); var keepO = new HashSet<object>(objs, ReferenceEqualityComparer.Instance);
        foreach (var m in Model.Members.Where(m => keepM.Contains(m.Id))) { keepN.Add(m.NodeI); keepN.Add(m.NodeJ); }
        foreach (var o in keepO.OfType<FootingRef>().ToList()) keepN.Add(o.NodeId);
        var all = AllHideable();
        HiddenMembers.Clear(); HiddenNodes.Clear(); _hiddenObjs.Clear();
        foreach (int m in all.Members) if (!keepM.Contains(m)) HiddenMembers.Add(m);
        foreach (int n in all.Nodes) if (!keepN.Contains(n)) HiddenNodes.Add(n);
        foreach (var o in all.Objs) if (!keepO.Contains(o)) _hiddenObjs.Add(o);
        // une semelle dont le nœud est conservé n'est visible que si elle est elle-même conservée
        NotifyVisibility();
        return HiddenCount;
    }

    /// <summary>Inverse la visibilité : ce qui était masqué devient visible et inversement.</summary>
    public void InvertVisibility()
    {
        var all = AllHideable();
        var hm = new HashSet<int>(HiddenMembers); var hn = new HashSet<int>(HiddenNodes); var ho = new HashSet<object>(_hiddenObjs, ReferenceEqualityComparer.Instance);
        HiddenMembers.Clear(); HiddenNodes.Clear(); _hiddenObjs.Clear();
        foreach (int m in all.Members) if (!hm.Contains(m)) HiddenMembers.Add(m);
        foreach (int n in all.Nodes) if (!hn.Contains(n)) HiddenNodes.Add(n);
        foreach (var o in all.Objs) if (!ho.Contains(o)) _hiddenObjs.Add(o);
        NotifyVisibility();
    }

    /// <summary>Oublie tous les états masqués sans redessiner (nouveau modèle, ouverture d'un fichier).</summary>
    public void ResetHidden() { HiddenMembers.Clear(); HiddenNodes.Clear(); _hiddenObjs.Clear(); Touch(); }

    /// <summary>Cadre la vue sur une boîte (m) : élément visé par un message de vérification.</summary>
    public void ZoomBox(double x0, double y0, double z0, double x1, double y1, double z1)
    {
        var pts = new List<StructCalc.Engine.Geometry.Vec3>();
        foreach (double x in new[] { Math.Min(x0, x1) - 0.5, Math.Max(x0, x1) + 0.5 })
            foreach (double y in new[] { Math.Min(y0, y1) - 0.5, Math.Max(y0, y1) + 0.5 })
                foreach (double z in new[] { Math.Min(z0, z1) - 0.5, Math.Max(z0, z1) + 0.5 })
                    pts.Add(new StructCalc.Engine.Geometry.Vec3(x, y, z));
        var (mn, mx) = BoundsOf(pts);
        _pivot = new StructCalc.Engine.Geometry.Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, 70);
    }

    /// <summary>Retire des états masqués les éléments qui n'existent plus (suppression, annuler / rétablir, nouveau modèle).</summary>
    public void PruneHidden()
    {
        PruneSelection();
        if (!HasHidden) return;
        if (Model == null) { HiddenMembers.Clear(); HiddenNodes.Clear(); _hiddenObjs.Clear(); return; }
        var ids = new HashSet<int>(Model.Members.Select(m => m.Id)); var nids = new HashSet<int>(Model.Nodes.Select(n => n.Id));
        HiddenMembers.RemoveWhere(i => !ids.Contains(i)); HiddenNodes.RemoveWhere(i => !nids.Contains(i));
        var all = new HashSet<object>(AllHideable().Objs, ReferenceEqualityComparer.Instance);
        _hiddenObjs.RemoveWhere(o => !all.Contains(o));
        Touch();
    }

    /// <summary>Catégories masquables en bloc.</summary>
    public (List<int> Members, List<int> Nodes, List<object> Objs) Category(string cat)
    {
        var mem = new List<int>(); var nodes = new List<int>(); var objs = new List<object>();
        if (Model == null) return (mem, nodes, objs);
        switch (cat)
        {
            case "columns": mem = Model.Members.Where(m => m.Type == MemberType.Column).Select(m => m.Id).ToList(); break;
            case "beams": mem = Model.Members.Where(m => m.Type != MemberType.Column).Select(m => m.Id).ToList(); break;
            case "steel": mem = Model.Members.Where(m => m.Kind == MaterialKind.Steel).Select(m => m.Id).ToList(); break;
            case "concrete": mem = Model.Members.Where(m => m.Kind == MaterialKind.ReinforcedConcrete).Select(m => m.Id).ToList(); break;
            case "slabs": objs.AddRange(Model.Slabs.Where(s => s.Placed)); objs.AddRange(Model.Shells.Where(s => s.Kind != "Voile")); objs.AddRange(Model.RibbedFloors); break;
            case "walls": objs.AddRange(Model.Walls); objs.AddRange(Model.Shells.Where(s => s.Kind == "Voile")); break;
            case "stairs": objs.AddRange(Model.Stairs.Where(s => s.Placed)); break;
            case "footings":
                objs.AddRange(Model.Rafts); objs.AddRange(Model.FootingDefs.Where(f => f.Kind == FootingKind.Filante));
                foreach (var s in Model.Supports) objs.Add(FootingRefOf(s.NodeId));
                break;
            case "supports": nodes = Model.Supports.Select(s => s.NodeId).Distinct().ToList(); break;
        }
        return (mem, nodes, objs);
    }

    /// <summary>Texte court de l'état de visibilité pour la barre d'état.</summary>
    public string HiddenSummary()
    {
        var parts = new List<string>();
        if (HiddenMembers.Count > 0) parts.Add($"{HiddenMembers.Count} barre(s)");
        if (HiddenNodes.Count > 0) parts.Add($"{HiddenNodes.Count} nœud(s)");
        if (_hiddenObjs.Count > 0) parts.Add($"{_hiddenObjs.Count} objet(s)");
        return parts.Count == 0 ? "" : "Masqués : " + string.Join(", ", parts);
    }
}
