using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Sélection des charges (de barre, surfaciques, nodales) et des cotes manuelles à l'écran : zones cliquables enregistrées au dessin,
/// surbrillance, suppression. Les charges surfaciques générées par une dalle ne se suppriment pas une à une (elles suivent la dalle).</summary>
public sealed partial class ModelViewport
{
    private readonly List<(object Obj, Point[] Pts, bool Area)> _objHits = new();

    /// <summary>Charge sélectionnée (MemberLoad, SurfaceLoad ou NodalLoad), null si aucune.</summary>
    public object? SelectedLoad { get; private set; }
    /// <summary>Cote manuelle sélectionnée, null si aucune.</summary>
    public ManualDim? SelectedDim { get; private set; }
    /// <summary>Déclenché quand une charge ou une cote est sélectionnée (null = désélection).</summary>
    public event Action<object?>? ObjectSelected;

    /// <summary>Charge ou cote sélectionnée.</summary>
    public object? SelectedObject => (object?)SelectedLoad ?? SelectedDim;

    private bool IsObjSelected(object o) => ReferenceEquals(o, SelectedLoad) || ReferenceEquals(o, SelectedDim);

    /// <summary>Enregistre une ligne brisée cliquable pour l'objet et la met en surbrillance s'il est sélectionné.</summary>
    private void AddHit(object o, params Point[] pts)
    {
        if (pts.Length < 2) return;
        _objHits.Add((o, pts, false));
        if (!IsObjSelected(o)) return;
        _c.Children.Add(new Polyline { Points = new PointCollection(pts), Stroke = new SolidColorBrush(Color.FromArgb(150, 0xFF, 0x6D, 0x00)), StrokeThickness = 7, StrokeLineJoin = PenLineJoin.Round, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, IsHitTestVisible = false });
    }

    /// <summary>Enregistre une zone cliquable rectangulaire (étiquette de charge) pour l'objet.</summary>
    private void AddHitRect(object o, double x, double y, double w, double h)
    {
        var pts = new[] { new Point(x, y), new Point(x + w, y), new Point(x + w, y + h), new Point(x, y + h) };
        _objHits.Add((o, pts, true));
        if (!IsObjSelected(o)) return;
        _c.Children.Add(new Polygon { Points = new PointCollection(pts), Stroke = Br("#FF6D00"), StrokeThickness = 2, Fill = new SolidColorBrush(Color.FromArgb(40, 0xFF, 0x6D, 0x00)), IsHitTestVisible = false });
    }

    /// <summary>Texte d'une charge, avec zone cliquable.</summary>
    private void LoadText(object o, string txt, double x, double y, Brush br, Brush? bg)
    {
        if (!Attr.LoadValues) return;
        Text(txt, x, y, 10, br, bg, true);
        AddHitRect(o, x - 1, y - 1, txt.Length * 5.6 + 6, 15);
    }

    private static double SegDist(Point p, Point a, Point b)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-9 ? 0 : Math.Clamp(((p.X - a.X) * dx + (p.Y - a.Y) * dy) / l2, 0, 1);
        double qx = a.X + t * dx - p.X, qy = a.Y + t * dy - p.Y;
        return Math.Sqrt(qx * qx + qy * qy);
    }

    /// <summary>Charge ou cote visée par le point écran (tolérance 6 px), null si aucune.</summary>
    public object? PickObject(Point p, double tol = 6)
    {
        object? best = null; double bd = tol;
        foreach (var h in _objHits)
        {
            if (h.Area) { if (InPoly(p, h.Pts)) return h.Obj; continue; }
            for (int i = 0; i + 1 < h.Pts.Length; i++)
            {
                double d = SegDist(p, h.Pts[i], h.Pts[i + 1]);
                if (d < bd) { bd = d; best = h.Obj; }
            }
        }
        return best;
    }

    /// <summary>Sélectionne une charge ou une cote (null = désélection) et désélectionne le reste.</summary>
    public void SelectObject(object? o, bool notify = true)
    {
        bool hadN = _selNodes.Count > 0, hadS = _selKeys.Any(k => k.Kind == StructCalc.Engine.Selection.ElementKind.Slab), hadM = _sel.Count > 0;
        _selNodes.Clear(); PrimaryNode = -1; _selKeys.Clear(); _sel.Clear(); _primary = -1;
        SelectedDim = o as ManualDim;
        SelectedLoad = o is ManualDim ? null : o;
        Redraw();
        if (!notify) return;
        if (hadN) NodeSelectionChanged?.Invoke();
        if (hadS) SlabSelected?.Invoke(null);
        if (hadM) { SelectionChanged?.Invoke(); MemberSelected?.Invoke(-1); }
        ObjectSelected?.Invoke(o);
        ElementSelectionChanged?.Invoke();
    }

    /// <summary>La charge surfacique est-elle générée par une dalle (D1-G, D1-Q, D1-G#2...) ?</summary>
    public bool IsSlabGenerated(SurfaceLoad s) =>
        Model != null && Model.Slabs.Any(d => s.Name == d.Name + "-G" || s.Name == d.Name + "-Q" || s.Name.StartsWith(d.Name + "-G#") || s.Name.StartsWith(d.Name + "-Q#"));

    /// <summary>Description courte d'une charge ou d'une cote pour la barre d'état et les menus.</summary>
    public string DescribeObject(object o)
    {
        switch (o)
        {
            case MemberLoad m:
                return m.Kind switch
                {
                    MemberLoadKind.Point => $"Charge ponctuelle {m.Case} sur la barre {m.MemberId} : ({m.Px:0.##} ; {m.Py:0.##} ; {m.Pz:0.##}) kN",
                    MemberLoadKind.Moment => $"Moment {m.Case} sur la barre {m.MemberId} : ({m.Mx:0.##} ; {m.My:0.##} ; {m.Mz:0.##}) kN.m",
                    MemberLoadKind.Thermal => $"Température {m.Case} sur la barre {m.MemberId} : ΔT = {m.Dt:0.#} °C",
                    MemberLoadKind.Trapezoid => $"Charge trapézoïdale {m.Case} sur la barre {m.MemberId} : ({m.Wx:0.##} ; {m.Wy:0.##} ; {m.Wz:0.##}) → ({m.Wx2:0.##} ; {m.Wy2:0.##} ; {m.Wz2:0.##}) kN/m",
                    _ => $"Charge répartie {m.Case} sur la barre {m.MemberId} : ({m.Wx:0.##} ; {m.Wy:0.##} ; {m.Wz:0.##}) kN/m"
                };
            case SurfaceLoad s:
                return $"Charge surfacique {s.Name} ({s.Case}) : {s.Q:0.##} kN/m²" + (IsSlabGenerated(s) ? " — générée par la dalle" : "");
            case NodalLoad n:
                return $"Charge nodale {n.Case} au nœud {n.NodeId} : F = ({n.Fx:0.##} ; {n.Fy:0.##} ; {n.Fz:0.##}) kN";
            case FootingRef fr:
            {
                var pf = Model == null ? null : StructCalc.Engine.Geometry.FootingPlacement.From(Model, Output).FirstOrDefault(q => q.NodeId == fr.NodeId);
                return pf == null ? $"Semelle {fr.Name}" : $"Semelle {pf.Name} sous le nœud {pf.NodeId} : {pf.A:0.00} x {pf.B:0.00} x {pf.H:0.00} m" + (pf.Glacis ? " à glacis" : " (bloc)") + (pf.FromAssistant ? " · définie dans l'assistant" : " · dimensionnée automatiquement") + (pf.Ok ? "" : " · NON CONFORME");
            }
            case StairDef sd:
                return $"Escalier {sd.Name} ({sd.Layout}) · H = {sd.HeightM:0.##} m · emmarchement {sd.WidthM:0.##} m · en ({sd.X:0.##} ; {sd.Y:0.##} ; {sd.Z:0.##})";
            case ManualDim d:
                return $"Cote manuelle : {Math.Sqrt(Math.Pow(d.X2 - d.X1, 2) + Math.Pow(d.Y2 - d.Y1, 2) + Math.Pow(d.Z2 - d.Z1, 2)):0.###} m";
        }
        return "";
    }

    /// <summary>Supprime la charge ou la cote sélectionnée. Retourne le message de résultat ("" si rien).</summary>
    public string DeleteSelectedObject()
    {
        if (Model == null) return "";
        var o = SelectedObject;
        if (o == null) return "";
        if (o is SurfaceLoad sl && IsSlabGenerated(sl))
            return $"La charge {sl.Name} est générée par la dalle : modifiez G / Q dans les propriétés de la dalle, ou mettez la dalle en « métré seul ».";
        BeforeEdit?.Invoke();
        bool load = true;
        switch (o)
        {
            case MemberLoad m: Model.MemberLoads.Remove(m); break;
            case SurfaceLoad s: Model.SurfaceLoads.Remove(s); break;
            case NodalLoad n: Model.NodalLoads.Remove(n); break;
            case ManualDim d: Model.ManualDims.Remove(d); load = false; break;
        }
        string msg = (load ? "Charge supprimée" : "Cote supprimée") + "  (Ctrl+Z pour annuler)";
        SelectedLoad = null; SelectedDim = null;
        if (load) ModelEdited?.Invoke();
        Redraw();
        ObjectSelected?.Invoke(null);
        ElementSelectionChanged?.Invoke();
        return msg;
    }
}
