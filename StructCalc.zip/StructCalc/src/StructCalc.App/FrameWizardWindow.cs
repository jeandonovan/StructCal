using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Assistant de génération d'ossature régulière (poteaux, poutres, appuis, charges).</summary>
public sealed class FrameWizardWindow : Window
{
    private readonly Dictionary<string, TextBox> _f = new();
    private readonly ComboBox _mat = new() { SelectedIndex = 0 };
    private readonly CheckBox _fixed = new() { Content = "Appuis encastrés (sinon articulés)", IsChecked = true, Margin = new Thickness(0, 8, 0, 0) };
    public StructModel? Result { get; private set; }

    public FrameWizardWindow()
    {
        Title = "Assistant : générer une ossature";
        Width = 470; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var grid = new Grid { Margin = new Thickness(16) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(250) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        int r = 0;
        void Row(string label, string key, string def)
        {
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var t = new TextBlock { Text = label, Margin = new Thickness(0, 4, 8, 4), VerticalAlignment = VerticalAlignment.Center };
            var b = new TextBox { Text = def, Margin = new Thickness(0, 2, 0, 2), Padding = new Thickness(3) };
            Grid.SetRow(t, r); Grid.SetRow(b, r); Grid.SetColumn(b, 1);
            grid.Children.Add(t); grid.Children.Add(b); _f[key] = b; r++;
        }
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var tm = new TextBlock { Text = "Matériau", Margin = new Thickness(0, 4, 8, 4) };
        _mat.Items.Add("Béton armé"); _mat.Items.Add("Acier"); _mat.SelectedIndex = 0;
        Grid.SetRow(tm, r); Grid.SetRow(_mat, r); Grid.SetColumn(_mat, 1);
        grid.Children.Add(tm); grid.Children.Add(_mat); r++;
        Row("Travées en X (nombre)", "bx", "2");
        Row("Travées en Y (0 = portique plan)", "by", "0");
        Row("Étages (nombre)", "st", "2");
        Row("Portée en X (m)", "lx", "5");
        Row("Portée en Y (m)", "ly", "5");
        Row("Hauteur d'étage (m)", "h", "3.2");
        Row("Poteau BA : b (cm)", "cb", "30");
        Row("Poteau BA : h (cm)", "ch", "30");
        Row("Poutre BA : b (cm)", "bb", "25");
        Row("Poutre BA : h (cm)", "bh", "45");
        Row("Profil poteau acier", "cp", "HEA240");
        Row("Profil poutre acier", "bp", "IPE300");
        Row("Charge permanente G (kN/m par poutre)", "g", "18");
        Row("Charge d'exploitation Q (kN/m par poutre)", "q", "6");

        var panel = new StackPanel();
        panel.Children.Add(grid);
        panel.Children.Add(new Border { Margin = new Thickness(16, 0, 16, 0), Child = _fixed });
        panel.Children.Add(new TextBlock
        {
            Text = "Le poids propre est ajouté automatiquement. Les charges G et Q sont appliquées à chaque poutre (X et Y) : ajustez-les ensuite dans le tableau ou barre par barre.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(16, 8, 16, 0), Foreground = System.Windows.Media.Brushes.Gray, FontSize = 11
        });
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(16) };
        var ok = new Button { Content = "Générer", Padding = new Thickness(18, 6, 18, 6), IsDefault = true, Margin = new Thickness(0, 0, 8, 0) };
        var cancel = new Button { Content = "Annuler", Padding = new Thickness(14, 6, 14, 6), IsCancel = true };
        ok.Click += (s, e) => Generate();
        buttons.Children.Add(ok); buttons.Children.Add(cancel);
        panel.Children.Add(buttons);
        Content = panel;
    }

    private double D(string k) => double.TryParse(_f[k].Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double v) ? v : double.NaN;

    private void Generate()
    {
        try
        {
            var spec = new FrameSpec
            {
                BaysX = (int)D("bx"), BaysY = (int)D("by"), Storeys = (int)D("st"),
                SpanX = D("lx"), SpanY = D("ly"), StoreyHeight = D("h"),
                Steel = _mat.SelectedIndex == 1,
                ColB = D("cb") / 100, ColH = D("ch") / 100, BeamB = D("bb") / 100, BeamH = D("bh") / 100,
                ColProfile = _f["cp"].Text.Trim().ToUpperInvariant(), BeamProfile = _f["bp"].Text.Trim().ToUpperInvariant(),
                G = D("g"), Q = D("q"), FixedBase = _fixed.IsChecked == true
            };
            if (new[] { spec.SpanX, spec.SpanY, spec.StoreyHeight, spec.ColB, spec.ColH, spec.BeamB, spec.BeamH, spec.G, spec.Q }.Any(double.IsNaN))
                throw new ArgumentException("Une valeur numérique est invalide.");
            Result = FrameGenerator.Generate(spec);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Assistant d'ossature", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
