using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Sections;

namespace StructCalc.UI;

/// <summary>Dessin de la section étudiée : contour, cadres, barres et cotes.</summary>
public sealed class SectionPreview : FrameworkElement
{
    private SectionGeom? _g;
    private List<(double X, double Y, double Dia)> _bars = new();
    private double _inset;
    private string _caption = "";

    public void Set(SectionGeom g, List<(double X, double Y, double Dia)> bars, double stirrupInset, string caption)
    {
        _g = g; _bars = bars; _inset = stirrupInset; _caption = caption; InvalidateVisual();
    }

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, ActualWidth, ActualHeight));
        if (_g == null || ActualWidth < 50 || ActualHeight < 50) return;
        var g = _g;
        double w = g.Shape == SectionShape.Circle ? g.B : g.B, h = g.Height;
        double s = Math.Min((ActualWidth - 140) / w, (ActualHeight - 120) / h);
        if (s <= 0) return;
        double ox = (ActualWidth - w * s) / 2, oy = 50 + (ActualHeight - 110 - h * s) / 2;
        Point P(double x, double y) => new(ox + x * s, oy + y * s);
        var fill = new SolidColorBrush(Color.FromRgb(0xE3, 0xE6, 0xEA)); fill.Freeze();
        var edge = new Pen(new SolidColorBrush(Color.FromRgb(0x37, 0x47, 0x4F)), 2); edge.Freeze();
        var stir = new Pen(new SolidColorBrush(Color.FromRgb(0x1E, 0x88, 0xE5)), 1.6); stir.Freeze();
        var dim = new Pen(Brushes.Gray, 0.8); dim.Freeze();
        var tf = new Typeface("Segoe UI");
        void Label(string t, double x, double y, bool center = true)
        {
            var ft = new FormattedText(t, System.Globalization.CultureInfo.CurrentCulture, FlowDirection.LeftToRight, tf, 12, Brushes.DimGray, 1.0);
            dc.DrawText(ft, new Point(center ? x - ft.Width / 2 : x, y));
        }
        if (g.Shape == SectionShape.Circle)
        {
            var c = P(w / 2, h / 2); double r = w * s / 2;
            dc.DrawEllipse(fill, edge, c, r, r);
            if (_inset > 0) dc.DrawEllipse(null, stir, c, r - _inset * s, r - _inset * s);
        }
        else
        {
            var pts = g.OutlineShown();
            var geo = new StreamGeometry();
            using (var ctx = geo.Open()) { ctx.BeginFigure(P(pts[0].X, pts[0].Y), true, true); foreach (var q in pts.Skip(1)) ctx.LineTo(P(q.X, q.Y), true, false); }
            geo.Freeze();
            dc.DrawGeometry(fill, edge, geo);
            if (_inset > 0 && (g.Shape == SectionShape.Rectangle))
                dc.DrawRectangle(null, stir, new Rect(P(_inset, _inset), P(w - _inset, h - _inset)));
            else if (_inset > 0)
            {
                var sg = new StreamGeometry();
                var cx = pts.Average(q => q.X); var cy = pts.Average(q => q.Y);
                using (var ctx = sg.Open())
                {
                    // contour réduit vers l'intérieur : décalage de chaque sommet vers le centre de gravité du contour
                    var inner = pts.Select(q => (X: q.X + Math.Sign(cx - q.X) * _inset, Y: q.Y + Math.Sign(cy - q.Y) * _inset)).ToList();
                    ctx.BeginFigure(P(inner[0].X, inner[0].Y), false, true); foreach (var q in inner.Skip(1)) ctx.LineTo(P(q.X, q.Y), true, false);
                }
                sg.Freeze(); dc.DrawGeometry(null, stir, sg);
            }
        }
        foreach (var b in _bars)
        {
            double rr = Math.Max(3, b.Dia / 1000.0 * s / 2);
            dc.DrawEllipse(Brushes.Firebrick, new Pen(Brushes.Black, 0.6), P(b.X, b.Y), rr, rr);
        }
        // cotes
        double yb = oy + h * s + 22;
        dc.DrawLine(dim, new Point(ox, yb), new Point(ox + w * s, yb));
        Label(g.Shape == SectionShape.Circle ? $"Ø {g.B * 100:0} cm" : $"{g.B * 100:0} cm", ox + w * s / 2, yb + 2);
        double xr = ox + w * s + 24;
        dc.DrawLine(dim, new Point(xr, oy), new Point(xr, oy + h * s));
        Label($"{h * 100:0} cm", xr + 4, oy + h * s / 2 - 8, false);
        Label(_caption, ActualWidth / 2, 12);
    }
}

/// <summary>Assistants poutre et poteau : section rectangulaire, en T, en L (poutre) ; rectangulaire, circulaire, en T, en L (poteau).</summary>
public sealed class SectionWizardWindow : Window
{
    private readonly bool _beam;
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<AnalysisOutput?> _out;
    private readonly Func<int> _selected;
    private readonly Func<Func<StructModel, string>, string> _apply;
    private readonly BeamSectionInput _bi = new();
    private readonly ColumnSectionInput _ci = new();
    private readonly ComboBox _shape = new() { Width = 230 };
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(8) };
    private readonly SectionPreview _preview = new();
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private readonly ScrollViewer _formHost = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private FormKit _form = null!;
    private BeamSectionResult? _br;
    private ColumnSectionResult? _cr;

    public SectionWizardWindow(bool beam, Func<StructModel> model, Func<AnalysisOutput?> output, Func<int> selectedId, Func<Func<StructModel, string>, string> apply)
    {
        _beam = beam; _get = model; _out = output; _selected = selectedId; _apply = apply;
        Title = beam ? "Assistant poutre : rectangulaire, en T, en L" : "Assistant poteau : rectangulaire, circulaire, en T, en L";
        Width = 1250; Height = 780; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _bi.Fc = _ci.Fc = _model.Fc28; _bi.Fe = _ci.Fe = _model.Fe;

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(470) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Section :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        if (beam) { _shape.Items.Add("Rectangulaire"); _shape.Items.Add("En T (poutre centrale)"); _shape.Items.Add("En L (poutre de rive)"); }
        else { _shape.Items.Add("Rectangulaire"); _shape.Items.Add("Circulaire"); _shape.Items.Add("En T"); _shape.Items.Add("En L"); }
        _shape.SelectedIndex = 0;
        _shape.SelectionChanged += (s, e) => { SetShape(); RebuildForm(); Recompute(); };
        bar.Children.Add(_shape);
        bar.Children.Add(new Border { Width = 10 });
        bar.Children.Add(Ui.Btn("↧ Efforts de la barre sélectionnée", (s, e) => TakeForces()));
        bar.Children.Add(Ui.Btn("Appliquer b x h à la barre", (s, e) => ApplyToMember()));
        bar.Children.Add(Ui.Btn("Copier la note", (s, e) => { try { Clipboard.SetText(_report.Text); _status.Text = "Note copiée."; } catch { } }));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);
        var tabs = new TabControl { Margin = new Thickness(4) };
        tabs.Items.Add(new TabItem { Header = "Section et armatures", Content = _preview });
        tabs.Items.Add(new TabItem { Header = "Note de calcul", Content = _report });
        Grid.SetRow(tabs, 1); Grid.SetColumn(tabs, 1); root.Children.Add(tabs);
        Content = root;
        SetShape(); RebuildForm();
        Loaded += (s, e) => Recompute();
        SizeChanged += (s, e) => Recompute();
    }

    private void SetShape()
    {
        int i = Math.Max(0, _shape.SelectedIndex);
        if (_beam) _bi.Shape = i == 1 ? SectionShape.Tee : i == 2 ? SectionShape.Ell : SectionShape.Rectangle;
        else _ci.Shape = i == 1 ? SectionShape.Circle : i == 2 ? SectionShape.Tee : i == 3 ? SectionShape.Ell : SectionShape.Rectangle;
    }

    private void RebuildForm()
    {
        _form = new FormKit();
        if (_beam) BeamForm(); else ColumnForm();
        _form.Changed += Recompute;
        _formHost.Content = _form.Root;
    }

    private void BeamForm()
    {
        var p = _bi; var f = _form;
        bool flange = p.Shape != SectionShape.Rectangle;
        f.Section("Section", flange ? "Poutre en T ou en L avec la dalle comme table de compression : la largeur collaborante est calculée selon la norme choisie." : "Poutre rectangulaire.");
        f.Num("Largeur de l'âme bw", () => p.Bw * 100, v => p.Bw = v / 100, null, "cm");
        f.Num("Hauteur totale h", () => p.H * 100, v => p.H = v / 100, null, "cm");
        if (flange) f.Num("Épaisseur de la table hf (dalle)", () => p.Hf * 100, v => p.Hf = v / 100, "Épaisseur de la dalle au droit de la poutre", "cm");
        f.Num("Bord -> axe des armatures d'", () => p.Dprime * 100, v => p.Dprime = v / 100, "Enrobage + cadre + demi-barre : 4 à 6 cm", "cm");
        if (flange)
        {
            f.Section("Table collaborante");
            f.Num("Portée L de la travée", () => p.Span, v => p.Span = v, null, "m");
            f.Combo("Position de la travée", new (string, SpanPosition)[] { ("Travée de rive (l0 = 0,85 L)", SpanPosition.EndSpan), ("Travée intermédiaire (l0 = 0,70 L)", SpanPosition.InteriorSpan), ("Isostatique (l0 = L)", SpanPosition.Isostatic), ("Console (l0 = 2 L)", SpanPosition.Cantilever) }, () => p.Position, v => p.Position = v);
            if (p.Shape == SectionShape.Tee) f.Num("Demi-distance libre à gauche bi", () => p.BiLeft, v => p.BiLeft = v, "Moitié de la distance libre jusqu'à la poutre voisine", "m");
            f.Num(p.Shape == SectionShape.Tee ? "Demi-distance libre à droite bi" : "Débord de la dalle côté intérieur bi", () => p.BiRight, v => p.BiRight = v, null, "m");
            f.Combo("Règle de calcul de b", new (string, FlangeRule)[] { ("Eurocode 2 (5.3.2.1)", FlangeRule.Ec2), ("BAEL A.4.1,3", FlangeRule.Bael) }, () => p.Rule, v => p.Rule = v);
            f.Num("Largeur b imposée (0 = calculée)", () => p.BImposed, v => p.BImposed = v, null, "m");
        }
        f.Section("Efforts de calcul (ELU)");
        f.Num("Moment en travée Mu", () => p.MuSag, v => p.MuSag = v, "Fibre supérieure comprimée", "kN·m");
        f.Num("Moment sur appui Mu", () => p.MuHog, v => p.MuHog = v, "Valeur absolue ; 0 si aucun", "kN·m");
        f.Num("Effort tranchant Vu", () => p.Vu, v => p.Vu = v, "À l'abscisse d du nu de l'appui", "kN");
        f.Num("Moment de service Mser (travée)", () => p.MserSag, v => p.MserSag = v, "0 = pas de vérification ELS", "kN·m");
        f.Section("Matériaux");
        f.Num("Béton fc28", () => p.Fc, v => p.Fc = v, null, "MPa");
        f.Num("Acier fe", () => p.Fe, v => p.Fe = v, null, "MPa");
        f.Combo("Fissuration", new (string, CrackingClass)[] { ("Peu préjudiciable", CrackingClass.PeuPrejudiciable), ("Préjudiciable", CrackingClass.Prejudiciable), ("Très préjudiciable", CrackingClass.TresPrejudiciable) }, () => p.Crack, v => p.Crack = v);
    }

    private void ColumnForm()
    {
        var p = _ci; var f = _form;
        f.Section("Section");
        switch (p.Shape)
        {
            case SectionShape.Circle:
                f.Num("Diamètre D", () => p.B * 100, v => p.B = v / 100, null, "cm");
                f.Num("Nombre de barres", () => p.BarsCircle, v => p.BarsCircle = (int)Math.Round(v), "6 au minimum", "");
                break;
            case SectionShape.Tee:
            case SectionShape.Ell:
                f.Num("Largeur de la table b", () => p.B * 100, v => p.B = v / 100, null, "cm");
                f.Num("Épaisseur de la table hf", () => p.Hf * 100, v => p.Hf = v / 100, null, "cm");
                f.Num("Largeur de l'âme bw", () => p.Bw * 100, v => p.Bw = v / 100, null, "cm");
                f.Num("Hauteur totale h", () => p.H * 100, v => p.H = v / 100, "Dans le plan de flexion", "cm");
                break;
            default:
                f.Num("Largeur b", () => p.B * 100, v => p.B = v / 100, null, "cm");
                f.Num("Hauteur h (dans le plan de flexion)", () => p.H * 100, v => p.H = v / 100, "Échangez b et h pour l'autre axe", "cm");
                break;
        }
        f.Num("Bord -> axe des armatures d'", () => p.Dprime * 100, v => p.Dprime = v / 100, "Enrobage + cadre + demi-barre : 4 à 6 cm", "cm");
        f.Section("Efforts de calcul (ELU)");
        f.Num("Effort normal Nu (compression)", () => p.Nu, v => p.Nu = v, null, "kN");
        f.Num("Moment du 1er ordre Mu", () => p.Mu, v => p.Mu = v, "Négatif : fibre supérieure tendue (utile pour T et L)", "kN·m");
        if (p.Shape == SectionShape.Rectangle)
            f.Num("Moment Mu,z (autre direction)", () => p.MuZ, v => p.MuZ = v, "Flexion déviée (EC2 5.8.9) : 0 = flexion plane ; sinon armatures sur tout le pourtour", "kN·m");
        f.Num("Longueur de flambement lf", () => p.Lf, v => p.Lf = v, "lf = 0,7 L0 (encastré-articulé) à 2 L0 (console)", "m");
        f.Num("α = Mg / (Mg + Mq)", () => p.Alpha, v => p.Alpha = v, "Part des charges permanentes dans le moment : 0,7 à 1", "");
        f.Num("Rapport de fluage φ", () => p.Phi, v => p.Phi = v, "2 en général", "");
        f.Section("Matériaux");
        f.Num("Béton fc28", () => p.Fc, v => p.Fc = v, null, "MPa");
        f.Num("Acier fe", () => p.Fe, v => p.Fe = v, null, "MPa");
    }

    private static List<(double X, double Y, double Dia)> RowBars(SectionGeom g, double y, int n, double dia, double dPrime)
    {
        var res = new List<(double, double, double)>();
        if (n <= 0) return res;
        double w = g.WidthAt(y), x0, x1;
        switch (g.Shape)
        {
            case SectionShape.Tee: x0 = g.B / 2 - w / 2; x1 = g.B / 2 + w / 2; break;
            case SectionShape.Ell: x0 = 0; x1 = w; break;
            default: x0 = g.B / 2 - w / 2; x1 = g.B / 2 + w / 2; break;
        }
        x0 += dPrime; x1 -= dPrime;
        for (int i = 0; i < n; i++) res.Add((n == 1 ? (x0 + x1) / 2 : x0 + i * (x1 - x0) / (n - 1), y, dia));
        return res;
    }

    private void Recompute()
    {
        try
        {
            if (_beam)
            {
                var r = BeamSectionDesigner.Design(_bi); _br = r;
                _report.Text = r.Report;
                var bars = new List<(double, double, double)>();
                var g = r.Geom;
                if (r.Bottom != null) bars.AddRange(RowBars(g, g.Height - _bi.Dprime, r.Bottom.Count, r.Bottom.Diameter, _bi.Dprime));
                if (r.Top != null) bars.AddRange(RowBars(g, _bi.Dprime, r.Top.Count, r.Top.Diameter, _bi.Dprime));
                bars.AddRange(RowBars(g, _bi.Dprime, 2, 8, _bi.Dprime).Where(_ => r.Top == null));
                _preview.Set(g, bars, Math.Max(0.015, _bi.Dprime - 0.012), $"{(r.Bottom?.Label ?? "-")} en bas" + (r.Top != null ? $", {r.Top.Label} en haut" : "") + $" ; cadres HA{r.StirDia} / {r.StirSpacingCm:0} cm");
                SetStatus(r.Ok, r.Warnings);
            }
            else
            {
                var r = ColumnSectionDesigner.Design(_ci); _cr = r;
                _report.Text = r.Report;
                var g = r.Geom; var bars = new List<(double, double, double)>();
                if (r.Bars != null)
                {
                    if (g.Shape == SectionShape.Circle) bars.AddRange(r.BarPositions.Select(b => (b.X, b.Y, (double)r.Bars.Diameter)));
                    else
                    {
                        int half = Math.Max(1, r.Bars.Count / 2);
                        bars.AddRange(RowBars(g, _ci.Dprime, half, r.Bars.Diameter, _ci.Dprime));
                        bars.AddRange(RowBars(g, g.Height - _ci.Dprime, half, r.Bars.Diameter, _ci.Dprime));
                    }
                }
                _preview.Set(g, bars, Math.Max(0.015, _ci.Dprime - 0.012), $"{r.Bars?.Label ?? "-"} ; {(g.Shape == SectionShape.Circle ? "cerces" : "cadres")} HA{r.TieDia} / {r.TieSpacingCm:0} cm");
                SetStatus(r.Ok, r.Warnings);
            }
        }
        catch (Exception ex) { _status.Text = "Erreur : " + ex.Message; _status.Foreground = Brushes.Firebrick; }
    }

    private void SetStatus(bool ok, List<string> warnings)
    {
        _status.Text = ok ? "✔ Section vérifiée" : "⚠ " + (warnings.FirstOrDefault() ?? "À vérifier");
        _status.Foreground = ok ? Brushes.DarkGreen : Brushes.Firebrick;
    }

    private void TakeForces()
    {
        var o = _out();
        int id = _selected();
        var r = o?.Members.FirstOrDefault(x => x.MemberId == id);
        var mem = _model.Members.FirstOrDefault(x => x.Id == id);
        if (r == null || mem == null || r.Kind != MaterialKind.ReinforcedConcrete)
        {
            _status.Text = "Sélectionnez une barre en béton armé et lancez le calcul (F5).";
            _status.Foreground = Brushes.Firebrick;
            return;
        }
        if (_beam)
        {
            _bi.Bw = mem.B; _bi.H = mem.H; _bi.MuSag = Math.Round(r.MuSag, 1); _bi.MuHog = Math.Round(r.MuHog, 1); _bi.Vu = Math.Round(r.Vu, 1); _bi.Span = r.Length > 0 ? r.Length : _bi.Span;
            _bi.Dprime = mem.Cover > 0 ? mem.Cover : _bi.Dprime;
        }
        else
        {
            _ci.B = mem.B; _ci.H = mem.H; _ci.Nu = Math.Round(r.NuMax, 0); _ci.Mu = Math.Round(Math.Max(r.MuSag, r.MuHog), 1); if (r.Length > 0) _ci.Lf = r.Length;
            _ci.Dprime = mem.Cover > 0 ? mem.Cover : _ci.Dprime;
            if (_ci.Shape != SectionShape.Rectangle) { _shape.SelectedIndex = 0; }
        }
        RebuildForm(); Recompute();
        _status.Text = $"Efforts de la barre {id} repris (valeurs ELU du calcul).";
    }

    private void ApplyToMember()
    {
        int id = _selected();
        double b, h;
        if (_beam) { if (_bi.Shape != SectionShape.Rectangle) { _status.Text = "Seule la section rectangulaire équivalente (bw x h) peut être appliquée à la barre."; return; } b = _bi.Bw; h = _bi.H; }
        else if (_ci.Shape == SectionShape.Circle) { b = h = _ci.B; }
        else if (_ci.Shape == SectionShape.Rectangle) { b = _ci.B; h = _ci.H; }
        else { _status.Text = "Seules les sections rectangulaire et circulaire (diamètre) peuvent être appliquées à la barre."; return; }
        _status.Text = _apply(m =>
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) return "Sélectionnez d'abord une barre dans le modèle.";
            mem.B = b; mem.H = h;
            return $"Barre {id} : section {b * 100:0} x {h * 100:0} cm appliquée (relancez le calcul avec F5).";
        });
    }
}
