using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

/// <summary>Voiles (avec leurs ouvertures), radiers et semelles filantes posés dans le modèle : affichage en plan et en 3D.</summary>
public sealed partial class ModelViewport
{
    private void Quads(IEnumerable<Vec3[]> quads, Brush fill, Brush edge, double th = 0.9)
    {
        var items = quads.Select(q => (P: q.Select(v => S(v.X, v.Y, v.Z)).ToArray(), D: q.Average(v => V3(v.X, v.Y, v.Z).D))).OrderByDescending(t => t.D).ToList();
        foreach (var it in items)
            _c.Children.Add(new Polygon { Points = new PointCollection(it.P), Fill = fill, Stroke = edge, StrokeThickness = th, StrokeLineJoin = PenLineJoin.Round, IsHitTestVisible = false });
    }

    /// <summary>Boîte alignée sur les axes : (x0,y0)-(x1,y1) en plan, du dessous zb au dessus zt.</summary>
    private static List<Vec3[]> BoxFaces(double x0, double y0, double x1, double y1, double zb, double zt, bool topOnly)
    {
        var res = new List<Vec3[]> { new[] { new Vec3(x0, y0, zt), new Vec3(x1, y0, zt), new Vec3(x1, y1, zt), new Vec3(x0, y1, zt) } };
        if (topOnly) return res;
        res.Add(new[] { new Vec3(x0, y0, zb), new Vec3(x1, y0, zb), new Vec3(x1, y1, zb), new Vec3(x0, y1, zb) });
        res.Add(new[] { new Vec3(x0, y0, zb), new Vec3(x1, y0, zb), new Vec3(x1, y0, zt), new Vec3(x0, y0, zt) });
        res.Add(new[] { new Vec3(x1, y0, zb), new Vec3(x1, y1, zb), new Vec3(x1, y1, zt), new Vec3(x1, y0, zt) });
        res.Add(new[] { new Vec3(x1, y1, zb), new Vec3(x0, y1, zb), new Vec3(x0, y1, zt), new Vec3(x1, y1, zt) });
        res.Add(new[] { new Vec3(x0, y1, zb), new Vec3(x0, y0, zb), new Vec3(x0, y0, zt), new Vec3(x0, y1, zt) });
        return res;
    }

    private void DrawFoundationsAndWalls()
    {
        if (Model == null) return;
        bool plan = Mode == ViewMode.Plan;

        // ---- radiers
        if (Model.Rafts.Count > 0)
        {
            var fc = ElementPalette.Get("Footing");
            var fill = new SolidColorBrush(ElementPalette.WithAlpha(fc, (byte)(plan ? 90 : 215))); fill.Freeze();
            var edge = Theme.Fixed(ElementPalette.Shade(fc, 0.35));
            foreach (var rf in Model.Rafts)
            {
                if (IsObjHidden(rf)) continue;
                var rkey = ElementKey.Named(ElementKind.Raft, rf.Name);
                foreach (var p in rf.Panels)
                {
                    var faces = BoxFaces(p.X0, p.Y0, p.X0 + p.Lx, p.Y0 + p.Ly, rf.ZTop - rf.H, rf.ZTop, plan);
                    Quads(faces, fill, edge);
                    foreach (var fc2 in faces) AddFaceHit(rkey, fc2, !plan);
                }
                if (rf.Panels.Count > 0)
                {
                    var p0 = rf.Panels[0]; var c = S(p0.X0 + p0.Lx / 2, p0.Y0 + p0.Ly / 2, rf.ZTop);
                    Text($"{rf.Name}  radier h={rf.H * 100:0} cm", c.X - 40, c.Y - 7, 11, edge, null, true);
                }
            }
        }

        // ---- semelles filantes posées
        var strips = Model.FootingDefs.Where(f => f.Kind == FootingKind.Filante && f.LengthM > 0.5).ToList();
        if (strips.Count > 0)
        {
            var fc = ElementPalette.Get("Footing");
            var fill = new SolidColorBrush(ElementPalette.WithAlpha(fc, (byte)(plan ? 110 : 225))); fill.Freeze();
            var edge = Theme.Fixed(ElementPalette.Shade(fc, 0.35));
            foreach (var f in strips)
            {
                if (IsObjHidden(f)) continue;
                double a = f.FixedA > 0 ? f.FixedA : 0.8, h = f.ThicknessM > 0 ? f.ThicknessM : 0.4;
                double ca = Math.Cos(f.AngleDeg * Math.PI / 180), sa = Math.Sin(f.AngleDeg * Math.PI / 180);
                Vec3 P(double u, double v, double z) => new(f.X0 + u * ca - v * sa, f.Y0 + u * sa + v * ca, z);
                double zb = f.ZTop - h, zt = f.ZTop, L = f.LengthM;
                var q = new List<Vec3[]> { new[] { P(0, -a / 2, zt), P(L, -a / 2, zt), P(L, a / 2, zt), P(0, a / 2, zt) } };
                if (!plan)
                {
                    q.Add(new[] { P(0, -a / 2, zb), P(L, -a / 2, zb), P(L, a / 2, zb), P(0, a / 2, zb) });
                    q.Add(new[] { P(0, -a / 2, zb), P(L, -a / 2, zb), P(L, -a / 2, zt), P(0, -a / 2, zt) });
                    q.Add(new[] { P(L, -a / 2, zb), P(L, a / 2, zb), P(L, a / 2, zt), P(L, -a / 2, zt) });
                    q.Add(new[] { P(L, a / 2, zb), P(0, a / 2, zb), P(0, a / 2, zt), P(L, a / 2, zt) });
                    q.Add(new[] { P(0, a / 2, zb), P(0, -a / 2, zb), P(0, -a / 2, zt), P(0, a / 2, zt) });
                }
                Quads(q, fill, edge);
                var fkey = ElementKey.Named(ElementKind.Footing, f.Name);
                foreach (var fq in q) AddFaceHit(fkey, fq, !plan);
                var c = S(P(L / 2, 0, zt).X, P(L / 2, 0, zt).Y, zt);
                Text($"{f.Name}  filante {a:0.00} x {h:0.00} m", c.X - 40, c.Y - 7, 10, edge, null, true);
            }
        }

        // ---- voiles et murs de soutènement
        if (Model.Walls.Count > 0)
        {
            var wc = ElementPalette.Get("Wall");
            var fill = new SolidColorBrush(ElementPalette.WithAlpha(wc, (byte)(plan ? 160 : 225))); fill.Freeze();
            var side = new SolidColorBrush(ElementPalette.WithAlpha(ElementPalette.Shade(wc, 0.7), 235)); side.Freeze();
            var edge = Theme.Fixed(ElementPalette.Shade(wc, 0.35));
            foreach (var w in Model.Walls)
            {
                if (IsObjHidden(w)) continue;
                double ca = Math.Cos(w.AngleDeg * Math.PI / 180), sa = Math.Sin(w.AngleDeg * Math.PI / 180), t2 = w.ThicknessM / 2;
                var wkey = ElementKey.Named(ElementKind.Wall, w.Name);
                Vec3 P(double u, double z, double f) => new(w.X + u * ca - f * sa, w.Y + u * sa + f * ca, w.Z + z);
                if (plan)
                {
                    var topq = new[] { P(0, w.HeightM, -t2), P(w.LengthM, w.HeightM, -t2), P(w.LengthM, w.HeightM, t2), P(0, w.HeightM, t2) };
                    Quads(new[] { topq }, fill, edge, 1.2);
                    AddFaceHit(wkey, topq, false);
                }
                else
                {
                    // face (avec trous d'ouvertures) la plus éloignée, puis rives, puis face la plus proche
                    Geometry FaceGeo(double f)
                    {
                        var g = new StreamGeometry { FillRule = FillRule.EvenOdd };
                        using (var ctx = g.Open())
                        {
                            void Fig(IEnumerable<(double U, double Z)> pts)
                            {
                                var l = pts.Select(p => S(P(p.U, p.Z, f).X, P(p.U, p.Z, f).Y, P(p.U, p.Z, f).Z)).ToList();
                                ctx.BeginFigure(l[0], true, true);
                                foreach (var pt in l.Skip(1)) ctx.LineTo(pt, true, false);
                            }
                            Fig(new[] { (0.0, 0.0), (w.LengthM, 0.0), (w.LengthM, w.HeightM), (0.0, w.HeightM) });
                            foreach (var o in w.Openings) Fig(new[] { (o.XM, o.ZM), (o.XM + o.WidthM, o.ZM), (o.XM + o.WidthM, o.ZM + o.HeightM), (o.XM, o.ZM + o.HeightM) });
                        }
                        g.Freeze();
                        return g;
                    }
                    double dN = V3(P(w.LengthM / 2, w.HeightM / 2, -t2).X, P(w.LengthM / 2, w.HeightM / 2, -t2).Y, P(w.LengthM / 2, w.HeightM / 2, -t2).Z).D;
                    double dP = V3(P(w.LengthM / 2, w.HeightM / 2, t2).X, P(w.LengthM / 2, w.HeightM / 2, t2).Y, P(w.LengthM / 2, w.HeightM / 2, t2).Z).D;
                    double far = dN > dP ? -t2 : t2, near = -far;
                    var pen = new Pen(edge, 0.9); pen.Freeze();
                    void Face(double f) => _c.Children.Add(new System.Windows.Shapes.Path { Data = FaceGeo(f), Fill = fill, Stroke = edge, StrokeThickness = 0.9, IsHitTestVisible = false });
                    Face(far);
                    var rims = new List<Vec3[]>
                    {
                        new[] { P(0, w.HeightM, -t2), P(w.LengthM, w.HeightM, -t2), P(w.LengthM, w.HeightM, t2), P(0, w.HeightM, t2) },
                        new[] { P(0, 0, -t2), P(0, w.HeightM, -t2), P(0, w.HeightM, t2), P(0, 0, t2) },
                        new[] { P(w.LengthM, 0, -t2), P(w.LengthM, w.HeightM, -t2), P(w.LengthM, w.HeightM, t2), P(w.LengthM, 0, t2) },
                    };
                    foreach (var o in w.Openings)
                    {
                        double u0 = o.XM, u1 = o.XM + o.WidthM, z0 = o.ZM, z1 = o.ZM + o.HeightM;
                        rims.Add(new[] { P(u0, z0, -t2), P(u1, z0, -t2), P(u1, z0, t2), P(u0, z0, t2) });
                        rims.Add(new[] { P(u0, z1, -t2), P(u1, z1, -t2), P(u1, z1, t2), P(u0, z1, t2) });
                        rims.Add(new[] { P(u0, z0, -t2), P(u0, z1, -t2), P(u0, z1, t2), P(u0, z0, t2) });
                        rims.Add(new[] { P(u1, z0, -t2), P(u1, z1, -t2), P(u1, z1, t2), P(u1, z0, t2) });
                    }
                    Quads(rims, side, edge, 0.8);
                    Face(near);
                    // zones désignables : les deux faces (avec leurs ouvertures : on peut cliquer à travers) et les rives
                    foreach (double ff in new[] { far, near })
                    {
                        var outline = new[] { P(0, 0, ff), P(w.LengthM, 0, ff), P(w.LengthM, w.HeightM, ff), P(0, w.HeightM, ff) };
                        var holes = w.Openings.Select(o => (IReadOnlyList<Vec3>)new[] { P(o.XM, o.ZM, ff), P(o.XM + o.WidthM, o.ZM, ff), P(o.XM + o.WidthM, o.ZM + o.HeightM, ff), P(o.XM, o.ZM + o.HeightM, ff) }).ToList();
                        AddFaceHit(wkey, outline, true, holes);
                    }
                    foreach (var rim in rims) AddFaceHit(wkey, rim, true);
                }
                var c = S(P(w.LengthM / 2, w.HeightM, 0).X, P(w.LengthM / 2, w.HeightM, 0).Y, w.Z + w.HeightM);
                Text($"{w.Name}{(w.Retaining ? " soutènement" : " voile")}  e={w.ThicknessM * 100:0} cm", c.X - 40, c.Y - 14, 10, edge, null, true);
            }
        }
    }

    /// <summary>Planchers nervurés (poutrelles + hourdis) dont l'emprise est connue : trame de poutrelles dessinée et désignable. Sans emprise, le plancher
    /// reste sélectionnable par la liste (« hors vue ») mais n'est pas dessiné.</summary>
    private void DrawRibbedFloors()
    {
        if (Model == null || Model.RibbedFloors.Count == 0 || !Attr.Slabs) return;
        var c0 = Color.FromRgb(0x8E, 0x6B, 0xBF);
        var fill = new SolidColorBrush(Color.FromArgb(70, c0.R, c0.G, c0.B)); fill.Freeze();
        var edge = Theme.Fixed(ElementPalette.Shade(c0, 0.35));
        var rib = Theme.Fixed(Color.FromArgb(150, c0.R, c0.G, c0.B));
        foreach (var rf in Model.RibbedFloors)
        {
            if (IsObjHidden(rf) || rf.X1 <= rf.X0 + 0.1 || rf.Y1 <= rf.Y0 + 0.1) continue;
            double z = rf.Z;
            var quad = new[] { new Vec3(rf.X0, rf.Y0, z), new Vec3(rf.X1, rf.Y0, z), new Vec3(rf.X1, rf.Y1, z), new Vec3(rf.X0, rf.Y1, z) };
            _c.Children.Add(new Polygon { Points = new PointCollection(quad.Select(v => S(v.X, v.Y, v.Z))), Fill = fill, Stroke = edge, StrokeThickness = 1.2, IsHitTestVisible = false });
            double sp = Math.Max(rf.SpacingM, 0.2);
            bool alongX = rf.RibDirection != 'Y';
            double len = alongX ? rf.Y1 - rf.Y0 : rf.X1 - rf.X0;
            int n = (int)Math.Min(80, Math.Floor(len / sp));
            for (int i = 1; i <= n; i++)
            {
                double t = i * sp;
                var p1 = alongX ? S(rf.X0, rf.Y0 + t, z) : S(rf.X0 + t, rf.Y0, z);
                var p2 = alongX ? S(rf.X1, rf.Y0 + t, z) : S(rf.X0 + t, rf.Y1, z);
                Ln(p1.X, p1.Y, p2.X, p2.Y, rib, 1);
            }
            AddFaceHit(ElementKey.Named(ElementKind.Ribbed, rf.Name), quad, false);
            var cc = S((rf.X0 + rf.X1) / 2, (rf.Y0 + rf.Y1) / 2, z);
            Text($"{rf.Name}  plancher nervuré {rf.TotalHeightCm:0} cm", cc.X - 50, cc.Y - 7, 10, edge, null, true);
        }
    }
}
