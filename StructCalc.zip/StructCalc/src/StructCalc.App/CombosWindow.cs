using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Combinaisons d'actions éditables (G, Q, vent, neige, séisme) et coefficient de frottement pour la stabilité.</summary>
public sealed class CombosWindow : Window
{
    private readonly ObservableCollection<CustomCombo> _rows;
    private readonly DataGrid _grid = new() { AutoGenerateColumns = false, CanUserAddRows = false, Margin = new Thickness(8) };
    private readonly CheckBox _use = new() { Content = "Utiliser ces combinaisons à la place de celles de la norme", Margin = new Thickness(8, 8, 8, 0), FontWeight = FontWeights.SemiBold };
    private readonly TextBox _mu = new() { Width = 60 };
    private readonly Func<IReadOnlyList<Combination>?> _codeCombos;
    public bool UseCustom => _use.IsChecked == true;
    public List<CustomCombo> Result => _rows.ToList();
    public double Friction { get; private set; }

    public CombosWindow(Window owner, StructModel m, Func<IReadOnlyList<Combination>?> codeCombos)
    {
        Owner = owner; _codeCombos = codeCombos;
        Title = "Combinaisons d'actions - " + AppInfo.Name;
        Width = 820; Height = 520; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        _rows = new ObservableCollection<CustomCombo>(m.CustomCombos.Select(c => new CustomCombo { Name = c.Name, State = c.State, G = c.G, Q = c.Q, W = c.W, S = c.S, E = c.E }));
        _use.IsChecked = m.UseCustomCombos;
        _mu.Text = m.BaseFriction.ToString(System.Globalization.CultureInfo.InvariantCulture);
        Friction = m.BaseFriction;

        _grid.Columns.Add(new DataGridTextColumn { Header = "Nom", Binding = new Binding("Name"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        _grid.Columns.Add(new DataGridComboBoxColumn { Header = "État limite", SelectedItemBinding = new Binding("State"), ItemsSource = Enum.GetValues<LimitState>(), Width = 90 });
        foreach (var (h, p) in new[] { ("G (permanent)", "G"), ("Q (exploit.)", "Q"), ("W (vent)", "W"), ("S (neige)", "S"), ("E (séisme)", "E") })
            _grid.Columns.Add(new DataGridTextColumn { Header = h, Binding = new Binding(p) { Mode = BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.LostFocus }, Width = 85 });
        _grid.ItemsSource = _rows;

        var top = new StackPanel();
        top.Children.Add(_use);
        top.Children.Add(new TextBlock
        {
            Text = "Un coefficient 0 = action ignorée ; un coefficient négatif inverse le sens (vent, séisme). Sans ELS, les flèches et la fissuration ne sont pas vérifiées. Une liste vide = combinaisons de la norme.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(8, 4, 8, 0), Foreground = System.Windows.Media.Brushes.Gray
        });

        var bar = new WrapPanel { Margin = new Thickness(8) };
        bar.Children.Add(B("Reprendre celles de la norme", (s, e) => FromCode()));
        bar.Children.Add(B("Ajouter", (s, e) => { _rows.Add(new CustomCombo()); }));
        bar.Children.Add(B("Supprimer la ligne", (s, e) => { if (_grid.SelectedItem is CustomCombo c) _rows.Remove(c); }));
        bar.Children.Add(new TextBlock { Text = "   Frottement semelle/sol μ :", VerticalAlignment = VerticalAlignment.Center });
        bar.Children.Add(_mu);
        var ok = B("OK", (s, e) => Accept()); ok.IsDefault = true;
        var cancel = B("Annuler", (s, e) => DialogResult = false); cancel.IsCancel = true;
        bar.Children.Add(ok); bar.Children.Add(cancel);

        var root = new DockPanel();
        DockPanel.SetDock(top, Dock.Top); DockPanel.SetDock(bar, Dock.Bottom);
        root.Children.Add(top); root.Children.Add(bar); root.Children.Add(_grid);
        Content = root;
    }

    private static Button B(string t, RoutedEventHandler h)
    {
        var b = new Button { Content = t, Padding = new Thickness(12, 3, 12, 3), Margin = new Thickness(0, 0, 6, 0) };
        b.Click += h;
        return b;
    }

    private void FromCode()
    {
        var c = _codeCombos();
        if (c == null) { MessageBox.Show("Aucune norme disponible pour ce projet.", Title); return; }
        if (_rows.Count > 0 && MessageBox.Show("Remplacer la liste actuelle par les combinaisons de la norme ?", Title, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        _rows.Clear();
        foreach (var r in StructCalc.Engine.CombinationSet.FromCode(c)) _rows.Add(r);
    }

    private void Accept()
    {
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        if (!double.TryParse(_mu.Text.Replace(',', '.'), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var mu) || mu <= 0 || mu > 1.5)
        { MessageBox.Show("Le coefficient de frottement doit être compris entre 0 et 1,5 (0,5 pour béton sur sol courant).", Title); return; }
        Friction = mu;
        if (UseCustom && !_rows.Any(r => r.State == LimitState.ELU || r.State == LimitState.Accidental))
        { MessageBox.Show("Ajoutez au moins une combinaison à l'ELU.", Title); return; }
        DialogResult = true;
    }
}
