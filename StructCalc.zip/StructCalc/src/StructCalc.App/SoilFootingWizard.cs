using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;
using StructCalc.Engine.Geotech;

namespace StructCalc.UI;

/// <summary>Assistant sol et semelles : coupe de sol (couches, nappe, sécurité), capacité portante, tassement, semelles isolées et filantes.</summary>
public sealed class SoilFootingWizardWindow : Window
{
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<Func<StructModel, string>, string> _apply;
    private SoilProfile _soil;
    private FootingDef _foot = new();
    private int _layerIdx;
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(8) };
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private readonly ScrollViewer _formHost = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly ComboBox _list = new() { Width = 220 };
    private readonly SheetPreview _preview = new();
    private FormKit _form = null!;
    private bool _busy;

    public SoilFootingWizardWindow(Func<StructModel> model, Func<Func<StructModel, string>, string> apply, FootingDef? seed = null)
    {
        _get = model; _apply = apply;
        Title = "Assistant sol et semelles";
        Width = 1250; Height = 800; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _soil = _model.Soil.Clone();
        if (_soil.Layers.Count == 0) _soil.Layers.Add(new SoilLayer { Name = "Remblai / limon", ThicknessM = 1.0, GammaKnM3 = 17, GammaSatKnM3 = 19, PhiDeg = 20, CKPa = 5, EoedMPa = 5 });
        if (_soil.Layers.Count == 1) _soil.Layers.Add(new SoilLayer { Name = "Argile sableuse", ThicknessM = 0, GammaKnM3 = 19, GammaSatKnM3 = 20, PhiDeg = 25, CKPa = 15, EoedMPa = 12 });
        _foot = seed?.Clone() ?? _model.FootingDefs.FirstOrDefault()?.Clone() ?? NewFoot();

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(480) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Semelle :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        bar.Children.Add(_list);
        bar.Children.Add(new Border { Width = 10 });
        bar.Children.Add(Ui.Btn("➕ Nouvelle", (s, e) => { _foot = NewFoot(); FillList(); RebuildForm(); Recompute(); }));
        bar.Children.Add(Ui.Btn("💾 Enregistrer sol + semelle", (s, e) => Save(), true));
        bar.Children.Add(Ui.Btn("🗑 Supprimer la semelle", (s, e) => Delete()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);
        var tabs = new TabControl { Margin = new Thickness(4) };
        tabs.Items.Add(new TabItem { Header = "Plan ferraillé", Content = _preview });
        tabs.Items.Add(new TabItem { Header = "Note de calcul", Content = _report });
        Grid.SetRow(tabs, 1); Grid.SetColumn(tabs, 1); root.Children.Add(tabs);
        Content = root;
        _list.SelectionChanged += (s, e) =>
        {
            if (_busy) return; int i = _list.SelectedIndex;
            if (i >= 0 && i < _model.FootingDefs.Count) { _foot = _model.FootingDefs[i].Clone(); RebuildForm(); Recompute(); }
        };
        FillList(); RebuildForm();
        Loaded += (s, e) => Recompute();
    }

    private FootingDef NewFoot()
    {
        int n = 1; while (_model.FootingDefs.Any(x => x.Name == "S" + n)) n++;
        return new FootingDef { Name = "S" + n };
    }

    private void FillList()
    {
        _busy = true; _list.Items.Clear();
        foreach (var f in _model.FootingDefs) _list.Items.Add($"{f.Name} - {(f.Kind == FootingKind.Isolee ? "isolée" : "filante")}");
        if (!_model.FootingDefs.Any(x => x.Name == _foot.Name)) _list.Items.Add($"{_foot.Name} (nouvelle)");
        int idx = _model.FootingDefs.FindIndex(x => x.Name == _foot.Name);
        _list.SelectedIndex = idx >= 0 ? idx : _list.Items.Count - 1;
        _busy = false;
    }

    private void RebuildForm()
    {
        _form = new FormKit();
        _form.Section("Coupe de sol", "Les paramètres viennent du rapport géotechnique : φ et c effectifs, γ, module œdométrique (ou Cc et e0). Pour une argile saturée en court terme, φ = 0 et c = cu.");
        _form.Num("Profondeur d'assise D (sous le terrain naturel)", () => _soil.FoundationDepthM, v => _soil.FoundationDepthM = v, null, "m");
        _form.Num("Profondeur de la nappe (< 0 = aucune)", () => _soil.WaterDepthM, v => _soil.WaterDepthM = v, null, "m");
        _form.Num("Coefficient de sécurité Fs (ELS)", () => _soil.FsServ, v => _soil.FsServ = v, "3 selon DTU 13.12", "");
        _form.Check("Vérifier le tassement", () => _soil.CheckSettlement, v => _soil.CheckSettlement = v);
        _form.Num("Tassement admissible", () => _soil.SettlementLimitMm, v => _soil.SettlementLimitMm = v, "25 mm usuel (semelles isolées)", "mm");
        _form.Combo("Couche à éditer", _soil.Layers.Select((ly, i) => ($"{i + 1} - {ly.Name}", i)).ToList(), () => Math.Min(_layerIdx, _soil.Layers.Count - 1), v => { _layerIdx = v; Rebuild2(); });
        var l = _soil.Layers[Math.Min(_layerIdx, _soil.Layers.Count - 1)];
        _form.Text("Nom", () => l.Name, v => l.Name = v);
        _form.Num("Épaisseur (0 = semi-infinie)", () => l.ThicknessM, v => l.ThicknessM = v, null, "m");
        _form.Num("γ humide", () => l.GammaKnM3, v => l.GammaKnM3 = v, null, "kN/m³");
        _form.Num("γ saturé", () => l.GammaSatKnM3, v => l.GammaSatKnM3 = v, null, "kN/m³");
        _form.Num("Angle de frottement φ", () => l.PhiDeg, v => l.PhiDeg = v, "0 pour une argile en non drainé", "°");
        _form.Num("Cohésion c (ou cu)", () => l.CKPa, v => l.CKPa = v, null, "kPa");
        _form.Num("Module œdométrique Eoed", () => l.EoedMPa, v => l.EoedMPa = v, null, "MPa");
        _form.Num("Indice de compression Cc (0 = Eoed)", () => l.Cc, v => l.Cc = v, null, "");
        _form.Num("Indice des vides e0", () => l.E0, v => l.E0 = v, null, "");
        _form.Add(Ui.Btn("➕ Ajouter une couche", (s, e) => { _soil.Layers.Add(new SoilLayer { Name = "Couche " + (_soil.Layers.Count + 1) }); _layerIdx = _soil.Layers.Count - 1; Rebuild2(); }));
        _form.Add(Ui.Btn("➖ Supprimer cette couche", (s, e) => { if (_soil.Layers.Count > 1) { _soil.Layers.RemoveAt(Math.Min(_layerIdx, _soil.Layers.Count - 1)); _layerIdx = 0; Rebuild2(); } }));

        var f = _foot;
        _form.Section("Semelle");
        _form.Text("Nom", () => f.Name, v => f.Name = v);
        _form.Combo("Type", new (string, FootingKind)[] { ("Isolée sous poteau", FootingKind.Isolee), ("Filante sous voile (par mètre)", FootingKind.Filante) }, () => f.Kind, v => { bool ch = f.Kind != v; f.Kind = v; if (ch) Dispatcher.BeginInvoke(new Action(RebuildForm)); });
        _form.Num("Poteau a (ou épaisseur du voile)", () => f.ColA, v => f.ColA = v, null, "m");
        _form.Num("Poteau b (isolée)", () => f.ColB, v => f.ColB = v, null, "m");
        _form.Num("Nu (ELU)", () => f.NuKN, v => f.NuKN = v, "kN, ou kN/m pour une filante", "kN");
        _form.Num("Nser (ELS)", () => f.NserKN, v => f.NserKN = v, null, "kN");
        if (f.Kind == FootingKind.Filante)
        {
            _form.Section("Murs portés par la semelle", "Chaque mur ou charge linéaire de la bibliothèque s'ajoute à Nu et Nser ci-dessus (1,35 G + 1,5 Q à l'ELU, G + Q à l'ELS).");
            foreach (var wl in f.WallLoads.ToList())
            {
                var item = wl;
                _form.Add(new TextBlock { Text = $"• {item.Text} : G = {item.GKnM:0.##}, Q = {item.QKnM:0.##} kN/m", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4, 2, 4, 2) });
                _form.Add(Ui.Btn("➖ Retirer cette charge", (s, e) => { f.WallLoads.Remove(item); RebuildForm(); Recompute(); }));
            }
            _form.Add(Ui.Btn("➕ Ajouter un mur depuis la bibliothèque...", (s, e) =>
            {
                var r = FoundationLineLoads.Ask(this, false);
                if (r == null) return;
                f.WallLoads.Add(new LineLoadItem { Text = r.Text, GKnM = r.G, QKnM = r.Q });
                RebuildForm(); Recompute();
            }));
            var tot = f.WithWallLoads();
            _form.Add(new TextBlock { Text = $"Total par mètre : Nu = {tot.NuKN:0.#} kN/m, Nser = {tot.NserKN:0.#} kN/m", FontWeight = FontWeights.SemiBold, Margin = new Thickness(4, 6, 4, 4) });
        }
        _form.Num("Moment ELS sens A", () => f.MaKNm, v => f.MaKNm = v, "Excentrement ; entraîne la vérification de Meyerhof", "kN.m");
        _form.Num("Moment ELS sens B", () => f.MbKNm, v => f.MbKNm = v, null, "kN.m");
        _form.Num("Profondeur propre (0 = D du sol)", () => f.DepthM, v => f.DepthM = v, null, "m");
        _form.Num("Dimension A imposée (0 = auto)", () => f.FixedA, v => f.FixedA = v, null, "m");
        _form.Num("Dimension B imposée (0 = auto)", () => f.FixedB, v => f.FixedB = v, null, "m");
        _form.Check("Semelle à glacis (dessus en pente, bord vertical mince)", () => f.Glacis, v => f.Glacis = v);
        _form.Num("Glacis : épaisseur au bord", () => f.GlacisEdgeCm, v => f.GlacisEdgeCm = v, "20 cm usuel ; le dessus monte en pente jusqu'à un plateau (poteau + 10 cm) ; isolée seulement", "cm");
        _form.Num("q admissible imposée (sans sol)", () => f.QAdmOverrideKPa, v => f.QAdmOverrideKPa = v, "> 0 : ignore la coupe de sol", "kPa");
        _form.Changed += Recompute;
        _formHost.Content = _form.Root;
    }

    private void Rebuild2() { RebuildForm(); Recompute(); }

    private void Recompute()
    {
        try
        {
            var rc = (DesignCodeRegistry.Get(_model.RcCodeId) as IReinforcedConcreteCode) ?? (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
            var r = FootingSizer.Design(_foot, _soil, rc, _model.Fc28, _model.Fe, _model.Settings.CoverFootingCm / 100.0, _model.Settings);
            var sb = new System.Text.StringBuilder(r.Report);
            sb.AppendLine();
            sb.AppendLine("--- Capacité portante en fonction de la largeur (aperçu de la coupe de sol) ---");
            foreach (double bb in new[] { 0.6, 1.0, 1.5, 2.0, 3.0 })
            {
                var br = SoilMechanics.Bearing(_soil, bb, bb, _foot.DepthM > 0 ? _foot.DepthM : _soil.FoundationDepthM);
                var st = SoilMechanics.Settlement(_soil, bb, bb, _foot.DepthM > 0 ? _foot.DepthM : _soil.FoundationDepthM, Math.Max(br.QAdm - br.Q0, 0));
                sb.AppendLine($"  B = {bb:0.0} m : qu = {br.Qu:0} kPa, qadm = {br.QAdm:0} kPa, tassement sous qadm ≈ {st.TotalMm:0.0} mm");
            }
            _report.Text = sb.ToString();
            ShowSheet(r);
            _status.Text = r.Ok ? "✔ Conforme" : "⚠ " + (r.Design.Warnings.FirstOrDefault() ?? "À vérifier");
            _status.Foreground = r.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
        }
        catch (Exception ex) { _status.Text = "Erreur : " + ex.Message; _status.Foreground = Brushes.Firebrick; }
    }

    /// <summary>Plan de ferraillage de la semelle (plan, coupe, nappes) à partir du dimensionnement courant.</summary>
    private void ShowSheet(FootingSizing r)
    {
        Sheet? sh = null;
        try
        {
            if (_foot.Kind == FootingKind.Isolee && r.Design.Values.ContainsKey("A_m"))
            {
                var tmp = new StructModel { Settings = _model.Settings };
                tmp.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 }); tmp.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 3 });
                tmp.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, B = _foot.ColA, H = _foot.ColB });
                var dr = r.Design;
                dr.Element = $"Semelle {_foot.Name} - nœud 1";
                var o = new AnalysisOutput(); o.Footings.Add(dr);
                sh = RcSheets.Footings(tmp, o, new List<BarLine>()).FirstOrDefault();
            }
        }
        catch { sh = null; }
        if (sh != null) { sh.Number = "-"; _preview.Show(sh); }
        else _preview.Show(new Sheet { Name = "-", Title = _foot.Kind == FootingKind.Filante
            ? "Semelle filante : le dimensionnement figure dans la note de calcul (le plan s'affiche pour une semelle isolée)."
            : "Plan de ferraillage indisponible : complétez le sol et les charges (voir la note de calcul)." });
    }

    private void Save()
    {
        var soil = _soil.Clone(); var f = _foot.Clone();
        _status.Text = _apply(m =>
        {
            m.Soil = soil;
            int i = m.FootingDefs.FindIndex(x => x.Name == f.Name);
            if (i >= 0) m.FootingDefs[i] = f; else m.FootingDefs.Add(f);
            return $"Sol et semelle {f.Name} enregistrés (les semelles sous poteaux du modèle utilisent aussi ce sol au prochain calcul).";
        });
        _status.Foreground = Brushes.DarkGreen; FillList();
    }

    private void Delete()
    {
        string n = _foot.Name;
        if (!_model.FootingDefs.Any(x => x.Name == n)) return;
        _apply(m => { m.FootingDefs.RemoveAll(x => x.Name == n); return $"Semelle {n} supprimée."; });
        _foot = _model.FootingDefs.FirstOrDefault()?.Clone() ?? NewFoot();
        FillList(); RebuildForm(); Recompute();
    }
}
