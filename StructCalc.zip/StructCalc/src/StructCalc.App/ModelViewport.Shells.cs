using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;

namespace StructCalc.UI;

/// <summary>Coques du modèle 3D (voiles et dalles maillés) : dessin des éléments.</summary>
public sealed partial class ModelViewport
{
    private void DrawShells(Dictionary<int, Node> nodes)
    {
        if (Model == null || Model.Shells.Count == 0) return;
        var wallC = ElementPalette.Get("Wall"); var slabC = ElementPalette.Get("Slab");
        var wallFill = new SolidColorBrush(ElementPalette.WithAlpha(wallC, 80)); wallFill.Freeze();
        var slabFill = new SolidColorBrush(ElementPalette.WithAlpha(slabC, 70)); slabFill.Freeze();
        var wallEdge = Theme.Fixed(ElementPalette.Shade(wallC, 0.3)); var slabEdge = Theme.Fixed(ElementPalette.Shade(slabC, 0.35));
        foreach (var s in Model.Shells)
        {
            if (IsObjHidden(s)) continue;
            if (!nodes.TryGetValue(s.N1, out var a) || !nodes.TryGetValue(s.N2, out var b) || !nodes.TryGetValue(s.N3, out var c) || !nodes.TryGetValue(s.N4, out var d)) continue;
            bool wall = s.Kind == "Voile";
            AddFaceHit(ElementKey.Named(ElementKind.Shell, s.Name), new[] { new Vec3(a.X, a.Y, a.Z), new Vec3(b.X, b.Y, b.Z), new Vec3(c.X, c.Y, c.Z), new Vec3(d.X, d.Y, d.Z) });
            _c.Children.Add(new Polygon
            {
                Points = new PointCollection { S(a), S(b), S(c), S(d) },
                Fill = wall ? wallFill : slabFill, Stroke = wall ? wallEdge : slabEdge, StrokeThickness = 0.7, IsHitTestVisible = false
            });
        }
    }

    /// <summary>Coque (voile ou dalle maillé) sous le point écran donné ; null si aucune.</summary>
    private ShellPanel? ShellAt(Point p)
    {
        if (Model == null || Model.Shells.Count == 0) return null;
        var nodes = Model.Nodes.ToDictionary(n => n.Id);
        ShellPanel? hit = null;
        foreach (var s in Model.Shells)
        {
            if (IsObjHidden(s)) continue;
            if (!nodes.TryGetValue(s.N1, out var a) || !nodes.TryGetValue(s.N2, out var b) || !nodes.TryGetValue(s.N3, out var c) || !nodes.TryGetValue(s.N4, out var d)) continue;
            var q = new[] { S(a), S(b), S(c), S(d) };
            bool inside = false;
            for (int i = 0, j = 3; i < 4; j = i++)
                if ((q[i].Y > p.Y) != (q[j].Y > p.Y) && p.X < (q[j].X - q[i].X) * (p.Y - q[i].Y) / (q[j].Y - q[i].Y) + q[i].X) inside = !inside;
            if (inside) hit = s;
        }
        return hit;
    }
}
