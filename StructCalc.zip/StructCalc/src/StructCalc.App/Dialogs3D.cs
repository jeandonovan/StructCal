using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

internal static class Ui
{
    public static double Num(string? s, double def = double.NaN) =>
        double.TryParse((s ?? "").Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double v) ? v : def;
    public static string Fmt(double v) => v.ToString("0.####", CultureInfo.InvariantCulture);

    public static Button Btn(string text, RoutedEventHandler click, bool def = false)
    {
        var b = new Button { Content = text, Padding = new Thickness(12, 5, 12, 5), Margin = new Thickness(0, 0, 8, 0), IsDefault = def };
        b.Click += click;
        return b;
    }
}

/// <summary>Petite fenêtre qui demande une ou plusieurs valeurs.</summary>
public sealed class PromptWindow : Window
{
    private readonly List<TextBox> _boxes = new();
    public string[] Values => _boxes.Select(b => b.Text).ToArray();

    public PromptWindow(string title, string intro, params (string Label, string Default)[] fields)
    {
        Title = title; Width = 460; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new StackPanel { Margin = new Thickness(16) };
        root.Children.Add(new TextBlock { Text = intro, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });
        foreach (var f in fields)
        {
            var row = new Grid { Margin = new Thickness(0, 3, 0, 3) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(250) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            var t = new TextBlock { Text = f.Label, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap };
            var b = new TextBox { Text = f.Default, Padding = new Thickness(3) };
            Grid.SetColumn(b, 1);
            row.Children.Add(t); row.Children.Add(b);
            root.Children.Add(row); _boxes.Add(b);
        }
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        var cancel = new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true };
        buttons.Children.Add(Ui.Btn("OK", (s, e) => DialogResult = true, true)); buttons.Children.Add(cancel);
        root.Children.Add(buttons);
        Content = root;
        Loaded += (s, e) => { if (_boxes.Count > 0) { _boxes[0].Focus(); _boxes[0].SelectAll(); } };
    }

    public static string[]? Ask(Window? owner, string title, string intro, params (string Label, string Default)[] fields)
    {
        var w = new PromptWindow(title, intro, fields) { Owner = owner };
        return w.ShowDialog() == true ? w.Values : null;
    }
}

// =====================================================================================================  ÉTAGES
public sealed class LevelRow : INotifyPropertyChanged
{
    private string _name = "", _z = "0";
    public string Name { get => _name; set { _name = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name))); } }
    public string Z { get => _z; set { _z = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Z))); } }
    public double? OriginalZ { get; set; }
    private string _h = "";
    public string HeightText { get => _h; set { _h = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HeightText))); } }
    public event PropertyChangedEventHandler? PropertyChanged;
}

/// <summary>Définition des étages (niveaux) : tableau modifiable, génération régulière, détection depuis le modèle, déplacement des nœuds avec le niveau.</summary>
public sealed class LevelsWindow : Window
{
    private readonly StructModel _m;
    private readonly ObservableCollection<LevelRow> _rows = new();
    private readonly DataGrid _grid = new();
    private readonly CheckBox _moveNodes = new() { Content = "Déplacer nœuds, dalles et charges quand je change une cote ou une hauteur", IsChecked = true, Margin = new Thickness(0, 8, 0, 0) };
    private readonly Dictionary<string, TextBox> _f = new();
    private const string HeightHeader = "Hauteur jusqu'au niveau suivant";
    public List<StoreyDef> Result { get; private set; } = new();
    public bool MoveNodes => _moveNodes.IsChecked == true;
    public List<(double From, double To)> Moves { get; } = new();

    public LevelsWindow(StructModel m)
    {
        _m = m;
        Title = "Étages (niveaux)";
        Width = 760; Height = 520; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new Grid { Margin = new Thickness(14) };
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(260) });
        root.RowDefinitions.Add(new RowDefinition());
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        _grid.AutoGenerateColumns = false; _grid.CanUserAddRows = false; _grid.ItemsSource = _rows;
        _grid.Columns.Add(new DataGridTextColumn { Header = "Nom du niveau", Binding = new Binding("Name"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        _grid.Columns.Add(new DataGridTextColumn { Header = "Cote Z (m)", Binding = new Binding("Z"), Width = 100 });
        _grid.Columns.Add(new DataGridTextColumn { Header = HeightHeader, Binding = new Binding("HeightText"), Width = 190 });
        _grid.CellEditEnding += (s, e) =>
        {
            // la colonne « Hauteur » est modifiable : les niveaux au-dessus suivent (hauteur d'étage = écart de cote avec le niveau suivant)
            if (e.EditAction == DataGridEditAction.Commit && e.Row.Item is LevelRow row && Equals(e.Column.Header, HeightHeader) && e.EditingElement is TextBox tb)
                ApplyHeight(row, tb.Text);
            Dispatcher.BeginInvoke(new Action(Recalc), System.Windows.Threading.DispatcherPriority.Background);
        };
        Grid.SetRow(_grid, 0); root.Children.Add(_grid);

        var side = new StackPanel { Margin = new Thickness(14, 0, 0, 0) };
        side.Children.Add(new TextBlock { Text = "Générer des étages réguliers", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 6) });
        void Field(string label, string key, string def)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) }); g.ColumnDefinitions.Add(new ColumnDefinition());
            var t = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap };
            var b = new TextBox { Text = def, Padding = new Thickness(3) };
            Grid.SetColumn(b, 1); g.Children.Add(t); g.Children.Add(b); side.Children.Add(g); _f[key] = b;
        }
        Field("Nombre d'étages", "n", "4");
        Field("Cote de la base (m)", "z0", "0");
        Field("Hauteurs (m) : une valeur ou une liste", "h", "3.5 3 3");
        side.Children.Add(new TextBlock { Text = "Ex. « 3.5 3 » : RDC 3,5 m puis 3 m pour tous les suivants.", FontSize = 10.5, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 4) });
        side.Children.Add(Ui.Btn("Générer (remplace la liste)", (s, e) => Generate()));
        side.Children.Add(new Separator { Margin = new Thickness(0, 10, 0, 10) });
        side.Children.Add(Ui.Btn("Ajouter un niveau au-dessus", (s, e) => AddAbove()));
        side.Children.Add(new Border { Height = 6 });
        side.Children.Add(Ui.Btn("Supprimer la ligne choisie", (s, e) => { if (_grid.SelectedItem is LevelRow r) { _rows.Remove(r); Recalc(); } }));
        side.Children.Add(new Border { Height = 6 });
        side.Children.Add(Ui.Btn("Détecter depuis le modèle", (s, e) => Detect()));
        side.Children.Add(new Border { Height = 6 });
        side.Children.Add(Ui.Btn("Tout effacer (détection automatique)", (s, e) => _rows.Clear()));
        side.Children.Add(_moveNodes);
        side.Children.Add(new TextBlock
        {
            Text = "Astuce : écrivez directement dans la colonne « Hauteur jusqu'au niveau suivant » ; les niveaux au-dessus se décalent, avec leurs nœuds, dalles et charges. Un niveau défini ici apparaît dans l'arborescence, dans les vues et sert de repère d'accrochage. Sans niveau défini, StructCalc les détecte à partir des nœuds.",
            FontSize = 10.5, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 10, 0, 0)
        });
        Grid.SetColumn(side, 1); root.Children.Add(side);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        buttons.Children.Add(Ui.Btn("OK", (s, e) => Accept(), true));
        buttons.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true });
        Grid.SetRow(buttons, 1); Grid.SetColumnSpan(buttons, 2); root.Children.Add(buttons);
        Content = root;

        foreach (var l in m.Levels.OrderBy(x => x.Elevation)) _rows.Add(new LevelRow { Name = l.Name, Z = Ui.Fmt(l.Elevation), OriginalZ = l.Elevation });
        Recalc();
    }

    /// <summary>Hauteur saisie pour un étage : les cotes des niveaux au-dessus sont décalées de la différence.</summary>
    private void ApplyHeight(LevelRow row, string text)
    {
        double h = Ui.Num((text ?? "").Replace("m", "").Replace("M", "").Trim(), double.NaN);
        var ordered = _rows.Select(r => (Row: r, Z: Ui.Num(r.Z))).Where(x => !double.IsNaN(x.Z)).OrderBy(x => x.Z).ToList();
        int i = ordered.FindIndex(x => ReferenceEquals(x.Row, row));
        if (i < 0 || i + 1 >= ordered.Count || double.IsNaN(h) || h < 0.2 || h > 30) return;      // dernier niveau ou saisie invalide : ignoré
        double delta = h - (ordered[i + 1].Z - ordered[i].Z);
        if (Math.Abs(delta) < 1e-9) return;
        for (int j = i + 1; j < ordered.Count; j++) ordered[j].Row.Z = Ui.Fmt(ordered[j].Z + delta);
    }

    private void Recalc()
    {
        var list = _rows.Select(r => (Row: r, Z: Ui.Num(r.Z))).ToList();
        var ordered = list.Where(x => !double.IsNaN(x.Z)).OrderBy(x => x.Z).ToList();
        foreach (var r in _rows) r.HeightText = "";
        for (int i = 0; i + 1 < ordered.Count; i++) ordered[i].Row.HeightText = Ui.Fmt(ordered[i + 1].Z - ordered[i].Z) + " m";
    }

    private void Generate()
    {
        int n = (int)Ui.Num(_f["n"].Text, 0);
        double z0 = Ui.Num(_f["z0"].Text, 0);
        var hs = GridTools.ParseSpacings(_f["h"].Text, out string err);
        if (n < 1 || n > 80 || err != "") { MessageBox.Show(err != "" ? err : "Nombre d'étages entre 1 et 80.", "Étages", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        var list = GridTools.GenerateStoreys(n, z0, hs);
        _rows.Clear();
        foreach (var l in list) _rows.Add(new LevelRow { Name = l.Name, Z = Ui.Fmt(l.Elevation) });
        Recalc();
    }

    private void AddAbove()
    {
        var zs = _rows.Select(r => Ui.Num(r.Z)).Where(v => !double.IsNaN(v)).OrderBy(v => v).ToList();
        double top = zs.Count > 0 ? zs[^1] : 0;
        double h = zs.Count > 1 ? zs[^1] - zs[^2] : 3.0;
        _rows.Add(new LevelRow { Name = $"Niveau {_rows.Count}", Z = Ui.Fmt(top + h) });
        Recalc();
    }

    private void Detect()
    {
        var tmp = new StructModel();
        foreach (var n in _m.Nodes) tmp.Nodes.Add(n);
        foreach (var mm in _m.Members) tmp.Members.Add(mm);
        var info = StructureAnalyzer.Analyze(tmp);
        _rows.Clear();
        foreach (var l in info.Levels) _rows.Add(new LevelRow { Name = l.Name, Z = Ui.Fmt(l.Z), OriginalZ = l.Z });
        Recalc();
    }

    private void Accept()
    {
        var res = new List<StoreyDef>();
        foreach (var r in _rows)
        {
            double z = Ui.Num(r.Z);
            if (double.IsNaN(z)) { MessageBox.Show($"La cote « {r.Z} » du niveau « {r.Name} » est invalide.", "Étages", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            res.Add(new StoreyDef { Name = string.IsNullOrWhiteSpace(r.Name) ? "Niveau" : r.Name.Trim(), Elevation = z });
            if (r.OriginalZ is double oz && Math.Abs(oz - z) > 1e-6) Moves.Add((oz, z));
        }
        if (res.Select(x => Math.Round(x.Elevation, 4)).Distinct().Count() != res.Count)
        { MessageBox.Show("Deux niveaux ont la même cote.", "Étages", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        Result = res.OrderBy(x => x.Elevation).ToList();
        DialogResult = true;
    }

    /// <summary>Déplace les nœuds situés sur un niveau dont la cote a changé (à appeler après OK, si MoveNodes).</summary>
    public int ApplyMoves(StructModel m)
    {
        if (!MoveNodes || Moves.Count == 0) return 0;
        int moved = 0;
        var newZ = new Dictionary<int, double>();
        foreach (var n in m.Nodes)
        {
            foreach (var mv in Moves)
                if (Math.Abs(n.Z - mv.From) <= 0.05) { newZ[n.Id] = mv.To; break; }
        }
        foreach (var sl in m.SurfaceLoads)
            foreach (var mv in Moves)
                if (Math.Abs(sl.Z - mv.From) <= 0.05) { sl.Z = mv.To; break; }          // les charges surfaciques suivent leur niveau
        foreach (var sb in m.Slabs.Where(q => q.Placed))
            foreach (var mv in Moves)
                if (Math.Abs(sb.Z - mv.From) <= 0.05) { sb.Z = mv.To; break; }          // les dalles dessinées suivent leur niveau
        foreach (var rf in m.RibbedFloors)
            foreach (var mv in Moves)
                if (Math.Abs(rf.Z - mv.From) <= 0.05) { rf.Z = mv.To; break; }
        StructCalc.Engine.Structure.StoreyOps.SyncAllSlabLoads(m);                      // charges des dalles régénérées à leur nouvelle cote
        foreach (var n in m.Nodes) if (newZ.TryGetValue(n.Id, out double nz) && Math.Abs(n.Z - nz) > 1e-9) { n.Z = nz; moved++; }
        return moved;
    }
}

// =====================================================================================================  GRILLE
public sealed class AxisRow
{
    public string Name { get; set; } = "";
    public string Pos { get; set; } = "0";
}

/// <summary>Définition de la grille de construction (axes numérotés X et lettrés Y), avec génération à partir de travées « 3x5 4.5 ».</summary>
public sealed class GridWindow : Window
{
    private readonly StructModel _m;
    private readonly ObservableCollection<AxisRow> _x = new(), _y = new();
    private readonly TextBox _xo = new() { Text = "0" }, _yo = new() { Text = "0" }, _xs = new() { Text = "3x5" }, _ys = new() { Text = "2x6" };
    public GridDef Result { get; private set; } = new();

    public GridWindow(StructModel m)
    {
        _m = m;
        Title = "Grille de construction (axes)";
        Width = 800; Height = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new Grid { Margin = new Thickness(14) };
        root.ColumnDefinitions.Add(new ColumnDefinition()); root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) }); root.ColumnDefinitions.Add(new ColumnDefinition());
        root.RowDefinitions.Add(new RowDefinition()); root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var left = Block("Axes numérotés (1, 2, 3...) — lignes parallèles à Y", _x, _xo, _xs, true);
        var right = Block("Axes lettrés (A, B, C...) — lignes parallèles à X", _y, _yo, _ys, false);
        Grid.SetColumn(right, 2);
        root.Children.Add(left); root.Children.Add(right);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        buttons.Children.Add(Ui.Btn("Détecter depuis le modèle", (s, e) => Detect()));
        buttons.Children.Add(Ui.Btn("Tout effacer (détection automatique)", (s, e) => { _x.Clear(); _y.Clear(); }));
        buttons.Children.Add(Ui.Btn("OK", (s, e) => Accept(), true));
        buttons.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true });
        Grid.SetRow(buttons, 1); Grid.SetColumnSpan(buttons, 3); root.Children.Add(buttons);
        Content = root;

        foreach (var ax in m.Grid.XAxes.OrderBy(q => q.Pos)) _x.Add(new AxisRow { Name = ax.Name, Pos = Ui.Fmt(ax.Pos) });
        foreach (var ay in m.Grid.YAxes.OrderBy(q => q.Pos)) _y.Add(new AxisRow { Name = ay.Name, Pos = Ui.Fmt(ay.Pos) });
        if (m.Grid.XAxes.Count > 1) _xs.Text = GridTools.SpacingText(m.Grid.XAxes);
        if (m.Grid.YAxes.Count > 1) _ys.Text = GridTools.SpacingText(m.Grid.YAxes);
    }

    private FrameworkElement Block(string title, ObservableCollection<AxisRow> rows, TextBox origin, TextBox spacing, bool numbered)
    {
        var p = new DockPanel();
        var top = new StackPanel { Margin = new Thickness(0, 0, 0, 8) };
        top.Children.Add(new TextBlock { Text = title, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 6), TextWrapping = TextWrapping.Wrap });
        var g = new Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) }); g.ColumnDefinitions.Add(new ColumnDefinition());
        g.RowDefinitions.Add(new RowDefinition()); g.RowDefinitions.Add(new RowDefinition());
        var t1 = new TextBlock { Text = "Origine (m)", VerticalAlignment = VerticalAlignment.Center };
        var t2 = new TextBlock { Text = "Travées (m)", VerticalAlignment = VerticalAlignment.Center };
        origin.Padding = new Thickness(3); origin.Margin = new Thickness(0, 2, 0, 2); spacing.Padding = new Thickness(3); spacing.Margin = new Thickness(0, 2, 0, 2);
        Grid.SetColumn(origin, 1); Grid.SetRow(t2, 1); Grid.SetRow(spacing, 1); Grid.SetColumn(spacing, 1);
        g.Children.Add(t1); g.Children.Add(origin); g.Children.Add(t2); g.Children.Add(spacing);
        top.Children.Add(g);
        top.Children.Add(new TextBlock { Text = "Ex. « 3x5 4.5 2x6 » = trois travées de 5 m, une de 4,5 m, deux de 6 m.", FontSize = 10.5, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap });
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
        bar.Children.Add(Ui.Btn("Générer (remplace)", (s, e) => Generate(rows, origin, spacing, numbered)));
        bar.Children.Add(Ui.Btn("+ axe", (s, e) =>
        {
            double last = rows.Count > 0 ? Ui.Num(rows[^1].Pos, 0) : 0;
            double sp = rows.Count > 1 ? last - Ui.Num(rows[^2].Pos, 0) : 5;
            int i = rows.Count;
            rows.Add(new AxisRow { Name = numbered ? (i + 1).ToString() : StructureAnalyzer.AlphaName(i), Pos = Ui.Fmt(last + sp) });
        }));
        bar.Children.Add(Ui.Btn("− axe", (s, e) => { if (rows.Count > 0) rows.RemoveAt(rows.Count - 1); }));
        top.Children.Add(bar);
        DockPanel.SetDock(top, Dock.Top);
        p.Children.Add(top);
        var dg = new DataGrid { AutoGenerateColumns = false, CanUserAddRows = false, ItemsSource = rows };
        dg.Columns.Add(new DataGridTextColumn { Header = "Nom", Binding = new Binding("Name"), Width = 90 });
        dg.Columns.Add(new DataGridTextColumn { Header = numbered ? "Position x (m)" : "Position y (m)", Binding = new Binding("Pos"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
        p.Children.Add(dg);
        return p;
    }

    private void Generate(ObservableCollection<AxisRow> rows, TextBox origin, TextBox spacing, bool numbered)
    {
        var sp = GridTools.ParseSpacings(spacing.Text, out string err);
        if (err != "") { MessageBox.Show(err, "Grille", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        double o = Ui.Num(origin.Text, 0);
        var axes = GridTools.BuildAxes(o, sp, numbered);
        rows.Clear();
        foreach (var a in axes) rows.Add(new AxisRow { Name = a.Name, Pos = Ui.Fmt(a.Pos) });
    }

    private void Detect()
    {
        var tmp = new StructModel();
        foreach (var n in _m.Nodes) tmp.Nodes.Add(n);
        foreach (var mm in _m.Members) tmp.Members.Add(mm);
        var info = StructureAnalyzer.Analyze(tmp);
        _x.Clear(); _y.Clear();
        foreach (var a in info.XAxes) _x.Add(new AxisRow { Name = a.Name, Pos = Ui.Fmt(a.Pos) });
        foreach (var a in info.YAxes) _y.Add(new AxisRow { Name = a.Name, Pos = Ui.Fmt(a.Pos) });
        if (info.XAxes.Count > 1) _xs.Text = GridTools.SpacingText(info.XAxes.Select(a => new AxisDef { Name = a.Name, Pos = a.Pos }).ToList());
        if (info.YAxes.Count > 1) _ys.Text = GridTools.SpacingText(info.YAxes.Select(a => new AxisDef { Name = a.Name, Pos = a.Pos }).ToList());
    }

    private bool Read(ObservableCollection<AxisRow> rows, List<AxisDef> into, string what)
    {
        foreach (var r in rows)
        {
            double p = Ui.Num(r.Pos);
            if (double.IsNaN(p)) { MessageBox.Show($"Position « {r.Pos} » invalide ({what} {r.Name}).", "Grille", MessageBoxButton.OK, MessageBoxImage.Warning); return false; }
            into.Add(new AxisDef { Name = string.IsNullOrWhiteSpace(r.Name) ? "?" : r.Name.Trim(), Pos = p });
        }
        if (into.Select(a => Math.Round(a.Pos, 4)).Distinct().Count() != into.Count)
        { MessageBox.Show($"Deux axes {what} ont la même position.", "Grille", MessageBoxButton.OK, MessageBoxImage.Warning); return false; }
        return true;
    }

    private void Accept()
    {
        var g = new GridDef();
        if (!Read(_x, g.XAxes, "numérotés") || !Read(_y, g.YAxes, "lettrés")) return;
        g.XAxes = g.XAxes.OrderBy(a => a.Pos).ToList(); g.YAxes = g.YAxes.OrderBy(a => a.Pos).ToList();
        Result = g;
        DialogResult = true;
    }
}

// =====================================================================================================  OSSATURE DEPUIS LA GRILLE
public sealed class FrameFromGridWindow : Window
{
    private readonly Dictionary<string, TextBox> _f = new();
    private readonly ComboBox _mat = new();
    private readonly CheckBox _bx = new() { Content = "Poutres le long de X (axes lettrés)", IsChecked = true };
    private readonly CheckBox _by = new() { Content = "Poutres le long de Y (axes numérotés)", IsChecked = true };
    private readonly CheckBox _sup = new() { Content = "Appuis à la base", IsChecked = true };
    private readonly CheckBox _fix = new() { Content = "Appuis encastrés (sinon articulés)", IsChecked = true };
    private readonly CheckBox _base = new() { Content = "Longrines (poutres) au niveau de base", IsChecked = false };
    public GridTools.FrameOptions Result { get; private set; } = new();

    public FrameFromGridWindow(int nx, int ny, int nl)
    {
        Title = "Créer l'ossature depuis la grille et les étages";
        Width = 480; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new StackPanel { Margin = new Thickness(16) };
        root.Children.Add(new TextBlock
        {
            Text = $"Grille : {nx} axes numérotés × {ny} axes lettrés, {nl} niveaux. StructCalc place un poteau à chaque intersection d'axes entre deux niveaux, et des poutres le long des axes à chaque niveau. Rien n'est dupliqué si des barres existent déjà.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10)
        });
        _mat.Items.Add("Béton armé"); _mat.Items.Add("Acier"); _mat.SelectedIndex = 0;
        void Row(string label, string key, string def)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) }); g.ColumnDefinitions.Add(new ColumnDefinition());
            var t = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center };
            var b = new TextBox { Text = def, Padding = new Thickness(3) };
            Grid.SetColumn(b, 1); g.Children.Add(t); g.Children.Add(b); root.Children.Add(g); _f[key] = b;
        }
        var gm = new Grid { Margin = new Thickness(0, 2, 0, 2) };
        gm.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) }); gm.ColumnDefinitions.Add(new ColumnDefinition());
        gm.Children.Add(new TextBlock { Text = "Matériau", VerticalAlignment = VerticalAlignment.Center });
        Grid.SetColumn(_mat, 1); gm.Children.Add(_mat); root.Children.Add(gm);
        Row("Poteau BA : b (cm)", "cb", "30"); Row("Poteau BA : h (cm)", "ch", "30");
        Row("Poutre BA : b (cm)", "bb", "25"); Row("Poutre BA : h (cm)", "bh", "45");
        Row("Profil poteau acier", "cp", "HEA240"); Row("Profil poutre acier", "bp", "IPE300");
        Row("Charge permanente G (kN/m par poutre, 0 = aucune)", "g", "18"); Row("Charge d'exploitation Q (kN/m par poutre)", "q", "6");
        foreach (var c in new[] { _bx, _by, _sup, _fix, _base }) { c.Margin = new Thickness(0, 4, 0, 0); root.Children.Add(c); }
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
        buttons.Children.Add(Ui.Btn("Créer", (s, e) => Accept(), true));
        buttons.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true });
        root.Children.Add(buttons);
        Content = root;
    }

    private void Accept()
    {
        double cb = Ui.Num(_f["cb"].Text), ch = Ui.Num(_f["ch"].Text), bb = Ui.Num(_f["bb"].Text), bh = Ui.Num(_f["bh"].Text);
        if (new[] { cb, ch, bb, bh }.Any(v => double.IsNaN(v) || v < 10)) { MessageBox.Show("Sections invalides (cm).", "Ossature", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        Result = new GridTools.FrameOptions
        {
            ColumnB = cb / 100, ColumnH = ch / 100, BeamB = bb / 100, BeamH = bh / 100,
            Steel = _mat.SelectedIndex == 1,
            ColumnProfile = _f["cp"].Text.Trim().ToUpperInvariant(), BeamProfile = _f["bp"].Text.Trim().ToUpperInvariant(),
            BeamsAlongX = _bx.IsChecked == true, BeamsAlongY = _by.IsChecked == true,
            G = Math.Max(0, Ui.Num(_f["g"].Text, 0)), Q = Math.Max(0, Ui.Num(_f["q"].Text, 0)),
            SupportsAtBase = _sup.IsChecked == true, FixedSupports = _fix.IsChecked == true, BeamsOnBaseLevel = _base.IsChecked == true,
        };
        DialogResult = true;
    }
}

// =====================================================================================================  FONDS DE PLAN
public enum UnderlayAction { None, Add, Remove, Calibrate, Move, Align, AlignVertical, Zoom, PaperScale }

/// <summary>Gestion des fonds de plan : liste, propriétés (échelle, rotation, origine, opacité, calques DXF, page PDF) et actions de calage.</summary>
public sealed class UnderlayWindow : Window
{
    private readonly StructModel _m;
    private readonly UnderlayManager _mgr;
    private readonly ListBox _list = new();
    private readonly Dictionary<string, TextBox> _f = new();
    private readonly CheckBox _vis = new() { Content = "Visible" };
    private readonly Slider _op = new() { Minimum = 0.1, Maximum = 1, Value = 0.6 };
    private readonly StackPanel _layers = new();
    private readonly TextBlock _info = new() { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 6, 0, 0) };
    private UnderlayDef? _cur;
    public UnderlayAction Action { get; private set; } = UnderlayAction.None;
    public int ActionId { get; private set; } = -1;
    public double PaperDenominator { get; private set; } = 100;

    public UnderlayWindow(StructModel m, UnderlayManager mgr)
    {
        _m = m; _mgr = mgr;
        Title = "Fonds de plan (DXF, DWG, PDF, images)";
        Width = 860; Height = 640; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new Grid { Margin = new Thickness(14) };
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        root.RowDefinitions.Add(new RowDefinition()); root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var left = new DockPanel();
        var lb = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 8, 0, 0) };
        lb.Children.Add(Ui.Btn("Importer…", (s, e) => Do(UnderlayAction.Add)));
        lb.Children.Add(Ui.Btn("Retirer", (s, e) => Do(UnderlayAction.Remove)));
        DockPanel.SetDock(lb, Dock.Bottom); left.Children.Add(lb);
        _list.SelectionChanged += (s, e) => { Store(); Show(_list.SelectedItem as UnderlayDef); };
        _list.DisplayMemberPath = "Name";
        left.Children.Add(_list);
        root.Children.Add(left);

        var right = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Margin = new Thickness(14, 0, 0, 0) };
        var rp = new StackPanel();
        void Row(string label, string key)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(210) }); g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
            var t = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap };
            var b = new TextBox { Padding = new Thickness(3) };
            Grid.SetColumn(b, 1); g.Children.Add(t); g.Children.Add(b); rp.Children.Add(g); _f[key] = b;
        }
        Row("Nom", "name");
        rp.Children.Add(_vis);
        var og = new Grid { Margin = new Thickness(0, 4, 0, 4) };
        og.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(210) }); og.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
        og.Children.Add(new TextBlock { Text = "Opacité", VerticalAlignment = VerticalAlignment.Center });
        Grid.SetColumn(_op, 1); og.Children.Add(_op); rp.Children.Add(og);
        Row("Échelle (m par unité du dessin ou par pixel)", "scale");
        Row("Rotation (°, sens anti-horaire)", "rot");
        Row("Origine X (m)", "ox"); Row("Origine Y (m)", "oy"); Row("Cote Z du plan (m)", "oz");
        Row("PDF : page (1 = première)", "page");

        rp.Children.Add(new TextBlock { Text = "Caler le fond sur le modèle", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 12, 0, 4) });
        var act = new WrapPanel();
        act.Children.Add(Ui.Btn("Échelle : 2 points + distance réelle", (s, e) => Do(UnderlayAction.Calibrate)));
        act.Children.Add(Ui.Btn("Déplacer : point du fond → point du modèle", (s, e) => Do(UnderlayAction.Move)));
        act.Children.Add(Ui.Btn("Aligner à l'horizontale (2 points)", (s, e) => Do(UnderlayAction.Align)));
        act.Children.Add(Ui.Btn("Aligner à la verticale (2 points)", (s, e) => Do(UnderlayAction.AlignVertical)));
        act.Children.Add(Ui.Btn("Cadrer la vue sur le fond", (s, e) => Do(UnderlayAction.Zoom)));
        rp.Children.Add(act);
        var pg = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
        pg.Children.Add(new TextBlock { Text = "PDF imprimé à l'échelle 1/", VerticalAlignment = VerticalAlignment.Center });
        var den = new TextBox { Text = "100", Width = 60, Padding = new Thickness(3), Margin = new Thickness(4, 0, 8, 0) };
        _f["den"] = den; pg.Children.Add(den);
        pg.Children.Add(Ui.Btn("Appliquer", (s, e) => { PaperDenominator = Ui.Num(den.Text, 100); Do(UnderlayAction.PaperScale); }));
        rp.Children.Add(pg);

        rp.Children.Add(new TextBlock { Text = "Calques du DXF (décochez pour masquer)", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 12, 0, 4) });
        rp.Children.Add(new Border { BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(1), MaxHeight = 170, Child = new ScrollViewer { Content = _layers, VerticalScrollBarVisibility = ScrollBarVisibility.Auto } });
        rp.Children.Add(_info);
        right.Content = rp;
        Grid.SetColumn(right, 1); root.Children.Add(right);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        buttons.Children.Add(Ui.Btn("OK", (s, e) => { Store(); DialogResult = true; }, true));
        buttons.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(14, 5, 14, 5), IsCancel = true });
        Grid.SetRow(buttons, 1); Grid.SetColumnSpan(buttons, 2); root.Children.Add(buttons);
        Content = root;

        _list.ItemsSource = _m.Underlays;
        if (_m.Underlays.Count > 0) _list.SelectedIndex = 0; else Show(null);
    }

    private void Do(UnderlayAction a)
    {
        Store();
        if (a != UnderlayAction.Add && _cur == null) { MessageBox.Show("Choisissez d'abord un fond de plan dans la liste.", "Fonds de plan", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        Action = a; ActionId = _cur?.Id ?? -1;
        DialogResult = true;
    }

    private void Show(UnderlayDef? d)
    {
        _cur = d;
        bool on = d != null;
        foreach (var tb in _f.Values) tb.IsEnabled = on;
        _vis.IsEnabled = on; _op.IsEnabled = on;
        _layers.Children.Clear();
        if (d == null) { foreach (var tb in _f.Values) if (tb != _f["den"]) tb.Text = ""; _info.Text = "Aucun fond de plan. Cliquez « Importer… » pour ajouter un DXF, un DWG, un PDF (Revit, AutoCAD…) ou une image."; return; }
        _f["name"].Text = d.Name; _vis.IsChecked = d.Visible; _op.Value = Math.Max(0.1, d.Opacity);
        _f["scale"].Text = d.Scale.ToString("0.#########", CultureInfo.InvariantCulture);
        _f["rot"].Text = Ui.Fmt(d.Rotation); _f["ox"].Text = Ui.Fmt(d.OriginX); _f["oy"].Text = Ui.Fmt(d.OriginY); _f["oz"].Text = Ui.Fmt(d.OriginZ);
        _f["page"].Text = (d.Page + 1).ToString(CultureInfo.InvariantCulture);
        _f["page"].IsEnabled = d.Kind == "pdf";
        var data = _mgr.Find(d.Id);
        string kind = d.Kind == "dxf" ? "DXF vectoriel : accrochage exact sur extrémités, milieux et intersections."
            : d.Kind == "pdf" ? "PDF rendu en image : accrochage détecté sur les traits (extrémités, coins, intersections), précis à quelques millimètres. Pour un accrochage exact, exportez un DXF."
            : "Image : accrochage détecté sur les pixels sombres.";
        _info.Text = kind + (data != null && data.Error != "" ? "\n⚠ " + data.Error : "") + (data?.Dxf != null ? $"\n{data.Dxf.Segments.Count} segments, {data.Dxf.Layers.Count} calques." : "")
            + (data?.PageCount > 1 ? $"\nPDF de {data.PageCount} pages." : "");
        if (data?.Dxf != null)
        {
            var hidden = new HashSet<string>(d.HiddenLayers, StringComparer.OrdinalIgnoreCase);
            foreach (var l in data.Dxf.Layers.Where(x => x.Count > 0).OrderBy(x => x.Name))
                _layers.Children.Add(new CheckBox { Content = $"{l.Name}  ({l.Count})", Tag = l.Name, IsChecked = !hidden.Contains(l.Name), Margin = new Thickness(4, 1, 4, 1) });
        }
    }

    private void Store()
    {
        var d = _cur;
        if (d == null) return;
        if (_f["name"].Text.Trim() != "") d.Name = _f["name"].Text.Trim();
        d.Visible = _vis.IsChecked == true; d.Opacity = _op.Value;
        double sc = Ui.Num(_f["scale"].Text); if (!double.IsNaN(sc) && sc > 1e-9) d.Scale = sc;
        d.Rotation = Ui.Num(_f["rot"].Text, d.Rotation); d.OriginX = Ui.Num(_f["ox"].Text, d.OriginX);
        d.OriginY = Ui.Num(_f["oy"].Text, d.OriginY); d.OriginZ = Ui.Num(_f["oz"].Text, d.OriginZ);
        int pg = (int)Ui.Num(_f["page"].Text, d.Page + 1) - 1; if (pg >= 0) d.Page = pg;
        if (_layers.Children.Count > 0)
            d.HiddenLayers = _layers.Children.OfType<CheckBox>().Where(c => c.IsChecked != true).Select(c => (string)c.Tag).ToList();
    }
}
