using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Results;

namespace StructCalc.UI;

/// <summary>Diagrammes d'efforts par source (cas, combinaison, enveloppe ELU/ELS) : N, Vy, Vz, T, My, Mz avec combinaison responsable, réactions d'appui,
/// déformée par cas / combinaison / mode propre (avec animation) et infobulles de valeurs.</summary>
public sealed partial class ModelViewport
{
    /// <summary>Source des diagrammes et des réactions : « Cas G », nom d'une combinaison, « Enveloppe ELU » ou « Enveloppe ELS ».</summary>
    public string DiagramSource { get; set; } = ResultsStore.EnvUls;
    /// <summary>Source de la déformée ("" = combinaison de service la plus défavorable, sinon cas, combinaison, enveloppe ou « Mode k »).</summary>
    public string DeformSource { get; set; } = "";
    /// <summary>Facteur d'animation de la déformée (1 = amplitude pleine).</summary>
    public double DeformPhase { get; set; } = 1.0;

    private ResultsStore? Store => Output?.Store;

    private static bool IsStoreDiagram(DiagramKind d) => d >= DiagramKind.NSigned && d <= DiagramKind.Mz;

    private static ForceQty QtyOf(DiagramKind d) => d switch
    {
        DiagramKind.NSigned => ForceQty.N, DiagramKind.Vy => ForceQty.Vy, DiagramKind.Vz => ForceQty.Vz, DiagramKind.Torsion => ForceQty.T,
        DiagramKind.My => ForceQty.My, _ => ForceQty.Mz
    };

    private double StoreDiagramMax()
    {
        var st = Store;
        if (st == null || Model == null) return 0;
        return st.MaxAbs(DiagramSource, QtyOf(Diagram), Model.Members.Where(x => MemberShown(x.Type)).Select(x => x.Id));
    }

    private void DrawStoreDiagram(Member mem, Point a, Point b, double k)
    {
        var st = Store; if (st == null) return;
        var q = QtyOf(Diagram);
        var s = st.Series(DiagramSource, mem.Id, q);
        int n = s.X.Length; if (n < 2) return;
        double dx = b.X - a.X, dy = b.Y - a.Y, len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 6) return;
        double nx = -dy / len, ny = dx / len;
        if (Math.Abs(ny) < 0.3) { if (nx < 0) { nx = -nx; ny = -ny; } }
        else if (ny < 0) { nx = -nx; ny = -ny; }
        var (fillMax, strokeMax, fillMin, strokeMin) = q switch
        {
            ForceQty.N => (Br("#66E53935"), Br("#C62828"), Br("#661E88E5"), Br("#1565C0")),     // traction rouge, compression bleue
            ForceQty.Vy or ForceQty.Vz => (Br("#6643A047"), Br("#2E7D32"), Br("#66FB8C00"), Br("#E65100")),
            ForceQty.T => (Br("#667E57C2"), Br("#4527A0"), Br("#66EC407A"), Br("#AD1457")),
            _ => (Br("#664A90E2"), Br("#1565C0"), Br("#66F5A623"), Br("#E65100"))
        };
        bool env = s.Min.Zip(s.Max, (lo, hi) => Math.Abs(hi - lo) > 1e-6).Any(x => x);

        void Poly(double[] vals, Brush fill, Brush stroke, bool label, string[] combos)
        {
            if (vals.Length != n || vals.All(v => Math.Abs(v) < 1e-6)) return;
            var pts = new PointCollection();
            for (int i = 0; i < n; i++) pts.Add(new Point(a.X + dx * i / (n - 1), a.Y + dy * i / (n - 1)));
            for (int i = n - 1; i >= 0; i--)
                pts.Add(new Point(a.X + dx * i / (n - 1) + nx * vals[i] * k, a.Y + dy * i / (n - 1) + ny * vals[i] * k));
            _c.Children.Add(new System.Windows.Shapes.Polygon { Points = pts, Fill = fill, Stroke = stroke, StrokeThickness = 1, IsHitTestVisible = false });
            if (!label) return;
            int ix = 0; for (int i = 1; i < n; i++) if (Math.Abs(vals[i]) > Math.Abs(vals[ix])) ix = i;
            string cb = ix < combos.Length && combos[ix] != "" && env ? "  [" + combos[ix] + "]" : "";
            Text(vals[ix].ToString("0.#") + cb, a.X + dx * ix / (n - 1) + nx * (vals[ix] * k + (vals[ix] >= 0 ? 6 : -18)) - 8,
                 a.Y + dy * ix / (n - 1) + ny * (vals[ix] * k + (vals[ix] >= 0 ? 6 : -18)) - 7, 9, Dark, Br("#CCFFFFFF"));
        }
        Poly(s.Max, fillMax, strokeMax, true, s.MaxCombo);
        if (env) Poly(s.Min, fillMin, strokeMin, true, s.MinCombo);
    }

    private List<ReactionLine>? _reacCache; private string _reacSource = ""; private AnalysisOutput? _reacFor;

    private List<ReactionLine> ReactionsOf()
    {
        var st = Store; if (st == null) return new List<ReactionLine>();
        if (_reacCache == null || _reacSource != DiagramSource || !ReferenceEquals(_reacFor, Output))
        { try { _reacCache = st.Reactions(DiagramSource); } catch { _reacCache = new List<ReactionLine>(); } _reacSource = DiagramSource; _reacFor = Output; }
        return _reacCache;
    }

    private void DrawReactionLabels(Dictionary<int, Node> nodes)
    {
        foreach (var r in ReactionsOf())
        {
            if (!nodes.TryGetValue(r.NodeId, out var nd)) continue;
            var p = S(nd);
            string fz = Math.Abs(r.Max[2] - r.Min[2]) < 1e-6 ? $"Fz = {r.Max[2]:0.0}" : $"Fz = {r.Min[2]:0.0} / {r.Max[2]:0.0}";
            string fh = $"Fx = {r.Min[0]:0.#}/{r.Max[0]:0.#}  Fy = {r.Min[1]:0.#}/{r.Max[1]:0.#}";
            Text(fz + " kN", p.X + 10, p.Y + 14, 10, Dark, Br("#E6FFF3E0"), true);
            if (Math.Abs(r.Max[0]) + Math.Abs(r.Max[1]) + Math.Abs(r.Min[0]) + Math.Abs(r.Min[1]) > 0.05) Text(fh, p.X + 10, p.Y + 28, 9, Gray, Br("#CCFFFFFF"));
        }
    }

    /// <summary>Déplacements nodaux (m, rad) de la déformée affichée.</summary>
    private Dictionary<int, double[]>? DeformMap()
    {
        var st = Store;
        if (DeformSource != "" && st != null)
        {
            try
            {
                var d = st.Displacements(DeformSource);
                if (d.Count > 0) return d.ToDictionary(x => x.NodeId, x => x.U);
            }
            catch { }
        }
        return Output?.Global?.Deformed;
    }

    /// <summary>Infobulle d'une barre : extrêmes de chaque effort et combinaison responsable (source des diagrammes).</summary>
    private string ResultHint(int memberId)
    {
        var st = Store; if (st == null) return "";
        try { return st.MemberSummary(DiagramSource, memberId); } catch { return ""; }
    }

    private string ReactionHint(int nodeId)
    {
        if (Store == null || Model == null || !Model.Supports.Any(s => s.NodeId == nodeId)) return "";
        var r = ReactionsOf().FirstOrDefault(x => x.NodeId == nodeId);
        if (r == null) return "";
        return $"  ·  [{DiagramSource}] Fz = {r.Min[2]:0.0} / {r.Max[2]:0.0} kN (max : {r.MaxCombo[2]})  Fx = {r.Min[0]:0.0} / {r.Max[0]:0.0}  Fy = {r.Min[1]:0.0} / {r.Max[1]:0.0}  My = {r.Min[4]:0.0} / {r.Max[4]:0.0} kN.m";
    }
}
