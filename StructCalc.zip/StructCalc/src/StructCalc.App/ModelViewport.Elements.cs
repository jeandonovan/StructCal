using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>État de la sélection tel que la barre de sélection l'affiche : éléments, masqués, hors vue.</summary>
public sealed class SelectionReport
{
    public List<ElementKey> Keys { get; init; } = new();
    public HashSet<ElementKey> Hidden { get; init; } = new();
    public HashSet<ElementKey> OffView { get; init; } = new();
    public string Text => SelectionSummary.Describe(Keys, Hidden.Contains, OffView.Contains);
}

/// <summary>Système de sélection CENTRAL, indépendant de la vue : une sélection est un ensemble d'éléments du MODÈLE (barres, nœuds, dalles, escaliers, semelles, voiles,
/// radiers, planchers nervurés, coques). Les vues (3D, plan, élévation, côté) enregistrent seulement, à chaque dessin, les zones écran de ce qu'elles montrent ;
/// la désignation choisit l'élément le plus proche de la caméra, le surlignage est le même partout, et rien n'est effacé au changement de vue.</summary>
public sealed partial class ModelViewport
{
    // ---- éléments hors barres et nœuds (ceux-ci restent dans _sel et _selNodes)
    private readonly HashSet<ElementKey> _selKeys = new();

    private sealed class ElemHit
    {
        public ElementKey Key;
        public Point[] Pts = Array.Empty<Point>();
        public double Depth;
        public bool Opaque;
        public Point[][]? Holes;
    }
    private readonly List<ElemHit> _elemHits = new();
    private readonly Dictionary<int, double> _barDepth = new();

    /// <summary>Déclenché à chaque changement de la sélection (tous types d'éléments).</summary>
    public event Action? ElementSelectionChanged;
    /// <summary>Déclenché (au repos, regroupé) après un redessin tant qu'il y a une sélection : change de vue, zoom... l'état « hors vue » peut avoir changé.</summary>
    public event Action? ElementSelectionRefresh;
    private bool _refreshPending;

    private void ScheduleSelectionRefresh()
    {
        if (_refreshPending || SelectedCount == 0 || ElementSelectionRefresh == null) return;
        _refreshPending = true;
        _c.Dispatcher.BeginInvoke(new Action(() => { _refreshPending = false; ElementSelectionRefresh?.Invoke(); }), System.Windows.Threading.DispatcherPriority.Background);
    }

    // ---- couleurs de sélection : mêmes partout, distinctes des rouges / oranges des erreurs et avertissements
    private static readonly Color SelC = Color.FromRgb(0x00, 0xB8, 0xFF);
    private static readonly Brush SelLineBr = Theme.Fixed(SelC);
    private static readonly Brush SelFillBr = Theme.Fixed(Color.FromArgb(70, SelC.R, SelC.G, SelC.B));
    private static readonly Brush SelCasingBr = Theme.Fixed(Color.FromRgb(0x06, 0x24, 0x44));
    private static readonly Brush SelCasingSoftBr = Theme.Fixed(Color.FromArgb(200, 0x06, 0x24, 0x44));

    // ------------------------------------------------------------------ identité des objets du modèle
    public static ElementKey? KeyOf(object? o) => o switch
    {
        SlabPanel s => ElementKey.Named(ElementKind.Slab, s.Name),
        StairDef d => ElementKey.Named(ElementKind.Stair, d.Name),
        FootingRef f => ElementKey.FootingAt(f.NodeId),
        FootingDef fd => ElementKey.Named(ElementKind.Footing, fd.Name),
        WallDef w => ElementKey.Named(ElementKind.Wall, w.Name),
        RaftDef r => ElementKey.Named(ElementKind.Raft, r.Name),
        RibbedFloorDef rf => ElementKey.Named(ElementKind.Ribbed, rf.Name),
        ShellPanel sh => ElementKey.Named(ElementKind.Shell, sh.Name),
        _ => null
    };

    /// <summary>Objet du modèle désigné par la clé (null s'il n'existe plus).</summary>
    public object? ObjectOf(ElementKey k)
    {
        if (Model == null) return null;
        switch (k.Kind)
        {
            case ElementKind.Slab: return Model.Slabs.FirstOrDefault(s => s.Name == k.Name);
            case ElementKind.Stair: return Model.Stairs.FirstOrDefault(s => s.Name == k.Name);
            case ElementKind.Footing:
                if (k.Id >= 0) return Model.Nodes.Any(n => n.Id == k.Id) ? FootingRefOf(k.Id) : null;
                return Model.FootingDefs.FirstOrDefault(f => f.Kind == FootingKind.Filante && f.Name == k.Name);
            case ElementKind.Wall: return Model.Walls.FirstOrDefault(w => w.Name == k.Name);
            case ElementKind.Raft: return Model.Rafts.FirstOrDefault(r => r.Name == k.Name);
            case ElementKind.Ribbed: return Model.RibbedFloors.FirstOrDefault(r => r.Name == k.Name);
            case ElementKind.Shell: return Model.Shells.FirstOrDefault(s => s.Name == k.Name);
        }
        return null;
    }

    /// <summary>Tous les objets du modèle correspondant à la clé (une coque = toutes ses mailles).</summary>
    public IEnumerable<object> ObjectsOf(ElementKey k)
    {
        if (k.Kind == ElementKind.Shell && Model != null) return Model.Shells.Where(s => s.Name == k.Name);
        var o = ObjectOf(k);
        return o == null ? Array.Empty<object>() : new[] { o };
    }

    public bool IsKeySelected(ElementKey k) => k.Kind switch
    {
        ElementKind.Bar => _sel.Contains(k.Id),
        ElementKind.Node => _selNodes.Contains(k.Id),
        _ => _selKeys.Contains(k)
    };

    private bool ElemSel(ElementKey k) => _selKeys.Count > 0 && _selKeys.Contains(k);

    /// <summary>Nombre d'éléments sélectionnés, tous types confondus (une coque = un élément).</summary>
    public int SelectedCount => _sel.Count + _selNodes.Count + _selKeys.Count;

    /// <summary>Éléments sélectionnés autres que barres et nœuds.</summary>
    public IReadOnlyCollection<ElementKey> SelectedElementKeys => _selKeys;

    /// <summary>Toute la sélection sous forme de clés, dans l'ordre barres, nœuds, puis éléments surfaciques.</summary>
    public List<ElementKey> SelectedKeys()
    {
        var res = new List<ElementKey>(SelectedCount);
        res.AddRange(_sel.OrderBy(i => i).Select(ElementKey.Bar));
        res.AddRange(_selNodes.OrderBy(i => i).Select(ElementKey.Node));
        res.AddRange(_selKeys.OrderBy(k => Array.IndexOf(ElementKinds.Order, k.Kind)).ThenBy(k => k.Id).ThenBy(k => k.Name, StringComparer.Ordinal));
        return res;
    }

    /// <summary>Escalier sélectionné quand c'est le seul élément sélectionné de cette famille.</summary>
    public StairDef? SelectedStair => OnlyOne(ElementKind.Stair) is ElementKey k ? ObjectOf(k) as StairDef : null;

    private ElementKey? OnlyOne(ElementKind kind)
    {
        ElementKey? found = null;
        foreach (var k in _selKeys)
        {
            if (k.Kind != kind) continue;
            if (found != null) return null;
            found = k;
        }
        return found;
    }

    // ------------------------------------------------------------------ enregistrement des zones écran (appelé par les dessins)
    private double ViewDepth(double rawD) => UsePersp ? _camDist + rawD - _focusD : rawD - _focusD;

    /// <summary>Zone cliquable d'un élément : polygone écran, profondeur (plus petit = plus près), opaque s'il masque ce qu'il y a derrière.</summary>
    private void AddElemHit(ElementKey key, Point[] pts, double depth, bool opaque = false, Point[][]? holes = null)
    {
        if (pts.Length < 3) return;
        _elemHits.Add(new ElemHit { Key = key, Pts = pts, Depth = depth, Opaque = opaque, Holes = holes });
    }

    /// <summary>Face définie en coordonnées modèle (m) : projetée avec la vue courante.</summary>
    private void AddFaceHit(ElementKey key, IReadOnlyList<Vec3> world, bool opaque = false, IReadOnlyList<IReadOnlyList<Vec3>>? holes = null)
    {
        if (world.Count < 3) return;
        var pts = new Point[world.Count];
        double d = 0;
        for (int i = 0; i < pts.Length; i++)
        {
            var v = V3(world[i].X, world[i].Y, world[i].Z);
            d += v.D;
            pts[i] = S(world[i].X, world[i].Y, world[i].Z);
        }
        Point[][]? hp = null;
        if (holes != null && holes.Count > 0)
            hp = holes.Select(h => h.Select(v => S(v.X, v.Y, v.Z)).ToArray()).ToArray();
        AddElemHit(key, pts, ViewDepth(d / pts.Length), opaque, hp);
    }

    // ------------------------------------------------------------------ désignation : l'élément le plus proche de la caméra
    private List<ElementKey> CandidatesAt(Point p)
    {
        var c = new List<PickCandidate>();
        int nd = NodeAt(p, 7);
        if (nd != -1) c.Add(new PickCandidate(ElementKey.Node(nd), 0, true, false));
        foreach (var (id, pts, depth) in _pick)
            if (InPoly(p, pts)) c.Add(new PickCandidate(ElementKey.Bar(id), depth, true, false));
        foreach (var h in _hit)
        {
            if (DistToSegment(p, h.A, h.B) >= 8) continue;
            _barDepth.TryGetValue(h.Id, out double dep);
            c.Add(new PickCandidate(ElementKey.Bar(h.Id), dep, true, false));
        }
        foreach (var e in _elemHits)
        {
            if (!InPoly(p, e.Pts)) continue;
            if (e.Holes != null && e.Holes.Any(hl => InPoly(p, hl))) continue;
            c.Add(new PickCandidate(e.Key, e.Depth, false, e.Opaque));
        }
        return PickLogic.Order(c);
    }

    private ElementKey? _lastPick;
    private Point _lastPickPos;
    private DateTime _lastPickAt = DateTime.MinValue;

    /// <summary>Clic de sélection (outil Sélection). Retourne vrai si le clic a été traité.</summary>
    private void SelectClick(Point pos, bool ctrl, bool shift)
    {
        if (!ctrl && !shift)
        {
            // charges et cotes d'abord (zones fines), sans effacer le reste tant qu'on ne les désigne pas
            var ob = PickObject(pos);
            if (ob != null)
            {
                SelectObject(ob);
                Hint?.Invoke(DescribeObject(ob) + "  ·  Suppr = supprimer · clic droit = modifier");
                return;
            }
        }
        var ordered = CandidatesAt(pos);
        bool same = _lastPick != null && (DateTime.UtcNow - _lastPickAt).TotalSeconds < 4
                    && Math.Abs(pos.X - _lastPickPos.X) < 4 && Math.Abs(pos.Y - _lastPickPos.Y) < 4 && !ctrl && !shift;
        var chosen = PickLogic.Choose(ordered, _lastPick, same);
        if (chosen == null)
        {
            _lastPick = null;
            if (!ctrl && !shift && HasAnySelection) { ClearSelection(); Hint?.Invoke("Sélection effacée (clic dans le vide)."); }
            return;
        }
        _lastPick = chosen; _lastPickPos = pos; _lastPickAt = DateTime.UtcNow;
        var key = chosen.Value;
        if (shift && !ctrl) SelectKeys(new[] { key }, 'r');
        else if (ctrl) SelectKeys(new[] { key }, 't');
        else SelectKeys(new[] { key }, 'n');
        string more = ordered.Count > 1 && !ctrl && !shift ? $"  ·  {ordered.Count} éléments à cet endroit : cliquez encore pour passer au suivant" : "";
        if (IsKeySelected(key)) Hint?.Invoke(DescribeElement(key) + more);
    }

    // ------------------------------------------------------------------ opérations de sélection (une seule logique pour tous les types)
    private sealed class SelSnap
    {
        public HashSet<int> M = new(), N = new();
        public HashSet<ElementKey> K = new();
        public bool Obj;
        public int Primary;
    }

    private SelSnap Snap() => new()
    {
        M = new HashSet<int>(_sel), N = new HashSet<int>(_selNodes), K = new HashSet<ElementKey>(_selKeys),
        Obj = SelectedLoad != null || SelectedDim != null, Primary = _primary
    };

    /// <summary>Applique les clés : 'n' = remplacer la sélection, 'a' = ajouter, 'r' = retirer, 't' = inverser chacune (Ctrl+clic).</summary>
    public void SelectKeys(IEnumerable<ElementKey> keys, char mode, bool notify = true)
    {
        var before = Snap();
        var list = keys.ToList();
        if (mode == 'n')
        {
            _sel.Clear(); _primary = -1; _selNodes.Clear(); PrimaryNode = -1; _selKeys.Clear();
            SelectedLoad = null; SelectedDim = null;
        }
        else if (list.Count > 0 && (SelectedLoad != null || SelectedDim != null)) { SelectedLoad = null; SelectedDim = null; }
        foreach (var k in list)
        {
            bool add = mode switch { 'r' => false, 't' => !IsKeySelected(k), _ => true };
            switch (k.Kind)
            {
                case ElementKind.Bar:
                    if (add) { _sel.Add(k.Id); _primary = k.Id; } else _sel.Remove(k.Id);
                    break;
                case ElementKind.Node:
                    if (add) { _selNodes.Add(k.Id); PrimaryNode = k.Id; } else _selNodes.Remove(k.Id);
                    break;
                default:
                    if (add) _selKeys.Add(k); else _selKeys.Remove(k);
                    break;
            }
        }
        if (!_sel.Contains(_primary)) _primary = _sel.Count > 0 ? _sel.Last() : -1;
        if (!_selNodes.Contains(PrimaryNode)) PrimaryNode = _selNodes.Count > 0 ? _selNodes.Last() : -1;
        Commit(before, notify);
    }

    /// <summary>Redessine et prévient les écouteurs de ce qui a réellement changé.</summary>
    private void Commit(SelSnap before, bool notify)
    {
        Redraw();
        if (!notify) return;
        bool mem = !before.M.SetEquals(_sel), nodes = !before.N.SetEquals(_selNodes), keys = !before.K.SetEquals(_selKeys);
        bool slabs = keys && (before.K.Any(k => k.Kind == ElementKind.Slab) || _selKeys.Any(k => k.Kind == ElementKind.Slab));
        if (nodes) NodeSelectionChanged?.Invoke();
        if (slabs) SlabSelected?.Invoke(SelectedSlab);
        if (mem) { SelectionChanged?.Invoke(); MemberSelected?.Invoke(_primary); }
        if (before.Obj && SelectedLoad == null && SelectedDim == null) ObjectSelected?.Invoke(null);
        if (mem || nodes || keys || before.Obj) ElementSelectionChanged?.Invoke();
    }

    /// <summary>Vide toute la sélection (action explicite de l'utilisateur : Échap, menu, clic dans le vide).</summary>
    public void ClearAllSelection(bool notify = true) => SelectKeys(Array.Empty<ElementKey>(), 'n', notify);

    /// <summary>Sélectionne ces éléments (remplace la sélection).</summary>
    public void SetKeys(IEnumerable<ElementKey> keys, bool notify = true) => SelectKeys(keys, 'n', notify);

    /// <summary>Inverse la sélection parmi les éléments visibles des familles données (barres et éléments surfaciques par défaut).</summary>
    public void InvertSelection(IEnumerable<ElementKind>? kinds = null)
    {
        if (Model == null) return;
        var ks = new HashSet<ElementKind>(kinds ?? new[] { ElementKind.Bar, ElementKind.Slab, ElementKind.Stair, ElementKind.Footing, ElementKind.Wall, ElementKind.Raft, ElementKind.Ribbed, ElementKind.Shell });
        var visible = VisibleKeys().Where(k => ks.Contains(k.Kind)).ToList();
        var next = visible.Where(k => !IsKeySelected(k)).ToList();
        SelectKeys(next, 'n');
    }

    /// <summary>Éléments de ce type qui ne sont pas masqués (barres, nœuds, dalles...).</summary>
    public List<ElementKey> VisibleKeys(ElementKind? only = null)
    {
        var res = new List<ElementKey>();
        if (Model == null) return res;
        var info = GetInfo();
        foreach (var k in ElementCatalog.Everything(Model, Output))
        {
            if (only != null && k.Kind != only) continue;
            if (ElementCatalog.IsUnpickable(Model, k)) continue;      // pas de géométrie : jamais proposé comme sélectionnable
            if (!KeyHidden(k, info)) res.Add(k);
        }
        return res;
    }

    /// <summary>Cet élément est-il masqué (explicitement ou par son niveau) ?</summary>
    public bool IsKeyHidden(ElementKey k) => Model != null && KeyHidden(k, GetInfo());

    private bool KeyHidden(ElementKey k, StructureInfo info) => k.Kind switch
    {
        ElementKind.Bar => MemberHidden(k.Id, info),
        ElementKind.Node => NodeHidden(k.Id, info),
        ElementKind.Footing => (k.Id >= 0 && (FootingHidden(k.Id) || NodeHidden(k.Id, info))) || (k.Id < 0 && IsObjHidden(ObjectOf(k))),
        _ => ObjectsOf(k).All(IsObjHidden)
    };

    /// <summary>Barre de sélection : nombre, types, masqués et hors vue (d'après le dernier dessin).</summary>
    public SelectionReport Report()
    {
        var keys = SelectedKeys();
        var hidden = new HashSet<ElementKey>(); var off = new HashSet<ElementKey>();
        if (keys.Count == 0 || Model == null) return new SelectionReport { Keys = keys };
        var info = GetInfo();
        var barOn = new HashSet<int>(_hit.Select(h => h.Id));
        var elemOn = new HashSet<ElementKey>();
        double w = Math.Max(_c.ActualWidth, 10), h2 = Math.Max(_c.ActualHeight, 10);
        foreach (var e in _elemHits)
        {
            if (elemOn.Contains(e.Key)) continue;
            if (e.Pts.Any(p => p.X >= -2 && p.X <= w + 2 && p.Y >= -2 && p.Y <= h2 + 2) || e.Pts.Max(p => p.X) >= 0 && e.Pts.Min(p => p.X) <= w && e.Pts.Max(p => p.Y) >= 0 && e.Pts.Min(p => p.Y) <= h2)
                elemOn.Add(e.Key);
        }
        foreach (var k in keys)
        {
            if (KeyHidden(k, info)) { hidden.Add(k); continue; }
            if (ElementCatalog.IsUnpickable(Model, k)) { off.Add(k); continue; }
            bool on = k.Kind switch
            {
                ElementKind.Bar => barOn.Contains(k.Id),
                ElementKind.Node => Model.Nodes.FirstOrDefault(q => q.Id == k.Id) is Node nn && S(nn).X >= -2 && S(nn).X <= w + 2 && S(nn).Y >= -2 && S(nn).Y <= h2 + 2,
                _ => elemOn.Contains(k)
            };
            if (!on) off.Add(k);
        }
        return new SelectionReport { Keys = keys, Hidden = hidden, OffView = off };
    }

    // ------------------------------------------------------------------ rectangle de sélection (barres, nœuds et éléments)
    private static bool PolyTouchesRect(Point[] poly, double x0, double y0, double x1, double y1)
    {
        foreach (var p in poly) if (p.X >= x0 && p.X <= x1 && p.Y >= y0 && p.Y <= y1) return true;
        foreach (var c in new[] { new Point(x0, y0), new Point(x1, y0), new Point(x1, y1), new Point(x0, y1) }) if (InPoly(c, poly)) return true;
        for (int i = 0; i < poly.Length; i++) if (SegHitsRect(poly[i], poly[(i + 1) % poly.Length], x0, y0, x1, y1)) return true;
        return false;
    }

    private List<ElementKey> KeysInBox(Point a, Point b)
    {
        var res = new List<ElementKey>();
        double x0 = Math.Min(a.X, b.X), x1 = Math.Max(a.X, b.X), y0 = Math.Min(a.Y, b.Y), y1 = Math.Max(a.Y, b.Y);
        bool crossing = b.X < a.X;     // de droite à gauche : tout ce qui touche le rectangle
        res.AddRange(IdsInBox(a, b).Select(ElementKey.Bar));
        res.AddRange(NodesInBox(a, b).Select(ElementKey.Node));
        var seen = new HashSet<ElementKey>();
        foreach (var g in _elemHits.GroupBy(h => h.Key))
        {
            bool ok;
            if (crossing) ok = g.Any(h => PolyTouchesRect(h.Pts, x0, y0, x1, y1));
            else ok = g.All(h => h.Pts.All(p => p.X >= x0 && p.X <= x1 && p.Y >= y0 && p.Y <= y1));
            if (ok && seen.Add(g.Key)) res.Add(g.Key);
        }
        return res;
    }

    // ------------------------------------------------------------------ surlignage (par-dessus toute la scène : visible même derrière un autre élément)
    private void DrawElementHighlights()
    {
        if (_selKeys.Count > 0)
        {
            foreach (var h in _elemHits)
            {
                if (!_selKeys.Contains(h.Key)) continue;
                _c.Children.Add(new Polygon { Points = new PointCollection(h.Pts), Fill = SelFillBr, Stroke = SelCasingSoftBr, StrokeThickness = 4.4, StrokeLineJoin = PenLineJoin.Round, IsHitTestVisible = false });
            }
            foreach (var h in _elemHits)
            {
                if (!_selKeys.Contains(h.Key)) continue;
                _c.Children.Add(new Polygon { Points = new PointCollection(h.Pts), Stroke = SelLineBr, StrokeThickness = 2.2, StrokeLineJoin = PenLineJoin.Round, IsHitTestVisible = false });
            }
        }
        if (_sel.Count > 0)
        {
            foreach (var h in _hit)
                if (_sel.Contains(h.Id)) Ln(h.A.X, h.A.Y, h.B.X, h.B.Y, SelCasingSoftBr, 8);
            foreach (var h in _hit)
                if (_sel.Contains(h.Id)) Ln(h.A.X, h.A.Y, h.B.X, h.B.Y, SelLineBr, 4.4);
        }
    }

    // ------------------------------------------------------------------ description et géométrie d'un élément
    public string DescribeElement(ElementKey k)
    {
        if (Model == null) return k.Label;
        switch (k.Kind)
        {
            case ElementKind.Bar:
            {
                var m = Model.Members.FirstOrDefault(x => x.Id == k.Id);
                if (m == null) return k.Label;
                string sec = m.Kind == MaterialKind.Steel ? m.Profile : $"{m.B * 100:0}x{m.H * 100:0}";
                return $"{(m.Type == MemberType.Column ? "Poteau" : "Poutre")} {m.Id} · {sec} · nœuds {m.NodeI}-{m.NodeJ}";
            }
            case ElementKind.Node: return DescribeNode(k.Id);
            case ElementKind.Slab:
                return ObjectOf(k) is SlabPanel s ? $"Dalle {s.Name} · {s.Lx:0.00} x {s.Ly:0.00} m · h = {s.H * 100:0} cm · cote {s.Z:0.00} m" : k.Label;
            case ElementKind.Stair: case ElementKind.Footing when k.Id >= 0:
                return ObjectOf(k) is object o ? DescribeObject(o) : k.Label;
            case ElementKind.Footing:
                return ObjectOf(k) is FootingDef fd ? $"Semelle filante {fd.Name} · L = {fd.LengthM:0.00} m" : k.Label;
            case ElementKind.Wall:
                return ObjectOf(k) is WallDef w ? $"Voile {w.Name} · {w.LengthM:0.00} x {w.HeightM:0.00} m · e = {w.ThicknessM * 100:0} cm" + (w.Retaining ? " · soutènement" : "") : k.Label;
            case ElementKind.Raft:
                return ObjectOf(k) is RaftDef r ? $"Radier {r.Name} · h = {r.H * 100:0} cm · {r.Panels.Count} panneau(x)" : k.Label;
            case ElementKind.Ribbed:
                return ObjectOf(k) is RibbedFloorDef rf ? $"Plancher nervuré {rf.Name} · {rf.TotalHeightCm:0} cm ({rf.HourdisCm:0}+{rf.ToppingCm:0}) · entraxe {rf.SpacingM:0.00} m" : k.Label;
            case ElementKind.Shell:
            {
                var sh = Model.Shells.Where(q => q.Name == k.Name).ToList();
                return sh.Count == 0 ? k.Label : $"{(sh[0].Kind == "Voile" ? "Voile maillé" : "Dalle maillée")} {k.Name} · e = {sh[0].T * 100:0.#} cm · {sh.Count} maille(s)";
            }
        }
        return k.Label;
    }

    /// <summary>Boîte englobante d'un élément (m) pour le zoom ; null s'il n'a pas de géométrie.</summary>
    public List<Vec3>? PointsOf(ElementKey k)
    {
        if (Model == null) return null;
        var pts = new List<Vec3>();
        void Box(double x0, double y0, double z0, double x1, double y1, double z1)
        {
            foreach (double x in new[] { x0, x1 }) foreach (double y in new[] { y0, y1 }) foreach (double z in new[] { z0, z1 }) pts.Add(new Vec3(x, y, z));
        }
        switch (k.Kind)
        {
            case ElementKind.Bar:
            {
                var m = Model.Members.FirstOrDefault(x => x.Id == k.Id);
                if (m == null) return null;
                double r = Math.Max(Math.Max(m.B, m.H), 0.3) * 0.75 + 0.25;
                foreach (int id in new[] { m.NodeI, m.NodeJ })
                    if (Model.Nodes.FirstOrDefault(q => q.Id == id) is Node nb) Box(nb.X - r, nb.Y - r, nb.Z - r, nb.X + r, nb.Y + r, nb.Z + r);
                break;
            }
            case ElementKind.Node:
                if (Model.Nodes.FirstOrDefault(q => q.Id == k.Id) is Node nd) Box(nd.X - 1.2, nd.Y - 1.2, nd.Z - 1.2, nd.X + 1.2, nd.Y + 1.2, nd.Z + 1.2);
                break;
            case ElementKind.Slab:
                if (ObjectOf(k) is SlabPanel s) Box(s.X0, s.Y0, s.Z - Math.Max(s.H, 0.2) - 0.3, s.X0 + s.Lx, s.Y0 + s.Ly, s.Z + 0.3);
                break;
            case ElementKind.Stair:
                if (ObjectOf(k) is StairDef sd) foreach (var f in StairFacesOf(sd)) pts.AddRange(f.Pts);
                break;
            case ElementKind.Footing:
                if (k.Id >= 0)
                {
                    var pf = FootingPlacement.From(Model, Output).FirstOrDefault(q => q.NodeId == k.Id);
                    if (pf != null) Box(pf.X - pf.A / 2 - 0.3, pf.Y - pf.B / 2 - 0.3, pf.ZTop - pf.H - 0.3, pf.X + pf.A / 2 + 0.3, pf.Y + pf.B / 2 + 0.3, pf.ZTop + 0.3);
                }
                else if (ObjectOf(k) is FootingDef fd)
                {
                    double ca = Math.Cos(fd.AngleDeg * Math.PI / 180), sa = Math.Sin(fd.AngleDeg * Math.PI / 180), a = fd.FixedA > 0 ? fd.FixedA : 0.8;
                    foreach (double u in new[] { 0.0, fd.LengthM }) foreach (double v in new[] { -a / 2, a / 2 }) foreach (double z in new[] { fd.ZTop - 0.5, fd.ZTop })
                        pts.Add(new Vec3(fd.X0 + u * ca - v * sa, fd.Y0 + u * sa + v * ca, z));
                }
                break;
            case ElementKind.Wall:
                if (ObjectOf(k) is WallDef w)
                {
                    double ca = Math.Cos(w.AngleDeg * Math.PI / 180), sa = Math.Sin(w.AngleDeg * Math.PI / 180), t2 = w.ThicknessM / 2;
                    foreach (double u in new[] { 0.0, w.LengthM }) foreach (double f in new[] { -t2, t2 }) foreach (double z in new[] { 0.0, w.HeightM })
                        pts.Add(new Vec3(w.X + u * ca - f * sa, w.Y + u * sa + f * ca, w.Z + z));
                }
                break;
            case ElementKind.Raft:
                if (ObjectOf(k) is RaftDef rf) foreach (var p in rf.Panels) Box(p.X0, p.Y0, rf.ZTop - rf.H, p.X0 + p.Lx, p.Y0 + p.Ly, rf.ZTop);
                break;
            case ElementKind.Ribbed:
                if (ObjectOf(k) is RibbedFloorDef rb && rb.HasFootprint) Box(rb.X0, rb.Y0, rb.Z - rb.TotalHeightCm / 100 - 0.3, rb.X1, rb.Y1, rb.Z + 0.3);
                break;
            case ElementKind.Shell:
            {
                var nodes = Model.Nodes.GroupBy(q => q.Id).ToDictionary(g => g.Key, g => g.First());
                foreach (var sh in Model.Shells.Where(q => q.Name == k.Name))
                    foreach (int id in new[] { sh.N1, sh.N2, sh.N3, sh.N4 })
                        if (nodes.TryGetValue(id, out var ns)) Box(ns.X - 0.2, ns.Y - 0.2, ns.Z - 0.2, ns.X + 0.2, ns.Y + 0.2, ns.Z + 0.2);
                break;
            }
        }
        return pts.Count == 0 ? null : pts;
    }

    /// <summary>Zoom sur toute la sélection (barres, nœuds, dalles, semelles, escaliers...).</summary>
    private void ZoomAllSelected()
    {
        var pts = new List<Vec3>();
        foreach (var k in SelectedKeys()) { var p = PointsOf(k); if (p != null) pts.AddRange(p); }
        if (pts.Count == 0) { ZoomExtents(); return; }
        var (mn, mx) = BoundsOf(pts);
        _pivot = new Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, SelectedCount == 1 ? Math.Min(_c.ActualWidth, _c.ActualHeight) * 0.2 : 70);
    }

    /// <summary>Supprime des clés de la sélection qui n'existent plus dans le modèle (suppression, annuler / rétablir).</summary>
    public void PruneSelection()
    {
        if (Model == null) { _selKeys.Clear(); return; }
        var bars = new HashSet<int>(Model.Members.Select(q => q.Id)); var nodes = new HashSet<int>(Model.Nodes.Select(q => q.Id));
        _sel.RemoveWhere(i => !bars.Contains(i)); _selNodes.RemoveWhere(i => !nodes.Contains(i));
        _selKeys.RemoveWhere(k => ObjectOf(k) == null);
        if (!_sel.Contains(_primary)) _primary = _sel.Count > 0 ? _sel.First() : -1;
        if (!_selNodes.Contains(PrimaryNode)) PrimaryNode = _selNodes.Count > 0 ? _selNodes.Last() : -1;
    }
}
