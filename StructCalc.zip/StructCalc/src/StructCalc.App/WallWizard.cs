using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Walls;

namespace StructCalc.UI;

/// <summary>Assistant voiles en coques : géométrie, ouvertures, charges, calcul éléments finis, cartes de résultats colorées et ferraillage.</summary>
public sealed class WallWizardWindow : Window
{
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<Func<StructModel, string>, string> _apply;
    private WallDef _w = new();
    private int _opIdx;
    private WallResult? _res;
    private readonly ComboBox _list = new() { Width = 180 };
    private readonly ComboBox _map = new() { Width = 300 };
    private readonly Canvas _canvas = new() { ClipToBounds = true, Background = Brushes.White };
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(8) };
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private readonly TextBlock _legend = new() { Margin = new Thickness(8), FontFamily = new FontFamily("Consolas") };
    private readonly ScrollViewer _formHost = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private FormKit _form = null!;
    private bool _busy;

    private static readonly string[] Maps =
    {
        "Armatures verticales requises (cm²/m par face)", "Armatures horizontales requises (cm²/m par face)", "Compression de membrane (MPa)",
        "Effort vertical ny le plus comprimé (kN/m)", "Cisaillement |nxy| (kN/m)", "Moment de plaque max (kN.m/m)", "Déplacement ELS (mm)", "Maillage",
    };

    public WallWizardWindow(Func<StructModel> model, Func<Func<StructModel, string>, string> apply)
    {
        _get = model; _apply = apply;
        Title = "Assistant voiles en coques (éléments finis) avec ouvertures";
        Width = 1400; Height = 840; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _w = _model.Walls.FirstOrDefault()?.Clone() ?? NewWall();
        foreach (var s in Maps) _map.Items.Add(s);
        _map.SelectedIndex = 0;
        _map.SelectionChanged += (s, e) => Draw();

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(480) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Voile :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        bar.Children.Add(_list);
        bar.Children.Add(new Border { Width = 8 });
        bar.Children.Add(Ui.Btn("➕ Nouveau", (s, e) => { _w = NewWall(); _opIdx = 0; FillList(); RebuildForm(); Recompute(); }));
        bar.Children.Add(Ui.Btn("▶ Calculer", (s, e) => Recompute(), true));
        bar.Children.Add(Ui.Btn("💾 Enregistrer", (s, e) => Save()));
        bar.Children.Add(Ui.Btn("🗑 Supprimer", (s, e) => Delete()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);

        var right = new Grid();
        right.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        right.RowDefinitions.Add(new RowDefinition());
        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(4) };
        top.Children.Add(new TextBlock { Text = "Carte :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
        top.Children.Add(_map); top.Children.Add(_legend);
        right.Children.Add(top);
        var tabs = new TabControl { Margin = new Thickness(4) };
        var host = new Border { Child = _canvas };
        _canvas.SizeChanged += (s, e) => Draw();
        tabs.Items.Add(new TabItem { Header = "Voile et cartes de résultats", Content = host });
        tabs.Items.Add(new TabItem { Header = "Note de calcul", Content = _report });
        Grid.SetRow(tabs, 1); right.Children.Add(tabs);
        Grid.SetRow(right, 1); Grid.SetColumn(right, 1); root.Children.Add(right);
        Content = root;
        _list.SelectionChanged += (s, e) =>
        {
            if (_busy) return; int i = _list.SelectedIndex;
            if (i >= 0 && i < _model.Walls.Count) { _w = _model.Walls[i].Clone(); _opIdx = 0; RebuildForm(); Recompute(); }
        };
        FillList(); RebuildForm();
        Loaded += (s, e) => Recompute();
    }

    private WallDef NewWall()
    {
        int n = 1; while (_model.Walls.Any(x => x.Name == "V" + n)) n++;
        var w = new WallDef { Name = "V" + n, CoverCm = _model.Settings.CoverSlabCm > 0 ? 3 : 3 };
        w.Openings.Add(new WallOpening { Name = "O1", XM = 1.6, ZM = 0, WidthM = 1.0, HeightM = 2.1 });
        return w;
    }

    private void FillList()
    {
        _busy = true; _list.Items.Clear();
        foreach (var x in _model.Walls) _list.Items.Add($"{x.Name} ({x.LengthM:0.0} x {x.HeightM:0.0} m)");
        if (!_model.Walls.Any(x => x.Name == _w.Name)) _list.Items.Add($"{_w.Name} (nouveau)");
        int idx = _model.Walls.FindIndex(x => x.Name == _w.Name);
        _list.SelectedIndex = idx >= 0 ? idx : _list.Items.Count - 1;
        _busy = false;
    }

    private void RebuildForm()
    {
        _form = new FormKit();
        var w = _w;
        _form.Section("Voile", "Le voile est modélisé en coque : membrane (efforts dans le plan) + plaque (flexion hors plan) ; les ouvertures sont découpées dans le maillage.");
        _form.Text("Nom", () => w.Name, v => w.Name = v);
        _form.Num("Longueur", () => w.LengthM, v => w.LengthM = v, null, "m");
        _form.Num("Hauteur", () => w.HeightM, v => w.HeightM = v, null, "m");
        _form.Num("Épaisseur", () => w.ThicknessM, v => w.ThicknessM = v, "≥ max(15 cm ; he/20) en zone sismique", "m");
        var meshItems = new List<(string, string)> { ("Réglage du projet (assistant de configuration)", MeshPresets.GlobalId) };
        foreach (var mp in MeshPresets.All) meshItems.Add((mp.Label, mp.Id));
        _form.Combo("Maillage", meshItems, () => string.IsNullOrEmpty(w.MeshMode) ? MeshPresets.GlobalId : w.MeshMode, v => w.MeshMode = v,
            "Grossier : avant-projet ; Courant : dimensionnement ; Fin / Très fin : concentrations aux angles d'ouvertures ; Manuel : taille saisie ci-dessous.");
        _form.Combo("Type d'éléments", new (string, string)[] { ("Réglage du projet", "Global"), ("Quadrangles (MITC4 / QM6)", "Quad"), ("Triangulé (CST + DKT)", "Tri") },
            () => string.IsNullOrEmpty(w.MeshElement) ? "Global" : w.MeshElement, v => w.MeshElement = v,
            "Triangulé : chaque maille coupée en deux triangles ; mailler plus finement pour un voile élancé chargé dans son plan.");
        _form.Num("Taille des éléments (mode Manuel)", () => w.MeshM, v => w.MeshM = v, "Utilisée seulement si le maillage est « Manuel » ; 0,20 à 0,30 m courant, 0,10 m pour affiner", "m");
        _form.Num("Enrobage (axe des aciers)", () => w.CoverCm, v => w.CoverCm = v, null, "cm");
        _form.Combo("Appui en pied", new (string, WallBase)[] { ("Encastré", WallBase.Encastre), ("Articulé", WallBase.Articule) }, () => w.Base, v => w.Base = v);
        _form.Check("Tête maintenue hors plan (plancher)", () => w.TopHeldOutOfPlane, v => w.TopHeldOutOfPlane = v);
        _form.Check("Poids propre (25 kN/m³)", () => w.SelfWeight, v => w.SelfWeight = v);

        _form.Section("Charges");
        _form.Num("G en tête (hors poids propre)", () => w.GTopKnPerM, v => w.GTopKnPerM = v, "Réaction des planchers supérieurs", "kN/m");
        _form.Num("Q en tête", () => w.QTopKnPerM, v => w.QTopKnPerM = v, null, "kN/m");
        _form.Num("Effort horizontal dans le plan E (séisme)", () => w.EHorizKn, v => w.EHorizKn = v, "Appliqué en tête, ± dans les combinaisons", "kN");
        _form.Num("Pression hors plan W (vent / poussée)", () => w.WindKPa, v => w.WindKPa = v, "Perpendiculaire au voile", "kPa");

        _form.Section("Mur de soutènement / voile périphérique", "Poussée des terres triangulaire K·γ·z + surcharge, à la place de la pression uniforme W.");
        _form.Check("Mur de soutènement (poussée des terres)", () => w.Retaining, v => w.Retaining = v);
        _form.Num("Hauteur de terre retenue (0 = tout le mur)", () => w.RetainedHeightM, v => w.RetainedHeightM = v, null, "m");
        _form.Num("Coefficient de poussée K", () => w.KEarth, v => w.KEarth = v, "0,5 = repos (mur bloqué) ; Ka ≈ 0,33 mur libre", "");
        _form.Num("Poids volumique du remblai γ", () => w.SoilGammaKnM3, v => w.SoilGammaKnM3 = v, null, "kN/m³");
        _form.Num("Surcharge sur le remblai q", () => w.SurchargeKPa, v => w.SurchargeKPa = v, null, "kPa");

        _form.Section("Ouvertures (portes, fenêtres, trémies)", "Position mesurée depuis le bord gauche et le pied du voile.");
        if (w.Openings.Count == 0) { _form.Add(new TextBlock { Text = "Aucune ouverture.", Margin = new Thickness(4) }); }
        else
        {
            _opIdx = Math.Min(_opIdx, w.Openings.Count - 1);
            _form.Combo("Ouverture à éditer", w.Openings.Select((op, i) => ($"{i + 1} - {op.Name}", i)).ToList(), () => _opIdx, v => { _opIdx = v; RebuildForm(); });
            var o = w.Openings[_opIdx];
            _form.Text("Nom", () => o.Name, v => o.Name = v);
            _form.Num("Position x (bord gauche)", () => o.XM, v => o.XM = v, null, "m");
            _form.Num("Hauteur d'allège", () => o.ZM, v => o.ZM = v, "0 pour une porte", "m");
            _form.Num("Largeur", () => o.WidthM, v => o.WidthM = v, null, "m");
            _form.Num("Hauteur", () => o.HeightM, v => o.HeightM = v, null, "m");
        }
        _form.Add(Ui.Btn("➕ Ajouter une ouverture", (s, e) => { _w.Openings.Add(new WallOpening { Name = "O" + (_w.Openings.Count + 1), XM = Math.Min(0.5 + 1.5 * _w.Openings.Count, Math.Max(0.1, _w.LengthM - 1.2)), WidthM = 1.0, HeightM = 1.2, ZM = 0.9 }); _opIdx = _w.Openings.Count - 1; RebuildForm(); Recompute(); }));
        _form.Add(Ui.Btn("➖ Supprimer l'ouverture", (s, e) => { if (_w.Openings.Count > 0) { _w.Openings.RemoveAt(_opIdx); _opIdx = 0; RebuildForm(); Recompute(); } }));
        _formHost.Content = _form.Root;
    }

    private void Recompute()
    {
        try
        {
            System.Windows.Input.Mouse.OverrideCursor = System.Windows.Input.Cursors.Wait;
            var rc = (DesignCodeRegistry.Get(_model.RcCodeId) as IReinforcedConcreteCode) ?? (IReinforcedConcreteCode)DesignCodeRegistry.Get("BAEL91");
            _res = WallDesigner.Design(_w, rc, _model.Fc28, _model.Fe, _model.Settings);
            _report.Text = _res.Report;
            _status.Text = _res.Ok ? $"✔ {_res.Mesh.Elems.Count} éléments - conforme" : "⚠ " + (_res.Warnings.FirstOrDefault() ?? "À vérifier");
            _status.Foreground = _res.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
            Draw();
        }
        catch (Exception ex) { _res = null; _status.Text = "Erreur : " + ex.Message; _status.Foreground = Brushes.Firebrick; _canvas.Children.Clear(); }
        finally { System.Windows.Input.Mouse.OverrideCursor = null; }
    }

    private static Color Ramp(double t)
    {
        t = Math.Max(0, Math.Min(1, t));
        // bleu - cyan - vert - jaune - rouge
        double[][] stops = { new[] { 0.0, 0, 0, 255 }, new[] { 0.25, 0, 200, 255 }, new[] { 0.5, 0, 220, 0 }, new[] { 0.75, 255, 230, 0 }, new[] { 1.0, 255, 0, 0 } };
        for (int i = 0; i < stops.Length - 1; i++)
            if (t <= stops[i + 1][0])
            {
                double f = (t - stops[i][0]) / (stops[i + 1][0] - stops[i][0]);
                return Color.FromRgb((byte)(stops[i][1] + f * (stops[i + 1][1] - stops[i][1])), (byte)(stops[i][2] + f * (stops[i + 1][2] - stops[i][2])), (byte)(stops[i][3] + f * (stops[i + 1][3] - stops[i][3])));
            }
        return Colors.Red;
    }

    private void Draw()
    {
        _canvas.Children.Clear();
        var r = _res; if (r == null || _canvas.ActualWidth < 50) return;
        double[]? vals = _map.SelectedIndex switch
        {
            0 => r.AsV, 1 => r.AsH, 2 => r.SigC, 3 => r.NyMin, 4 => r.NxyMax, 5 => r.MPlateMax, 6 => r.Disp, _ => null,
        };
        double vmin = 0, vmax = 1;
        if (vals != null && vals.Length > 0) { vmin = vals.Min(); vmax = vals.Max(); if (vmax - vmin < 1e-12) vmax = vmin + 1; }
        double W = _w.LengthM, H = _w.HeightM, m = 24;
        double sc = Math.Min((_canvas.ActualWidth - 2 * m) / W, (_canvas.ActualHeight - 2 * m) / H);
        double ox = m, oy = _canvas.ActualHeight - m;
        foreach (var el in r.Mesh.Elems)
        {
            int idx = r.Mesh.Elems.IndexOf(el);
            var rect = new Rectangle { Width = el.A * sc + 0.6, Height = el.B * sc + 0.6, Stroke = vals == null ? Brushes.Gray : null, StrokeThickness = 0.5 };
            rect.Fill = vals == null ? Brushes.WhiteSmoke : new SolidColorBrush(Ramp((vals[idx] - vmin) / (vmax - vmin)));
            rect.ToolTip = vals == null ? null : $"{vals[idx]:0.###}";
            Canvas.SetLeft(rect, ox + (el.Xc - el.A / 2) * sc); Canvas.SetTop(rect, oy - (el.Yc + el.B / 2) * sc);
            _canvas.Children.Add(rect);
        }
        var outline = new Rectangle { Width = W * sc, Height = H * sc, Stroke = Brushes.Black, StrokeThickness = 1.5 };
        Canvas.SetLeft(outline, ox); Canvas.SetTop(outline, oy - H * sc); _canvas.Children.Add(outline);
        foreach (var o in _w.Openings)
        {
            var rr = new Rectangle { Width = o.WidthM * sc, Height = o.HeightM * sc, Stroke = Brushes.Black, StrokeThickness = 1.5, Fill = Brushes.White };
            Canvas.SetLeft(rr, ox + o.XM * sc); Canvas.SetTop(rr, oy - (o.ZM + o.HeightM) * sc); _canvas.Children.Add(rr);
            var tb = new TextBlock { Text = o.Name, FontSize = 11 }; Canvas.SetLeft(tb, ox + o.XM * sc + 3); Canvas.SetTop(tb, oy - (o.ZM + o.HeightM) * sc + 3); _canvas.Children.Add(tb);
        }
        foreach (var z in r.Zones.Take(8))
        {
            var zr = new Rectangle { Width = (z.X1 - z.X0) * sc, Height = (z.Y1 - z.Y0) * sc, Stroke = Brushes.Magenta, StrokeThickness = 1.2, StrokeDashArray = new DoubleCollection { 3, 2 } };
            Canvas.SetLeft(zr, ox + z.X0 * sc); Canvas.SetTop(zr, oy - z.Y1 * sc); _canvas.Children.Add(zr);
        }
        _legend.Text = vals == null ? "" : $"  min {vmin:0.###}  →  max {vmax:0.###}   (bleu → rouge ; pointillés magenta : zones à renforcer)";
    }

    private void Save()
    {
        var c = _w.Clone();
        _status.Text = _apply(m =>
        {
            int i = m.Walls.FindIndex(x => x.Name == c.Name);
            if (i >= 0) m.Walls[i] = c; else m.Walls.Add(c);
            return $"Voile {c.Name} enregistré (calcul F5, plans « PLANS »).";
        });
        _status.Foreground = Brushes.DarkGreen; FillList();
    }

    private void Delete()
    {
        string n = _w.Name; if (!_model.Walls.Any(x => x.Name == n)) return;
        _apply(m => { m.Walls.RemoveAll(x => x.Name == n); return $"Voile {n} supprimé."; });
        _w = _model.Walls.FirstOrDefault()?.Clone() ?? NewWall(); FillList(); RebuildForm(); Recompute();
    }
}
