using System.Windows;
using StructCalc.Core;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Tableau « Vérification » : un clic sur un message sélectionne (et réaffiche si besoin) l'élément concerné, un clic droit propose des corrections
/// sûres (annulables par Ctrl+Z, avec confirmation quand elles suppriment quelque chose), une explication, ou d'ignorer l'avertissement.</summary>
public partial class MainWindow
{
    private readonly HashSet<string> _ignoredIssues = new();
    private DateTime _issueFocusAt = DateTime.MinValue;

    /// <summary>Une correction proposée pour un message. <c>Run</c> modifie le modèle (l'annulation et la vérification suivante sont gérées par l'appelant) et
    /// renvoie le texte du résultat, ou null si rien n'a été fait ; <c>Direct</c> ouvre une fenêtre qui gère elle-même l'annulation.</summary>
    private sealed class IssueFix
    {
        public string Label = "";
        public string? Confirm;
        public Func<IReadOnlyList<ModelIssue>, string?>? Run;
        public Action? Direct;
        public bool Batch;
        public string BatchLabel = "";
    }

    private static string IssueKey(ModelIssue i) => i.Code + "|" + i.Message;

    /// <summary>Les erreurs sont toujours montrées ; les avertissements et infos ignorés par l'utilisateur sont masqués jusqu'à « Réafficher les messages ignorés ».</summary>
    private List<ModelIssue> FilterIssues(List<ModelIssue> l) =>
        l.Where(i => i.Level == IssueLevel.Error || !_ignoredIssues.Contains(IssueKey(i))).ToList();

    private void FillIssues(List<ModelIssue> issues)
    {
        var shown = FilterIssues(issues);
        _vp.Issues = shown;
        _vp.Redraw();
        GridIssues.ItemsSource = shown.Select(i => new IssueRow
        {
            Niveau = i.Level == IssueLevel.Error ? "Erreur" : i.Level == IssueLevel.Warning ? "Avertissement" : "Info",
            Message = i.Message, Noeud = i.NodeId?.ToString() ?? "", Barre = i.MemberId?.ToString() ?? "", Issue = i
        }).ToList();
        TabCheck.Header = shown.Count > 0 ? $"Vérification ({shown.Count})" : "Vérification";
        _lastIssues = issues;
        RebuildMessages();
    }

    private void RunCheckNow()
    {
        ReadParams();
        FillIssues(ModelChecker.Check(_model));
    }

    private void InitIssues()
    {
        var menu = new ContextMenu();
        GridIssues.ContextMenu = menu;
        GridIssues.ToolTip = "Clic sur un message : sélectionne l'élément concerné dans la vue  ·  Clic droit : corrections proposées";
        GridIssues.ContextMenuOpening += (s, e) => { if (!BuildIssueMenu(menu)) e.Handled = true; };
        GridIssues.PreviewMouseRightButtonDown += (s, e) =>
        {
            var row = IssueAncestor<DataGridRow>(e.OriginalSource as DependencyObject);
            if (row != null) { GridIssues.SelectedItem = row.Item; row.IsSelected = true; }
        };
        // un nouveau clic sur le message déjà sélectionné recadre la vue (la sélection du tableau ne change pas, donc aucun événement)
        GridIssues.PreviewMouseLeftButtonUp += (s, e) =>
        {
            if ((DateTime.Now - _issueFocusAt).TotalMilliseconds < 400) return;
            var row = IssueAncestor<DataGridRow>(e.OriginalSource as DependencyObject);
            if (row?.Item is IssueRow r && r.Issue != null) FocusIssue(r.Issue);
        };
    }

    private static T? IssueAncestor<T>(DependencyObject? d) where T : DependencyObject
    {
        while (d != null)
        {
            if (d is T t) return t;
            d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
        }
        return null;
    }

    private void GridIssues_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (GridIssues.SelectedItem is not IssueRow r || r.Issue == null) return;
        _issueFocusAt = DateTime.Now;
        FocusIssue(r.Issue);
    }

    private SlabPanel? SlabOfLoad(SurfaceLoad sl) =>
        _model.Slabs.FirstOrDefault(d => sl.Name == d.Name + "-G" || sl.Name == d.Name + "-Q" || sl.Name.StartsWith(d.Name + "-G#") || sl.Name.StartsWith(d.Name + "-Q#"));

    // ------------------------------------------------------------------ clic : sélectionner l'élément concerné
    private void FocusIssue(ModelIssue iss)
    {
        var mem = new List<int>(); var nodes = new List<int>(); var objs = new List<object>();
        SlabPanel? slab = null; SurfaceLoad? manual = null;
        switch (iss.Subject)
        {
            case int[] ns: nodes.AddRange(ns.Where(n => FindNode(n) != null)); break;
            case SlabPanel s: slab = s; objs.Add(s); break;
            case SurfaceLoad sl:
                slab = SlabOfLoad(sl);
                if (slab != null) objs.Add(slab); else manual = sl;
                break;
            case MemberLoad ml: if (_model.Members.Any(m => m.Id == ml.MemberId)) mem.Add(ml.MemberId); break;
            case NodalLoad nl: if (FindNode(nl.NodeId) != null) nodes.Add(nl.NodeId); break;
            case SupportDef sd: if (FindNode(sd.NodeId) != null) nodes.Add(sd.NodeId); break;
            case ShellPanel sh:
                foreach (int n in new[] { sh.N1, sh.N2, sh.N3, sh.N4 }) if (FindNode(n) != null) nodes.Add(n);
                objs.AddRange(_model.Shells.Where(q => q.Name == sh.Name));
                break;
        }
        if (iss.Subject2 is int other && FindNode(other) != null) nodes.Add(other);
        if (iss.NodeId is int nid && FindNode(nid) != null && !nodes.Contains(nid)) nodes.Add(nid);
        if (iss.MemberId is int mid && _model.Members.Any(m => m.Id == mid) && !mem.Contains(mid)) mem.Add(mid);

        // l'élément visé ne doit pas rester caché
        if (mem.Any(_vp.HiddenMembers.Contains) || nodes.Any(_vp.HiddenNodes.Contains) || objs.Any(_vp.IsObjHidden)) _vp.Unhide(mem, nodes, objs);

        if (slab != null)
        {
            _vp.SelectSlab(slab);
            if (iss.Subject2 is SlabPanel s2) _vp.ZoomBox(Math.Min(slab.X0, s2.X0), Math.Min(slab.Y0, s2.Y0), slab.Z, Math.Max(slab.X0 + slab.Lx, s2.X0 + s2.Lx), Math.Max(slab.Y0 + slab.Ly, s2.Y0 + s2.Ly), slab.Z);
            else _vp.ZoomSlab(slab);
        }
        else if (manual != null)
        {
            _vp.SelectObject(manual);
            _vp.ZoomBox(manual.X0, manual.Y0, manual.Z, manual.X1, manual.Y1, manual.Z);
        }
        else if (mem.Count > 0) { _vp.SetSelection(mem); _vp.ZoomSelection(); }
        else if (nodes.Count > 0) { _vp.SelectNodesOnly(nodes); _vp.ZoomNodes(nodes); }
        else { _vp.ClearSelection(); }
        StatusLeft.Text = "Élément concerné sélectionné  -  clic droit sur le message : corrections proposées, explication ou « Ignorer ».";
    }

    // ------------------------------------------------------------------ clic droit : corrections
    private static string Trunc(string s, int n) => s.Length <= n ? s : s[..(n - 1)] + "…";

    private bool BuildIssueMenu(ContextMenu cm)
    {
        cm.Items.Clear();
        var rows = (GridIssues.ItemsSource as List<IssueRow>) ?? new List<IssueRow>();
        var all = rows.Where(r => r.Issue != null).Select(r => r.Issue!).ToList();
        if (GridIssues.SelectedItem is not IssueRow row || row.Issue == null)
        {
            cm.Items.Add(Mi("Revérifier le modèle", RunCheckNow));
            if (_ignoredIssues.Count > 0) cm.Items.Add(Mi($"Réafficher les {_ignoredIssues.Count} message(s) ignoré(s)", () => { _ignoredIssues.Clear(); _ignoreWhy.Clear(); SaveMessageStatuses(); RunCheckNow(); }));
            return true;
        }
        AppendIssueItems(cm, row.Issue!, all, true);
        return true;
    }

    /// <summary>Corrections, explication et options d'un message de vérification du modèle (utilisé par l'onglet Vérification et par l'onglet Messages).</summary>
    private void AppendIssueItems(ContextMenu cm, ModelIssue iss, List<ModelIssue> all, bool withIgnore)
    {
        cm.Items.Add(MenuTitle(Trunc(iss.Message, 95)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Sélectionner et zoomer sur l'élément concerné", () => FocusIssue(iss)));
        var fixes = FixesFor(iss);
        var same = all.Where(x => x.Code == iss.Code).ToList();
        if (fixes.Count > 0)
        {
            cm.Items.Add(new Separator());
            cm.Items.Add(MenuTitle("Corrections proposées"));
            foreach (var f in fixes)
            {
                var ff = f;
                cm.Items.Add(Mi(ff.Label, () => ApplyFix(ff, new[] { iss })));
                if (ff.Batch && same.Count > 1)
                    cm.Items.Add(Mi($"{ff.BatchLabel} ({same.Count} messages de ce type)", () => ApplyFix(ff, same)));
            }
        }
        else
        {
            cm.Items.Add(new Separator());
            cm.Items.Add(Mi("Pas de correction automatique fiable pour ce message (voir « Que faire ? »)", () => { }, false));
        }
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Que faut-il faire ? (explication)...", () => MessageBox.Show(this, Explain(iss), "Vérification", MessageBoxButton.OK, MessageBoxImage.Information)));
        if (withIgnore && iss.Level != IssueLevel.Error)
            cm.Items.Add(Mi("Ignorer ce message (il ne sera plus affiché)", () => { _ignoredIssues.Add(IssueKey(iss)); SaveMessageStatuses(); FillIssues(ModelChecker.Check(_model)); Say("Message ignoré. Clic droit dans le tableau > « Réafficher les messages ignorés » pour le retrouver."); }));
        else if (withIgnore)
            cm.Items.Add(Mi("Ignorer (impossible : une erreur bloque le calcul)", () => { }, false));
        cm.Items.Add(Mi("Copier le message", () => { try { Clipboard.SetText(iss.Message); } catch { } }));
        cm.Items.Add(Mi("Revérifier le modèle", RunCheckNow));
        if (_ignoredIssues.Count > 0) cm.Items.Add(Mi($"Réafficher les {_ignoredIssues.Count} message(s) ignoré(s)", () => { _ignoredIssues.Clear(); _ignoreWhy.Clear(); SaveMessageStatuses(); RunCheckNow(); }));
    }

    /// <summary>Applique une correction : confirmation si elle supprime, instantané d'annulation, exécution, nouvelle vérification.</summary>
    private void ApplyFix(IssueFix f, IReadOnlyList<ModelIssue> list)
    {
        if (f.Direct != null) { f.Direct(); RunCheckNow(); return; }
        if (f.Confirm != null && MessageBox.Show(this, f.Confirm, "Correction", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        CommitGrids(); PushUndo();
        string snap = _undo.Count > 0 ? _undo[^1] : "";
        string? msg;
        try { msg = f.Run!(list); }
        catch (Exception ex)
        {
            if (snap != "") { _undo.RemoveAt(_undo.Count - 1); _model = ModelIO.FromJson(snap); BindModel(); UpdateUndoUi(); }
            Say("Correction impossible, le modèle est resté inchangé : " + ex.Message);
            return;
        }
        if (msg == null) { if (_undo.Count > 0) { _undo.RemoveAt(_undo.Count - 1); UpdateUndoUi(); } return; }
        OnModelEdited();
        RunCheckNow();
        Say(msg + "  (Ctrl+Z pour annuler.)");
    }

    // ------------------------------------------------------------------ catalogue des corrections
    private IEnumerable<int> BaseNodes()
    {
        var used = new HashSet<int>();
        foreach (var m in _model.Members) { used.Add(m.NodeI); used.Add(m.NodeJ); }
        foreach (var s in _model.Shells) { used.Add(s.N1); used.Add(s.N2); used.Add(s.N3); used.Add(s.N4); }
        var ns = _model.Nodes.Where(n => used.Contains(n.Id)).ToList();
        if (ns.Count == 0) return Array.Empty<int>();
        double zmin = ns.Min(n => n.Z);
        return ns.Where(n => n.Z <= zmin + 0.05).Select(n => n.Id).Distinct().ToList();
    }

    private string? SupportBase(bool fixedBase)
    {
        int c = 0;
        foreach (int id in BaseNodes())
        {
            if (_model.Supports.Any(s => s.NodeId == id)) continue;
            _model.Supports.Add(fixedBase ? new SupportDef { NodeId = id } : new SupportDef { NodeId = id, Rx = false, Ry = false, Rz = false });
            c++;
        }
        return c == 0 ? null : $"{c} appui(s) posé(s) au pied de la structure ({(fixedBase ? "encastrements" : "articulations")}, nœuds les plus bas).";
    }

    private static IEnumerable<T> Subjects<T>(IReadOnlyList<ModelIssue> l) where T : class => l.Select(x => x.Subject).OfType<T>().Distinct();

    private List<IssueFix> FixesFor(ModelIssue iss)
    {
        var L = new List<IssueFix>();
        IssueFix F(string label, Func<IReadOnlyList<ModelIssue>, string?> run, string? confirm = null, string? batch = null)
        {
            var f = new IssueFix { Label = label, Run = run, Confirm = confirm, Batch = batch != null, BatchLabel = batch ?? "" };
            L.Add(f); return f;
        }
        void D(string label, Action act) => L.Add(new IssueFix { Label = label, Direct = act });
        Member? Mem(int? id) => id == null ? null : _model.Members.FirstOrDefault(m => m.Id == id.Value);
        double LenOf(Member m)
        {
            var a = FindNode(m.NodeI); var b = FindNode(m.NodeJ);
            return a == null || b == null ? 0 : Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
        }

        switch (iss.Code)
        {
            case "NODE_DUP":
                F("Supprimer les doublons de ce nœud (garder le premier)", l =>
                {
                    int c = 0;
                    foreach (int id in l.Where(x => x.NodeId.HasValue).Select(x => x.NodeId!.Value).Distinct())
                    {
                        bool seen = false;
                        for (int k = 0; k < _model.Nodes.Count; k++)
                            if (_model.Nodes[k].Id == id) { if (!seen) seen = true; else { _model.Nodes.RemoveAt(k); k--; c++; } }
                    }
                    return c > 0 ? $"{c} doublon(s) de nœud supprimé(s)." : null;
                }, null, "Supprimer tous les doublons de nœuds");
                break;
            case "MEM_DUP":
                F("Supprimer les doublons de cette barre (garder la première)", l =>
                {
                    int c = 0;
                    foreach (int id in l.Where(x => x.MemberId.HasValue).Select(x => x.MemberId!.Value).Distinct())
                    {
                        bool seen = false;
                        for (int k = 0; k < _model.Members.Count; k++)
                            if (_model.Members[k].Id == id) { if (!seen) seen = true; else { _model.Members.RemoveAt(k); k--; c++; } }
                    }
                    return c > 0 ? $"{c} doublon(s) de barre supprimé(s)." : null;
                }, null, "Supprimer tous les doublons de barres");
                break;
            case "MEM_NODE_MISSING":
            case "MEM_SAME_NODES":
            case "MEM_ZERO":
                F($"Supprimer la barre {iss.MemberId} (et ses charges)", l =>
                {
                    var ids = l.Where(x => x.MemberId.HasValue).Select(x => x.MemberId!.Value).Distinct().ToList();
                    SelectionTools.Delete(_model, ids);
                    return $"{ids.Count} barre(s) supprimée(s).";
                }, $"Supprimer la barre {iss.MemberId} et ses charges ?", "Supprimer toutes ces barres");
                break;
            case "BEAM_SHORT":
                F($"Convertir la barre {iss.MemberId} en voile (poutre-voile maillée)", l =>
                {
                    var done = new List<string>(); var refused = new List<string>();
                    foreach (int id in l.Where(x => x.MemberId.HasValue).Select(x => x.MemberId!.Value).Distinct().ToList())
                    {
                        var r = DeepBeamConversion.ToWall(_model, id);
                        (r.Done ? done : refused).Add(r.Text);
                    }
                    if (refused.Count > 0) MessageBox.Show(this, "Non convertie(s) :\n" + string.Join("\n", refused), "Poutre-voile", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return done.Count == 0 ? null : string.Join("  ", done);
                }, $"Remplacer la barre {iss.MemberId} (L/h < 2) par un voile maillé de même hauteur et de même épaisseur ?\n\n" +
                   "- Les nœuds d'extrémité sont conservés : les poteaux restent reliés.\n" +
                   "- Les charges de barre saisies deviennent des charges nodales aux deux extrémités (même résultante).\n" +
                   "- Les charges de dalle qui s'appuyaient sur cette poutre sont reportées sur les autres bords du panneau (le logiciel ne reporte pas les dalles sur un voile).\n" +
                   "- Le voile se ferraille ensuite avec l'assistant Voiles.\n\nAnnulable par Ctrl+Z.", "Convertir toutes ces poutres");
                break;
            case "SEC_INVALID":
                F("Donner une section de départ (poteau 25 x 25 cm, poutre 25 x 40 cm)", l =>
                {
                    int c = 0;
                    foreach (var m in l.Select(x => Mem(x.MemberId)).Where(m => m != null && m.Kind == MaterialKind.ReinforcedConcrete).Select(m => m!).Distinct())
                    {
                        m.B = 0.25; m.H = m.Type == MemberType.Column ? 0.25 : 0.40; c++;
                    }
                    return c > 0 ? $"{c} barre(s) : section de départ appliquée. Lancez le calcul avec « Optimiser les sections » pour la redimensionner." : null;
                }, null, "Appliquer à toutes ces barres");
                break;
            case "COVER_BIG":
                F("Ramener l'enrobage à 4 cm (axe des aciers)", l =>
                {
                    int c = 0;
                    foreach (var m in l.Select(x => Mem(x.MemberId)).Where(m => m != null).Select(m => m!).Distinct())
                    {
                        m.Cover = Math.Min(0.04, 0.4 * Math.Min(m.B, m.H)); c++;
                    }
                    return $"{c} barre(s) : enrobage ramené à 4 cm (ou moins si la section est petite).";
                }, null, "Appliquer à toutes ces barres");
                break;
            case "PROFILE_UNKNOWN":
                D("Choisir un profilé du catalogue...", () =>
                {
                    var m = Mem(iss.MemberId); if (m == null) return;
                    var v = PromptWindow.Ask(this, "Profilé acier", $"Barre {m.Id} : le profilé « {m.Profile} » n'existe pas dans le catalogue.\nExemples : IPE300, HEA240, HEB200 (familles du catalogue : {string.Join(", ", SteelCatalog.All.Select(p => p.Name).Take(6))}...).", ("Profilé (ex. IPE300)", m.Profile));
                    if (v == null) return;
                    string p = v[0].Trim();
                    if (!SteelCatalog.TryGet(p, out var prof)) { MessageBox.Show(this, $"« {p} » n'est pas dans le catalogue : aucun changement.", "Profilé", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
                    CommitGrids(); PushUndo();
                    m.Profile = prof.Name;
                    OnModelEdited();
                    Say($"Barre {m.Id} : profilé {prof.Name}.");
                });
                break;
            case "LOAD_MEM_MISSING":
                F("Supprimer cette charge orpheline", l =>
                {
                    var del = Subjects<MemberLoad>(l).ToList();
                    foreach (var x in del) _model.MemberLoads.Remove(x);
                    return $"{del.Count} charge(s) orpheline(s) supprimée(s).";
                }, null, "Supprimer toutes les charges orphelines");
                break;
            case "LOAD_OUTSIDE":
                F("Ramener la charge sur la barre (au point le plus proche)", l =>
                {
                    int c = 0;
                    foreach (var x in Subjects<MemberLoad>(l))
                    {
                        var m = _model.Members.FirstOrDefault(q => q.Id == x.MemberId); if (m == null) continue;
                        double len = LenOf(m), max = x.Relative ? 1 : len;
                        x.A = Math.Clamp(x.A, 0, max); c++;
                    }
                    return $"{c} charge(s) ramenée(s) sur leur barre.";
                }, null, "Ramener toutes ces charges");
                F("Supprimer la charge", l => { var del = Subjects<MemberLoad>(l).ToList(); foreach (var x in del) _model.MemberLoads.Remove(x); return $"{del.Count} charge(s) supprimée(s)."; },
                    "Supprimer cette charge ponctuelle ?");
                break;
            case "LOAD_TRAP_OUT":
                F("Ramener la charge répartie dans la barre (bornes limitées à la longueur)", l =>
                {
                    int c = 0, gone = 0;
                    foreach (var x in Subjects<MemberLoad>(l))
                    {
                        var m = _model.Members.FirstOrDefault(q => q.Id == x.MemberId); if (m == null) continue;
                        double len = LenOf(m), max = x.Relative ? 1 : len;
                        x.A = Math.Clamp(x.A, 0, max); x.B = Math.Clamp(x.B, 0, max);
                        if (Math.Abs(x.B - x.A) < 1e-6) { _model.MemberLoads.Remove(x); gone++; } else c++;
                    }
                    return $"{c} charge(s) répartie(s) ramenée(s) dans la barre" + (gone > 0 ? $", {gone} supprimée(s) (étendue nulle après correction)." : ".");
                }, null, "Ramener toutes ces charges");
                F("Supprimer la charge", l => { var del = Subjects<MemberLoad>(l).ToList(); foreach (var x in del) _model.MemberLoads.Remove(x); return $"{del.Count} charge(s) supprimée(s)."; },
                    "Supprimer cette charge répartie ?");
                break;
            case "LOAD_TRAP_ZERO":
                F("Supprimer cette charge d'étendue nulle", l => { var del = Subjects<MemberLoad>(l).ToList(); foreach (var x in del) _model.MemberLoads.Remove(x); return $"{del.Count} charge(s) supprimée(s)."; },
                    null, "Supprimer toutes ces charges");
                break;
            case "SURF_NOBEAM":
            case "SURF_FREE_EDGES":
            case "SURF_PARTIAL":
                if (iss.Subject is SurfaceLoad sl)
                {
                    var slab = SlabOfLoad(sl);
                    if (slab != null)
                    {
                        // la vraie correction : le logiciel crée les poutres de rive manquantes (et, au choix, les poteaux d'angle)
                        Func<IReadOnlyList<ModelIssue>, bool, string?> perimeter = (l, cols) =>
                        {
                            var ds = l.Select(x => x.Subject).OfType<SurfaceLoad>().Select(SlabOfLoad).Where(q => q != null).Select(q => q!).Distinct().ToList();
                            var texts = new List<string>(); int made = 0;
                            foreach (var d in ds)
                            {
                                var r = SlabPerimeter.Create(_model, d, cols);
                                if (r.Beams + r.Columns + r.Nodes > 0) { texts.Add(r.Text); made++; }
                            }
                            return made == 0 ? null : string.Join("  ", texts);
                        };
                        F($"Créer les poutres de rive manquantes de la dalle {slab.Name}", l => perimeter(l, false),
                            $"Créer, sur les bords de la dalle {slab.Name} qui n'ont pas de poutre, des poutres de rive (section prise sur le modèle, sinon 25 x 40 cm), reliées aux nœuds existants ?\nElles devront être portées par des poteaux : utilisez l'option suivante si les angles n'en ont pas.", "Appliquer à toutes ces dalles");
                        F($"Créer les poutres de rive ET les poteaux d'angle manquants (jusqu'au niveau le plus bas, encastrés en pied)", l => perimeter(l, true),
                            $"Créer les poutres de rive manquantes de la dalle {slab.Name} et, sous chaque angle qui n'est pas déjà porté, un poteau (section prise sur le modèle, sinon 25 x 25 cm) descendu jusqu'au niveau le plus bas, avec un encastrement en pied ?", "Appliquer à toutes ces dalles");
                        if (iss.Code == "SURF_NOBEAM")
                        {
                            F($"Mettre la dalle {slab.Name} en « métré seul » (non chargée, pour le calcul)", l =>
                            {
                                var names = l.Select(x => x.Subject).OfType<SurfaceLoad>().Select(SlabOfLoad).Where(q => q != null).Select(q => q!).Distinct().ToList();
                                foreach (var d in names) { d.CalcMode = SlabCalcMode.MassOnly; StoreyOps.SyncSlabLoads(_model, d); }
                                return $"Dalle(s) {string.Join(", ", names.Select(d => d.Name))} : métré seul, charges retirées du calcul. Posez les poutres de contour pour les recharger.";
                            }, $"La dalle {slab.Name} n'est plus chargée dans le calcul (son poids et ses charges ne descendent plus). À utiliser seulement si la dalle est provisoire ou portée ailleurs. Continuer ?", "Appliquer à toutes ces dalles");
                            F($"Supprimer la dalle {slab.Name} (et ses charges)", l =>
                            {
                                var ds = l.Select(x => x.Subject).OfType<SurfaceLoad>().Select(SlabOfLoad).Where(q => q != null).Select(q => q!).Distinct().ToList();
                                foreach (var d in ds) _vp.RemoveSlab(d);
                                return $"{ds.Count} dalle(s) supprimée(s).";
                            }, $"Supprimer la dalle {slab.Name} et ses charges surfaciques ?");
                        }
                        if (iss.Code == "SURF_FREE_EDGES")
                            D($"Console de la dalle {slab.Name} : déclarer une charge de bout (garde-corps, kN/m)...", () =>
                            {
                                var v = PromptWindow.Ask(this, $"Console - dalle {slab.Name}", $"Charge linéique de bout (garde-corps, acrotère, mur...) en kN/m, prise en compte dans le calcul de la console. Valeur actuelle : {F3(slab.CantileverTipKnM)} kN/m ; 0 = aucune.", ("Charge de bout (kN/m)", F3(slab.CantileverTipKnM > 0 ? slab.CantileverTipKnM : 1.0)));
                                if (v == null) return;
                                CommitGrids(); PushUndo();
                                slab.CantileverTipKnM = Math.Max(0, Ui.Num(v[0], slab.CantileverTipKnM));
                                OnModelEdited();
                                Say($"Dalle {slab.Name} : charge de bout {F3(slab.CantileverTipKnM)} kN/m. Relancez le calcul (F5) : la console est recalculée.");
                            });
                        D($"Propriétés de la dalle {slab.Name} (épaisseur, charges, console, mode de calcul)...", () => SlabProps(slab));
                    }
                    else
                    {
                        F("Supprimer cette charge surfacique", l => { var del = Subjects<SurfaceLoad>(l).ToList(); foreach (var x in del) _model.SurfaceLoads.Remove(x); return $"{del.Count} charge(s) surfacique(s) supprimée(s)."; },
                            "Supprimer cette charge surfacique ?");
                        D("Modifier la charge...", () => { _vp.SelectObject(sl); EditObject(sl); });
                    }
                }
                break;
            case "NLOAD_NODE":
                F("Supprimer cette charge nodale orpheline", l => { var del = Subjects<NodalLoad>(l).ToList(); foreach (var x in del) _model.NodalLoads.Remove(x); return $"{del.Count} charge(s) nodale(s) supprimée(s)."; },
                    null, "Supprimer toutes les charges nodales orphelines");
                break;
            case "SUPPORT_NODE":
                F("Supprimer cet appui orphelin", l => { var del = Subjects<SupportDef>(l).ToList(); foreach (var x in del) _model.Supports.Remove(x); return $"{del.Count} appui(s) orphelin(s) supprimé(s)."; },
                    null, "Supprimer tous les appuis orphelins");
                break;
            case "SHELL_NODE":
                F("Supprimer cette maille (un de ses nœuds n'existe plus)", l => { var del = Subjects<ShellPanel>(l).ToList(); foreach (var x in del) _model.Shells.Remove(x); return $"{del.Count} maille(s) supprimée(s)."; },
                    "Supprimer cette maille de coque ?", "Supprimer toutes ces mailles");
                break;
            case "SHELL_THIN":
                if (iss.Subject is ShellPanel shp)
                {
                    D($"Prédimensionner l'épaisseur ({shp.Name})...", () => PreDesignShell(shp.Name));
                    double t = shp.Kind == "Voile" ? 0.15 : 0.20;
                    F($"Mettre l'épaisseur de {shp.Name} à {t * 100:0} cm (toutes ses mailles)", l =>
                    {
                        var names = l.Select(x => x.Subject).OfType<ShellPanel>().Select(s => s.Name).Distinct().ToList();
                        int c = 0;
                        foreach (var cell in _model.Shells.Where(q => names.Contains(q.Name))) { cell.T = cell.Kind == "Voile" ? 0.15 : 0.20; c++; }
                        return $"{c} maille(s) : épaisseur portée à {(shp.Kind == "Voile" ? 15 : 20)} cm. Relancez le calcul.";
                    }, null, "Appliquer à toutes ces coques");
                }
                break;
            case "NO_SUPPORT":
                F("Encastrer le pied de la structure (nœuds les plus bas)", l => SupportBase(true));
                F("Articuler le pied de la structure (nœuds les plus bas)", l => SupportBase(false));
                break;
            case "MECHANISM":
                F("Passer tous les appuis en encastrement", l =>
                {
                    foreach (var s in _model.Supports) { s.Ux = s.Uy = s.Uz = s.Rx = s.Ry = s.Rz = true; }
                    return $"{_model.Supports.Count} appui(s) passé(s) en encastrement.";
                }, "Transformer tous les appuis existants en encastrements (6 degrés bloqués) ?");
                F("Ajouter un encastrement au pied de la structure (nœuds les plus bas)", l => SupportBase(true));
                break;
            case "UNSUPPORTED":
                if (iss.Subject is int[])
                {
                    F("Encastrer le nœud le plus bas de cette partie", l =>
                    {
                        int c = 0;
                        foreach (var arr in l.Select(x => x.Subject).OfType<int[]>())
                        {
                            var low = _model.Nodes.Where(n => arr.Contains(n.Id)).OrderBy(n => n.Z).FirstOrDefault();
                            if (low != null && !_model.Supports.Any(s => s.NodeId == low.Id)) { _model.Supports.Add(new SupportDef { NodeId = low.Id }); c++; }
                        }
                        return c > 0 ? $"{c} encastrement(s) posé(s) sous la/les partie(s) non appuyée(s)." : null;
                    }, "Poser un encastrement sur le nœud le plus bas de cette partie ? Vérifiez que cette partie doit bien reposer là.", "Appliquer à toutes ces parties");
                    F("Fusionner les nœuds proches (5 mm) pour relier cette partie au reste", l =>
                    {
                        var r = ModifyTools.MergeNodes(_model, 0.005);
                        return r.MergedNodes > 0 ? $"{r.MergedNodes} nœud(s) fusionné(s) ({r.RemovedMembers} barre(s) devenue(s) nulle(s) retirée(s))." : null;
                    });
                }
                break;
            case "NODE_ISOLATED":
                F($"Supprimer le nœud {iss.NodeId}", l =>
                {
                    var ids = l.Where(x => x.NodeId.HasValue).Select(x => x.NodeId!.Value).Distinct().ToList();
                    _vp.DeleteNodes(ids);
                    return $"{ids.Count} nœud(s) isolé(s) supprimé(s).";
                }, $"Supprimer le nœud {iss.NodeId} (isolé) avec son éventuel appui ou sa charge ?", "Supprimer tous les nœuds isolés");
                break;
            case "NODE_OVERLAP":
                F("Fusionner les nœuds superposés (tolérance 2 mm)", l =>
                {
                    var r = ModifyTools.MergeNodes(_model, 0.002);
                    return r.MergedNodes > 0 ? $"{r.MergedNodes} nœud(s) fusionné(s)" + (r.RemovedMembers > 0 ? $" ; {r.RemovedMembers} barre(s) devenue(s) nulle(s) retirée(s)." : ".") : null;
                });
                break;
            case "NO_LOAD":
                F("Inclure le poids propre dans le calcul", l => { _model.IncludeSelfWeight = true; ChkSelfWeight.IsChecked = true; return "Poids propre inclus. Ajoutez ensuite les charges d'exploitation et permanentes."; });
                D("Ouvrir l'assistant de charges...", () => LoadAssistant_Click(this, new RoutedEventArgs()));
                break;
            case "SLAB_DIM":
                if (iss.Subject is SlabPanel sd1)
                {
                    F($"Supprimer la dalle {sd1.Name}", l => { var ds = Subjects<SlabPanel>(l).ToList(); foreach (var s in ds) _vp.RemoveSlab(s); return $"{ds.Count} dalle(s) supprimée(s)."; },
                        $"Supprimer la dalle {sd1.Name} (dimensions invalides) et ses charges ?");
                    D($"Propriétés de la dalle {sd1.Name}...", () => SlabProps(sd1));
                }
                break;
            case "SLAB_THIN":
                if (iss.Subject is SlabPanel st1)
                {
                    F($"Mettre l'épaisseur à 12 cm ({st1.Name})", l =>
                    {
                        var ds = Subjects<SlabPanel>(l).ToList();
                        foreach (var s in ds) { s.H = 0.12; StoreyOps.SyncSlabLoads(_model, s); }
                        return $"{ds.Count} dalle(s) : épaisseur 12 cm, charges recalculées.";
                    }, null, "Mettre toutes ces dalles à 12 cm");
                    D($"Propriétés de la dalle {st1.Name}...", () => SlabProps(st1));
                }
                break;
            case "SLAB_EDGE":
                if (iss.Subject is SlabPanel se1) D($"Propriétés de la dalle {se1.Name}...", () => SlabProps(se1));
                break;
            case "SLAB_OVERLAP":
                if (iss.Subject is SlabPanel oa && iss.Subject2 is SlabPanel ob)
                {
                    F($"Supprimer la dalle {oa.Name}", l => { _vp.RemoveSlab(oa); return $"Dalle {oa.Name} supprimée."; }, $"Supprimer la dalle {oa.Name} et ses charges ? (la dalle {ob.Name} est conservée)");
                    F($"Supprimer la dalle {ob.Name}", l => { _vp.RemoveSlab(ob); return $"Dalle {ob.Name} supprimée."; }, $"Supprimer la dalle {ob.Name} et ses charges ? (la dalle {oa.Name} est conservée)");
                }
                break;
            case "SURF_OVERLAP":
                if (iss.Subject is SurfaceLoad la && iss.Subject2 is SurfaceLoad lb)
                {
                    if (!_vp.IsSlabGenerated(la)) F($"Supprimer la charge « {la.Name} »", l => { _model.SurfaceLoads.Remove(la); return $"Charge « {la.Name} » supprimée."; }, $"Supprimer la charge surfacique « {la.Name} » ? (« {lb.Name} » est conservée)");
                    if (!_vp.IsSlabGenerated(lb)) F($"Supprimer la charge « {lb.Name} »", l => { _model.SurfaceLoads.Remove(lb); return $"Charge « {lb.Name} » supprimée."; }, $"Supprimer la charge surfacique « {lb.Name} » ? (« {la.Name} » est conservée)");
                }
                break;
        }
        return L;
    }

    // ------------------------------------------------------------------ explications (ce qu'il faut faire quand aucune correction automatique n'est sûre)
    private string Explain(ModelIssue iss)
    {
        string head = iss.Message + "\n\n";
        return head + iss.Code switch
        {
            "NODE_DUP" or "MEM_DUP" => "Le même numéro est utilisé plusieurs fois (fichier modifié à la main ou fusion de projets). Le clic droit propose de supprimer les doublons ; vérifiez ensuite que la bonne géométrie a été gardée.",
            "MEM_NODE_MISSING" => "La barre référence un nœud qui n'existe plus. Supprimez la barre, ou recréez le nœud manquant (tableau Nœuds) aux bonnes coordonnées.",
            "MEM_SAME_NODES" or "MEM_ZERO" => "La barre n'a aucune longueur : elle ne peut pas être calculée. Supprimez-la, ou séparez ses deux nœuds.",
            "SEC_INVALID" => "La section est vide ou négative. Donnez une section réelle dans le panneau « Modifier la barre », ou une section de départ (clic droit) puis laissez le calcul l'optimiser.",
            "COVER_BIG" => "L'enrobage mesuré à l'axe des aciers dépasse la moitié de la section : aucune armature ne peut y tenir. Réduisez l'enrobage (4 à 5 cm) ou augmentez la section.",
            "BEAM_SHORT" => "Une poutre dont la portée est inférieure à deux fois sa hauteur n'est plus une poutre : le modèle de flexion ne s'applique pas (poutre-voile). Le clic droit la remplace par un voile maillé de même hauteur et épaisseur, nœuds d'extrémité conservés, charges de barre ramenées en charges nodales. Si la portée est fausse, corrigez plutôt la géométrie.",
            "PROFILE_UNKNOWN" => "Le nom du profilé n'est pas dans le catalogue (IPE, HEA, HEB, ou vos profilés personnalisés). Choisissez-en un via le clic droit.",
            "LOAD_MEM_MISSING" => "La charge est attachée à une barre supprimée : elle ne sert plus à rien. Supprimez-la.",
            "LOAD_OUTSIDE" or "LOAD_TRAP_OUT" => "La position de la charge sort de la barre (longueur plus courte que prévu ?). Le clic droit la ramène dans la barre au point le plus proche ; vérifiez que c'est bien l'endroit voulu.",
            "LOAD_TRAP_ZERO" => "Début et fin de la charge sont confondus : elle ne charge rien. Supprimez-la ou donnez-lui une étendue.",
            "SURF_NOBEAM" => "Aucune poutre ne borde cette zone chargée : il n'y a aucun chemin pour descendre la charge. Le clic droit crée les poutres de rive (et, au choix, les poteaux d'angle jusqu'au niveau le plus bas, encastrés en pied) ; les sections créées sont des valeurs de départ que le calcul optimise. Si la dalle est provisoire ou portée ailleurs, mettez-la en « métré seul ».",
            "SURF_FREE_EDGES" => "Certains bords de la dalle n'ont pas de poutre. Si la dalle n'est portée que d'un côté, c'est une console : le logiciel la calcule (flexion, chapeaux, tranchant, flèche, ancrage, torsion de la poutre d'appui : onglet « Dalles / Semelles / Alertes ») ; déclarez le garde-corps en bout par le clic droit. Si une poutre de rive est prévue, le clic droit la crée.",
            "SURF_PARTIAL" => "Une partie de la charge n'arrive sur aucune poutre : un bord n'est pas porté, ou une poutre s'arrête avant la dalle. Complétez les poutres de contour ou redimensionnez la dalle.",
            "NLOAD_NODE" or "SUPPORT_NODE" => "Le nœud référencé n'existe plus. Supprimez la charge ou l'appui orphelin.",
            "SHELL_NODE" => "Une maille de coque référence un nœud supprimé. Supprimez la maille ou recréez le nœud.",
            "SHELL_THIN" => "Épaisseur inférieure à 5 cm : irréaliste pour un voile ou une dalle. Prédimensionnez-la, ou fixez 15 à 20 cm.",
            "NO_SUPPORT" => "Sans appui, la structure flotte : le calcul est impossible. Posez des appuis au pied des poteaux (outil Appui), ou utilisez le clic droit pour encastrer le pied de la structure.",
            "MECHANISM" => "Une structure 3D doit bloquer au moins 6 degrés de liberté pour ne pas bouger comme un corps rigide. Ajoutez des appuis, ou passez les appuis existants en encastrement.",
            "UNSUPPORTED" => "Cette partie n'est reliée à aucun appui : elle flotte. Reliez-la au reste (barre, fusion de nœuds quasi confondus) ou donnez-lui un appui. Les nœuds concernés sont sélectionnés dans la vue.",
            "NODE_ISOLATED" => "Un nœud sans barre ne sert à rien (reste d'une suppression, ou point de repère). Supprimez-le, ou tracez une barre à partir de lui.",
            "NODE_OVERLAP" => "Deux nœuds sont exactement au même endroit mais ne sont pas reliés : les barres des deux côtés ne se transmettent aucun effort. Fusionnez-les.",
            "NO_LOAD" => "Rien n'est chargé et le poids propre est exclu : tous les efforts seraient nuls. Incluez le poids propre ou ajoutez des charges.",
            "SLAB_DIM" => "La dalle a une dimension nulle ou négative : supprimez-la ou corrigez-la dans ses propriétés.",
            "SLAB_THIN" => "Une dalle de moins de 10 cm pose problème (enrobage, flèche). Passez à 12 cm au moins, ou justifiez-la.",
            "SLAB_EDGE" => "Information : les bords de la dalle ont été ajustés sur les faces des poutres, ses charges sont reportées sur les axes des poutres. Rien à corriger.",
            "SLAB_OVERLAP" => "Deux dalles occupent le même emplacement au même niveau : la charge serait comptée deux fois. Supprimez l'une des deux, ou redimensionnez-la (propriétés de la dalle).",
            "SURF_OVERLAP" => "Deux charges surfaciques se recouvrent : vérifiez qu'elles ne comptent pas deux fois la même surface (dalle + charge manuelle, par exemple). Supprimez celle qui fait doublon.",
            _ => "Pas d'explication détaillée pour ce message : sélectionnez l'élément concerné (clic sur le message) et vérifiez-le dans les propriétés."
        };
    }
}
