using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Licensing;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine;
using StructCalc.Engine.Drawing;

namespace StructCalc.UI;

public sealed class IssueRow
{
    public string Niveau { get; set; } = "";
    public string Message { get; set; } = "";
    public string Noeud { get; set; } = "";
    public string Barre { get; set; } = "";
    /// <summary>Le message d'origine (code, objet visé) : sert à sélectionner l'élément et à proposer des corrections.</summary>
    public ModelIssue? Issue { get; set; }
}

/// <summary>Outils de modélisation (dessin, annulation, correction de section), vérification du modèle, plans, IFC, licence.</summary>
public partial class MainWindow
{
    private readonly List<string> _undo = new();
    private int _editingId = -1;

    private void InitTools()
    {
        _vp.BeforeEdit += PushUndo;
        _vp.ModelEdited += OnModelEdited;
        _vp.SlabDrawn += OnSlabDrawn;
        _vp.StairDrawn += OnStairDrawn;
        _vp.Hint += msg => StatusLeft.Text = msg;
        var names = SteelCatalog.All.Select(p => p.Name).ToList();
        NewProfileBox.ItemsSource = names; NewProfileBox.SelectedItem = "IPE300";
        EdProfile.ItemsSource = names;
        EdCase.ItemsSource = new[] { "G", "Q", "W", "S" }; EdCase.SelectedIndex = 0;
        StatusRight.Text = "kN, m, MPa  ·  " + LicenseManager.Current.Message;
    }

    // ------------------------------------------------------------------ annuler / rétablir
    private readonly List<string> _redo = new();

    /// <summary>À appeler AVANT chaque modification du modèle : mémorise l'état courant (et efface la pile « Rétablir »).</summary>
    private void PushUndo()
    {
        try
        {
            _undo.Add(ModelIO.ToJson(_model));
            if (_undo.Count > 80) _undo.RemoveAt(0);
            _redo.Clear();
        }
        catch { }
        UpdateUndoUi();
    }

    private void UpdateUndoUi()
    {
        if (UndoBtn == null || RedoBtn == null) return;
        UndoBtn.IsEnabled = _undo.Count > 0; RedoBtn.IsEnabled = _redo.Count > 0;
        UndoBtn.ToolTip = _undo.Count > 0 ? $"Annuler la dernière action (Ctrl+Z) - {_undo.Count} action(s) mémorisée(s)" : "Rien à annuler";
        RedoBtn.ToolTip = _redo.Count > 0 ? $"Rétablir l'action annulée (Ctrl+Y) - {_redo.Count} action(s)" : "Rien à rétablir";
        if (UndoMenu != null) UndoMenu.IsEnabled = _undo.Count > 0;
        if (RedoMenu != null) RedoMenu.IsEnabled = _redo.Count > 0;
    }

    private void Undo_Click(object sender, RoutedEventArgs e)
    {
        if (_undo.Count == 0) { StatusLeft.Text = "Rien à annuler."; return; }
        CommitGrids();
        string js = _undo[^1];
        _undo.RemoveAt(_undo.Count - 1);
        try { _redo.Add(ModelIO.ToJson(_model)); } catch { }
        _model = ModelIO.FromJson(js);
        BindModel();
        UpdateUndoUi();
        StatusLeft.Text = "Action annulée.  Pour la rétablir : bouton « ↷ Rétablir » ou Ctrl+Y.";
    }

    private void Redo_Click(object sender, RoutedEventArgs e)
    {
        if (_redo.Count == 0) { StatusLeft.Text = "Rien à rétablir."; return; }
        CommitGrids();
        string js = _redo[^1];
        _redo.RemoveAt(_redo.Count - 1);
        try { _undo.Add(ModelIO.ToJson(_model)); } catch { }
        _model = ModelIO.FromJson(js);
        BindModel();
        UpdateUndoUi();
        StatusLeft.Text = "Action rétablie.";
    }

    /// <summary>Crée la dalle dessinée à la souris (nom automatique, épaisseur de la dernière dalle ou 16 cm) et ses charges surfaciques G et Q.</summary>
    private SlabPanel? _slabProto;
    private bool _askingSlab, _slabByBay;
    private string _slabPrefix = "D";
    private double? _slabLevelZ;

    /// <summary>Ouvre la fenêtre « type de dalle » ; Annuler repasse en sélection.</summary>
    private bool AskSlabType()
    {
        _askingSlab = true;
        try
        {
            var lvls = StructCalc.Engine.Structure.StructureAnalyzer.Analyze(_model).Levels.Select(l => (l.Name, l.Z));
            var w = new SlabDrawWindow(_slabProto ?? _model.Slabs.LastOrDefault(), lvls, _slabPrefix, _slabByBay, _slabLevelZ) { Owner = this };
            if (w.ShowDialog() == true)
            {
                _slabProto = w.Proto; _slabPrefix = w.Prefix; _slabByBay = w.ByBay; _slabLevelZ = w.LevelZ;
                _vp.SlabByBay = w.ByBay;
                if (w.LevelZ is double lz) { WorkBox.Text = Ui.Fmt(lz); ToolOption_Changed(this, new RoutedEventArgs()); }
                StatusLeft.Text = $"{StructCalc.Engine.Structure.SlabPresets.Name(w.Proto.Kind)}, h = {w.Proto.H * 100:0} cm : " + (w.ByBay ? "cliquez dans une trame en vue Plan." : "cliquez deux coins opposés en vue Plan.") + " (Bouton ▾ pour changer le type.)";
                return true;
            }
            ToolSelectNone();
            return false;
        }
        finally { _askingSlab = false; }
    }

    private StairDef? _stairProto;
    private bool _askingStair;
    private string _stairPrefix = "E";
    private bool _stairFromAbove;

    /// <summary>Ouvre la fenêtre « type d'escalier » ; Annuler repasse en sélection.</summary>
    private bool AskStairType()
    {
        _askingStair = true;
        try
        {
            var w = new StairDrawWindow(_stairProto ?? _model.Stairs.LastOrDefault(), _stairPrefix, _stairFromAbove) { Owner = this };
            if (w.ShowDialog() == true)
            {
                _stairProto = w.Proto; _stairPrefix = w.Prefix; _stairFromAbove = w.FromAbove; _vp.StairProto = w.Proto;
                int li = Array.FindIndex(StairWizardWindow.LayoutItems, x => x.Item2 == w.Proto.Layout);
                StatusLeft.Text = $"Escalier {StairWizardWindow.LayoutShort[Math.Max(0, li)].ToLowerInvariant()}, emmarchement {w.Proto.WidthM:0.00} m : en vue Plan, cliquez le départ puis la direction de montée. (Bouton ▾ pour changer le type.)";
                return true;
            }
            ToolSelectNone();
            return false;
        }
        finally { _askingStair = false; }
    }

    private void StairSetup_Click(object sender, RoutedEventArgs e) { if (RbStair.IsChecked == true) AskStairType(); else RbStair.IsChecked = true; }

    private void OnStairDrawn(double x, double y, double angle, double z)
    {
        var proto = _stairProto; if (proto == null) return;
        PushUndo();
        int n = 1; while (_model.Stairs.Any(s => s.Name == _stairPrefix + n)) n++;
        var d = proto.Clone();
        d.Name = _stairPrefix + n; d.X = Math.Round(x, 3); d.Y = Math.Round(y, 3); d.Z = z; d.AngleDeg = angle; d.Placed = true;
        var info = LevelInfoNow();
        string note = "";
        if (_stairFromAbove)
        {
            // tracé depuis l'étage : z = arrivée (haut) ; le départ est le niveau juste en dessous
            int top = info.Levels.FindIndex(l => Math.Abs(l.Z - z) < 0.05);
            if (top > 0)
            {
                double zb = info.Levels[top - 1].Z;
                d.Z = zb; if (d.HeightM < 0.5) d.HeightM = info.Levels[top].Z - zb;
                note = $" (de {info.Levels[top - 1].Label} vers {info.Levels[top].Label})";
            }
            else
            {
                if (d.HeightM < 0.5) d.HeightM = 3.06;
                d.Z = z - d.HeightM;
                note = " — aucun niveau en dessous trouvé : départ placé à " + d.Z.ToString("0.00") + " m";
            }
        }
        else if (d.HeightM < 0.5)
        {
            int li = info.Levels.FindIndex(l => Math.Abs(l.Z - z) < 0.05);
            double ha = li >= 0 ? StructCalc.Engine.Structure.StoreyOps.HeightAbove(info, li) : 0;
            d.HeightM = ha > 0.5 ? ha : 3.06;
        }
        _model.Stairs.Add(d);
        try { GridSlabs.Items.Refresh(); } catch { }
        _vp.SelectObject(d, false);
        OnModelEdited();
        var g = StructCalc.Engine.Stairs.StairGeometryBuilder.Build(d);
        StatusLeft.Text = $"Escalier {d.Name} posé{note}, hauteur {d.HeightM:0.00} m : {g.Risers} contremarches de {g.RiserM * 100:0.#} cm, giron {g.TreadM * 100:0.#} cm" + (g.Ok ? "" : " — attention : " + g.Warnings.FirstOrDefault()) + ".  Clic droit > Prédimensionner / Dimensionner ; Ctrl+Z annule.";
    }

    private void SlabSetup_Click(object sender, RoutedEventArgs e) { if (RbSlab.IsChecked == true) AskSlabType(); else RbSlab.IsChecked = true; }

    private void OnSlabDrawn(double x0, double y0, double x1, double y1, double z)
    {
        PushUndo();
        int n = 1; while (_model.Slabs.Any(s => s.Name == _slabPrefix + n)) n++;
        var like = _slabProto ?? _model.Slabs.LastOrDefault();
        var s = new SlabPanel
        {
            Name = _slabPrefix + n, Lx = Math.Round(x1 - x0, 3), Ly = Math.Round(y1 - y0, 3), H = like?.H ?? 0.16, GExtra = like?.GExtra ?? 1.5,
            Q = like?.Q ?? 2.5, Continuity = like?.Continuity ?? SlabContinuity.Interieure, Crack = like?.Crack ?? CrackingClass.PeuPrejudiciable,
            Placed = true, X0 = Math.Round(x0, 3), Y0 = Math.Round(y0, 3), Z = z,
            Gamma = like?.Gamma ?? 25, CalcMode = like?.CalcMode ?? SlabCalcMode.Bidirectional,
            Kind = like?.Kind ?? SlabKind.Pleine, HourdisCm = like?.HourdisCm ?? 0, ToppingCm = like?.ToppingCm ?? 0, VolumeFactor = like?.VolumeFactor ?? 1, CoverCm = like?.CoverCm ?? 0
        };
        StructCalc.Engine.Structure.SlabPresets.Apply(s);
        _model.Slabs.Add(s);
        StructCalc.Engine.Structure.StoreyOps.SyncSlabLoads(_model, s);       // charges G (γ x h + permanentes) et Q à la cote de la dalle
        OnModelEdited();
        try { GridSlabs.Items.Refresh(); } catch { }
        Log($"Dalle {s.Name} dessinée : {s.Lx:0.00} x {s.Ly:0.00} m, h = {s.H * 100:0} cm, volume {s.Volume:0.00} m³, cote {z:0.00} m (charges G et Q créées ; clic droit sur la dalle : épaisseur, volume, mode de calcul, niveau).");
        StatusLeft.Text = $"Dalle {s.Name} ajoutée - continuez à dessiner ou relancez le calcul (F5).";
    }

    private void OnModelEdited()
    {
        _dirty = true;
        _out = null; _vp.Output = null; _vp.Issues = null;
        GridResults.ItemsSource = null; GridIssues.ItemsSource = null;
        ResultText.Text = ""; QtyText.Text = "";
        StatusMid.Text = $"{_model.Nodes.Count} nœuds · {_model.Members.Count} barres";
        StatusLeft.Text = "Modèle modifié : relancez le calcul (F5).";
        try { foreach (var g in new[] { GridNodes, GridMembers, GridSupports, GridNodalLoads, GridMemberLoads }) g.Items.Refresh(); } catch { }
        _vp.PruneHidden();
        _vp.Redraw();
        RefreshStructure();
        _lastIssues = null; _msgStale = true;
        if (ReferenceEquals(BottomTabs.SelectedItem, TabMsgs)) RebuildMessages();
    }

    // ------------------------------------------------------------------ outils de dessin
    private void Tool_Checked(object sender, RoutedEventArgs e)
    {
        if (_vp == null) return;
        if (sender is RadioButton rb && rb.Tag is string t && Enum.TryParse<EditTool>(t, out var tool))
        {
            _vp.Tool = tool;
            _vp.CancelPending();            // repart d'un état propre (point de départ, sélection de points...)
            ToolOption_Changed(sender, e);   // resynchronise pas de grille, niveau de travail, type d'appui
            NewSection_Changed(sender, e);   // et section des nouvelles barres
            StatusLeft.Text = tool switch
            {
                EditTool.Node => "Nœud : cliquez pour placer un nœud (accroché à la grille).",
                EditTool.Member => "Barre : cliquez le point de départ, puis les points suivants ; Échap pour terminer.",
                EditTool.Support => "Appui : cliquez un nœud pour poser ou retirer un appui.",
                EditTool.Slab => "Dalle : en vue Plan, cliquez deux coins opposés (accrochages actifs). La dalle prend le niveau de travail.",
                EditTool.Stair => "Escalier : en vue Plan, cliquez le départ puis la direction de la montée. Il prend le niveau de travail.",
                EditTool.Dim => "Cote : cliquez le premier point puis le second (accrochage aux nœuds, axes, niveaux). Menu Cotation pour les options.",
                EditTool.Delete => "Supprimer : cliquez une barre, un nœud ou une dalle.",
                _ => "Sélection : cliquez une barre pour voir ses résultats et la modifier.",
            };
            if (tool == EditTool.Slab && !_askingSlab) { if (!AskSlabType()) return; }
            if (tool == EditTool.Stair && !_askingStair) { if (!AskStairType()) return; }
            if ((tool == EditTool.Slab || tool == EditTool.Stair) && _vp.Mode != ViewMode.Plan) _vp.SetMode(ViewMode.Plan);
        }
    }

    private void DarkMode_Click(object sender, RoutedEventArgs e)
    {
        Theme.Set(DarkMenu.IsChecked);
        StatusLeft.Text = Theme.Dark ? "Mode sombre activé." : "Mode clair activé.";
    }

    private void InitTheme()
    {
        DarkMenu.IsChecked = Theme.Dark;
        Theme.Changed += () => { DarkMenu.IsChecked = Theme.Dark; _vp?.Redraw(); };
        ToolOption_Changed(this, new RoutedEventArgs());
        NewSection_Changed(this, new RoutedEventArgs());
    }

    private void ToolSelectNone() { if (RbSelect != null) RbSelect.IsChecked = true; }

    private void ToolOption_Changed(object sender, RoutedEventArgs e)
    {
        if (_vp == null || ComboGrid == null || WorkBox == null || ComboSupport == null) return;
        if (ComboGrid.SelectedItem is ComboBoxItem it && double.TryParse(it.Content?.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out double g))
            _vp.GridStep = g;
        _vp.WorkOffset = Num(WorkBox.Text, 0);
        _vp.SupportFixed = ComboSupport.SelectedIndex == 0;
    }

    private void NewSection_Changed(object sender, RoutedEventArgs e)
    {
        if (_vp == null || RbNewSteel == null || NewBBox == null || NewHBox == null || NewProfileBox == null) return;
        _vp.NewSteel = RbNewSteel.IsChecked == true;
        _vp.NewB = Math.Max(0.1, Num(NewBBox.Text, 25) / 100);
        _vp.NewH = Math.Max(0.1, Num(NewHBox.Text, 45) / 100);
        _vp.NewProfile = NewProfileBox.SelectedItem as string ?? "IPE300";
    }

    // ------------------------------------------------------------------ modification d'une barre
    private void FillEditor(Member? mem)
    {
        if (EdPanel == null) return;
        _editingId = mem?.Id ?? -1;
        EdPanel.IsEnabled = mem != null;
        if (mem == null) return;
        EdMat.SelectedIndex = mem.Kind == MaterialKind.Steel ? 1 : 0;
        EdType.SelectedIndex = mem.Type == MemberType.Column ? 1 : 0;
        EdB.Text = (mem.B * 100).ToString("0.#", CultureInfo.InvariantCulture);
        EdH.Text = (mem.H * 100).ToString("0.#", CultureInfo.InvariantCulture);
        EdRoll.Text = mem.Roll.ToString("0.##", CultureInfo.InvariantCulture);
        EdProfile.SelectedItem = string.IsNullOrEmpty(mem.Profile) ? null : mem.Profile;
    }

    private bool ApplyEdit(bool grow)
    {
        var mem = _model.Members.FirstOrDefault(m => m.Id == _editingId);
        if (mem == null) { StatusLeft.Text = "Sélectionnez d'abord une barre."; return false; }
        PushUndo();
        var kindBefore = mem.Kind;
        mem.Kind = EdMat.SelectedIndex == 1 ? MaterialKind.Steel : MaterialKind.ReinforcedConcrete;
        mem.Type = EdType.SelectedIndex == 1 ? MemberType.Column : MemberType.Beam;
        var targets = _vp.Selection.Count > 1
            ? _model.Members.Where(m => _vp.IsSelected(m.Id)).ToList()
            : EdAll.IsChecked == true
                ? _model.Members.Where(m => m.Type == mem.Type && m.Kind == mem.Kind).ToList()
                : new List<Member> { mem };
        if (!targets.Contains(mem)) targets.Add(mem);
        foreach (var t in targets)
        {
            if (mem.Kind == MaterialKind.Steel)
            {
                string prof = EdProfile.SelectedItem as string ?? (string.IsNullOrEmpty(t.Profile) ? (t.Type == MemberType.Column ? "HEA240" : "IPE300") : t.Profile);
                if (grow) { var next = SteelCatalog.Next(t.Profile.Length > 0 ? t.Profile : prof); prof = next?.Name ?? prof; }
                t.Kind = MaterialKind.Steel; t.Profile = prof; t.LfFactor = Math.Max(t.LfFactor, 1.0);
            }
            else
            {
                double b = Math.Max(0.1, Num(EdB.Text, t.B * 100) / 100), h = Math.Max(0.1, Num(EdH.Text, t.H * 100) / 100);
                if (grow)
                {
                    h = Math.Round(t.H + 0.05, 2);
                    b = t.Type == MemberType.Column ? Math.Round(t.B + 0.05, 2) : t.B;
                }
                t.Kind = MaterialKind.ReinforcedConcrete; t.B = b; t.H = h; t.Profile = "";
            }
        }
        double rollNew = Num(EdRoll.Text, mem.Roll);
        if (Math.Abs(rollNew - mem.Roll) > 1e-9) foreach (var t in targets) t.Roll = rollNew;
        var keep = _vp.Selection.ToList();
        OnModelEdited();
        if (keep.Count > 1) { _vp.SetSelection(keep, false); _vp.Redraw(); ShowGroup(); }
        else { _vp.SelectedId = mem.Id; _vp.Redraw(); FillEditor(mem); }
        StatusLeft.Text = $"{(targets.Count > 1 ? targets.Count + " barres modifiées" : "Barre " + mem.Id + " modifiée")} - relancez le calcul (F5).";
        return true;
    }

    /// <summary>Pivote la sélection (ou la barre éditée) de ±90° autour de son axe, ou remet la rotation à zéro. Effet immédiat.</summary>
    private void RollQuick_Click(object sender, RoutedEventArgs e)
    {
        string tag = (sender as FrameworkElement)?.Tag as string ?? "90";
        var ids = _vp.Selection.Count > 0 ? _vp.Selection.ToList() : (_editingId >= 0 ? new List<int> { _editingId } : new List<int>());
        var targets = _model.Members.Where(m => ids.Contains(m.Id)).ToList();
        if (targets.Count == 0) { StatusLeft.Text = "Sélectionnez d'abord un ou plusieurs éléments à pivoter."; return; }
        PushUndo();
        double delta = tag == "reset" ? 0 : Num(tag, 90);
        foreach (var t in targets)
        {
            double r = tag == "reset" ? 0 : (t.Roll + delta) % 360;
            if (r > 180) r -= 360; else if (r <= -180) r += 360;
            t.Roll = r;
        }
        var keep = _vp.Selection.ToList();
        OnModelEdited();
        if (keep.Count > 1) { _vp.SetSelection(keep, false); _vp.Redraw(); ShowGroup(); }
        else { var m0 = targets[0]; _vp.SelectedId = m0.Id; _vp.Redraw(); FillEditor(m0); }
        StatusLeft.Text = tag == "reset" ? $"Rotation remise à 0° ({targets.Count} élément(s))." : $"{targets.Count} élément(s) pivoté(s) de {delta:+0;-0}° - relancez le calcul (F5).";
    }

    private void EditApply_Click(object sender, RoutedEventArgs e) => ApplyEdit(false);
    private void EditGrow_Click(object sender, RoutedEventArgs e) => ApplyEdit(true);
    private void EditApplyRun_Click(object sender, RoutedEventArgs e) { if (ApplyEdit(false)) Run_Click(sender, e); }

    private void AddLoad_Click(object sender, RoutedEventArgs e)
    {
        if (_editingId < 0 || !_model.Members.Any(m => m.Id == _editingId)) { StatusLeft.Text = "Sélectionnez d'abord une barre."; return; }
        PushUndo();
        var cas = Enum.TryParse<ActionType>(EdCase.SelectedItem as string, out var c) ? c : ActionType.G;
        _model.MemberLoads.Add(new MemberLoad { MemberId = _editingId, Case = cas, Wz = -Num(EdWz.Text, 0) });
        OnModelEdited();
        StatusLeft.Text = $"Charge {cas} = {Num(EdWz.Text, 0)} kN/m ajoutée à la barre {_editingId}.";
    }

    // ------------------------------------------------------------------ vérification
    private void Check_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var issues = FilterIssues(ModelChecker.Check(_model));
        FillIssues(issues);
        BottomTabs.SelectedItem = TabCheck;
        int ne = issues.Count(i => i.Level == IssueLevel.Error), nw = issues.Count(i => i.Level == IssueLevel.Warning);
        StatusLeft.Text = issues.Count == 0 ? "Vérification : aucun problème détecté ✔" : $"Vérification : {ne} erreur(s), {nw} avertissement(s).";
    }

    // ------------------------------------------------------------------ assistant d'ossature
    private void Wizard_Click(object sender, RoutedEventArgs e)
    {
        var w = new FrameWizardWindow { Owner = this };
        if (w.ShowDialog() == true && w.Result != null)
        {
            PushUndo();
            _model = w.Result;
            BindModel();
            Log($"Ossature générée : {_model.Nodes.Count} nœuds, {_model.Members.Count} barres.");
            StatusLeft.Text = "Ossature générée : vérifiez les charges puis lancez le calcul (F5).";
        }
    }

    // ------------------------------------------------------------------ assistant de configuration
    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var w = new SettingsWizardWindow(_model) { Owner = this };
        if (w.ShowDialog() == true && w.Result != null)
        {
            PushUndo();
            _model = w.Result;
            BindModel();
            Log($"Configuration appliquée : norme BA {_model.RcCodeId}, norme CM {_model.SteelCodeId}, séisme {(_model.Seismic.Enabled ? _model.Seismic.Norm : "désactivé")}.");
            StatusLeft.Text = "Configuration appliquée : relancez le calcul (F5), puis régénérez les plans.";
        }
    }

    // ------------------------------------------------------------------ plans, IFC, licence
    private void Plans_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        try
        {
            var sheets = DrawingGenerator.Generate(_model, _out!, LicenseManager.Current.IsFull);
            Log($"{sheets.Count} planche(s) d'exécution générée(s).");
            new SheetViewerWindow(sheets, _model.Name) { Owner = this }.Show();
        }
        catch (Exception ex)
        {
            Log("Erreur de génération des plans : " + ex.Message);
            MessageBox.Show("Erreur de génération des plans : " + ex.Message, "StructCalc", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Ifc_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var dlg = new SaveFileDialog { Filter = "IFC (*.ifc)|*.ifc", FileName = _model.Name + ".ifc" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            IfcWriter.Save(_model, _out, dlg.FileName);
            Log("Modèle IFC : " + dlg.FileName + " (Revit : Fichier > Ouvrir > IFC)");
            StatusLeft.Text = "IFC exporté : " + dlg.FileName;
        }
        catch (Exception ex) { Log("Erreur IFC : " + ex.Message); }
    }

    private void License_Click(object sender, RoutedEventArgs e)
    {
        new LicenseWindow(LicenseManager.Current) { Owner = this }.ShowDialog();
        LicenseManager.Refresh();
        StatusRight.Text = "kN, m, MPa  ·  " + LicenseManager.Current.Message;
    }
}
