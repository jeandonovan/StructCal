using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;

namespace StructCalc.UI;

/// <summary>Dessin de la section d'une barre : béton avec cadres et barres (échelle respectée), ou profilé acier.</summary>
public static class SectionDrawing
{
    private static Brush Br(string hex)
    {
        var b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex)!;
        b.Freeze();
        return b;
    }

    private static void Text(Canvas c, string s, double x, double y, double size, Brush fg, bool bold = false)
    {
        var t = new TextBlock { Text = s, FontSize = size, Foreground = fg };
        if (bold) t.FontWeight = FontWeights.SemiBold;
        Canvas.SetLeft(t, x); Canvas.SetTop(t, y);
        c.Children.Add(t);
    }

    /// <summary>Diamètre des barres de montage (réglage du projet), renseigné par la fenêtre principale.</summary>
    public static int MountingDiaMm { get; set; } = 10;

    public static void Draw(Canvas c, Member? mem, MemberDesignResult? r)
    {
        DrawCore(c, mem, r);
        Theme.MapTree(c);
    }

    private static void DrawCore(Canvas c, Member? mem, MemberDesignResult? r)
    {
        c.Children.Clear();
        if (mem == null) return;
        double W = c.Width, H = c.Height;
        if (mem.Kind == MaterialKind.Steel) { DrawSteel(c, mem, r, W, H); return; }

        double b = r?.B > 0 ? r.B : mem.B, h = r?.H > 0 ? r.H : mem.H;
        double sc = Math.Min((W - 100) / b, (H - 90) / h);
        double x0 = (W - b * sc) / 2 - 8, y0 = 16;
        var concrete = new Rectangle { Width = b * sc, Height = h * sc, Fill = Br("#E5E7EB"), Stroke = Br("#374151"), StrokeThickness = 2 };
        Canvas.SetLeft(concrete, x0); Canvas.SetTop(concrete, y0);
        c.Children.Add(concrete);

        // même disposition que les plans d'exécution et le ferraillage 3D (RebarLayout)
        double covM = r != null && r.CoverM > 0 ? r.CoverM : mem.Cover;
        int botDia = r?.BotDia ?? 0, topDia = r?.TopDia ?? 0, stDia = r?.StirDia ?? 0;
        bool isCol = (r?.Type ?? mem.Type) == MemberType.Column;
        var lay = RebarLayout.Of(isCol, b, h, covM, r?.BotN ?? 0, botDia, r?.TopN ?? 0, stDia);
        double cx = x0 + b * sc / 2, cy = y0 + h * sc / 2;
        double StirW = lay.StirY * 2 * sc, StirH = lay.StirZ * 2 * sc;
        var stirrup = new Rectangle
        {
            Width = StirW, Height = StirH, Stroke = Br("#2E7D32"),
            StrokeThickness = Math.Max(1.5, Math.Max(stDia, 6) / 1000.0 * sc), RadiusX = 3, RadiusY = 3
        };
        Canvas.SetLeft(stirrup, cx - StirW / 2); Canvas.SetTop(stirrup, cy - StirH / 2);
        c.Children.Add(stirrup);

        void Pin(double x1, double y1, double x2, double y2)
        {
            c.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, Stroke = Br("#2E7D32"), StrokeThickness = Math.Max(1.2, Math.Max(stDia, 6) / 1000.0 * sc * 0.8) });
        }
        void Bar(double y, double z, int dia, string col)
        {
            double d = Math.Max(6, dia / 1000.0 * sc);
            var e = new Ellipse { Width = d, Height = d, Fill = Br(col), Stroke = Br("#FFFFFF"), StrokeThickness = 0.8 };
            Canvas.SetLeft(e, cx + y * sc - d / 2); Canvas.SetTop(e, cy - z * sc - d / 2);   // Z vers le haut
            c.Children.Add(e);
        }

        if (r != null && isCol)
        {
            foreach (double y in lay.TiesY) Pin(cx + y * sc, cy - lay.StirZ * sc, cx + y * sc, cy + lay.StirZ * sc);
            foreach (double z in lay.TiesZ) Pin(cx - lay.StirY * sc, cy - z * sc, cx + lay.StirY * sc, cy - z * sc);
            foreach (var (y, z) in lay.Column) Bar(y, z, r.BotDia, "#111827");
        }
        else if (r != null)
        {
            int mount = MountingDiaMm;
            foreach (var (y, z) in lay.Bottom) Bar(y, z, r.BotDia, "#111827");
            foreach (var (y, z) in lay.Mounting) Bar(y, z, mount, "#6B7280");
            foreach (var (y, z) in lay.Top) Bar(y, z, r.TopDia, "#1565C0");
        }

        var dim = Br("#1F4E79");
        Text(c, $"b = {b * 100:0} cm", x0 + b * sc / 2 - 24, y0 + h * sc + 4, 11, dim, true);
        Text(c, $"h = {h * 100:0} cm", x0 + b * sc + 6, y0 + h * sc / 2 - 8, 11, dim, true);
        if (r != null)
        {
            if (r.Type == MemberType.Column)
                Text(c, $"Longitudinales : {r.BotN} HA{r.BotDia}", 10, H - 46, 11, Br("#111827"), true);
            else
            {
                Text(c, $"Chapeaux : {r.TopN} HA{r.TopDia} par appui ; montage 2 HA{MountingDiaMm}", 10, H - 62, 11, Br("#111827"), true);
                Text(c, $"Inf. : {r.BotN} HA{r.BotDia}", 10, H - 46, 11, Br("#111827"), true);
            }
            Text(c, $"Cadres HA{r.StirDia} e = {r.StirSpacingCm:0} cm", 10, H - 28, 11, Br("#2E7D32"), true);
        }
    }

    private static void DrawSteel(Canvas c, Member mem, MemberDesignResult? r, double W, double H)
    {
        if (!SteelCatalog.TryGet(mem.Profile, out var p)) { Text(c, "Profil inconnu : " + mem.Profile, 10, 10, 12, Br("#C62828")); return; }
        double sc = Math.Min((W - 90) / p.B, (H - 90) / p.H);
        double x0 = (W - p.B * sc) / 2, y0 = 18;
        var fill = Br("#90A4AE"); var stroke = Br("#37474F");
        void Rect(double x, double y, double w, double h)
        {
            var rc = new Rectangle { Width = w, Height = h, Fill = fill, Stroke = stroke, StrokeThickness = 1.5 };
            Canvas.SetLeft(rc, x); Canvas.SetTop(rc, y);
            c.Children.Add(rc);
        }
        Rect(x0, y0, p.B * sc, p.Tf * sc);
        Rect(x0, y0 + (p.H - p.Tf) * sc, p.B * sc, p.Tf * sc);
        Rect(x0 + (p.B - p.Tw) * sc / 2, y0 + p.Tf * sc, p.Tw * sc, (p.H - 2 * p.Tf) * sc);
        var dim = Br("#1F4E79");
        Text(c, $"b = {p.B:0} mm", x0 + p.B * sc / 2 - 28, y0 + p.H * sc + 4, 11, dim, true);
        Text(c, $"h = {p.H:0}", x0 + p.B * sc + 6, y0 + p.H * sc / 2 - 8, 11, dim, true);
        Text(c, p.Name, 10, H - 46, 14, Br("#111827"), true);
        Text(c, $"tw = {p.Tw} ; tf = {p.Tf} mm ; {p.MassKgPerM:0.0} kg/m", 10, H - 24, 11, Br("#374151"));
        if (r != null) Text(c, $"Taux : {r.Utilization * 100:0} %", W - 100, H - 46, 12, r.Ok ? Br("#2E7D32") : Br("#C62828"), true);
    }
}
