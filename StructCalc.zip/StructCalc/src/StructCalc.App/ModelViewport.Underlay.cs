using System.Globalization;
using System.Windows;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.UI;

/// <summary>Fonds de plan (DXF, PDF, image) dessinés sous le modèle, et étendue de la scène.</summary>
public sealed partial class ModelViewport
{
    public List<UnderlayData> Underlays { get; set; } = new();

    /// <summary>Matrice écran d'un plan horizontal situé à la cote z (projection orthographique de la vue courante).</summary>
    private Matrix ViewMatrixAtZ(double z)
    {
        double cy = Math.Cos(_yaw), sy = Math.Sin(_yaw), cp = Math.Cos(_pitch), sp = Math.Sin(_pitch);
        return new Matrix(_scale * cy, -_scale * sp * sy, -_scale * sy, -_scale * sp * cy, _ox, _oy - _scale * z * cp);
    }

    /// <summary>Coordonnées source (DXF ou pixels) → coordonnées modèle, dans le plan XY.</summary>
    private static Matrix LocalMatrix(UnderlayDef d)
    {
        var m = Matrix.Identity;
        m.Scale(d.Scale, d.Scale);
        m.Rotate(d.Rotation);
        m.Translate(d.OriginX, d.OriginY);
        return m;
    }

    private void DrawUnderlays(DrawingContext dc)
    {
        if (Underlays.Count == 0) return;
        bool plan = Mode == ViewMode.Plan;
        bool ortho = plan || (Mode == ViewMode.Iso && !UsePersp);
        foreach (var ud in Underlays)
        {
            var def = ud.Def;
            if (!def.Visible || ud.Error != "") continue;
            if (Mode == ViewMode.Elevation || Mode == ViewMode.Side) continue;
            if (!ortho) { DrawUnderlayFrame(dc, ud); continue; }

            var local = LocalMatrix(def);
            var view = ViewMatrixAtZ(def.OriginZ);
            if (ud.Image != null)
            {
                var flip = new Matrix(1, 0, 0, -1, 0, ud.H);
                dc.PushOpacity(Math.Max(0.05, Math.Min(1, def.Opacity)));
                dc.PushTransform(new MatrixTransform(flip * local * view));
                dc.DrawImage(ud.Image, new Rect(0, 0, ud.W, ud.H));
                dc.Pop(); dc.Pop();
            }
            else if (ud.Dxf != null)
            {
                var total = local * view;
                double sc = Math.Sqrt(Math.Abs(total.Determinant));
                if (sc < 1e-12) continue;
                dc.PushOpacity(Math.Max(0.05, Math.Min(1, def.Opacity)));
                dc.PushTransform(new MatrixTransform(total));
                foreach (var kv in ud.Geometries())
                {
                    var col = Color.FromRgb((byte)((kv.Key >> 16) & 255), (byte)((kv.Key >> 8) & 255), (byte)(kv.Key & 255));
                    dc.DrawGeometry(null, new Pen(BrushOf(col), 1.0 / sc), kv.Value);
                }
                dc.Pop(); dc.Pop();
                if (plan) DrawDxfTexts(dc, ud, total);
            }
        }
    }

    private void DrawDxfTexts(DrawingContext dc, UnderlayData ud, Matrix total)
    {
        if (ud.Dxf == null || ud.Dxf.Texts.Count == 0) return;
        double sc = Math.Sqrt(Math.Abs(total.Determinant));
        double ppd = VisualTreeHelper.GetDpi(_c).PixelsPerDip;
        var face = new Typeface("Segoe UI");
        var brush = BrushOf(Color.FromArgb((byte)(255 * Math.Max(0.15, Math.Min(1, ud.Def.Opacity))), 0x40, 0x40, 0x40));
        var hidden = new HashSet<string>(ud.Def.HiddenLayers, StringComparer.OrdinalIgnoreCase);
        int drawn = 0;
        double w = _c.ActualWidth, h = _c.ActualHeight;
        foreach (var t in ud.Dxf.Texts)
        {
            double hpx = t.Height * sc;
            if (hpx < 6 || hpx > 160) continue;
            if (hidden.Contains(ud.Dxf.Layers[t.Layer].Name)) continue;
            var p = total.Transform(new Point(t.X, t.Y));
            if (p.X < -50 || p.Y < -50 || p.X > w + 50 || p.Y > h + 50) continue;
            double r = t.Rotation * Math.PI / 180;
            var dir = total.Transform(new Vector(Math.Cos(r), Math.Sin(r)));
            double ang = Math.Atan2(dir.Y, dir.X) * 180 / Math.PI;
            var ft = new FormattedText(t.Text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, face, hpx, brush, ppd);
            dc.PushTransform(new RotateTransform(ang, p.X, p.Y));
            dc.DrawText(ft, new Point(p.X, p.Y - hpx));
            dc.Pop();
            if (++drawn >= 700) break;
        }
    }

    private void DrawUnderlayFrame(DrawingContext dc, UnderlayData ud)
    {
        var b = ud.Bounds();
        if (b == null) return;
        var z = ud.Def.OriginZ;
        var pts = new[] { new Vec3(b.Value.X0, b.Value.Y0, z), new Vec3(b.Value.X1, b.Value.Y0, z), new Vec3(b.Value.X1, b.Value.Y1, z), new Vec3(b.Value.X0, b.Value.Y1, z) };
        var pen = PenOf(Color.FromArgb(160, 0x60, 0x60, 0x60), 1);
        for (int i = 0; i < 4; i++) dc.DrawLine(pen, Proj(pts[i], out _), Proj(pts[(i + 1) % 4], out _));
    }

    /// <summary>Étendue de la scène : nœuds, axes, niveaux (et fonds de plan si includeUnderlays ou si le modèle est vide).</summary>
    private (Vec3 Min, Vec3 Max)? SceneBounds(bool includeUnderlays)
    {
        if (Model == null) return null;
        var xs = new List<double>(); var ys = new List<double>(); var zs = new List<double>();
        foreach (var n in Model.Nodes) { xs.Add(n.X); ys.Add(n.Y); zs.Add(n.Z); }
        bool hasModel = xs.Count > 0;
        foreach (var a in Model.Grid.XAxes) xs.Add(a.Pos);
        foreach (var a in Model.Grid.YAxes) ys.Add(a.Pos);
        foreach (var l in Model.Levels) zs.Add(l.Elevation);
        if (includeUnderlays || !hasModel)
            foreach (var ud in Underlays)
            {
                if (!ud.Def.Visible) continue;
                var b = ud.Bounds();
                if (b == null) continue;
                xs.Add(b.Value.X0); xs.Add(b.Value.X1); ys.Add(b.Value.Y0); ys.Add(b.Value.Y1); zs.Add(ud.Def.OriginZ);
            }
        if (xs.Count == 0 && ys.Count == 0 && zs.Count == 0) return null;
        if (xs.Count == 0) { xs.Add(0); xs.Add(10); }
        if (ys.Count == 0) { ys.Add(0); ys.Add(10); }
        if (zs.Count == 0) zs.Add(0);
        return (new Vec3(xs.Min(), ys.Min(), zs.Min()), new Vec3(xs.Max(), ys.Max(), zs.Max()));
    }

    /// <summary>Cadre un fond de plan dans la fenêtre (vue en plan).</summary>
    public void ZoomUnderlay(int id)
    {
        var ud = Underlays.FirstOrDefault(u => u.Def.Id == id);
        var b = ud?.Bounds();
        if (ud == null || b == null) return;
        SetMode(ViewMode.Plan);
        var pts = new List<Vec3>
        {
            new(b.Value.X0, b.Value.Y0, ud.Def.OriginZ), new(b.Value.X1, b.Value.Y0, ud.Def.OriginZ),
            new(b.Value.X1, b.Value.Y1, ud.Def.OriginZ), new(b.Value.X0, b.Value.Y1, ud.Def.OriginZ)
        };
        FitScreen(pts, 40);
    }
}
