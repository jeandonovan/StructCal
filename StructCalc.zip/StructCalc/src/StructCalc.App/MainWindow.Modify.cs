using System.Windows;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Outils de modification type CAO/DAO appliqués à la sélection : déplacer/copier par 2 points, rotation, symétrie par axe, échelle, étirer,
/// réseaux, diviser, prolonger, aligner, fusionner, filtre de sélection.</summary>
public partial class MainWindow
{
    private FilterWindow? _filterWin;

    private static bool Yes(string s) => s.Trim().ToLowerInvariant().StartsWith("o") || s.Trim().ToLowerInvariant().StartsWith("y");

    /// <summary>Exécute une modification avec annulation possible et message de résultat ; en cas d'erreur, le modèle est restauré.</summary>
    private void RunEdit(string name, Func<string> op)
    {
        CommitGrids();
        string before;
        try { before = ModelIO.ToJson(_model); } catch { before = ""; }
        string msg;
        try { msg = op(); }
        catch (Exception ex)
        {
            if (before.Length > 0) { _model = ModelIO.FromJson(before); BindModel(); }
            MessageBox.Show($"{name} : {ex.Message}", "StructCalc", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        string after = ""; try { after = ModelIO.ToJson(_model); } catch { }
        if (before.Length > 0 && before != after)
        {
            _undo.Add(before); if (_undo.Count > 80) _undo.RemoveAt(0); _redo.Clear(); UpdateUndoUi();
            OnModelEdited();
            Log(msg + "  (Ctrl+Z pour annuler)");
        }
        else StatusLeft.Text = msg;
    }

    private void Filter_Click(object sender, RoutedEventArgs e)
    {
        if (_filterWin != null) { _filterWin.Activate(); return; }
        _filterWin = new FilterWindow(() => _model, () => _out,
            () => { if (_msgStale || _msgs.Count == 0) RebuildMessages(); return _msgs; },
            () => _vp.SelectedKeys(),
            (keys, mode) => { var l = keys.ToList(); if (l.Count > 0 || mode != 'n') _vp.SelectKeys(l, mode); },
            k => _vp.IsKeyHidden(k)) { Owner = this };
        _filterWin.Closed += (s, a) => _filterWin = null;
        _filterWin.Show();
    }

    // ------------------------------------------------------------------ déplacer / copier par deux points
    private void MoveCopy2P(bool copy)
    {
        if (!NeedSelection(copy ? "les copier" : "les déplacer")) return;
        var ids = Sel();
        _vp.BeginPick(2, (copy ? "Copier" : "Déplacer") + " : 1) cliquez le point de base  2) cliquez le point d'arrivée (accrochages actifs : nœuds, axes, intersections...).", pts =>
        {
            double dx = pts[1].X - pts[0].X, dy = pts[1].Y - pts[0].Y;
            if (Math.Abs(dx) + Math.Abs(dy) < 1e-6) return;
            RunEdit(copy ? "Copier" : "Déplacer", () =>
            {
                if (copy)
                {
                    var created = ModifyTools.CopyTransformed(_model, ids, Xform.Translation(dx, dy, 0), true, false);
                    _vp.SetSelection(created);
                    return $"{created.Count} barre(s) copiée(s) (dX = {dx:0.###} m, dY = {dy:0.###} m).";
                }
                var r = ModifyTools.TransformInPlace(_model, ModifyTools.NodesOf(_model, ids), Xform.Translation(dx, dy, 0));
                return $"{r.Moved} nœud(s) déplacé(s) (dX = {dx:0.###} m, dY = {dy:0.###} m).";
            });
        });
    }
    private void MovePick_Click(object sender, RoutedEventArgs e) => MoveCopy2P(false);
    private void CopyPick_Click(object sender, RoutedEventArgs e) => MoveCopy2P(true);

    // ------------------------------------------------------------------ rotation
    private void Rotate_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les faire pivoter")) return;
        var ids = Sel();
        var v0 = PromptWindow.Ask(this, "Rotation de la sélection", "Rotation autour d'un axe VERTICAL. Choisissez « cliquer » pour désigner le centre dans la vue (avec accrochages) ou saisissez ses coordonnées.",
            ("Angle (°, anti-horaire vu de dessus)", "90"), ("Centre", "cliquer"), ("Centre X (m) si saisi", "0"), ("Centre Y (m) si saisi", "0"), ("Copier (oui) ou déplacer (non)", "non"), ("Nombre de copies (si copie)", "1"));
        if (v0 == null) return;
        double ang = Ui.Num(v0[0], 90); bool pick = v0[1].Trim().ToLowerInvariant().StartsWith("c"); bool copy = Yes(v0[4]); int n = (int)Ui.Num(v0[5], 1);
        void Go(double cx, double cy) => RunEdit("Rotation", () =>
        {
            if (copy)
            {
                var all = new List<int>();
                for (int i = 1; i <= Math.Max(1, n); i++) all.AddRange(ModifyTools.CopyTransformed(_model, ids, Xform.Rotation(cx, cy, ang * i), true, true));
                _vp.SetSelection(all);
                return $"{all.Count} barre(s) créée(s) par rotation de {ang:0.##}° autour de ({cx:0.###} ; {cy:0.###}).";
            }
            var r = ModifyTools.TransformInPlace(_model, ModifyTools.NodesOf(_model, ids), Xform.Rotation(cx, cy, ang));
            return $"{r.Moved} nœud(s) tourné(s) de {ang:0.##}°." + (r.DroppedPanels > 0 ? $" {r.DroppedPanels} charge(s) surfacique(s) supprimée(s) (panneau plus aligné sur X/Y : recréez-les)." : "");
        });
        if (pick) _vp.BeginPick(1, "Rotation : cliquez le centre de rotation.", pts => Go(pts[0].X, pts[0].Y));
        else Go(Ui.Num(v0[2], 0), Ui.Num(v0[3], 0));
    }

    // ------------------------------------------------------------------ symétrie par axe quelconque
    private void MirrorLine_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("faire une symétrie")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Symétrie par un axe", "Après OK, cliquez deux points qui définissent l'axe de symétrie (plan vertical passant par ces points).", ("Conserver les barres d'origine (oui/non)", "oui"));
        if (v == null) return;
        bool keep = !v[0].Trim().ToLowerInvariant().StartsWith("n");
        _vp.BeginPick(2, "Symétrie : cliquez le 1er puis le 2e point de l'axe de symétrie.", pts =>
        {
            RunEdit("Symétrie", () =>
            {
                var t = Xform.MirrorLine(pts[0].X, pts[0].Y, pts[1].X, pts[1].Y);
                var created = ModifyTools.CopyTransformed(_model, ids, t, true, true);
                if (!keep) SelectionTools.Delete(_model, ids.Where(i => !created.Contains(i)));
                _vp.SetSelection(created);
                return $"Symétrie : {created.Count} barre(s) créée(s).";
            });
        });
    }

    // ------------------------------------------------------------------ échelle
    private void Scale_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("changer leur échelle")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Échelle de la sélection", "Agrandit ou réduit la géométrie des barres sélectionnées par rapport à un point de base (les nœuds partagés avec d'autres barres entraînent ces barres). Les sections ne changent pas.",
            ("Facteur X", "1,5"), ("Facteur Y", "1,5"), ("Facteur Z", "1"), ("Point de base", "cliquer"), ("Base X (m) si saisi", "0"), ("Base Y (m) si saisi", "0"), ("Copier (oui) ou modifier (non)", "non"));
        if (v == null) return;
        double fx = Ui.Num(v[0], 1), fy = Ui.Num(v[1], 1), fz = Ui.Num(v[2], 1);
        if (fx <= 0.01 || fy <= 0.01 || fz <= 0.01) { MessageBox.Show("Les facteurs doivent être strictement positifs.", "Échelle", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        bool pick = v[3].Trim().ToLowerInvariant().StartsWith("c"); bool copy = Yes(v[6]);
        void Go(double bx, double by) => RunEdit("Échelle", () =>
        {
            double bz = _model.Nodes.Where(n => ModifyTools.NodesOf(_model, ids).Contains(n.Id)).Select(n => n.Z).DefaultIfEmpty(0).Min();
            var t = Xform.Scale(bx, by, bz, fx, fy, fz);
            if (copy) { var c = ModifyTools.CopyTransformed(_model, ids, t, true, true); _vp.SetSelection(c); return $"{c.Count} barre(s) créée(s) à l'échelle ({fx:0.###} ; {fy:0.###} ; {fz:0.###})."; }
            var r = ModifyTools.TransformInPlace(_model, ModifyTools.NodesOf(_model, ids), t);
            return $"{r.Moved} nœud(s) mis à l'échelle." + (r.DroppedPanels > 0 ? $" {r.DroppedPanels} panneau(x) surfacique(s) supprimé(s)." : "");
        });
        if (pick) _vp.BeginPick(1, "Échelle : cliquez le point de base (il reste immobile).", pts => Go(pts[0].X, pts[0].Y));
        else Go(Ui.Num(v[4], 0), Ui.Num(v[5], 0));
    }

    // ------------------------------------------------------------------ étirer
    private void Stretch_Click(object sender, RoutedEventArgs e)
    {
        var v = PromptWindow.Ask(this, "Étirer", "Déplace tous les nœuds situés dans une fenêtre rectangulaire (vue en plan) ; les barres qui les relient à d'autres nœuds s'allongent ou se raccourcissent. " +
                                                  "Après OK : 1) deux clics = fenêtre  2) deux clics = vecteur de déplacement (base puis arrivée).",
            ("Altitude Z minimale de la fenêtre (m)", "-1000"), ("Altitude Z maximale de la fenêtre (m)", "1000"), ("Déplacement vertical dZ (m)", "0"));
        if (v == null) return;
        double z0 = Ui.Num(v[0], -1000), z1 = Ui.Num(v[1], 1000), dz = Ui.Num(v[2], 0);
        _vp.BeginPick(4, "Étirer : clics 1-2 = coins de la fenêtre ; clics 3-4 = point de base puis point d'arrivée.", p =>
        {
            RunEdit("Étirer", () =>
            {
                double dx = p[3].X - p[2].X, dy = p[3].Y - p[2].Y;
                var r = ModifyTools.Stretch(_model, p[0].X, p[0].Y, p[1].X, p[1].Y, z0, z1, dx, dy, dz);
                return $"{r.Moved} nœud(s) étiré(s) de ({dx:0.###} ; {dy:0.###} ; {dz:0.###}) m." + (r.DroppedPanels > 0 ? $" {r.DroppedPanels} panneau(x) surfacique(s) supprimé(s) (non rectangulaire)." : "");
            });
        });
    }

    // ------------------------------------------------------------------ réseaux
    private void ArrayRect_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("faire un réseau")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Réseau rectangulaire", "Répète la sélection en lignes, colonnes et niveaux. Le nombre inclut l'original.",
            ("Nombre suivant X", "3"), ("Pas suivant X (m)", "5"), ("Nombre suivant Y", "1"), ("Pas suivant Y (m)", "5"), ("Nombre suivant Z (niveaux)", "1"), ("Pas suivant Z (m)", "3"));
        if (v == null) return;
        int nx = (int)Ui.Num(v[0], 1), ny = (int)Ui.Num(v[2], 1), nz = (int)Ui.Num(v[4], 1);
        if (nx * ny * nz > 400 || nx * ny * nz < 2) { MessageBox.Show("Le réseau doit contenir entre 2 et 400 exemplaires.", "Réseau", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        RunEdit("Réseau", () =>
        {
            var c = ModifyTools.ArrayRect(_model, ids, nx, ny, nz, Ui.Num(v[1], 5), Ui.Num(v[3], 5), Ui.Num(v[5], 3));
            _vp.SetSelection(c);
            return $"Réseau {nx} x {ny} x {nz} : {c.Count} barre(s) créée(s).";
        });
    }

    private void ArrayPolar_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("faire un réseau polaire")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Réseau polaire", "Répète la sélection autour d'un axe vertical. Angle total 360 = cercle complet. Le nombre inclut l'original.",
            ("Nombre d'exemplaires", "6"), ("Angle total (°)", "360"), ("Centre", "cliquer"), ("Centre X (m) si saisi", "0"), ("Centre Y (m) si saisi", "0"));
        if (v == null) return;
        int n = (int)Ui.Num(v[0], 6); double tot = Ui.Num(v[1], 360);
        if (n < 2 || n > 100) { MessageBox.Show("Entre 2 et 100 exemplaires.", "Réseau polaire", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        void Go(double cx, double cy) => RunEdit("Réseau polaire", () =>
        {
            var c = ModifyTools.ArrayPolar(_model, ids, cx, cy, n, tot);
            _vp.SetSelection(c);
            return $"Réseau polaire : {c.Count} barre(s) créée(s).";
        });
        if (v[2].Trim().ToLowerInvariant().StartsWith("c")) _vp.BeginPick(1, "Réseau polaire : cliquez le centre.", pts => Go(pts[0].X, pts[0].Y));
        else Go(Ui.Num(v[3], 0), Ui.Num(v[4], 0));
    }

    // ------------------------------------------------------------------ diviser / prolonger / aligner / fusionner
    private void Divide_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les diviser")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Diviser les barres", "Coupe chaque barre sélectionnée ; les charges sont réparties sur les tronçons.",
            ("Mode : « egaux » (n tronçons) ou « distance »", "egaux"), ("Nombre de tronçons (mode egaux)", "2"), ("Distance (mode distance)", "2"), ("Distance en % de la longueur (oui/non)", "non"), ("Mesurée depuis le nœud j (oui/non)", "non"));
        if (v == null) return;
        bool eq = !v[0].Trim().ToLowerInvariant().StartsWith("d");
        RunEdit("Diviser", () =>
        {
            int n = eq ? ModifyTools.DivideEqual(_model, ids, (int)Ui.Num(v[1], 2))
                       : ModifyTools.DivideAt(_model, ids, Yes(v[3]) ? Ui.Num(v[2], 50) / 100 : Ui.Num(v[2], 2), Yes(v[3]), Yes(v[4]));
            return n == 0 ? "Aucune barre divisée (distance hors barre ?)." : $"{n} barre(s) créée(s) par division.";
        });
    }

    private void Extend_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les prolonger")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Prolonger / raccourcir", "Déplace l'extrémité choisie le long de l'axe de la barre. Valeur positive = prolonge, négative = raccourcit. Un nouveau nœud est créé : les barres voisines ne bougent pas.",
            ("Extrémité (i ou j)", "j"), ("Longueur (m)", "1"));
        if (v == null) return;
        RunEdit("Prolonger", () =>
        {
            int n = ModifyTools.Extend(_model, ids, !v[0].Trim().ToLowerInvariant().StartsWith("i"), Ui.Num(v[1], 1));
            return $"{n} barre(s) modifiée(s).";
        });
    }

    private void Align_Click(object sender, RoutedEventArgs e)
    {
        if (!NeedSelection("les aligner")) return;
        var ids = Sel();
        var v = PromptWindow.Ask(this, "Aligner", "Place tous les nœuds des barres sélectionnées sur une même coordonnée (les barres voisines suivent).", ("Axe (x, y ou z)", "x"), ("Valeur (m)", "0"));
        if (v == null) return;
        char ax = v[0].Trim().ToLowerInvariant() switch { "y" => 'y', "z" => 'z', _ => 'x' };
        RunEdit("Aligner", () =>
        {
            var r = ModifyTools.AlignNodes(_model, ids, ax, Ui.Num(v[1], 0));
            return $"{r.Moved} nœud(s) aligné(s) sur {char.ToUpper(ax)} = {Ui.Num(v[1], 0):0.###} m.";
        });
    }

    private void MergeNodes_Click(object sender, RoutedEventArgs e)
    {
        var v = PromptWindow.Ask(this, "Fusionner les nœuds", "Fusionne les nœuds distants de moins de la tolérance, supprime les barres de longueur nulle et les barres en double (utile après un import ou des copies).", ("Tolérance (mm)", "5"));
        if (v == null) return;
        RunEdit("Fusion", () =>
        {
            var r = ModifyTools.MergeNodes(_model, Ui.Num(v[0], 5) / 1000);
            return r.MergedNodes == 0 ? "Aucun nœud à fusionner." : $"{r.MergedNodes} nœud(s) fusionné(s), {r.RemovedMembers} barre(s) supprimée(s).";
        });
    }
}
