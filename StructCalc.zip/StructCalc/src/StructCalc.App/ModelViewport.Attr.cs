using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Selection;
using StructCalc.Engine;
using StructCalc.Engine.Stairs;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Attributs d'affichage (symboles de sens de portée et de ferraillage des dalles, sens et axes locaux des barres) et escaliers du modèle d'ensemble.</summary>
public sealed partial class ModelViewport
{
    /// <summary>Familles d'objets affichées ou masquées (fenêtre Affichage > Attributs).</summary>
    public ViewAttributes Attr { get; } = ViewAttributes.Load();

    // ------------------------------------------------------------------ barres : sens et axes locaux
    private void DrawMemberAttrs(Dictionary<int, Node> nodes, StructureInfo info)
    {
        if (Model == null || (!Attr.MemberDirection && !Attr.LocalAxes)) return;
        foreach (var mem in Model.Members)
        {
            if (MemberHidden(mem.Id, info)) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
            Point a = S(na), b = S(nb);
            var m = new Point((a.X + b.X) / 2, (a.Y + b.Y) / 2);
            if (Attr.MemberDirection)
            {
                double dx = b.X - a.X, dy = b.Y - a.Y, len = Math.Sqrt(dx * dx + dy * dy);
                if (len > 24)
                {
                    dx /= len; dy /= len;
                    Arrow(new Point(m.X - dx * 9, m.Y - dy * 9), new Point(m.X + dx * 11, m.Y + dy * 11), Br("#6A1B9A"), 2);
                }
            }
            if (Attr.LocalAxes)
            {
                double L; double[,] R;
                try { (L, R) = FrameSolver.LocalAxes(na, nb, mem.Roll); } catch { continue; }
                if (L < 1e-6) continue;
                var axes = new[] { (1.0, 0.0, 0.0, "x", "#D32F2F"), (0.0, 1.0, 0.0, "y", "#2E7D32"), (0.0, 0.0, 1.0, "z", "#1565C0") };
                foreach (var (lx, ly, lz, name, col) in axes)
                {
                    var g = LoadMath.ToGlobal(R, lx, ly, lz);
                    var w = W(g[0], g[1], g[2]);
                    double sx = w.X * 20, sy = -w.Y * 20;
                    if (Math.Sqrt(sx * sx + sy * sy) < 4) continue;
                    var tip = new Point(m.X + sx, m.Y + sy);
                    Arrow(m, tip, Br(col), 1.8);
                    Text(name, tip.X + (sx >= 0 ? 2 : -9), tip.Y - 7, 9, Br(col), null, true);
                }
            }
        }
    }

    // ------------------------------------------------------------------ dalles : sens de portée et ferraillage
    private void DrawSlabSymbols(SlabPanel s)
    {
        if (!Attr.SpanOrRebar) return;
        double cx = s.X0 + s.Lx / 2, cy = s.Y0 + s.Ly / 2, z = s.Z;
        bool ox = s.CalcMode == SlabCalcMode.OneWayX, oy = s.CalcMode == SlabCalcMode.OneWayY, mass = s.CalcMode == SlabCalcMode.MassOnly;
        bool xDir = !oy && !mass, yDir = !ox && !mass;      // sens porteurs
        if (Attr.SlabSpanSymbol)
        {
            var br = Br("#BF360C");
            double hx = s.Lx * 0.28, hy = s.Ly * 0.28;
            if (mass) Text("non chargée (métré)", S(cx, cy, z).X - 52, S(cx, cy, z).Y + 12, 10, br, null, true);
            if (xDir) { Arrow(S(cx, cy, z), S(cx - hx, cy, z), br, 2); Arrow(S(cx, cy, z), S(cx + hx, cy, z), br, 2); }
            if (yDir) { Arrow(S(cx, cy, z), S(cx, cy - hy, z), br, 2); Arrow(S(cx, cy, z), S(cx, cy + hy, z), br, 2); }
        }
        if (Attr.SlabRebarSymbol && !mass && !(RenderStyle == DisplayStyle.Ferraille && Output != null))   // en ferraillage 3D, les vraies barres remplacent les symboles
        {
            var blue = Br("#1565C0"); var green = Br("#2E7D32"); var red = Br("#C62828"); var gray = Br("#78909C");
            const int bars = 6;
            double mx = s.Lx * 0.08, my = s.Ly * 0.08;
            // nappe inférieure : barres principales dans les sens porteurs
            if (xDir)
                for (int i = 1; i <= bars; i++)
                {
                    double y = s.Y0 + s.Ly * i / (bars + 1);
                    var p1 = S(s.X0 + mx, y, z); var p2 = S(s.X0 + s.Lx - mx, y, z);
                    Ln(p1.X, p1.Y, p2.X, p2.Y, blue, 1.4);
                }
            if (yDir)
                for (int i = 1; i <= bars; i++)
                {
                    double x = s.X0 + s.Lx * i / (bars + 1);
                    var p1 = S(x, s.Y0 + my, z); var p2 = S(x, s.Y0 + s.Ly - my, z);
                    Ln(p1.X, p1.Y, p2.X, p2.Y, green, 1.4);
                }
            // dalle portant dans un seul sens : armatures de répartition (pointillés)
            if (!(xDir && yDir))
            {
                for (int i = 1; i <= 3; i++)
                {
                    var l = new Line();
                    Point p1, p2;
                    if (ox) { double x = s.X0 + s.Lx * i / 4; p1 = S(x, s.Y0 + my, z); p2 = S(x, s.Y0 + s.Ly - my, z); }
                    else { double y = s.Y0 + s.Ly * i / 4; p1 = S(s.X0 + mx, y, z); p2 = S(s.X0 + s.Lx - mx, y, z); }
                    l.X1 = p1.X; l.Y1 = p1.Y; l.X2 = p2.X; l.Y2 = p2.Y; l.Stroke = gray; l.StrokeThickness = 1; l.StrokeDashArray = new DoubleCollection { 3, 3 }; l.IsHitTestVisible = false;
                    _c.Children.Add(l);
                }
            }
            // chapeaux sur appuis (nappe supérieure) : segments rouges le long des rives
            double ex = s.Lx * 0.22, ey = s.Ly * 0.22;
            for (int i = 1; i <= 3; i++)
            {
                double fy = s.Y0 + s.Ly * i / 4, fx = s.X0 + s.Lx * i / 4;
                DashSeg(S(s.X0, fy, z), S(s.X0 + ex, fy, z), red); DashSeg(S(s.X0 + s.Lx, fy, z), S(s.X0 + s.Lx - ex, fy, z), red);
                DashSeg(S(fx, s.Y0, z), S(fx, s.Y0 + ey, z), red); DashSeg(S(fx, s.Y0 + s.Ly, z), S(fx, s.Y0 + s.Ly - ey, z), red);
            }
            var lg = S(s.X0, s.Y0 + s.Ly, z);
            Text("inf. " + (xDir && yDir ? "X+Y" : xDir ? "X" : "Y") + " · sup. rouge", lg.X + 3, lg.Y - 15, 9, Dark, Br("#B3FFFFFF"), true);
        }
    }

    private void DashSeg(Point a, Point b, Brush br) => Ln(a.X, a.Y, b.X, b.Y, br, 2.2);

    // ------------------------------------------------------------------ escaliers posés dans le modèle
    private readonly Dictionary<StairDef, List<StairFace>> _stairCache = new();
    private readonly Dictionary<StairDef, string> _stairSig = new();

    private List<StairFace> StairFacesOf(StairDef d)
    {
        string sig = $"{d.Layout}|{d.HeightM}|{d.WidthM}|{d.TargetRiserCm}|{d.TargetTreadCm}|{d.RunM}|{d.StartLandingM}|{d.EndLandingM}|{d.MidLandingM}|{d.GapM}|{d.InnerRadiusM}|{d.TurnAngleDeg}|{d.X}|{d.Y}|{d.Z}|{d.AngleDeg}|{d.Mirror}";
        if (_stairCache.TryGetValue(d, out var f) && _stairSig.TryGetValue(d, out var sg) && sg == sig) return f;
        List<StairFace> faces;
        try { faces = StairShape.Build(d); } catch { faces = new List<StairFace>(); }
        _stairCache[d] = faces; _stairSig[d] = sig;
        return faces;
    }

    private void DrawStairs()
    {
        if (Model == null || !Attr.Stairs) return;
        foreach (var d in Model.Stairs)
        {
            if (!d.Placed || IsObjHidden(d)) continue;
            var faces = StairFacesOf(d);
            if (faces.Count == 0) continue;
            var skey = ElementKey.Named(ElementKind.Stair, d.Name);
            var items = faces.Select(f => (F: f, P: f.Pts.Select(v => S(v.X, v.Y, v.Z)).ToArray(), D: f.Pts.Average(v => V3(v.X, v.Y, v.Z).D))).OrderByDescending(q => q.D).ToList();
            Color stC = ElementPalette.Get("Stair"); bool stSet = ElementPalette.IsSet("Stair");
            var tread = new SolidColorBrush(ElementPalette.WithAlpha(stC, 225)); tread.Freeze();
            var land = new SolidColorBrush(stSet ? ElementPalette.WithAlpha(ElementPalette.Shade(stC, 0.12), 225) : Color.FromArgb(225, 0xB0, 0xBE, 0xC5)); land.Freeze();
            var riser = new SolidColorBrush(stSet ? ElementPalette.WithAlpha(ElementPalette.Shade(stC, 0.25), 225) : Color.FromArgb(225, 0x90, 0xA4, 0xAE)); riser.Freeze();
            var waist = new SolidColorBrush(stSet ? ElementPalette.WithAlpha(ElementPalette.Shade(stC, 0.35), 235) : Color.FromArgb(235, 0x78, 0x90, 0x9C)); waist.Freeze();
            var edge = Br("#37474F");
            double th = 0.9;
            foreach (var it in items)
            {
                Brush fill = it.F.Kind == StairFaceKind.Rail ? Br("#80455A64") : it.F.Kind == StairFaceKind.Tread ? tread : it.F.Kind == StairFaceKind.Landing ? land : it.F.Kind == StairFaceKind.Waist ? waist : riser;
                if (Mode == ViewMode.Plan && it.F.Kind is StairFaceKind.Riser or StairFaceKind.Waist or StairFaceKind.Rail) continue;
                _c.Children.Add(new Polygon { Points = new PointCollection(it.P), Fill = fill, Stroke = edge, StrokeThickness = th, StrokeLineJoin = PenLineJoin.Round, IsHitTestVisible = false });
                if (it.F.Kind is not StairFaceKind.Riser and not StairFaceKind.Rail) AddElemHit(skey, it.P, ViewDepth(it.D), true);
            }
            if (Attr.StairNames)
            {
                var first = items.Where(q => q.F.Kind == StairFaceKind.Tread).Select(q => q.P).FirstOrDefault() ?? items[0].P;
                var c0 = new Point(first.Average(q => q.X), first.Average(q => q.Y));
                Text($"{d.Name}  ({faces.Count(q => q.Kind == StairFaceKind.Tread)} marches)", c0.X - 20, c0.Y - 22, 10, Br("#263238"), Br("#CCFFFFFF"), true);
            }
        }
    }
}
