using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Résultats globaux façon Robot : réactions d'appui, déplacements nodaux, flèches des poutres, déplacements d'étage, synthèse du projet et estimation du coût.</summary>
public sealed class ResultsWindow : Window
{
    public ResultsWindow(StructModel m, AnalysisOutput o, Action<int> selectNode)
    {
        Title = "Résultats globaux - réactions, déplacements, flèches, étages, coût";
        Width = 1050; Height = 680; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var tabs = new TabControl { Margin = new Thickness(8) };
        var g = o.Global;
        if (g != null)
        {
            tabs.Items.Add(new TabItem { Header = "Réactions d'appui", Content = MakeGrid(g.Reactions.Select(r => new
            {
                Noeud = r.NodeId, Axes = r.AxisRef,
                Fz_min = r.Min[2].ToString("0.0"), Fz_max = r.Max[2].ToString("0.0"), Fz_ELS = r.FzService.ToString("0.0"),
                Fx_min = r.Min[0].ToString("0.0"), Fx_max = r.Max[0].ToString("0.0"),
                Fy_min = r.Min[1].ToString("0.0"), Fy_max = r.Max[1].ToString("0.0"),
                My_min = r.Min[4].ToString("0.0"), My_max = r.Max[4].ToString("0.0"),
            }).ToList(), "Enveloppe ELU/accidentelle en kN et kN.m. Total des Fz par cas : " + string.Join("   ", g.TotalFzByCase.Select(kv => $"{kv.Key} = {kv.Value:0.0} kN")), null) });
            tabs.Items.Add(new TabItem { Header = "Déplacements", Content = MakeGrid(g.Displacements.OrderByDescending(d => d.Total).Select(d => new
            {
                Noeud = d.NodeId, Ux_mm = d.Ux.ToString("0.00"), Uy_mm = d.Uy.ToString("0.00"), Uz_mm = d.Uz.ToString("0.00"), Total_mm = d.Total.ToString("0.00"), Combinaison = d.Combo
            }).ToList(), $"Déplacement maximal : {g.MaxDisplacementMm:0.00} mm (combinaison de service {g.DeformedCombo}). Cochez « Déformée » dans la vue pour la voir.", null) });
            tabs.Items.Add(new TabItem { Header = $"Flèches ({(g.DeflectionsOk ? "OK" : "NON OK")})", Content = MakeGrid(g.Deflections.OrderByDescending(d => d.DeltaMm / Math.Max(d.LimitMm, 1e-9)).Select(d => new
            {
                Barre = d.MemberId, Portee_m = d.LengthM.ToString("0.00"), Fleche_mm = d.DeltaMm.ToString("0.0"), Limite_mm = d.LimitMm.ToString("0.0"),
                L_sur = double.IsInfinity(d.Ratio) ? "-" : d.Ratio.ToString("0"), Verdict = d.Ok ? "OK" : "NON OK", Combinaison = d.Combo
            }).ToList(), "Flèche totale ELS, limite L/250 (ou selon la norme choisie).", null) });
            tabs.Items.Add(new TabItem { Header = $"Étages ({(g.DriftsOk ? "OK" : "NON OK")})", Content = MakeGrid(g.Drifts.Select(d => new
            {
                Niveau = d.Level, Hauteur_m = d.HeightM.ToString("0.00"), Delta_mm = d.DeltaMm.ToString("0.0"),
                h_sur = double.IsInfinity(d.Ratio) ? "-" : d.Ratio.ToString("0"), Limite = "h/" + d.LimitDenominator.ToString("0"), Verdict = d.Ok ? "OK" : "NON OK", Base = d.Basis, Combinaison = d.Combo
            }).ToList(), "Déplacement relatif entre étages consécutifs.", null) });
        }
        tabs.Items.Add(new TabItem { Header = "Synthèse", Content = Mono(ProjectSummary.Build(m, o)) });
        string cost;
        try { cost = CostEstimator.Compute(Quantities.Compute(m, o), m.Prices).ToText(); } catch (Exception ex) { cost = "Estimation impossible : " + ex.Message; }
        tabs.Items.Add(new TabItem { Header = "Estimation du coût", Content = Mono(cost + Environment.NewLine + Environment.NewLine + "Les prix unitaires sont modifiables dans le modèle (liste de prix) ; ils sont indicatifs.") });
        Content = tabs;
    }

    private static UIElement Mono(string text) => new TextBox
    {
        Text = text, IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 13, Padding = new Thickness(10),
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, BorderThickness = new Thickness(0)
    };

    private static UIElement MakeGrid<T>(List<T> rows, string note, Action<T>? _)
    {
        var dock = new DockPanel();
        var tb = new TextBlock { Text = note, Margin = new Thickness(6), TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray };
        DockPanel.SetDock(tb, Dock.Top); dock.Children.Add(tb);
        var dg = new DataGrid { ItemsSource = rows, IsReadOnly = true, AutoGenerateColumns = true, AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(0xF4, 0xF7, 0xFB)) };
        dg.AutoGeneratingColumn += (s, e) => e.Column.Header = e.PropertyName.Replace('_', ' ');
        dock.Children.Add(dg);
        return dock;
    }
}
