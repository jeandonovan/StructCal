using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

public enum SnapKind { None, Node, Mid, GridCross, OnAxis, Level, Track, UnderlayEnd, UnderlayMid, UnderlayCross, UnderlayLine, UnderlayPoint, Step }

/// <summary>Résultat d'un accrochage, en coordonnées du plan de la vue (U,V) : Plan = (x,y) ; Élévation = (x,z) ; Côté = (y,z).</summary>
public sealed class SnapHit
{
    public double U, V;
    public SnapKind Kind;
    public int NodeId = -1;
    public string Label = "";
    public double? GuideU, GuideV;           // lignes de repérage (axe, niveau, alignement)
    public Vec3? World;                      // vue 3D : point dans l'espace (U,V non utilisés)
}

/// <summary>Accrochages intelligents, comme dans Robot / AutoCAD : nœuds, milieux, intersections d'axes, axes, niveaux, alignement,
/// extrémités / milieux / intersections du fond de plan (DXF vectoriel, PDF et images détectés sur les pixels), puis pas de grille.</summary>
public sealed partial class ModelViewport
{
    public bool SnapEnabled { get; set; } = true;
    public bool SnapNodes { get; set; } = true;
    public bool SnapMid { get; set; } = true;
    public bool SnapGridInt { get; set; } = true;
    public bool SnapOnAxis { get; set; } = true;
    public bool SnapLevels { get; set; } = true;
    public bool SnapTrack { get; set; } = true;
    public bool SnapUnderlay { get; set; } = true;
    public bool SnapStep { get; set; } = true;
    public double SnapPixels { get; set; } = 12;

    // ------------------------------------------------------------------ plan de la vue
    private (double U, double V) PlaneOf(double x, double y, double z) => Mode switch
    {
        ViewMode.Plan => (x, y), ViewMode.Elevation => (x, z), ViewMode.Side => (y, z), _ => (0, 0)
    };

    private bool OnPlane(Node n) => Mode switch
    {
        ViewMode.Plan => Math.Abs(n.Z - WorkOffset) < 1e-3,
        ViewMode.Elevation => Math.Abs(n.Y - WorkOffset) < 1e-3,
        ViewMode.Side => Math.Abs(n.X - WorkOffset) < 1e-3,
        _ => false
    };

    private void PlaneWorld(double u, double v, out double x, out double y, out double z)
    {
        x = y = z = 0;
        switch (Mode)
        {
            case ViewMode.Plan: x = u; y = v; z = WorkOffset; break;
            case ViewMode.Elevation: x = u; z = v; y = WorkOffset; break;
            case ViewMode.Side: y = u; z = v; x = WorkOffset; break;
        }
    }

    private Point PlaneScreen(double u, double v)
    {
        PlaneWorld(u, v, out double x, out double y, out double z);
        return S(x, y, z);
    }

    private void AddAt(UIElement e, double x, double y)
    {
        Canvas.SetLeft(e, x); Canvas.SetTop(e, y);
        _c.Children.Add(e);
    }

    private readonly struct Cand
    {
        public readonly double U, V, Penalty; public readonly SnapKind Kind; public readonly string Label; public readonly int Node;
        public Cand(double u, double v, SnapKind k, string label, double pen, int node = -1) { U = u; V = v; Kind = k; Label = label; Penalty = pen; Node = node; }
    }

    private static double DistSeg(double px, double py, double x1, double y1, double x2, double y2, out double qx, out double qy)
    {
        double dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-18 ? 0 : Math.Max(0, Math.Min(1, ((px - x1) * dx + (py - y1) * dy) / l2));
        qx = x1 + t * dx; qy = y1 + t * dy;
        return Math.Sqrt((px - qx) * (px - qx) + (py - qy) * (py - qy));
    }

    private static bool SegIntersect(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy, out double ix, out double iy)
    {
        ix = iy = 0;
        double r1 = bx - ax, r2 = by - ay, s1 = dx - cx, s2 = dy - cy;
        double den = r1 * s2 - r2 * s1;
        if (Math.Abs(den) < 1e-12) return false;
        double t = ((cx - ax) * s2 - (cy - ay) * s1) / den, u = ((cx - ax) * r2 - (cy - ay) * r1) / den;
        if (t < -1e-9 || t > 1 + 1e-9 || u < -1e-9 || u > 1 + 1e-9) return false;
        ix = ax + t * r1; iy = ay + t * r2;
        return true;
    }

    // ------------------------------------------------------------------ calcul
    /// <summary>Point d'accrochage sous le curseur (null en vue 3D libre).</summary>
    private SnapHit? ComputeSnap(Point p)
    {
        if (Model == null) return null;
        if (Mode == ViewMode.Iso) return ComputeSnapIso(p);
        if (!ToWorld(p, out double wx, out double wy, out double wz)) return null;
        var (cu, cv) = PlaneOf(wx, wy, wz);
        if (!SnapEnabled)
            return new SnapHit { U = cu, V = cv, Kind = SnapKind.None };

        double tolPx = SnapPixels, tol = tolPx / _scale;
        var info = GetInfo();
        var cands = new List<Cand>();

        if (SnapNodes)
            foreach (var n in Model.Nodes)
            {
                var (u, v) = PlaneOf(n.X, n.Y, n.Z);
                if (Math.Abs(u - cu) > tol || Math.Abs(v - cv) > tol) continue;
                bool on = OnPlane(n);
                cands.Add(new Cand(u, v, SnapKind.Node, "Nœud " + n.Id + (on ? "" : " (hors plan)"), on ? 0 : 6, n.Id));
            }

        if (SnapMid)
        {
            var nd = Model.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
            foreach (var m in Model.Members)
            {
                if (!nd.TryGetValue(m.NodeI, out var a) || !nd.TryGetValue(m.NodeJ, out var b)) continue;
                if (!OnPlane(a) || !OnPlane(b)) continue;
                var (u1, v1) = PlaneOf(a.X, a.Y, a.Z); var (u2, v2) = PlaneOf(b.X, b.Y, b.Z);
                double mu = (u1 + u2) / 2, mv = (v1 + v2) / 2;
                if (Math.Abs(mu - cu) > tol || Math.Abs(mv - cv) > tol) continue;
                cands.Add(new Cand(mu, mv, SnapKind.Mid, "Milieu barre " + m.Id, 3));
            }
        }

        // axes : intersections et verrouillage d'une seule coordonnée
        double? lockU = null, lockV = null; string lockUName = "", lockVName = "";
        SnapKind lockUKind = SnapKind.OnAxis, lockVKind = SnapKind.OnAxis;
        var uAxes = Mode == ViewMode.Side ? info.YAxes : info.XAxes;
        var vAxes = Mode == ViewMode.Plan ? info.YAxes : null;
        if (SnapGridInt || SnapOnAxis)
        {
            if (Mode == ViewMode.Plan)
            {
                if (SnapGridInt)
                    foreach (var ax in info.XAxes) foreach (var ay in info.YAxes)
                        if (Math.Abs(ax.Pos - cu) <= tol && Math.Abs(ay.Pos - cv) <= tol)
                            cands.Add(new Cand(ax.Pos, ay.Pos, SnapKind.GridCross, $"Axes {ay.Name}-{ax.Name}", 2));
            }
            else if (SnapGridInt)
            {
                foreach (var ax in uAxes) foreach (var lv in info.Levels)
                    if (Math.Abs(ax.Pos - cu) <= tol && Math.Abs(lv.Z - cv) <= tol)
                        cands.Add(new Cand(ax.Pos, lv.Z, SnapKind.GridCross, $"Axe {ax.Name} / {lv.Name}", 2));
            }
        }
        if (SnapOnAxis)
        {
            double bu = tol;
            foreach (var ax in uAxes) if (Math.Abs(ax.Pos - cu) <= bu) { bu = Math.Abs(ax.Pos - cu); lockU = ax.Pos; lockUName = "Axe " + ax.Name; }
            if (vAxes != null)
            {
                double bv = tol;
                foreach (var ay in vAxes) if (Math.Abs(ay.Pos - cv) <= bv) { bv = Math.Abs(ay.Pos - cv); lockV = ay.Pos; lockVName = "Axe " + ay.Name; }
            }
        }
        if (SnapLevels && Mode != ViewMode.Plan)
        {
            double bv = tol;
            foreach (var lv in info.Levels) if (Math.Abs(lv.Z - cv) <= bv) { bv = Math.Abs(lv.Z - cv); lockV = lv.Z; lockVName = lv.Name; lockVKind = SnapKind.Level; }
        }
        // alignement avec le point précédent (outil Barre)
        if (SnapTrack && Tool == EditTool.Member && _pendingNodeId != -1)
        {
            var pn = Model.Nodes.FirstOrDefault(n => n.Id == _pendingNodeId);
            if (pn != null)
            {
                var (pu, pv) = PlaneOf(pn.X, pn.Y, pn.Z);
                if (lockU == null && Math.Abs(pu - cu) <= tol) { lockU = pu; lockUName = "Aligné vertical"; lockUKind = SnapKind.Track; }
                if (lockV == null && Math.Abs(pv - cv) <= tol) { lockV = pv; lockVName = "Aligné horizontal"; lockVKind = SnapKind.Track; }
            }
        }
        // fonds de plan (uniquement en plan)
        if (SnapUnderlay && Mode == ViewMode.Plan)
            foreach (var ud in Underlays)
                if (ud.Def.Visible && ud.Error == "") UnderlayCandidates(ud, cu, cv, tol, cands);

        // meilleur point
        int best = -1; double bestScore = double.MaxValue;
        for (int i = 0; i < cands.Count; i++)
        {
            double du = (cands[i].U - cu) * _scale, dv = (cands[i].V - cv) * _scale;
            double d = Math.Sqrt(du * du + dv * dv);
            if (d > tolPx) continue;
            double score = d + cands[i].Penalty;
            if (score < bestScore) { bestScore = score; best = i; }
        }
        if (best >= 0)
        {
            var c = cands[best];
            return new SnapHit { U = c.U, V = c.V, Kind = c.Kind, NodeId = c.Node, Label = c.Label };
        }

        // sinon : coordonnées verrouillées + pas de grille
        var hit = new SnapHit { U = cu, V = cv, Kind = SnapKind.None };
        if (lockU != null) { hit.U = lockU.Value; hit.GuideU = lockU; }
        else if (SnapStep) hit.U = Sn(cu);
        if (lockV != null) { hit.V = lockV.Value; hit.GuideV = lockV; }
        else if (SnapStep) hit.V = Sn(cv);
        if (lockU != null && lockV != null) { hit.Kind = SnapKind.GridCross; hit.Label = lockUName + " × " + lockVName; }
        else if (lockU != null) { hit.Kind = lockUKind; hit.Label = lockUName; }
        else if (lockV != null) { hit.Kind = lockVKind; hit.Label = lockVName; }
        else if (SnapStep) { hit.Kind = SnapKind.Step; hit.Label = ""; }
        return hit;
    }

    private void UnderlayCandidates(UnderlayData ud, double cu, double cv, double tol, List<Cand> cands)
    {
        var def = ud.Def;
        if (ud.Dxf != null)
        {
            ud.EnsureWorld();
            var w = ud.World;
            int n = w.Length / 5;
            var near = new List<int>();
            double bestLineD = tol; double lqx = 0, lqy = 0; bool haveLine = false;
            for (int i = 0; i < n; i++)
            {
                double x1 = w[i * 5], y1 = w[i * 5 + 1], x2 = w[i * 5 + 2], y2 = w[i * 5 + 3];
                if (Math.Max(x1, x2) < cu - tol || Math.Min(x1, x2) > cu + tol || Math.Max(y1, y2) < cv - tol || Math.Min(y1, y2) > cv + tol) continue;
                double d = DistSeg(cu, cv, x1, y1, x2, y2, out double qx, out double qy);
                if (d > tol) continue;
                if (near.Count < 90) near.Add(i);
                if (d < bestLineD) { bestLineD = d; lqx = qx; lqy = qy; haveLine = true; }
            }
            foreach (int i in near)
            {
                double x1 = w[i * 5], y1 = w[i * 5 + 1], x2 = w[i * 5 + 2], y2 = w[i * 5 + 3];
                if (w[i * 5 + 4] != 0) continue;                                 // fragments de courbes : pas d'accrochage sur leurs sommets
                if (Math.Abs(x1 - cu) <= tol && Math.Abs(y1 - cv) <= tol) cands.Add(new Cand(x1, y1, SnapKind.UnderlayEnd, "Extrémité (fond)", 1));
                if (Math.Abs(x2 - cu) <= tol && Math.Abs(y2 - cv) <= tol) cands.Add(new Cand(x2, y2, SnapKind.UnderlayEnd, "Extrémité (fond)", 1));
                double mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
                if (Math.Abs(mx - cu) <= tol && Math.Abs(my - cv) <= tol) cands.Add(new Cand(mx, my, SnapKind.UnderlayMid, "Milieu (fond)", 3));
            }
            for (int a = 0; a < near.Count; a++)
                for (int b = a + 1; b < near.Count; b++)
                {
                    int i = near[a], j = near[b];
                    if (SegIntersect(w[i * 5], w[i * 5 + 1], w[i * 5 + 2], w[i * 5 + 3], w[j * 5], w[j * 5 + 1], w[j * 5 + 2], w[j * 5 + 3], out double ix, out double iy)
                        && Math.Abs(ix - cu) <= tol && Math.Abs(iy - cv) <= tol)
                        cands.Add(new Cand(ix, iy, SnapKind.UnderlayCross, "Intersection (fond)", 1));
                }
            foreach (var pt in ud.WorldPoints)
                if (Math.Abs(pt.X - cu) <= tol && Math.Abs(pt.Y - cv) <= tol) cands.Add(new Cand(pt.X, pt.Y, SnapKind.UnderlayPoint, "Centre / point (fond)", 1));
            if (haveLine) cands.Add(new Cand(lqx, lqy, SnapKind.UnderlayLine, "Sur le trait (fond)", 9));
        }
        else if (ud.Ink != null)
        {
            var (sx, sy) = UnderlayMath.FromModel(def, cu, cv);
            double pxScr = _scale * def.Scale;
            if (pxScr <= 1e-9) return;
            int rad = (int)Math.Round(Math.Min(30, Math.Max(2, SnapPixels / pxScr)));
            if (RasterSnap.Find(ud.Ink, ud.W, ud.H, sx - 0.5, ud.H - sy - 0.5, rad, out double fx, out double fy, out var kind))
            {
                var m = UnderlayMath.ToModel(def, fx + 0.5, ud.H - (fy + 0.5));
                var (k, label, pen) = kind switch
                {
                    RasterSnapKind.Cross => (SnapKind.UnderlayCross, "Intersection (fond)", 1.0),
                    RasterSnapKind.Corner => (SnapKind.UnderlayEnd, "Coin (fond)", 1.0),
                    RasterSnapKind.End => (SnapKind.UnderlayEnd, "Extrémité (fond)", 1.0),
                    _ => (SnapKind.UnderlayLine, "Sur le trait (fond)", 9.0)
                };
                cands.Add(new Cand(m.X, m.Y, k, label, pen));
            }
        }
    }

    // ------------------------------------------------------------------ affichage
    private void DrawSnapOverlay(Dictionary<int, Node> nodes)
    {
        if (!_cursorValid) return;
        if (Tool == EditTool.Select && !Picking) return;
        var hit = ComputeSnap(_cursor);
        if (hit == null) return;
        var orange = Br("#E65100");
        Point m = hit.World is Vec3 w3 ? S(w3.X, w3.Y, w3.Z) : PlaneScreen(hit.U, hit.V);

        // repères d'axe / niveau / alignement
        var guide = Br("#99E65100");
        if (hit.GuideU != null)
        {
            DashLn(m.X, m.Y - 3000, m.X, m.Y + 3000, guide, 1);
        }
        if (hit.GuideV is double)
            DashLn(m.X - 3000, m.Y, m.X + 3000, m.Y, guide, 1);

        var col = hit.Kind switch
        {
            SnapKind.Node or SnapKind.UnderlayEnd or SnapKind.UnderlayPoint => Br("#E65100"),
            SnapKind.Mid or SnapKind.UnderlayMid => Br("#2E7D32"),
            SnapKind.GridCross or SnapKind.UnderlayCross => Br("#C2185B"),
            SnapKind.OnAxis or SnapKind.Level or SnapKind.Track or SnapKind.UnderlayLine => Br("#1565C0"),
            _ => orange
        };
        switch (hit.Kind)
        {
            case SnapKind.Node: case SnapKind.UnderlayEnd: case SnapKind.UnderlayPoint:
                AddAt(new Rectangle { Width = 13, Height = 13, Stroke = col, StrokeThickness = 2, IsHitTestVisible = false }, m.X - 6.5, m.Y - 6.5);
                break;
            case SnapKind.Mid: case SnapKind.UnderlayMid:
                _c.Children.Add(new Polygon { Stroke = col, StrokeThickness = 2, Fill = Brushes.Transparent, IsHitTestVisible = false,
                    Points = new PointCollection { new Point(m.X, m.Y - 8), new Point(m.X - 8, m.Y + 6), new Point(m.X + 8, m.Y + 6) } });
                break;
            case SnapKind.GridCross: case SnapKind.UnderlayCross:
                Ln(m.X - 8, m.Y - 8, m.X + 8, m.Y + 8, col, 2); Ln(m.X - 8, m.Y + 8, m.X + 8, m.Y - 8, col, 2);
                AddAt(new Ellipse { Width = 16, Height = 16, Stroke = col, StrokeThickness = 1.5, IsHitTestVisible = false }, m.X - 8, m.Y - 8);
                break;
            case SnapKind.OnAxis: case SnapKind.Level: case SnapKind.Track: case SnapKind.UnderlayLine:
                AddAt(new Ellipse { Width = 12, Height = 12, Stroke = col, StrokeThickness = 2, IsHitTestVisible = false }, m.X - 6, m.Y - 6);
                break;
            default:
                Ln(m.X - 9, m.Y, m.X + 9, m.Y, col, 1.5); Ln(m.X, m.Y - 9, m.X, m.Y + 9, col, 1.5);
                break;
        }
        double x = 0, y = 0, z = 0;
        if (hit.World is Vec3 w4) { x = w4.X; y = w4.Y; z = w4.Z; } else PlaneWorld(hit.U, hit.V, out x, out y, out z);
        string coords = Mode == ViewMode.Iso ? $"({x:0.###} ; {y:0.###} ; {z:0.###})" : Mode == ViewMode.Plan ? $"({x:0.###} ; {y:0.###})" : Mode == ViewMode.Elevation ? $"(x {x:0.###} ; z {z:0.###})" : $"(y {y:0.###} ; z {z:0.###})";
        Text((hit.Label != "" ? hit.Label + "  " : "") + coords, m.X + 12, m.Y + 8, 10, col, Br("#E6FFFFFF"), true);

        if (Picking && _pickPts.Count > 0)
        {
            var last = _pickPts[^1];
            var a = S(last.X, last.Y, WorkOffset);
            DashLn(a.X, a.Y, m.X, m.Y, orange, 1.5);
            for (int i = 0; i < _pickPts.Count; i++)
            {
                var q = S(_pickPts[i].X, _pickPts[i].Y, WorkOffset);
                AddAt(new Ellipse { Width = 9, Height = 9, Fill = orange, IsHitTestVisible = false }, q.X - 4.5, q.Y - 4.5);
            }
            if (_pickPts.Count >= 1)
            {
                double dd = Math.Sqrt((hit.U - last.X) * (hit.U - last.X) + (hit.V - last.Y) * (hit.V - last.Y));
                Text($"{dd:0.###} m (mesuré sur le fond actuel)", m.X + 12, m.Y + 24, 10, orange, Br("#E6FFFFFF"));
            }
            return;
        }
        if (Tool == EditTool.Member && _pendingNodeId != -1 && nodes.TryGetValue(_pendingNodeId, out var pn))
        {
            var a = S(pn);
            double dx = m.X - a.X, dy = m.Y - a.Y, len = Math.Sqrt(dx * dx + dy * dy);
            double p0 = 0;
            while (len > 1 && p0 < len)
            {
                double q = Math.Min(p0 + 7, len);
                Ln(a.X + dx * p0 / len, a.Y + dy * p0 / len, a.X + dx * q / len, a.Y + dy * q / len, orange, 2);
                p0 = q + 4;
            }
        }
    }

    // ------------------------------------------------------------------ saisie de points (calage des fonds de plan)
    private readonly List<(double X, double Y)> _pickPts = new();
    private int _pickCount;
    private Action<List<(double X, double Y)>>? _pickDone;
    public bool Picking => _pickDone != null;

    /// <summary>Demande n points à l'utilisateur dans la vue en plan (avec tous les accrochages), puis appelle done avec leurs coordonnées modèle (x, y).</summary>
    public void BeginPick(int count, string prompt, Action<List<(double X, double Y)>> done)
    {
        _pickPts.Clear(); _pickCount = count; _pickDone = done;
        if (Mode != ViewMode.Plan) SetMode(ViewMode.Plan);
        _c.Cursor = System.Windows.Input.Cursors.Cross;
        Hint?.Invoke(prompt + "  (Échap pour annuler)");
        Redraw();
    }

    public void CancelPick()
    {
        _pickDone = null; _pickPts.Clear();
        _c.Cursor = Tool == EditTool.Select ? System.Windows.Input.Cursors.Arrow : System.Windows.Input.Cursors.Cross;
        Hint?.Invoke("Saisie annulée.");
        Redraw();
    }

    private void HandlePickClick(Point p)
    {
        var hit = ComputeSnap(p);
        if (hit == null) return;
        _pickPts.Add((hit.U, hit.V));
        if (_pickPts.Count < _pickCount)
        {
            Hint?.Invoke($"Point {_pickPts.Count} enregistré - cliquez le point suivant ({_pickPts.Count + 1}/{_pickCount}).");
            Redraw();
            return;
        }
        var done = _pickDone; var pts = new List<(double X, double Y)>(_pickPts);
        _pickDone = null; _pickPts.Clear();
        _c.Cursor = Tool == EditTool.Select ? System.Windows.Input.Cursors.Arrow : System.Windows.Input.Cursors.Cross;
        Redraw();
        done?.Invoke(pts);
    }
}
