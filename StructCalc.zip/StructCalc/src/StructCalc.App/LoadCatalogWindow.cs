using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Loads;

namespace StructCalc.UI;

/// <summary>Valeur choisie dans le catalogue des charges.</summary>
public sealed record CatalogPick(double Value, string Kind, bool Live, string Text);

/// <summary>Bibliothèque de charges (NF P 06-004 / NF EN 1991-1-1) : mur + hauteur + épaisseur donne la charge linéaire, couches de plancher/toiture donnent la charge
/// surfacique, catégories d'usage donnent Q, matériaux donnent la charge d'après leurs dimensions. Utilisée par les saisies de charges.</summary>
public sealed class LoadCatalogWindow : Window
{
    public CatalogPick? Result { get; private set; }
    private readonly TabControl _tabs = new();
    private readonly Func<CatalogPick?>[] _picks = new Func<CatalogPick?>[4];
    private readonly ComboBox _range = new();

    private static RangeMode Mode(int i) => i == 1 ? RangeMode.Mean : i == 2 ? RangeMode.Min : RangeMode.Max;
    private RangeMode Rm => Mode(_range.SelectedIndex);
    private static string F(double v) => v.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
    private static double N(TextBox t, double d = 0) => Ui.Num(t.Text, d);

    /// <summary>Ouvre la bibliothèque. <paramref name="tab"/> : 0 mur, 1 couches, 2 exploitation, 3 matériaux.</summary>
    public static CatalogPick? Pick(Window? owner, int tab = 0)
    {
        var w = new LoadCatalogWindow(tab) { Owner = owner };
        return w.ShowDialog() == true ? w.Result : null;
    }

    private static TextBlock Hint(string t) => new() { Text = t, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(0, 2, 0, 6) };
    private static TextBlock Big(out TextBlock tb) { tb = new TextBlock { FontSize = 15, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 8, 0, 2), Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), TextWrapping = TextWrapping.Wrap }; return tb; }

    private static StackPanel Row(StackPanel host, string label, UIElement c, double lw = 190)
    {
        var g = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 3) };
        g.Children.Add(new TextBlock { Text = label, Width = lw, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap });
        g.Children.Add(c); host.Children.Add(g); return g;
    }
    private static TextBox Box(string def, double w = 80) => new() { Text = def, Width = w, Padding = new Thickness(3) };
    private static ComboBox Cmb(IEnumerable<object> items, double w = 420, int sel = 0)
    {
        var c = new ComboBox { Width = w };
        foreach (var i in items) c.Items.Add(i);
        if (c.Items.Count > 0) c.SelectedIndex = Math.Min(sel, c.Items.Count - 1);
        return c;
    }

    public LoadCatalogWindow(int startTab = 0)
    {
        Title = "Bibliothèque de charges (NF P 06-004 / NF EN 1991-1-1)"; Width = 720; Height = 640; MinHeight = 520;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new DockPanel { Margin = new Thickness(12) };

        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
        top.Children.Add(new TextBlock { Text = "Si le tableau donne une fourchette, retenir :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) });
        _range.Items.Add("la valeur maximale (sécuritaire)"); _range.Items.Add("la valeur moyenne"); _range.Items.Add("la valeur minimale");
        _range.SelectedIndex = 0; _range.Width = 240; top.Children.Add(_range);
        DockPanel.SetDock(top, Dock.Top); root.Children.Add(top);

        var bot = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 8, 0, 0) };
        bot.Children.Add(Ui.Btn("Utiliser cette valeur", (s, e) =>
        {
            var p = _picks[Math.Max(0, _tabs.SelectedIndex)]();
            if (p == null) { MessageBox.Show(this, "Rien à utiliser : complétez la saisie.", Title); return; }
            Result = p; DialogResult = true;
        }, true));
        bot.Children.Add(Ui.Btn("Annuler", (s, e) => DialogResult = false));
        DockPanel.SetDock(bot, Dock.Bottom); root.Children.Add(bot);

        var disc = Hint("Valeurs indicatives de la fiche française (NF P 06-004, Annexe Nationale NF EN 1991-1-1) : à confirmer avec les fiches techniques des produits utilisés et la réglementation locale (CBA / BAEL / RPA).");
        DockPanel.SetDock(disc, Dock.Bottom); root.Children.Add(disc);

        _tabs.Items.Add(new TabItem { Header = "Mur / cloison → kN/m", Content = Scroll(WallTab()) });
        _tabs.Items.Add(new TabItem { Header = "Couches → kN/m²", Content = Scroll(LayersTab()) });
        _tabs.Items.Add(new TabItem { Header = "Exploitation Q", Content = Scroll(LiveTab()) });
        _tabs.Items.Add(new TabItem { Header = "Matériaux (kN/m³)", Content = Scroll(MaterialTab()) });
        _tabs.SelectedIndex = Math.Clamp(startTab, 0, 3);
        root.Children.Add(_tabs);
        Content = root;
    }

    private static ScrollViewer Scroll(UIElement e) => new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = e, Padding = new Thickness(8) };

    // ------------------------------------------------------------------ 0 : mur
    private UIElement WallTab()
    {
        var p = new StackPanel();
        p.Children.Add(Hint("Choisissez la maçonnerie, son épaisseur et la hauteur du mur : la charge linéaire (kN/m) à poser sur la poutre ou la dalle se calcule seule. Enduits et ouvertures sont optionnels."));
        var items = LoadCatalog.Masonry.ToList();
        var mat = Cmb(items.Cast<object>(), 560);
        var th = Box("20"); var hh = Box("3"); var open = Box("0");
        var thCombo = new ComboBox { Width = 150, Margin = new Thickness(8, 0, 0, 0) };
        var faces = Cmb(new object[] { "Aucune face", "1 face enduite", "2 faces enduites" }, 160, 0);
        var plast = Cmb(LoadCatalog.Of(LoadCatalog.GPlaster).Cast<object>(), 330, 1);
        var plTh = Box("1.5");
        var res = Big(out var r1); var det = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 2) };
        WallLoadResult? last = null;

        Row(p, "Matériau de maçonnerie", mat, 190);
        var rowT = Row(p, "Épaisseur (cm)", th); rowT.Children.Add(thCombo);
        Row(p, "Hauteur du mur (m)", hh);
        Row(p, "Enduit", faces); Row(p, "Type d'enduit", plast); Row(p, "Épaisseur d'enduit (cm)", plTh);
        Row(p, "Ouvertures déduites (%)", open);
        p.Children.Add(res); p.Children.Add(det);

        void FillThick()
        {
            thCombo.Items.Clear();
            if (mat.SelectedItem is CatalogItem it && it.Unit == CatalogUnit.Table) foreach (var pt in it.Points) thCombo.Items.Add(F(pt.Thickness) + " cm");
            thCombo.Visibility = thCombo.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        }
        void Calc()
        {
            if (mat.SelectedItem is not CatalogItem it) return;
            var pl = plast.SelectedItem as CatalogItem;
            last = LoadCatalog.Wall(it, N(th), N(hh), faces.SelectedIndex, pl, N(plTh), N(open), Rm);
            r1.Text = $"Charge linéaire du mur : {F(last.LinearKnM)} kN/m";
            string s = $"Maçonnerie {F(last.MasonryKnM2)} kN/m²" + (last.PlasterKnM2 > 0 ? $" + enduits {F(last.PlasterKnM2)} kN/m²" : "") + $" = {F(last.SurfaceKnM2)} kN/m² × {F(N(hh))} m";
            if (N(open) > 0) s += $" × (1 - {F(N(open))} %)";
            if (last.OutsideTable) s += "\nÉpaisseur hors du tableau : valeur proportionnelle à l'épaisseur, à vérifier.";
            else if (it.Unit == CatalogUnit.Table && !it.Points.Any(q => Math.Abs(q.Thickness - N(th)) < 1e-6)) s += "\nÉpaisseur intermédiaire : interpolation entre les valeurs du tableau.";
            if (!string.IsNullOrEmpty(it.Note)) s += "\n" + it.Note;
            s += double.IsNaN(last.PartitionEquivalentKnM2) ? "\nCloison de plus de 3 kN/m : à traiter comme charge linéaire (pas de surcharge équivalente)."
               : $"\nSi c'est une cloison légère déplaçable sur dalle : surcharge équivalente {F(last.PartitionEquivalentKnM2)} kN/m² (à ajouter à Q, EN 1991-1-1 6.3.1.2).";
            det.Text = s;
        }
        mat.SelectionChanged += (s, e) => { FillThick(); if (mat.SelectedItem is CatalogItem it && it.Points.Length > 0) th.Text = F(it.Points[Math.Min(2, it.Points.Length - 1)].Thickness); else if (mat.SelectedItem is CatalogItem c2) th.Text = c2.Name.Contains("plâtre") ? "7" : "8"; Calc(); };
        thCombo.SelectionChanged += (s, e) => { if (thCombo.SelectedItem is string t) { th.Text = t.Replace(" cm", ""); } };
        foreach (var t in new[] { th, hh, plTh, open }) t.TextChanged += (s, e) => Calc();
        faces.SelectionChanged += (s, e) => Calc(); plast.SelectionChanged += (s, e) => Calc(); _range.SelectionChanged += (s, e) => Calc();
        FillThick(); mat.SelectedIndex = Math.Max(0, items.FindIndex(i => i.Id == "bc")); Calc();

        _picks[0] = () => last == null || last.LinearKnM <= 0 ? null
            : new CatalogPick(last.LinearKnM, "Linear", false, $"mur {((CatalogItem)mat.SelectedItem).Name} e = {F(N(th))} cm, h = {F(N(hh))} m");
        return p;
    }

    // ------------------------------------------------------------------ 1 : couches
    private UIElement LayersTab()
    {
        var p = new StackPanel();
        p.Children.Add(Hint("Empilez les couches d'un plancher ou d'une toiture (revêtement, chape, isolant, enduit, étanchéité, couverture...) : la somme donne la charge permanente G en kN/m². " +
                            "Ne mettez pas la dalle pleine si StructCalc calcule déjà son poids propre (« G supplémentaire » = revêtements, cloisons, faux plafond seulement)."));
        var group = Cmb(LoadCatalog.SurfaceGroups.Cast<object>(), 330);
        var item = Cmb(Array.Empty<object>(), 560);
        var th = Box("5"); var thLabel = new TextBlock { Text = "Épaisseur (cm)", Width = 190, VerticalAlignment = VerticalAlignment.Center };
        var list = new ListBox { Height = 150, Margin = new Thickness(0, 4, 0, 4) };
        var layers = new List<(CatalogItem It, double T)>();
        var total = Big(out var tt);
        Row(p, "Famille", group); Row(p, "Élément", item);
        var rowT = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 3) };
        rowT.Children.Add(thLabel); rowT.Children.Add(th);
        var add = Ui.Btn("Ajouter la couche", (s, e) =>
        {
            if (item.SelectedItem is not CatalogItem it) return;
            layers.Add((it, N(th))); Refresh();
        }); add.Margin = new Thickness(12, 0, 0, 0); rowT.Children.Add(add);
        var del = Ui.Btn("Retirer la sélection", (s, e) => { int i = list.SelectedIndex; if (i >= 0) { layers.RemoveAt(i); Refresh(); } }); rowT.Children.Add(del);
        p.Children.Add(rowT); p.Children.Add(list); p.Children.Add(total);

        double Sum() => layers.Sum(l => l.It.Surface(l.T, Rm, out _));
        void Refresh()
        {
            list.Items.Clear();
            foreach (var l in layers) list.Items.Add($"{l.It.Name}{(l.It.NeedsThickness ? $" - {F(l.T)} cm" : "")}  →  {F(l.It.Surface(l.T, Rm, out _))} kN/m²");
            tt.Text = $"Charge permanente totale : {F(Sum())} kN/m²";
        }
        void FillItems()
        {
            item.Items.Clear();
            foreach (var i in LoadCatalog.Of((string)group.SelectedItem!)) item.Items.Add(i);
            if (item.Items.Count > 0) item.SelectedIndex = 0;
        }
        void Sel()
        {
            if (item.SelectedItem is not CatalogItem it) return;
            bool need = it.NeedsThickness; th.IsEnabled = need; thLabel.Text = need ? "Épaisseur (cm)" : "Épaisseur (cm), valeur fixe";
            if (it.Unit == CatalogUnit.Table && it.Points.Length > 0) th.Text = F(it.Points[0].Thickness);
        }
        group.SelectionChanged += (s, e) => FillItems(); item.SelectionChanged += (s, e) => Sel(); _range.SelectionChanged += (s, e) => Refresh();
        FillItems(); Refresh();
        _picks[1] = () => layers.Count == 0 ? null : new CatalogPick(Sum(), "Surface", false, $"{layers.Count} couche(s) : " + string.Join(" + ", layers.Select(l => l.It.Name.Split(':').Last().Trim())));
        return p;
    }

    // ------------------------------------------------------------------ 2 : exploitation
    private UIElement LiveTab()
    {
        var p = new StackPanel();
        p.Children.Add(Hint("Charges d'exploitation par catégorie d'usage (NF EN 1991-1-1 et Annexe Nationale). qk : charge répartie (kN/m²) ; Qk : charge concentrée (kN), à vérifier séparément ; " +
                            "horizontale : sur parapets, garde-corps et cloisons de séparation (kN/m)."));
        var cat = Cmb(LoadCatalog.LiveCategories.Select(c => (object)c.Name), 640);
        var use = Cmb(new object[] { "Charge répartie qk (kN/m²)", "Charge concentrée Qk (kN)", "Charge horizontale sur garde-corps (kN/m)" }, 300);
        var info = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 6, 0, 2) };
        var big = Big(out var tt);
        Row(p, "Catégorie", cat, 100); Row(p, "Valeur à utiliser", use, 100);
        p.Children.Add(big); p.Children.Add(info);
        LiveCategory C() => LoadCatalog.LiveCategories[Math.Max(0, cat.SelectedIndex)];
        double V() => use.SelectedIndex == 0 ? C().QkKnM2 : use.SelectedIndex == 1 ? C().PointKn : C().HorizKnM;
        string U() => use.SelectedIndex == 0 ? "kN/m²" : use.SelectedIndex == 1 ? "kN" : "kN/m";
        void Calc()
        {
            var c = C();
            tt.Text = $"{F(V())} {U()}";
            info.Text = $"qk = {F(c.QkKnM2)} kN/m²   Qk = {F(c.PointKn)} kN   horizontale = {F(c.HorizKnM)} kN/m" + (c.Note != "" ? "\n" + c.Note : "") +
                        "\nÀ ajouter si besoin : cloisons légères déplaçables (0,5 / 0,8 / 1,2 kN/m² selon leur poids par mètre : onglet Mur/cloison). Les valeurs de combinaison (ψ) sont gérées par le projet.";
        }
        cat.SelectionChanged += (s, e) => Calc(); use.SelectionChanged += (s, e) => Calc(); Calc();
        _picks[2] = () => V() <= 0 ? null : new CatalogPick(V(), use.SelectedIndex == 0 ? "Surface" : use.SelectedIndex == 1 ? "Point" : "Linear", true, C().Name.Split(':')[0].Trim() + " : " + F(V()) + " " + U());
        return p;
    }

    // ------------------------------------------------------------------ 3 : matériaux
    private UIElement MaterialTab()
    {
        var p = new StackPanel();
        p.Children.Add(Hint("Poids volumique d'un matériau (kN/m³) → charge linéaire d'un élément (largeur × hauteur), charge surfacique (épaisseur) ou charge ponctuelle (volume). Exemple : acrotère en béton armé, bardage, réservoir de sable..."));
        var mat = Cmb(LoadCatalog.Volumics.Cast<object>(), 560);
        var use = Cmb(new object[] { "Linéaire : section b × h → kN/m", "Surfacique : épaisseur → kN/m²", "Ponctuel : volume → kN" }, 300);
        var a = Box("0.2"); var b = Box("0.5");
        var la = new TextBlock { Width = 190, VerticalAlignment = VerticalAlignment.Center }; var lb = new TextBlock { Width = 190, VerticalAlignment = VerticalAlignment.Center };
        var big = Big(out var tt); var info = new TextBlock { TextWrapping = TextWrapping.Wrap };
        Row(p, "Matériau", mat); Row(p, "Résultat", use);
        var r1 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 3) }; r1.Children.Add(la); r1.Children.Add(a); p.Children.Add(r1);
        var r2 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 3) }; r2.Children.Add(lb); r2.Children.Add(b); p.Children.Add(r2);
        p.Children.Add(big); p.Children.Add(info);
        double Val()
        {
            if (mat.SelectedItem is not CatalogItem it) return 0;
            double g = it.Volumic(Rm);
            return use.SelectedIndex switch { 0 => g * N(a) * N(b), 1 => g * N(a), _ => g * N(a) };
        }
        string Unit() => use.SelectedIndex == 0 ? "kN/m" : use.SelectedIndex == 1 ? "kN/m²" : "kN";
        void Calc()
        {
            int k = use.SelectedIndex;
            la.Text = k == 0 ? "Largeur b (m)" : k == 1 ? "Épaisseur (m)" : "Volume (m³)";
            lb.Text = "Hauteur h (m)"; (b.Parent as StackPanel)!.Visibility = k == 0 ? Visibility.Visible : Visibility.Collapsed;
            if (mat.SelectedItem is not CatalogItem it) return;
            tt.Text = $"{F(Val())} {Unit()}";
            info.Text = $"γ = {F(it.Volumic(Rm))} kN/m³" + (it.Min != it.Max ? $" (fourchette {F(it.Min)} à {F(it.Max)})" : "") + (it.Note != "" ? "  -  " + it.Note : "");
        }
        mat.SelectionChanged += (s, e) => Calc(); use.SelectionChanged += (s, e) => Calc(); _range.SelectionChanged += (s, e) => Calc();
        a.TextChanged += (s, e) => Calc(); b.TextChanged += (s, e) => Calc();
        mat.SelectedIndex = Math.Max(0, LoadCatalog.Volumics.ToList().FindIndex(i => i.Id == "ba")); Calc();
        _picks[3] = () => Val() <= 0 ? null : new CatalogPick(Val(), use.SelectedIndex == 0 ? "Linear" : use.SelectedIndex == 1 ? "Surface" : "Point", false,
            ((CatalogItem)mat.SelectedItem!).Name + " " + F(Val()) + " " + Unit());
        return p;
    }
}
