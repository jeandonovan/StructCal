using System.Windows;

namespace StructCalc.UI;

/// <summary>Assistants de création et de calcul : escaliers, planchers, fondations avec sol, voiles en coques.</summary>
public partial class MainWindow
{
    private StairWizardWindow? _stairWin;
    private FloorWizardWindow? _floorWin;
    private SoilFootingWizardWindow? _soilWin;
    private WallWizardWindow? _wallWin;
    private RaftWizardWindow? _raftWin;
    private SectionWizardWindow? _beamWin, _colWin;
    private SteelLibraryWindow? _steelLib;

    private void SteelLibrary_Click(object sender, RoutedEventArgs e)
    {
        if (_steelLib != null) { _steelLib.Activate(); return; }
        _steelLib = new SteelLibraryWindow(ApplySteelProfile) { Owner = this };
        _steelLib.Closed += (s, a) => _steelLib = null;
        _steelLib.Show();
    }

    /// <summary>Affecte le profilé aux barres sélectionnées (elles deviennent des barres acier). Retourne le nombre de barres modifiées.</summary>
    private int ApplySteelProfile(string profile)
    {
        var ids = _vp.Selection.ToList();
        if (ids.Count == 0 && _vp.SelectedId >= 0) ids.Add(_vp.SelectedId);
        var targets = _model.Members.Where(m => ids.Contains(m.Id)).ToList();
        if (targets.Count == 0) return 0;
        PushUndo();
        foreach (var m in targets)
        {
            m.Kind = StructCalc.Core.MaterialKind.Steel; m.Profile = profile; m.LfFactor = Math.Max(m.LfFactor, 1.0);
        }
        OnModelEdited();
        _vp.SetSelection(ids, false); _vp.Redraw();
        StatusLeft.Text = $"{profile} appliqué à {targets.Count} barre(s) - relancez le calcul (F5).";
        return targets.Count;
    }

    private void BeamAssistant_Click(object sender, RoutedEventArgs e)
    {
        if (_beamWin != null) { _beamWin.Activate(); return; }
        _beamWin = new SectionWizardWindow(true, () => _model, () => _out, () => _vp.SelectedId, ApplyLoadEdit) { Owner = this };
        _beamWin.Closed += (s, a) => _beamWin = null;
        _beamWin.Show();
    }

    private void ColumnAssistant_Click(object sender, RoutedEventArgs e)
    {
        if (_colWin != null) { _colWin.Activate(); return; }
        _colWin = new SectionWizardWindow(false, () => _model, () => _out, () => _vp.SelectedId, ApplyLoadEdit) { Owner = this };
        _colWin.Closed += (s, a) => _colWin = null;
        _colWin.Show();
    }

    private void Walls_Click(object sender, RoutedEventArgs e)
    {
        if (_wallWin != null) { _wallWin.Activate(); return; }
        _wallWin = new WallWizardWindow(() => _model, ApplyLoadEdit) { Owner = this };
        _wallWin.Closed += (s, a) => _wallWin = null;
        _wallWin.Show();
    }

    private void LoadCatalog_Click(object sender, RoutedEventArgs e) => ApplyCatalog(0, null);

    private void Rafts_Click(object sender, RoutedEventArgs e)
    {
        if (_raftWin != null) { _raftWin.Activate(); return; }
        _raftWin = new RaftWizardWindow(() => _model, () => _out, ApplyLoadEdit) { Owner = this };
        _raftWin.Closed += (s, a) => _raftWin = null;
        _raftWin.Show();
    }

    private void Soil_Click(object sender, RoutedEventArgs e)
    {
        if (_soilWin != null) { _soilWin.Activate(); return; }
        _soilWin = new SoilFootingWizardWindow(() => _model, ApplyLoadEdit) { Owner = this };
        _soilWin.Closed += (s, a) => _soilWin = null;
        _soilWin.Show();
    }

    private void Floors_Click(object sender, RoutedEventArgs e)
    {
        if (_floorWin != null) { _floorWin.Activate(); return; }
        _floorWin = new FloorWizardWindow(() => _model, ApplyLoadEdit) { Owner = this };
        _floorWin.Closed += (s, a) => _floorWin = null;
        _floorWin.Show();
    }

    private void Stairs_Click(object sender, RoutedEventArgs e)
    {
        if (_stairWin != null) { _stairWin.Activate(); return; }
        _stairWin = new StairWizardWindow(() => _model, ApplyLoadEdit) { Owner = this };
        _stairWin.Closed += (s, a) => _stairWin = null;
        _stairWin.Show();
    }

    private void SlabTypes_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SlabTypesWindow { Owner = this };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var sheets = StructCalc.Engine.Drawing.SlabTypeSheets.Build(dlg.P);
            if (sheets.Count == 0) { StatusLeft.Text = "Aucun type de dalle sélectionné."; return; }
            int n = 1;
            foreach (var sh in sheets)
            {
                sh.Number = (n++).ToString("00");
                StructCalc.Engine.Drawing.SheetLayout.Prepare(sh);
                StructCalc.Engine.Drawing.TitleBlock.Add(sh, _model.Name, "Coupes types", StructCalc.Core.Licensing.LicenseManager.Current.IsFull, _model.Settings);
            }
            Log($"Types de dalle : {sheets.Count} planche(s) de coupes types.");
            new SheetViewerWindow(sheets, _model.Name + " - types de dalle") { Owner = this }.Show();
        }
        catch (Exception ex)
        {
            Log("Erreur de dessin des types de dalle : " + ex.Message);
            MessageBox.Show("Erreur : " + ex.Message, "StructCalc", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
