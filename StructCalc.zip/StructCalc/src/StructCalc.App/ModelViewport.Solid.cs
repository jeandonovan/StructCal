using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Partie « scène 3D » de la vue : solides des barres (styles trait, caché, ombré, réaliste, rayons X), axes (grid lines) et niveaux,
/// perspective, orbite autour d'un pivot (élément sélectionné) comme dans SketchUp ou Revit, zoom sur la sélection.</summary>
public sealed partial class ModelViewport
{
    // ------------------------------------------------------------------ options
    private DisplayStyle _renderStyle = DisplayStyle.Ombre;
    public DisplayStyle RenderStyle { get => _renderStyle; set { _renderStyle = value; Redraw(); } }
    public bool Perspective { get; set; } = true;
    public bool OrbitOnSelection { get; set; } = true;
    public bool ShowGrid { get; set; } = true;
    public bool ShowLevels { get; set; } = true;
    public bool ShowShadows { get; set; } = true;
    public HashSet<int> HiddenLevels { get; set; } = new();
    public string HighlightAxis { get; set; } = "";
    public int HighlightLevel { get; set; } = -1;
    public double LevelTolerance { get; set; } = 0.05;
    public event Action<string>? HoverChanged;

    public string StyleName => RenderStyle switch
    {
        DisplayStyle.Fil => "fil (axes)", DisplayStyle.Trait => "trait", DisplayStyle.Cache => "lignes cachées",
        DisplayStyle.Ombre => "ombré", DisplayStyle.Realiste => "réaliste", DisplayStyle.Ferraille => "ferraillage 3D", _ => "rayons X"
    };

    private bool Solid => RenderStyle == DisplayStyle.Cache || RenderStyle == DisplayStyle.Ombre || RenderStyle == DisplayStyle.Realiste;

    // ------------------------------------------------------------------ niveaux, axes et solides (avec cache)
    private static readonly StructureInfo EmptyInfo = new();
    private StructureInfo? _info;
    private long _infoSig;
    private List<Face>? _faces;
    private long _facesSig;

    public StructureInfo Info => GetInfo();

    private long ModelSignature()
    {
        if (Model == null) return 0;
        long s = Model.Nodes.Count * 1000003L + Model.Members.Count;
        foreach (var n in Model.Nodes)
            s = s * 31 + n.Id + (long)Math.Round(n.X * 1000) * 7 + (long)Math.Round(n.Y * 1000) * 13 + (long)Math.Round(n.Z * 1000) * 17;
        foreach (var m in Model.Members)
            s = s * 31 + m.Id + m.NodeI * 5L + m.NodeJ * 11L + (long)Math.Round(m.B * 1000) * 3 + (long)Math.Round(m.H * 1000) * 19 + (long)Math.Round(m.Roll * 100) * 23
                + (m.Profile ?? "").GetHashCode() + (int)m.Type * 101 + (int)m.Kind * 211;
        foreach (var l in Model.Levels) s = s * 31 + (long)Math.Round(l.Elevation * 1000) + (l.Name ?? "").GetHashCode();
        foreach (var a in Model.Grid.XAxes) s = s * 37 + (long)Math.Round(a.Pos * 1000) + (a.Name ?? "").GetHashCode();
        foreach (var a in Model.Grid.YAxes) s = s * 41 + (long)Math.Round(a.Pos * 1000) + (a.Name ?? "").GetHashCode();
        return s;
    }

    private StructureInfo GetInfo()
    {
        if (Model == null) return EmptyInfo;
        long s = ModelSignature();
        if (_info == null || s != _infoSig) { _info = StructureAnalyzer.Analyze(Model, LevelTolerance); _infoSig = s; }
        return _info;
    }

    private List<Face> GetFaces()
    {
        if (Model == null) return new List<Face>();
        long s = ModelSignature();
        if (_faces == null || s != _facesSig) { _faces = MemberSolids.Build(Model, true); _facesSig = s; }
        return _faces;
    }

    private bool MemberHidden(int id, StructureInfo info) =>
        HiddenMembers.Contains(id) || (HiddenLevels.Count > 0 && info.MemberLevel.TryGetValue(id, out int lv) && HiddenLevels.Contains(lv));

    private bool NodeHidden(int id, StructureInfo info) =>
        HiddenNodes.Contains(id) || AutoNodeHidden(id) || (HiddenLevels.Count > 0 && info.NodeLevel.TryGetValue(id, out int lv) && HiddenLevels.Contains(lv));

    // ------------------------------------------------------------------ caméra
    private void UpdateFocusDepth() => _focusD = V3(_focus.X, _focus.Y, _focus.Z).D;

    private Vec3 ViewDir()
    {
        double cy = Math.Cos(_yaw), sy = Math.Sin(_yaw), cp = Math.Cos(_pitch), sp = Math.Sin(_pitch);
        return new Vec3(sy * cp, cy * cp, -sp);      // direction qui s'éloigne de l'observateur
    }

    private Vec3 CameraPos() => _focus - ViewDir() * _camDist;

    private Point Proj(Vec3 p, out double depth)
    {
        var v = V3(p.X, p.Y, p.Z);
        depth = v.D - _focusD;
        double k = 1;
        if (UsePersp)
        {
            double dc = _camDist + depth;
            k = dc > 0.08 * _camDist ? _camDist / dc : 12.5;
            depth = dc;
        }
        return new Point(_ox + v.U * k * _scale, _oy - v.V * k * _scale);
    }

    private Vec3? MemberCenter(int id)
    {
        if (Model == null) return null;
        var mem = Model.Members.FirstOrDefault(m => m.Id == id);
        if (mem == null) return null;
        var a = Model.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = Model.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        if (a == null || b == null) return null;
        return new Vec3((a.X + b.X) / 2, (a.Y + b.Y) / 2, (a.Z + b.Z) / 2);
    }

    private Vec3 ModelCenter()
    {
        var sb = SceneBounds(false);
        if (sb == null) return new Vec3(0, 0, 0);
        return new Vec3((sb.Value.Min.X + sb.Value.Max.X) / 2, (sb.Value.Min.Y + sb.Value.Max.Y) / 2, (sb.Value.Min.Z + sb.Value.Max.Z) / 2);
    }

    /// <summary>Centre de rotation de l'orbite : l'élément sélectionné (si l'option est active), sinon le centre du modèle.</summary>
    private Vec3 ComputePivot()
    {
        if (OrbitOnSelection && SelectedId >= 0) { var c = MemberCenter(SelectedId); if (c.HasValue) return c.Value; }
        return ModelCenter();
    }

    /// <summary>Tourne la vue autour du pivot, qui reste fixe à l'écran.</summary>
    private void OrbitBy(double dyaw, double dpitch)
    {
        _faceView = false;
        if (Mode != ViewMode.Iso)
        {
            Mode = ViewMode.Iso;
            Hint?.Invoke("Vue 3D libre : cliquez pour dessiner (accrochage aux nœuds, niveaux et axes).");
        }
        UpdateFocusDepth();
        var before = S(_pivot.X, _pivot.Y, _pivot.Z);
        _yaw += dyaw;
        _pitch = Math.Max(-1.55, Math.Min(1.55, _pitch + dpitch));
        UpdateFocusDepth();
        var after = S(_pivot.X, _pivot.Y, _pivot.Z);
        _ox += before.X - after.X; _oy += before.Y - after.Y;
    }

    private void OnMidDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Middle) return;
        if (e.ClickCount == 2) { ZoomExtents(); return; }
        _last = e.GetPosition(_c);
        if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0) _midPanning = true;
        else { _orbiting = true; _pivot = ComputePivot(); }
        _c.CaptureMouse();
    }

    private void OnMidUp(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Middle) return;
        _orbiting = false; _midPanning = false;
        _c.ReleaseMouseCapture();
    }

    private static (Vec3 Min, Vec3 Max) BoundsOf(IEnumerable<Vec3> pts)
    {
        double x0 = double.MaxValue, y0 = double.MaxValue, z0 = double.MaxValue, x1 = double.MinValue, y1 = double.MinValue, z1 = double.MinValue;
        foreach (var p in pts)
        {
            x0 = Math.Min(x0, p.X); y0 = Math.Min(y0, p.Y); z0 = Math.Min(z0, p.Z);
            x1 = Math.Max(x1, p.X); y1 = Math.Max(y1, p.Y); z1 = Math.Max(z1, p.Z);
        }
        return (new Vec3(x0, y0, z0), new Vec3(x1, y1, z1));
    }

    /// <summary>Cadre les points dans la fenêtre (marge en pixels de chaque côté).</summary>
    private void FitScreen(List<Vec3> pts, double marginPx)
    {
        if (pts.Count == 0 || _c.ActualWidth < 10 || _c.ActualHeight < 10) { Redraw(); return; }
        var (mn, mx) = BoundsOf(pts);
        _focus = new Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        UpdateFocusDepth();
        _scale = 1; _ox = 0; _oy = 0;
        double x0 = double.MaxValue, x1 = double.MinValue, y0 = double.MaxValue, y1 = double.MinValue;
        foreach (var p in pts)
        {
            var s = S(p.X, p.Y, p.Z);
            x0 = Math.Min(x0, s.X); x1 = Math.Max(x1, s.X); y0 = Math.Min(y0, s.Y); y1 = Math.Max(y1, s.Y);
        }
        double bw = Math.Max(x1 - x0, 1e-6), bh = Math.Max(y1 - y0, 1e-6);
        double availW = Math.Max(_c.ActualWidth - 2 * marginPx, 60), availH = Math.Max(_c.ActualHeight - 2 * marginPx, 60);
        _scale = Math.Max(0.2, Math.Min(Math.Min(availW / bw, availH / bh), 400));
        _ox = _c.ActualWidth / 2 - (x0 + x1) / 2 * _scale;
        _oy = _c.ActualHeight / 2 - (y0 + y1) / 2 * _scale;
        Redraw();
    }

    /// <summary>Zoom sur l'élément sélectionné ; il devient aussi le centre d'orbite.</summary>
    public void ZoomSelection()
    {
        if (Model == null) return;
        if (_selNodes.Count > 0 || _selKeys.Count > 0) { ZoomAllSelected(); return; }
        var ids = _sel.Count > 0 ? new HashSet<int>(_sel) : new HashSet<int>();
        if (ids.Count == 0) { ZoomExtents(); return; }
        var pts = new List<Vec3>();
        double rMax = 0.3;
        foreach (var mem in Model.Members.Where(m => ids.Contains(m.Id)))
        {
            var a = Model.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = Model.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
            if (a == null || b == null) continue;
            double r = Math.Max(Math.Max(mem.B, mem.H), 0.3) * 0.75 + 0.25;
            rMax = Math.Max(rMax, r);
            foreach (var n in new[] { a, b })
                foreach (double dx in new[] { -r, r }) foreach (double dy in new[] { -r, r }) foreach (double dz in new[] { -r, r })
                    pts.Add(new Vec3(n.X + dx, n.Y + dy, n.Z + dz));
        }
        if (pts.Count == 0) { ZoomExtents(); return; }
        var (mn, mx) = BoundsOf(pts);
        _pivot = new Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, ids.Count == 1 ? Math.Min(_c.ActualWidth, _c.ActualHeight) * 0.2 : 70);
    }

    /// <summary>Zoom sur un niveau (tous les nœuds de ce niveau).</summary>
    public void ZoomToLevel(int levelIndex)
    {
        var info = GetInfo();
        if (Model == null || levelIndex < 0 || levelIndex >= info.Levels.Count) return;
        var pts = new List<Vec3>();
        foreach (int id in info.Levels[levelIndex].NodeIds)
        {
            var n = Model.Nodes.FirstOrDefault(x => x.Id == id);
            if (n == null) continue;
            foreach (double dz in new[] { -0.6, 0.6 }) { pts.Add(new Vec3(n.X - 0.4, n.Y - 0.4, n.Z + dz)); pts.Add(new Vec3(n.X + 0.4, n.Y + 0.4, n.Z + dz)); }
        }
        if (pts.Count == 0) return;
        var (mn, mx) = BoundsOf(pts);
        _pivot = new Vec3((mn.X + mx.X) / 2, (mn.Y + mx.Y) / 2, (mn.Z + mx.Z) / 2);
        FitScreen(pts, 70);
    }

    private string DescribeHover(int id)
    {
        if (Model == null || id < 0) return "";
        var info = GetInfo();
        var mem = Model.Members.FirstOrDefault(m => m.Id == id);
        if (mem == null) return "";
        var na = Model.Nodes.FirstOrDefault(n => n.Id == mem.NodeI);
        string axes = na == null ? "" : info.AxisRef(na.X, na.Y);
        string lv = info.LevelOfMember(id)?.Name ?? "";
        return $"{StructureAnalyzer.MemberTitle(Model, id, Output)}  ·  {lv}" + (axes != "" ? $"  ·  axes {axes}" : "")
               + $"  ·  L = {StructureAnalyzer.MemberLength(Model, mem):0.00} m"
               + (ResultHint(id) is { Length: > 0 } rh ? "  ·  " + rh : "");
    }

    // ------------------------------------------------------------------ pinceaux et crayons (cache)
    private readonly Dictionary<int, SolidColorBrush> _brushes = new();
    private readonly Dictionary<long, Pen> _pens = new();

    private SolidColorBrush BrushOf(Color c)
    {
        int key = (c.A << 24) | (c.R << 16) | (c.G << 8) | c.B;
        if (!_brushes.TryGetValue(key, out var b))
        {
            if (_brushes.Count > 4000) _brushes.Clear();
            b = new SolidColorBrush(c); b.Freeze(); _brushes[key] = b;
        }
        return b;
    }

    private Pen PenOf(Color c, double th)
    {
        long key = ((long)((c.A << 24) | (c.R << 16) | (c.G << 8) | c.B) << 16) | (long)(th * 10);
        if (!_pens.TryGetValue(key, out var p))
        {
            if (_pens.Count > 2000) _pens.Clear();
            p = new Pen(BrushOf(c), th) { LineJoin = PenLineJoin.Round, StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
            p.Freeze(); _pens[key] = p;
        }
        return p;
    }

    private static Color Mix(Color a, Color b, double t) =>
        Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));

    private static byte Cl(double v) => (byte)Math.Max(0, Math.Min(255, v));

    private static readonly Vec3 Sun = new Vec3(0.5, -0.4, 0.77).Unit();

    private static Color Shade(Color c, Vec3 n)
    {
        double lam = Math.Max(0, n.Dot(Sun));
        double k = 0.40 + 0.52 * lam + 0.10 * (0.5 + 0.5 * n.Z);
        return Color.FromRgb(Cl(c.R * k), Cl(c.G * k), Cl(c.B * (k + 0.03)));
    }

    private Color BaseColor(Member mem, Dictionary<int, MemberDesignResult> res)
    {
        Color mat = ElementPalette.Get(ElementPalette.KeyOf(mem));            // couleur d'origine ou choisie (menu Options > Couleurs des éléments)
        if (ElementPalette.ByResult && res.TryGetValue(mem.Id, out var r))
        {
            Color st = r.Skipped ? Color.FromRgb(0xBD, 0xBD, 0xBD) : r.Ok ? Color.FromRgb(0x66, 0xBB, 0x6A) : Color.FromRgb(0xE5, 0x73, 0x73);
            if (RenderStyle == DisplayStyle.Ombre || RenderStyle == DisplayStyle.RayonsX) return st;
            if (!r.Skipped && !r.Ok) return Mix(mat, Color.FromRgb(0xD3, 0x2F, 0x2F), 0.45);
        }
        return mat;
    }

    private sealed class VisualHost : FrameworkElement
    {
        private readonly DrawingVisual _v;
        public VisualHost(DrawingVisual v) { _v = v; AddVisualChild(v); IsHitTestVisible = false; }
        protected override int VisualChildrenCount => 1;
        protected override Visual GetVisualChild(int index) => _v;
    }

    private sealed class DrawItem
    {
        public Face F = null!;
        public Point[] Pts = Array.Empty<Point>();
        public double Depth;
    }

    private readonly List<(int Id, Point[] Pts, double Depth)> _pick = new();

    // ------------------------------------------------------------------ scène
    private void DrawScene(Dictionary<int, Node> nodes, StructureInfo info)
    {
        _pick.Clear();
        double w = Math.Max(_c.ActualWidth, 10), h = Math.Max(_c.ActualHeight, 10);
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen())
        {
            if (RenderStyle == DisplayStyle.Realiste) DrawSky(dc, w, h);
            DrawUnderlays(dc);
            if (!info.IsEmpty)
            {
                if (RenderStyle == DisplayStyle.Realiste) DrawGround(dc, info);
                if (ShowGrid) DrawGridLines(dc, info);
            }
            DrawFootings(dc, info);                       // semelles dimensionnées : sous les barres
            if (RenderStyle != DisplayStyle.Fil) DrawFaces(dc, info);
            if (ShowDeformed) DrawDeformed(dc, info);
            if (RenderStyle == DisplayStyle.Ferraille) DrawRebar(dc, info);
        }
        _c.Children.Add(new VisualHost(dv));
    }

    private static readonly Brush SkyBrush = MakeSky();
    private static Brush MakeSky()
    {
        var g = new LinearGradientBrush(Color.FromRgb(0xB9, 0xD5, 0xEC), Color.FromRgb(0xF3, 0xF6, 0xFA), 90);
        g.Freeze();
        return g;
    }

    private void DrawSky(DrawingContext dc, double w, double h) => dc.DrawRectangle(SkyBrush, null, new Rect(0, 0, w, h));

    private static List<(double X, double Y)> Hull(List<(double X, double Y)> pts)
    {
        var p = pts.OrderBy(q => q.X).ThenBy(q => q.Y).ToList();
        if (p.Count < 3) return p;
        double Cross((double X, double Y) o, (double X, double Y) a, (double X, double Y) b) => (a.X - o.X) * (b.Y - o.Y) - (a.Y - o.Y) * (b.X - o.X);
        var lower = new List<(double X, double Y)>();
        foreach (var q in p) { while (lower.Count >= 2 && Cross(lower[^2], lower[^1], q) <= 0) lower.RemoveAt(lower.Count - 1); lower.Add(q); }
        var upper = new List<(double X, double Y)>();
        for (int i = p.Count - 1; i >= 0; i--) { var q = p[i]; while (upper.Count >= 2 && Cross(upper[^2], upper[^1], q) <= 0) upper.RemoveAt(upper.Count - 1); upper.Add(q); }
        lower.RemoveAt(lower.Count - 1); upper.RemoveAt(upper.Count - 1);
        lower.AddRange(upper);
        return lower;
    }

    private void DrawGround(DrawingContext dc, StructureInfo info)
    {
        double span = Math.Max(Math.Max(info.MaxX - info.MinX, info.MaxY - info.MinY), 4);
        double m = Math.Max(3, 0.35 * span), zg = info.MinZ - 0.002;
        var corners = new[] { new Vec3(info.MinX - m, info.MinY - m, zg), new Vec3(info.MaxX + m, info.MinY - m, zg), new Vec3(info.MaxX + m, info.MaxY + m, zg), new Vec3(info.MinX - m, info.MaxY + m, zg) };
        var pts = new Point[4];
        for (int i = 0; i < 4; i++) pts[i] = Proj(corners[i], out _);
        dc.DrawGeometry(BrushOf(Color.FromRgb(0xD8, 0xE1, 0xE6)), PenOf(Color.FromRgb(0xB5, 0xC2, 0xCB), 1), Geo(pts));
        // maillage léger du sol (tous les 1 m environ, 2 m si le terrain est grand)
        double step = span > 30 ? 5 : span > 12 ? 2 : 1;
        var gp = PenOf(Color.FromArgb(70, 0x90, 0xA4, 0xAE), 0.6);
        for (double x = Math.Ceiling((info.MinX - m) / step) * step; x <= info.MaxX + m; x += step)
            dc.DrawLine(gp, Proj(new Vec3(x, info.MinY - m, zg), out _), Proj(new Vec3(x, info.MaxY + m, zg), out _));
        for (double y = Math.Ceiling((info.MinY - m) / step) * step; y <= info.MaxY + m; y += step)
            dc.DrawLine(gp, Proj(new Vec3(info.MinX - m, y, zg), out _), Proj(new Vec3(info.MaxX + m, y, zg), out _));

        if (!ShowShadows || Model == null) return;
        var sun = Sun;
        var byMember = new Dictionary<int, List<(double X, double Y)>>();
        foreach (var f in GetFaces())
        {
            if (!f.Cap || MemberHidden(f.MemberId, info)) continue;
            if (!byMember.TryGetValue(f.MemberId, out var list)) { list = new List<(double, double)>(); byMember[f.MemberId] = list; }
            foreach (var p in f.P)
            {
                double t = (p.Z - zg) / sun.Z;
                list.Add((p.X - sun.X * t, p.Y - sun.Y * t));
            }
        }
        var group = new GeometryGroup { FillRule = FillRule.Nonzero };
        foreach (var list in byMember.Values)
        {
            var hull = Hull(list);
            if (hull.Count < 3) continue;
            var sp = hull.Select(q => Proj(new Vec3(q.X, q.Y, zg), out _)).ToArray();
            group.Children.Add(Geo(sp));
        }
        group.Freeze();
        dc.DrawGeometry(BrushOf(Color.FromArgb(60, 0, 0, 0)), null, group);
    }

    private static StreamGeometry Geo(Point[] pts)
    {
        var g = new StreamGeometry();
        using (var ctx = g.Open())
        {
            ctx.BeginFigure(pts[0], true, true);
            if (pts.Length > 1)
            {
                var rest = new Point[pts.Length - 1];
                Array.Copy(pts, 1, rest, 0, rest.Length);
                ctx.PolyLineTo(rest, true, false);
            }
        }
        g.Freeze();
        return g;
    }

    // ---- axes (grid lines) et niveaux
    private static readonly Color GridRedC = Color.FromRgb(0xB0, 0x3A, 0x2E);
    private static readonly Color HiC = Color.FromRgb(0xFB, 0x8C, 0x00);
    private static readonly Color LevelC = Color.FromRgb(0x00, 0x89, 0x7B);

    private List<(GridAxis Ax, Vec3 A, Vec3 B, bool Both)> GridSegments(StructureInfo info)
    {
        var res = new List<(GridAxis Ax, Vec3 A, Vec3 B, bool Both)>();
        double ext = Math.Max(1.5, 0.15 * Math.Max(info.MaxX - info.MinX, info.MaxY - info.MinY));
        double z0 = info.MinZ;
        switch (Mode)
        {
            case ViewMode.Elevation:
                foreach (var ax in info.XAxes) res.Add((ax, new Vec3(ax.Pos, info.MinY, z0 - 0.4), new Vec3(ax.Pos, info.MinY, info.MaxZ + 1.2), false));
                break;
            case ViewMode.Side:
                foreach (var ax in info.YAxes) res.Add((ax, new Vec3(info.MinX, ax.Pos, z0 - 0.4), new Vec3(info.MinX, ax.Pos, info.MaxZ + 1.2), false));
                break;
            default:
                foreach (var ax in info.XAxes) res.Add((ax, new Vec3(ax.Pos, info.MinY - ext, z0), new Vec3(ax.Pos, info.MaxY + ext, z0), true));
                foreach (var ax in info.YAxes) res.Add((ax, new Vec3(info.MinX - ext, ax.Pos, z0), new Vec3(info.MaxX + ext, ax.Pos, z0), true));
                break;
        }
        return res;
    }

    private void DrawGridLines(DrawingContext dc, StructureInfo info)
    {
        var dash = new DashStyle(new double[] { 9, 2.5, 1.5, 2.5 }, 0);
        foreach (var (ax, a, b, _) in GridSegments(info))
        {
            bool hi = ax.Name == HighlightAxis;
            var pen = new Pen(BrushOf(hi ? HiC : Color.FromArgb(200, GridRedC.R, GridRedC.G, GridRedC.B)), hi ? 2.4 : 1.0) { DashStyle = dash };
            dc.DrawLine(pen, Proj(a, out _), Proj(b, out _));
        }
    }

    private void BubbleAt(Point c, string label, bool hi)
    {
        var col = BrushOf(hi ? HiC : GridRedC);
        var e = new Ellipse { Width = 22, Height = 22, Stroke = col, StrokeThickness = hi ? 2.2 : 1.2, Fill = Brushes.White, IsHitTestVisible = false };
        Canvas.SetLeft(e, c.X - 11); Canvas.SetTop(e, c.Y - 11);
        _c.Children.Add(e);
        bool two = label.Length > 1;
        var t = new TextBlock { Text = label, Width = 22, TextAlignment = TextAlignment.Center, FontSize = two ? 9 : 11, FontWeight = FontWeights.SemiBold, Foreground = col, IsHitTestVisible = false };
        Canvas.SetLeft(t, c.X - 11); Canvas.SetTop(t, c.Y - (two ? 7 : 8));
        _c.Children.Add(t);
    }

    private void DrawGridBubbles(StructureInfo info)
    {
        if (!ShowGrid || info.IsEmpty) return;
        foreach (var (ax, a, b, both) in GridSegments(info))
        {
            bool hi = ax.Name == HighlightAxis;
            Point pa = S(a.X, a.Y, a.Z), pb = S(b.X, b.Y, b.Z);
            double dx = pb.X - pa.X, dy = pb.Y - pa.Y, len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 1e-6) { dx = 0; dy = -1; len = 1; }
            dx /= len; dy /= len;
            BubbleAt(new Point(pb.X + dx * 14, pb.Y + dy * 14), ax.Name, hi);
            if (both) BubbleAt(new Point(pa.X - dx * 14, pa.Y - dy * 14), ax.Name, hi);
        }
    }

    private void DashLn(double x1, double y1, double x2, double y2, Brush b, double th)
    {
        _c.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, Stroke = b, StrokeThickness = th, StrokeDashArray = new DoubleCollection { 6, 3 }, IsHitTestVisible = false });
    }

    private void DrawLevelTags(StructureInfo info)
    {
        if (!ShowLevels || info.IsEmpty || info.Levels.Count == 0 || Mode == ViewMode.Plan) return;
        double ext = Math.Max(1.2, 0.12 * Math.Max(info.MaxX - info.MinX, info.MaxY - info.MinY));
        foreach (var lv in info.Levels)
        {
            if (HiddenLevels.Contains(lv.Index)) continue;
            bool hi = lv.Index == HighlightLevel;
            var br = BrushOf(hi ? HiC : LevelC);
            double th = hi ? 2.2 : 1.0;
            string label = $"{lv.Name}  {(lv.Z >= 0 ? "+" : "")}{lv.Z:0.00}";
            if (Mode == ViewMode.Elevation || Mode == ViewMode.Side)
            {
                bool elev = Mode == ViewMode.Elevation;
                Vec3 a = elev ? new Vec3(info.MinX - ext, info.MinY, lv.Z) : new Vec3(info.MinX, info.MinY - ext, lv.Z);
                Vec3 b = elev ? new Vec3(info.MaxX + ext, info.MinY, lv.Z) : new Vec3(info.MinX, info.MaxY + ext, lv.Z);
                Point pa = S(a.X, a.Y, a.Z), pb = S(b.X, b.Y, b.Z);
                DashLn(pa.X, pa.Y, pb.X, pb.Y, br, th);
                Text(label, Math.Min(pa.X, pb.X) + 4, pa.Y - 15, 10, hi ? Br("#E65100") : Br("#00695C"), Br("#CCFFFFFF"), true);
            }
            else
            {
                double m = ext * 0.6;
                var corners = new[]
                {
                    new Vec3(info.MinX - m, info.MinY - m, lv.Z), new Vec3(info.MaxX + m, info.MinY - m, lv.Z),
                    new Vec3(info.MaxX + m, info.MaxY + m, lv.Z), new Vec3(info.MinX - m, info.MaxY + m, lv.Z)
                };
                var ps = corners.Select(c => S(c.X, c.Y, c.Z)).ToArray();
                for (int i = 0; i < 4; i++) DashLn(ps[i].X, ps[i].Y, ps[(i + 1) % 4].X, ps[(i + 1) % 4].Y, br, th);
                Text(label, ps[0].X + 4, ps[0].Y - 15, 10, hi ? Br("#E65100") : Br("#00695C"), Br("#CCFFFFFF"), true);
            }
        }
    }

    // ---- solides
    private void DrawFaces(DrawingContext dc, StructureInfo info)
    {
        if (Model == null) return;
        var faces = GetFaces();
        var results = new Dictionary<int, MemberDesignResult>();
        if (Output != null) foreach (var r in Output.Members) results[r.MemberId] = r;
        var mems = new Dictionary<int, Member>();
        foreach (var m in Model.Members) mems[m.Id] = m;

        bool persp = UsePersp;
        var g = ViewDir();
        var cam = CameraPos();
        double near = 0.08 * _camDist;
        bool cull = Solid;
        var items = new List<DrawItem>(faces.Count / 2 + 8);
        foreach (var f in faces)
        {
            if (MemberHidden(f.MemberId, info)) continue;
            bool front = persp ? f.N.Dot(f.P[0] - cam) < 0 : f.N.Dot(g) < 0;
            if (cull && !front) continue;
            var pts = new Point[f.P.Length];
            double dsum = 0; bool bad = false;
            for (int i = 0; i < pts.Length; i++)
            {
                pts[i] = Proj(f.P[i], out double d);
                dsum += d;
                if (persp && d < near) { bad = true; break; }
            }
            if (bad) continue;
            items.Add(new DrawItem { F = f, Pts = pts, Depth = dsum / pts.Length });
        }
        if (cull) items.Sort((a, b) => b.Depth.CompareTo(a.Depth));        // algorithme du peintre : du plus loin au plus proche

        foreach (var it in items)
        {
            var f = it.F;
            if (!mems.TryGetValue(f.MemberId, out var mem)) continue;
            Color baseC = BaseColor(mem, results);
            if (RenderStyle == DisplayStyle.Trait)
            {
                DrawEdges(dc, it, PenOf(Mix(baseC, Color.FromRgb(0x10, 0x20, 0x30), 0.35), 1.1));
                continue;
            }
            Brush fill; Pen? seam; Pen edge;
            switch (RenderStyle)
            {
                case DisplayStyle.Cache:
                    fill = BrushOf(Colors.White); seam = PenOf(Colors.White, 0.8); edge = PenOf(Color.FromRgb(0x10, 0x10, 0x10), 1.0); break;
                case DisplayStyle.Ferraille:
                    fill = BrushOf(Color.FromArgb(26, 0x90, 0xA4, 0xAE)); seam = null; edge = PenOf(Color.FromArgb(150, 0x60, 0x70, 0x78), 0.8); break;
                case DisplayStyle.RayonsX:
                    fill = BrushOf(Color.FromArgb(46, baseC.R, baseC.G, baseC.B)); seam = null; edge = PenOf(Mix(baseC, Color.FromRgb(0x10, 0x20, 0x30), 0.5), 0.9); break;
                default:
                {
                    var c = Shade(baseC, f.N);
                    fill = BrushOf(c); seam = PenOf(c, 0.8);
                    edge = PenOf(Color.FromArgb(RenderStyle == DisplayStyle.Realiste ? (byte)150 : (byte)190, 0x20, 0x28, 0x30), 0.7);
                    break;
                }
            }
            dc.DrawGeometry(fill, seam, Geo(it.Pts));
            DrawEdges(dc, it, edge);
            if (Solid) _pick.Add((f.MemberId, it.Pts, it.Depth));
        }

        // sélection et survol : par-dessus tout
        var selFill = BrushOf(Color.FromArgb(70, 0x00, 0xB8, 0xFF));
        var selPen = PenOf(Color.FromRgb(0x00, 0xB8, 0xFF), 2.6);
        var hovPen = PenOf(Color.FromRgb(0xFF, 0xB3, 0x00), 1.8);
        foreach (var it in items)
        {
            if (IsSelected(it.F.MemberId))
            {
                if (it.F.Cap || Solid || RenderStyle == DisplayStyle.RayonsX || RenderStyle == DisplayStyle.Ferraille) dc.DrawGeometry(selFill, null, Geo(it.Pts));
                DrawEdges(dc, it, selPen);
            }
            else if (it.F.MemberId == _hoverId) DrawEdges(dc, it, hovPen);
        }
    }

    private static void DrawEdges(DrawingContext dc, DrawItem it, Pen pen)
    {
        int n = it.Pts.Length, mask = it.F.EdgeMask;
        for (int i = 0; i < n; i++)
            if ((mask & (1 << i)) != 0) dc.DrawLine(pen, it.Pts[i], it.Pts[(i + 1) % n]);
    }

    // ---- sélection à la souris sur les solides
    private static bool InPoly(Point p, Point[] poly)
    {
        bool inside = false;
        for (int i = 0, j = poly.Length - 1; i < poly.Length; j = i++)
        {
            if ((poly[i].Y > p.Y) != (poly[j].Y > p.Y) &&
                p.X < (poly[j].X - poly[i].X) * (p.Y - poly[i].Y) / (poly[j].Y - poly[i].Y) + poly[i].X)
                inside = !inside;
        }
        return inside;
    }

    private int HitFaces(Point p)
    {
        int best = -1; double bd = double.MaxValue;
        foreach (var (id, pts, depth) in _pick)
        {
            if (depth >= bd) continue;
            if (InPoly(p, pts)) { bd = depth; best = id; }
        }
        return best;
    }
}
