using System.IO;
using Microsoft.Win32;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using StructCalc.Core;

namespace StructCalc.UI;

/// <summary>Préférences de l'utilisateur (enregistrées dans %APPDATA%\StructCalc\options.json).</summary>
public sealed class AppOptions
{
    public int AutoSaveMinutes { get; set; } = 2;
    public bool ConfirmOnClose { get; set; } = true;
    public string Accent { get; set; } = "#1F4E79";
    /// <summary>Fond de la vue de travail ; vide = automatique selon le thème clair / sombre.</summary>
    public string ViewBack { get; set; } = "";
    public string ColorOk { get; set; } = "#2E7D32";
    public string ColorKo { get; set; } = "#C62828";
    public string ColorBar { get; set; } = "#1F4E79";
    /// <summary>Logo (PNG, JPG...) et nom de l'entreprise imprimés en tête de la note de calcul PDF.</summary>
    public string LogoPath { get; set; } = "";
    public string CompanyName { get; set; } = "";
    public Dictionary<string, string> Shortcuts { get; set; } = new();
    /// <summary>Couleurs modifiées des éléments (poteaux, poutres, dalles, semelles...) ; une famille absente garde sa couleur d'origine.</summary>
    public Dictionary<string, string> ElementColors { get; set; } = new();
    /// <summary>Colorer les barres selon le résultat du calcul (vert / rouge) quand il existe.</summary>
    public bool ColorByResult { get; set; } = true;

    public static AppOptions Current { get; private set; } = Load();

    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppInfo.Name, "options.json");

    private static AppOptions Load()
    {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<AppOptions>(File.ReadAllText(FilePath)) ?? new AppOptions(); }
        catch { }
        return new AppOptions();
    }

    public static void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(Current, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    public static void Reset() { Current = new AppOptions(); Save(); }

    public static bool TryColor(string? hex, out Color c)
    {
        c = Colors.Transparent;
        if (string.IsNullOrWhiteSpace(hex)) return false;
        try { c = (Color)ColorConverter.ConvertFromString(hex.Trim())!; return true; } catch { return false; }
    }
}

/// <summary>Une commande à laquelle on peut affecter un raccourci clavier.</summary>
public sealed class ShortcutAction
{
    public string Id { get; init; } = "";
    public string Group { get; init; } = "";
    public string Label { get; init; } = "";
    public string Default { get; init; } = "";
    /// <summary>Vrai si le raccourci d'origine est géré en dur dans la fenêtre principale (il est neutralisé quand l'utilisateur en choisit un autre).</summary>
    public bool Builtin { get; init; }
    public Action Run { get; init; } = () => { };
    public string Current => AppOptions.Current.Shortcuts.TryGetValue(Id, out var g) ? g : Default;
    public bool Modified => Current != Default;
    // colonnes de la liste
    public string Gesture => string.IsNullOrEmpty(Current) ? "(aucun)" : Current;
    public string DefaultText => string.IsNullOrEmpty(Default) ? "-" : Default;

    public static string Format(Key key, ModifierKeys mods)
    {
        var parts = new List<string>();
        if ((mods & ModifierKeys.Control) != 0) parts.Add("Ctrl");
        if ((mods & ModifierKeys.Alt) != 0) parts.Add("Alt");
        if ((mods & ModifierKeys.Shift) != 0) parts.Add("Maj");
        parts.Add(key.ToString());
        return string.Join("+", parts);
    }

    public static bool IsModifierKey(Key k) =>
        k is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin or Key.System or Key.None or Key.DeadCharProcessed or Key.ImeProcessed;
}

/// <summary>Fenêtre « Options » : interface, espace de travail (couleurs), raccourcis clavier, général.</summary>
public sealed class OptionsWindow : Window
{
    private readonly IList<ShortcutAction> _acts;
    private readonly Action<bool, double> _apply;
    private readonly double[] _scales;
    private readonly CheckBox _dark = new() { Content = "Mode sombre", Margin = new Thickness(0, 4, 0, 4) };
    private readonly CheckBox _confirm = new() { Content = "Proposer d'enregistrer avant de quitter si le projet a été modifié", Margin = new Thickness(0, 4, 0, 4) };
    private readonly ComboBox _scale = new() { Width = 110, HorizontalAlignment = HorizontalAlignment.Left };
    private readonly TextBox _accent = new() { Width = 90 }, _back = new() { Width = 90 }, _ok = new() { Width = 90 }, _ko = new() { Width = 90 }, _bar = new() { Width = 90 };
    private readonly TextBox _auto = new() { Width = 50 };
    private readonly TextBox _company = new() { Width = 300 }, _logo = new() { Width = 300 };
    private readonly ListView _list = new() { MinHeight = 260 };
    private readonly TextBox _capture = new() { IsReadOnly = true, Width = 190, Text = "" };
    private readonly TabControl _tabs = new() { Margin = new Thickness(8) };
    private string _pending = "";

    public OptionsWindow(Window owner, IList<ShortcutAction> actions, double[] scales, double currentScale, bool dark, Action<bool, double> apply, int tab)
    {
        Owner = owner; _acts = actions; _apply = apply; _scales = scales;
        Title = "Options - " + AppInfo.Name;
        Width = 720; Height = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var o = AppOptions.Current;
        _dark.IsChecked = dark; _confirm.IsChecked = o.ConfirmOnClose;
        foreach (var s in scales) _scale.Items.Add($"{s * 100:0} %");
        _scale.SelectedIndex = Math.Max(0, Array.IndexOf(scales, scales.OrderBy(x => Math.Abs(x - currentScale)).First()));
        _accent.Text = o.Accent; _back.Text = o.ViewBack; _ok.Text = o.ColorOk; _ko.Text = o.ColorKo; _bar.Text = o.ColorBar;
        _auto.Text = o.AutoSaveMinutes.ToString();
        _company.Text = o.CompanyName; _logo.Text = o.LogoPath;

        _tabs.Items.Add(new TabItem { Header = "Interface", Content = BuildInterface() });
        _tabs.Items.Add(new TabItem { Header = "Espace de travail", Content = BuildWorkspace() });
        _tabs.Items.Add(new TabItem { Header = "Raccourcis clavier", Content = BuildShortcuts() });
        _tabs.Items.Add(new TabItem { Header = "Général", Content = BuildGeneral() });
        _tabs.SelectedIndex = Math.Clamp(tab, 0, 3);

        var root = new DockPanel();
        var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(8) };
        btns.Children.Add(Btn("Valeurs par défaut", (s, e) => ResetAll()));
        btns.Children.Add(Btn("Appliquer", (s, e) => Commit()));
        var ok = Btn("OK", (s, e) => { Commit(); DialogResult = true; });
        ok.IsDefault = true;
        btns.Children.Add(ok);
        var cancel = Btn("Annuler", (s, e) => DialogResult = false);
        cancel.IsCancel = true;
        btns.Children.Add(cancel);
        DockPanel.SetDock(btns, Dock.Bottom);
        root.Children.Add(btns);
        root.Children.Add(_tabs);
        Content = root;
    }

    private static Button Btn(string text, RoutedEventHandler h)
    {
        var b = new Button { Content = text, Padding = new Thickness(14, 4, 14, 4), Margin = new Thickness(4, 0, 0, 0), MinWidth = 80 };
        b.Click += h;
        return b;
    }

    private static TextBlock Head(string t) => new() { Text = t, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 12, 0, 4) };

    /// <summary>Ligne « libellé + code couleur + pastilles prédéfinies ».</summary>
    private UIElement ColorRow(string label, TextBox tb, (string Name, string Hex)[] presets, string note = "")
    {
        var sp = new WrapPanel { Margin = new Thickness(0, 3, 0, 3) };
        sp.Children.Add(new TextBlock { Text = label, Width = 170, VerticalAlignment = VerticalAlignment.Center });
        sp.Children.Add(tb);
        var preview = new Border { Width = 26, Height = 20, Margin = new Thickness(6, 0, 8, 0), BorderBrush = Brushes.Gray, BorderThickness = new Thickness(1) };
        void Upd() => preview.Background = AppOptions.TryColor(tb.Text, out var c) ? Theme.Fixed(c) : Brushes.Transparent;
        tb.TextChanged += (s, e) => Upd();
        Upd();
        sp.Children.Add(preview);
        foreach (var (name, hex) in presets)
        {
            var b = new Button { Width = 22, Height = 20, Margin = new Thickness(1, 0, 1, 0), ToolTip = name, Padding = new Thickness(0) };
            if (AppOptions.TryColor(hex, out var c)) b.Background = Theme.Fixed(c);
            else { b.Content = "A"; b.ToolTip = name + " (automatique)"; }
            string h = hex;
            b.Click += (s, e) => tb.Text = h;
            sp.Children.Add(b);
        }
        if (note != "") sp.Children.Add(new TextBlock { Text = "  " + note, Foreground = Brushes.Gray, VerticalAlignment = VerticalAlignment.Center });
        return sp;
    }

    private UIElement BuildInterface()
    {
        var p = new StackPanel { Margin = new Thickness(14) };
        p.Children.Add(Head("Thème"));
        p.Children.Add(_dark);
        p.Children.Add(Head("Taille de l'interface"));
        p.Children.Add(_scale);
        p.Children.Add(Head("Couleur d'accentuation (barres de titre, boutons, sélection)"));
        p.Children.Add(ColorRow("Couleur :", _accent, new[]
        {
            ("Bleu StructCalc", "#1F4E79"), ("Bleu Revit", "#0B5CAD"), ("Vert Robot", "#2E7D32"), ("Gris AutoCAD", "#3C4A57"),
            ("Rouge brique", "#A63D2F"), ("Violet", "#5E35B1"), ("Orange", "#D2691E"), ("Turquoise", "#00796B")
        }));
        p.Children.Add(new TextBlock { Text = "Le code couleur est au format #RRGGBB.", Foreground = Brushes.Gray, Margin = new Thickness(0, 6, 0, 0) });
        return p;
    }

    private UIElement BuildWorkspace()
    {
        var p = new StackPanel { Margin = new Thickness(14) };
        p.Children.Add(Head("Fond de la vue de travail"));
        p.Children.Add(ColorRow("Fond :", _back, new[]
        {
            ("Automatique (selon le thème)", ""), ("Blanc", "#FFFFFF"), ("Gris très clair", "#F2F4F7"), ("Crème", "#FBF8EF"),
            ("Gris foncé (AutoCAD)", "#212830"), ("Noir", "#101214")
        }, "A = automatique"));
        p.Children.Add(new TextBlock { Text = "Les fonds foncés se combinent avec le mode sombre.", Foreground = Brushes.Gray, Margin = new Thickness(0, 2, 0, 0) });
        p.Children.Add(Head("Couleurs des barres dans la vue"));
        p.Children.Add(ColorRow("Barre conforme (OK) :", _ok, new[] { ("Vert", "#2E7D32"), ("Vert clair", "#43A047"), ("Bleu", "#1565C0"), ("Turquoise", "#00897B") }));
        p.Children.Add(ColorRow("Barre non conforme :", _ko, new[] { ("Rouge", "#C62828"), ("Magenta", "#C2185B"), ("Orange", "#E65100") }));
        p.Children.Add(ColorRow("Barre non calculée :", _bar, new[] { ("Bleu StructCalc", "#1F4E79"), ("Gris", "#546E7A"), ("Noir", "#212121"), ("Blanc", "#FAFAFA") }));
        return p;
    }

    private UIElement BuildGeneral()
    {
        var p = new StackPanel { Margin = new Thickness(14) };
        p.Children.Add(Head("Sauvegarde"));
        var r = new StackPanel { Orientation = Orientation.Horizontal };
        r.Children.Add(new TextBlock { Text = "Sauvegarde automatique toutes les ", VerticalAlignment = VerticalAlignment.Center });
        r.Children.Add(_auto);
        r.Children.Add(new TextBlock { Text = " minutes (0 = désactivée)", VerticalAlignment = VerticalAlignment.Center });
        p.Children.Add(r);
        p.Children.Add(_confirm);
        p.Children.Add(Head("Entreprise (en-tête de la note de calcul PDF)"));
        var rc = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        rc.Children.Add(new TextBlock { Text = "Nom :", Width = 50, VerticalAlignment = VerticalAlignment.Center }); rc.Children.Add(_company);
        p.Children.Add(rc);
        var rl = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
        rl.Children.Add(new TextBlock { Text = "Logo :", Width = 50, VerticalAlignment = VerticalAlignment.Center }); rl.Children.Add(_logo);
        var br = new Button { Content = "Parcourir...", Margin = new Thickness(6, 0, 0, 0), Padding = new Thickness(8, 1, 8, 1) };
        br.Click += (s, e) =>
        {
            var dlg = new OpenFileDialog { Filter = "Images (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp" };
            if (dlg.ShowDialog() == true) _logo.Text = dlg.FileName;
        };
        rl.Children.Add(br);
        p.Children.Add(rl);
        p.Children.Add(Head("Fichiers de configuration"));
        var open = new Button { Content = "Ouvrir le dossier de configuration", Padding = new Thickness(10, 3, 10, 3), HorizontalAlignment = HorizontalAlignment.Left };
        open.Click += (s, e) =>
        {
            try
            {
                string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppInfo.Name);
                Directory.CreateDirectory(d);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(d) { UseShellExecute = true });
            }
            catch { }
        };
        p.Children.Add(open);
        return p;
    }

    private UIElement BuildShortcuts()
    {
        var p = new DockPanel { Margin = new Thickness(10) };
        var top = new TextBlock
        {
            Text = "Choisissez une commande, cliquez dans la case, tapez la combinaison voulue (ex. Ctrl+Maj+S) puis « Affecter ». Retour arrière dans la case = aucun raccourci.",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 6)
        };
        DockPanel.SetDock(top, Dock.Top);
        p.Children.Add(top);

        var bar = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
        bar.Children.Add(new TextBlock { Text = "Nouveau raccourci :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
        _capture.PreviewKeyDown += CaptureKey;
        bar.Children.Add(_capture);
        bar.Children.Add(Btn("Affecter", (s, e) => Assign()));
        bar.Children.Add(Btn("Rétablir celui d'origine", (s, e) => RestoreOne()));
        DockPanel.SetDock(bar, Dock.Bottom);
        p.Children.Add(bar);

        var gv = new GridView();
        gv.Columns.Add(new GridViewColumn { Header = "Groupe", Width = 110, DisplayMemberBinding = new System.Windows.Data.Binding("Group") });
        gv.Columns.Add(new GridViewColumn { Header = "Commande", Width = 280, DisplayMemberBinding = new System.Windows.Data.Binding("Label") });
        gv.Columns.Add(new GridViewColumn { Header = "Raccourci", Width = 120, DisplayMemberBinding = new System.Windows.Data.Binding("Gesture") });
        gv.Columns.Add(new GridViewColumn { Header = "Origine", Width = 100, DisplayMemberBinding = new System.Windows.Data.Binding("DefaultText") });
        _list.View = gv;
        _list.ItemsSource = _acts;
        p.Children.Add(_list);
        return p;
    }

    private void CaptureKey(object sender, KeyEventArgs e)
    {
        e.Handled = true;
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        if (key == Key.Back) { _pending = ""; _capture.Text = "(aucun)"; return; }
        if (ShortcutAction.IsModifierKey(key)) return;
        _pending = ShortcutAction.Format(key, Keyboard.Modifiers);
        _capture.Text = _pending;
    }

    private void Assign()
    {
        if (_list.SelectedItem is not ShortcutAction a) { MessageBox.Show("Choisissez d'abord une commande dans la liste.", Title); return; }
        if (_capture.Text == "") { MessageBox.Show("Tapez d'abord la combinaison dans la case.", Title); return; }
        string g = _pending;
        if (g != "")
        {
            // une touche seule (sans Ctrl/Alt) gênerait la saisie dans les cellules : on l'accepte, elle est ignorée pendant la saisie de texte
            var other = _acts.FirstOrDefault(x => x != a && x.Current == g);
            if (other != null)
            {
                MessageBox.Show($"« {g} » est déjà utilisé par : {other.Label}.\nChoisissez une autre combinaison ou libérez d'abord celle-là.", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
        }
        if (g == a.Default) AppOptions.Current.Shortcuts.Remove(a.Id); else AppOptions.Current.Shortcuts[a.Id] = g;
        _list.Items.Refresh();
    }

    private void RestoreOne()
    {
        if (_list.SelectedItem is not ShortcutAction a) return;
        var other = _acts.FirstOrDefault(x => x != a && x.Current == a.Default && a.Default != "");
        if (other != null) { MessageBox.Show($"« {a.Default} » est maintenant utilisé par : {other.Label}.", Title, MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        AppOptions.Current.Shortcuts.Remove(a.Id);
        _list.Items.Refresh();
    }

    private void ResetAll()
    {
        if (MessageBox.Show("Rétablir toutes les options (couleurs, raccourcis, sauvegarde) aux valeurs d'origine ?", Title, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        AppOptions.Reset();
        var o = AppOptions.Current;
        _accent.Text = o.Accent; _back.Text = o.ViewBack; _ok.Text = o.ColorOk; _ko.Text = o.ColorKo; _bar.Text = o.ColorBar;
        _auto.Text = o.AutoSaveMinutes.ToString(); _confirm.IsChecked = o.ConfirmOnClose; _dark.IsChecked = false;
        _company.Text = ""; _logo.Text = "";
        _scale.SelectedIndex = Math.Max(0, Array.IndexOf(_scales, 1.0));
        _list.Items.Refresh();
    }

    private static string Fix(string text, string fallback) => string.IsNullOrWhiteSpace(text) ? fallback : (AppOptions.TryColor(text, out _) ? text.Trim() : fallback);

    private void Commit()
    {
        var o = AppOptions.Current;
        o.Accent = Fix(_accent.Text, "#1F4E79");
        o.ViewBack = string.IsNullOrWhiteSpace(_back.Text) ? "" : Fix(_back.Text, "");
        o.ColorOk = Fix(_ok.Text, "#2E7D32");
        o.ColorKo = Fix(_ko.Text, "#C62828");
        o.ColorBar = Fix(_bar.Text, "#1F4E79");
        o.AutoSaveMinutes = int.TryParse(_auto.Text, out var m) ? Math.Clamp(m, 0, 120) : 2;
        o.ConfirmOnClose = _confirm.IsChecked == true;
        o.CompanyName = _company.Text.Trim(); o.LogoPath = _logo.Text.Trim();
        AppOptions.Save();
        _apply(_dark.IsChecked == true, _scales[Math.Max(0, _scale.SelectedIndex)]);
    }
}
