using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Arborescence de la structure : niveaux (détectés automatiquement) → poteaux / poutres → éléments ; axes numérotés et lettrés ; appuis.
/// Un clic sur un élément le sélectionne dans la vue 3D ; chaque niveau a une case à cocher (visibilité), un menu contextuel (isoler, zoom, plan de travail)
/// et une fiche d'information en bas.</summary>
public sealed class StructurePanel : Grid
{
    private sealed record NodeTag(string Key, string Kind, int Id = -1, string Name = "");

    private readonly TreeView _tree = new() { BorderThickness = new Thickness(0), FontSize = 12, Background = Brushes.White };
    private readonly TextBlock _summary = new() { TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, FontSize = 11, Margin = new Thickness(8, 6, 8, 4) };
    private readonly TextBox _infoBox = new()
    {
        IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 11, TextWrapping = TextWrapping.Wrap,
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MinHeight = 110, MaxHeight = 230, BorderThickness = new Thickness(0, 1, 0, 0),
        Background = new SolidColorBrush(Color.FromRgb(0xF7, 0xF9, 0xFB)), Padding = new Thickness(8, 6, 8, 6)
    };

    private StructModel? _m;
    private AnalysisOutput? _o;
    private StructureInfo _struct = new();
    private readonly Dictionary<int, TreeViewItem> _memberItems = new();
    private bool _building, _suppress;
    private int _lastLevels = -1;

    /// <summary>Niveaux masqués (partagé avec la vue 3D).</summary>
    public HashSet<int> Hidden { get; } = new();
    public StructureInfo Structure => _struct;
    public double Tolerance { get; set; } = 0.05;

    public event Action<int>? MemberChosen;
    public event Action<int>? LevelChosen;
    public event Action<string>? AxisChosen;
    public event Action? VisibilityChanged;
    public event Action<int>? WorkPlaneRequested;
    /// <summary>Sélection groupée demandée (double-clic ou menu) : identifiants des barres + libellé.</summary>
    public event Action<List<int>, string>? GroupChosen;
    public event Action? AddLevelRequested;
    public event Action<int>? RenameLevelRequested;
    /// <summary>Modification de hauteur d'étage : indice du niveau, et true pour l'étage situé sous ce niveau.</summary>
    public event Action<int, bool>? LevelHeightRequested;
    /// <summary>Un nœud (ou un appui) est choisi dans l'arborescence.</summary>
    public event Action<int>? NodeChosen;
    public event Action<int>? NodeZoomRequested;
    /// <summary>Une dalle dessinée est choisie dans l'arborescence.</summary>
    public event Action<string>? SlabChosen;
    public event Action<string>? SlabZoomRequested;
    /// <summary>Remplit le menu contextuel d'un nœud / d'une dalle (construit par la fenêtre principale, comme pour le clic droit dans la vue).</summary>
    public Action<int, ContextMenu>? NodeMenuFiller { get; set; }
    public Action<string, ContextMenu>? SlabMenuFiller { get; set; }
    private readonly Dictionary<int, TreeViewItem> _nodeItems = new();
    private readonly Dictionary<string, TreeViewItem> _slabItems = new();
    /// <summary>Copie du contenu d'un niveau : niveau source, catégorie (all / columns / beams / slabs).</summary>
    public event Action<int, string>? CopyLevelRequested;

    public StructurePanel()
    {
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var head = new StackPanel();
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 6, 6, 0) };
        var showAll = new Button { Content = "👁 Tout afficher", Padding = new Thickness(8, 3, 8, 3), Margin = new Thickness(0, 0, 6, 0) };
        showAll.Click += (s, e) => ShowAllLevels();
        var expand = new Button { Content = "Tout déplier", Padding = new Thickness(8, 3, 8, 3), Margin = new Thickness(0, 0, 6, 0) };
        expand.Click += (s, e) => SetExpanded(_tree.Items, true);
        var collapse = new Button { Content = "Replier", Padding = new Thickness(8, 3, 8, 3) };
        collapse.Click += (s, e) => { SetExpanded(_tree.Items, false); foreach (TreeViewItem t in _tree.Items) t.IsExpanded = true; };
        bar.Children.Add(showAll); bar.Children.Add(expand); bar.Children.Add(collapse);
        head.Children.Add(bar);
        head.Children.Add(_summary);
        SetRow(head, 0); Children.Add(head);

        SetRow(_tree, 1); Children.Add(_tree);
        SetRow(_infoBox, 2); Children.Add(_infoBox);

        _tree.SelectedItemChanged += (s, e) => OnSelected();
        _tree.MouseDoubleClick += OnTreeDoubleClick;
        _infoBox.Text = "Cliquez sur un niveau, un axe ou un élément de l'arborescence.";
    }

    // ------------------------------------------------------------------ construction de l'arbre
    public void Refresh(StructModel m, AnalysisOutput? o)
    {
        _m = m; _o = o;
        var expanded = new HashSet<string>();
        CollectExpanded(_tree.Items, expanded);
        bool first = _lastLevels < 0;
        _struct = StructureAnalyzer.Analyze(m, Tolerance);
        if (_struct.Levels.Count != _lastLevels) { Hidden.Clear(); _lastLevels = _struct.Levels.Count; }
        var results = new Dictionary<int, MemberDesignResult>();
        if (o != null) foreach (var r in o.Members) results[r.MemberId] = r;

        _building = true;
        _tree.Items.Clear();
        _memberItems.Clear(); _nodeItems.Clear(); _slabItems.Clear();

        // ---- niveaux (du plus haut au plus bas, comme les élévations de Revit)
        var levels = new TreeViewItem { Header = $"Niveaux ({_struct.Levels.Count})", Tag = new NodeTag("levels", "root"), FontWeight = FontWeights.SemiBold, ContextMenu = RootMenu() };
        foreach (var lv in _struct.Levels.OrderByDescending(x => x.Index))
        {
            var chk = new CheckBox { IsChecked = !Hidden.Contains(lv.Index), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), ToolTip = "Afficher / masquer ce niveau dans la vue 3D" };
            int idx = lv.Index;
            chk.Checked += (s, e) => { if (!_building) { Hidden.Remove(idx); VisibilityChanged?.Invoke(); } };
            chk.Unchecked += (s, e) => { if (!_building) { Hidden.Add(idx); VisibilityChanged?.Invoke(); } };
            var head = new StackPanel { Orientation = Orientation.Horizontal };
            head.Children.Add(chk);
            head.Children.Add(new TextBlock { Text = lv.Label, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center });
            var item = new TreeViewItem { Header = head, Tag = new NodeTag("L" + idx, "level", idx), ContextMenu = LevelMenu(idx) };

            AddGroup(item, "L" + idx + "P", $"Poteaux ({lv.ColumnIds.Count})", lv.ColumnIds, results, idx, "columns");
            AddGroup(item, "L" + idx + "B", $"Poutres ({lv.BeamIds.Count})", lv.BeamIds, results, idx, "beams");
            var slabs = m.Slabs.Where(sl => sl.Placed && Math.Abs(sl.Z - lv.Z) < 0.05).ToList();
            if (slabs.Count > 0)
            {
                var gs = new TreeViewItem { Header = $"Dalles ({slabs.Count})   {slabs.Sum(x => x.Volume):0.0} m³", Tag = new NodeTag("L" + idx + "D", "group"), ContextMenu = GroupMenu(idx, "slabs") };
                foreach (var sl in slabs)
                {
                    var si = new TreeViewItem { Header = $"{sl.Name}   {sl.Lx:0.00} x {sl.Ly:0.00} m   h = {sl.H * 100:0} cm   V = {sl.Volume:0.0} m³", Tag = new NodeTag("D" + sl.Name, "slab", Name: sl.Name) };
                    string sn = sl.Name; si.ContextMenu = new ContextMenu();
                    si.ContextMenuOpening += (s, e) => { si.IsSelected = true; if (SlabMenuFiller == null) { e.Handled = true; return; } SlabMenuFiller(sn, si.ContextMenu!); };
                    _slabItems[sn] = si;
                    gs.Items.Add(si);
                }
                item.Items.Add(gs);
            }
            levels.Items.Add(item);
        }
        _tree.Items.Add(levels);

        // ---- axes
        var axes = new TreeViewItem { Header = $"Axes - grid lines ({_struct.XAxes.Count + _struct.YAxes.Count})", Tag = new NodeTag("axes", "root"), FontWeight = FontWeights.SemiBold };
        var ax = new TreeViewItem { Header = $"Axes numérotés ({_struct.XAxes.Count}) - x constant", Tag = new NodeTag("ax-x", "group") };
        foreach (var a in _struct.XAxes) ax.Items.Add(AxisItem(a.Name, a.Label + (a.SpacingToPrevious > 0 ? $"   (entraxe {a.SpacingToPrevious:0.00})" : "")));
        var ay = new TreeViewItem { Header = $"Axes lettrés ({_struct.YAxes.Count}) - y constant", Tag = new NodeTag("ax-y", "group") };
        foreach (var a in _struct.YAxes) ay.Items.Add(AxisItem(a.Name, a.Label + (a.SpacingToPrevious > 0 ? $"   (entraxe {a.SpacingToPrevious:0.00})" : "")));
        axes.Items.Add(ax); axes.Items.Add(ay);
        _tree.Items.Add(axes);

        // ---- appuis
        var sup = new TreeViewItem { Header = $"Appuis ({m.Supports.Count})", Tag = new NodeTag("supports", "root"), FontWeight = FontWeights.SemiBold };
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        foreach (var s in m.Supports)
        {
            string at = nodes.TryGetValue(s.NodeId, out var nd) ? _struct.AxisRef(nd.X, nd.Y) : "";
            string kind = s.Rx && s.Ry && s.Rz ? "encastrement" : "articulation";
            var ti = new TreeViewItem { Header = $"Nœud {s.NodeId}  {(at != "" ? "(axes " + at + ")  " : "")}{kind}", Tag = new NodeTag("S" + s.NodeId, "support", s.NodeId) };
            HookNodeMenu(ti, s.NodeId);
            sup.Items.Add(ti);
        }
        _tree.Items.Add(sup);

        // ---- nœuds (tous, y compris les nœuds libres ou isolés)
        var degree = new Dictionary<int, int>();
        foreach (var mm in m.Members) { degree[mm.NodeI] = degree.GetValueOrDefault(mm.NodeI) + 1; degree[mm.NodeJ] = degree.GetValueOrDefault(mm.NodeJ) + 1; }
        var supSet = new HashSet<int>(m.Supports.Select(x => x.NodeId));
        int isolated = nodes.Values.Count(n => degree.GetValueOrDefault(n.Id) == 0);
        var nodeRoot = new TreeViewItem { Header = $"Nœuds ({nodes.Count})" + (isolated > 0 ? $"  -  {isolated} isolé(s)" : ""), Tag = new NodeTag("nodes", "root"), FontWeight = FontWeights.SemiBold };
        foreach (var n in nodes.Values.OrderBy(x => x.Id))
        {
            string atN = _struct.AxisRef(n.X, n.Y);
            int dg = degree.GetValueOrDefault(n.Id);
            string tag = supSet.Contains(n.Id) ? "  ▲ appui" : dg == 0 ? "  ⚠ isolé" : "";
            var ni = new TreeViewItem
            {
                Header = $"Nœud {n.Id}   ({n.X:0.##} ; {n.Y:0.##} ; {n.Z:0.##}){(atN != "" ? "   axes " + atN : "")}{tag}",
                Tag = new NodeTag("N" + n.Id, "node", n.Id), FontWeight = FontWeights.Normal
            };
            if (dg == 0 && !supSet.Contains(n.Id)) ni.Foreground = Brushes.Firebrick;
            HookNodeMenu(ni, n.Id);
            _nodeItems[n.Id] = ni;
            nodeRoot.Items.Add(ni);
        }
        _tree.Items.Add(nodeRoot);

        // ---- état déplié
        if (first) { levels.IsExpanded = true; axes.IsExpanded = true; }
        else RestoreExpanded(_tree.Items, expanded);
        _building = false;
        _summary.Text = StructureAnalyzer.Overview(m, _struct);
    }

    /// <summary>Demande d'ouverture de l'élévation d'un axe comme plan de dessin.</summary>
    public event Action<string>? AxisPlaneRequested;

    private TreeViewItem AxisItem(string name, string header)
    {
        var item = new TreeViewItem { Header = header, Tag = new NodeTag("A" + name, "axis", Name: name) };
        var cm = new ContextMenu();
        var draw = new MenuItem { Header = "Dessiner dans l'élévation de cet axe (poutres, poteaux)" };
        draw.Click += (s, e) => AxisPlaneRequested?.Invoke(name);
        cm.Items.Add(draw);
        item.ContextMenu = cm;
        return item;
    }

    public static string SlabModeText(SlabCalcMode m) => m switch
    {
        SlabCalcMode.OneWayX => "un sens (X)", SlabCalcMode.OneWayY => "un sens (Y)", SlabCalcMode.MassOnly => "non chargée (métré seul)", _ => "deux sens"
    };

    private void HookNodeMenu(TreeViewItem item, int nodeId)
    {
        item.ContextMenu = new ContextMenu();
        item.ContextMenuOpening += (s, e) => { item.IsSelected = true; if (NodeMenuFiller == null) { e.Handled = true; return; } NodeMenuFiller(nodeId, item.ContextMenu!); };
    }

    private void AddGroup(TreeViewItem parent, string key, string title, List<int> ids, Dictionary<int, MemberDesignResult> results, int lvIdx = -1, string cat = "")
    {
        if (ids.Count == 0 || _m == null) return;
        var g = new TreeViewItem { Header = title, Tag = new NodeTag(key, "group") };
        if (cat != "") g.ContextMenu = GroupMenu(lvIdx, cat);
        foreach (int id in ids.OrderBy(x => x))
        {
            var mem = _m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            string glyph = "·";
            Brush col = Brushes.Gray;
            if (results.TryGetValue(id, out var r))
            {
                if (r.Skipped) { glyph = "○"; }
                else if (r.Ok) { glyph = "✔"; col = Brushes.ForestGreen; }
                else { glyph = "✖"; col = Brushes.Firebrick; }
            }
            var h = new StackPanel { Orientation = Orientation.Horizontal };
            h.Children.Add(new TextBlock { Text = StructureAnalyzer.MemberTitle(_m, id, _o) + "   " });
            h.Children.Add(new TextBlock { Text = glyph, Foreground = col, FontWeight = FontWeights.Bold });
            var item = new TreeViewItem { Header = h, Tag = new NodeTag("M" + id, "member", id) };
            _memberItems[id] = item;
            g.Items.Add(item);
        }
        parent.Items.Add(g);
    }

    private ContextMenu LevelMenu(int idx)
    {
        var cm = new ContextMenu();
        var zoom = new MenuItem { Header = "Zoom sur ce niveau" };
        zoom.Click += (s, e) => LevelChosen?.Invoke(idx);
        var iso = new MenuItem { Header = "Isoler ce niveau (masquer les autres)" };
        iso.Click += (s, e) => Isolate(idx);
        var all = new MenuItem { Header = "Afficher tous les niveaux" };
        all.Click += (s, e) => ShowAllLevels();
        var wp = new MenuItem { Header = "Prendre ce niveau comme plan de travail (dessin)" };
        wp.Click += (s, e) => WorkPlaneRequested?.Invoke(idx);
        var selAll = new MenuItem { Header = "Sélectionner tout le niveau (poteaux + poutres)" };
        selAll.Click += (s, e) => SelectGroup(idx, "all");
        var add = new MenuItem { Header = "Ajouter un niveau..." };
        add.Click += (s, e) => AddLevelRequested?.Invoke();
        int nLv = _struct.Levels.Count;
        double hUp = idx + 1 < nLv ? _struct.Levels[idx + 1].Z - _struct.Levels[idx].Z : 0;
        double hDn = idx > 0 && idx < nLv ? _struct.Levels[idx].Z - _struct.Levels[idx - 1].Z : 0;
        var hgtUp = new MenuItem { Header = hUp > 0 ? $"Hauteur de l'étage au-dessus ({hUp:0.00} m)..." : "Hauteur de l'étage au-dessus (dernier niveau)", IsEnabled = hUp > 0 };
        hgtUp.Click += (s, e) => LevelHeightRequested?.Invoke(idx, false);
        var hgtDn = new MenuItem { Header = hDn > 0 ? $"Hauteur de l'étage en dessous ({hDn:0.00} m)..." : "Hauteur de l'étage en dessous (premier niveau)", IsEnabled = hDn > 0 };
        hgtDn.Click += (s, e) => LevelHeightRequested?.Invoke(idx, true);
        var ren = new MenuItem { Header = "Renommer ce niveau..." };
        ren.Click += (s, e) => RenameLevelRequested?.Invoke(idx);
        var copy = new MenuItem { Header = "Copier le contenu vers un autre niveau" };
        foreach (var (title, cat) in new[] { ("Tout (poteaux, poutres, dalles)...", "all"), ("Poteaux...", "columns"), ("Poutres...", "beams"), ("Dalles...", "slabs") })
        {
            var mi = new MenuItem { Header = title };
            string c = cat; mi.Click += (s, e) => CopyLevelRequested?.Invoke(idx, c);
            copy.Items.Add(mi);
        }
        cm.Items.Add(selAll); cm.Items.Add(new Separator());
        cm.Items.Add(zoom); cm.Items.Add(iso); cm.Items.Add(all); cm.Items.Add(new Separator()); cm.Items.Add(wp); cm.Items.Add(new Separator());
        cm.Items.Add(add); cm.Items.Add(ren); cm.Items.Add(hgtUp); cm.Items.Add(hgtDn); cm.Items.Add(copy);
        return cm;
    }

    private ContextMenu RootMenu()
    {
        var cm = new ContextMenu();
        var add = new MenuItem { Header = "Ajouter un niveau..." };
        add.Click += (s, e) => AddLevelRequested?.Invoke();
        var all = new MenuItem { Header = "Sélectionner toute la structure" };
        all.Click += (s, e) => { if (_m != null) GroupChosen?.Invoke(_m.Members.Select(x => x.Id).ToList(), "toute la structure"); };
        var show = new MenuItem { Header = "Afficher tous les niveaux" };
        show.Click += (s, e) => ShowAllLevels();
        cm.Items.Add(add); cm.Items.Add(all); cm.Items.Add(show);
        return cm;
    }

    private ContextMenu GroupMenu(int idx, string cat)
    {
        var cm = new ContextMenu();
        string what = cat == "columns" ? "poteaux" : cat == "beams" ? "poutres" : "dalles";
        if (cat != "slabs")
        {
            var sel = new MenuItem { Header = $"Sélectionner tous les {what} de ce niveau" };
            sel.Click += (s, e) => SelectGroup(idx, cat);
            cm.Items.Add(sel);
        }
        var copy = new MenuItem { Header = $"Copier les {what} vers un autre niveau..." };
        copy.Click += (s, e) => CopyLevelRequested?.Invoke(idx, cat);
        cm.Items.Add(copy);
        return cm;
    }

    private List<int> IdsOf(int idx, string cat)
    {
        if (idx < 0 || idx >= _struct.Levels.Count) return new List<int>();
        var lv = _struct.Levels[idx];
        return cat == "columns" ? lv.ColumnIds.ToList() : cat == "beams" ? lv.BeamIds.ToList() : lv.ColumnIds.Concat(lv.BeamIds).ToList();
    }

    private void SelectGroup(int idx, string cat)
    {
        var ids = IdsOf(idx, cat);
        string name = idx >= 0 && idx < _struct.Levels.Count ? _struct.Levels[idx].Name : "";
        string what = cat == "columns" ? "poteaux" : cat == "beams" ? "poutres" : "éléments";
        GroupChosen?.Invoke(ids, $"{ids.Count} {what} du niveau « {name} »");
    }

    /// <summary>Double-clic : un niveau sélectionne tout son contenu ; « Poteaux » / « Poutres » sélectionnent ce groupe ; « Niveaux » sélectionne toute la structure.</summary>
    private void OnTreeDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (_m == null) return;
        DependencyObject? d = e.OriginalSource as DependencyObject;
        while (d != null && d is not TreeViewItem) d = d is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
        if (d is not TreeViewItem item || item.Tag is not NodeTag t) return;
        if (t.Kind == "level") { SelectGroup(t.Id, "all"); e.Handled = true; }
        else if (t.Kind == "group" && t.Key.Length > 2 && t.Key[0] == 'L' && (t.Key[^1] == 'P' || t.Key[^1] == 'B') && int.TryParse(t.Key[1..^1], out int li))
        { SelectGroup(li, t.Key[^1] == 'P' ? "columns" : "beams"); e.Handled = true; }
        else if ((t.Kind == "node" || t.Kind == "support") && t.Id >= 0) { NodeZoomRequested?.Invoke(t.Id); e.Handled = true; }
        else if (t.Kind == "slab") { SlabZoomRequested?.Invoke(t.Name); e.Handled = true; }
        else if (t.Kind == "root" && t.Key == "levels") { GroupChosen?.Invoke(_m.Members.Select(x => x.Id).ToList(), "toute la structure"); e.Handled = true; }
    }

    public void Isolate(int idx)
    {
        Hidden.Clear();
        foreach (var lv in _struct.Levels) if (lv.Index != idx) Hidden.Add(lv.Index);
        if (_m != null) Refresh(_m, _o);
        VisibilityChanged?.Invoke();
    }

    public void ShowAllLevels()
    {
        Hidden.Clear();
        if (_m != null) Refresh(_m, _o);
        VisibilityChanged?.Invoke();
    }

    // ------------------------------------------------------------------ état déplié
    private static void CollectExpanded(ItemCollection items, HashSet<string> set)
    {
        foreach (var o in items)
            if (o is TreeViewItem t)
            {
                if (t.IsExpanded && t.Tag is NodeTag tag) set.Add(tag.Key);
                CollectExpanded(t.Items, set);
            }
    }

    private static void RestoreExpanded(ItemCollection items, HashSet<string> set)
    {
        foreach (var o in items)
            if (o is TreeViewItem t)
            {
                if (t.Tag is NodeTag tag) t.IsExpanded = set.Contains(tag.Key);
                RestoreExpanded(t.Items, set);
            }
    }

    private static void SetExpanded(ItemCollection items, bool value)
    {
        foreach (var o in items)
            if (o is TreeViewItem t) { t.IsExpanded = value; SetExpanded(t.Items, value); }
    }

    // ------------------------------------------------------------------ sélection
    private void OnSelected()
    {
        if (_building || _suppress || _m == null) return;
        if (_tree.SelectedItem is not TreeViewItem item || item.Tag is not NodeTag t) return;
        switch (t.Kind)
        {
            case "member":
                _infoBox.Text = StructureAnalyzer.DescribeMember(_m, _struct, t.Id, _o);
                MemberChosen?.Invoke(t.Id);
                break;
            case "level":
                _infoBox.Text = StructureAnalyzer.DescribeLevel(_m, _struct, t.Id);
                LevelChosen?.Invoke(t.Id);
                break;
            case "slab":
            {
                var sl = _m.Slabs.FirstOrDefault(x => x.Name == t.Name);
                _infoBox.Text = sl == null ? "" : $"Dalle {sl.Name}\nDimensions : {sl.Lx:0.00} x {sl.Ly:0.00} m ; épaisseur {sl.H * 100:0} cm\nCote du dessus : {sl.Z:0.00} m ; coin ({sl.X0:0.00} ; {sl.Y0:0.00})\nVolume : {sl.Volume:0.00} m³ ; poids propre {sl.SelfWeightKnM2:0.00} kN/m² ({sl.TotalWeightKn:0} kN au total)\nCharges : G supplémentaire {sl.GExtra:0.0} kN/m², Q = {sl.Q:0.0} kN/m² ; calcul : {SlabModeText(sl.CalcMode)}\nClic droit : propriétés, dimensionnement (assistant Planchers), suppression.";
                SlabChosen?.Invoke(t.Name);
                break;
            }
            case "axis":
                _infoBox.Text = StructureAnalyzer.DescribeAxis(_struct, t.Name);
                AxisChosen?.Invoke(t.Name);
                break;
            case "support":
            case "node":
                var n = _m.Nodes.FirstOrDefault(x => x.Id == t.Id);
                NodeChosen?.Invoke(t.Id);
                _infoBox.Text = n == null ? "" : $"{(t.Kind == "support" ? "Appui au nœud" : "Nœud")} {n.Id}\nPosition : ({n.X:0.00} ; {n.Y:0.00} ; {n.Z:0.00})\nAxes : {_struct.AxisRef(n.X, n.Y)}\nNiveau : {_struct.Levels.ElementAtOrDefault(_struct.NodeLevel.TryGetValue(n.Id, out int li) ? li : -1)?.Label}";
                break;
            default:
                _infoBox.Text = StructureAnalyzer.Overview(_m, _struct);
                break;
        }
    }

    /// <summary>Sélection d'un nœud venant de la vue (sans rebondir en événement).</summary>
    public void SelectNode(int id)
    {
        if (_m == null) return;
        _suppress = true;
        try
        {
            if (id >= 0 && _nodeItems.TryGetValue(id, out var item))
            {
                for (var p = item.Parent as TreeViewItem; p != null; p = p.Parent as TreeViewItem) p.IsExpanded = true;
                item.IsSelected = true; item.BringIntoView();
            }
            else if (_tree.SelectedItem is TreeViewItem cur && cur.Tag is NodeTag nt && (nt.Kind == "node" || nt.Kind == "support")) cur.IsSelected = false;
        }
        finally { _suppress = false; }
    }

    public void SelectSlab(string name)
    {
        _suppress = true;
        try
        {
            if (_slabItems.TryGetValue(name, out var item))
            {
                for (var p = item.Parent as TreeViewItem; p != null; p = p.Parent as TreeViewItem) p.IsExpanded = true;
                item.IsSelected = true; item.BringIntoView();
            }
        }
        finally { _suppress = false; }
    }

    /// <summary>Sélection venant de la vue 3D ou du tableau des résultats (sans rebondir en événement).</summary>
    public void SelectMember(int id)
    {
        if (_m == null) return;
        _suppress = true;
        try
        {
            if (id >= 0 && _memberItems.TryGetValue(id, out var item))
            {
                for (var p = item.Parent as TreeViewItem; p != null; p = p.Parent as TreeViewItem) p.IsExpanded = true;
                item.IsSelected = true;
                item.BringIntoView();
                _infoBox.Text = StructureAnalyzer.DescribeMember(_m, _struct, id, _o);
            }
            else
            {
                if (_tree.SelectedItem is TreeViewItem cur) cur.IsSelected = false;
                _infoBox.Text = StructureAnalyzer.Overview(_m, _struct);
            }
        }
        finally { _suppress = false; }
    }
}
