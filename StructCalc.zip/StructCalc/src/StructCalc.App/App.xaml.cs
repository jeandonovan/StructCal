using System.Windows;
using StructCalc.Core.Licensing;

namespace StructCalc.UI;

public partial class App : Application
{
    /// <summary>Fichier modèle passé en argument (double-clic, ou envoi depuis Revit), null sinon.</summary>
    public static string? StartupFile { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        StartupFile = e.Args.FirstOrDefault(a => System.IO.File.Exists(a));
        try { StructCalc.Engine.RevitLink.RememberApp(Environment.ProcessPath ?? ""); } catch { }
        // filet de sécurité : une erreur inattendue dans un clic n'arrête plus le logiciel ; elle est notée dans %APPDATA%\\StructCalc\\erreurs.log
        DispatcherUnhandledException += (s, ex) =>
        {
            try
            {
                string dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc");
                System.IO.Directory.CreateDirectory(dir);
                System.IO.File.AppendAllText(System.IO.Path.Combine(dir, "erreurs.log"), $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex.Exception}\r\n\r\n");
            }
            catch { }
            ex.Handled = true;
            MessageBox.Show("Une erreur inattendue s'est produite, l'opération est annulée mais le logiciel reste ouvert.\n\n" + ex.Exception.Message
                + "\n\nLe détail est enregistré dans %APPDATA%\\StructCalc\\erreurs.log : envoyez-le à l'auteur.", "StructCalc", MessageBoxButton.OK, MessageBoxImage.Warning);
        };
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        Theme.Init();
        var st = LicenseManager.Current;
        if (!st.CanRun)
        {
            new LicenseWindow(st).ShowDialog();
            LicenseManager.Refresh();
            if (!LicenseManager.Current.CanRun) { Shutdown(); return; }
        }
        var main = new MainWindow();
        MainWindow = main;
        ShutdownMode = ShutdownMode.OnMainWindowClose;
        main.Show();
        main.AfterShow(StartupFile);
    }
}
