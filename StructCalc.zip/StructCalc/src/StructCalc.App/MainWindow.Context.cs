using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Menus contextuels (clic droit) façon Robot Structural Analysis / Advance Design : nœud, appui, barre, dalle, zone vide ;
/// les mêmes menus s'ouvrent depuis l'arborescence. Liaison avec les assistants Sol et semelles et Planchers.</summary>
public partial class MainWindow
{
    private static string F2(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
    private static string F3(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);

    private static MenuItem Mi(string header, Action act, bool enabled = true, string? gesture = null)
    {
        var m = new MenuItem { Header = header, IsEnabled = enabled };
        if (gesture != null) m.InputGestureText = gesture;
        m.Click += (s, e) => act();
        return m;
    }

    private static MenuItem MenuTitle(string text) =>
        new() { Header = text, IsEnabled = false, FontWeight = FontWeights.SemiBold };

    private void InitContext()
    {
        InitElementSelection();
        _vp.ContextRequested += OnViewContext;
        _vp.NodeSelectionChanged += OnNodeSelectionChanged;
        _vp.SlabSelected += OnSlabSelected;
        if (_panel == null) return;
        _panel.LevelHeightRequested += AskLevelHeight;
        _panel.AxisPlaneRequested += name =>
        {
            var info = _panel.Structure;
            var xa = info.XAxes.FirstOrDefault(a => a.Name == name); var ya = info.YAxes.FirstOrDefault(a => a.Name == name);
            if (xa == null && ya == null) return;
            // axe numéroté (x constant) -> vue de côté ; axe lettré (y constant) -> élévation
            double pos = xa?.Pos ?? ya!.Pos;
            _vp.SetMode(xa != null ? ViewMode.Side : ViewMode.Elevation);
            WorkBox.Text = pos.ToString("0.###", CultureInfo.InvariantCulture);
            _vp.WorkOffset = pos;
            RbMember.IsChecked = true;
            Say($"Élévation de l'axe {name} ({(xa != null ? "x" : "y")} = {F3(pos)} m) : dessinez les poutres et poteaux à l'écran.");
        };
        _panel.NodeMenuFiller = (id, cm) => FillNodeMenu(cm, id);
        _panel.SlabMenuFiller = (name, cm) => { var s = FindSlab(name); if (s == null) cm.Items.Clear(); else FillSlabMenu(cm, s); };
        _panel.NodeChosen += id => { if (!(_vp.SelectedNodes.Count == 1 && _vp.PrimaryNode == id)) _vp.SelectNodesOnly(new[] { id }); };
        _panel.NodeZoomRequested += id => { _vp.SelectNodesOnly(new[] { id }); _vp.ZoomNodes(new[] { id }); };
        _panel.SlabChosen += name => { var s = FindSlab(name); if (s != null && !ReferenceEquals(s, _vp.SelectedSlab)) _vp.SelectSlab(s); };
        _panel.SlabZoomRequested += name => { var s = FindSlab(name); if (s != null) { _vp.SelectSlab(s); _vp.ZoomSlab(s); } };
    }

    private SlabPanel? FindSlab(string name) => _model.Slabs.FirstOrDefault(s => s.Name == name);
    private Node? FindNode(int id) => _model.Nodes.FirstOrDefault(n => n.Id == id);

    private void ShowMenu(ContextMenu cm)
    {
        cm.PlacementTarget = ViewCanvas;
        cm.Placement = System.Windows.Controls.Primitives.PlacementMode.MousePoint;
        cm.IsOpen = true;
    }

    // ------------------------------------------------------------------ clic droit dans la vue
    private void OnViewContext(ViewTarget t)
    {
        var cm = new ContextMenu();
        switch (t.Kind)
        {
            case ViewTargetKind.Node: FillNodeMenu(cm, t.Id); break;
            case ViewTargetKind.Member: FillMemberMenu(cm, t.Id); break;
            case ViewTargetKind.Slab: if (t.Slab != null) FillSlabMenu(cm, t.Slab); break;
            case ViewTargetKind.Shell: if (t.Shell != null) FillShellMenu(cm, t.Shell); break;
            case ViewTargetKind.Load: if (t.Obj != null) FillLoadMenu(cm, t.Obj); break;
            case ViewTargetKind.Dim: if (t.Obj is ManualDim md) FillDimMenu(cm, md); break;
            case ViewTargetKind.Element: if (t.Key is StructCalc.Engine.Selection.ElementKey ek) FillElementMenu(cm, ek, t.Obj); break;
            case ViewTargetKind.Selection: FillMultiMenu(cm); break;
            default: FillEmptyMenu(cm, t.At); break;
        }
        if (cm.Items.Count > 0) ShowMenu(cm);
    }

    // ------------------------------------------------------------------ sélection d'un nœud / d'une dalle : informations
    private void OnNodeSelectionChanged()
    {
        var ids = _vp.SelectedNodes;
        if (ids.Count == 0) { _panel?.SelectNode(-1); return; }
        int id = _vp.PrimaryNode;
        _panel?.SelectNode(id);
        if (ids.Count == 1)
        {
            var n = FindNode(id);
            StatusLeft.Text = n == null ? "" : $"Nœud {id} : X = {F3(n.X)}  Y = {F3(n.Y)}  Z = {F3(n.Z)} m  -  clic droit : menu (appui, semelle, charge, déplacer, supprimer...)";
        }
        else StatusLeft.Text = $"{ids.Count} nœuds sélectionnés  -  clic droit : appui, charge, déplacement, suppression pour tous.";
        Dispatcher.BeginInvoke(new Action(() => { if (_vp.SelectedCount > _vp.SelectedNodes.Count) return; if (_vp.SelectedNodes.Count == 1) ShowNode(_vp.PrimaryNode); else if (_vp.SelectedNodes.Count > 1) ShowNodes(); }), DispatcherPriority.Background);
    }

    private void OnSlabSelected(SlabPanel? s)
    {
        if (s == null) return;
        _panel?.SelectSlab(s.Name);
        StatusLeft.Text = $"Dalle {s.Name} sélectionnée  -  clic droit : propriétés, dimensionnement, duplication, suppression.";
        DetailTitle.Text = $"Dalle {s.Name}";
        DetailSub.Text = $"{F2(s.Lx)} x {F2(s.Ly)} m, h = {s.H * 100:0} cm, cote du dessus {F2(s.Z)} m";
        GridProps.ItemsSource = new List<object>
        {
            new { Parametre = "Dimensions", Valeur = $"{F2(s.Lx)} x {F2(s.Ly)} m" },
            new { Parametre = "Épaisseur", Valeur = $"{s.H * 100:0} cm" },
            new { Parametre = "Volume de béton", Valeur = $"{F2(s.Volume)} m³" },
            new { Parametre = "Poids propre", Valeur = $"{F2(s.SelfWeightKnM2)} kN/m²  ({s.TotalWeightKn:0} kN)" },
            new { Parametre = "Niveau d'attache", Valeur = StoreyOps.LevelOf(LevelInfoNow(), s) is int li && li >= 0 ? LevelInfoNow().Levels[li].Label : "aucun (cote libre)" },
            new { Parametre = "Calcul", Valeur = StructurePanel.SlabModeText(s.CalcMode) },
            new { Parametre = "Coin (X0 ; Y0)", Valeur = $"{F2(s.X0)} ; {F2(s.Y0)}" },
            new { Parametre = "Cote du dessus", Valeur = $"{F2(s.Z)} m" },
            new { Parametre = "G supplémentaire", Valeur = $"{s.GExtra:0.0} kN/m²" },
            new { Parametre = "Q exploitation", Valeur = $"{s.Q:0.0} kN/m²" },
            new { Parametre = "Continuité", Valeur = s.Continuity.ToString() },
        };
        NotesBox.Text = "Clic droit sur la dalle : propriétés, dimensionnement (assistant Planchers), zoom, duplication, suppression. Suppr : supprimer.";
        SectionDrawing.Draw(SectionCanvas, null, null);
    }

    private void ShowNodes()
    {
        DetailTitle.Text = $"{_vp.SelectedNodes.Count} nœuds sélectionnés";
        DetailSub.Text = "Clic droit : appui, charge nodale, déplacement ou suppression pour tous les nœuds sélectionnés.";
        GridProps.ItemsSource = new List<object>
        {
            new { Parametre = "Nœuds", Valeur = string.Join(", ", _vp.SelectedNodes.Take(30)) + (_vp.SelectedNodes.Count > 30 ? " ..." : "") },
            new { Parametre = "Dont appuis", Valeur = _vp.SelectedNodes.Count(i => _model.Supports.Any(s => s.NodeId == i)).ToString() },
        };
        NotesBox.Text = ""; SectionDrawing.Draw(SectionCanvas, null, null);
    }

    private static string SupportText(SupportDef s) =>
        s.Rx && s.Ry && s.Rz && s.Ux && s.Uy && s.Uz ? "Encastrement"
        : s.Ux && s.Uy && s.Uz && !s.Rx && !s.Ry && !s.Rz ? "Articulation (rotule)"
        : !s.Ux && !s.Uy && s.Uz ? "Appui simple (vertical)" : "Appui personnalisé";

    private void ShowNode(int id)
    {
        var n = FindNode(id);
        if (n == null) return;
        var info = LevelInfoNow();
        var sup = _model.Supports.FirstOrDefault(s => s.NodeId == id);
        var bars = _model.Members.Where(m => m.NodeI == id || m.NodeJ == id).ToList();
        DetailTitle.Text = $"Nœud {id}" + (sup != null ? "  -  appui" : bars.Count == 0 ? "  -  isolé" : "");
        DetailSub.Text = bars.Count == 0 && sup == null ? "Nœud sans barre : clic droit pour le déplacer, le supprimer ou tracer une barre à partir de lui." : "Clic droit : appui, dimensionnement de la semelle, charge nodale, déplacement...";
        var props = new List<object>
        {
            new { Parametre = "Position X ; Y ; Z", Valeur = $"{F3(n.X)} ; {F3(n.Y)} ; {F3(n.Z)} m" },
            new { Parametre = "Axes", Valeur = info.AxisRef(n.X, n.Y) },
            new { Parametre = "Appui", Valeur = sup == null ? "aucun" : SupportText(sup) },
            new { Parametre = "Barres reliées", Valeur = bars.Count == 0 ? "aucune" : string.Join(", ", bars.Select(b => (b.Type == MemberType.Column ? "P" : "B") + b.Id)) },
            new { Parametre = "Charges nodales", Valeur = _model.NodalLoads.Count(l => l.NodeId == id).ToString() },
        };
        var rr = _out?.Global?.Reactions.FirstOrDefault(r => r.NodeId == id);
        if (rr != null)
        {
            props.Add(new { Parametre = "Réaction Fz max (ELU)", Valeur = $"{rr.Max[2]:0.0} kN" });
            props.Add(new { Parametre = "Réaction Fz (ELS)", Valeur = $"{rr.FzService:0.0} kN" });
            props.Add(new { Parametre = "Fx / Fy max", Valeur = $"{Math.Max(Math.Abs(rr.Max[0]), Math.Abs(rr.Min[0])):0.0} / {Math.Max(Math.Abs(rr.Max[1]), Math.Abs(rr.Min[1])):0.0} kN" });
        }
        GridProps.ItemsSource = props;
        NotesBox.Text = sup != null && rr == null ? "Lancez le calcul (F5) pour obtenir les réactions d'appui et pré-remplir la semelle." : "";
        SectionDrawing.Draw(SectionCanvas, null, null);
    }

    // ------------------------------------------------------------------ menu d'un nœud / appui
    private List<int> NodeTargets(int clicked) =>
        _vp.SelectedNodes.Contains(clicked) ? _vp.SelectedNodes.ToList() : new List<int> { clicked };

    private void FillNodeMenu(ContextMenu cm, int clicked)
    {
        cm.Items.Clear();
        var ids = NodeTargets(clicked);
        var n = FindNode(clicked);
        if (n == null) return;
        bool single = ids.Count == 1;
        var sup = _model.Supports.FirstOrDefault(s => s.NodeId == clicked);
        int bars = _model.Members.Count(m => m.NodeI == clicked || m.NodeJ == clicked);
        cm.Items.Add(MenuTitle(single ? $"Nœud {clicked}   ({F2(n.X)} ; {F2(n.Y)} ; {F2(n.Z)})" + (sup != null ? "   ▲ " + SupportText(sup) : bars == 0 ? "   ⚠ isolé" : "") : $"{ids.Count} nœuds sélectionnés"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Appliquer une charge de la bibliothèque...", () => { if (!_vp.SelectedNodes.Contains(clicked)) _vp.SelectNodesOnly(ids); ApplyCatalog(0, "nodes"); }));
        cm.Items.Add(Mi("Zoom sur " + (single ? "le nœud" : "les nœuds"), () => _vp.ZoomNodes(ids)));
        if (single) cm.Items.Add(Mi("Propriétés : modifier les coordonnées...", () => NodeProps(clicked)));
        cm.Items.Add(Mi("Déplacer...", () => MoveNodesBy(ids), true, "M"));
        cm.Items.Add(new Separator());

        var sub = new MenuItem { Header = "Appui" };
        sub.Items.Add(Mi("Encastrement", () => SetSupports(ids, "fixed")));
        sub.Items.Add(Mi("Articulation (3 translations bloquées)", () => SetSupports(ids, "pinned")));
        sub.Items.Add(Mi("Appui simple (vertical seul)", () => SetSupports(ids, "roller")));
        sub.Items.Add(new Separator());
        sub.Items.Add(Mi("Retirer l'appui", () => SetSupports(ids, "none"), ids.Any(i => _model.Supports.Any(s => s.NodeId == i))));
        cm.Items.Add(sub);
        cm.Items.Add(Mi(sup != null ? "Dimensionner la semelle sous cet appui (assistant Sol et semelles)..." : "Dimensionner la semelle (poser d'abord un appui)", () => OpenFootingFor(clicked), single && sup != null));
        cm.Items.Add(Mi("Prédimensionner la semelle sous cet appui...", () => PreDesignFooting(clicked), single && sup != null));
        cm.Items.Add(Mi("Ajouter une charge nodale...", () => AddNodalLoad(ids)));
        cm.Items.Add(new Separator());

        if (single)
        {
            cm.Items.Add(Mi("Tracer une barre à partir de ce nœud", () => StartBarFrom(clicked)));
            cm.Items.Add(Mi("Sélectionner les barres reliées", () => _vp.SetSelection(_model.Members.Where(m => m.NodeI == clicked || m.NodeJ == clicked).Select(m => m.Id)), bars > 0));
        }
        var sel = new MenuItem { Header = "Sélectionner" };
        sel.Items.Add(Mi("Tous les nœuds du même niveau", () => _vp.SelectNodesOnly(_model.Nodes.Where(q => Math.Abs(q.Z - n.Z) < 0.05).Select(q => q.Id))));
        sel.Items.Add(Mi("Tous les appuis", () => _vp.SelectNodesOnly(_model.Supports.Select(s => s.NodeId))));
        sel.Items.Add(Mi("Tous les nœuds isolés (sans barre)", () => _vp.SelectNodesOnly(_model.Nodes.Where(q => !_model.Members.Any(m => m.NodeI == q.Id || m.NodeJ == q.Id)).Select(q => q.Id))));
        sel.Items.Add(Mi("Tous les nœuds", () => _vp.SelectNodesOnly(_model.Nodes.Select(q => q.Id))));
        cm.Items.Add(sel);
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi(single ? "Supprimer le nœud" : $"Supprimer les {ids.Count} nœuds", () => DeleteNodesAsk(ids), true, "Suppr"));
        AddVisibilityItems(cm, ids);
    }

    private void NodeProps(int id)
    {
        var n = FindNode(id); if (n == null) return;
        var v = PromptWindow.Ask(this, $"Nœud {id}", "Coordonnées en mètres. Les barres reliées suivent le nœud.", ("X (m)", F3(n.X)), ("Y (m)", F3(n.Y)), ("Z (m)", F3(n.Z)));
        if (v == null) return;
        CommitGrids(); PushUndo();
        n.X = Ui.Num(v[0], n.X); n.Y = Ui.Num(v[1], n.Y); n.Z = Ui.Num(v[2], n.Z);
        OnModelEdited(); ShowNode(id);
        Log($"Nœud {id} déplacé en ({F3(n.X)} ; {F3(n.Y)} ; {F3(n.Z)}).");
    }

    private void MoveNodesBy(List<int> ids)
    {
        var v = PromptWindow.Ask(this, "Déplacer les nœuds", $"Déplace {ids.Count} nœud(s) ; les barres reliées suivent.", ("dX (m)", "0"), ("dY (m)", "0"), ("dZ (m)", "0"));
        if (v == null) return;
        double dx = Ui.Num(v[0], 0), dy = Ui.Num(v[1], 0), dz = Ui.Num(v[2], 0);
        if (Math.Abs(dx) + Math.Abs(dy) + Math.Abs(dz) < 1e-9) return;
        CommitGrids(); PushUndo();
        foreach (var n in _model.Nodes.Where(q => ids.Contains(q.Id))) { n.X += dx; n.Y += dy; n.Z += dz; }
        OnModelEdited();
        Log($"{ids.Count} nœud(s) déplacé(s) de ({F3(dx)} ; {F3(dy)} ; {F3(dz)}).");
    }

    private void SetSupports(List<int> ids, string kind)
    {
        CommitGrids(); PushUndo();
        foreach (int id in ids)
        {
            foreach (var old in _model.Supports.Where(x => x.NodeId == id).ToList()) _model.Supports.Remove(old);
            switch (kind)
            {
                case "fixed": _model.Supports.Add(new SupportDef { NodeId = id }); break;
                case "pinned": _model.Supports.Add(new SupportDef { NodeId = id, Rx = false, Ry = false, Rz = false }); break;
                case "roller": _model.Supports.Add(new SupportDef { NodeId = id, Ux = false, Uy = false, Rx = false, Ry = false, Rz = false }); break;
            }
        }
        OnModelEdited();
        if (ids.Count == 1) ShowNode(ids[0]);
        string what = kind switch { "fixed" => "encastrement", "pinned" => "articulation", "roller" => "appui simple", _ => "appui retiré" };
        Log($"{ids.Count} nœud(s) : {what}.");
    }

    private void AddNodalLoad(List<int> ids)
    {
        var v = PromptWindow.Ask(this, "Charge nodale", $"Appliquée à {ids.Count} nœud(s). Unités : kN et kN.m ; Fz négatif = vers le bas.",
            ("Cas (G, Q, W, S ou E)", "Q"), ("Fx", "0"), ("Fy", "0"), ("Fz", "-10"), ("Mx", "0"), ("My", "0"), ("Mz", "0"));
        if (v == null) return;
        if (!Enum.TryParse<ActionType>(v[0].Trim().ToUpperInvariant(), out var cas)) cas = ActionType.G;
        CommitGrids(); PushUndo();
        foreach (int id in ids)
            _model.NodalLoads.Add(new NodalLoad { NodeId = id, Case = cas, Fx = Ui.Num(v[1], 0), Fy = Ui.Num(v[2], 0), Fz = Ui.Num(v[3], 0), Mx = Ui.Num(v[4], 0), My = Ui.Num(v[5], 0), Mz = Ui.Num(v[6], 0) });
        OnModelEdited();
        Log($"Charge nodale ({cas}) ajoutée sur {ids.Count} nœud(s).");
    }

    private void StartBarFrom(int id)
    {
        if (_vp.Mode == ViewMode.Iso) { _vp.SetMode(ViewMode.Elevation); }
        RbMember.IsChecked = true;
        _vp.StartMemberFrom(id);
        StatusLeft.Text = $"Barre : nœud {id} pris comme point de départ - cliquez l'autre extrémité (clic droit ou Échap pour annuler).";
    }

    private void DeleteNodesAsk(List<int> ids)
    {
        int nb = _model.Members.Count(m => ids.Contains(m.NodeI) || ids.Contains(m.NodeJ));
        if (nb > 0 && MessageBox.Show($"Supprimer {ids.Count} nœud(s) avec {nb} barre(s) reliée(s) ?\nVous pourrez annuler avec Ctrl+Z.", "Supprimer", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        CommitGrids(); PushUndo();
        _vp.DeleteNodes(ids);
        OnModelEdited(); ShowMember(-1);
        Log($"{ids.Count} nœud(s) supprimé(s).");
    }

    /// <summary>Suppr au clavier : barres, nœuds ou dalle sélectionnés.</summary>
    private void DeleteAnySelection()
    {
        if (_vp.SelectedObject != null) { StatusLeft.Text = _vp.DeleteSelectedObject(); return; }
        // élément surfacique ou sélection mélangée : suppression centrale, avec confirmation
        if (_vp.SelectedElementKeys.Count > 0 || (_vp.Selection.Count > 0 && _vp.SelectedNodes.Count > 0) || _vp.Report().Hidden.Count > 0) { DeleteSelectionConfirm(); return; }
        if (_vp.Selection.Count > 0) { DeleteSelection_Click(this, new RoutedEventArgs()); return; }
        if (_vp.SelectedNodes.Count > 0) { DeleteNodesAsk(_vp.SelectedNodes.ToList()); return; }
    }

    // ------------------------------------------------------------------ semelle : assistant Sol et semelles pré-rempli
    private FootingDef BuildFootingSeed(int nodeId, out string note)
    {
        var existing = _model.FootingDefs.FirstOrDefault(f => f.Name == "S" + nodeId);
        if (existing != null) { note = $"Semelle S{nodeId} existante rouverte."; return existing.Clone(); }
        var col = _model.Members.FirstOrDefault(m => m.Type == MemberType.Column && m.Kind == MaterialKind.ReinforcedConcrete && (m.NodeI == nodeId || m.NodeJ == nodeId));
        var fd = new FootingDef { Name = "S" + nodeId };
        if (col != null) { fd.ColA = col.B; fd.ColB = col.H; }
        var rr = _out?.Global?.Reactions.FirstOrDefault(r => r.NodeId == nodeId);
        if (rr != null && rr.Max[2] > 0)
        {
            fd.NuKN = Math.Round(rr.Max[2], 1);
            fd.NserKN = Math.Round(rr.FzService > 0 ? rr.FzService : rr.Max[2] / 1.4, 1);
            note = $"Semelle S{nodeId} pré-remplie : poteau {fd.ColA * 100:0}x{fd.ColB * 100:0} cm, Nu = {fd.NuKN:0.#} kN, Nser = {fd.NserKN:0.#} kN (réactions du dernier calcul).";
        }
        else note = $"Semelle S{nodeId} : lancez le calcul (F5) pour récupérer les réactions ; valeurs par défaut en attendant (modifiables dans l'assistant).";
        return fd;
    }

    private void OpenFootingFor(int nodeId)
    {
        var seed = BuildFootingSeed(nodeId, out string note);
        _soilWin?.Close();
        _soilWin = new SoilFootingWizardWindow(() => _model, ApplyLoadEdit, seed) { Owner = this };
        _soilWin.Closed += (s, a) => _soilWin = null;
        _soilWin.Show();
        Say(note);
    }

    // ------------------------------------------------------------------ menu d'une dalle
    private void FillSlabMenu(ContextMenu cm, SlabPanel s)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle($"Dalle {s.Name}   {F2(s.Lx)} x {F2(s.Ly)} m   h = {s.H * 100:0} cm"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Propriétés : épaisseur et charges...", () => SlabProps(s)));
        cm.Items.Add(Mi("Charges depuis la bibliothèque (revêtements, usage)...", () => SlabCatalog(s)));
        cm.Items.Add(Mi("Dimensionner la dalle (assistant Planchers)...", () => OpenFloorFor(s)));
        cm.Items.Add(Mi("Prédimensionner l'épaisseur...", () => PreDesignSlab(s)));
        cm.Items.Add(Mi("Zoom sur la dalle", () => { _vp.SelectSlab(s); _vp.ZoomSlab(s); }));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Dupliquer avec décalage...", () => DuplicateSlab(s)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Supprimer la dalle", () => DeleteSlabNow(s), true, "Suppr"));
        AddVisibilityItems(cm, null, s);
    }

    /// <summary>Remplit G supplémentaire (couches : revêtement, chape, isolant...) ou Q (catégorie d'usage) de la dalle depuis la bibliothèque de charges.</summary>
    private void SlabCatalog(SlabPanel s)
    {
        if (!ReferenceEquals(_vp.SelectedSlab, s)) _vp.SelectSlab(s);
        ApplyCatalog(1, "slab");
    }

    private void OpenFloorFor(SlabPanel s)
    {
        _floorWin?.Close();
        _floorWin = new FloorWizardWindow(() => _model, ApplyLoadEdit, s) { Owner = this };
        _floorWin.Closed += (a, b) => _floorWin = null;
        _floorWin.Show();
        Say($"Assistant Planchers ouvert sur la dalle {s.Name} (dalle pleine {F2(s.Lx)} x {F2(s.Ly)} m, h = {s.H * 100:0} cm). Enregistrez pour mettre à jour le projet.");
    }

    private static int ModeToNum(SlabCalcMode m) => m switch { SlabCalcMode.OneWayX => 2, SlabCalcMode.OneWayY => 3, SlabCalcMode.MassOnly => 4, _ => 1 };
    private static SlabCalcMode NumToMode(double v) => (int)Math.Round(v) switch { 2 => SlabCalcMode.OneWayX, 3 => SlabCalcMode.OneWayY, 4 => SlabCalcMode.MassOnly, _ => SlabCalcMode.Bidirectional };

    /// <summary>Hauteur d'étage modifiée depuis l'arborescence : les niveaux au-dessus, avec leurs nœuds, dalles et charges, suivent.</summary>
    private void AskLevelHeight(int idx, bool below)
    {
        int lower = below ? idx - 1 : idx;
        var info = LevelInfoNow();
        double cur = StoreyOps.HeightAbove(info, lower);
        if (cur <= 0) { Say("Il n'y a pas d'étage à cet endroit."); return; }
        string a = info.Levels[lower].Name, b = info.Levels[lower + 1].Name;
        var v = PromptWindow.Ask(this, "Hauteur d'étage", $"Étage entre « {a} » et « {b} » (actuellement {F3(cur)} m).\nLes niveaux au-dessus, avec leurs nœuds, dalles et charges, sont décalés de la différence.", ("Nouvelle hauteur (m)", F3(cur)));
        if (v == null) return;
        double h = Ui.Num(v[0], double.NaN);
        CommitGrids(); PushUndo();
        if (!StoreyOps.SetHeight(_model, info, lower, h, out string msg)) { _undo.RemoveAt(_undo.Count - 1); UpdateUndoUi(); Say(msg); return; }
        OnModelEdited();
        try { GridSlabs.Items.Refresh(); } catch { }
        _vp.ZoomExtents();
        Say(msg);
    }

    private void SlabProps(SlabPanel s)
    {
        var info = LevelInfoNow();
        int lv = StoreyOps.LevelOf(info, s);
        string levels = string.Join(" ; ", info.Levels.Select(l => $"{l.Index} = {l.Name}"));
        var v = PromptWindow.Ask(this, $"Dalle {s.Name}",
            $"Volume de béton : {F3(s.Volume)} m³ (surface {F2(s.Lx * s.Ly)} m²) ; poids propre {F2(s.SelfWeightKnM2)} kN/m², soit {s.TotalWeightKn:0} kN.\nLes charges surfaciques G et Q de la dalle sont recalculées et la dalle suit son niveau quand les hauteurs d'étage changent.",
            ("Épaisseur h (cm)", (s.H * 100).ToString("0.#", CultureInfo.InvariantCulture)),
            ("Poids volumique γ (kN/m³)", F3(s.Gamma)),
            ("G supplémentaire (kN/m²)", F3(s.GExtra)),
            ("Q exploitation (kN/m²)", F3(s.Q)),
            ("Calcul : 1 = deux sens, 2 = sens X, 3 = sens Y, 4 = métré seul (non chargée)", ModeToNum(s.CalcMode).ToString()),
            ($"Niveau d'attache ({levels})", lv >= 0 ? lv.ToString() : ""),
            ("Chapiteau : côté carré (m), 0 = aucun", F3(s.CapitalSide)),
            ("Chapiteau : surépaisseur sous la dalle (cm)", F3(s.CapitalExtraCm)),
            ("Console : charge linéique de bout, garde-corps (kN/m), 0 = aucune", F3(s.CantileverTipKnM)),
            ("Méthode de calcul : 0 = réglage du projet, " + string.Join(", ", StructCalc.Engine.Structure.SlabMethods.All.Select((a, i) => $"{i + 1} = {a.Label}")),
                (string.IsNullOrEmpty(s.Method) ? 0 : Array.FindIndex(StructCalc.Engine.Structure.SlabMethods.All, a => a.Id == s.Method) + 1).ToString()));
        if (v == null) return;
        CommitGrids(); PushUndo();
        s.H = Math.Max(0.05, Ui.Num(v[0], s.H * 100) / 100.0);
        s.Gamma = Math.Max(1, Ui.Num(v[1], s.Gamma)); s.GExtra = Ui.Num(v[2], s.GExtra); s.Q = Ui.Num(v[3], s.Q);
        s.CalcMode = NumToMode(Ui.Num(v[4], ModeToNum(s.CalcMode)));
        s.CapitalSide = Math.Max(0, Ui.Num(v[6], s.CapitalSide)); s.CapitalExtraCm = Math.Max(0, Ui.Num(v[7], s.CapitalExtraCm));
        s.CantileverTipKnM = Math.Max(0, Ui.Num(v[8], s.CantileverTipKnM));
        int mi = (int)Math.Round(Ui.Num(v[9], 0));
        s.Method = mi >= 1 && mi <= StructCalc.Engine.Structure.SlabMethods.All.Length ? StructCalc.Engine.Structure.SlabMethods.All[mi - 1].Id : "";
        double li = Ui.Num(v[5], double.NaN);
        if (!double.IsNaN(li)) StoreyOps.AttachSlab(_model, info, s, (int)li);
        StoreyOps.SyncSlabLoads(_model, s);
        OnModelEdited();
        try { GridSlabs.Items.Refresh(); } catch { }
        OnSlabSelected(s);
        Log($"Dalle {s.Name} : h = {s.H * 100:0.#} cm, V = {F2(s.Volume)} m³, γ = {s.Gamma:0.##} kN/m³, G = {s.GExtra:0.##}, Q = {s.Q:0.##} kN/m², calcul : {StructurePanel.SlabModeText(s.CalcMode)}, méthode : {(string.IsNullOrEmpty(s.Method) ? "réglage du projet" : StructCalc.Engine.Structure.SlabMethods.Label(s.Method))}.");
    }

    private void DuplicateSlab(SlabPanel s)
    {
        var v = PromptWindow.Ask(this, $"Dupliquer la dalle {s.Name}", "Décalage de la copie (m) : dZ pour l'étage au-dessus, dX / dY pour une dalle voisine.", ("dX (m)", "0"), ("dY (m)", "0"), ("dZ (m)", "3"));
        if (v == null) return;
        double dx = Ui.Num(v[0], 0), dy = Ui.Num(v[1], 0), dz = Ui.Num(v[2], 0);
        if (Math.Abs(dx) + Math.Abs(dy) + Math.Abs(dz) < 1e-9) return;
        CommitGrids(); PushUndo();
        int k = 1; while (_model.Slabs.Any(q => q.Name == "D" + k)) k++;
        var c = new SlabPanel { Name = "D" + k, Lx = s.Lx, Ly = s.Ly, H = s.H, GExtra = s.GExtra, Q = s.Q, Continuity = s.Continuity, Crack = s.Crack, Gamma = s.Gamma, CalcMode = s.CalcMode, Method = s.Method, Placed = true, X0 = s.X0 + dx, Y0 = s.Y0 + dy, Z = s.Z + dz };
        _model.Slabs.Add(c);
        StoreyOps.SyncSlabLoads(_model, c);
        OnModelEdited();
        try { GridSlabs.Items.Refresh(); } catch { }
        _vp.SelectSlab(c);
        Log($"Dalle {c.Name} créée par duplication de {s.Name}.");
    }

    private void DeleteSlabNow(SlabPanel s)
    {
        CommitGrids(); PushUndo();
        _vp.RemoveSlab(s);
        if (ReferenceEquals(_vp.SelectedSlab, s)) _vp.SelectSlab(null);
        OnModelEdited();
        try { GridSlabs.Items.Refresh(); } catch { }
        ShowMember(-1);
        Log($"Dalle {s.Name} supprimée.");
    }

    // ------------------------------------------------------------------ menu d'une barre
    private void FillMemberMenu(ContextMenu cm, int id)
    {
        cm.Items.Clear();
        var mem = _model.Members.FirstOrDefault(m => m.Id == id);
        if (mem == null) return;
        int n = _vp.Selection.Count;
        string sec = mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}";
        cm.Items.Add(MenuTitle(n > 1 ? $"{n} barres sélectionnées" : $"{(mem.Type == MemberType.Column ? "Poteau" : "Poutre")} {id}   {sec}"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Appliquer une charge de la bibliothèque (mur, revêtement...)...", () => ApplyCatalog(0, "members")));
        cm.Items.Add(Mi("Zoom sur la sélection", () => _vp.ZoomSelection()));
        var sel = new MenuItem { Header = "Sélectionner" };
        sel.Items.Add(Mi("Barres de même section", () => _vp.SetSelection(SelectionTools.SelectWhere(_model, "sameSection", id))));
        sel.Items.Add(Mi("Barres du même niveau", () => _vp.SetSelection(SelectionTools.SelectWhere(_model, "sameLevel", id))));
        sel.Items.Add(Mi("Tous les poteaux", () => _vp.SetSelection(SelectionTools.SelectWhere(_model, "columns"))));
        sel.Items.Add(Mi("Toutes les poutres", () => _vp.SetSelection(SelectionTools.SelectWhere(_model, "beams"))));
        sel.Items.Add(Mi("Barres non conformes (après calcul)", () => SelectRule_Click(new MenuItem { Tag = "failing" }, new RoutedEventArgs()), _out != null));
        cm.Items.Add(sel);
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Copier avec décalage...", () => CopySelection_Click(this, new RoutedEventArgs()), true, "C"));
        cm.Items.Add(Mi("Déplacer...", () => MoveSelection_Click(this, new RoutedEventArgs()), true, "M"));
        cm.Items.Add(Mi("Symétrie...", () => MirrorSelection_Click(this, new RoutedEventArgs())));
        cm.Items.Add(Mi("Diviser en tronçons égaux...", DivideSelected));
        cm.Items.Add(Mi("Pivoter la section de 90°", RollSelected90));
        AddMemberPreDesignItems(cm, mem);
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Ajouter des charges sur la sélection (assistant de charges)...", () => LoadAssistant_Click(this, new RoutedEventArgs()), true, "Ctrl+L"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Supprimer", () => DeleteSelection_Click(this, new RoutedEventArgs()), true, "Suppr"));
        AddVisibilityItems(cm);
    }

    private void DivideSelected()
    {
        var v = PromptWindow.Ask(this, "Diviser les barres", $"Coupe chaque barre sélectionnée en tronçons égaux (nouveaux nœuds).", ("Nombre de tronçons", "2"));
        if (v == null) return;
        int parts = (int)Ui.Num(v[0], 2);
        if (parts < 2 || parts > 50) { Say("Nombre de tronçons invalide (2 à 50)."); return; }
        CommitGrids(); PushUndo();
        int c = ModifyTools.DivideEqual(_model, Sel(), parts);
        _vp.ClearSelection();
        OnModelEdited();
        Log($"{c} barre(s) créée(s) par division.");
    }

    private void RollSelected90()
    {
        CommitGrids(); PushUndo();
        foreach (var m in _model.Members.Where(q => _vp.IsSelected(q.Id))) m.Roll = (m.Roll + 90) % 360;
        OnModelEdited();
        Say("Section pivotée de 90° autour de l'axe de la barre.");
    }

    // ------------------------------------------------------------------ menu de la zone vide
    private void FillEmptyMenu(ContextMenu cm, Point at)
    {
        cm.Items.Clear();
        bool flat = true;
        cm.Items.Add(Mi("Ajouter un nœud ici", () => { int id = _vp.AddNodeAtScreen(at); if (id != -1) _vp.SelectNodesOnly(new[] { id }); }, flat));
        cm.Items.Add(Mi("Dessiner des barres (outil Barre)", () => RbMember.IsChecked = true));
        cm.Items.Add(Mi("Dessiner une dalle (outil Dalle, vue Plan)", () => { _vp.SetMode(ViewMode.Plan); RbSlab.IsChecked = true; }));
        cm.Items.Add(Mi("Poser des appuis (outil Appui)", () => RbSupport.IsChecked = true));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Tout sélectionner", () => SelectAll_Click(this, new RoutedEventArgs()), true, "Ctrl+A"));
        cm.Items.Add(Mi("Désélectionner", () => _vp.ClearSelection(), _vp.HasAnySelection, "Échap"));
        var selN = new MenuItem { Header = "Sélectionner les nœuds" };
        selN.Items.Add(Mi("Tous les appuis", () => _vp.SelectNodesOnly(_model.Supports.Select(s => s.NodeId)), _model.Supports.Count > 0));
        selN.Items.Add(Mi("Nœuds isolés (sans barre)", () => _vp.SelectNodesOnly(_model.Nodes.Where(q => !_model.Members.Any(m => m.NodeI == q.Id || m.NodeJ == q.Id)).Select(q => q.Id))));
        selN.Items.Add(Mi("Tous les nœuds", () => _vp.SelectNodesOnly(_model.Nodes.Select(q => q.Id))));
        cm.Items.Add(selN);
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Zoom étendu", () => _vp.ZoomExtents()));
        var views = new MenuItem { Header = "Vue" };
        views.Items.Add(Mi("3D", () => ViewIso_Click(this, new RoutedEventArgs())));
        views.Items.Add(Mi("Plan", () => ViewPlan_Click(this, new RoutedEventArgs())));
        views.Items.Add(Mi("Élévation", () => ViewElev_Click(this, new RoutedEventArgs())));
        views.Items.Add(Mi("Côté", () => ViewSide_Click(this, new RoutedEventArgs())));
        cm.Items.Add(views);
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Annuler la dernière action", () => Undo_Click(this, new RoutedEventArgs()), _undo.Count > 0, "Ctrl+Z"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Tout afficher", ShowAllHidden, _vp.HasHidden || _levelsHiddenNow, "Ctrl+H"));
        var hideC = new MenuItem { Header = "Masquer / réafficher une catégorie" };
        FillCategoryMenus(hideC.Items, false);
        var isoC = new MenuItem { Header = "Isoler une catégorie" };
        FillCategoryMenus(isoC.Items, true);
        cm.Items.Add(hideC); cm.Items.Add(isoC);
        cm.Items.Add(Mi("Inverser l'affichage (masqué ↔ visible)", InvertVisibility, _vp.HasHidden));
    }
}
