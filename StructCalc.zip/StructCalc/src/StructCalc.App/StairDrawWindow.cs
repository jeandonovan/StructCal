using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Fenêtre « Escalier à dessiner » : galerie des 8 types, paramètres principaux ; l'outil Escalier pose ensuite l'escalier par 2 clics en vue Plan
/// (1er clic = départ, 2e clic = direction de montée).</summary>
public sealed class StairDrawWindow : Window
{
    public StairDef Proto { get; }
    public string Prefix { get; private set; } = "E";
    /// <summary>Tracé depuis l'étage : le niveau de travail est l'ARRIVÉE (haut) ; le départ est au niveau inférieur.</summary>
    public bool FromAbove { get; private set; }
    private readonly ContentControl _host = new();

    public StairDrawWindow(StairDef? like, string prefix, bool fromAbove)
    {
        FromAbove = fromAbove;
        Prefix = string.IsNullOrWhiteSpace(prefix) ? "E" : prefix;
        Proto = new StairDef
        {
            Layout = like?.Layout ?? StairLayout.DroitPalier, Usage = like?.Usage ?? StairUsage.Habitation, WidthM = like?.WidthM ?? 1.2,
            HeightM = 0, TargetRiserCm = like?.TargetRiserCm ?? 17, TargetTreadCm = like?.TargetTreadCm ?? 28, EndLandingM = like?.EndLandingM ?? 1.2,
            MidLandingM = like?.MidLandingM ?? 1.2, GapM = like?.GapM ?? 0.10, InnerRadiusM = like?.InnerRadiusM ?? 0.30, TurnAngleDeg = like?.TurnAngleDeg ?? 270,
            StartLandingM = like?.StartLandingM ?? 0, SlabThicknessCm = like?.SlabThicknessCm ?? 0
        };
        Title = "Escalier à dessiner - type et paramètres";
        Width = 560; Height = 700; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        var root = new DockPanel();
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(12) };
        bar.Children.Add(Ui.Btn("Valider et dessiner", (s, e) => DialogResult = true, true));
        bar.Children.Add(new Button { Content = "Annuler", Padding = new Thickness(12, 5, 12, 5), IsCancel = true });
        DockPanel.SetDock(bar, Dock.Bottom); root.Children.Add(bar);
        root.Children.Add(new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _host });
        Content = root;
        Build();
    }

    private UIElement Gallery()
    {
        var d = Proto;
        var wrap = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
        for (int i = 0; i < StairWizardWindow.LayoutItems.Length; i++)
        {
            var (text, lay) = StairWizardWindow.LayoutItems[i];
            bool sel = d.Layout == lay;
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(StairWizardWindow.Picto(lay));
            sp.Children.Add(new TextBlock { Text = StairWizardWindow.LayoutShort[i], FontSize = 11, TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0), FontWeight = sel ? FontWeights.Bold : FontWeights.Normal });
            var card = new System.Windows.Controls.Border
            {
                Width = 100, Height = 82, Margin = new Thickness(0, 0, 5, 5), Padding = new Thickness(3), Cursor = System.Windows.Input.Cursors.Hand,
                BorderThickness = new Thickness(sel ? 2.5 : 1), CornerRadius = new CornerRadius(4), Child = sp, ToolTip = text,
            };
            card.SetResourceReference(System.Windows.Controls.Border.BorderBrushProperty, sel ? "Accent" : "ThemeBorder");
            card.SetResourceReference(System.Windows.Controls.Border.BackgroundProperty, sel ? "ThemeHover" : "ThemeBg");
            var chosen = lay;
            card.MouseLeftButtonUp += (s, e) =>
            {
                if (d.Layout == chosen) return;
                StairWizardWindow.ApplyLayout(d, chosen);
                Dispatcher.BeginInvoke(new Action(Build));
            };
            wrap.Children.Add(card);
        }
        return wrap;
    }

    private void Build()
    {
        var d = Proto; var f = new FormKit();
        f.Section("Type d'escalier", "Cliquez un type, réglez les paramètres, puis posez l'escalier en vue Plan : 1er clic = départ, 2e clic = direction de la montée (angle accroché à 15°).");
        f.Add(Gallery());
        f.Section("Niveau");
        f.Combo("Le niveau de travail est", new (string, bool)[] { ("Le départ (en bas) : l'escalier monte", false), ("L'arrivée (étage) : l'escalier descend vers le niveau inférieur", true) }, () => FromAbove, v => FromAbove = v,
            "Dessiner depuis l'étage : la hauteur = écart entre le niveau de travail et le niveau en dessous");
        f.Section("Paramètres");
        f.Text("Préfixe du nom", () => Prefix, v => Prefix = string.IsNullOrWhiteSpace(v) ? "E" : v.Trim());
        f.Combo("Usage", new (string, StairUsage)[] { ("Habitation", StairUsage.Habitation), ("Bureaux", StairUsage.Bureaux), ("Public", StairUsage.Public), ("Industrie", StairUsage.Industrie) }, () => d.Usage, v => d.Usage = v);
        f.Num("Emmarchement", () => d.WidthM, v => { d.WidthM = Math.Max(0.6, v); if (d.Layout is StairLayout.QuartPalier or StairLayout.DoubleQuartPalier) d.MidLandingM = d.WidthM; }, "Largeur de la volée (1,00 m logement, 1,20 m et plus si public)", "m");
        f.Num("Hauteur à franchir", () => d.HeightM, v => d.HeightM = v < 0.5 ? 0 : v, "0 = jusqu'au niveau supérieur (sinon 3,06 m)", "m");
        f.Num("Contremarche visée", () => d.TargetRiserCm, v => d.TargetRiserCm = Math.Clamp(v, 14, 20), "16 à 18 cm", "cm");
        f.Num("Giron visé", () => d.TargetTreadCm, v => d.TargetTreadCm = v < 20 ? 0 : v, "0 = calculé par Blondel (2h + g ≈ 64 cm)", "cm");
        if (d.Layout != StairLayout.Droit && d.Layout != StairLayout.Helicoidal)
            f.Num("Palier intermédiaire", () => d.MidLandingM, v => d.MidLandingM = Math.Max(d.WidthM, v), "Longueur dans le sens de la volée", "m");
        f.Num("Palier d'arrivée", () => d.EndLandingM, v => d.EndLandingM = Math.Max(0, v), null, "m");
        if (d.Layout == StairLayout.Helicoidal)
        {
            f.Num("Rayon intérieur (jour)", () => d.InnerRadiusM, v => d.InnerRadiusM = Math.Max(0.05, v), null, "m");
            f.Num("Angle total", () => d.TurnAngleDeg, v => d.TurnAngleDeg = Math.Clamp(v, 90, 720), null, "°");
        }
        _host.Content = f.Root;
    }
}
