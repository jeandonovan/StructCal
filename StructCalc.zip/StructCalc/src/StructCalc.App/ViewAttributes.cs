using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace StructCalc.UI;

/// <summary>Attributs d'affichage des vues, à la façon de la fenêtre « Attributs » de Robot Structural Analysis : chaque famille d'objets
/// (nœuds, barres, dalles, charges, cotes, escaliers...) se montre ou se masque indépendamment. Mémorisés d'une session à l'autre.</summary>
public sealed class ViewAttributes
{
    // nœuds
    public bool NodeSymbols { get; set; } = true;       // points des nœuds
    public bool NodeNumbers { get; set; } = true;       // numéros des nœuds
    public bool Supports { get; set; } = true;          // symboles d'appuis
    // barres
    public bool MemberLabels { get; set; } = true;      // numéro et section
    public bool MemberDirection { get; set; }           // flèche du sens i → j
    public bool LocalAxes { get; set; }                 // axes locaux x, y, z au milieu
    // dalles
    public bool Slabs { get; set; } = true;             // contour et remplissage
    public bool SlabNames { get; set; } = true;         // nom et épaisseur
    public bool SlabSpanSymbol { get; set; }            // symbole du sens de portée
    public bool SlabRebarSymbol { get; set; }           // symbole du sens du ferraillage (nappes inférieure et supérieure)
    public bool SlabThickness { get; set; } = true;     // épaisseur visible en 3D
    // charges
    public bool MemberLoads { get; set; } = true;
    public bool SurfaceLoads { get; set; } = true;
    public bool NodalLoads { get; set; } = true;
    public bool LoadValues { get; set; } = true;        // valeurs et cas à côté des charges
    // escaliers
    public bool Stairs { get; set; } = true;
    public bool StairNames { get; set; } = true;

    [JsonIgnore] public bool SpanOrRebar => SlabSpanSymbol || SlabRebarSymbol;

    [JsonIgnore]
    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "attributes.json");

    public static ViewAttributes Load()
    {
        try
        {
            if (File.Exists(FilePath)) return JsonSerializer.Deserialize<ViewAttributes>(File.ReadAllText(FilePath)) ?? new ViewAttributes();
        }
        catch { }
        return new ViewAttributes();
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    public void SetAll(bool on)
    {
        NodeSymbols = NodeNumbers = Supports = MemberLabels = Slabs = SlabNames = SlabThickness = MemberLoads = SurfaceLoads = NodalLoads = LoadValues = Stairs = StairNames = on;
        MemberDirection = LocalAxes = SlabSpanSymbol = SlabRebarSymbol = on;
    }
}
