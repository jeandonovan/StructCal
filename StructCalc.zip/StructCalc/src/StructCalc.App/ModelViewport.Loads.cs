using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Dessin des charges de barre (réparties, trapèzes, ponctuelles, moments, températures) et des charges surfaciques.</summary>
public sealed partial class ModelViewport
{
    private void DrawMemberLoads(Dictionary<int, Node> nodes)
    {
        if (Model == null) return;
        double maxW = 0;
        foreach (var l in Model.MemberLoads)
            maxW = Math.Max(maxW, Math.Max(Math.Sqrt(l.Wx * l.Wx + l.Wy * l.Wy + l.Wz * l.Wz), Math.Sqrt(l.Wx2 * l.Wx2 + l.Wy2 * l.Wy2 + l.Wz2 * l.Wz2)));
        if (maxW < 1e-9) maxW = 1;
        double maxP = 0;
        foreach (var l in Model.MemberLoads) maxP = Math.Max(maxP, Math.Sqrt(l.Px * l.Px + l.Py * l.Py + l.Pz * l.Pz));
        if (maxP < 1e-9) maxP = 1;

        foreach (var grp in Model.MemberLoads.GroupBy(l => l.MemberId))
        {
            var mem = Model.Members.FirstOrDefault(x => x.Id == grp.Key);
            if (mem == null || MemberHidden(mem.Id, GetInfo())) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
            double L; double[,] R;
            try { (L, R) = FrameSolver.LocalAxes(na, nb, mem.Roll); } catch { continue; }
            if (L < 1e-6) continue;
            int lab = 0;
            foreach (var l in grp)
            {
                var br = CaseBrush(l.Case);
                Point P(double s) => S(na.X + (nb.X - na.X) * s / L, na.Y + (nb.Y - na.Y) * s / L, na.Z + (nb.Z - na.Z) * s / L);
                string cs = l.Case.ToString();
                switch (l.Kind)
                {
                    case MemberLoadKind.Uniform:
                    case MemberLoadKind.Trapezoid:
                    {
                        double s0 = 0, s1 = L;
                        if (l.Kind == MemberLoadKind.Trapezoid) { s0 = LoadMath.Pos(l, l.A, L); s1 = LoadMath.Pos(l, l.B, L); if (s1 < s0) (s0, s1) = (s1, s0); }
                        var g0 = LoadMath.GlobalIntensity(l, R, false); var g1 = LoadMath.GlobalIntensity(l, R, true);
                        int cnt = Math.Max(2, (int)(Math.Abs(P(s1).X - P(s0).X) / 26 + Math.Abs(P(s1).Y - P(s0).Y) / 26));
                        cnt = Math.Min(cnt, 40);
                        Point? prev = null;
                        var tails = new List<Point>();
                        for (int i = 0; i <= cnt; i++)
                        {
                            double t = (double)i / cnt, s = s0 + (s1 - s0) * t;
                            var gv = new[] { g0[0] + (g1[0] - g0[0]) * t, g0[1] + (g1[1] - g0[1]) * t, g0[2] + (g1[2] - g0[2]) * t };
                            double mag = Math.Sqrt(gv[0] * gv[0] + gv[1] * gv[1] + gv[2] * gv[2]);
                            if (mag < 1e-9) { prev = null; continue; }
                            var w = W(gv[0] / mag, gv[1] / mag, gv[2] / mag);
                            double dx = w.X, dy = -w.Y, dl = Math.Sqrt(dx * dx + dy * dy);
                            var p = P(s);
                            if (dl < 0.2) { prev = null; continue; }
                            dx /= dl; dy /= dl;
                            double len = (8 + 26 * Math.Min(1, mag / maxW)) * Math.Min(1, dl + 0.3);
                            var tail = new Point(p.X - dx * len, p.Y - dy * len);
                            Arrow(tail, p, br, 1.2);
                            if (prev != null) Ln(prev.Value.X, prev.Value.Y, tail.X, tail.Y, br, 1.2);
                            prev = tail; tails.Add(tail);
                            AddHit(l, tail, new Point(tail.X + (p.X - tail.X) * 0.7, tail.Y + (p.Y - tail.Y) * 0.7));
                        }
                        if (tails.Count > 1) AddHit(l, tails.ToArray());
                        var pm = P((s0 + s1) / 2);
                        double wm = Math.Max(Math.Sqrt(g0[0] * g0[0] + g0[1] * g0[1] + g0[2] * g0[2]), Math.Sqrt(g1[0] * g1[0] + g1[1] * g1[1] + g1[2] * g1[2]));
                        string txt = l.Kind == MemberLoadKind.Trapezoid
                            ? $"{cs} {Math.Sqrt(g0[0] * g0[0] + g0[1] * g0[1] + g0[2] * g0[2]):0.#}→{Math.Sqrt(g1[0] * g1[0] + g1[1] * g1[1] + g1[2] * g1[2]):0.#} kN/m"
                            : $"{cs} {wm:0.#} kN/m";
                        LoadText(l, txt, pm.X - 28, pm.Y - 44 - 12 * lab++, br, null);
                        break;
                    }
                    case MemberLoadKind.Point:
                    {
                        double s = LoadMath.Pos(l, l.A, L);
                        double[] g = l.Frame == LoadFrame.Local ? LoadMath.ToGlobal(R, l.Px, l.Py, l.Pz) : new[] { l.Px, l.Py, l.Pz };
                        double mag = Math.Sqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]);
                        if (mag < 1e-9) break;
                        var w = W(g[0] / mag, g[1] / mag, g[2] / mag);
                        double dx = w.X, dy = -w.Y, dl = Math.Sqrt(dx * dx + dy * dy);
                        var p = P(s);
                        if (dl < 0.2) { LoadText(l, $"{cs} {mag:0.#} kN ⊙", p.X + 4, p.Y - 14, br, null); break; }
                        dx /= dl; dy /= dl;
                        var tail = new Point(p.X - dx * 44, p.Y - dy * 44);
                        Arrow(tail, p, br, 2.4);
                        AddHit(l, tail, new Point(tail.X + (p.X - tail.X) * 0.75, tail.Y + (p.Y - tail.Y) * 0.75));
                        LoadText(l, $"{cs} {mag:0.#} kN" + (l.Relative ? $" à {l.A * 100:0.#}%" : $" à {l.A:0.##} m"), tail.X - 10, tail.Y - 14 - 12 * lab++, br, null);
                        break;
                    }
                    case MemberLoadKind.Moment:
                    {
                        double s = LoadMath.Pos(l, l.A, L);
                        var p = P(s);
                        var el = new Ellipse { Width = 22, Height = 22, Stroke = br, StrokeThickness = 2, Fill = Brushes.Transparent };
                        Canvas.SetLeft(el, p.X - 11); Canvas.SetTop(el, p.Y - 11);
                        _c.Children.Add(el);
                        AddHitRect(l, p.X - 11, p.Y - 11, 22, 22);
                        double mm = Math.Sqrt(l.Mx * l.Mx + l.My * l.My + l.Mz * l.Mz);
                        LoadText(l, $"{cs} M={mm:0.#} kN.m", p.X + 12, p.Y - 20 - 12 * lab++, br, null);
                        break;
                    }
                    case MemberLoadKind.Thermal:
                    {
                        var pm = P(L / 2);
                        LoadText(l, $"{cs} ΔT={l.Dt:0.#}°C" + (Math.Abs(l.Dg) > 1e-9 ? $" grad={l.Dg:0.#}°C" : ""), pm.X - 30, pm.Y - 30 - 12 * lab++, br, null);
                        break;
                    }
                }
            }
        }
    }

    private void DrawSurfaceLoads()
    {
        if (Model == null) return;
        foreach (var s in Model.SurfaceLoads)
        {
            double x0 = Math.Min(s.X0, s.X1), x1 = Math.Max(s.X0, s.X1), y0 = Math.Min(s.Y0, s.Y1), y1 = Math.Max(s.Y0, s.Y1);
            var pts = new PointCollection { S(x0, y0, s.Z), S(x1, y0, s.Z), S(x1, y1, s.Z), S(x0, y1, s.Z) };
            var br = (SolidColorBrush)CaseBrush(s.Case);
            var fill = new SolidColorBrush(Color.FromArgb(38, br.Color.R, br.Color.G, br.Color.B));
            _c.Children.Add(new Polygon { Points = pts, Fill = fill, Stroke = br, StrokeThickness = 1, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false });
            var c = S((x0 + x1) / 2, (y0 + y1) / 2, s.Z);
            string d = s.Distribution == SurfaceDistribution.TwoWay ? "" : (s.Distribution == SurfaceDistribution.OneWayX ? " ↔X" : " ↕Y");
            AddHit(s, pts[0], pts[1], pts[2], pts[3], pts[0]);
            LoadText(s, $"{s.Case} {s.Q:0.##} kN/m²{d}", c.X - 34, c.Y - 7, br, Br("#99FFFFFF"));
            // petites flèches de charge en vue 3D / élévation
            if (Mode != ViewMode.Plan)
            {
                var w = W(0, 0, -1); double dx = w.X, dy = -w.Y, dl = Math.Sqrt(dx * dx + dy * dy);
                if (dl > 0.2)
                    for (int i = 0; i < 2; i++)
                        for (int j = 0; j < 2; j++)
                        {
                            var p = S(x0 + (x1 - x0) * (0.25 + 0.5 * i), y0 + (y1 - y0) * (0.25 + 0.5 * j), s.Z);
                            Arrow(new Point(p.X - dx / dl * 22, p.Y - dy / dl * 22), p, br, 1.1);
                        }
            }
        }
    }
}
