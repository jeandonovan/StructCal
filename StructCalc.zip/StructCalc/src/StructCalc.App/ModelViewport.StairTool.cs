using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using StructCalc.Core.Model;
using StructCalc.Engine.Stairs;

namespace StructCalc.UI;

/// <summary>Outil « Escalier » : 1er clic = point de départ, 2e clic = direction de la montée (angle accroché à 15°) ; aperçu élastique.</summary>
public partial class ModelViewport
{
    private (double U, double V)? _stairA;

    /// <summary>Escalier modèle (type et paramètres choisis dans la fenêtre « Escalier à dessiner »).</summary>
    public StairDef? StairProto { get; set; }

    /// <summary>Un escalier vient d'être posé : x, y du départ (m), angle (°) et cote z du plancher bas (m).</summary>
    public event Action<double, double, double, double>? StairDrawn;

    private static double StairAngle((double U, double V) a, SnapHit h)
    {
        double dx = h.U - a.U, dy = h.V - a.V;
        if (Math.Sqrt(dx * dx + dy * dy) < 0.05) return 0;
        return Math.Round(Math.Atan2(dy, dx) * 180 / Math.PI / 15.0) * 15.0;
    }

    private void HandleStairClick(Point p)
    {
        if (Mode != ViewMode.Plan) { Hint?.Invoke("Escalier : passez en vue Plan (le niveau de travail donne la cote du plancher bas)."); return; }
        var hit = ComputeSnap(p);
        if (hit == null) return;
        if (_stairA == null)
        {
            _stairA = (hit.U, hit.V);
            Hint?.Invoke("Escalier : cliquez un second point pour donner la direction de la montée (même point = direction +X ; Échap pour annuler).");
            Redraw();
            return;
        }
        var a = _stairA.Value; _stairA = null;
        StairDrawn?.Invoke(a.U, a.V, StairAngle(a, hit), WorkOffset);
        Redraw();
    }

    private void DrawStairRubber()
    {
        if (Tool != EditTool.Stair || StairProto == null || !_cursorValid || Mode != ViewMode.Plan) return;
        var hit = ComputeSnap(_cursor);
        if (hit == null) return;
        var a = _stairA ?? (hit.U, hit.V);
        var d = StairProto.Clone();
        d.X = a.U; d.Y = a.V; d.Z = WorkOffset;
        d.AngleDeg = _stairA == null ? 0 : StairAngle(a, hit);
        if (d.HeightM < 0.5) d.HeightM = 3.06;
        List<StairFace> faces;
        try { faces = StairShape.Build(d); } catch { return; }
        var fill = new SolidColorBrush(Color.FromArgb(70, 0xE6, 0x51, 0x00)); fill.Freeze();
        var edge = Br("#E65100");
        foreach (var f in faces)
        {
            if (f.Kind is StairFaceKind.Riser or StairFaceKind.Waist or StairFaceKind.Rail) continue;
            _c.Children.Add(new Polygon { Points = new PointCollection(f.Pts.Select(v => S(v.X, v.Y, v.Z))), Fill = fill, Stroke = edge, StrokeThickness = 1.1, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false });
        }
        var p0 = S(a.U, a.V, WorkOffset);
        if (_stairA != null) _c.Children.Add(new Line { X1 = p0.X, Y1 = p0.Y, X2 = S(hit.U, hit.V, WorkOffset).X, Y2 = S(hit.U, hit.V, WorkOffset).Y, Stroke = edge, StrokeThickness = 1.2, IsHitTestVisible = false });
        Text(_stairA == null ? "Départ ?" : $"{d.AngleDeg:0}°", p0.X + 8, p0.Y - 18, 11, edge, null, true);
    }
}
