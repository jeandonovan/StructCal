using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using StructCalc.Engine.Results;

namespace StructCalc.UI;

/// <summary>Sources d'affichage des résultats (cas, combinaisons, enveloppes, modes), animation de la déformée et explorateur de résultats.</summary>
public partial class MainWindow
{
    private bool _fillingSources;
    private DispatcherTimer? _animTimer;
    private double _animT;
    private ResultsExplorerWindow? _explorer;
    private ResultsStore? _hookedStore;

    private void FillSourceCombos()
    {
        if (ComboSource == null || ComboDeform == null) return;
        _fillingSources = true;
        try
        {
            string keepSrc = ComboSource.SelectedItem as string ?? ResultsStore.EnvUls;
            string keepDef = ComboDeform.SelectedItem as string ?? "";
            ComboSource.Items.Clear(); ComboDeform.Items.Clear();
            var st = _out?.Store;
            if (st == null) { _vp.DiagramSource = ResultsStore.EnvUls; _vp.DeformSource = ""; return; }
            foreach (var s in st.ForceSources()) ComboSource.Items.Add(s);
            ComboDeform.Items.Add("Service le plus défavorable (par défaut)");
            foreach (var s in st.DeformSources()) ComboDeform.Items.Add(s);
            ComboSource.SelectedItem = ComboSource.Items.Contains(keepSrc) ? keepSrc : ResultsStore.EnvUls;
            ComboDeform.SelectedItem = ComboDeform.Items.Contains(keepDef) ? keepDef : ComboDeform.Items[0];
            _vp.DiagramSource = ComboSource.SelectedItem as string ?? ResultsStore.EnvUls;
            _vp.DeformSource = ComboDeform.SelectedIndex <= 0 ? "" : ComboDeform.SelectedItem as string ?? "";
            if (!ReferenceEquals(_hookedStore, st))
            {
                if (_hookedStore != null) _hookedStore.ModalChanged -= OnModalChanged;
                _hookedStore = st; st.ModalChanged += OnModalChanged;
            }
        }
        finally { _fillingSources = false; }
    }

    private void OnModalChanged() => Dispatcher.BeginInvoke(new Action(() => { FillSourceCombos(); _vp.Redraw(); }));

    private void Animate_Changed(object sender, RoutedEventArgs e)
    {
        if (ChkAnimate == null || _vp == null) return;
        if (ChkAnimate.IsChecked == true)
        {
            ChkDeformed.IsChecked = true;
            _animTimer ??= new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(60) };
            _animTimer.Tick -= AnimTick; _animTimer.Tick += AnimTick;
            _animT = 0; _animTimer.Start();
        }
        else
        {
            _animTimer?.Stop();
            _vp.DeformPhase = 1.0; _vp.Redraw();
        }
    }

    private void AnimTick(object? sender, EventArgs e)
    {
        _animT += 0.35;
        _vp.DeformPhase = Math.Sin(_animT);
        _vp.Redraw();
    }

    private void ResultsExplorer_Click(object sender, RoutedEventArgs e)
    {
        if (_out == null || _out.Store == null)
        {
            MessageBox.Show("Lancez d'abord le calcul (F5).", "Explorateur de résultats", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (_explorer != null) { _explorer.Refresh(_model, _out, _vp.SelectedId); _explorer.Activate(); return; }
        _explorer = new ResultsExplorerWindow(_model, _out, _vp.SelectedId) { Owner = this };
        _explorer.Closed += (s, a) => _explorer = null;
        _explorer.Show();
    }
}
