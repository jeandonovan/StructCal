using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Licensing;

namespace StructCalc.UI;

/// <summary>Fenêtre de licence : état, identifiant du poste, demande de licence (copie, WhatsApp, e-mail), import d'une licence signée.</summary>
public sealed class LicenseWindow : Window
{
    private readonly TextBlock _msg = new() { TextWrapping = TextWrapping.Wrap, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 10, 0, 10), FontSize = 13 };
    private readonly TextBox _name = new() { Padding = new Thickness(5), Margin = new Thickness(0, 2, 0, 8) };
    private readonly TextBox _phone = new() { Padding = new Thickness(5), Margin = new Thickness(0, 2, 0, 8) };
    private readonly TextBox _idBox = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 20, Margin = new Thickness(0, 4, 0, 10), Padding = new Thickness(8) };

    public LicenseWindow(LicenseStatus st)
    {
        Title = "StructCalc - Licence et activation";
        Width = 640; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        var accent = Application.Current?.TryFindResource("Accent") as Brush ?? Brushes.SteelBlue;

        var sp = new StackPanel { Margin = new Thickness(24, 20, 24, 20) };
        sp.Children.Add(new TextBlock { Text = AppInfo.Name + " " + AppInfo.Version, FontSize = 24, FontWeight = FontWeights.Bold, Foreground = accent });
        sp.Children.Add(new TextBlock { Text = AppInfo.Copyright, Foreground = Brushes.Gray });

        _msg.Text = (st.IsCreator ? "★ " : st.IsFull ? "✔ " : "") + st.Message;
        _msg.Foreground = !st.CanRun ? Brushes.Firebrick : st.IsFull ? Brushes.DarkGreen : Brushes.DarkOrange;
        sp.Children.Add(_msg);

        sp.Children.Add(new TextBlock { Text = "Identifiant de ce poste (la licence est liée à cet ordinateur)", FontWeight = FontWeights.SemiBold });
        _idBox.Text = LicenseManager.MachineId();
        sp.Children.Add(_idBox);

        sp.Children.Add(new TextBlock { Text = "Pour demander une licence, indiquez votre nom (ou société) et votre téléphone :", TextWrapping = TextWrapping.Wrap });
        sp.Children.Add(new TextBlock { Text = "Nom / société", Margin = new Thickness(0, 6, 0, 0) });
        sp.Children.Add(_name);
        sp.Children.Add(new TextBlock { Text = "Téléphone / WhatsApp" });
        sp.Children.Add(_phone);

        var row1 = new WrapPanel();
        row1.Children.Add(Btn("Copier la demande", (s, e) => { Clipboard.SetText(Request()); _msg.Text = "Demande copiée : collez-la dans un message à l'auteur."; }));
        row1.Children.Add(Btn("Envoyer par WhatsApp", (s, e) => Open($"https://wa.me/{AppInfo.WhatsAppNumber}?text={Uri.EscapeDataString(Request())}")));
        row1.Children.Add(Btn("Envoyer par e-mail", (s, e) => Open($"mailto:{AppInfo.Email}?subject={Uri.EscapeDataString("Demande de licence StructCalc")}&body={Uri.EscapeDataString(Request())}")));
        sp.Children.Add(row1);

        var row2 = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        row2.Children.Add(Btn("Importer une licence (.lic)...", (s, e) =>
        {
            var dlg = new OpenFileDialog { Filter = "Licence StructCalc (*.lic)|*.lic" };
            if (dlg.ShowDialog() != true) return;
            bool ok = LicenseManager.Install(dlg.FileName, out string msg);
            _msg.Text = msg;
            _msg.Foreground = ok ? Brushes.DarkGreen : Brushes.Firebrick;
            if (ok) DialogResult = true;
        }, true));
        row2.Children.Add(Btn(st.CanRun ? "Fermer" : "Quitter", (s, e) => { DialogResult = st.CanRun; }));
        sp.Children.Add(row2);

        sp.Children.Add(new TextBlock
        {
            Text = "Contact de l'auteur :\n" + AppInfo.Author + "\n" + AppInfo.Email + "\n" + AppInfo.Phones,
            Margin = new Thickness(0, 16, 0, 0), Foreground = Brushes.DimGray
        });
        Content = sp;
    }

    private string Request() =>
        "Bonjour, je souhaite une licence " + AppInfo.Name + " " + AppInfo.Version + ".\n" +
        "Nom / société : " + _name.Text.Trim() + "\n" +
        "Téléphone : " + _phone.Text.Trim() + "\n" +
        "Identifiant du poste : " + _idBox.Text + "\n" +
        "Merci de m'indiquer le tarif et le mode de paiement.";

    private void Open(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
        catch (Exception ex) { _msg.Text = "Impossible d'ouvrir le lien : " + ex.Message + " (utilisez « Copier la demande »)."; }
    }

    private static Button Btn(string text, RoutedEventHandler h, bool primary = false)
    {
        var b = new Button { Content = text, Padding = new Thickness(12, 7, 12, 7), Margin = new Thickness(0, 0, 8, 0) };
        if (primary && Application.Current?.TryFindResource("PrimaryBtn") is Style st) b.Style = st;
        b.Click += h;
        return b;
    }
}
