using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Radiers généraux : liste, cote du dessus, épaisseur, enrobage et rectangles du contour ; note de calcul du dernier calcul (F5).
/// Les radiers venant de Revit y sont modifiables : la cote, l'épaisseur et les rectangles se corrigent ici sans repasser par Revit.</summary>
public sealed class RaftWizardWindow : Window
{
    private readonly Func<StructModel> _get;
    private StructModel _model => _get();
    private readonly Func<AnalysisOutput?> _out;
    private readonly Func<Func<StructModel, string>, string> _apply;
    private RaftDef _r = new();
    private int _pIdx;
    private readonly ComboBox _list = new() { Width = 200 };
    private readonly ScrollViewer _formHost = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly TextBox _report = new() { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(8), TextWrapping = TextWrapping.NoWrap };
    private readonly TextBlock _status = new() { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
    private FormKit _form = null!;
    private bool _busy;

    public RaftWizardWindow(Func<StructModel> model, Func<AnalysisOutput?> output, Func<Func<StructModel, string>, string> apply)
    {
        _get = model; _out = output; _apply = apply;
        Title = "Radier général (dalle de fondation sur le sol)";
        Width = 1100; Height = 720; WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;
        _r = _model.Rafts.FirstOrDefault()?.Clone() ?? NewRaft();

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(440) });
        root.ColumnDefinitions.Add(new ColumnDefinition());
        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10, 8, 10, 6) };
        bar.Children.Add(new TextBlock { Text = "Radier :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0), FontWeight = FontWeights.SemiBold });
        bar.Children.Add(_list);
        bar.Children.Add(new Border { Width = 8 });
        bar.Children.Add(Ui.Btn("➕ Nouveau", (s, e) => { _r = NewRaft(); _pIdx = 0; FillList(); RebuildForm(); ShowReport(); }));
        bar.Children.Add(Ui.Btn("💾 Enregistrer", (s, e) => Save(), true));
        bar.Children.Add(Ui.Btn("🗑 Supprimer", (s, e) => Delete()));
        bar.Children.Add(Ui.Btn("Fermer", (s, e) => Close()));
        bar.Children.Add(_status);
        Grid.SetColumnSpan(bar, 2); root.Children.Add(bar);
        Grid.SetRow(_formHost, 1); root.Children.Add(_formHost);
        var tabs = new TabControl { Margin = new Thickness(4) };
        tabs.Items.Add(new TabItem { Header = "Note de calcul (dernier calcul F5)", Content = _report });
        Grid.SetRow(tabs, 1); Grid.SetColumn(tabs, 1); root.Children.Add(tabs);
        Content = root;
        _list.SelectionChanged += (s, e) =>
        {
            if (_busy) return; int i = _list.SelectedIndex;
            if (i >= 0 && i < _model.Rafts.Count) { _r = _model.Rafts[i].Clone(); _pIdx = 0; RebuildForm(); ShowReport(); }
        };
        FillList(); RebuildForm(); ShowReport();
    }

    private RaftDef NewRaft()
    {
        int n = 1; while (_model.Rafts.Any(x => x.Name == "R" + n)) n++;
        var r = new RaftDef { Name = "R" + n, H = 0.40, CoverCm = 5 };
        var m = _model;
        if (m.Nodes.Count > 0)
        {
            double zmin = m.Nodes.Min(q => q.Z);
            var low = m.Nodes.Where(q => Math.Abs(q.Z - zmin) < 0.05).ToList();
            double x0 = low.Min(q => q.X) - 0.5, x1 = low.Max(q => q.X) + 0.5, y0 = low.Min(q => q.Y) - 0.5, y1 = low.Max(q => q.Y) + 0.5;
            r.ZTop = Math.Round(zmin, 3);
            r.Panels.Add(new RaftPanel { X0 = Math.Round(x0, 2), Y0 = Math.Round(y0, 2), Lx = Math.Round(x1 - x0, 2), Ly = Math.Round(y1 - y0, 2) });
        }
        else r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 10, Ly = 10 });
        return r;
    }

    private void FillList()
    {
        _busy = true; _list.Items.Clear();
        foreach (var x in _model.Rafts) _list.Items.Add($"{x.Name} ({x.Area:0.0} m², h={x.H * 100:0} cm)");
        if (!_model.Rafts.Any(x => x.Name == _r.Name)) _list.Items.Add($"{_r.Name} (nouveau)");
        int idx = _model.Rafts.FindIndex(x => x.Name == _r.Name);
        _list.SelectedIndex = idx >= 0 ? idx : _list.Items.Count - 1;
        _busy = false;
    }

    private void RebuildForm()
    {
        _form = new FormKit();
        var r = _r;
        _form.Section("Radier", "Le radier est supposé rigide : pression de sol linéaire sous les poteaux et voiles posés dessus. Il remplace les semelles isolées de ces poteaux.");
        _form.Text("Nom", () => r.Name, v => r.Name = v);
        _form.Num("Cote du dessus", () => r.ZTop, v => r.ZTop = v, "Les appuis à moins de 1 m de cette cote le chargent", "m");
        _form.Num("Épaisseur", () => r.H, v => r.H = v, "Vérifiée au poinçonnement (épaisseur minimale donnée dans la note)", "m");
        _form.Num("Enrobage (axe des aciers)", () => r.CoverCm, v => r.CoverCm = v, "5 cm contre le sol (sur béton de propreté)", "cm");
        _form.Section("Contour (rectangles)", "Un contour quelconque se compose de plusieurs rectangles ; les trous (puits, fosses) sont laissés vides.");
        if (r.Panels.Count == 0) r.Panels.Add(new RaftPanel { X0 = 0, Y0 = 0, Lx = 10, Ly = 10 });
        _pIdx = Math.Min(_pIdx, r.Panels.Count - 1);
        _form.Combo("Rectangle à éditer", r.Panels.Select((p, i) => ($"{i + 1} : {p.Lx:0.0} x {p.Ly:0.0} m", i)).ToList(), () => _pIdx, v => { _pIdx = v; RebuildForm(); });
        var pn = r.Panels[_pIdx];
        _form.Num("Coin X0", () => pn.X0, v => pn.X0 = v, null, "m");
        _form.Num("Coin Y0", () => pn.Y0, v => pn.Y0 = v, null, "m");
        _form.Num("Largeur (X)", () => pn.Lx, v => pn.Lx = v, null, "m");
        _form.Num("Longueur (Y)", () => pn.Ly, v => pn.Ly = v, null, "m");
        _form.Add(Ui.Btn("➕ Ajouter un rectangle", (s, e) => { var last = r.Panels[^1]; r.Panels.Add(new RaftPanel { X0 = last.X0 + last.Lx, Y0 = last.Y0, Lx = 2, Ly = last.Ly }); _pIdx = r.Panels.Count - 1; RebuildForm(); }));
        _form.Add(Ui.Btn("➖ Supprimer ce rectangle", (s, e) => { if (r.Panels.Count > 1) { r.Panels.RemoveAt(_pIdx); _pIdx = 0; RebuildForm(); } }));
        _form.Add(new TextBlock { Text = $"Surface totale : {r.Area:0.0} m²" + (string.IsNullOrEmpty(r.ExternalId) ? "" : $" ; lié à Revit (#{r.ExternalId})"), Margin = new Thickness(4, 8, 4, 4), FontWeight = FontWeights.SemiBold });
        _form.Section("Murs posés sur le radier", "Murs de la bibliothèque (maçonnerie, façade, cloison lourde) en plus des poteaux et voiles du modèle. G + Q en kN/m, ELU 1,35 G + 1,5 Q.");
        foreach (var ll in r.LineLoads.ToList())
        {
            var item = ll;
            _form.Add(new TextBlock { Text = $"• {item.Text} : ({item.X1:0.##} ; {item.Y1:0.##}) → ({item.X2:0.##} ; {item.Y2:0.##}), L = {item.Length:0.##} m, G = {item.GKnM:0.##}, Q = {item.QKnM:0.##} kN/m", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4, 2, 4, 2) });
            _form.Add(Ui.Btn("➖ Retirer ce mur", (s, e) => { r.LineLoads.Remove(item); RebuildForm(); }));
        }
        _form.Add(Ui.Btn("➕ Ajouter un mur depuis la bibliothèque...", (s, e) =>
        {
            var a = FoundationLineLoads.Ask(this, true);
            if (a == null) return;
            r.LineLoads.Add(new RaftLineLoad { Text = a.Text, GKnM = a.G, QKnM = a.Q, X1 = a.X1, Y1 = a.Y1, X2 = a.X2, Y2 = a.Y2 });
            RebuildForm();
        }));
        _formHost.Content = _form.Root;
    }

    private void ShowReport()
    {
        var o = _out();
        var res = o?.Rafts.FirstOrDefault(q => q.Def.Name == _r.Name);
        _report.Text = res != null ? res.Report : "Aucun résultat pour ce radier : enregistrez puis lancez le calcul (F5).\n\nLe radier reprend les charges des poteaux appuyés à sa cote (réactions d'appui) et des voiles posés dessus.";
        _status.Text = res == null ? "" : (res.Ok ? "✔ conforme" : "⚠ " + (res.Design.Warnings.FirstOrDefault() ?? "À vérifier"));
        _status.Foreground = res != null && res.Ok ? Brushes.DarkGreen : Brushes.Firebrick;
    }

    private void Save()
    {
        var c = _r.Clone();
        string old = _model.Rafts.FirstOrDefault(x => x.ExternalId == c.ExternalId && c.ExternalId != "")?.Name ?? c.Name;
        _status.Text = _apply(m =>
        {
            int i = m.Rafts.FindIndex(x => x.Name == old);
            if (i >= 0) m.Rafts[i] = c; else m.Rafts.Add(c);
            return $"Radier {c.Name} enregistré (calcul F5).";
        });
        _status.Foreground = Brushes.DarkGreen; FillList();
    }

    private void Delete()
    {
        string n = _r.Name; if (!_model.Rafts.Any(x => x.Name == n)) return;
        _apply(m => { m.Rafts.RemoveAll(x => x.Name == n); return $"Radier {n} supprimé."; });
        _r = _model.Rafts.FirstOrDefault()?.Clone() ?? NewRaft(); FillList(); RebuildForm(); ShowReport();
    }
}
