using System.IO;
using System.Linq;
using System.Windows;
using StructCalc.Engine;

namespace StructCalc.UI;

public partial class MainWindow
{
    /// <summary>Met à jour le projet courant depuis le dernier export Revit, sans doublon : éléments appariés par identifiant Revit,
    /// charges et appuis saisis conservés, éléments disparus de Revit signalés (jamais supprimés automatiquement).</summary>
    private void MergeRevitModel_Click(object sender, RoutedEventArgs e)
    {
        if (!File.Exists(RevitLink.FromRevit))
        {
            MessageBox.Show("Aucun modèle reçu de Revit pour l'instant.\nDans Revit : onglet Compléments > StructCalc > « Envoyer vers StructCalc ».", "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        StructCalc.Core.Model.StructModel incoming;
        try { incoming = ModelIO.Load(RevitLink.FromRevit); }
        catch (Exception ex) { MessageBox.Show("Le fichier reçu de Revit est illisible : " + ex.Message, "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Warning); return; }

        if (!_model.Members.Any(x => !string.IsNullOrEmpty(x.ExternalId)) && !_model.Slabs.Any(x => !string.IsNullOrEmpty(x.ExternalId)) && !_model.Walls.Any(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            MessageBox.Show("Ce projet n'a encore aucun élément lié à Revit : il n'y a rien à mettre à jour.\nUtilisez « Importer le dernier modèle reçu de Revit » pour une première importation.", "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var preview = RevitSync.Diff(_model, incoming);
        if (!preview.HasChanges) { Say("Mise à jour Revit : aucune différence (" + preview.Unchanged + " élément(s) identiques)."); return; }
        if (MessageBox.Show(preview.Details() + "\n\nAppliquer ces changements au projet ?\n(Charges, appuis et hypothèses saisis dans StructCalc sont conservés ; Ctrl+Z pour revenir.)",
                "StructCalc - Mise à jour depuis Revit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        PushUndo();
        var rep = RevitSync.Merge(_model, incoming);
        _vp.ClearAllSelection();
        OnModelEdited();
        Say("Mise à jour depuis Revit : " + rep.Summary() + (rep.Removed.Count > 0 ? " Des éléments absents de Revit sont conservés : à vérifier." : "") + " Relancez le calcul (F5).");
    }

    /// <summary>Dépose le modèle courant dans le dossier d'échange : dans Revit, la commande « Créer le modèle » y crée poteaux, poutres et dalles.</summary>
    private void SendModelToRevit_Click(object sender, RoutedEventArgs e)
    {
        int steel = _model.Members.Count(x => x.Kind != StructCalc.Core.MaterialKind.ReinforcedConcrete);
        int lacking = _model.Stairs.Count + _model.FootingDefs.Count + _model.RibbedFloors.Count;
        string txt = $"{_model.Members.Count - steel} barre(s) béton et {_model.Slabs.Count(x => x.Placed)} dalle(s) placée(s), {_model.Walls.Count} voile(s) et {_model.Rafts.Count} radier(s) seront proposés à Revit.\n\n" +
                     "Non créés par cette version : escaliers, semelles (créées ensuite par « Créer armatures », à partir des réactions), planchers nervurés, poteaux inclinés, barres acier" + (lacking > 0 ? $" ({lacking} escalier/semelle/plancher dans ce projet)" : "") + ".\n\nDans Revit : onglet Compléments > StructCalc > « Créer le modèle »." +
                     "\nPuis ici : Fichier > « Reprendre les identifiants des éléments créés dans Revit ».";
        if (MessageBox.Show(txt, "StructCalc - Envoyer le modèle à Revit", MessageBoxButton.OKCancel, MessageBoxImage.Information) != MessageBoxResult.OK) return;
        try { ModelIO.Save(_model, RevitLink.ModelToRevit); Say("Modèle déposé pour Revit. Dans Revit : Compléments > StructCalc > « Créer le modèle »."); }
        catch (Exception ex) { MessageBox.Show("Envoi impossible : " + ex.Message, "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    /// <summary>Relie les éléments du projet à ceux que Revit vient de créer : les mises à jour et résultats suivants se font sans doublon.</summary>
    private void TakeCreatedIds_Click(object sender, RoutedEventArgs e)
    {
        if (!File.Exists(RevitLink.CreatedIds))
        {
            MessageBox.Show("Aucun compte rendu de création reçu de Revit.\nDans Revit : Compléments > StructCalc > « Créer le modèle ».", "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        StructCalc.Engine.CreatedIdsFile f;
        try { f = StructCalc.Engine.CreatedIdsFile.Load(RevitLink.CreatedIds); }
        catch (Exception ex) { MessageBox.Show("Fichier illisible : " + ex.Message, "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        PushUndo();
        int n = f.ApplyTo(_model);
        OnModelEdited();
        Say($"{n} élément(s) liés à Revit." + (f.Notes.Count > 0 ? " Remarques de Revit : " + string.Join(" ; ", f.Notes.Take(3)) : ""));
    }
}
