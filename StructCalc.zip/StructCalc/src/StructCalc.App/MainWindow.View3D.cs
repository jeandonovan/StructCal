using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Vue 3D : styles d'affichage, niveaux et axes détectés, arborescence de la structure, navigation.</summary>
public partial class MainWindow
{
    private StructurePanel? _panel;
    private bool _structQueued;

    private string BaseStatusMid() => $"{_model.Nodes.Count} nœuds · {_model.Members.Count} barres" + (_vp != null && _vp.HasHidden ? "  ·  " + _vp.HiddenSummary() + " (Ctrl+H : tout afficher)" : "");

    private void InitStructurePanel()
    {
        var panel = new StructurePanel();
        _panel = panel;
        StructureHost.Child = panel;
        _vp.HiddenLevels = panel.Hidden;
        _vp.HoverChanged += s => StatusMid.Text = s != "" ? s : BaseStatusMid();
        _vp.PerspectiveRequested += on => ChkPersp.IsChecked = on;

        panel.MemberChosen += id =>
        {
            _vp.SelectedId = id; _vp.HighlightAxis = ""; _vp.HighlightLevel = -1;
            _vp.Redraw();
            ShowMember(id);
            if (GridResults.ItemsSource is List<ResultRow> rows)
            {
                var row = rows.FirstOrDefault(r => r.Barre == id);
                GridResults.SelectedItem = row;
            }
        };
        panel.LevelChosen += idx =>
        {
            _vp.SelectedId = -1; _vp.HighlightAxis = ""; _vp.HighlightLevel = idx;
            _vp.ZoomToLevel(idx);
            ShowMember(-1);
        };
        panel.AxisChosen += name =>
        {
            _vp.HighlightAxis = name; _vp.HighlightLevel = -1;
            _vp.Redraw();
        };
        panel.VisibilityChanged += () => _vp.Redraw();
        panel.GroupChosen += (ids, label) =>
        {
            _vp.HighlightAxis = ""; _vp.HighlightLevel = -1;
            _vp.SetSelection(ids, false);
            _vp.Redraw();
            if (ids.Count > 1) ShowGroup(); else ShowMember(ids.Count == 1 ? ids[0] : -1);
            StatusLeft.Text = ids.Count == 0 ? "Aucun élément à sélectionner." : $"{ids.Count} élément(s) sélectionné(s) : {label}. Ctrl+C / outils de modification ou touches M, C, R.";
        };
        panel.AddLevelRequested += AskAddLevel;
        panel.RenameLevelRequested += AskRename;
        panel.CopyLevelRequested += AskCopy;
        panel.WorkPlaneRequested += idx =>
        {
            var lv = panel.Structure.Levels.ElementAtOrDefault(idx);
            if (lv == null) return;
            WorkBox.Text = lv.Z.ToString("0.###", CultureInfo.InvariantCulture);
            _vp.WorkOffset = lv.Z;
            StatusLeft.Text = $"Plan de travail : {lv.Label}. Les nouveaux nœuds seront posés à cette cote en vue Plan.";
        };
    }

    /// <summary>Reconstruit l'arborescence (regroupe les demandes successives en une seule).</summary>
    private void RefreshStructure()
    {
        if (_panel == null || _structQueued) return;
        _structQueued = true;
        Dispatcher.BeginInvoke(new Action(() =>
        {
            _structQueued = false;
            try { _panel.Refresh(_model, _out); RefreshLevelCombo(); } catch (Exception ex) { Log("Arborescence : " + ex.Message); }
            _vp.Redraw();
        }), DispatcherPriority.Background);
    }

    private bool _syncing3D;

    private void View3DOption_Changed(object sender, RoutedEventArgs e)
    {
        if (_syncing3D) return;
        if (_vp == null || ComboStyle == null || ChkGrid == null || ChkLevels == null || ChkShadows == null || ChkPersp == null || ChkOrbitSel == null || ChkFootings == null || ChkGlacis == null || ComboFootPos == null) return;
        _vp.ShowFootings = ChkFootings.IsChecked == true;
        if (_model != null)
        {
            _model.FootingGlacis = ChkGlacis.IsChecked == true;
            int i = Math.Max(0, ComboFootPos.SelectedIndex);
            int[] ax = { 0, 1, -1, 0, 0, 1, -1, 1, -1 }, ay = { 0, 0, 0, 1, -1, 1, 1, -1, -1 };
            _model.FootingAlignX = ax[i]; _model.FootingAlignY = ay[i];
        }
        _vp.ShowGrid = ChkGrid.IsChecked == true;
        _vp.ShowLevels = ChkLevels.IsChecked == true;
        _vp.ShowShadows = ChkShadows.IsChecked == true;
        _vp.Perspective = ChkPersp.IsChecked == true;
        _vp.OrbitOnSelection = ChkOrbitSel.IsChecked == true;
        _vp.RenderStyle = (DisplayStyle)Math.Max(0, ComboStyle.SelectedIndex);    // redessine
    }

    private void StyleMenu_Click(object sender, RoutedEventArgs e)
    {
        if (sender is MenuItem mi && int.TryParse(mi.Tag as string, out int i)) ComboStyle.SelectedIndex = i;
    }

    private void ZoomSel_Click(object sender, RoutedEventArgs e) => _vp.ZoomSelection();
}
