using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Selection;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Sélection centrale côté fenêtre : barre de sélection (nombre, types, masqués / hors vue) et ses actions — zoom, masquer, isoler, supprimer (avec confirmation),
/// propriétés, messages et résultats associés —, menu contextuel commun, commandes « Toutes les dalles... » et filtre. Le tout agit sur la MÊME sélection,
/// quelle que soit la vue dans laquelle elle a été faite.</summary>
public partial class MainWindow
{
    private Border? _selBar;
    private TextBlock? _selText;
    private readonly List<(Border Chip, Func<bool> Enabled)> _selChips = new();
    private HashSet<ElementKey>? _msgKeyFilter;

    private static Brush FB(byte r, byte g, byte b, byte a = 255) => Theme.Fixed(Color.FromArgb(a, r, g, b));

    // ------------------------------------------------------------------ barre de sélection
    private void InitElementSelection()
    {
        _vp.ElementSelectionChanged += OnElementSelection;
        _vp.ElementSelectionRefresh += RefreshSelectionBar;
        var panel = new StackPanel { Orientation = Orientation.Horizontal };
        _selText = new TextBlock { Foreground = FB(255, 255, 255), FontSize = 12, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 0, 8, 0) };
        panel.Children.Add(_selText);
        AddChip(panel, "Zoom", "Zoom sur la sélection (touche Z)", () => _vp.ZoomSelection(), () => true);
        AddChip(panel, "Masquer", "Masque la sélection dans la vue (touche H) ; elle reste sélectionnée", () => HideSelection(), () => true);
        AddChip(panel, "Isoler", "Masque tout sauf la sélection (touche I)", () => IsolateSelection(), () => true);
        AddChip(panel, "Propriétés", "Affiche les propriétés de la sélection dans le panneau de droite", ShowSelectionProps, () => true);
        AddChip(panel, "Messages", "Affiche les messages qui se rapportent à la sélection", ShowSelectionMessages, () => _selHasMessages);
        AddChip(panel, "Résultats", "Affiche les résultats du calcul pour la sélection (après le calcul, F5)", ShowSelectionResults, () => _out != null);
        AddChip(panel, "Inverser", "Inverse la sélection parmi les éléments visibles", () => _vp.InvertSelection(), () => true);
        AddChip(panel, "Supprimer…", "Supprime la sélection, avec confirmation (annulable par Ctrl+Z)", DeleteSelectionConfirm, () => true);
        AddChip(panel, "✕ Vider", "Vide la sélection (Échap)", () => { _vp.ClearAllSelection(); Say("Sélection vidée."); }, () => true);
        _selBar = new Border
        {
            Child = panel, Background = FB(0x0B, 0x1B, 0x2E, 0xEB), BorderBrush = FB(0x00, 0xB8, 0xFF), BorderThickness = new Thickness(1.5),
            CornerRadius = new CornerRadius(12), Padding = new Thickness(10, 5, 8, 5), Margin = new Thickness(12, 0, 12, 30),
            HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Bottom, Visibility = Visibility.Collapsed
        };
        Panel.SetZIndex(_selBar, 5);
        Grid.SetRow(_selBar, 1);
        CenterGrid.Children.Add(_selBar);
    }

    private bool _selHasMessages;

    private void AddChip(StackPanel host, string text, string tip, Action act, Func<bool> enabled)
    {
        var tb = new TextBlock { Text = text, Foreground = FB(255, 255, 255), FontSize = 11.5, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
        var normal = FB(0x1F, 0x4A, 0x73); var hover = FB(0x00, 0x7F, 0xB8);
        var chip = new Border { Child = tb, Background = normal, CornerRadius = new CornerRadius(9), Padding = new Thickness(9, 3, 9, 3), Margin = new Thickness(3, 0, 0, 0), Cursor = Cursors.Hand, ToolTip = tip };
        chip.MouseEnter += (s, ev) => { if (chip.IsEnabled) chip.Background = hover; };
        chip.MouseLeave += (s, ev) => chip.Background = normal;
        chip.MouseLeftButtonUp += (s, ev) => { if (chip.IsEnabled) { act(); ev.Handled = true; } };
        chip.MouseLeftButtonDown += (s, ev) => ev.Handled = true;      // le clic ne traverse pas jusqu'à la vue
        host.Children.Add(chip);
        _selChips.Add((chip, enabled));
    }

    private string _selLastText = "";

    /// <summary>Met à jour la barre : nombre et types, masqués / hors vue (d'après le dernier dessin), boutons disponibles.</summary>
    private void RefreshSelectionBar()
    {
        if (_selBar == null || _selText == null) return;
        var rep = _vp.Report();
        if (rep.Keys.Count == 0) { _selBar.Visibility = Visibility.Collapsed; _selLastText = ""; return; }
        _selBar.Visibility = Visibility.Visible;
        string txt = rep.Text;
        if (txt != _selLastText)
        {
            _selLastText = txt;
            _selText.Text = txt;
            var det = new List<string>();
            if (rep.Hidden.Count > 0) det.Add("Masqués : " + string.Join(", ", rep.Hidden.Take(12).Select(k => k.Label)) + (rep.Hidden.Count > 12 ? "…" : ""));
            if (rep.OffView.Count > 0) det.Add("Hors vue (dans cette vue, ou hors de l'écran) : " + string.Join(", ", rep.OffView.Take(12).Select(k => k.Label)) + (rep.OffView.Count > 12 ? "…" : ""));
            var noGeo = rep.Keys.Where(k => ElementCatalog.IsUnpickable(_model, k)).ToList();
            if (noGeo.Count > 0) det.Add(ElementCatalog.RibbedNoFootprint + " (" + string.Join(", ", noGeo.Take(6).Select(k => k.Label)) + ")");
            if (det.Count == 0) det.Add("Tous les éléments sélectionnés sont visibles dans cette vue.");
            _selText.ToolTip = string.Join(Environment.NewLine, det) + Environment.NewLine + "Les éléments masqués ou hors vue restent sélectionnés.";
        }
        _selHasMessages = _msgs.Count > 0 && rep.Keys.Take(300).Any(k => ElementStatus.HasMessages(_msgs, k));
        foreach (var (chip, enabled) in _selChips) { bool on = enabled(); chip.IsEnabled = on; chip.Opacity = on ? 1 : 0.4; }
    }

    private void OnElementSelection()
    {
        RefreshSelectionBar();
        var keys = _vp.SelectedKeys();
        if (keys.Count == 0) return;
        if (keys.Any(k => ElementCatalog.IsUnpickable(_model, k))) { StatusLeft.Text = ElementCatalog.RibbedNoFootprint + " Renseignez l'emprise dans l'assistant Planchers."; return; }
        bool other = keys.Any(k => k.Kind != ElementKind.Bar && k.Kind != ElementKind.Node);
        if (keys.Count == 1 && other && keys[0].Kind != ElementKind.Slab) ShowElementProps(keys);
        else if (keys.Count > 1 && other) ShowElementProps(keys);
        if (keys.Count > 1 || other) StatusLeft.Text = _vp.Report().Text + "  ·  Ctrl+clic : ajouter / retirer  ·  Échap : vider";
    }

    // ------------------------------------------------------------------ propriétés
    private void ShowSelectionProps()
    {
        var keys = _vp.SelectedKeys();
        if (keys.Count == 0) { Say("Rien n'est sélectionné."); return; }
        if (keys.All(k => k.Kind == ElementKind.Bar)) { if (keys.Count == 1) ShowMember(keys[0].Id); else ShowGroup(); return; }
        if (keys.All(k => k.Kind == ElementKind.Node)) { if (keys.Count == 1) ShowNode(keys[0].Id); else ShowNodes(); return; }
        if (keys.Count == 1 && keys[0].Kind == ElementKind.Slab && _vp.ObjectOf(keys[0]) is SlabPanel sl) { OnSlabSelected(sl); return; }
        ShowElementProps(keys);
    }

    private static object PropRow(string p, string v) => new { Parametre = p, Valeur = v };

    private string CalcState(ElementKey k)
    {
        if (_out == null) return "calcul non effectué";
        if (ElementStatus.NonOk(_out, k)) return "NON OK";
        return ElementStatus.HasResult(_out, k) ? "OK" : "pas de vérification propre à cet élément";
    }

    private void ShowElementProps(List<ElementKey> keys)
    {
        var rows = new List<object>();
        string title, sub, notes = "";
        if (keys.Count == 1)
        {
            var k = keys[0];
            title = k.Label;
            sub = _vp.DescribeElement(k);
            var o = _vp.ObjectOf(k);
            switch (o)
            {
                case StairDef d:
                    rows.Add(PropRow("Disposition", d.Layout.ToString())); rows.Add(PropRow("Hauteur à franchir", $"{F2(d.HeightM)} m")); rows.Add(PropRow("Emmarchement", $"{F2(d.WidthM)} m"));
                    rows.Add(PropRow("Départ (X ; Y ; Z)", $"{F2(d.X)} ; {F2(d.Y)} ; {F2(d.Z)}")); rows.Add(PropRow("Orientation", $"{d.AngleDeg:0}°"));
                    break;
                case FootingRef fr:
                {
                    var pf = FootingPlacement.From(_model, _out).FirstOrDefault(q => q.NodeId == fr.NodeId);
                    rows.Add(PropRow("Sous le nœud", fr.NodeId.ToString()));
                    if (pf != null)
                    {
                        rows.Add(PropRow("Dimensions A x B x H", $"{F2(pf.A)} x {F2(pf.B)} x {F2(pf.H)} m")); rows.Add(PropRow("Forme", pf.Glacis ? "à glacis" : "bloc"));
                        rows.Add(PropRow("Origine", pf.FromAssistant ? "assistant Sol et semelles" : "dimensionnée automatiquement")); rows.Add(PropRow("Cote du dessus", $"{F2(pf.ZTop)} m"));
                    }
                    break;
                }
                case FootingDef fd:
                    rows.Add(PropRow("Longueur", $"{F2(fd.LengthM)} m")); rows.Add(PropRow("Largeur", $"{F2(fd.FixedA > 0 ? fd.FixedA : 0.8)} m")); rows.Add(PropRow("Épaisseur", $"{F2(fd.ThicknessM > 0 ? fd.ThicknessM : 0.4)} m")); rows.Add(PropRow("Cote du dessus", $"{F2(fd.ZTop)} m"));
                    break;
                case WallDef w:
                    rows.Add(PropRow("Longueur x hauteur", $"{F2(w.LengthM)} x {F2(w.HeightM)} m")); rows.Add(PropRow("Épaisseur", $"{w.ThicknessM * 100:0} cm")); rows.Add(PropRow("Ouvertures", w.Openings.Count.ToString()));
                    rows.Add(PropRow("Type", w.Retaining ? "mur de soutènement" : "voile")); rows.Add(PropRow("Pied (X ; Y ; Z)", $"{F2(w.X)} ; {F2(w.Y)} ; {F2(w.Z)}"));
                    break;
                case RaftDef r:
                    rows.Add(PropRow("Épaisseur", $"{r.H * 100:0} cm")); rows.Add(PropRow("Panneaux", r.Panels.Count.ToString())); rows.Add(PropRow("Surface", $"{r.Panels.Sum(p => p.Lx * p.Ly):0.0} m²")); rows.Add(PropRow("Cote du dessus", $"{F2(r.ZTop)} m"));
                    break;
                case RibbedFloorDef rf:
                    rows.Add(PropRow("Hourdis + dalle de compression", $"{rf.HourdisCm:0} + {rf.ToppingCm:0} cm")); rows.Add(PropRow("Entraxe des poutrelles", $"{F2(rf.SpacingM)} m"));
                    rows.Add(PropRow("Travées", string.Join(" ; ", rf.Spans.Select(F2)) + " m")); rows.Add(PropRow("G supplémentaire / Q", $"{rf.GExtraKnM2:0.00} / {rf.QKnM2:0.00} kN/m²"));
                    rows.Add(PropRow("Emprise dans la vue", rf.HasFootprint ? "définie" : "non définie : le plancher n'est pas dessiné (renseignez l'emprise dans l'assistant Planchers)"));
                    break;
                case ShellPanel sh:
                {
                    var all = _model.Shells.Where(q => q.Name == sh.Name).ToList();
                    rows.Add(PropRow("Nature", sh.Kind)); rows.Add(PropRow("Épaisseur", $"{sh.T * 100:0.#} cm")); rows.Add(PropRow("Mailles", all.Count.ToString()));
                    break;
                }
            }
            rows.Add(PropRow("Calcul", CalcState(k)));
            int nm = ElementStatus.MessagesOf(_msgs, k).Count;
            rows.Add(PropRow("Messages associés", nm == 0 ? "aucun" : nm.ToString()));
            var ex = ElementStatus.ExtraOf(_out, k);
            if (ex != null) notes = ex.Text;
        }
        else
        {
            title = $"{keys.Count} éléments sélectionnés";
            sub = _vp.Report().Text;
            foreach (var kind in ElementKinds.Order)
            {
                var grp = keys.Where(q => q.Kind == kind).ToList();
                if (grp.Count == 0) continue;
                rows.Add(PropRow(CapitalFirst(ElementKinds.Plural(kind)), grp.Count.ToString()));
            }
            if (_out != null) rows.Add(PropRow("Dont NON OK", keys.Count(q => ElementStatus.NonOk(_out, q)).ToString()));
            int withMsg = keys.Count(q => ElementStatus.HasMessages(_msgs, q));
            rows.Add(PropRow("Avec messages", withMsg.ToString()));
            notes = string.Join(Environment.NewLine, keys.Take(80).Select(q => "• " + _vp.DescribeElement(q))) + (keys.Count > 80 ? Environment.NewLine + "…" : "");
        }
        DetailTitle.Text = title;
        DetailSub.Text = sub;
        GridProps.ItemsSource = rows;
        NotesBox.Text = notes;
        SectionDrawing.Draw(SectionCanvas, null, null);
    }

    private static string CapitalFirst(string t) => t.Length == 0 ? t : char.ToUpper(t[0]) + t[1..];

    // ------------------------------------------------------------------ messages associés
    private void ShowSelectionMessages()
    {
        var keys = _vp.SelectedKeys();
        if (keys.Count == 0) { Say("Rien n'est sélectionné."); return; }
        if (_msgStale || _msgs.Count == 0) RebuildMessages();
        var linked = keys.Where(k => ElementStatus.HasMessages(_msgs, k)).ToList();
        if (linked.Count == 0) { Say("Aucun message ne se rapporte à la sélection."); return; }
        _msgKeyFilter = new HashSet<ElementKey>(keys);
        BottomTabs.SelectedItem = TabMsgs;
        ApplyMessageView();
        Say($"Messages de la sélection : {linked.Count} élément(s) concerné(s) sur {keys.Count}. « Actualiser » ou un autre filtre rétablit la liste complète.");
    }

    // ------------------------------------------------------------------ résultats associés
    private void ShowSelectionResults()
    {
        var keys = _vp.SelectedKeys();
        if (keys.Count == 0) { Say("Rien n'est sélectionné."); return; }
        if (_out == null) { Say("Calcul non effectué : lancez le calcul (F5) pour afficher les résultats associés."); return; }
        if (keys.Count == 1 && keys[0].Kind == ElementKind.Bar) { ShowMemberDetails(keys[0].Id); return; }
        var rows = new List<object>();
        var notes = new System.Text.StringBuilder();
        int none = 0, nonOk = 0;
        foreach (var k in keys)
        {
            if (!ElementStatus.HasResult(_out, k)) { none++; continue; }
            bool bad = ElementStatus.NonOk(_out, k);
            if (bad) nonOk++;
            string state = bad ? "NON OK" : "OK";
            string extra = "";
            if (k.Kind == ElementKind.Bar && _out.Members.FirstOrDefault(r => r.MemberId == k.Id) is MemberDesignResult mr) extra = $" · taux {mr.Utilization * 100:0} %";
            rows.Add(PropRow(k.Label, state + extra));
            DesignResult? dr = k.Kind == ElementKind.Slab ? _out.Slabs.FirstOrDefault(s => s.Element.StartsWith("Dalle " + k.Name, StringComparison.Ordinal))
                : k.Kind == ElementKind.Footing && k.Id >= 0 ? _out.Footings.FirstOrDefault(f => FootingPlacement.NodeIdOf(f.Element) == k.Id) : null;
            if (dr != null)
            {
                notes.AppendLine("— " + k.Label + " (" + state + ")");
                foreach (var kv in dr.Values.Take(10)) notes.AppendLine($"   {kv.Key} = {kv.Value:0.###}");
                foreach (var n in dr.Notes.Take(6)) notes.AppendLine("   " + n);
                foreach (var w in dr.Warnings.Take(6)) notes.AppendLine("   ⚠ " + w);
                notes.AppendLine();
            }
            var ex = ElementStatus.ExtraOf(_out, k);
            if (ex != null) { notes.AppendLine("— " + k.Label + " (" + state + ")"); notes.AppendLine(ex.Text); notes.AppendLine(); }
        }
        if (rows.Count == 0) { Say("Aucun résultat de calcul pour cette sélection (nœuds, coques et éléments non vérifiés par le calcul n'ont pas de résultat propre)."); return; }
        DetailTitle.Text = $"Résultats de la sélection ({rows.Count} élément(s))";
        DetailSub.Text = none > 0 ? $"{none} élément(s) sélectionné(s) sans résultat propre (nœuds, coques...)." : "Résultats du dernier calcul.";
        GridProps.ItemsSource = rows;
        string t = notes.ToString();
        NotesBox.Text = t.Length > 12000 ? t[..12000] + Environment.NewLine + "…" : t;
        SectionDrawing.Draw(SectionCanvas, null, null);
        Say($"Résultats associés à la sélection : {rows.Count} élément(s), dont {nonOk} NON OK.");
    }

    // ------------------------------------------------------------------ suppression avec confirmation
    private void DeleteSelectionConfirm()
    {
        var keys = _vp.SelectedKeys();
        if (keys.Count == 0) { Say("Rien n'est sélectionné."); return; }
        var rep = _vp.Report();
        // semelles dimensionnées automatiquement : elles suivent le calcul, on ne les supprime pas ici
        var autoFootings = keys.Where(k => k.Kind == ElementKind.Footing && k.Id >= 0).ToList();
        var todo = keys.Except(autoFootings).ToList();
        if (todo.Count == 0)
        {
            Say("Une semelle sous un appui est dimensionnée par le calcul : elle ne se supprime pas ici. Pour la retirer, modifiez l'appui ou utilisez l'assistant Sol et semelles.");
            return;
        }
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Supprimer du modèle : " + SelectionSummary.Describe(todo) + " ?");
        int hid = todo.Count(rep.Hidden.Contains);
        if (hid > 0) sb.AppendLine($"Attention : {hid} de ces éléments sont masqués (invisibles à l'écran) et seront supprimés aussi.");
        int nodesSel = todo.Count(k => k.Kind == ElementKind.Node);
        if (nodesSel > 0) sb.AppendLine("Un nœud supprimé entraîne ses barres, appuis et charges.");
        if (todo.Any(k => k.Kind == ElementKind.Stair)) sb.AppendLine("Un escalier est retiré du modèle d'ensemble ; sa définition reste dans le projet.");
        if (autoFootings.Count > 0) sb.AppendLine($"{autoFootings.Count} semelle(s) dimensionnée(s) automatiquement ne sont pas supprimées.");
        sb.AppendLine("Vous pourrez annuler avec Ctrl+Z.");
        if (MessageBox.Show(this, sb.ToString(), "Supprimer la sélection", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        CommitGrids();
        PushUndo();
        int removed = 0;
        var barIds = todo.Where(k => k.Kind == ElementKind.Bar).Select(k => k.Id).ToList();
        if (barIds.Count > 0) { SelectionTools.Delete(_model, barIds); removed += barIds.Count; }
        var nodeIds = todo.Where(k => k.Kind == ElementKind.Node && _model.Nodes.Any(n => n.Id == k.Id)).Select(k => k.Id).ToList();
        if (nodeIds.Count > 0) { _vp.DeleteNodes(nodeIds); removed += nodeIds.Count; }
        foreach (var k in todo)
        {
            switch (k.Kind)
            {
                case ElementKind.Slab: if (_vp.ObjectOf(k) is SlabPanel sl) { _vp.RemoveSlab(sl); removed++; } break;
                case ElementKind.Stair: if (_vp.ObjectOf(k) is StairDef sd) { sd.Placed = false; removed++; } break;
                case ElementKind.Footing: removed += _model.FootingDefs.RemoveAll(f => f.Kind == FootingKind.Filante && f.Name == k.Name); break;
                case ElementKind.Wall: removed += _model.Walls.RemoveAll(w => w.Name == k.Name); break;
                case ElementKind.Raft: removed += _model.Rafts.RemoveAll(r => r.Name == k.Name); break;
                case ElementKind.Ribbed:
                    removed += _model.RibbedFloors.RemoveAll(r => r.Name == k.Name);
                    _model.SurfaceLoads.RemoveAll(q => q.Name == k.Name + "-G" || q.Name == k.Name + "-Q");
                    break;
                case ElementKind.Shell: removed += _model.Shells.RemoveAll(s => s.Name == k.Name) > 0 ? 1 : 0; break;
            }
        }
        _vp.ClearAllSelection();
        OnModelEdited();
        ShowMember(-1);
        Log($"Sélection supprimée : {removed} élément(s).");
        StatusLeft.Text = $"{removed} élément(s) supprimé(s)  (Ctrl+Z pour annuler). Relancez le calcul (F5).";
    }

    // ------------------------------------------------------------------ menu Sélection : par famille, NON OK, avec messages
    private void SelectionMenu_Opened(object sender, RoutedEventArgs e)
    {
        if (!ReferenceEquals(e.OriginalSource, sender)) return;
        if (sender is not MenuItem menu) return;
        foreach (var item in menu.Items.OfType<MenuItem>())
        {
            switch (item.Tag as string)
            {
                case "kind:Bar": case "kind:Node": case "kind:Slab": case "kind:Stair": case "kind:Footing": case "kind:Wall": case "kind:Raft": case "kind:Ribbed": case "kind:Shell":
                {
                    var kind = Enum.Parse<ElementKind>(((string)item.Tag!)[5..]);
                    int n = _vp.VisibleKeys(kind).Count;
                    item.Visibility = n > 0 ? Visibility.Visible : Visibility.Collapsed;      // la commande n'apparaît que si elle peut agir
                    if (n > 0) item.Header = KindMenuLabel(kind, n);
                    break;
                }
                case "special:nonok":
                {
                    int n = _out == null ? 0 : ElementFilter.NonOk(_model, _out).Count(k => !_vp.IsKeyHidden(k));
                    item.Visibility = n > 0 ? Visibility.Visible : Visibility.Collapsed;
                    if (n > 0) item.Header = $"Éléments NON OK après calcul ({n})";
                    break;
                }
                case "special:messages":
                {
                    if (_msgStale || _msgs.Count == 0) RebuildMessages();
                    int n = ElementFilter.WithMessages(_model, _out, _msgs).Count(k => !_vp.IsKeyHidden(k));
                    item.Visibility = n > 0 ? Visibility.Visible : Visibility.Collapsed;
                    if (n > 0) item.Header = $"Éléments avec messages ({n})";
                    break;
                }
                case "special:none": item.IsEnabled = _vp.HasAnySelection; break;
                case "special:invert": item.IsEnabled = _vp.VisibleKeys().Count > 0; break;
            }
        }
    }

    private static string KindMenuLabel(ElementKind k, int n) => k switch
    {
        ElementKind.Bar => $"Toutes les barres ({n})", ElementKind.Node => $"Tous les nœuds ({n})", ElementKind.Slab => $"Toutes les dalles ({n})",
        ElementKind.Stair => $"Tous les escaliers ({n})", ElementKind.Footing => $"Toutes les semelles ({n})", ElementKind.Wall => $"Tous les voiles ({n})",
        ElementKind.Raft => $"Tous les radiers ({n})", ElementKind.Ribbed => $"Tous les planchers nervurés ({n})", ElementKind.Shell => $"Toutes les coques ({n})", _ => ""
    };

    private void SelectKind_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem mi || mi.Tag is not string tag || !tag.StartsWith("kind:")) return;
        var kind = Enum.Parse<ElementKind>(tag[5..]);
        var all = ElementCatalog.All(_model, _out, kind);
        var vis = _vp.VisibleKeys(kind);
        int noGeo = all.Count(k => ElementCatalog.IsUnpickable(_model, k));
        if (vis.Count == 0) { Say(noGeo > 0 ? ElementCatalog.RibbedNoFootprint : $"Aucun {ElementKinds.Singular(kind)} visible à sélectionner."); return; }
        _vp.SelectKeys(vis, 'n');
        int hid = all.Count - vis.Count - noGeo;
        Say($"{ElementKinds.Count(kind, vis.Count)} sélectionné(s)" + (hid > 0 ? $" ({hid} masqué(s) ignoré(s))" : "") + (noGeo > 0 ? " — " + ElementCatalog.RibbedNoFootprint : "") + "  ·  Z : zoom · H : masquer · I : isoler · Suppr : supprimer.");
    }

    private void SelectNonOk_Click(object sender, RoutedEventArgs e)
    {
        if (_out == null) { Say("Lancez d'abord le calcul (F5) : « NON OK » n'existe qu'après calcul."); return; }
        var keys = ElementFilter.NonOk(_model, _out).Where(k => !_vp.IsKeyHidden(k)).ToList();
        if (keys.Count == 0) { Say("Aucun élément NON OK."); return; }
        _vp.SelectKeys(keys, 'n');
        Say("NON OK après calcul : " + SelectionSummary.Describe(keys));
    }

    private void SelectWithMessages_Click(object sender, RoutedEventArgs e)
    {
        if (_msgStale || _msgs.Count == 0) RebuildMessages();
        var keys = ElementFilter.WithMessages(_model, _out, _msgs).Where(k => !_vp.IsKeyHidden(k)).ToList();
        if (keys.Count == 0) { Say("Aucun élément n'a de message."); return; }
        _vp.SelectKeys(keys, 'n');
        Say("Éléments avec messages : " + SelectionSummary.Describe(keys));
    }

    // ------------------------------------------------------------------ menu contextuel d'un élément surfacique ou d'une sélection multiple
    private void FillSelectionTail(ContextMenu cm)
    {
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Zoom sur la sélection", () => _vp.ZoomSelection(), true, "Z"));
        cm.Items.Add(Mi("Propriétés", ShowSelectionProps));
        cm.Items.Add(Mi("Messages associés", ShowSelectionMessages, _selHasMessages));
        cm.Items.Add(Mi("Résultats associés", ShowSelectionResults, _out != null));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Masquer", () => HideSelection(), true, "H"));
        cm.Items.Add(Mi("Isoler (masquer tout le reste)", () => IsolateSelection(), true, "I"));
        cm.Items.Add(Mi("Inverser la sélection", () => _vp.InvertSelection()));
        cm.Items.Add(Mi("Supprimer…", DeleteSelectionConfirm, true, "Suppr"));
        cm.Items.Add(Mi("Vider la sélection", () => _vp.ClearAllSelection(), true, "Échap"));
    }

    private void FillElementMenu(ContextMenu cm, ElementKey key, object? obj)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.DescribeElement(key)));
        switch (key.Kind)
        {
            case ElementKind.Stair:
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Position, type et dimensions de l'escalier...", () => PlaceStairDialog(obj as StairDef)));
                if (obj is StairDef st) cm.Items.Add(Mi("Prédimensionner (contremarche, giron, paillasse)...", () => PreDesignStair(st)));
                cm.Items.Add(Mi("Dimensionner / ferrailler (assistant Escaliers)...", () => Stairs_Click(this, new RoutedEventArgs())));
                break;
            case ElementKind.Footing when key.Id >= 0:
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Ouvrir dans l'assistant Sol et semelles...", () => OpenFootingFor(key.Id)));
                cm.Items.Add(Mi("Prédimensionner la semelle...", () => PreDesignFooting(key.Id)));
                break;
            case ElementKind.Wall:
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Assistant Voiles (éléments finis)...", () => Walls_Click(this, new RoutedEventArgs())));
                break;
            case ElementKind.Raft:
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Assistant Radier général...", () => Rafts_Click(this, new RoutedEventArgs())));
                break;
            case ElementKind.Ribbed:
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Assistant Planchers (corps creux)...", () => Floors_Click(this, new RoutedEventArgs())));
                break;
        }
        FillSelectionTail(cm);
    }

    private void FillMultiMenu(ContextMenu cm)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.Report().Text));
        FillSelectionTail(cm);
    }

    // ------------------------------------------------------------------ messages : filtre sur la sélection
    private bool MessageMatchesSelection(AppMessage am) => _msgKeyFilter == null || _msgKeyFilter.Any(k => ElementStatus.Concerns(am, k));
}
