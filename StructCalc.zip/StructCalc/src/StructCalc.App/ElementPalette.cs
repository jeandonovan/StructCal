using System.Windows.Media;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.UI;

/// <summary>Une famille d'éléments dont la couleur est réglable.</summary>
public sealed record ElementColorDef(string Id, string Group, string Label, string Default, string Note = "");

/// <summary>Couleurs des éléments du modèle (poteaux, poutres, dalles, voiles, semelles, escaliers, appuis, nœuds) réglables à volonté.
/// Seules les couleurs modifiées sont enregistrées (options.json) ; le reste suit les couleurs d'origine.</summary>
public static class ElementPalette
{
    public static readonly ElementColorDef[] All =
    {
        new("ColumnRc", "Structure", "Poteaux béton", "#A4AAB2", "vue 3D ombrée / réaliste ; en fil de fer : seulement si modifiée"),
        new("BeamRc", "Structure", "Poutres béton", "#C3C8CE"),
        new("ColumnSteel", "Structure", "Poteaux acier", "#5F86B2"),
        new("BeamSteel", "Structure", "Poutres acier", "#7C9FC6"),
        new("Slab", "Surfaces", "Dalles", "#269AA8"),
        new("Wall", "Surfaces", "Voiles", "#FF8F00"),
        new("Footing", "Fondations", "Semelles", "#B8AE9A"),
        new("Stair", "Escaliers", "Escaliers (marches ; contremarches et paillasse plus sombres)", "#CFD8DC"),
        new("Support", "Symboles", "Appuis", "#37474F"),
        new("Node", "Symboles", "Nœuds", "#37474F"),
    };

    /// <summary>Jeux de couleurs prêts à l'emploi (la liste vide = couleurs d'origine).</summary>
    public static readonly (string Name, Dictionary<string, string> Map)[] Presets =
    {
        ("Couleurs d'origine", new Dictionary<string, string>()),
        ("Contraste élevé", new Dictionary<string, string> { ["ColumnRc"] = "#37474F", ["BeamRc"] = "#1565C0", ["ColumnSteel"] = "#6A1B9A", ["BeamSteel"] = "#AB47BC", ["Slab"] = "#00ACC1", ["Wall"] = "#E65100", ["Footing"] = "#8D6E63", ["Stair"] = "#78909C", ["Support"] = "#000000", ["Node"] = "#000000" }),
        ("Pastel", new Dictionary<string, string> { ["ColumnRc"] = "#90CAF9", ["BeamRc"] = "#A5D6A7", ["ColumnSteel"] = "#80DEEA", ["BeamSteel"] = "#B39DDB", ["Slab"] = "#FFE082", ["Wall"] = "#FFAB91", ["Footing"] = "#D7CCC8", ["Stair"] = "#CFD8DC", ["Support"] = "#546E7A", ["Node"] = "#546E7A" }),
        ("Plan imprimé (gris)", new Dictionary<string, string> { ["ColumnRc"] = "#616161", ["BeamRc"] = "#9E9E9E", ["ColumnSteel"] = "#424242", ["BeamSteel"] = "#757575", ["Slab"] = "#BDBDBD", ["Wall"] = "#757575", ["Footing"] = "#E0E0E0", ["Stair"] = "#F5F5F5", ["Support"] = "#000000", ["Node"] = "#000000" }),
    };

    private static readonly Dictionary<string, Brush> Cache = new();

    /// <summary>Colorer les barres selon le résultat du calcul (vert conforme, rouge non conforme) quand il existe.</summary>
    public static bool ByResult => AppOptions.Current.ColorByResult;

    public static string KeyOf(Member m) => m.Kind == MaterialKind.Steel
        ? (m.Type == MemberType.Column ? "ColumnSteel" : "BeamSteel")
        : (m.Type == MemberType.Column ? "ColumnRc" : "BeamRc");

    public static string DefaultHex(string id) => All.First(x => x.Id == id).Default;

    public static bool IsSet(string id) => AppOptions.Current.ElementColors.TryGetValue(id, out var h) && AppOptions.TryColor(h, out _);

    public static Color Get(string id)
    {
        if (AppOptions.Current.ElementColors.TryGetValue(id, out var h) && AppOptions.TryColor(h, out var c)) return c;
        AppOptions.TryColor(DefaultHex(id), out var d);
        return d;
    }

    public static Brush BrushOf(string id)
    {
        if (!Cache.TryGetValue(id, out var b)) Cache[id] = b = Theme.Fixed(Get(id));
        return b;
    }

    /// <summary>Assombrit (f &gt; 0) ou éclaircit (f &lt; 0) une couleur.</summary>
    public static Color Shade(Color c, double f)
    {
        byte T(byte v) => (byte)Math.Clamp(f >= 0 ? v * (1 - f) : v + (255 - v) * -f, 0, 255);
        return Color.FromRgb(T(c.R), T(c.G), T(c.B));
    }

    public static Color WithAlpha(Color c, byte a) => Color.FromArgb(a, c.R, c.G, c.B);

    /// <summary>Enregistre les couleurs modifiées (celles identiques à l'origine sont retirées).</summary>
    public static void Apply(Dictionary<string, string> map, bool byResult)
    {
        var o = AppOptions.Current;
        o.ElementColors = map.Where(kv => AppOptions.TryColor(kv.Value, out var c) && !(AppOptions.TryColor(DefaultHex(kv.Key), out var d) && d == c))
                             .ToDictionary(kv => kv.Key, kv => kv.Value);
        o.ColorByResult = byResult;
        Cache.Clear();
        AppOptions.Save();
    }
}
