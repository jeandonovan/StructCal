using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.UI;

/// <summary>Un fond de plan chargé en mémoire : dessin DXF (vectoriel) ou image (PDF rendu / image) avec masque « encre » pour l'accrochage.</summary>
public sealed class UnderlayData
{
    public UnderlayDef Def { get; set; } = new();
    public string Key { get; set; } = "";
    public DxfDrawing? Dxf { get; set; }
    public BitmapSource? Image { get; set; }
    public byte[]? Ink { get; set; }
    public int W { get; set; }
    public int H { get; set; }
    public int PageCount { get; set; } = 1;
    public string Error { get; set; } = "";
    public bool IsRaster => Image != null;

    // ---- géométrie DXF pour l'affichage (coordonnées source), mise en cache par couleur
    private Dictionary<int, StreamGeometry>? _geo;
    private string _geoSig = "";

    public Dictionary<int, StreamGeometry> Geometries()
    {
        var hidden = new HashSet<string>(Def.HiddenLayers, StringComparer.OrdinalIgnoreCase);
        string sig = string.Join("|", Def.HiddenLayers.OrderBy(x => x));
        if (_geo != null && sig == _geoSig) return _geo;
        var res = new Dictionary<int, StreamGeometry>();
        if (Dxf != null)
        {
            var groups = new Dictionary<int, StreamGeometryContext>();
            var geos = new Dictionary<int, StreamGeometry>();
            foreach (var s in Dxf.Segments)
            {
                if (hidden.Contains(Dxf.Layers[s.Layer].Name)) continue;
                if (!groups.TryGetValue(s.Rgb, out var ctx))
                {
                    var g = new StreamGeometry();
                    ctx = g.Open();
                    groups[s.Rgb] = ctx; geos[s.Rgb] = g;
                }
                ctx.BeginFigure(new Point(s.X1, s.Y1), false, false);
                ctx.LineTo(new Point(s.X2, s.Y2), true, false);
            }
            foreach (var kv in groups) kv.Value.Close();
            foreach (var kv in geos) { kv.Value.Freeze(); res[kv.Key] = kv.Value; }
        }
        _geo = res; _geoSig = sig;
        return res;
    }

    // ---- segments en coordonnées modèle (pour l'accrochage), recalculés quand le placement change
    public double[] World = Array.Empty<double>();           // x1,y1,x2,y2,curve(0/1) par segment
    private string _worldSig = "";

    public void EnsureWorld()
    {
        if (Dxf == null) return;
        string sig = $"{Def.OriginX:R}|{Def.OriginY:R}|{Def.Scale:R}|{Def.Rotation:R}|{string.Join("|", Def.HiddenLayers)}";
        if (sig == _worldSig) return;
        var hidden = new HashSet<string>(Def.HiddenLayers, StringComparer.OrdinalIgnoreCase);
        var list = new List<double>(Dxf.Segments.Count * 5);
        foreach (var s in Dxf.Segments)
        {
            if (hidden.Contains(Dxf.Layers[s.Layer].Name)) continue;
            var a = UnderlayMath.ToModel(Def, s.X1, s.Y1); var b = UnderlayMath.ToModel(Def, s.X2, s.Y2);
            list.Add(a.X); list.Add(a.Y); list.Add(b.X); list.Add(b.Y); list.Add(s.Curve ? 1 : 0);
        }
        World = list.ToArray();
        WorldPoints = Dxf.Points.Select(p => UnderlayMath.ToModel(Def, p.X, p.Y)).ToArray();
        _worldSig = sig;
    }
    public (double X, double Y)[] WorldPoints = Array.Empty<(double, double)>();

    /// <summary>Étendue du fond en coordonnées modèle.</summary>
    public (double X0, double Y0, double X1, double Y1)? Bounds()
    {
        var pts = new List<(double X, double Y)>();
        if (Dxf != null && !Dxf.IsEmpty)
        {
            foreach (var c in new[] { (Dxf.MinX, Dxf.MinY), (Dxf.MaxX, Dxf.MinY), (Dxf.MaxX, Dxf.MaxY), (Dxf.MinX, Dxf.MaxY) }) pts.Add(UnderlayMath.ToModel(Def, c.Item1, c.Item2));
        }
        else if (Image != null)
        {
            foreach (var c in new[] { (0.0, 0.0), ((double)W, 0.0), ((double)W, (double)H), (0.0, (double)H) }) pts.Add(UnderlayMath.ToModel(Def, c.Item1, c.Item2));
        }
        else return null;
        return (pts.Min(p => p.X), pts.Min(p => p.Y), pts.Max(p => p.X), pts.Max(p => p.Y));
    }
}

public static class DwgConverter
{
    /// <summary>Cherche le convertisseur gratuit « ODA File Converter » (Open Design Alliance).</summary>
    public static string? FindConverter()
    {
        string? env = Environment.GetEnvironmentVariable("ODA_FILE_CONVERTER");
        if (!string.IsNullOrEmpty(env) && File.Exists(env)) return env;
        foreach (var root in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) })
        {
            try
            {
                string oda = Path.Combine(root, "ODA");
                if (!Directory.Exists(oda)) continue;
                foreach (var dir in Directory.GetDirectories(oda, "ODAFileConverter*"))
                {
                    string exe = Path.Combine(dir, "ODAFileConverter.exe");
                    if (File.Exists(exe)) return exe;
                }
            }
            catch { }
        }
        return null;
    }

    /// <summary>Convertit un .dwg en .dxf (ASCII, R2018) dans un dossier temporaire. Retourne le chemin du DXF ou null avec un message.</summary>
    public static async Task<(string? Dxf, string Message)> ConvertAsync(string dwgPath)
    {
        string? exe = FindConverter();
        if (exe == null)
            return (null, "Le format DWG est propriétaire : StructCalc ne peut pas le lire directement.\n\n" +
                "Deux solutions :\n" +
                "1) Dans AutoCAD / Revit : « Enregistrer sous » → DXF (version 2013 ou 2018), puis importez ce DXF.\n" +
                "2) Installez le convertisseur gratuit « ODA File Converter » (opendesign.com) : StructCalc le détectera et convertira vos DWG tout seul.");
        string work = Path.Combine(Path.GetTempPath(), "StructCalc_dwg_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        string inDir = Path.Combine(work, "in"), outDir = Path.Combine(work, "out");
        Directory.CreateDirectory(inDir); Directory.CreateDirectory(outDir);
        string name = Path.GetFileName(dwgPath);
        File.Copy(dwgPath, Path.Combine(inDir, name), true);
        var psi = new ProcessStartInfo(exe, $"\"{inDir}\" \"{outDir}\" ACAD2018 DXF 0 1 \"{name}\"") { CreateNoWindow = true, UseShellExecute = false };
        try
        {
            using var proc = Process.Start(psi);
            if (proc == null) return (null, "Impossible de lancer ODA File Converter.");
            await Task.Run(() => proc.WaitForExit(120000));
        }
        catch (Exception ex) { return (null, "Erreur ODA File Converter : " + ex.Message); }
        string dxf = Path.Combine(outDir, Path.ChangeExtension(name, ".dxf"));
        return File.Exists(dxf) ? (dxf, "") : (null, "La conversion DWG → DXF n'a produit aucun fichier (version de DWG non prise en charge ?).");
    }
}

public static class UnderlayLoader
{
    private const int MaxLongSide = 4800;

    public static string KindOf(string path) => Path.GetExtension(path).ToLowerInvariant() switch
    {
        ".dxf" => "dxf", ".dwg" => "dwg", ".pdf" => "pdf", _ => "img"
    };

    public static async Task<UnderlayData> LoadAsync(UnderlayDef def)
    {
        var d = new UnderlayData { Def = def, Key = def.Id + "|" + def.Path + "|" + def.Page };
        try
        {
            if (!File.Exists(def.Path)) { d.Error = "Fichier introuvable : " + def.Path; return d; }
            switch (def.Kind)
            {
                case "dxf":
                    d.Dxf = await Task.Run(() => DxfReader.Read(def.Path));
                    if (d.Dxf.IsEmpty) d.Error = "Le DXF ne contient aucune géométrie reconnue (lignes, polylignes, arcs, cercles, blocs).";
                    break;
                case "pdf":
                    await LoadPdfAsync(d);
                    break;
                default:
                    await Task.Run(() => LoadImage(d));
                    break;
            }
        }
        catch (Exception ex) { d.Error = ex.Message; }
        return d;
    }

    private static async Task LoadPdfAsync(UnderlayData d)
    {
        var def = d.Def;
        var file = await Windows.Storage.StorageFile.GetFileFromPathAsync(Path.GetFullPath(def.Path));
        var doc = await Windows.Data.Pdf.PdfDocument.LoadFromFileAsync(file);
        d.PageCount = (int)doc.PageCount;
        if (def.Page < 0 || def.Page >= d.PageCount) def.Page = 0;
        using var page = doc.GetPage((uint)def.Page);
        double wDip = page.Size.Width, hDip = page.Size.Height;
        double k = MaxLongSide / Math.Max(wDip, hDip);
        uint pw = (uint)Math.Max(64, Math.Round(wDip * k)), ph = (uint)Math.Max(64, Math.Round(hDip * k));
        def.PageWidthMm = wDip / 96.0 * 25.4;
        using var ms = new Windows.Storage.Streams.InMemoryRandomAccessStream();
        var opt = new Windows.Data.Pdf.PdfPageRenderOptions { DestinationWidth = pw, DestinationHeight = ph, BackgroundColor = new Windows.UI.Color { A = 255, R = 255, G = 255, B = 255 } };
        await page.RenderToStreamAsync(ms, opt);
        ms.Seek(0);
        using var net = System.IO.WindowsRuntimeStreamExtensions.AsStreamForRead(ms);
        var copy = new MemoryStream();
        await net.CopyToAsync(copy);
        copy.Position = 0;
        var bi = new BitmapImage();
        bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.StreamSource = copy; bi.EndInit(); bi.Freeze();
        BuildRaster(d, bi, whiteToTransparent: true);
        def.PixelWidth = d.W; def.PixelHeight = d.H;
    }

    private static void LoadImage(UnderlayData d)
    {
        var bi = new BitmapImage();
        bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.UriSource = new Uri(Path.GetFullPath(d.Def.Path)); bi.EndInit(); bi.Freeze();
        BuildRaster(d, bi, whiteToTransparent: false);
        d.Def.PixelWidth = d.W; d.Def.PixelHeight = d.H;
    }

    private static void BuildRaster(UnderlayData d, BitmapSource src, bool whiteToTransparent)
    {
        var conv = new FormatConvertedBitmap(src, PixelFormats.Bgra32, null, 0);
        int w = conv.PixelWidth, h = conv.PixelHeight, stride = w * 4;
        var px = new byte[stride * h];
        conv.CopyPixels(px, stride, 0);
        var ink = new byte[w * h];
        for (int i = 0; i < w * h; i++)
        {
            int o = i * 4;
            byte b = px[o], g = px[o + 1], r = px[o + 2];
            int min = Math.Min(r, Math.Min(g, b));
            if (whiteToTransparent)
            {
                int a = 255 - min;
                if (a > 0)
                {
                    px[o] = (byte)Math.Min(255, (b - min) * 255 / a);
                    px[o + 1] = (byte)Math.Min(255, (g - min) * 255 / a);
                    px[o + 2] = (byte)Math.Min(255, (r - min) * 255 / a);
                }
                px[o + 3] = (byte)a;
                ink[i] = (byte)(a > 110 ? 1 : 0);
            }
            else ink[i] = (byte)((r * 30 + g * 59 + b * 11) / 100 < 110 ? 1 : 0);
        }
        var bmp = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgra32, null, px, stride);
        bmp.Freeze();
        d.Image = bmp; d.Ink = ink; d.W = w; d.H = h;
    }
}

/// <summary>Garde les fonds de plan chargés ; ne recharge un fichier que s'il a changé.</summary>
public sealed class UnderlayManager
{
    private readonly Dictionary<string, UnderlayData> _cache = new();
    public List<UnderlayData> Items { get; private set; } = new();

    public async Task SyncAsync(StructModel m, Action<string> log)
    {
        var items = new List<UnderlayData>();
        foreach (var def in m.Underlays)
        {
            string key = def.Id + "|" + def.Path + "|" + def.Page;
            if (!_cache.TryGetValue(key, out var data) || data.Error != "" && File.Exists(def.Path))
            {
                data = await UnderlayLoader.LoadAsync(def);
                _cache[key] = data;
                if (data.Error != "") log($"Fond de plan « {def.Name} » : {data.Error}");
            }
            data.Def = def;
            items.Add(data);
        }
        Items = items;
    }

    public void Prime(UnderlayData d) => _cache[d.Key] = d;

    public UnderlayData? Find(int id) => Items.FirstOrDefault(i => i.Def.Id == id);
}
