using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Licensing;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

public record CodeItem(string Id, string Label);

/// <summary>Ligne du tableau des résultats.</summary>
public sealed class ResultRow
{
    public int Barre { get; set; }
    public string Type { get; set; } = "";
    public string Section { get; set; } = "";
    public double Longueur { get; set; }
    public double MuTravee { get; set; }
    public double MuAppui { get; set; }
    public double Vu { get; set; }
    public double Nu { get; set; }
    public string ArmInf { get; set; } = "";
    public string ArmSup { get; set; } = "";
    public string Transversales { get; set; } = "";
    public double TauxPct { get; set; }
    public string TauxText { get; set; } = "";
    public string Etat { get; set; } = "";
}

public partial class MainWindow : Window
{
    private StructModel _model = new StructModel();
    private AnalysisOutput? _out;
    private readonly ModelViewport _vp;

    private static readonly Dictionary<string, string> Headers = new()
    {
        { "Id", "N°" }, { "X", "X (m)" }, { "Y", "Y (m)" }, { "Z", "Z (m)" },
        { "NodeId", "Nœud" }, { "NodeI", "Nœud i" }, { "NodeJ", "Nœud j" }, { "Type", "Type" }, { "Kind", "Matériau" },
        { "B", "b (m)" }, { "H", "h (m)" }, { "Cover", "Enrobage axe (m)" }, { "LfFactor", "Coef. lf/l" },
        { "Crack", "Fissuration" }, { "PropA", "A (m²)" }, { "PropIy", "Iy (m⁴)" }, { "PropIz", "Iz (m⁴)" }, { "PropJ", "J (m⁴)" },
        { "ExternalId", "Id Revit" }, { "Profile", "Profil acier" },
        { "Ux", "Ux" }, { "Uy", "Uy" }, { "Uz", "Uz" }, { "Rx", "Rx" }, { "Ry", "Ry" }, { "Rz", "Rz" },
        { "Case", "Cas" }, { "Fx", "Fx (kN)" }, { "Fy", "Fy (kN)" }, { "Fz", "Fz (kN)" },
        { "Mx", "Mx (kN.m)" }, { "My", "My (kN.m)" }, { "Mz", "Mz (kN.m)" },
        { "MemberId", "Barre" }, { "Wx", "Wx (kN/m)" }, { "Wy", "Wy (kN/m)" }, { "Wz", "Wz (kN/m)" },
        { "Name", "Nom" }, { "Lx", "Lx (m)" }, { "Ly", "Ly (m)" }, { "GExtra", "G sup. (kN/m²)" }, { "Q", "Q (kN/m²)" },
        { "Continuity", "Continuité" }, { "Gamma", "γ (kN/m³)" }, { "CalcMode", "Calcul" }, { "Volume", "Volume (m³)" }, { "SelfWeightKnM2", "Poids propre (kN/m²)" }, { "TotalWeightKn", "Poids total (kN)" }, { "Enabled", "Activé" }, { "Norm", "Norme" }, { "Direction", "Direction" },
        { "Zone", "Zone (RPA)" }, { "Group", "Groupe (RPA)" }, { "Site", "Site (RPA)" }, { "R", "R" }, { "Beta", "β (Q)" },
        { "XiPercent", "ξ (%)" }, { "Ct", "Ct" }, { "AgOverG", "ag/g (EC8)" }, { "Ground", "Sol (EC8)" },
        { "BehaviorQ", "q (EC8)" }, { "ImportanceGamma", "γI" }, { "PsiE", "ψE" },
    };

    public MainWindow()
    {
        InitializeComponent();
        Title = $"{AppInfo.Name} {AppInfo.Version} - Dimensionnement béton armé et charpente métallique - © {AppInfo.Author}";
        if (LicenseManager.Current.IsCreator) Title += "   ★ LICENCE CRÉATEUR";
        CodeRc.ItemsSource = DesignCodeRegistry.Available(MaterialKind.ReinforcedConcrete)
            .Select(c => new CodeItem(c.Id, c.DisplayName + (c.IsImplemented ? "" : "  (à venir)"))).ToList();
        CodeSteel.ItemsSource = DesignCodeRegistry.Available(MaterialKind.Steel)
            .Select(c => new CodeItem(c.Id, c.DisplayName + (c.IsImplemented ? "" : "  (à venir)"))).ToList();
        SoilPresetBox.ItemsSource = SoilPresets.All.Select(x => $"{x.Name} - {x.QAdmKPa:0} kPa").Append(SoilPresets.Custom).ToList();
        _vp = new ModelViewport(ViewCanvas);
        _vp.MemberSelected += OnMemberSelected;
        _vp.SelectionChanged += UpdateSelectionStatus;
        InitTools();
        InitStructurePanel();
        InitContext();
        InitVisibility();
        InitIssues();
        InitMessages();
        InitDims();
        BindModel();
        UpdateUndoUi();
        InitDock();
        InitTheme();
    }

    // ------------------------------------------------------------------ liaison modèle <-> interface
    private void HookRedraw(INotifyCollectionChanged c) => c.CollectionChanged += (s, e) => { _vp.Redraw(); RefreshStructure(); };

    private void BindModel()
    {
        Units.Apply(_model.Settings);
        GridNodes.ItemsSource = _model.Nodes;
        GridMembers.ItemsSource = _model.Members;
        GridSupports.ItemsSource = _model.Supports;
        GridNodalLoads.ItemsSource = _model.NodalLoads;
        GridMemberLoads.ItemsSource = _model.MemberLoads;
        GridSlabs.ItemsSource = _model.Slabs;
        GridSeismic.ItemsSource = new List<SeismicParams> { _model.Seismic };
        HookRedraw(_model.Nodes); HookRedraw(_model.Members); HookRedraw(_model.Supports);
        HookRedraw(_model.NodalLoads); HookRedraw(_model.MemberLoads);

        NameBox.Text = _model.Name;
        FcBox.Text = _model.Fc28.ToString(CultureInfo.InvariantCulture);
        FeBox.Text = _model.Fe.ToString(CultureInfo.InvariantCulture);
        FyBox.Text = _model.SteelFy.ToString(CultureInfo.InvariantCulture);
        SoilBox.Text = _model.SigmaSolKPa.ToString(CultureInfo.InvariantCulture);
        UpdateSoilInfo();
        ChkSelfWeight.IsChecked = _model.IncludeSelfWeight;
        ChkSway.IsChecked = _model.SwayFrame;
        ChkAutoLf.IsChecked = _model.AutoEffectiveLength;
        ChkBraced.IsChecked = _model.BracedOutOfPlane;
        CodeRc.SelectedValue = _model.RcCodeId;
        CodeSteel.SelectedValue = _model.SteelCodeId;

        GridResults.ItemsSource = null; GridIssues.ItemsSource = null;
        UpdateUnitHeaders();
        ResultText.Text = ""; QtyText.Text = "";
        _out = null;
        _lastIssues = null; _msgStale = true;
        LoadMessageStatuses();
        if (ReferenceEquals(BottomTabs.SelectedItem, TabMsgs)) RebuildMessages();
        _syncing3D = true;
        if (ChkGlacis != null) ChkGlacis.IsChecked = _model.FootingGlacis;
        if (ComboFootPos != null)
        {
            int[] ax = { 0, 1, -1, 0, 0, 1, -1, 1, -1 }, ay = { 0, 0, 0, 1, -1, 1, 1, -1, -1 };
            int k = 0; for (int i = 0; i < ax.Length; i++) if (ax[i] == _model.FootingAlignX && ay[i] == _model.FootingAlignY) { k = i; break; }
            ComboFootPos.SelectedIndex = k;
        }
        _syncing3D = false;
        _vp.Model = _model; _vp.PruneHidden(); _vp.Output = null; _vp.SelectedId = -1;
        _ = SyncUnderlaysAsync();
        ShowMember(-1);
        StatusLeft.Text = "Modèle : " + _model.Name;
        StatusMid.Text = BaseStatusMid();
        RefreshStructure();
        Dispatcher.BeginInvoke(new Action(() => _vp.ZoomExtents()), DispatcherPriority.Loaded);
    }

    private static double Num(string s, double fallback) =>
        double.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double v) ? v : fallback;

    private void CommitGrids()
    {
        foreach (var g in new[] { GridNodes, GridMembers, GridSupports, GridNodalLoads, GridMemberLoads, GridSlabs, GridSeismic })
            g.CommitEdit(DataGridEditingUnit.Row, true);
    }

    private void ReadParams()
    {
        CommitGrids();
        _model.Name = NameBox.Text;
        _model.Fc28 = Num(FcBox.Text, 25);
        _model.Fe = Num(FeBox.Text, 500);
        _model.SteelFy = Num(FyBox.Text, 275);
        _model.SigmaSolKPa = Num(SoilBox.Text, 0);
        _model.IncludeSelfWeight = ChkSelfWeight.IsChecked == true;
        _model.SwayFrame = ChkSway.IsChecked == true;
        _model.AutoEffectiveLength = ChkAutoLf.IsChecked == true;
        _model.BracedOutOfPlane = ChkBraced.IsChecked == true;
        if (CodeRc.SelectedValue is string rc) _model.RcCodeId = rc;
        if (CodeSteel.SelectedValue is string cm) _model.SteelCodeId = cm;
    }

    private void Log(string s) { LogBox.AppendText(s + Environment.NewLine); _journal.Add(s); }

    // ------------------------------------------------------------------ tableaux
    private void Grid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
    {
        if (Headers.TryGetValue(e.PropertyName, out var h)) e.Column.Header = h;
        ApplyUnitToColumn(sender, e);
        if (ReferenceEquals(sender, GridMemberLoads))
        {
            // la grille ne montre que l'essentiel : tout le détail (ponctuelles, trapèzes, thermique...) se saisit dans l'assistant « Charges »
            var shown = new[] { "MemberId", "Case", "Kind", "Frame", "Wx", "Wy", "Wz", "A", "B", "Label" };
            if (!shown.Contains(e.PropertyName)) e.Column.Visibility = Visibility.Collapsed;
            string? t = e.PropertyName switch { "Kind" => "Type", "Frame" => "Repère", "A" => $"De ({Units.Length})", "B" => $"À ({Units.Length})", "Label" => "Libellé", _ => null };
            if (t != null) e.Column.Header = t;
            if (e.PropertyName is "Kind" or "Frame" or "A" or "B") e.Column.IsReadOnly = false;
        }
    }

    private void Grid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.EditAction == DataGridEditAction.Commit) PushUndo();          // l'état d'avant la saisie est encore dans le modèle
        bool slabGrid = ReferenceEquals(sender, GridSlabs);
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (slabGrid) { StructCalc.Engine.Structure.StoreyOps.SyncAllSlabLoads(_model); try { GridSlabs.Items.Refresh(); } catch { } }   // dimensions, γ ou mode modifiés : charges des dalles recalculées
            _vp.Redraw(); RefreshStructure();
        }), DispatcherPriority.Background);
    }

    // ------------------------------------------------------------------ fichier
    private void New_Click(object sender, RoutedEventArgs e)
    {
        if (!ConfirmClose()) return;
        ShowWelcome();
    }
    private void Example_Click(object sender, RoutedEventArgs e) { _model = ExampleModels.Portal(); _vp.ResetHidden(); BindModel(); Log("Exemple chargé : portique béton armé 2 travées / 2 niveaux."); }
    private void ExampleSteel_Click(object sender, RoutedEventArgs e) { _model = ExampleModels.SteelPortal(); _vp.ResetHidden(); BindModel(); Log("Exemple chargé : portique acier 8 m x 4 m."); }
    private void Exit_Click(object sender, RoutedEventArgs e) => Close();

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = AppInfo.OpenFilter, DefaultExt = AppInfo.FileExt };
        if (dlg.ShowDialog() != true) return;
        OpenModelFile(dlg.FileName);
    }

    /// <summary>Ouvre un modèle depuis un fichier (menu Ouvrir, argument de la ligne de commande, envoi depuis Revit).</summary>
    private bool OpenModelFile(string path)
    {
        try { ApplyLoaded(path, ModelIO.Load(path)); return true; }
        catch (Exception ex) { Log("Erreur d'ouverture : " + ex.Message); return false; }
    }

    /// <summary>Met en place un modèle déjà lu (ouverture depuis le menu, l'accueil, un argument ou Revit).</summary>
    private void ApplyLoaded(string path, StructModel model)
    {
        _model = model; _vp.ResetHidden(); BindModel(); Log("Ouvert : " + path);
        bool real = !path.Equals(RecoveryFile, StringComparison.OrdinalIgnoreCase) && !path.Contains("from_revit");
        if (real) AddRecent(path);
        OnModelEdited();
        _vp.ZoomExtents();
        _filePath = real ? path : null; _dirty = !real;
    }

    private static bool InEditField() =>
        Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is DataGridCell || Keyboard.FocusedElement is ComboBox || Keyboard.FocusedElement is System.Windows.Controls.Primitives.TextBoxBase;

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (HandleCustomShortcut(e)) return;
        if (e.Key == Key.Escape)
        {
            bool idle = _vp.Tool == EditTool.Select && !_vp.Picking;
            _vp.CancelPending(); ToolSelectNone();
            if (idle && _vp.HasAnySelection) { _vp.ClearSelection(); StatusLeft.Text = "Sélection effacée."; }
            e.Handled = true;
        }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Z && !(Keyboard.FocusedElement is TextBox)) { Undo_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (((Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Y) || (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift) && e.Key == Key.Z))
                 && !(Keyboard.FocusedElement is TextBox)) { Redo_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.A && !InEditField()) { SelectAll_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.Delete && Keyboard.Modifiers == ModifierKeys.None && !InEditField() && _vp.HasAnySelection) { DeleteAnySelection(); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.L && !InEditField()) { LoadAssistant_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.F3) { ToggleSnap(); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.F && !InEditField()) { Filter_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.None && !InEditField() && !(Keyboard.FocusedElement is ComboBox) && _vp.Selection.Count > 0 && !_vp.Picking && (e.Key == Key.M || e.Key == Key.C || e.Key == Key.R))
        { if (e.Key == Key.M) MovePick_Click(this, new RoutedEventArgs()); else if (e.Key == Key.C) CopyPick_Click(this, new RoutedEventArgs()); else Rotate_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.F6) { GlobalResults_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.F7) { ResultsExplorer_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.F5) { Run_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (e.Key == Key.Z && Keyboard.Modifiers == ModifierKeys.None && !(Keyboard.FocusedElement is TextBox) && !(Keyboard.FocusedElement is DataGridCell) && !(Keyboard.FocusedElement is ComboBox))
        { _vp.ZoomSelection(); e.Handled = true; }
        else if (e.Key == Key.Home && !(Keyboard.FocusedElement is TextBox) && !(Keyboard.FocusedElement is DataGridCell))
        { _vp.ZoomExtents(); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.S) { Save_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.W && !InEditField()) { CloseProject_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.P) { PrintView_Click(this, new RoutedEventArgs()); e.Handled = true; }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.O) { Open_Click(this, new RoutedEventArgs()); e.Handled = true; }
    }

    // ------------------------------------------------------------------ calcul
    private void Run_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            ReadParams();
            LogBox.Clear(); _journal.Clear();
            var issues = ModelChecker.Check(_model);
            FillIssues(issues);
            foreach (var advice in SettingsAdvisor.Check(_model)) Log("Conseil : " + advice);
            if (issues.Any(i => i.Level == IssueLevel.Error))
            {
                int ne = issues.Count(i => i.Level == IssueLevel.Error);
                Log($"Calcul annulé : {ne} erreur(s) dans le modèle (voir l'onglet Vérification).");
                StatusLeft.Text = $"Modèle invalide : {ne} erreur(s) à corriger (onglet Vérification).";
                BottomTabs.SelectedItem = TabCheck;
                return;
            }
            StatusLeft.Text = "Calcul en cours...";
            Log($"Calcul : norme BA = {_model.RcCodeId}, norme CM = {_model.SteelCodeId}, {_model.Nodes.Count} nœuds, {_model.Members.Count} barres.");
            _out = ProjectAnalyzer.Run(_model, ChkOptimize.IsChecked == true);

            _vp.Output = _out;
            FillSourceCombos();
            _vp.Redraw();
            RefreshStructure();
            FillResults();
            ResultText.Text = ReportWriter.ToText(_out) + (_out.SlabFields.Count > 0 ? "\n\n" + StructCalc.Engine.Structure.SlabFE.Report(_out.SlabFields) : "");
            QtyText.Text = Quantities.Compute(_model, _out).ToText();
            GridMembers.Items.Refresh();
            GridSlabs.Items.Refresh();
            foreach (var msg in _out.Messages) Log(msg);

            int ko = _out.Members.Count(r => !r.Ok && !r.Skipped);
            int sk = _out.Members.Count(r => r.Skipped);
            int ok = _out.Members.Count(r => r.Ok && !r.Skipped);
            Log($"Terminé : {_out.Iterations} itération(s) ; {ok} OK ; {ko} NON OK ; {sk} non traitée(s) ; {_out.Slabs.Count} dalle(s) ; {_out.Footings.Count} semelle(s).");
            StatusLeft.Text = ko == 0 ? "Calcul terminé : tout est OK ✔" : $"Calcul terminé : {ko} barre(s) NON OK ✖";
            StatusMid.Text = $"{ok} OK · {ko} NON OK · {sk} non traitées · {_out.Slabs.Count} dalle(s) · {_out.Footings.Count} semelle(s) · {_out.Iterations} itération(s)";
            RebuildMessages();
            BottomTabs.SelectedItem = TabResults;
            if (_vp.SelectedId >= 0) ShowMember(_vp.SelectedId);
        }
        catch (Exception ex)
        {
            Log("ERREUR : " + ex.Message);
            StatusLeft.Text = "Erreur : " + ex.Message;
            BottomTabs.SelectedIndex = BottomTabs.Items.Count - 1;
        }
    }

    private static ResultRow ToRow(MemberDesignResult r)
    {
        double mt = r.MuSag, ma = r.MuHog;
        if (r.Type == MemberType.Column && r.StMsag.Length > 0) { mt = Math.Max(r.StMsag.Max(), r.StMhog.Max()); ma = 0; }
        string typ = (r.Kind == MaterialKind.Steel ? "acier" : "BA");
        return new ResultRow
        {
            Barre = r.MemberId,
            Type = (r.Type == MemberType.Column ? "Poteau " : "Poutre ") + typ,
            Section = SecText(r),
            Longueur = Math.Round(Units.Len(r.Length), 2),
            MuTravee = Math.Round(Units.Mom(mt), 1), MuAppui = Math.Round(Units.Mom(ma), 1),
            Vu = Math.Round(Units.Frc(r.Vu), 1), Nu = Math.Round(Units.Frc(r.NuMax), 0),
            ArmInf = r.BarsBottom,
            ArmSup = r.Kind == MaterialKind.Steel || r.Type == MemberType.Column ? "-" : r.BarsTop,
            Transversales = r.Stirrups,
            TauxPct = r.Skipped ? 0 : Math.Min(r.Utilization * 100, 100),
            TauxText = r.Skipped ? "-" : $"{r.Utilization * 100:0} %",
            Etat = r.Status,
        };
    }

    private bool _syncFilter;

    private void FillResults()
    {
        var f = (ResultFilter)Math.Max(0, ComboFilter?.SelectedIndex ?? 0);
        GridResults.ItemsSource = _out == null ? null : _out.Members.Where(r => f == ResultFilter.Tous || (f == ResultFilter.Poteaux && r.Type == MemberType.Column) || (f == ResultFilter.Poutres && r.Type != MemberType.Column)).Select(ToRow).ToList();
    }

    // ------------------------------------------------------------------ sélection d'une barre
    private bool _syncGrid;

    private void OnMemberSelected(int id)
    {
        if (_vp.Selection.Count > 1) ShowGroup();
        else ShowMember(id);
        _panel?.SelectMember(id);
        if (GridResults.ItemsSource is List<ResultRow> rows)
        {
            var row = rows.FirstOrDefault(r => r.Barre == id);
            _syncGrid = true;
            try { GridResults.SelectedItem = row; if (row != null) GridResults.ScrollIntoView(row); }
            finally { _syncGrid = false; }
        }
        UpdateSelectionStatus();
    }

    private void GridResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_syncGrid) return;
        if (GridResults.SelectedItem is ResultRow row)
        {
            _vp.SelectedId = row.Barre;
            _vp.Redraw();
            ShowMember(row.Barre);
            _panel?.SelectMember(row.Barre);
            UpdateSelectionStatus();
        }
    }

    private void ShowMember(int id)
    {
        var mem = id < 0 ? null : _model.Members.FirstOrDefault(m => m.Id == id);
        FillEditor(mem);
        if (mem == null)
        {
            DetailTitle.Text = "Aucune barre sélectionnée";
            DetailSub.Text = "Cliquez sur une barre dans la vue ou dans le tableau des résultats.";
            SectionDrawing.Draw(SectionCanvas, null, null);
            GridProps.ItemsSource = null; NotesBox.Text = "";
            return;
        }
        var r = _out?.Members.FirstOrDefault(x => x.MemberId == id);
        string typ = mem.Type == MemberType.Column ? "Poteau" : "Poutre";
        string mat = mem.Kind == MaterialKind.Steel ? "acier" : "béton armé";
        DetailTitle.Text = $"Barre {mem.Id} - {typ} ({mat}) {(r != null ? SecText(r) : "")}";
        DetailSub.Text = r == null ? "Lancez le calcul (F5) pour voir les résultats." : $"État : {r.Status}";

        var props = new List<object>
        {
            new { Parametre = "Nœuds i - j", Valeur = $"{mem.NodeI} - {mem.NodeJ}" },
            new { Parametre = "Longueur", Valeur = r != null ? $"{Units.LenS(r.Length)} {Units.Length}" : "" },
        };
        if (r != null)
        {
            if (mem.Kind == MaterialKind.Steel)
            {
                props.Add(new { Parametre = "Profil", Valeur = r.Profile });
                props.Add(new { Parametre = "Taux de travail", Valeur = $"{r.Utilization * 100:0} %" });
                props.Add(new { Parametre = "N compression max", Valeur = $"{Units.FrcS(r.NuMax, "0")} {Units.Force}" });
                props.Add(new { Parametre = "M max", Valeur = $"{Units.MomS(Math.Max(r.MuSag, r.MuHog))} {Units.MomentUnit}" });
                props.Add(new { Parametre = "V max", Valeur = $"{Units.FrcS(r.Vu)} {Units.Force}" });
            }
            else if (mem.Type == MemberType.Column)
            {
                props.Add(new { Parametre = "Nu max", Valeur = $"{Units.FrcS(r.NuMax, "0")} {Units.Force}" });
                props.Add(new { Parametre = "Vu max", Valeur = $"{Units.FrcS(r.Vu)} {Units.Force}" });
                props.Add(new { Parametre = "As totale", Valeur = $"{Units.AsS(r.AsBottom)} {Units.AsU}" });
                props.Add(new { Parametre = "Armatures", Valeur = r.BarsBottom });
                props.Add(new { Parametre = "Cadres", Valeur = r.Stirrups });
                props.Add(new { Parametre = "Taux (As / As max)", Valeur = $"{r.Utilization * 100:0} %" });
            }
            else
            {
                props.Add(new { Parametre = "Mu travée", Valeur = $"{Units.MomS(r.MuSag)} {Units.MomentUnit}" });
                props.Add(new { Parametre = "Mu appui", Valeur = $"{Units.MomS(r.MuHog)} {Units.MomentUnit}" });
                props.Add(new { Parametre = "Vu max", Valeur = $"{Units.FrcS(r.Vu)} {Units.Force}" });
                props.Add(new { Parametre = "As inférieure", Valeur = $"{Units.AsS(r.AsBottom)} {Units.AsU}  ({r.BarsBottom})" });
                props.Add(new { Parametre = "As supérieure", Valeur = $"{Units.AsS(r.AsTop)} {Units.AsU}  ({r.BarsTop})" });
                props.Add(new { Parametre = "Cadres", Valeur = r.Stirrups });
                props.Add(new { Parametre = "Taux (sollicitation / limite)", Valeur = $"{r.Utilization * 100:0} %" });
            }
        }
        GridProps.ItemsSource = props;
        SectionDrawing.MountingDiaMm = _model.Settings.MountingBarDiaMm;
        SectionDrawing.Draw(SectionCanvas, mem, r);

        if (r == null) { NotesBox.Text = ""; return; }
        var lines = new List<string>(r.Notes);
        foreach (var w in r.Warnings.Distinct()) lines.Add("⚠ " + w);
        NotesBox.Text = string.Join(Environment.NewLine, lines);
    }

    // ------------------------------------------------------------------ vue
    private void ViewElev_Click(object sender, RoutedEventArgs e) => _vp.SetMode(ViewMode.Elevation);
    private void ViewPlan_Click(object sender, RoutedEventArgs e) => _vp.SetMode(ViewMode.Plan);
    private void ViewSide_Click(object sender, RoutedEventArgs e) => _vp.SetMode(ViewMode.Side);
    private void ViewIso_Click(object sender, RoutedEventArgs e) => _vp.SetMode(ViewMode.Iso);
    private void Fit_Click(object sender, RoutedEventArgs e) => _vp.ZoomExtents();

    private void ViewOption_Changed(object sender, RoutedEventArgs e)
    {
        if (_vp == null || ChkLabels == null || ChkLoads == null || ComboDiagram == null || ComboFilter == null || ComboSlabView == null || ChkSlabMesh == null || ComboSource == null || ComboDeform == null) return;
        if (!_fillingSources)
        {
            _vp.DiagramSource = ComboSource.SelectedItem as string ?? StructCalc.Engine.Results.ResultsStore.EnvUls;
            _vp.DeformSource = ComboDeform.SelectedIndex <= 0 ? "" : ComboDeform.SelectedItem as string ?? "";
            if (_vp.DeformSource != "") ChkDeformed.IsChecked = true;
        }
        _vp.ShowLabels = ChkLabels.IsChecked == true;
        _vp.ShowLoads = ChkLoads.IsChecked == true;
        _vp.Diagram = (DiagramKind)Math.Max(0, ComboDiagram.SelectedIndex);
        var oldFilter = _vp.Filter;
        _vp.Filter = (ResultFilter)Math.Max(0, ComboFilter.SelectedIndex);
        if (_vp.Filter == ResultFilter.Dalles && oldFilter != ResultFilter.Dalles && ComboSlabView.SelectedIndex == 0 && _out?.SlabFields.Count > 0)
            ComboSlabView.SelectedIndex = (int)StructCalc.Engine.Structure.SlabFieldKind.Mx;      // « dalles seulement » : carte des moments par défaut
        _vp.SlabView = (StructCalc.Engine.Structure.SlabFieldKind)Math.Max(0, ComboSlabView.SelectedIndex);
        _vp.SlabMesh = ChkSlabMesh.IsChecked == true;
        if ((_vp.SlabView != StructCalc.Engine.Structure.SlabFieldKind.None || _vp.SlabMesh) && _vp.Mode != ViewMode.Plan && _vp.Mode != ViewMode.Iso) _vp.SetMode(ViewMode.Plan);
        if (_out != null && !_syncFilter) { _syncFilter = true; try { FillResults(); } finally { _syncFilter = false; } }
        _vp.Redraw();
    }

    // ------------------------------------------------------------------ exports
    private bool EnsureResults()
    {
        if (_out != null) return true;
        MessageBox.Show("Lancez d'abord le calcul (F5).", "StructCalc", MessageBoxButton.OK, MessageBoxImage.Information);
        return false;
    }

    private void Html_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        var dlg = new SaveFileDialog { Filter = "Page HTML (*.html)|*.html", FileName = "Note_de_calcul.html" };
        if (dlg.ShowDialog() != true) return;
        File.WriteAllText(dlg.FileName, ReportWriter.ToHtml(_model, _out!));
        Log("Note de calcul : " + dlg.FileName);
        Process.Start(new ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
    }

    private void Csv_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        var dlg = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "Resultats.csv" };
        if (dlg.ShowDialog() != true) return;
        File.WriteAllText(dlg.FileName, ReportWriter.ToCsv(_out!), new System.Text.UTF8Encoding(true));
        Log("CSV : " + dlg.FileName);
    }

    private bool _soilSync;

    /// <summary>Choix d'un type de sol : remplit la contrainte admissible (kPa) ; « saisie libre » laisse la valeur modifiable.</summary>
    private void SoilPreset_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_soilSync || SoilPresetBox.SelectedIndex < 0) return;
        int i = SoilPresetBox.SelectedIndex;
        if (i >= SoilPresets.All.Length) { SoilBox.Focus(); SoilBox.SelectAll(); UpdateSoilInfo(); return; }
        _soilSync = true;
        SoilBox.Text = SoilPresets.All[i].QAdmKPa.ToString(CultureInfo.InvariantCulture);
        _soilSync = false;
        UpdateSoilInfo();
    }

    /// <summary>Valeur tapée à la main : on bascule sur « saisie libre », ou sur le type de sol correspondant si la valeur est celle d'un type.</summary>
    private void SoilBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_soilSync) return;
        UpdateSoilInfo();
    }

    private void UpdateSoilInfo()
    {
        if (SoilPresetBox == null || SoilInfo == null || SoilBox == null) return;
        double v = Num(SoilBox.Text, 0);
        var pr = SoilPresets.Match(v);
        _soilSync = true;
        SoilPresetBox.SelectedIndex = pr != null ? Array.IndexOf(SoilPresets.All, pr) : SoilPresets.All.Length;
        _soilSync = false;
        SoilInfo.Text = v <= 0 ? "0 = pas de calcul de semelles"
            : $"{v:0.#} kPa = {v / 1000.0:0.###} MPa" + (pr != null ? "  -  " + pr.Remark : "  -  valeur saisie (étude géotechnique)");
    }

    /// <summary>Envoie le résumé des résultats à Revit (dossier d'échange) : dans Revit, bouton « Importer résultats ».</summary>
    private void SendToRevit_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        try
        {
            ModelIO.SaveRevitSummary(_out!, RevitLink.ToRevit, _model);
            int withId = _out!.Members.Count(m => !string.IsNullOrEmpty(m.ExternalId));
            string msg = withId > 0
                ? $"Résultats envoyés à Revit ({withId} élément(s) liés). Dans Revit : onglet Compléments > StructCalc > « Importer résultats »."
                : "Résultats enregistrés, mais aucune barre n'est liée à un élément Revit (modèle non issu de Revit) : rien à réinjecter.";
            // plans d'exécution (ferraillage...) : repris dans Revit par « Importer plans »
            int nPlans = 0;
            try
            {
                var sheets = StructCalc.Engine.Drawing.DrawingGenerator.Generate(_model, _out!, LicenseManager.Current.IsFull);
                StructCalc.Engine.Drawing.SheetExchange.Save(sheets, RevitLink.PlansToRevit);
                nPlans = sheets.Count;
            }
            catch (Exception ex2) { Log("Plans non envoyés à Revit : " + ex2.Message); }
            if (nPlans > 0) msg += $"  {nPlans} planche(s) d'exécution prêtes : dans Revit, bouton « Importer plans ».";
            Log(msg); StatusLeft.Text = msg;
        }
        catch (Exception ex) { Log("Envoi à Revit impossible : " + ex.Message); }
    }

    /// <summary>Appelé une fois la fenêtre affichée : surveillance du dossier Revit et ouverture du fichier passé en argument.</summary>
    internal void AfterShow(string? file)
    {
        StartRevitWatch();
        try { CustomProfiles.Apply(CustomProfiles.Load()); } catch { }
        StartAutoSave();
        ApplyAppearance();
        Theme.Changed += ApplyViewBack;
        if (string.IsNullOrEmpty(file)) { Dispatcher.BeginInvoke(new Action(() => { OfferRecovery(); StartupWelcome(); }), DispatcherPriority.ApplicationIdle); return; }
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (OpenModelFile(file)) StatusLeft.Text = "Modèle ouvert : " + file + (file.Contains("from_revit") ? "  (envoyé par Revit : ajoutez les charges, puis F5)" : "");
        }), DispatcherPriority.ApplicationIdle);
    }

    private FileSystemWatcher? _revitWatch;
    private DateTime _revitSeen = DateTime.MinValue;

    /// <summary>Surveille le dossier d'échange : quand Revit envoie un modèle alors que le logiciel est ouvert, propose de l'ouvrir.</summary>
    private void StartRevitWatch()
    {
        try
        {
            _revitWatch = new FileSystemWatcher(RevitLink.Dir, "from_revit.json") { NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.CreationTime | NotifyFilters.Size };
            FileSystemEventHandler h = (s, a) => Dispatcher.BeginInvoke(new Action(OnRevitModelReceived), System.Windows.Threading.DispatcherPriority.Background);
            _revitWatch.Changed += h; _revitWatch.Created += h;
            _revitWatch.EnableRaisingEvents = true;
        }
        catch { }
    }

    private void OnRevitModelReceived()
    {
        try
        {
            var t = File.GetLastWriteTime(RevitLink.FromRevit);
            if ((t - _revitSeen).TotalSeconds < 3) return;       // plusieurs évènements pour une même écriture
            _revitSeen = t;
            if (MessageBox.Show("Revit vient d'envoyer un modèle. L'ouvrir maintenant ?\n(Le modèle actuel sera remplacé ; Ctrl+Z pour revenir.)", "StructCalc - Revit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            PushUndo();
            if (OpenModelFile(RevitLink.FromRevit)) { StatusLeft.Text = "Modèle reçu de Revit ouvert. Ajoutez les charges, puis F5."; }
        }
        catch (Exception ex) { Log("Réception Revit : " + ex.Message); }
    }

    /// <summary>Ouvre à la demande le dernier modèle exporté par Revit (menu Fichier ou onglet Importer).</summary>
    private void OpenRevitModel_Click(object sender, RoutedEventArgs e)
    {
        if (!File.Exists(RevitLink.FromRevit))
        {
            MessageBox.Show("Aucun modèle reçu de Revit pour l'instant.\nDans Revit : onglet Compléments > StructCalc > « Envoyer vers StructCalc ».", "StructCalc - Revit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (MessageBox.Show($"Ouvrir le modèle reçu de Revit le {File.GetLastWriteTime(RevitLink.FromRevit):dd/MM/yyyy HH:mm} ?\n(Le modèle actuel sera remplacé ; Ctrl+Z pour revenir.)", "StructCalc - Revit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        PushUndo();
        if (OpenModelFile(RevitLink.FromRevit)) StatusLeft.Text = "Modèle reçu de Revit ouvert. Ajoutez les charges, puis F5.";
    }

    private void Revit_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureResults()) return;
        var dlg = new SaveFileDialog { Filter = "JSON (*.json)|*.json", FileName = "Resume_Revit.json" };
        if (dlg.ShowDialog() != true) return;
        ModelIO.SaveRevitSummary(_out!, dlg.FileName);
        Log("Résumé pour Revit : " + dlg.FileName);
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        var lines = DesignCodeRegistry.All.Select(c => (c.IsImplemented ? "  ✔ " : "  ○ ") + c.DisplayName);
        MessageBox.Show("StructCalc - dimensionnement automatisé béton armé / charpente métallique\n\nNormes :\n" +
                        string.Join("\n", lines) +
                        $"\n\nAuteur : {AppInfo.ContactLine}\n{AppInfo.Copyright}\nLicence : {LicenseManager.Current.Message}\n\nLes résultats doivent être vérifiés par l'ingénieur responsable avant exécution.",
                        "À propos de StructCalc", MessageBoxButton.OK, MessageBoxImage.Information);
    }
}
