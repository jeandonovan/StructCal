using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Results;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Alertes de dimensionnement (NON OK) : clic = sélection de l'élément, clic droit = résultats détaillés, diagrammes, combinaison critique et solutions
/// de dimensionnement. Aucune solution n'est appliquée sans validation : la fenêtre « Solutions » recalcule d'abord sur une copie et montre le taux avant / après.</summary>
public partial class MainWindow
{
    // ------------------------------------------------------------------ ouverture de la fenêtre de solutions
    private void OpenSolutions(string title, FixTarget t, List<FixOption> opts)
    {
        if (_out == null) { MessageBox.Show(this, "Lancez d'abord le calcul (F5) : les solutions se comparent aux résultats actuels.", "Solutions de dimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (opts.Count == 0)
        {
            MessageBox.Show(this, title + "\n\nAucune solution de dimensionnement automatique pour cette alerte.\n\n" + t.Detail, "Solutions de dimensionnement", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        ReadParams();
        string json = ModelIO.ToJson(_model);
        int before = DesignFixes.NonOkCount(_out);
        var w = new SolutionsWindow(this, t, opts, json, before, title);
        if (w.ShowDialog() != true || w.Chosen == null) return;
        ApplySolution(w.Chosen, title);
    }

    /// <summary>Applique la solution choisie (annulable par Ctrl+Z), remet les champs du projet d'accord avec le modèle, puis relance le calcul.</summary>
    private void ApplySolution(FixOption f, string title)
    {
        if (f.Step == null) return;
        CommitGrids(); PushUndo();
        string snap = _undo.Count > 0 ? _undo[^1] : "";
        try { f.Step.Apply(_model); }
        catch (Exception ex)
        {
            if (snap != "") { _undo.RemoveAt(_undo.Count - 1); _model = ModelIO.FromJson(snap); BindModel(); UpdateUndoUi(); }
            Say("Solution non appliquée, le modèle est resté inchangé : " + ex.Message);
            return;
        }
        FcBox.Text = _model.Fc28.ToString(CultureInfo.InvariantCulture);
        FeBox.Text = _model.Fe.ToString(CultureInfo.InvariantCulture);
        OnModelEdited();
        Log($"{title} : solution appliquée - {f.Label} ({f.Change}).");
        Say($"{f.Label} : {f.Change}. Recalcul...  (Ctrl+Z pour annuler.)");
        Run_Click(this, new RoutedEventArgs());
    }

    private void OpenMemberSolutions(int id, string[]? only, bool deflection = false, double? customB = null, double? customH = null)
    {
        if (_out == null) { MessageBox.Show(this, "Lancez d'abord le calcul (F5).", "Solutions de dimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        ReadParams();
        var (t, opts) = DesignFixes.ForMember(_model, _out, id, deflection);
        if (customB != null && customH != null) opts = new List<FixOption> { DesignFixes.CustomSection(_model, id, customB.Value, customH.Value) };
        else if (only != null) opts = opts.Where(q => only.Contains(q.Id)).ToList();
        OpenSolutions($"Solutions de dimensionnement - barre {id}" + (deflection ? " (flèche)" : ""), t, opts);
    }

    private void OpenSlabSolutions(string slabName, string[]? only = null)
    {
        if (_out == null) { MessageBox.Show(this, "Lancez d'abord le calcul (F5).", "Solutions de dimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        ReadParams();
        var (t, opts) = DesignFixes.ForSlab(_model, _out, slabName);
        if (only != null) opts = opts.Where(q => only.Contains(q.Id)).ToList();
        OpenSolutions($"Solutions de dimensionnement - dalle {slabName}", t, opts);
    }

    private void OpenPunchingSolutions(PunchingResult p, string[]? only = null)
    {
        if (_out == null) { MessageBox.Show(this, "Lancez d'abord le calcul (F5).", "Solutions de dimensionnement", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        ReadParams();
        var (t, opts) = DesignFixes.ForPunching(_model, _out, p);
        if (only != null) opts = opts.Where(q => only.Contains(q.Id)).ToList();
        OpenSolutions($"Solutions de dimensionnement - poinçonnement {p.Column} / dalle {p.Slab}", t, opts);
    }

    // ------------------------------------------------------------------ affichages liés à une barre
    private void SelectMemberById(int id)
    {
        if (_model.Members.All(q => q.Id != id)) return;
        if (_vp.HiddenMembers.Contains(id)) _vp.Unhide(new[] { id }, Array.Empty<int>(), Array.Empty<object>());
        _vp.SetSelection(new[] { id });
        _vp.ZoomSelection();
    }

    private void ShowMemberDetails(int id)
    {
        SelectMemberById(id);
        BottomTabs.SelectedItem = TabResults;
        ShowMember(id);
        ResultsExplorer_Click(this, new RoutedEventArgs());
    }

    private void ShowDiagram(DiagramKind kind, string? source)
    {
        if (_out == null) return;
        if (source != null && !string.IsNullOrEmpty(source) && ComboSource.Items.Contains(source)) ComboSource.SelectedItem = source;
        ComboDiagram.SelectedIndex = (int)kind;
        ViewOption_Changed(this, new RoutedEventArgs());
    }

    private void ShowCritical(int id)
    {
        if (_out == null) return;
        var c = DesignFixes.Critical(_out, id);
        SelectMemberById(id);
        ShowDiagram(DiagramKind.Moment, c.MomentCombo);
        Log(c.Text);
        MessageBox.Show(this, c.Text + "\n\nLe diagramme des moments de la vue est réglé sur la combinaison qui donne le moment maximal.", "Combinaison critique", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void ShowDeformedFor(string? combo)
    {
        if (_out == null) return;
        if (!string.IsNullOrEmpty(combo) && ComboDeform.Items.Contains(combo)) ComboDeform.SelectedItem = combo;
        ChkDeformed.IsChecked = true;
        ViewOption_Changed(this, new RoutedEventArgs());
    }

    // ------------------------------------------------------------------ menu d'une barre (tableau RÉSULTATS et onglet Messages)
    private void BuildMemberAlertMenu(ContextMenu cm, int id, bool deflection = false)
    {
        var r = _out?.Members.FirstOrDefault(x => x.MemberId == id);
        bool bad = r != null && !r.Ok && !r.Skipped;
        cm.Items.Add(MenuTitle(r == null ? $"Barre {id}" : $"Barre {id} - {r.Status}" + (r.Skipped ? "" : $" - taux {r.Utilization * 100:0} %")));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Sélectionner la barre dans la vue", () => SelectMemberById(id)));
        cm.Items.Add(Mi("Afficher les résultats détaillés de la barre...", () => ShowMemberDetails(id), _out != null));
        cm.Items.Add(Mi("Afficher le diagramme des moments", () => { SelectMemberById(id); ShowDiagram(DiagramKind.Moment, null); }, _out != null));
        cm.Items.Add(Mi("Afficher le diagramme des efforts tranchants", () => { SelectMemberById(id); ShowDiagram(DiagramKind.Shear, null); }, _out != null));
        cm.Items.Add(Mi("Afficher les déplacements (déformée)", () => { SelectMemberById(id); ShowDeformedFor(null); }, _out != null));
        cm.Items.Add(Mi("Afficher la combinaison critique...", () => ShowCritical(id), _out?.Store != null));
        if (_out != null && (bad || deflection))
        {
            var (_, opts) = DesignFixes.ForMember(_model, _out, id, deflection);
            bool Has(string oid) => opts.Any(q => q.Id == oid);
            cm.Items.Add(new Separator());
            cm.Items.Add(MenuTitle("Solutions de dimensionnement (validation avant toute modification)"));
            cm.Items.Add(Mi("Comparer toutes les solutions : taux avant / après...", () => OpenMemberSolutions(id, null, deflection)));
            if (Has("PROFILE")) cm.Items.Add(Mi("Passer au profilé supérieur...", () => OpenMemberSolutions(id, new[] { "PROFILE" }, deflection)));
            if (Has("H")) cm.Items.Add(Mi("Augmenter la hauteur de la section...", () => OpenMemberSolutions(id, new[] { "H" }, deflection)));
            if (Has("B")) cm.Items.Add(Mi("Augmenter la largeur de la section...", () => OpenMemberSolutions(id, new[] { "B" }, deflection)));
            if (Has("SEC")) cm.Items.Add(Mi("Augmenter la section du poteau (b et h)...", () => OpenMemberSolutions(id, new[] { "SEC" }, deflection)));
            var mem = _model.Members.FirstOrDefault(q => q.Id == id);
            if (mem != null && mem.Kind == MaterialKind.ReinforcedConcrete)
            {
                string curB = Ui.Fmt(mem.B * 100), curH = Ui.Fmt(mem.H * 100);
                cm.Items.Add(Mi("Choisir une autre section (b x h saisis)...", () =>
                {
                    var v = PromptWindow.Ask(this, $"Autre section - barre {id}", "Saisissez la section à essayer (cm). Elle sera recalculée sur une copie avant toute application.",
                        ("Largeur b (cm)", curB), ("Hauteur h (cm)", curH));
                    if (v == null) return;
                    double nb = Ui.Num(v[0]), nh = Ui.Num(v[1]);
                    if (double.IsNaN(nb) || double.IsNaN(nh) || nb < 10 || nh < 10 || nb > 300 || nh > 300) { MessageBox.Show(this, "Dimensions invalides (10 à 300 cm).", "Autre section", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
                    OpenMemberSolutions(id, null, deflection, nb, nh);
                }));
            }
            if (Has("FC")) cm.Items.Add(Mi("Augmenter la classe de béton (toute la structure)...", () => OpenMemberSolutions(id, new[] { "FC" }, deflection)));
            if (Has("FE")) cm.Items.Add(Mi("Augmenter la nuance des aciers (toute la structure)...", () => OpenMemberSolutions(id, new[] { "FE" }, deflection)));
            if (Has("DIA") || Has("BARS")) cm.Items.Add(Mi("Augmenter le diamètre / le nombre d'aciers autorisés...", () => OpenMemberSolutions(id, new[] { "DIA", "BARS" }, deflection)));
            if (Has("COVER")) cm.Items.Add(Mi("Modifier l'enrobage...", () => OpenMemberSolutions(id, new[] { "COVER" }, deflection)));
            if (Has("OPTIM")) cm.Items.Add(Mi("Relancer l'optimisation de la barre...", () => OpenMemberSolutions(id, new[] { "OPTIM" }, deflection)));
            var am = _msgs.FirstOrDefault(q => q.MemberId == id && q.Family == MsgFamily.Dimensionnement);
            if (am != null)
            {
                cm.Items.Add(new Separator());
                cm.Items.Add(Mi("Ignorer temporairement l'alerte (justification obligatoire)...", () => IgnoreMessage(am)));
            }
        }
        else if (r != null && r.Ok)
            cm.Items.Add(Mi("Cette barre est vérifiée : aucune solution à proposer", () => { }, false));
    }

    // ------------------------------------------------------------------ menus des autres alertes de dimensionnement
    private void BuildSlabAlertMenu(ContextMenu cm, string slabName)
    {
        var slab = _model.Slabs.FirstOrDefault(q => q.Name == slabName);
        cm.Items.Add(MenuTitle("Dalle " + slabName));
        cm.Items.Add(new Separator());
        if (slab != null)
        {
            cm.Items.Add(Mi("Sélectionner et zoomer sur la dalle", () => { _vp.SelectSlab(slab); _vp.ZoomSlab(slab); }));
            cm.Items.Add(Mi("Afficher le rapport de calcul des dalles", () => ShowModuleReport("Dalle " + slabName)));
            cm.Items.Add(new Separator());
            cm.Items.Add(MenuTitle("Solutions de dimensionnement (validation avant toute modification)"));
            cm.Items.Add(Mi("Comparer toutes les solutions...", () => OpenSlabSolutions(slabName)));
            cm.Items.Add(Mi("Augmenter l'épaisseur de la dalle...", () => OpenSlabSolutions(slabName, new[] { "SLABH" })));
            cm.Items.Add(Mi("Propriétés de la dalle (épaisseur, charges, continuité, méthode)...", () => SlabProps(slab)));
        }
    }

    private void BuildPunchingMenu(ContextMenu cm, PunchingResult p)
    {
        cm.Items.Add(MenuTitle($"Poinçonnement - {p.Column} / dalle {p.Slab}"));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Afficher les valeurs du poinçonnement (V_Ed, résistances, périmètre, d, Asw)...", () =>
            MessageBox.Show(this, DesignFixes.ForPunching(_model, _out ?? new AnalysisOutput(), p).Target.Detail, "Poinçonnement", MessageBoxButton.OK, MessageBoxImage.Information)));
        cm.Items.Add(Mi("Sélectionner la dalle et le poteau", () => FocusPunching(p)));
        cm.Items.Add(new Separator());
        cm.Items.Add(MenuTitle("Solutions de dimensionnement (validation avant toute modification)"));
        cm.Items.Add(Mi("Comparer toutes les solutions : taux avant / après...", () => OpenPunchingSolutions(p)));
        cm.Items.Add(Mi("Ajouter ou agrandir un chapiteau...", () => OpenPunchingSolutions(p, new[] { "CAP" })));
        cm.Items.Add(Mi("Augmenter l'épaisseur de la dalle...", () => OpenPunchingSolutions(p, new[] { "SLABH" })));
        cm.Items.Add(Mi("Augmenter la section du poteau...", () => OpenPunchingSolutions(p, new[] { "SEC" })));
    }

    private void FocusPunching(PunchingResult p)
    {
        var node = _model.Nodes.FirstOrDefault(n => Math.Abs(n.X - p.X) < 0.01 && Math.Abs(n.Y - p.Y) < 0.01 && Math.Abs(n.Z - p.Z) < 0.05);
        var slab = _model.Slabs.FirstOrDefault(q => q.Name == p.Slab);
        if (slab != null) { _vp.SelectSlab(slab); _vp.ZoomSlab(slab); }
        else if (node != null) { _vp.SelectNodesOnly(new[] { node.Id }); _vp.ZoomNodes(new[] { node.Id }); }
    }

    /// <summary>Affiche le rapport texte (onglet « Dalles / Semelles / Alertes ») et place le curseur sur le module demandé.</summary>
    private void ShowModuleReport(string title)
    {
        BottomTabs.SelectedItem = TabAlerts;
        string txt = ResultText.Text ?? "";
        int idx = txt.IndexOf(title, StringComparison.OrdinalIgnoreCase);
        if (idx < 0 && title.Contains(' ')) idx = txt.IndexOf(title.Split(' ')[1], StringComparison.OrdinalIgnoreCase);
        if (idx >= 0)
        {
            ResultText.Focus();
            ResultText.Select(idx, Math.Min(title.Length, txt.Length - idx));
            try { ResultText.ScrollToLine(ResultText.GetLineIndexFromCharacterIndex(idx)); } catch { }
        }
    }

    private void BuildFootingMenu(ContextMenu cm, AppMessage am, DesignResult f)
    {
        cm.Items.Add(MenuTitle(Trunc(f.Element, 90)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Sélectionner le nœud d'appui", () => FocusMessage(am)));
        cm.Items.Add(Mi("Afficher le détail de la non-conformité...", () => MessageBox.Show(this, DesignFixes.ForFooting(f).Detail, "Semelle", MessageBoxButton.OK, MessageBoxImage.Information)));
        cm.Items.Add(new Separator());
        cm.Items.Add(MenuTitle("Une semelle NON OK vient du sol, pas de la section : aucune solution automatique"));
        cm.Items.Add(Mi("Ouvrir l'assistant Sol et semelles (contrainte admissible, profondeur, dimensions)...", () => Soil_Click(this, new RoutedEventArgs())));
    }

    private void BuildModuleMenu(ContextMenu cm, AppMessage am, ExtraDesign x)
    {
        cm.Items.Add(MenuTitle(Trunc(x.Title, 90)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Sélectionner l'élément concerné", () => FocusMessage(am)));
        cm.Items.Add(Mi("Afficher le rapport du module", () => ShowModuleReport(x.Title)));
        cm.Items.Add(new Separator());
        cm.Items.Add(MenuTitle("Pas de solution automatique pour ce module : corrigez-le dans son assistant"));
    }
}
