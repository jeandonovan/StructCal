using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Attributs d'affichage (façon Robot) et escaliers posés dans le modèle d'ensemble.</summary>
public partial class MainWindow
{
    private AttributesWindow? _attrWin;

    private void Attributes_Click(object sender, RoutedEventArgs e)
    {
        if (_attrWin != null) { _attrWin.Activate(); return; }
        _attrWin = new AttributesWindow(_vp, () =>
        {
            try
            {
                ChkGrid.IsChecked = _vp.ShowGrid; ChkLevels.IsChecked = _vp.ShowLevels;
                ChkLabels.IsChecked = _vp.ShowLabels; ChkLoads.IsChecked = _vp.ShowLoads; ChkFootings.IsChecked = _vp.ShowFootings;
                InitDims();
            }
            catch { }
        }) { Owner = this };
        _attrWin.Closed += (s, a) => _attrWin = null;
        _attrWin.Show();
    }

    // ------------------------------------------------------------------ escaliers dans le modèle d'ensemble
    private static readonly string[] StairTypeNames =
    {
        "0 = droit (une volée)", "1 = droit avec palier", "2 = quart tournant avec palier", "3 = demi-tournant (U) avec palier",
        "4 = double quart tournant", "5 = quart tournant balancé", "6 = demi-tournant balancé", "7 = hélicoïdal"
    };

    private void StairPlace_Click(object sender, RoutedEventArgs e)
    {
        var def = _vp.SelectedStair;
        if (def == null && _model.Stairs.Count > 0) def = _model.Stairs.FirstOrDefault(s => !s.Placed) ?? _model.Stairs[0];
        PlaceStairDialog(def);
    }

    private void FillStairMenu(ContextMenu cm, StairDef d)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.DescribeObject(d)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Position, type et dimensions de l'escalier...", () => PlaceStairDialog(d)));
        cm.Items.Add(Mi("Prédimensionner (contremarche, giron, paillasse)...", () => PreDesignStair(d)));
        cm.Items.Add(Mi("Dimensionner / ferrailler (assistant Escaliers)...", () => Stairs_Click(this, new RoutedEventArgs())));
        cm.Items.Add(Mi("Retirer du modèle d'ensemble", () => StatusLeft.Text = _vp.DeleteSelectedObject(), true, "Suppr"));
        AddVisibilityItems(cm, null, d);
    }

    private void FillFootingMenu(ContextMenu cm, FootingRef f)
    {
        cm.Items.Clear();
        cm.Items.Add(MenuTitle(_vp.DescribeObject(f)));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi("Ouvrir dans l'assistant Sol et semelles (dimensions, glacis, ferraillage)...", () => OpenFootingFor(f.NodeId)));
        cm.Items.Add(Mi("Prédimensionner la semelle...", () => PreDesignFooting(f.NodeId)));
        cm.Items.Add(Mi("Zoom sur la semelle", () => { _vp.SelectNodesOnly(new[] { f.NodeId }); _vp.ZoomNodes(new[] { f.NodeId }); }));
        cm.Items.Add(new Separator());
        cm.Items.Add(Mi(_model.FootingGlacis ? "Réglage général : dessiner les semelles automatiques en blocs" : "Réglage général : dessiner les semelles automatiques à glacis", () =>
        {
            PushUndo(); _model.FootingGlacis = !_model.FootingGlacis; ChkGlacis.IsChecked = _model.FootingGlacis; OnModelEdited();
        }));
        AddVisibilityItems(cm, null, f);
    }

    private void PlaceStairDialog(StairDef? def)
    {
        bool isNew = def == null;
        var info = LevelInfoNow();
        string known = string.Join("\n", StairTypeNames);
        string names = _model.Stairs.Count > 0 ? string.Join(", ", _model.Stairs.Select(s => s.Name)) : "aucun pour l'instant";
        double z0 = def?.Z ?? (_vp.Mode == ViewMode.Plan ? _vp.WorkOffset : 0);
        var v = PromptWindow.Ask(this, "Placer un escalier dans le modèle d'ensemble",
            $"Types connus du logiciel :\n{known}\n\nEscaliers du projet : {names}. Un nom nouveau crée un escalier (dimensionnez-le ensuite avec l'assistant Escaliers). L'escalier est dessiné dans toutes les vues (3D, plan, élévation, côté).",
            ("Nom de l'escalier", def?.Name ?? "E" + (_model.Stairs.Count + 1)),
            ("Type (0 à 7)", ((int)(def?.Layout ?? StairLayout.DroitPalier)).ToString()),
            ("X du départ (m)", Ui.Fmt(def?.X ?? 0)), ("Y du départ (m)", Ui.Fmt(def?.Y ?? 0)),
            ("Z du départ = dessus du plancher bas (m)", Ui.Fmt(z0)),
            ("Rotation autour de Z (°)", Ui.Fmt(def?.AngleDeg ?? 0)),
            ("Hauteur à franchir (m), 0 = niveau suivant", Ui.Fmt(def?.HeightM ?? 0)),
            ("Emmarchement (m)", Ui.Fmt(def?.WidthM ?? 1.2)));
        if (v == null) return;
        string name = v[0].Trim();
        if (name == "") return;
        CommitGrids(); PushUndo();
        var target = _model.Stairs.FirstOrDefault(s => s.Name == name);
        if (target == null) { target = new StairDef { Name = name }; _model.Stairs.Add(target); }
        int lay = (int)Math.Round(Ui.Num(v[1], (int)target.Layout));
        target.Layout = (StairLayout)Math.Clamp(lay, 0, 7);
        target.X = Ui.Num(v[2], target.X); target.Y = Ui.Num(v[3], target.Y); target.Z = Ui.Num(v[4], target.Z);
        target.AngleDeg = Ui.Num(v[5], target.AngleDeg);
        double h = Ui.Num(v[6], 0);
        if (h < 0.5)
        {
            int li = info.Levels.FindIndex(l => Math.Abs(l.Z - target.Z) < 0.05);
            double ha = li >= 0 ? StoreyOps.HeightAbove(info, li) : 0;
            h = ha > 0.5 ? ha : (target.HeightM > 0.5 ? target.HeightM : 3.06);
        }
        target.HeightM = h;
        target.WidthM = Math.Max(0.6, Ui.Num(v[7], target.WidthM));
        target.Placed = true;
        try { GridSlabs.Items.Refresh(); } catch { }
        _vp.SelectObject(target, false);
        _vp.Redraw();
        var g = StructCalc.Engine.Stairs.StairGeometryBuilder.Build(target);
        Say($"Escalier {target.Name} posé : {g.Risers} contremarches de {g.RiserM * 100:0.#} cm, giron {g.TreadM * 100:0.#} cm" + (g.Ok ? "." : " — attention : " + g.Warnings.FirstOrDefault()) + "  (Ctrl+Z pour annuler)");
    }
}
