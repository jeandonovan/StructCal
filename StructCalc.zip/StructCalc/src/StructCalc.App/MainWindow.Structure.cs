using System.Globalization;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Geometry;
using StructCalc.Engine.Structure;

namespace StructCalc.UI;

/// <summary>Étages, grille de construction, ossature depuis la grille, fonds de plan (DXF / DWG / PDF / image) et accrochages.</summary>
public partial class MainWindow
{
    private readonly UnderlayManager _uMgr = new();

    private static double Nm(string? s, double def) => Ui.Num(s, def);

    // ------------------------------------------------------------------ étages
    private void Levels_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var w = new LevelsWindow(_model) { Owner = this };
        if (w.ShowDialog() != true) return;
        PushUndo();
        _model.Levels = w.Result;
        int moved = w.ApplyMoves(_model);
        OnModelEdited();
        Log(w.Result.Count == 0 ? "Étages : détection automatique." : $"Étages : {w.Result.Count} niveau(x) défini(s)" + (moved > 0 ? $", {moved} nœud(s) déplacé(s) avec leur niveau." : "."));
        _vp.ZoomExtents();
    }

    // ------------------------------------------------------------------ grille
    private void Grid_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var w = new GridWindow(_model) { Owner = this };
        if (w.ShowDialog() != true) return;
        PushUndo();
        _model.Grid = w.Result;
        OnModelEdited();
        Log(w.Result.IsEmpty ? "Grille : détection automatique." : $"Grille : {w.Result.XAxes.Count} axes numérotés, {w.Result.YAxes.Count} axes lettrés.");
        _vp.ZoomExtents();
    }

    private void FrameFromGrid_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        if (_model.Levels.Count < 2 || _model.Grid.XAxes.Count == 0 || _model.Grid.YAxes.Count == 0)
        {
            MessageBox.Show("Pour créer l'ossature, définissez d'abord :\n  • les étages (menu Structure › Étages), au moins 2 niveaux ;\n  • la grille (menu Structure › Grille), au moins 1 axe numéroté et 1 axe lettré.",
                "Ossature depuis la grille", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var w = new FrameFromGridWindow(_model.Grid.XAxes.Count, _model.Grid.YAxes.Count, _model.Levels.Count) { Owner = this };
        if (w.ShowDialog() != true) return;
        PushUndo();
        var r = GridTools.GenerateFrame(_model, w.Result);
        OnModelEdited();
        _vp.SetMode(ViewMode.Iso);
        Log($"Ossature créée depuis la grille : {r.NewNodes} nœuds, {r.NewColumns} poteaux, {r.NewBeams} poutres, {r.NewSupports} appuis.");
        StatusLeft.Text = "Ossature créée : vérifiez les charges puis lancez le calcul (F5).";
    }

    private void DupStorey_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        var info = StructureAnalyzer.Analyze(_model);
        if (info.Levels.Count < 2) { MessageBox.Show("Il faut au moins deux niveaux (une base et un étage).", "Étage type", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        string list = string.Join("\n", info.Levels.Select(l => $"  {l.Index} = {l.Label}"));
        var v = PromptWindow.Ask(this, "Dupliquer un étage type",
            "Copie les poutres du niveau choisi et les poteaux situés sous ce niveau, au-dessus du dernier niveau.\nNiveaux :\n" + list,
            ("Numéro du niveau type (≥ 1)", (info.Levels.Count - 1).ToString(CultureInfo.InvariantCulture)), ("Nombre d'étages à ajouter", "2"));
        if (v == null) return;
        int idx = (int)Nm(v[0], -1), count = (int)Nm(v[1], 0);
        if (idx < 1 || idx >= info.Levels.Count || count < 1 || count > 60) { MessageBox.Show("Valeurs invalides.", "Étage type", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        PushUndo();
        var (members, levels) = GridTools.DuplicateTypicalStorey(_model, idx, count);
        OnModelEdited();
        _vp.ZoomExtents();
        Log($"Étage type dupliqué {count} fois : {members} barres ajoutées" + (levels > 0 ? $", {levels} niveau(x) ajouté(s)." : "."));
    }

    // ------------------------------------------------------------------ accrochages
    private void Snap_Changed(object sender, RoutedEventArgs e)
    {
        if (_vp == null || SnapOnItem == null || SnapStepItem == null) return;
        _vp.SnapEnabled = SnapOnItem.IsChecked;
        _vp.SnapNodes = SnapNodeItem.IsChecked; _vp.SnapMid = SnapMidItem.IsChecked; _vp.SnapGridInt = SnapGridItem.IsChecked;
        _vp.SnapOnAxis = SnapAxisItem.IsChecked; _vp.SnapLevels = SnapLevelItem.IsChecked; _vp.SnapTrack = SnapTrackItem.IsChecked;
        _vp.SnapUnderlay = SnapUnderItem.IsChecked; _vp.SnapStep = SnapStepItem.IsChecked;
        _vp.Redraw();
    }

    private void ToggleSnap()
    {
        SnapOnItem.IsChecked = !SnapOnItem.IsChecked;
        Snap_Changed(this, new RoutedEventArgs());
        StatusLeft.Text = SnapOnItem.IsChecked ? "Accrochage activé (F3)." : "Accrochage désactivé (F3) : les points sont posés librement.";
    }

    // ------------------------------------------------------------------ fonds de plan
    private async Task SyncUnderlaysAsync()
    {
        try { await _uMgr.SyncAsync(_model, Log); }
        catch (Exception ex) { Log("Fonds de plan : " + ex.Message); }
        _vp.Underlays = _uMgr.Items;
        _vp.Redraw();
    }

    private async void ImportUnderlay_Click(object sender, RoutedEventArgs e) => await ImportUnderlayAsync(
        (sender as FrameworkElement)?.Tag as string);

    /// <summary>Importe un fond de plan. « mode » limite le choix du fichier : "cad" (DXF/DWG), "pdf", "img" ; null = tous les types.</summary>
    private async Task ImportUnderlayAsync(string? mode = null, string? presetFile = null)
    {
        const string imgExt = "*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff";
        var dlg = new OpenFileDialog
        {
            Title = mode switch { "cad" => "Importer un plan DXF / DWG", "pdf" => "Importer un plan PDF", "img" => "Importer une image de plan", _ => "Importer un fond de plan" },
            Filter = mode switch
            {
                "cad" => "Plans AutoCAD (DXF, DWG)|*.dxf;*.dwg|DXF|*.dxf|DWG (AutoCAD)|*.dwg",
                "pdf" => "PDF (Revit, AutoCAD...)|*.pdf",
                "img" => "Images|" + imgExt,
                _ => "Fonds de plan|*.dxf;*.dwg;*.pdf;" + imgExt + "|DXF|*.dxf|DWG (AutoCAD)|*.dwg|PDF (Revit, AutoCAD...)|*.pdf|Images|" + imgExt
            }
        };
        if (presetFile == null && dlg.ShowDialog() != true) return;
        string original = presetFile ?? dlg.FileName, path = original, kind = UnderlayLoader.KindOf(path);
        try
        {
            if (kind == "dwg")
            {
                StatusLeft.Text = "Conversion DWG → DXF en cours...";
                var (dxf, msg) = await DwgConverter.ConvertAsync(original);
                if (dxf == null) { MessageBox.Show(msg, "Import DWG", MessageBoxButton.OK, MessageBoxImage.Information); StatusLeft.Text = "Import DWG impossible."; return; }
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "fonds");
                Directory.CreateDirectory(dir);
                path = Path.Combine(dir, Path.GetFileNameWithoutExtension(original) + "_" + DateTime.Now.ToString("yyMMddHHmmss") + ".dxf");
                File.Copy(dxf, path, true);
                kind = "dxf";
            }
            var def = new UnderlayDef
            {
                Id = _model.Underlays.Count == 0 ? 1 : _model.Underlays.Max(u => u.Id) + 1,
                Name = Path.GetFileName(original), Kind = kind, Path = path, Opacity = kind == "dxf" ? 0.85 : 0.6
            };
            double den = 100;
            if (kind == "pdf")
            {
                var v = PromptWindow.Ask(this, "Import PDF",
                    "Un PDF issu de Revit ou d'AutoCAD est imprimé à une échelle (ex. 1/100). Indiquez-la pour que le fond soit à la bonne taille ; sinon laissez 100 et calez ensuite avec « Échelle : 2 points + distance réelle ».",
                    ("Échelle du dessin imprimé : 1 /", "100"), ("Page (1 = première)", "1"));
                if (v == null) return;
                den = Math.Max(1, Nm(v[0], 100)); def.Page = Math.Max(0, (int)Nm(v[1], 1) - 1);
            }
            StatusLeft.Text = "Chargement du fond de plan...";
            var data = await UnderlayLoader.LoadAsync(def);
            if (data.Error != "") { MessageBox.Show(data.Error, "Import du fond de plan", MessageBoxButton.OK, MessageBoxImage.Warning); StatusLeft.Text = "Import impossible."; return; }
            string note = "";
            if (kind == "dxf" && data.Dxf != null)
            {
                def.Scale = UnderlayMath.DxfInitialScale(data.Dxf);
                var b = data.Bounds();
                if (b != null && (Math.Abs((b.Value.X0 + b.Value.X1) / 2) > 2000 || Math.Abs((b.Value.Y0 + b.Value.Y1) / 2) > 2000))
                {
                    def.OriginX = -b.Value.X0; def.OriginY = -b.Value.Y0;
                    note = " Le dessin était loin de l'origine : son coin bas-gauche a été ramené en (0 ; 0).";
                }
                note += data.Dxf.MetersPerUnit > 0 ? $" Unités du DXF reconnues (1 unité = {def.Scale} m)." : $" Unités non précisées dans le DXF : échelle supposée {def.Scale} m par unité, à vérifier.";
            }
            else if (kind == "pdf") { def.Scale = UnderlayMath.PdfScale(def.PageWidthMm, def.PixelWidth, den); note = $" PDF mis à l'échelle 1/{den:0}."; }
            else { def.Scale = 0.01; note = " Taille inconnue : utilisez « Échelle : 2 points + distance réelle »."; }
            PushUndo();
            _model.Underlays.Add(def);
            _uMgr.Prime(data);
            await SyncUnderlaysAsync();
            _vp.ZoomUnderlay(def.Id);
            RbSelect.IsChecked = true;
            Log("Fond de plan importé : " + def.Name + "." + note);
            StatusLeft.Text = "Fond de plan importé. Placez-le avec Structure › Fonds de plan (échelle, déplacer, aligner), puis dessinez avec l'accrochage.";
        }
        catch (Exception ex) { Log("Erreur d'import : " + ex.Message); MessageBox.Show(ex.Message, "Import du fond de plan", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private async void Underlays_Click(object sender, RoutedEventArgs e)
    {
        ReadParams();
        string before = ModelIO.ToJson(_model);
        var work = ModelIO.FromJson(before);                 // le dialogue travaille sur une copie : « Annuler » ne change rien
        var w = new UnderlayWindow(work, _uMgr) { Owner = this };
        if (w.ShowDialog() != true) return;
        _undo.Add(before); if (_undo.Count > 80) _undo.RemoveAt(0);
        _redo.Clear(); UpdateUndoUi();
        _model.Underlays = work.Underlays;
        await SyncUnderlaysAsync();
        var def = _model.Underlays.FirstOrDefault(u => u.Id == w.ActionId);
        switch (w.Action)
        {
            case UnderlayAction.Add: await ImportUnderlayAsync(); break;
            case UnderlayAction.Remove:
                if (def != null) { _model.Underlays.Remove(def); await SyncUnderlaysAsync(); Log("Fond de plan retiré : " + def.Name); }
                break;
            case UnderlayAction.Zoom: if (def != null) _vp.ZoomUnderlay(def.Id); break;
            case UnderlayAction.PaperScale:
                if (def != null && def.Kind != "dxf" && def.PageWidthMm > 0)
                {
                    def.Scale = UnderlayMath.PdfScale(def.PageWidthMm, def.PixelWidth, w.PaperDenominator);
                    _vp.Redraw(); Log($"{def.Name} : échelle papier 1/{w.PaperDenominator:0}.");
                }
                else MessageBox.Show("L'échelle papier ne s'applique qu'aux PDF. Pour un DXF, utilisez l'échelle en m par unité.", "Fonds de plan", MessageBoxButton.OK, MessageBoxImage.Information);
                break;
            case UnderlayAction.Calibrate: if (def != null) PickCalibrate(def); break;
            case UnderlayAction.Move: if (def != null) PickMove(def); break;
            case UnderlayAction.Align: if (def != null) PickAlign(def, false); break;
            case UnderlayAction.AlignVertical: if (def != null) PickAlign(def, true); break;
        }
        _vp.Redraw();
    }

    private void PickCalibrate(UnderlayDef def)
    {
        _vp.BeginPick(2, "Échelle : cliquez deux points du fond dont vous connaissez la distance réelle (une cote, un mur, une trame...).", pts =>
        {
            double d0 = Math.Sqrt((pts[1].X - pts[0].X) * (pts[1].X - pts[0].X) + (pts[1].Y - pts[0].Y) * (pts[1].Y - pts[0].Y));
            var v = PromptWindow.Ask(this, "Calage de l'échelle", $"Distance actuellement mesurée entre vos deux points : {d0:0.###} m.", ("Distance réelle (m)", d0.ToString("0.###", CultureInfo.InvariantCulture)));
            if (v == null) return;
            double real = Nm(v[0], -1);
            PushUndo();
            if (real <= 0 || !UnderlayMath.Calibrate(def, pts[0], pts[1], real)) { MessageBox.Show("Distance invalide.", "Calage", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            Log($"{def.Name} : échelle corrigée (×{real / d0:0.####}).");
            _vp.Redraw();
        });
    }

    private void PickMove(UnderlayDef def)
    {
        _vp.BeginPick(2, "Déplacer : 1) cliquez un point du fond (coin de poteau, croisement d'axes...)  2) cliquez le point du modèle où il doit arriver (nœud, axe, intersection...).", pts =>
        {
            PushUndo();
            UnderlayMath.MoveTo(def, pts[0], pts[1]);
            Log($"{def.Name} : déplacé de ({pts[1].X - pts[0].X:0.###} ; {pts[1].Y - pts[0].Y:0.###}) m.");
            _vp.Redraw();
        });
    }

    private void PickAlign(UnderlayDef def, bool vertical)
    {
        _vp.BeginPick(2, vertical ? "Aligner : cliquez deux points d'une ligne du fond qui doit devenir verticale." : "Aligner : cliquez deux points d'une ligne du fond qui doit devenir horizontale.", pts =>
        {
            PushUndo();
            if (!UnderlayMath.Align(def, pts[0], pts[1], vertical)) { MessageBox.Show("Les deux points sont confondus.", "Alignement", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            Log($"{def.Name} : tourné, rotation totale {def.Rotation:0.###}°.");
            _vp.Redraw();
        });
    }
}
