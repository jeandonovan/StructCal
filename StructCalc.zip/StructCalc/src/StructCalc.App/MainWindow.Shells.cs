using System.Windows;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;

namespace StructCalc.UI;

/// <summary>Coques (voiles et dalles maillés) intégrées au modèle 3D : création, suppression.</summary>
public partial class MainWindow
{
    private void ShellWall_Click(object sender, RoutedEventArgs e)
    {
        double lvl = _model.Levels.Count > 0 ? _model.Levels.Min(l => l.Elevation) : 0;
        var v = PromptWindow.Ask(this, "Voile maillé dans le modèle 3D",
            "Crée un voile en éléments de coque couplé à l'ossature : les nœuds du maillage qui coïncident avec des nœuds existants (poteaux, poutres) sont partagés. " +
            "N'oubliez pas les appuis au pied du voile (outil Appui) et les charges.",
            ("Nom du voile", "V" + (_model.Shells.Select(s => s.Name).Distinct().Count(sn => sn.StartsWith("V")) + 1)),
            ("Pied : X (m)", "0"), ("Pied : Y (m)", "0"), ("Pied : cote Z (m)", Ui.Fmt(lvl)),
            ("Direction dans le plan XY (degrés, 0 = selon X)", "0"),
            ("Longueur (m)", "4"), ("Hauteur (m)", "3.06"), ("Épaisseur (m)", "0.20"), ("Taille des éléments (m)", "0.5"));
        if (v == null) return;
        double x = Ui.Num(v[1]), y = Ui.Num(v[2]), z = Ui.Num(v[3]), ang = Ui.Num(v[4]), len = Ui.Num(v[5]), h = Ui.Num(v[6]), t = Ui.Num(v[7]), mesh = Ui.Num(v[8]);
        if (new[] { x, y, z, ang, len, h, t, mesh }.Any(double.IsNaN) || len <= 0.2 || h <= 0.2 || t < 0.08 || mesh < 0.1) { Say("Voile : valeurs invalides (longueur, hauteur > 0,2 m ; épaisseur >= 0,08 m ; maille >= 0,1 m)."); return; }
        int nx = (int)Math.Ceiling(len / mesh - 1e-9), ny = (int)Math.Ceiling(h / mesh - 1e-9);
        if (nx * ny > 4000) { Say($"Maillage trop fin ({nx * ny} éléments) : augmentez la taille des éléments."); return; }
        PushUndo();
        string name = string.IsNullOrWhiteSpace(v[0]) ? "V1" : v[0].Trim();
        int n = ShellMesh.AddWall(_model, name, x, y, z, ang, len, h, t, mesh);
        OnModelEdited();
        Say($"Voile {name} : {n} éléments de coque créés. Ajoutez les appuis au pied, puis relancez le calcul (F5).");
    }

    private void ShellSlab_Click(object sender, RoutedEventArgs e)
    {
        double lvl = _model.Levels.Count > 1 ? _model.Levels.OrderBy(l => l.Elevation).Skip(1).First().Elevation : 3;
        var v = PromptWindow.Ask(this, "Dalle maillée dans le modèle 3D",
            "Crée une dalle en éléments de coque (flexion + membrane) couplée à l'ossature : les nœuds coïncidant avec des nœuds existants sont partagés. " +
            "Utile pour les dalles sur appuis ponctuels, les radiers, les planchers-diaphragmes.",
            ("Nom de la dalle", "D" + (_model.Shells.Select(s => s.Name).Distinct().Count(sn => sn.StartsWith("D")) + 1)),
            ("Coin minimal : X (m)", "0"), ("Coin minimal : Y (m)", "0"), ("Cote Z (m)", Ui.Fmt(lvl)),
            ("Dimension selon X (m)", "5"), ("Dimension selon Y (m)", "5"), ("Épaisseur (m)", "0.20"), ("Taille des éléments (m)", "0.5"),
            ("Charge permanente supplémentaire (kN/m²)", "1.5"), ("Charge d'exploitation (kN/m²)", "2.5"));
        if (v == null) return;
        double x = Ui.Num(v[1]), y = Ui.Num(v[2]), z = Ui.Num(v[3]), lx = Ui.Num(v[4]), ly = Ui.Num(v[5]), t = Ui.Num(v[6]), mesh = Ui.Num(v[7]), g = Ui.Num(v[8]), q = Ui.Num(v[9]);
        if (new[] { x, y, z, lx, ly, t, mesh, g, q }.Any(double.IsNaN) || lx <= 0.2 || ly <= 0.2 || t < 0.08 || mesh < 0.1) { Say("Dalle : valeurs invalides."); return; }
        int nx = (int)Math.Ceiling(lx / mesh - 1e-9), ny = (int)Math.Ceiling(ly / mesh - 1e-9);
        if (nx * ny > 4000) { Say($"Maillage trop fin ({nx * ny} éléments) : augmentez la taille des éléments."); return; }
        PushUndo();
        string name = string.IsNullOrWhiteSpace(v[0]) ? "D1" : v[0].Trim();
        int n = ShellMesh.AddSlab(_model, name, x, y, z, lx, ly, t, mesh, g, q);
        OnModelEdited();
        Say($"Dalle {name} : {n} éléments de coque créés. Elle est couplée aux poteaux et poutres dont les nœuds coïncident ; relancez le calcul (F5).");
    }

    private void ShellRemove_Click(object sender, RoutedEventArgs e)
    {
        if (_model.Shells.Count == 0) { Say("Aucune coque dans le modèle."); return; }
        var names = string.Join(", ", _model.Shells.Select(s => s.Name).Distinct());
        var v = PromptWindow.Ask(this, "Supprimer des coques", $"Groupes présents : {names}.\nSaisissez le nom d'un groupe à supprimer, ou * pour tout supprimer (les nœuds devenus inutiles sont retirés).",
            ("Nom du groupe ou *", _model.Shells[0].Name));
        if (v == null) return;
        string name = v[0].Trim();
        PushUndo();
        int n = ShellMesh.Remove(_model, name == "*" || name == "" ? null : name);
        OnModelEdited();
        Say($"{n} élément(s) de coque supprimé(s).");
    }
}
