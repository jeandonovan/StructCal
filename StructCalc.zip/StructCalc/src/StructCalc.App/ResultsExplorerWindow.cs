using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine;
using StructCalc.Engine.Results;
using StructCalc.Engine.Structure;
using EngFilter = StructCalc.Engine.Results.ResultFilter;

namespace StructCalc.UI;

/// <summary>Explorateur de résultats : tous les tableaux (réactions, efforts, enveloppes, déplacements, contraintes, ferraillage, conformité, poinçonnement, dalles, voiles, sismique, modal),
/// courbes interactives d'une barre, coupes de dalle, filtres (niveau, type, matériau, source) et exports (CSV, Excel, PNG, HTML).</summary>
public sealed class ResultsExplorerWindow : Window
{
    private StructModel _m;
    private AnalysisOutput _o;
    private readonly ComboBox _source = new() { Width = 220 };
    private readonly ComboBox _level = new() { Width = 120 }, _type = new() { Width = 110 }, _mat = new() { Width = 110 };
    private readonly ListBox _list = new() { Width = 270 };
    private readonly ContentControl _host = new();
    private readonly TextBlock _status = new() { Margin = new Thickness(6, 2, 6, 2), Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap };
    private List<TableSpec> _specs = new();
    private TableData? _current;
    private int _preMember;
    private bool _loading;

    private const string CurvesName = "Courbes d'une barre (interactif)";
    private const string CutName = "Coupe de dalle (interactif)";

    public ResultsExplorerWindow(StructModel m, AnalysisOutput o, int selectedMember)
    {
        _m = m; _o = o; _preMember = selectedMember;
        Title = "Explorateur de résultats"; Width = 1300; Height = 760; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new DockPanel { Margin = new Thickness(6) };

        var bar = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
        void Lbl(string t) => bar.Children.Add(new TextBlock { Text = t, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 4, 0) });
        Lbl("Source :"); bar.Children.Add(_source);
        Lbl("Niveau :"); bar.Children.Add(_level);
        Lbl("Type :"); bar.Children.Add(_type);
        Lbl("Matériau :"); bar.Children.Add(_mat);
        var b1 = Ui.Btn("Export CSV", (s, e) => ExportCsv()); b1.Margin = new Thickness(14, 0, 4, 0); bar.Children.Add(b1);
        bar.Children.Add(Ui.Btn("Export Excel (ce tableau)", (s, e) => ExportXlsx(false)));
        bar.Children.Add(Ui.Btn("Excel complet (tous les tableaux)", (s, e) => ExportXlsx(true)));
        bar.Children.Add(Ui.Btn("Image PNG", (s, e) => ExportPng()));
        bar.Children.Add(Ui.Btn("Rapport HTML des résultats", (s, e) => ExportHtml()));
        DockPanel.SetDock(bar, Dock.Top); root.Children.Add(bar);

        DockPanel.SetDock(_status, Dock.Bottom); root.Children.Add(_status);
        DockPanel.SetDock(_list, Dock.Left); root.Children.Add(_list);
        root.Children.Add(_host);
        Content = root;

        _list.SelectionChanged += (s, e) => ShowSelected();
        _source.SelectionChanged += (s, e) => { if (!_loading) ShowSelected(); };
        foreach (var c in new[] { _level, _type, _mat }) c.SelectionChanged += (s, e) => { if (!_loading) ShowSelected(); };
        Fill();
    }

    public void Refresh(StructModel m, AnalysisOutput o, int selectedMember)
    {
        _m = m; _o = o; _preMember = selectedMember; Fill();
    }

    private void Fill()
    {
        _loading = true;
        try
        {
            var st = _o.Store;
            string keepSrc = _source.SelectedItem as string ?? ResultsStore.EnvUls;
            _source.Items.Clear();
            if (st != null) foreach (var s in st.DeformSources()) _source.Items.Add(s);
            _source.SelectedItem = _source.Items.Contains(keepSrc) ? keepSrc : ResultsStore.EnvUls;
            var info = StructureAnalyzer.Analyze(_m);
            _level.Items.Clear(); _level.Items.Add("Tous"); foreach (var l in info.Levels) _level.Items.Add(l.Name); _level.SelectedIndex = 0;
            _type.Items.Clear(); foreach (var s in new[] { "Tous", "Poteaux", "Poutres" }) _type.Items.Add(s); _type.SelectedIndex = 0;
            _mat.Items.Clear(); foreach (var s in new[] { "Tous", "Béton armé", "Acier" }) _mat.Items.Add(s); _mat.SelectedIndex = 0;
        }
        finally { _loading = false; }
        RebuildSpecs();
    }

    private EngFilter CurrentFilter() => new()
    {
        Level = _level.SelectedIndex <= 0 ? "" : _level.SelectedItem as string ?? "",
        Type = _type.SelectedIndex == 1 ? MemberType.Column : _type.SelectedIndex == 2 ? MemberType.Beam : null,
        Kind = _mat.SelectedIndex == 1 ? MaterialKind.ReinforcedConcrete : _mat.SelectedIndex == 2 ? MaterialKind.Steel : null
    };

    private string Source => _source.SelectedItem as string ?? ResultsStore.EnvUls;

    private void RebuildSpecs()
    {
        string keep = (_list.SelectedItem as ListBoxItem)?.Tag as string ?? "";
        _list.Items.Clear();
        _specs = ResultTables.Catalog(_m, _o, Source, CurrentFilter());
        string group = "";
        foreach (var sp in _specs)
        {
            if (sp.Group != group)
            {
                group = sp.Group;
                _list.Items.Add(new ListBoxItem { Content = group.ToUpperInvariant(), IsEnabled = false, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), Tag = "" });
            }
            _list.Items.Add(new ListBoxItem { Content = "   " + sp.Name, Tag = sp.Name });
        }
        _list.Items.Add(new ListBoxItem { Content = "COURBES ET COUPES", IsEnabled = false, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(0x1F, 0x4E, 0x79)), Tag = "" });
        if (_o.Store != null) _list.Items.Add(new ListBoxItem { Content = "   " + CurvesName, Tag = CurvesName });
        if (_o.SlabFields.Count > 0) _list.Items.Add(new ListBoxItem { Content = "   " + CutName, Tag = CutName });
        var sel = _list.Items.OfType<ListBoxItem>().FirstOrDefault(i => (i.Tag as string) == keep && keep != "")
                  ?? _list.Items.OfType<ListBoxItem>().FirstOrDefault(i => i.IsEnabled);
        _list.SelectedItem = sel;
        ShowSelected();
    }

    private bool _rebuilding;
    private void ShowSelected()
    {
        if (_rebuilding) return;
        if (_list.SelectedItem is not ListBoxItem it || it.Tag is not string name || name == "") return;
        // le choix de source / filtre change le contenu des tableaux : on reconstruit les spécifications
        if (name != CurvesName && name != CutName)
        {
            _rebuilding = true;
            try { _specs = ResultTables.Catalog(_m, _o, Source, CurrentFilter()); } finally { _rebuilding = false; }
            var sp = _specs.FirstOrDefault(x => x.Name == name);
            if (sp == null) return;
            try { _current = sp.Build(); ShowTable(_current); }
            catch (Exception ex) { _current = null; _host.Content = new TextBlock { Text = "Tableau indisponible : " + ex.Message, Margin = new Thickness(12), TextWrapping = TextWrapping.Wrap }; }
        }
        else if (name == CurvesName) { _current = null; _host.Content = BuildCurves(); }
        else { _current = null; _host.Content = BuildCut(); }
    }

    // ------------------------------------------------------------------ tableau
    private void ShowTable(TableData t)
    {
        var dt = new DataTable();
        int nc = t.Headers.Count;
        var numeric = new bool[nc];
        for (int i = 0; i < nc; i++)
        {
            bool any = false, all = true;
            foreach (var r in t.Rows)
            {
                object? v = i < r.Length ? r[i] : null;
                if (v == null) continue;
                any = true;
                if (!(v is double || v is int || v is float || v is long)) { all = false; break; }
            }
            numeric[i] = any && all;
            dt.Columns.Add("c" + i, numeric[i] ? typeof(double) : typeof(string));
        }
        foreach (var r in t.Rows)
        {
            var row = dt.NewRow();
            for (int i = 0; i < nc; i++)
            {
                object? v = i < r.Length ? r[i] : null;
                if (v == null || (v is double d && (double.IsNaN(d) || double.IsInfinity(d)))) { row[i] = DBNull.Value; continue; }
                row[i] = numeric[i] ? Convert.ToDouble(v) : t.CellText(v);
            }
            dt.Rows.Add(row);
        }
        var grid = new DataGrid
        {
            ItemsSource = dt.DefaultView, IsReadOnly = true, AutoGenerateColumns = true, AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(0xF4, 0xF7, 0xFB)),
            SelectionUnit = DataGridSelectionUnit.CellOrRowHeader, ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader, CanUserSortColumns = true
        };
        grid.LoadingRow += (s, e) => ColourStatus(e.Row);
        grid.AutoGeneratingColumn += (s, e) =>
        {
            if (int.TryParse(e.PropertyName.AsSpan(1), out int idx) && idx >= 0 && idx < t.Headers.Count) e.Column.Header = t.Headers[idx].Replace("_", "__");
            if (e.Column is DataGridTextColumn tc && tc.Binding is System.Windows.Data.Binding bd && numeric[Math.Clamp(int.Parse(e.PropertyName.AsSpan(1)), 0, nc - 1)])
            { bd.StringFormat = "0.##"; tc.ElementStyle = new Style(typeof(TextBlock)) { Setters = { new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Right) } }; }
        };
        var dock = new DockPanel();
        var notes = new TextBlock { Text = string.Join("\n", t.Notes), TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(6) };
        DockPanel.SetDock(notes, Dock.Bottom);
        if (t.Notes.Count > 0) dock.Children.Add(notes);
        dock.Children.Add(grid);
        _host.Content = dock;
        string extra = "";
        if (t.Title.StartsWith("Vérifications"))
        {
            var (ok, lim, ko, man) = ResultTables.ComplianceCounts(t);
            extra = $"   ·   Vérifié : {ok}   À la limite : {lim}   Non vérifié : {ko}   À contrôler manuellement : {man}";
        }
        _status.Text = $"{t.Title}  -  {t.Rows.Count} ligne(s){extra}   ·   clic sur un en-tête : tri ; Ctrl+C : copier la sélection.";
    }

    private static void ColourStatus(DataGridRow row)
    {
        if (row.Item is not DataRowView v) return;
        object? last = v.Row.ItemArray.Length > 0 ? v.Row.ItemArray[^1] : null;
        string s = last as string ?? "";
        row.Background = s switch
        {
            "Non vérifié" or "NON OK" => new SolidColorBrush(Color.FromRgb(0xFD, 0xE0, 0xDC)),
            "À la limite" => new SolidColorBrush(Color.FromRgb(0xFF, 0xF3, 0xCD)),
            "À contrôler manuellement" => new SolidColorBrush(Color.FromRgb(0xE3, 0xF2, 0xFD)),
            _ => row.Background
        };
    }

    // ------------------------------------------------------------------ courbes d'une barre
    private UIElement BuildCurves()
    {
        var st = _o.Store!;
        var members = _m.Members.Where(x => CurrentFilter().Accept(x, StructureAnalyzer.Analyze(_m))).ToList();
        if (members.Count == 0) members = _m.Members.ToList();
        var memCombo = new ComboBox { Width = 230 };
        foreach (var mem in members) memCombo.Items.Add(new ComboBoxItem { Content = $"{(mem.Type == MemberType.Column ? "Poteau" : "Poutre")} {mem.Id}  ({(mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}")})", Tag = mem.Id });
        var qty = new ComboBox { Width = 130 };
        foreach (ForceQty q in Enum.GetValues(typeof(ForceQty))) qty.Items.Add(ResultsStore.QtyName(q));
        qty.SelectedIndex = (int)ForceQty.My;
        int pre = members.FindIndex(x => x.Id == _preMember);
        memCombo.SelectedIndex = pre >= 0 ? pre : 0;
        var canvas = new Canvas { Background = Brushes.White, ClipToBounds = true, MinHeight = 300 };
        var info = new TextBlock { Margin = new Thickness(8, 4, 8, 4), FontFamily = new FontFamily("Consolas"), TextWrapping = TextWrapping.Wrap };
        var top = new WrapPanel { Margin = new Thickness(4) };
        top.Children.Add(new TextBlock { Text = "Barre :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 4, 0) }); top.Children.Add(memCombo);
        top.Children.Add(new TextBlock { Text = "Grandeur :", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 4, 0) }); top.Children.Add(qty);
        var dock = new DockPanel();
        DockPanel.SetDock(top, Dock.Top); dock.Children.Add(top);
        DockPanel.SetDock(info, Dock.Bottom); dock.Children.Add(info);
        dock.Children.Add(canvas);

        ForceSeries? ser = null; double x0 = 0, x1 = 1, y0 = 0, y1 = 1; double ml = 60, mr = 20, mt = 20, mb = 30;
        Point P(double x, double y) => new(ml + (x - x0) / Math.Max(x1 - x0, 1e-9) * (canvas.ActualWidth - ml - mr), mt + (y1 - y) / Math.Max(y1 - y0, 1e-9) * (canvas.ActualHeight - mt - mb));
        void Draw()
        {
            canvas.Children.Clear();
            if (memCombo.SelectedItem is not ComboBoxItem ci || ci.Tag is not int id || qty.SelectedIndex < 0) return;
            var q = (ForceQty)qty.SelectedIndex;
            ser = st.Series(Source, id, q);
            if (ser.X.Length < 2 || canvas.ActualWidth < 80) { info.Text = "Aucune donnée pour cette barre / cette source."; return; }
            x0 = ser.X.Min(); x1 = ser.X.Max();
            y0 = Math.Min(0, ser.Min.Min()); y1 = Math.Max(0, ser.Max.Max());
            if (y1 - y0 < 1e-6) { y0 -= 1; y1 += 1; }
            double pad = (y1 - y0) * 0.1; y0 -= pad; y1 += pad;
            // grille
            for (int g = 0; g <= 5; g++)
            {
                double yv = y0 + (y1 - y0) * g / 5; var pa = P(x0, yv); var pb = P(x1, yv);
                canvas.Children.Add(new Line { X1 = pa.X, Y1 = pa.Y, X2 = pb.X, Y2 = pb.Y, Stroke = new SolidColorBrush(Color.FromRgb(0xE0, 0xE0, 0xE0)), StrokeThickness = 1 });
                var tb = new TextBlock { Text = yv.ToString("0.#"), FontSize = 10, Foreground = Brushes.Gray }; Canvas.SetLeft(tb, 4); Canvas.SetTop(tb, pa.Y - 8); canvas.Children.Add(tb);
            }
            for (int g = 0; g <= 5; g++)
            {
                double xv = x0 + (x1 - x0) * g / 5; var pa = P(xv, y0);
                var tb = new TextBlock { Text = xv.ToString("0.00") + " m", FontSize = 10, Foreground = Brushes.Gray }; Canvas.SetLeft(tb, pa.X - 14); Canvas.SetTop(tb, pa.Y + 4); canvas.Children.Add(tb);
            }
            var z0 = P(x0, 0); var z1 = P(x1, 0);
            canvas.Children.Add(new Line { X1 = z0.X, Y1 = z0.Y, X2 = z1.X, Y2 = z1.Y, Stroke = Brushes.Black, StrokeThickness = 1.4 });
            void Curve(double[] v, Color col)
            {
                var pts = new PointCollection { P(ser!.X[0], 0) };
                for (int i = 0; i < v.Length; i++) pts.Add(P(ser.X[i], v[i]));
                pts.Add(P(ser.X[^1], 0));
                canvas.Children.Add(new Polygon { Points = pts, Fill = new SolidColorBrush(Color.FromArgb(70, col.R, col.G, col.B)), Stroke = new SolidColorBrush(col), StrokeThickness = 1.8 });
            }
            bool env = ser.Min.Zip(ser.Max, (a, b) => Math.Abs(b - a) > 1e-6).Any(z => z);
            Curve(ser.Max, Color.FromRgb(0xC6, 0x28, 0x28));
            if (env) Curve(ser.Min, Color.FromRgb(0x15, 0x65, 0xC0));
            int imax = ser.IndexOfMax(), imin = ser.IndexOfMin();
            void Mark(int i, double v, string combo, Color c)
            {
                var p = P(ser!.X[i], v);
                var e = new Ellipse { Width = 8, Height = 8, Fill = new SolidColorBrush(c) }; Canvas.SetLeft(e, p.X - 4); Canvas.SetTop(e, p.Y - 4); canvas.Children.Add(e);
                var tb = new TextBlock { Text = $"{v:0.##} {ResultsStore.QtyUnit(q)}" + (env && combo != "" ? $"  [{combo}]" : ""), FontSize = 11, FontWeight = FontWeights.SemiBold, Background = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)) };
                Canvas.SetLeft(tb, Math.Min(p.X + 6, Math.Max(canvas.ActualWidth - 220, 0))); Canvas.SetTop(tb, Math.Max(p.Y - 20, 0)); canvas.Children.Add(tb);
            }
            Mark(imax, ser.Max[imax], ser.MaxCombo[imax], Color.FromRgb(0xC6, 0x28, 0x28));
            if (env || imin != imax) Mark(imin, ser.Min[imin], ser.MinCombo[imin], Color.FromRgb(0x15, 0x65, 0xC0));
            var cursor = new Line { Stroke = Brushes.DimGray, StrokeDashArray = new DoubleCollection { 3, 3 }, Y1 = mt, Y2 = canvas.ActualHeight - mb, Visibility = Visibility.Hidden, Name = "cur" };
            canvas.Children.Add(cursor);
            canvas.Tag = cursor;
            info.Text = $"{ResultsStore.QtyName(q)} - {Source}   max = {ser.Max[imax]:0.##} (x = {ser.X[imax]:0.00} m, {ser.MaxCombo[imax]})   min = {ser.Min[imin]:0.##} (x = {ser.X[imin]:0.00} m, {ser.MinCombo[imin]})   -   survolez la courbe pour lire les valeurs.";
            _status.Text = "Courbe interactive : la valeur et la combinaison responsable s'affichent au survol.";
        }
        canvas.MouseMove += (s, e) =>
        {
            if (ser == null || ser.X.Length < 2 || canvas.Tag is not Line cur) return;
            var p = e.GetPosition(canvas);
            double xv = x0 + (p.X - ml) / Math.Max(canvas.ActualWidth - ml - mr, 1) * (x1 - x0);
            int k = 0; double best = double.MaxValue;
            for (int i = 0; i < ser.X.Length; i++) { double d = Math.Abs(ser.X[i] - xv); if (d < best) { best = d; k = i; } }
            var pp = P(ser.X[k], 0);
            cur.X1 = cur.X2 = pp.X; cur.Visibility = Visibility.Visible;
            var q = (ForceQty)Math.Max(qty.SelectedIndex, 0);
            info.Text = $"x = {ser.X[k]:0.00} m   max = {ser.Max[k]:0.##} {ResultsStore.QtyUnit(q)} [{ser.MaxCombo[k]}]   min = {ser.Min[k]:0.##} [{ser.MinCombo[k]}]";
        };
        canvas.SizeChanged += (s, e) => Draw();
        memCombo.SelectionChanged += (s, e) => Draw(); qty.SelectionChanged += (s, e) => Draw();
        Dispatcher.BeginInvoke(new Action(Draw), System.Windows.Threading.DispatcherPriority.Loaded);
        return dock;
    }

    // ------------------------------------------------------------------ coupe de dalle
    private UIElement BuildCut()
    {
        var fieldNames = _o.SlabFields.Select(f => f.Name).Distinct().ToList();
        var slab = new ComboBox { Width = 90 }; foreach (var n in fieldNames) slab.Items.Add(n); slab.SelectedIndex = 0;
        var kinds = new[] { SlabFieldKind.Mx, SlabFieldKind.My, SlabFieldKind.Mxy, SlabFieldKind.M1, SlabFieldKind.M2, SlabFieldKind.Vx, SlabFieldKind.Vy, SlabFieldKind.Deflection,
                            SlabFieldKind.SigmaX, SlabFieldKind.SigmaY, SlabFieldKind.VonMises, SlabFieldKind.AsXBot, SlabFieldKind.AsYBot, SlabFieldKind.AsXTop, SlabFieldKind.AsYTop };
        var kind = new ComboBox { Width = 270 }; foreach (var k in kinds) kind.Items.Add($"{SlabField.Title(k)} [{SlabField.Unit(k)}]"); kind.SelectedIndex = 0;
        var mode = new ComboBox { Width = 250 };
        foreach (var s in new[] { "Coupe horizontale (y fixé)", "Coupe verticale (x fixé)", "Coupe suivant une direction quelconque (2 points)", "Bande de dalle (moyenne sur une largeur)", "À travers un poteau (direction X)", "À travers un poteau (direction Y)" }) mode.Items.Add(s);
        mode.SelectedIndex = 0;
        var colCombo = new ComboBox { Width = 120 }; foreach (var c in _m.Members.Where(x => x.Type == MemberType.Column)) colCombo.Items.Add(new ComboBoxItem { Content = "Poteau " + c.Id, Tag = c.Id }); if (colCombo.Items.Count > 0) colCombo.SelectedIndex = 0;
        var tA = new TextBox { Width = 60, Text = "", ToolTip = "y (horizontale), x (verticale) ou x1" };
        var tB = new TextBox { Width = 60, Text = "", ToolTip = "x2 pour l'oblique" };
        var tC = new TextBox { Width = 60, Text = "" }; var tD = new TextBox { Width = 60, Text = "" };
        var tW = new TextBox { Width = 50, Text = "0.5", ToolTip = "largeur de bande (m)" };
        var canvas = new Canvas { Background = Brushes.White, ClipToBounds = true, MinHeight = 280 };
        var info = new TextBlock { Margin = new Thickness(8, 4, 8, 4), FontFamily = new FontFamily("Consolas"), TextWrapping = TextWrapping.Wrap };
        List<(double S, double X, double Y, double V)> pts = new();
        double ml = 60, mt = 20, mr = 20, mb = 30;
        var go = Ui.Btn("Tracer", (s, e) => Draw());
        var csv = Ui.Btn("Exporter la coupe (CSV)", (s, e) => ExportCut());
        var p1 = new WrapPanel { Margin = new Thickness(4) };
        void Add(string t, UIElement c) { p1.Children.Add(new TextBlock { Text = t, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 3, 0) }); p1.Children.Add(c); }
        Add("Dalle :", slab); Add("Grandeur :", kind); Add("Type de coupe :", mode); Add("Poteau :", colCombo);
        Add("Valeur 1 (m) :", tA); Add("2 :", tB); Add("3 :", tC); Add("4 :", tD); Add("Largeur bande (m) :", tW);
        p1.Children.Add(go); p1.Children.Add(csv);
        var hint = new TextBlock { Text = "Horizontale : valeur 1 = y. Verticale : valeur 1 = x. Oblique : (x1, y1) = valeurs 1 et 3, (x2, y2) = valeurs 2 et 4. Bande : y (ou x) central en valeur 1, largeur de bande. Poteau : coupe passant par le poteau choisi.",
            TextWrapping = TextWrapping.Wrap, Foreground = Brushes.Gray, FontSize = 11, Margin = new Thickness(6, 0, 6, 4) };
        var dock = new DockPanel();
        DockPanel.SetDock(p1, Dock.Top); dock.Children.Add(p1);
        DockPanel.SetDock(hint, Dock.Top); dock.Children.Add(hint);
        DockPanel.SetDock(info, Dock.Bottom); dock.Children.Add(info);
        dock.Children.Add(canvas);

        List<SlabField> Cells() => _o.SlabFields.Where(f => f.Name == (slab.SelectedItem as string)).ToList();
        void Draw()
        {
            canvas.Children.Clear(); pts.Clear();
            var cells = Cells(); if (cells.Count == 0) return;
            double xa = cells.Min(c => c.X0), xb = cells.Max(c => c.X0 + c.Lx), ya = cells.Min(c => c.Y0), yb = cells.Max(c => c.Y0 + c.Ly);
            double v1 = Ui.Num(tA.Text, double.NaN), v2 = Ui.Num(tB.Text, double.NaN), v3 = Ui.Num(tC.Text, double.NaN), v4 = Ui.Num(tD.Text, double.NaN), w = Math.Max(Ui.Num(tW.Text, 0.5), 0.01);
            var k = kinds[Math.Max(kind.SelectedIndex, 0)];
            int md = mode.SelectedIndex;
            double ax, ay, bx, by;
            double cx = (xa + xb) / 2, cy = (ya + yb) / 2;
            if (md == 4 || md == 5)
            {
                if (colCombo.SelectedItem is ComboBoxItem cc && cc.Tag is int cid && _m.Members.FirstOrDefault(x => x.Id == cid) is { } col)
                {
                    var n1 = _m.Nodes.FirstOrDefault(n => n.Id == col.NodeI); var n2 = _m.Nodes.FirstOrDefault(n => n.Id == col.NodeJ);
                    if (n1 != null && n2 != null) { cx = (n1.X + n2.X) / 2; cy = (n1.Y + n2.Y) / 2; }
                }
            }
            switch (md)
            {
                case 0: case 3: { double y = double.IsNaN(v1) ? cy : v1; ax = xa; bx = xb; ay = by = y; break; }
                case 1: { double x = double.IsNaN(v1) ? cx : v1; ax = bx = x; ay = ya; by = yb; break; }
                case 2: ax = double.IsNaN(v1) ? xa : v1; bx = double.IsNaN(v2) ? xb : v2; ay = double.IsNaN(v3) ? ya : v3; by = double.IsNaN(v4) ? yb : v4; break;
                case 4: ax = xa; bx = xb; ay = by = cy; break;
                default: ax = bx = cx; ay = ya; by = yb; break;
            }
            if (md == 3)
            {
                // moyenne de 5 coupes parallèles dans la bande
                var acc = new List<(double S, double X, double Y, double V)>();
                for (int i = 0; i < 5; i++)
                {
                    double off = (i - 2) / 2.0 * w / 2;
                    var one = ResultTables.SlabCut(cells, k, ax, ay + off, bx, by + off);
                    if (acc.Count == 0) acc = one.Select(z => (z.S, z.X, z.Y, 0.0)).ToList();
                    for (int j = 0; j < one.Count; j++) acc[j] = (acc[j].S, acc[j].X, acc[j].Y, double.IsNaN(one[j].V) || double.IsNaN(acc[j].V) ? double.NaN : acc[j].V + one[j].V / 5);
                }
                pts = acc;
            }
            else pts = ResultTables.SlabCut(cells, k, ax, ay, bx, by);
            var valid = pts.Where(z => !double.IsNaN(z.V)).ToList();
            if (valid.Count < 2 || canvas.ActualWidth < 80) { info.Text = "La coupe ne rencontre pas la dalle : modifiez les valeurs."; return; }
            double s0 = pts[0].S, s1 = pts[^1].S, lo = Math.Min(0, valid.Min(z => z.V)), hi = Math.Max(0, valid.Max(z => z.V));
            if (hi - lo < 1e-6) { lo -= 1; hi += 1; }
            double pad = (hi - lo) * 0.1; lo -= pad; hi += pad;
            Point P(double s, double v) => new(ml + (s - s0) / Math.Max(s1 - s0, 1e-9) * (canvas.ActualWidth - ml - mr), mt + (hi - v) / (hi - lo) * (canvas.ActualHeight - mt - mb));
            for (int g = 0; g <= 5; g++)
            {
                double yv = lo + (hi - lo) * g / 5; var pa = P(s0, yv); var pb = P(s1, yv);
                canvas.Children.Add(new Line { X1 = pa.X, Y1 = pa.Y, X2 = pb.X, Y2 = pb.Y, Stroke = new SolidColorBrush(Color.FromRgb(0xE0, 0xE0, 0xE0)) });
                var tb = new TextBlock { Text = yv.ToString("0.#"), FontSize = 10, Foreground = Brushes.Gray }; Canvas.SetLeft(tb, 4); Canvas.SetTop(tb, pa.Y - 8); canvas.Children.Add(tb);
            }
            var z0 = P(s0, 0); var z1 = P(s1, 0);
            canvas.Children.Add(new Line { X1 = z0.X, Y1 = z0.Y, X2 = z1.X, Y2 = z1.Y, Stroke = Brushes.Black, StrokeThickness = 1.4 });
            var poly = new Polyline { Stroke = new SolidColorBrush(Color.FromRgb(0xC6, 0x28, 0x28)), StrokeThickness = 2 };
            foreach (var z in valid) poly.Points.Add(P(z.S, z.V));
            canvas.Children.Add(poly);
            var imax = valid.IndexOf(valid.OrderByDescending(z => z.V).First()); var imin = valid.IndexOf(valid.OrderBy(z => z.V).First());
            foreach (var (z, c) in new[] { (valid[imax], Colors.DarkRed), (valid[imin], Colors.DarkBlue) })
            {
                var p = P(z.S, z.V); var tb = new TextBlock { Text = z.V.ToString("0.##"), FontSize = 11, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(c) };
                Canvas.SetLeft(tb, p.X + 4); Canvas.SetTop(tb, p.Y - 18); canvas.Children.Add(tb);
            }
            info.Text = $"{SlabField.Title(k)} [{SlabField.Unit(k)}]   de ({pts[0].X:0.00} ; {pts[0].Y:0.00}) à ({pts[^1].X:0.00} ; {pts[^1].Y:0.00}) m   max = {valid.Max(z => z.V):0.##}   min = {valid.Min(z => z.V):0.##}";
            _status.Text = "Coupe de dalle : abscisse curviligne le long de la coupe, valeur interpolée sur le maillage.";
        }
        canvas.MouseMove += (s, e) =>
        {
            if (pts.Count < 2) return;
            var p = e.GetPosition(canvas); double frac = (p.X - ml) / Math.Max(canvas.ActualWidth - ml - mr, 1);
            int i = Math.Clamp((int)Math.Round(frac * (pts.Count - 1)), 0, pts.Count - 1);
            info.Text = $"s = {pts[i].S:0.00} m   point ({pts[i].X:0.00} ; {pts[i].Y:0.00})   valeur = {(double.IsNaN(pts[i].V) ? "hors dalle" : pts[i].V.ToString("0.##"))}";
        };
        canvas.SizeChanged += (s, e) => Draw();
        slab.SelectionChanged += (s, e) => Draw(); kind.SelectionChanged += (s, e) => Draw(); mode.SelectionChanged += (s, e) => Draw(); colCombo.SelectionChanged += (s, e) => Draw();
        _cutPoints = () => pts;
        Dispatcher.BeginInvoke(new Action(Draw), System.Windows.Threading.DispatcherPriority.Loaded);
        return dock;
    }

    private Func<List<(double S, double X, double Y, double V)>>? _cutPoints;

    private void ExportCut()
    {
        var pts = _cutPoints?.Invoke(); if (pts == null || pts.Count == 0) return;
        var t = new TableData("Coupe de dalle", "s (m)", "x (m)", "y (m)", "Valeur");
        foreach (var p in pts) t.Add(Math.Round(p.S, 4), Math.Round(p.X, 4), Math.Round(p.Y, 4), double.IsNaN(p.V) ? null : Math.Round(p.V, 4));
        SaveCsv(t, "coupe_dalle");
    }

    // ------------------------------------------------------------------ exports
    private static string Safe(string s) { foreach (char c in System.IO.Path.GetInvalidFileNameChars()) s = s.Replace(c, '_'); return s.Replace(' ', '_'); }

    private void SaveCsv(TableData t, string name)
    {
        var dlg = new SaveFileDialog { Filter = "CSV Excel (*.csv)|*.csv", FileName = Safe(name) + ".csv" };
        if (dlg.ShowDialog(this) != true) return;
        try { File.WriteAllText(dlg.FileName, t.ToCsv(), new System.Text.UTF8Encoding(true)); _status.Text = "CSV enregistré : " + dlg.FileName; }
        catch (Exception ex) { MessageBox.Show(this, "Export impossible : " + ex.Message, Title); }
    }

    private void ExportCsv()
    {
        if (_current == null) { MessageBox.Show(this, "Sélectionnez un tableau (pas une courbe) pour l'exporter en CSV.", Title); return; }
        SaveCsv(_current, _current.Title);
    }

    private void ExportXlsx(bool all)
    {
        List<TableData> sheets;
        if (all) sheets = ResultTables.All(_m, _o, Source);
        else if (_current != null) sheets = new List<TableData> { _current };
        else { MessageBox.Show(this, "Sélectionnez un tableau, ou utilisez « Excel complet ».", Title); return; }
        var dlg = new SaveFileDialog { Filter = "Classeur Excel (*.xlsx)|*.xlsx", FileName = Safe(all ? _m.Name + "_resultats" : _current!.Title) + ".xlsx" };
        if (dlg.ShowDialog(this) != true) return;
        try { File.WriteAllBytes(dlg.FileName, TableData.ToXlsx(sheets)); _status.Text = $"Excel enregistré ({sheets.Count} feuille(s)) : {dlg.FileName}"; }
        catch (Exception ex) { MessageBox.Show(this, "Export impossible : " + ex.Message, Title); }
    }

    private void ExportPng()
    {
        if (_host.Content is not FrameworkElement el || el.ActualWidth < 10) return;
        var dlg = new SaveFileDialog { Filter = "Image PNG (*.png)|*.png", FileName = Safe((_current?.Title ?? "courbe")) + ".png" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var rtb = new RenderTargetBitmap((int)el.ActualWidth * 2, (int)el.ActualHeight * 2, 192, 192, PixelFormats.Pbgra32);
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen()) dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, el.ActualWidth, el.ActualHeight));
            rtb.Render(dv); rtb.Render(el);
            var enc = new PngBitmapEncoder(); enc.Frames.Add(BitmapFrame.Create(rtb));
            using var fs = File.Create(dlg.FileName); enc.Save(fs);
            _status.Text = "Image enregistrée : " + dlg.FileName;
        }
        catch (Exception ex) { MessageBox.Show(this, "Export impossible : " + ex.Message, Title); }
    }

    private void ExportHtml()
    {
        var dlg = new SaveFileDialog { Filter = "Page HTML (*.html)|*.html", FileName = Safe(_m.Name + "_resultats_detailles") + ".html" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            File.WriteAllText(dlg.FileName, ReportWriter.DetailedHtml(_m, _o, Source), new System.Text.UTF8Encoding(false));
            _status.Text = "Rapport enregistré : " + dlg.FileName;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, "Export impossible : " + ex.Message, Title); }
    }
}
