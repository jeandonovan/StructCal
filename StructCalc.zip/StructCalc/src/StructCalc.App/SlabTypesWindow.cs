using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using StructCalc.Engine.Drawing;

namespace StructCalc.UI;

/// <summary>Commande « Types de dalle » : choix des types à dessiner et de leurs dimensions principales (cm), puis génération des coupes types.</summary>
public sealed class SlabTypesWindow : Window
{
    public SlabTypeParams P { get; } = new();
    private readonly List<(TextBox Box, Action<double> Set)> _fields = new();

    public SlabTypesWindow()
    {
        Title = "Dessiner les types de dalle";
        Width = 640; Height = 640; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new DockPanel { Margin = new Thickness(14) };
        var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
        DockPanel.SetDock(bar, Dock.Bottom);
        var ok = new Button { Content = "Dessiner les coupes", Padding = new Thickness(18, 5, 18, 5), Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        ok.Click += (s, e) => { Read(); DialogResult = true; };
        var cancel = new Button { Content = "Fermer", Padding = new Thickness(18, 5, 18, 5), IsCancel = true };
        bar.Children.Add(ok); bar.Children.Add(cancel);
        root.Children.Add(bar);

        var sp = new StackPanel();
        sp.Children.Add(new TextBlock
        {
            Text = "Cochez les types de dalle à dessiner et ajustez leurs dimensions (en cm). Chaque type donne une coupe cotée avec ses armatures de principe ; le résultat s'ouvre dans la visionneuse de plans (export DXF possible).",
            TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8)
        });
        Group(sp, "1. Dalle pleine", v => P.Solid = v, P.Solid,
            ("Épaisseur", () => P.SolidH, v => P.SolidH = v), ("Enrobage", () => P.Cover, v => P.Cover = v),
            ("Nappe inf. : diamètre (mm)", () => P.BotDia, v => P.BotDia = (int)v), ("Nappe inf. : espacement", () => P.BotE, v => P.BotE = v),
            ("Nappe sup. : diamètre (mm)", () => P.TopDia, v => P.TopDia = (int)v), ("Nappe sup. : espacement", () => P.TopE, v => P.TopE = v));
        Group(sp, "2. Plancher à corps creux", v => P.Ribbed = v, P.Ribbed,
            ("Hauteur du hourdis", () => P.HourdisH, v => P.HourdisH = v), ("Dalle de compression", () => P.ToppingH, v => P.ToppingH = v),
            ("Entraxe des poutrelles", () => P.RibSpacing, v => P.RibSpacing = v), ("Largeur de nervure", () => P.RibWidth, v => P.RibWidth = v),
            ("Barres par nervure", () => P.RibBars, v => P.RibBars = (int)v), ("Diamètre (mm)", () => P.RibDia, v => P.RibDia = (int)v));
        Group(sp, "3. Dalle sur prédalle", v => P.Predalle = v, P.Predalle,
            ("Épaisseur de la prédalle", () => P.PredalleH, v => P.PredalleH = v), ("Épaisseur totale", () => P.PredalleTotalH, v => P.PredalleTotalH = v));
        Group(sp, "4. Dalle alvéolée précontrainte", v => P.HollowCore = v, P.HollowCore,
            ("Hauteur", () => P.HollowH, v => P.HollowH = v), ("Nombre d'alvéoles", () => P.HollowCores, v => P.HollowCores = (int)v));
        Group(sp, "5. Dalle champignon", v => P.FlatSlab = v, P.FlatSlab,
            ("Épaisseur de dalle", () => P.FlatH, v => P.FlatH = v), ("Épaisseur au chapiteau", () => P.DropH, v => P.DropH = v),
            ("Largeur du chapiteau", () => P.DropWidth, v => P.DropWidth = v), ("Largeur du poteau", () => P.ColumnWidth, v => P.ColumnWidth = v));
        Group(sp, "6. Plancher mixte acier-béton", v => P.Composite = v, P.Composite,
            ("Hauteur du bac", () => P.DeckH, v => P.DeckH = v), ("Épaisseur totale", () => P.CompositeH, v => P.CompositeH = v));
        root.Children.Add(new ScrollViewer { Content = sp, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
        Content = root;
    }

    private readonly List<(CheckBox Box, Action<bool> Set)> _checks = new();

    private void Group(StackPanel host, string title, Action<bool> setSel, bool sel, params (string Label, Func<double> Get, Action<double> Set)[] fields)
    {
        var cb = new CheckBox { Content = title, IsChecked = sel, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 8, 0, 3) };
        _checks.Add((cb, setSel));
        host.Children.Add(cb);
        var g = new UniformGrid { Columns = 2, Margin = new Thickness(18, 0, 0, 0) };
        foreach (var f in fields)
        {
            var row = new Grid { Margin = new Thickness(0, 2, 12, 2) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(64) });
            row.Children.Add(new TextBlock { Text = f.Label, VerticalAlignment = VerticalAlignment.Center });
            var tb = new TextBox { Text = f.Get().ToString("0.##", CultureInfo.InvariantCulture), Margin = new Thickness(4, 0, 0, 0) };
            Grid.SetColumn(tb, 1);
            row.Children.Add(tb);
            _fields.Add((tb, f.Set));
            g.Children.Add(row);
        }
        host.Children.Add(g);
    }

    private void Read()
    {
        foreach (var (box, set) in _fields)
            if (double.TryParse(box.Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double v) && v > 0) set(v);
        foreach (var (box, set) in _checks) set(box.IsChecked == true);
    }
}
