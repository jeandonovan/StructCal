using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine;

public sealed class MemberDesignResult
{
    public int MemberId { get; set; }
    public string ExternalId { get; set; } = "";
    public MemberType Type { get; set; }
    public MaterialKind Kind { get; set; }
    public double B { get; set; }
    public double H { get; set; }
    public string Profile { get; set; } = "";
    public double Length { get; set; }
    public bool Ok { get; set; } = true;
    public bool Skipped { get; set; }
    public double AsBottom { get; set; }    // cm²
    public double AsTop { get; set; }       // cm² (poteaux : As total)
    public double Utilization { get; set; } // acier : taux de travail
    public string BarsBottom { get; set; } = "";   // acier : profil
    public string BarsTop { get; set; } = "";
    public string Stirrups { get; set; } = "";
    public double MuSag { get; set; }       // kN.m
    public double MuHog { get; set; }
    public double Vu { get; set; }          // kN
    public double NuMax { get; set; }       // kN compression
    public int BotN { get; set; }
    public int BotDia { get; set; }
    public int TopN { get; set; }
    public int TopDia { get; set; }
    public int StirDia { get; set; }
    public double StirSpacingCm { get; set; }
    public double NodalSpacingCm { get; set; }   // 0 = pas de zone critique (norme non parasismique)
    public double NodalZoneM { get; set; }       // longueur de la zone critique à chaque extrémité (m)
    /// <summary>Conditions forfaitaires de flèche (BAEL B.6.5,1 / EC2 7.4.2) satisfaites ?</summary>
    public bool ForfaitaireSatisfied { get; set; } = true;
    public bool Cantilever { get; set; }         // poutre console (une extrémité libre) : chapeaux sur toute la longueur
    public double CoverM { get; set; }           // bord -> axe des armatures (m)
    // enveloppes ELU/accidentel le long de la barre (pour les diagrammes) : moment sagging, moment hogging, |V|, compression
    public double[] StX { get; set; } = Array.Empty<double>();
    public double[] StMsag { get; set; } = Array.Empty<double>();
    public double[] StMhog { get; set; } = Array.Empty<double>();
    public double[] StV { get; set; } = Array.Empty<double>();
    public double[] StNc { get; set; } = Array.Empty<double>();
    public List<string> Notes { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    public string Status => Skipped ? "NON TRAITÉ" : Ok ? "OK" : "NON OK";
    public string SectionText => Kind == MaterialKind.Steel ? Profile : $"{B * 100:F0}x{H * 100:F0}";
    public string Summary =>
        Kind == MaterialKind.Steel ? $"Acier {Profile} : taux {Utilization:F2}"
        : Type == MemberType.Column ? $"Poteau {B * 100:F0}x{H * 100:F0} : {BarsBottom} ; {Stirrups}"
        : $"Poutre {B * 100:F0}x{H * 100:F0} : inf {BarsBottom} / sup {BarsTop} ; {Stirrups}";
}

internal static class MemberDesigner
{
    public static StationForces Combine(Combination c, Dictionary<ActionType, CaseResult> cases, int memberId, int k)
    {
        var s = new StationForces();
        foreach (var kv in c.Factors)
        {
            if (kv.Value == 0 || !cases.TryGetValue(kv.Key, out var cr)) continue;
            var a = cr.Members[memberId][k];
            double f = kv.Value;
            s.X = a.X;
            s.N += f * a.N; s.Vy += f * a.Vy; s.Vz += f * a.Vz; s.T += f * a.T; s.My += f * a.My; s.Mz += f * a.Mz;
        }
        return s;
    }

    /// <summary>Enveloppes des efforts (états ELU / accidentel) le long de la barre, pour l'affichage des diagrammes.</summary>
    public static void FillEnvelope(MemberDesignResult res, IEnumerable<Combination> combos,
                                    Dictionary<ActionType, CaseResult> cases, int memberId)
    {
        int ns = FrameSolver.Stations;
        var list = combos.Where(c => c.State != LimitState.ELS).ToList();
        if (list.Count == 0) return;
        // axe de flexion dominant (poteaux : My ou Mz selon le plan du portique ; poutres : My)
        bool useMz = false;
        if (res.Type == MemberType.Column)
        {
            double ay = 0, az = 0;
            foreach (var c in list)
                for (int k = 0; k < ns; k++)
                {
                    var f = Combine(c, cases, memberId, k);
                    ay = Math.Max(ay, Math.Abs(f.My)); az = Math.Max(az, Math.Abs(f.Mz));
                }
            useMz = az > ay;
        }
        var x = new double[ns]; var msag = new double[ns]; var mhog = new double[ns]; var v = new double[ns]; var nc = new double[ns];
        foreach (var c in list)
            for (int k = 0; k < ns; k++)
            {
                var f = Combine(c, cases, memberId, k);
                double m = useMz ? f.Mz : f.My;
                x[k] = f.X;
                msag[k] = Math.Max(msag[k], -m);
                mhog[k] = Math.Max(mhog[k], m);
                v[k] = Math.Max(v[k], Math.Max(Math.Abs(f.Vz), useMz ? Math.Abs(f.Vy) : 0));
                nc[k] = Math.Max(nc[k], -f.N);
            }
        res.StX = x; res.StMsag = msag; res.StMhog = mhog; res.StV = v; res.StNc = nc;
        if (res.Type == MemberType.Column) { res.MuSag = msag.Max(); res.MuHog = mhog.Max(); }
    }

    private static MemberDesignResult NewResult(Member mem, double length) => new()
    {
        MemberId = mem.Id, ExternalId = mem.ExternalId, Type = mem.Type, Kind = mem.Kind,
        B = mem.B, H = mem.H, Profile = mem.Profile, Length = length, CoverM = mem.Cover
    };

    // ======================================================================= BÉTON ARMÉ
    public static MemberDesignResult DesignRc(StructModel m, Member mem, double length, IReinforcedConcreteCode code,
                                              Dictionary<ActionType, CaseResult> cases)
    {
        var res = NewResult(mem, length);
        if (mem.Type == MemberType.Column) DesignColumn(m, mem, length, code, cases, res);
        else DesignBeam(m, mem, length, code, cases, res);
        return res;
    }

    private static void DesignBeam(StructModel m, Member mem, double length, IReinforcedConcreteCode code,
                                   Dictionary<ActionType, CaseResult> cases, MemberDesignResult res)
    {
        int ns = FrameSolver.Stations;
        // enveloppes par état limite : [sag, hog, vu]
        var env = new Dictionary<LimitState, double[]>();
        double msSag = 0, msHog = 0, nMax = 0, mzMax = 0, tMax = 0, bestMt = 0, bestM0 = 0;
        foreach (var c in CombinationSet.For(m, code.Combinations))
        {
            if (!env.TryGetValue(c.State, out var e)) { e = new double[3]; env[c.State] = e; }
            double cSag = 0, cHog = 0, endI = 0, endJ = 0;
            for (int k = 0; k < ns; k++)
            {
                var f = Combine(c, cases, mem.Id, k);
                double sag = -f.My;
                cSag = Math.Max(cSag, sag); cHog = Math.Max(cHog, -sag);
                if (k == 0) endI = Math.Max(0, -sag);
                if (k == ns - 1) endJ = Math.Max(0, -sag);
                if (c.State != LimitState.ELS)
                {
                    e[2] = Math.Max(e[2], Math.Abs(f.Vz));
                    nMax = Math.Max(nMax, Math.Abs(f.N));
                    mzMax = Math.Max(mzMax, Math.Abs(f.Mz));
                    tMax = Math.Max(tMax, Math.Abs(f.T));
                }
            }
            if (c.State == LimitState.ELS)
            {
                msSag = Math.Max(msSag, cSag); msHog = Math.Max(msHog, cHog);
                if (cSag > bestMt) { bestMt = cSag; bestM0 = cSag + (endI + endJ) / 2.0; }
            }
            else { e[0] = Math.Max(e[0], cSag); e[1] = Math.Max(e[1], cHog); }
        }

        var sec = new RcRectSection(mem.B, mem.H, mem.Cover, mem.Cover);
        DesignResult? bot = null, top = null, shear = null;
        double vu = 0, muSag = 0, muHog = 0;
        foreach (var st0 in new[] { LimitState.ELU, LimitState.Accidental })
        {
            if (!env.TryGetValue(st0, out var e)) continue;
            var b1 = code.DesignBeamFlexure(sec, m.Fc28, m.Fe, e[0], st0 == LimitState.ELU ? msSag : 0, mem.Crack, st0);
            var t1 = code.DesignBeamFlexure(sec, m.Fc28, m.Fe, e[1], st0 == LimitState.ELU ? msHog : 0, mem.Crack, st0);
            var s1 = code.DesignBeamShear(sec, m.Fc28, m.Fe, e[2], mem.Crack, st0);
            if (bot == null || b1.Values["As_cm2"] > bot.Values["As_cm2"] || (!b1.Ok && bot.Ok)) bot = b1;
            if (top == null || t1.Values["As_cm2"] > top.Values["As_cm2"] || (!t1.Ok && top.Ok)) top = t1;
            if (shear == null || s1.Values["At_over_st_cm2_per_m"] > shear.Values["At_over_st_cm2_per_m"] || (!s1.Ok && shear.Ok)) shear = s1;
            vu = Math.Max(vu, e[2]); muSag = Math.Max(muSag, e[0]); muHog = Math.Max(muHog, e[1]);
        }
        if (bot == null || top == null || shear == null) { res.Skipped = true; res.Warnings.Add("Aucune combinaison ELU."); return; }
        res.MuSag = muSag; res.MuHog = muHog; res.Vu = vu;

        double asB = bot.Values["As_cm2"], asT = top.Values["As_cm2"];
        var cfg = m.Settings;
        double minTot = code.BeamMinTotalAsCm2(sec);
        if (cfg.BeamMinPercent > 0) minTot = Math.Max(minTot, cfg.BeamMinPercent / 100.0 * mem.B * mem.H * 1e4);
        if (asB + asT < minTot)
        {
            asB = Math.Max(asB, minTot / 2); asT = Math.Max(asT, minTot / 2);
            res.Notes.Add($"Pourcentage minimal total imposé par la norme : {minTot:F2} cm² (inf + sup)");
        }
        var defl = code.CheckBeamDeflection(sec, length, m.Fc28, m.Fe, asB, bestMt, bestM0);

        res.AsBottom = asB; res.AsTop = asT;
        bool withinMax = true;
        double maxTot = cfg.BeamMaxPercent > 0 ? cfg.BeamMaxPercent / 100.0 * mem.B * mem.H * 1e4 : 0;
        if (maxTot > 0 && asB + asT > maxTot)
        {
            withinMax = false;
            res.Warnings.Add($"Armatures totales {asB + asT:F1} cm² > maximum {maxTot:F1} cm² ({cfg.BeamMaxPercent:0.#} % de la section) : augmenter la section.");
        }
        var cb = RebarSelector.ForBeam(asB, mem.B, mem.Cover, cfg);
        var ct = RebarSelector.ForBeam(asT, mem.B, mem.Cover, cfg);
        res.BarsBottom = $"{cb.Label} ({cb.AreaCm2:F2} cm²)";
        res.BarsTop = $"{ct.Label} ({ct.AreaCm2:F2} cm²)";
        res.BotN = cb.Count; res.BotDia = cb.Diameter; res.TopN = ct.Count; res.TopDia = ct.Diameter;
        int minBar = Math.Min(cb.Diameter, ct.Diameter);
        int minDia = (int)Math.Ceiling(Math.Max(cb.Diameter, ct.Diameter) / Math.Max(cfg.StirrupDiaRatio, 1.0));
        var st = RebarSelector.Stirrups(shear.Values["At_over_st_cm2_per_m"], shear.Values["st_max_cm"], minDia, cfg);
        res.Stirrups = $"cadres HA{st.Dia} e={st.SpacingCm:F0} cm (zone courante)";
        res.StirDia = st.Dia; res.StirSpacingCm = st.SpacingCm;
        double nodal = code.NodalStirrupSpacingCm(false, mem.H * 100, minBar);
        if (cfg.BeamNodalSpacingCm > 0) nodal = nodal > 0 ? Math.Min(nodal, cfg.BeamNodalSpacingCm) : cfg.BeamNodalSpacingCm;
        if (nodal > 0)
        {
            res.NodalSpacingCm = Math.Min(nodal, st.SpacingCm);
            res.NodalZoneM = Math.Min(0.25 * length, Math.Max(cfg.BeamCriticalZoneFactor, 0.5) * mem.H);
            res.Stirrups += $" ; zone critique e={res.NodalSpacingCm:F0} cm sur {res.NodalZoneM:F2} m";
        }

        res.Ok = bot.Ok && top.Ok && shear.Ok && withinMax;
        res.Utilization = Math.Max(Math.Max(bot.Values["mu"], top.Values["mu"]) / Math.Max(bot.Values["mu_l"], 1e-9),
                                   shear.Values["tau_u"] / Math.Max(shear.Values["tau_lim"], 1e-9));
        if (!withinMax) res.Utilization = Math.Max(res.Utilization, 1.01);
        res.Notes.Add($"Mu travée = {muSag:F1} kN.m, Mu appui = {muHog:F1} kN.m, Vu = {vu:F1} kN, Mser travée = {msSag:F1} kN.m");
        res.Notes.AddRange(bot.Notes.Select(n => "Armatures inférieures : " + n));
        res.Notes.AddRange(top.Notes.Select(n => "Armatures supérieures : " + n));
        res.Notes.AddRange(shear.Notes.Select(n => "Effort tranchant : " + n));
        res.ForfaitaireSatisfied = !(defl.Values.TryGetValue("needs_calc", out var nc) && nc > 0.5);
        string dm = cfg.DeflectionMethod ?? "Auto";
        bool showForf = dm == "Forfaitaire" || dm == "ForfPuisCalc";
        if (dm != "Aucune") res.Notes.AddRange(defl.Notes);
        res.Warnings.AddRange(bot.Warnings.Select(w => "Inf : " + w));
        res.Warnings.AddRange(top.Warnings.Select(w => "Sup : " + w));
        res.Warnings.AddRange(shear.Warnings);
        if (showForf) res.Warnings.AddRange(defl.Warnings);       // modes « calculée » : la flèche est calculée dans les vérifications complémentaires
        if (nMax > 0.05 * m.Fc28 * 1000 * mem.B * mem.H)
            res.Warnings.Add($"Effort normal notable (N={nMax:F0} kN) ignoré dans le calcul de la poutre.");
        if (mzMax > 0.15 * Math.Max(muSag, muHog) && mzMax > 5)
            res.Warnings.Add($"Flexion transversale Mz={mzMax:F1} kN.m non prise en compte (poutre en flexion simple).");
        if (tMax > 2) res.Warnings.Add($"Torsion T={tMax:F1} kN.m non vérifiée.");
    }

    private static void DesignColumn(StructModel m, Member mem, double length, IReinforcedConcreteCode code,
                                     Dictionary<ActionType, CaseResult> cases, MemberDesignResult res)
    {
        int ns = FrameSolver.Stations;
        int[] ks = { 0, ns / 2, ns - 1 };
        double lf = mem.LfFactor * length;
        DesignResult? gov = null;
        double vy = 0, vz = 0, nuMax = 0;
        bool allOk = true;
        var biDemands = new List<StructCalc.Engine.Sections.BiaxialDemand>();
        foreach (var c in CombinationSet.For(m, code.Combinations))
        {
            if (c.State == LimitState.ELS) continue;
            for (int k = 0; k < ns; k++)
            {
                var f = Combine(c, cases, mem.Id, k);
                vy = Math.Max(vy, Math.Abs(f.Vy)); vz = Math.Max(vz, Math.Abs(f.Vz));
                nuMax = Math.Max(nuMax, -f.N);
            }
            foreach (int k in ks)
            {
                var f = Combine(c, cases, mem.Id, k);
                var input = new ColumnInput(mem.B, mem.H, lf, m.Fc28, m.Fe, -f.N, Math.Abs(f.My), Math.Abs(f.Mz), mem.Cover, c.State);
                biDemands.Add(new StructCalc.Engine.Sections.BiaxialDemand(-f.N, Math.Abs(f.My), Math.Abs(f.Mz)));
                var r = code.DesignColumn(input);
                if (!r.Ok) allOk = false;
                if (gov == null || (!r.Ok && gov.Ok) || (r.Ok == gov.Ok && r.Values["As_cm2"] > gov.Values["As_cm2"]))
                { gov = r; gov.Element = $"Poteau - cas {c.Name}, section x={f.X:F2} m"; }
            }
        }
        if (gov == null) { res.Skipped = true; res.Warnings.Add("Aucune combinaison ELU."); return; }

        var cfg = m.Settings;
        double asTot = gov.Values["As_cm2"];
        double ac = mem.B * mem.H * 1e4;
        if (cfg.ColumnMinPercent > 0) asTot = Math.Max(asTot, cfg.ColumnMinPercent / 100.0 * ac);
        bool withinMaxCol = !(cfg.ColumnMaxPercent > 0 && asTot > cfg.ColumnMaxPercent / 100.0 * ac);
        if (!withinMaxCol)
            res.Warnings.Add($"Armatures {asTot:F1} cm² > maximum {cfg.ColumnMaxPercent / 100.0 * ac:F1} cm² ({cfg.ColumnMaxPercent:0.#} % de la section) : augmenter la section.");
        // flexion déviée (EC2 5.8.9) : seulement si les deux moments sont notables ; les armatures sont majorées au besoin
        bool biaxFail = false; string biaxNote = "";
        var biSig = biDemands.Where(d => d.N > 0 && Math.Max(d.My, d.Mz) > 5 && Math.Min(d.My, d.Mz) >= 0.15 * Math.Max(d.My, d.Mz)).ToList();
        if (biSig.Count > 0 && mem.B > 0.05 && mem.H > 0.05)
        {
            try
            {
                var bmat = new StructCalc.Engine.Sections.Mat { Fc = m.Fc28, Fe = m.Fe };
                double d1 = mem.Cover > 0.02 ? mem.Cover : 0.04;
                double asReqBi = StructCalc.Engine.Sections.BiaxialColumn.RequiredAs(mem.B, mem.H, asTot, Math.Max(asTot, 0.05 * ac), d1, bmat, lf, biSig, out var bres);
                biaxNote = bres.Text;
                if (!bres.Ok) { biaxFail = true; res.Warnings.Add("Flexion déviée non vérifiée avec 5 % d'acier : augmentez la section. " + bres.Text); }
                else if (asReqBi > asTot + 1e-9) { res.Notes.Add($"Flexion déviée : armatures majorées de {asTot:F1} à {asReqBi:F1} cm². "); asTot = asReqBi; }
            }
            catch { }
        }
        var cc = RebarSelector.ForColumn(asTot, cfg);
        if (biaxNote.Length > 0) res.Notes.Add(biaxNote);
        res.AsBottom = asTot; res.AsTop = asTot; res.NuMax = nuMax; res.Vu = Math.Max(vy, vz);
        res.BarsBottom = $"{cc.Label} ({cc.AreaCm2:F2} cm²)";
        res.BarsTop = res.BarsBottom;
        res.BotN = cc.Count; res.BotDia = cc.Diameter; res.TopN = cc.Count; res.TopDia = cc.Diameter;

        var s1 = code.DesignBeamShear(new RcRectSection(mem.B, mem.H, mem.Cover, mem.Cover), m.Fc28, m.Fe, vz, CrackingClass.Prejudiciable);
        var s2 = code.DesignBeamShear(new RcRectSection(mem.H, mem.B, mem.Cover, mem.Cover), m.Fc28, m.Fe, vy, CrackingClass.Prejudiciable);
        double atSt = Math.Max(s1.Values["At_over_st_cm2_per_m"], s2.Values["At_over_st_cm2_per_m"]);
        double stMax = Math.Min(cfg.MaxStirrupSpacingColumnCm, Math.Min(1.5 * cc.Diameter, Math.Min(mem.B, mem.H) * 100.0 + 10.0));
        int minDia = (int)Math.Ceiling(cc.Diameter / Math.Max(cfg.StirrupDiaRatio, 1.0));
        var st = RebarSelector.Stirrups(atSt, stMax, minDia, cfg);
        res.Stirrups = $"cadres HA{st.Dia} e={st.SpacingCm:F0} cm";
        res.StirDia = st.Dia; res.StirSpacingCm = st.SpacingCm;
        double nodal = code.NodalStirrupSpacingCm(true, Math.Min(mem.B, mem.H) * 100, cc.Diameter);
        if (cfg.ColumnNodalSpacingCm > 0) nodal = nodal > 0 ? Math.Min(nodal, cfg.ColumnNodalSpacingCm) : cfg.ColumnNodalSpacingCm;
        if (nodal > 0)
        {
            res.NodalSpacingCm = Math.Min(nodal, st.SpacingCm);
            res.NodalZoneM = Math.Min(0.5 * length, Math.Max(Math.Max(mem.B, mem.H), Math.Max(length / 6.0, cfg.ColumnCriticalZoneMinCm / 100.0)));
            res.Stirrups += $" ; zone nodale e={res.NodalSpacingCm:F0} cm sur {res.NodalZoneM:F2} m";
        }

        res.Ok = allOk && s1.Ok && s2.Ok && withinMaxCol && !biaxFail;
        res.Utilization = gov.Values["As_req_cm2"] / Math.Max(gov.Values["As_max_cm2"], 1e-9);
        if (!withinMaxCol) res.Utilization = Math.Max(res.Utilization, 1.01);
        res.Notes.Add($"Longueur de flambement lf = {mem.LfFactor} x {length:F2} = {lf:F2} m ; Nu max = {nuMax:F0} kN");
        res.Notes.AddRange(gov.Notes);
        res.Notes.AddRange(s1.Notes.Select(n => "Tranchant (plan xz) : " + n));
        res.Notes.AddRange(s2.Notes.Select(n => "Tranchant (plan xy) : " + n));
        res.Warnings.AddRange(gov.Warnings.Distinct());
        res.Warnings.AddRange(s1.Warnings.Concat(s2.Warnings));
    }

    // ======================================================================= ACIER
    public static MemberDesignResult DesignSteel(StructModel m, Member mem, double length, ISteelCode code,
                                                 Dictionary<ActionType, CaseResult> cases)
    {
        var res = NewResult(mem, length);
        if (!SteelCatalog.TryGet(mem.Profile, out var prof))
        {
            res.Skipped = true; res.Warnings.Add($"Profil '{mem.Profile}' inconnu (IPE, HEA, HEB disponibles).");
            return res;
        }
        res.Profile = prof.Name; res.B = prof.B / 1000.0; res.H = prof.H / 1000.0;
        int ns = FrameSolver.Stations;
        bool loaded = m.IncludeSelfWeight || LoadExpander.MemberLoadsOf(m).Any(l => l.MemberId == mem.Id);
        double lfy = Math.Max(mem.LfFactor, 0.5) * length, lfz = lfy;
        if (m.AutoEffectiveLength && mem.Type == MemberType.Column)
        {
            lfy = EffectiveLengths.Ratio(m, mem, true, m.SwayFrame) * length;
            lfz = EffectiveLengths.Ratio(m, mem, false, m.SwayFrame) * length;
            res.Notes.Add($"Longueurs de flambement (Annexe E EC3, {(m.SwayFrame ? "noeuds déplaçables" : "noeuds fixes")}) : lf,y = {lfy:F2} m ; lf,z = {lfz:F2} m");
        }
        DesignResult? gov = null;
        double maxU = 0, mySag = 0, myHog = 0, vmax = 0, nmax = 0;
        bool allOk = true;
        foreach (var c in CombinationSet.For(m, code.Combinations))
        {
            if (c.State == LimitState.ELS) continue;
            double m0 = Combine(c, cases, mem.Id, 0).My, m1 = Combine(c, cases, mem.Id, ns - 1).My;
            double big = Math.Abs(m0) >= Math.Abs(m1) ? m0 : m1, small = Math.Abs(m0) >= Math.Abs(m1) ? m1 : m0;
            double psi = Math.Abs(big) < 1e-6 ? 1.0 : small / big;
            for (int k = 0; k < ns; k++)
            {
                var f = Combine(c, cases, mem.Id, k);
                mySag = Math.Max(mySag, -f.My); myHog = Math.Max(myHog, f.My);
                vmax = Math.Max(vmax, Math.Max(Math.Abs(f.Vz), Math.Abs(f.Vy))); nmax = Math.Max(nmax, -f.N);
                var inp = new SteelInput(prof, m.SteelFy, length, lfy, lfz, length, -f.N, f.My, f.Mz, f.Vy, f.Vz, psi, loaded, c.State);
                var r = code.CheckMember(inp);
                double u = r.Values.TryGetValue("util", out var uu) ? uu : 9.99;
                if (!r.Ok) allOk = false;
                if (u > maxU || gov == null) { maxU = u; gov = r; gov.Element = $"{r.Element} - cas {c.Name}, x={f.X:F2} m"; }
            }
        }
        if (gov == null) { res.Skipped = true; res.Warnings.Add("Aucune combinaison ELU."); return res; }
        res.Utilization = maxU; res.Ok = allOk && maxU <= 1.0;
        res.MuSag = mySag; res.MuHog = myHog; res.Vu = vmax; res.NuMax = nmax;
        res.BarsBottom = prof.Name; res.BarsTop = prof.Name;
        res.Stirrups = $"taux de travail {maxU:F2}";
        res.Notes.AddRange(gov.Notes);
        res.Warnings.AddRange(gov.Warnings.Distinct());
        res.Warnings.Add("Flèche, assemblages et stabilité d'ensemble non vérifiés.");
        return res;
    }
}
