using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine.Geometry;

namespace StructCalc.Engine;

/// <summary>Métré estimatif (béton, aciers, profilés) à partir des résultats. Estimation : pas de recouvrements, coudes, chutes ni ancrages.</summary>
public sealed class Quantities
{
    public double ConcreteM3 { get; set; }
    public double RebarKg { get; set; }
    public double StirrupKg { get; set; }
    public double ProfileKg { get; set; }
    public double FormworkM2 { get; set; }
    public double RebarRatioKgM3 => ConcreteM3 > 0 ? (RebarKg + StirrupKg) / ConcreteM3 : 0;

    public static Quantities Compute(StructModel m, AnalysisOutput o)
    {
        var q = new Quantities();
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        foreach (var r in o.Members)
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == r.MemberId);
            if (mem == null || !nodes.ContainsKey(mem.NodeI) || !nodes.ContainsKey(mem.NodeJ)) continue;
            double L = r.Length;
            if (mem.Kind == MaterialKind.Steel)
            {
                if (SteelCatalog.TryGet(mem.Profile, out var p)) q.ProfileKg += p.MassKgPerM * L;
                continue;
            }
            q.ConcreteM3 += mem.B * mem.H * L;
            q.FormworkM2 += 2 * (mem.B + mem.H) * L;
            double asTot = mem.Type == MemberType.Column ? r.AsBottom : r.AsBottom + r.AsTop;
            q.RebarKg += asTot * L * 0.785;                                    // 1 cm² x 1 m d'acier = 0,785 kg
            if (r.StirDia > 0 && r.StirSpacingCm > 0)
            {
                double perim = 2 * ((mem.B - 0.06) + (mem.H - 0.06)) + 0.2;
                double n = L / (r.StirSpacingCm / 100.0) + 1;
                q.StirrupKg += n * perim * RebarSelector.Area(r.StirDia) * 0.785 * 1.0;
            }
        }
        foreach (var s in m.Slabs)
        {
            double area = s.Lx * s.Ly;
            q.ConcreteM3 += s.Volume;                  // volume de béton réel (corps creux, alvéolée, mixte : part de béton)
            q.FormworkM2 += area;
        }
        foreach (var s in o.Slabs)
        {
            if (!s.Values.ContainsKey("Asx_travee_cm2m")) continue;
            double a = (s.Values["Asx_travee_cm2m"] + s.Values["Asy_travee_cm2m"]
                        + 0.3 * (s.Values["Asx_appui_cm2m"] + s.Values["Asy_appui_cm2m"])) * 0.785;   // kg par m²
            var panel = m.Slabs.FirstOrDefault(x => s.Element.StartsWith("Dalle " + x.Name));
            if (panel != null) q.RebarKg += a * panel.Lx * panel.Ly;
        }
        foreach (var f in o.Footings)
        {
            if (!f.Values.ContainsKey("A_m")) continue;
            double A = f.Values["A_m"], B = f.Values["B_m"], h = f.Values["h_m"];
            int nid = FootingPlacement.NodeIdOf(f.Element);
            var fdef = m.FootingDefs.FirstOrDefault(x => x.Name == "S" + nid && x.Kind == FootingKind.Isolee);
            bool gl = fdef != null ? fdef.Glacis : m.FootingGlacis;
            if (gl)
            {
                var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && (x.NodeI == nid || x.NodeJ == nid));
                q.ConcreteM3 += FootingSolids.Volume(A, B, h, col?.B ?? 0.3, col?.H ?? 0.3, true, fdef != null ? fdef.GlacisEdgeCm : m.FootingGlacisEdgeCm);     // semelle à glacis : volume réduit
            }
            else q.ConcreteM3 += A * B * h;
            q.RebarKg += (f.Values["As_A_cm2"] * A + f.Values["As_B_cm2"] * B) * 0.785;
        }
        foreach (var x in o.Extras)
        {
            q.ConcreteM3 += x.ConcreteM3; q.FormworkM2 += x.FormworkM2; q.RebarKg += x.SteelKg;
        }
        return q;
    }

    public string ToText()
    {
        var sb = new StringBuilder();
        sb.AppendLine("MÉTRÉ ESTIMATIF (à titre indicatif)");
        sb.AppendLine("-----------------------------------");
        sb.AppendLine($"Béton                      : {ConcreteM3,9:F2} m³");
        sb.AppendLine($"Coffrage (barres + dalles) : {FormworkM2,9:F1} m²");
        sb.AppendLine($"Aciers HA longitudinaux    : {RebarKg,9:F0} kg");
        sb.AppendLine($"Aciers HA transversaux     : {StirrupKg,9:F0} kg");
        sb.AppendLine($"Ratio acier / béton        : {RebarRatioKgM3,9:F0} kg/m³");
        sb.AppendLine($"Profilés métalliques       : {ProfileKg,9:F0} kg");
        sb.AppendLine();
        sb.AppendLine("Sans recouvrements, coudes, ancrages ni chutes : majorer de 10 à 15 % pour une estimation de chantier.");
        return sb.ToString();
    }
}
