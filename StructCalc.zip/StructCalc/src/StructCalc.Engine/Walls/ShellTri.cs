using StructCalc.Engine.Structure;

namespace StructCalc.Engine.Walls;

/// <summary>Coque plane à maillage TRIANGULÉ : chaque maille rectangulaire du voile est coupée en deux triangles (diagonale alternée selon la parité de la maille).
/// Chaque triangle = membrane à déformation constante (CST) + plaque DKT (Kirchhoff), 5 ddl par nœud (u, v, w, φx, φy) comme l'élément quadrangulaire :
/// les deux éléments sont interchangeables dans le solveur. Les efforts de la maille sont la moyenne des deux triangles.
/// Le triangle CST est moins précis en flexion dans le plan que le quadrangle QM6 : affiner le maillage pour un voile élancé chargé dans son plan.</summary>
public static class ShellTri
{
    private static int[][] Tris(bool diagA) => diagA ? new[] { new[] { 0, 1, 2 }, new[] { 0, 2, 3 } } : new[] { new[] { 0, 1, 3 }, new[] { 1, 2, 3 } };

    private static (double[] x, double[] y) Coords(ShellElement.Props p, int[] t)
    {
        double[] cx = { 0, p.A, p.A, 0 }, cy = { 0, 0, p.B, p.B };
        return (new[] { cx[t[0]], cx[t[1]], cx[t[2]] }, new[] { cy[t[0]], cy[t[1]], cy[t[2]] });
    }

    private static double[,] CstB(double[] x, double[] y, out double area)
    {
        double y23 = y[1] - y[2], y31 = y[2] - y[0], y12 = y[0] - y[1], x32 = x[2] - x[1], x13 = x[0] - x[2], x21 = x[1] - x[0];
        area = 0.5 * ((x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0]));
        double f = 1.0 / (2 * area);
        return new double[,]
        {
            { f * y23, 0, f * y31, 0, f * y12, 0 },
            { 0, f * x32, 0, f * x13, 0, f * x21 },
            { f * x32, f * y23, f * x13, f * y31, f * x21, f * y12 }
        };
    }

    /// <summary>Rigidité 20 x 20 de la maille (ddl nœud i : 5i+0 u, 5i+1 v, 5i+2 w, 5i+3 φx, 5i+4 φy).</summary>
    public static double[,] Stiffness(ShellElement.Props p, bool diagA)
    {
        var K = new double[20, 20];
        double c0 = p.E * p.T / (1 - p.Nu * p.Nu), db = p.E * p.T * p.T * p.T / (12 * (1 - p.Nu * p.Nu));
        foreach (var t in Tris(diagA))
        {
            var (x, y) = Coords(p, t);
            var B = CstB(x, y, out double area);
            double d11 = c0, d12 = c0 * p.Nu, d33 = c0 * (1 - p.Nu) / 2;
            for (int a = 0; a < 6; a++)
                for (int b = 0; b < 6; b++)
                {
                    double s = B[0, a] * (d11 * B[0, b] + d12 * B[1, b]) + B[1, a] * (d12 * B[0, b] + d11 * B[1, b]) + B[2, a] * d33 * B[2, b];
                    K[5 * t[a / 2] + a % 2, 5 * t[b / 2] + b % 2] += s * area;
                }
            var kp = Dkt.Stiffness(x, y, db, p.Nu);
            for (int a = 0; a < 9; a++)
                for (int b = 0; b < 9; b++)
                    K[5 * t[a / 3] + 2 + a % 3, 5 * t[b / 3] + 2 + b % 3] += kp[a, b];
        }
        return K;
    }

    /// <summary>Efforts au centre de la maille (n en N/m, m en N.m/m, q en N/m), moyenne des deux triangles. <paramref name="u"/> : 20 déplacements locaux.</summary>
    public static (double nx, double ny, double nxy, double mx, double my, double mxy, double qx, double qy) Recover(ShellElement.Props p, double[] u, bool diagA)
    {
        double c0 = p.E * p.T / (1 - p.Nu * p.Nu), db = p.E * p.T * p.T * p.T / (12 * (1 - p.Nu * p.Nu));
        double nx = 0, ny = 0, nxy = 0, mx = 0, my = 0, mxy = 0, qx = 0, qy = 0;
        var tris = Tris(diagA);
        foreach (var t in tris)
        {
            var (x, y) = Coords(p, t);
            var B = CstB(x, y, out _);
            var um = new double[6]; var up = new double[9];
            for (int k = 0; k < 3; k++)
            {
                um[2 * k] = u[5 * t[k]]; um[2 * k + 1] = u[5 * t[k] + 1];
                for (int c = 0; c < 3; c++) up[3 * k + c] = u[5 * t[k] + 2 + c];
            }
            double exx = 0, eyy = 0, gxy = 0;
            for (int a = 0; a < 6; a++) { exx += B[0, a] * um[a]; eyy += B[1, a] * um[a]; gxy += B[2, a] * um[a]; }
            nx += c0 * (exx + p.Nu * eyy); ny += c0 * (p.Nu * exx + eyy); nxy += c0 * (1 - p.Nu) / 2 * gxy;
            var mv = Dkt.VertexMoments(x, y, up, db, p.Nu);
            for (int v = 0; v < 3; v++) { mx += mv[v][0] / 3; my += mv[v][1] / 3; mxy += mv[v][2] / 3; }
            var (sx, sy) = Dkt.Shear(x, y, mv);
            qx += sx; qy += sy;
        }
        double k2 = 1.0 / tris.Length;
        return (nx * k2, ny * k2, nxy * k2, mx * k2, my * k2, mxy * k2, qx * k2, qy * k2);
    }
}
