using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Walls;

public sealed class WallZone
{
    public double X0, Y0, X1, Y1;          // emprise (m, repère du voile)
    public double AsV, AsH;                // maxima requis par face (cm²/m)
    public string BarsV = "", BarsH = "";
    public int Elements;
}

public sealed class WallOpeningResult
{
    public WallOpening Opening = new();
    public double JambCm2, LintelCm2, SillCm2;
    public string Jamb = "", Lintel = "", Sill = "", Corners = "";
}

public sealed class WallResult
{
    public WallDef Def = new();
    public WallMesh Mesh = new();
    public double EModulusMPa;
    public double MeshM;
    public bool Triangulated;
    public List<string> ComboNames = new();
    public double[] AsV = Array.Empty<double>();            // par élément : maxima par face, cm²/m (barres verticales)
    public double[] AsH = Array.Empty<double>();            // barres horizontales
    public double[] SigC = Array.Empty<double>();           // compression maximale de membrane (MPa)
    public double[] Disp = Array.Empty<double>();           // déplacement moyen de l'élément, ELS G+Q(+E) en mm
    public double[] NyMin = Array.Empty<double>();          // effort vertical ny le plus comprimé (kN/m)
    public double[] NxyMax = Array.Empty<double>();         // cisaillement |nxy| max (kN/m)
    public double[] MPlateMax = Array.Empty<double>();      // moment de plaque max (kN.m/m)
    public double GeneralAsV, GeneralAsH, MinAs;
    public string GeneralV = "", GeneralH = "";
    public List<WallZone> Zones = new();
    public List<WallOpeningResult> OpeningResults = new();
    public double MaxDispMm;
    public double Tau, TauLim;
    public double ConcreteM3, SteelKg, FormworkM2;
    public List<string> Warnings = new();
    public bool Ok = true;
    public string Report = "";
}

/// <summary>Voile en coque : charges, solveur éléments finis, combinaisons, dimensionnement par modèle sandwich (Nielsen / Annexe F EC2) et armatures de renfort autour des ouvertures.</summary>
public static class WallDesigner
{
    private sealed record Combo(string Name, double G, double Q, double E, double W);

    public static WallResult Design(WallDef w, IReinforcedConcreteCode rc, double fc28, double fe, DesignSettings? cfg = null)
    {
        var res = new WallResult { Def = w };
        if (w.LengthM <= 0 || w.HeightM <= 0 || w.ThicknessM <= 0) { res.Ok = false; res.Warnings.Add("Dimensions du voile invalides."); return res; }
        foreach (var o in w.Openings)
        {
            if (o.XM < 0.1 - 1e-9 || o.XM + o.WidthM > w.LengthM - 0.1 + 1e-9 || o.ZM < 0 || o.ZM + o.HeightM > w.HeightM + 1e-9)
                res.Warnings.Add($"Ouverture {o.Name} hors du voile ou à moins de 10 cm d'un bord.");
            if (o.ZM + o.HeightM > w.HeightM - 0.2 - 1e-9) res.Warnings.Add($"Ouverture {o.Name} sans linteau (moins de 20 cm sous la tête) : la charge en tête est perdue au droit de l'ouverture.");
        }
        for (int a = 0; a < w.Openings.Count; a++)
            for (int b = a + 1; b < w.Openings.Count; b++)
            {
                var p = w.Openings[a]; var q = w.Openings[b];
                if (p.XM < q.XM + q.WidthM && q.XM < p.XM + p.WidthM && p.ZM < q.ZM + q.HeightM && q.ZM < p.ZM + p.HeightM)
                    res.Warnings.Add($"Les ouvertures {p.Name} et {q.Name} se chevauchent.");
            }
        if (res.Warnings.Any(x => x.Contains("hors du voile") || x.Contains("chevauchent"))) { res.Ok = false; res.Report = string.Join("\n", res.Warnings); return res; }

        double meshUsed = StructCalc.Core.MeshPresets.WallSize(w, cfg);
        var wm = w;
        if (Math.Abs(meshUsed - w.MeshM) > 1e-9) { wm = w.Clone(); wm.MeshM = meshUsed; }
        res.MeshM = meshUsed;
        bool tri = (string.IsNullOrEmpty(w.MeshElement) || w.MeshElement == "Global" ? cfg?.MeshElement : w.MeshElement) == "Tri";
        res.Triangulated = tri;
        var solver = new WallSolver(wm, fc28, tri);
        var mesh = solver.Mesh; res.Mesh = mesh; res.EModulusMPa = solver.E / 1e6;
        int ne = mesh.Elems.Count;

        // ---- cas de charges
        double[] fG = w.SelfWeight ? solver.SelfWeightLoad(25.0) : new double[mesh.Nodes.Count * 5];
        var tg = solver.TopLineLoad(w.GTopKnPerM * 1000); for (int i = 0; i < fG.Length; i++) fG[i] += tg[i];
        var G = solver.SolveCase(fG);
        var Q = solver.SolveCase(solver.TopLineLoad(w.QTopKnPerM * 1000));
        var E = solver.SolveCase(solver.TopHorizontal(w.EHorizKn * 1000));
        double hSoil = w.RetainedHeightM > 0 ? Math.Min(w.RetainedHeightM, w.HeightM) : w.HeightM;
        var W = solver.SolveCase(w.Retaining ? solver.EarthPressure(hSoil, w.SoilGammaKnM3, w.KEarth, w.SurchargeKPa) : solver.Pressure(w.WindKPa * 1000));
        bool lateral = w.Retaining || w.WindKPa != 0;

        var combos = new List<Combo> { new("1,35G + 1,5Q", 1.35, 1.5, 0, 0) };
        if (lateral) { combos.Add(new("1,35G + 1,5W", 1.35, 0, 0, 1.5)); combos.Add(new("1,35G + 1,5W (inversé)", 1.35, 0, 0, -1.5)); combos.Add(new("1,35G + 1,35Q + 1,35W", 1.35, 1.35, 0, 1.35)); combos.Add(new("1,35G + 1,35Q + 1,35W (inversé)", 1.35, 1.35, 0, -1.35)); }
        if (w.EHorizKn != 0) { combos.Add(new("G + Q + E", 1, 1, 1, 0)); combos.Add(new("G + Q - E", 1, 1, -1, 0)); combos.Add(new("0,8G + E", 0.8, 0, 1, 0)); combos.Add(new("0,8G - E", 0.8, 0, -1, 0)); }
        res.ComboNames = combos.Select(c => c.Name).ToList();

        // ---- dimensionnement par élément
        double t = w.ThicknessM, cov = w.CoverCm / 100, z = Math.Max(t - 2 * cov, 0.5 * t);
        double fyd = fe / 1.15, fcd = 0.85 * fc28 / 1.5;
        res.AsV = new double[ne]; res.AsH = new double[ne]; res.SigC = new double[ne]; res.NyMin = new double[ne]; res.NxyMax = new double[ne]; res.MPlateMax = new double[ne]; res.Disp = new double[ne];
        for (int e = 0; e < ne; e++)
        {
            foreach (var cb in combos)
            {
                double nx = cb.G * G.Forces[e].nx + cb.Q * Q.Forces[e].nx + cb.E * E.Forces[e].nx + cb.W * W.Forces[e].nx;
                double ny = cb.G * G.Forces[e].ny + cb.Q * Q.Forces[e].ny + cb.E * E.Forces[e].ny + cb.W * W.Forces[e].ny;
                double nxy = cb.G * G.Forces[e].nxy + cb.Q * Q.Forces[e].nxy + cb.E * E.Forces[e].nxy + cb.W * W.Forces[e].nxy;
                double mx = cb.G * G.Forces[e].mx + cb.Q * Q.Forces[e].mx + cb.E * E.Forces[e].mx + cb.W * W.Forces[e].mx;
                double my = cb.G * G.Forces[e].my + cb.Q * Q.Forces[e].my + cb.E * E.Forces[e].my + cb.W * W.Forces[e].my;
                double mxy = cb.G * G.Forces[e].mxy + cb.Q * Q.Forces[e].mxy + cb.E * E.Forces[e].mxy + cb.W * W.Forces[e].mxy;
                res.NyMin[e] = Math.Min(res.NyMin[e], ny / 1000); res.NxyMax[e] = Math.Max(res.NxyMax[e], Math.Abs(nxy) / 1000);
                res.MPlateMax[e] = Math.Max(res.MPlateMax[e], Math.Max(Math.Abs(mx), Math.Max(Math.Abs(my), Math.Abs(mxy))) / 1000);
                for (int face = -1; face <= 1; face += 2)
                {
                    double fx = nx / 2 + face * mx / z, fy = ny / 2 + face * my / z, fxy = nxy / 2 + face * mxy / z;
                    var (tx, ty) = Nielsen(fx, fy, fxy);
                    res.AsH[e] = Math.Max(res.AsH[e], tx / fyd / 100);
                    res.AsV[e] = Math.Max(res.AsV[e], ty / fyd / 100);
                    double s1 = (fx + fy) / 2 - Math.Sqrt(Math.Pow((fx - fy) / 2, 2) + fxy * fxy);       // contrainte principale (négative = compression)
                    res.SigC[e] = Math.Max(res.SigC[e], Math.Max(-s1, 0) / (0.5 * t) / 1e6);
                }
            }
            // déplacement ELS (G+Q, plus E/W)
            double dmax = 0;
            var el = mesh.Elems[e];
            foreach (int nd in el.N)
            {
                double ux = G.U[5 * nd] + Q.U[5 * nd] + Math.Abs(E.U[5 * nd]) + Math.Abs(W.U[5 * nd]);
                double uy = G.U[5 * nd + 1] + Q.U[5 * nd + 1];
                double uz = G.U[5 * nd + 2] + Math.Abs(W.U[5 * nd + 2]);
                dmax += Math.Sqrt(ux * ux + uy * uy + uz * uz) / 4;
            }
            res.Disp[e] = dmax * 1000;
        }
        res.MaxDispMm = res.Disp.Length > 0 ? res.Disp.Max() : 0;

        // ---- armatures minimales et générales
        double tCm = t * 100;
        res.MinAs = 0.0015 * 100 * tCm / 2;                       // 0,15 % de la section, par face (cm²/m)
        double maxSp = Math.Min(1.5 * tCm, 30);
        var sortedV = res.AsV.OrderBy(x => x).ToArray(); var sortedH = res.AsH.OrderBy(x => x).ToArray();
        res.GeneralAsV = Math.Max(res.MinAs, ne > 0 ? sortedV[(int)(0.9 * (ne - 1))] : 0);
        res.GeneralAsH = Math.Max(res.MinAs, ne > 0 ? sortedH[(int)(0.9 * (ne - 1))] : 0);
        var gv = RebarSelector.Spacing(res.GeneralAsV, maxSp, cfg); var gh = RebarSelector.Spacing(res.GeneralAsH, maxSp, cfg);
        res.GeneralV = $"HA{gv.Dia} e={gv.SpacingCm:0} cm"; res.GeneralH = $"HA{gh.Dia} e={gh.SpacingCm:0} cm";
        double asVprov = RebarSelector.Area(gv.Dia) * 100 / gv.SpacingCm, asHprov = RebarSelector.Area(gh.Dia) * 100 / gh.SpacingCm;

        // ---- zones à renforcer (composantes connexes des éléments où As > armatures générales)
        var need = new bool[ne]; var cell = new Dictionary<(int, int), int>();
        for (int e = 0; e < ne; e++) { cell[(mesh.Elems[e].I, mesh.Elems[e].J)] = e; need[e] = res.AsV[e] > asVprov + 1e-6 || res.AsH[e] > asHprov + 1e-6; }
        var seen = new bool[ne];
        for (int e0 = 0; e0 < ne; e0++)
        {
            if (!need[e0] || seen[e0]) continue;
            var stack = new Stack<int>(); stack.Push(e0); seen[e0] = true;
            var z0 = new WallZone { X0 = double.MaxValue, Y0 = double.MaxValue, X1 = double.MinValue, Y1 = double.MinValue };
            while (stack.Count > 0)
            {
                int e = stack.Pop(); var el = mesh.Elems[e];
                z0.Elements++; z0.AsV = Math.Max(z0.AsV, res.AsV[e]); z0.AsH = Math.Max(z0.AsH, res.AsH[e]);
                z0.X0 = Math.Min(z0.X0, el.Xc - el.A / 2); z0.X1 = Math.Max(z0.X1, el.Xc + el.A / 2);
                z0.Y0 = Math.Min(z0.Y0, el.Yc - el.B / 2); z0.Y1 = Math.Max(z0.Y1, el.Yc + el.B / 2);
                foreach (var (di, dj) in new[] { (1, 0), (-1, 0), (0, 1), (0, -1) })
                    if (cell.TryGetValue((el.I + di, el.J + dj), out int k) && need[k] && !seen[k]) { seen[k] = true; stack.Push(k); }
            }
            var sv = RebarSelector.Spacing(Math.Max(z0.AsV, res.GeneralAsV), maxSp, cfg); var sh = RebarSelector.Spacing(Math.Max(z0.AsH, res.GeneralAsH), maxSp, cfg);
            z0.BarsV = $"HA{sv.Dia} e={Math.Min(sv.SpacingCm, gv.SpacingCm):0}"; z0.BarsH = $"HA{sh.Dia} e={Math.Min(sh.SpacingCm, gh.SpacingCm):0}";
            res.Zones.Add(z0);
        }
        res.Zones = res.Zones.OrderByDescending(q => Math.Max(q.AsV, q.AsH)).Take(12).ToList();

        // ---- ouvertures : chaînages et renforts
        foreach (var o in w.Openings)
        {
            var ores = new WallOpeningResult { Opening = o };
            double aV = asVprov * 2, aH = asHprov * 2;          // deux faces, cm²/m
            double jamb = aV * o.WidthM / 2, lintel = aH * o.HeightM / 2;
            // renfort issu du calcul EF : somme des armatures sur les mailles voisines
            double jambFe = 0, lintFe = 0, sillFe = 0;
            for (int e = 0; e < ne; e++)
            {
                var el = mesh.Elems[e];
                bool inX = el.Xc > o.XM && el.Xc < o.XM + o.WidthM, inY = el.Yc > o.ZM && el.Yc < o.ZM + o.HeightM;
                bool sideL = Math.Abs(el.Xc + el.A / 2 - o.XM) < 1e-3, sideR = Math.Abs(el.Xc - el.A / 2 - (o.XM + o.WidthM)) < 1e-3;
                if ((sideL || sideR) && inY) jambFe = Math.Max(jambFe, res.AsV[e] * el.A * 2);
                if (inX && Math.Abs(el.Yc - el.B / 2 - (o.ZM + o.HeightM)) < 1e-3) lintFe = Math.Max(lintFe, res.AsH[e] * el.B * 2);
                if (inX && o.ZM > 0 && Math.Abs(el.Yc + el.B / 2 - o.ZM) < 1e-3) sillFe = Math.Max(sillFe, res.AsH[e] * el.B * 2);
            }
            double min12 = 2 * RebarSelector.Area(12);
            ores.JambCm2 = Math.Max(jamb, Math.Max(jambFe, min12));
            ores.LintelCm2 = Math.Max(lintel, Math.Max(lintFe, min12));
            ores.SillCm2 = o.ZM > 0 ? Math.Max(lintel, Math.Max(sillFe, min12)) : 0;
            ores.Jamb = Bars(ores.JambCm2); ores.Lintel = Bars(ores.LintelCm2); ores.Sill = o.ZM > 0 ? Bars(ores.SillCm2) : "-";
            ores.Corners = "2HA12 à 45° (L = 1,00 m) à chaque angle";
            res.OpeningResults.Add(ores);
        }

        // ---- vérifications globales
        if (w.EHorizKn != 0)
        {
            res.Tau = 1.4 * Math.Abs(w.EHorizKn) / 1000 / (0.9 * w.LengthM * t);
            res.TauLim = 0.2 * fc28;
            if (res.Tau > res.TauLim) { res.Ok = false; res.Warnings.Add($"Contrainte de cisaillement τ = {res.Tau:0.00} MPa > {res.TauLim:0.00} MPa : augmenter l'épaisseur ou la longueur du voile."); }
        }
        double emax = Math.Max(15, w.HeightM * 100 / 20);
        if (tCm < emax - 1e-9) { res.Warnings.Add($"Épaisseur {tCm:0} cm < max(15 cm ; he/20) = {emax:0} cm (RPA 99 art. 7.7.1)."); res.Ok = false; }
        double sigMax = res.SigC.Length > 0 ? res.SigC.Max() : 0;
        if (sigMax > fcd) { res.Ok = false; res.Warnings.Add($"Compression du béton {sigMax:0.0} MPa > {fcd:0.0} MPa dans certaines mailles (concentration près des ouvertures ou en pied)."); }
        if (res.MaxDispMm > w.HeightM * 1000 / 250) res.Warnings.Add($"Déplacement ELS {res.MaxDispMm:0.0} mm > h/250 = {w.HeightM * 1000 / 250:0.0} mm.");
        if (res.Warnings.Any(x => x.StartsWith("Ouverture"))) { }

        // ---- quantités
        double area = w.LengthM * w.HeightM - w.Openings.Sum(o => o.WidthM * o.HeightM);
        res.ConcreteM3 = area * t; res.FormworkM2 = 2 * area;
        double kg = 0;
        for (int e = 0; e < ne; e++) { var el = mesh.Elems[e]; kg += 7850 * 2 * (Math.Max(res.AsV[e], asVprov) + Math.Max(res.AsH[e], asHprov)) * 1e-4 * el.A * el.B; }
        kg += res.OpeningResults.Sum(q => (q.JambCm2 * 2 * (q.Opening.HeightM + 0.8) + q.LintelCm2 * (q.Opening.WidthM + 0.8) + q.SillCm2 * (q.Opening.WidthM + 0.8)) * 0.785 + 4 * 1.0 * RebarSelector.Area(12) * 0.785);
        res.SteelKg = kg;
        res.Report = Build(res, G, Q, E, W, asVprov, asHprov, fcd);
        return res;
    }

    private static string Bars(double cm2)
    {
        foreach (int dia in new[] { 12, 14, 16, 20, 25 })
        {
            int n = (int)Math.Ceiling(cm2 / RebarSelector.Area(dia) - 1e-9);
            if (n <= 8) { n = Math.Max(n, 2); return $"{n}HA{dia} ({n * RebarSelector.Area(dia):0.0} cm²)"; }
        }
        return $"{Math.Ceiling(cm2 / RebarSelector.Area(25))}HA25";
    }

    /// <summary>Armatures de membrane (Eurocode 2, Annexe F) : forces de traction par mètre dans les directions x et y, en N/m (≥ 0).</summary>
    public static (double tx, double ty) Nielsen(double nx, double ny, double nxy)
    {
        double s = Math.Abs(nxy);
        double tx = nx + s, ty = ny + s;
        if (tx < 0) { tx = 0; ty = ny + nxy * nxy / Math.Max(Math.Abs(nx), 1e-9); }
        else if (ty < 0) { ty = 0; tx = nx + nxy * nxy / Math.Max(Math.Abs(ny), 1e-9); }
        return (Math.Max(tx, 0), Math.Max(ty, 0));
    }

    private static string Build(WallResult r, WallCaseResult G, WallCaseResult Q, WallCaseResult E, WallCaseResult W, double asV, double asH, double fcd)
    {
        var w = r.Def; var sb = new StringBuilder();
        sb.AppendLine($"VOILE {w.Name} (coque) : L = {w.LengthM:0.00} m, H = {w.HeightM:0.00} m, e = {w.ThicknessM * 100:0} cm, {w.Openings.Count} ouverture(s)");
        sb.AppendLine($"Maillage : {(r.Triangulated ? r.Mesh.Elems.Count * 2 : r.Mesh.Elems.Count)} {(r.Triangulated ? "triangles CST + DKT (2 par maille)" : "éléments MITC4/QM6")} de ≈ {r.MeshM:0.00} m ({(string.IsNullOrEmpty(w.MeshMode) ? "Global" : w.MeshMode)}), {r.Mesh.Nodes.Count} nœuds, {r.Mesh.Nodes.Count * 5} ddl ; E = {r.EModulusMPa:0} MPa, ν = 0,2");
        sb.AppendLine($"Appui : pied {(w.Base == WallBase.Encastre ? "encastré" : "articulé")}, tête {(w.TopHeldOutOfPlane ? "maintenue hors plan (plancher)" : "libre hors plan")}");
        sb.AppendLine($"Charges : G en tête {w.GTopKnPerM:0.#} kN/m{(w.SelfWeight ? " + poids propre" : "")} ; Q = {w.QTopKnPerM:0.#} kN/m ; E = {w.EHorizKn:0.#} kN ; pression W = {w.WindKPa:0.##} kPa" + (w.Retaining ? $" ; poussée des terres : K = {w.KEarth:0.##}, γ = {w.SoilGammaKnM3:0.#} kN/m³, hauteur retenue {(w.RetainedHeightM > 0 ? w.RetainedHeightM : w.HeightM):0.00} m, surcharge {w.SurchargeKPa:0.#} kPa" : ""));
        sb.AppendLine("Combinaisons : " + string.Join(" ; ", r.ComboNames));
        sb.AppendLine("Dimensionnement : modèle sandwich (deux faces), armatures de membrane par la méthode de Nielsen (EC2 Annexe F) en chaque maille.");
        sb.AppendLine();
        foreach (var o in w.Openings) sb.AppendLine($"Ouverture {o.Name} : x = {o.XM:0.00} m, allège {o.ZM:0.00} m, {o.WidthM:0.00} x {o.HeightM:0.00} m");
        sb.AppendLine();
        sb.AppendLine("RÉSULTATS");
        sb.AppendLine($"  Déplacement maximal ELS ≈ {r.MaxDispMm:0.00} mm");
        sb.AppendLine($"  Armatures minimales (0,15 % de la section) : {r.MinAs:0.00} cm²/m par face");
        sb.AppendLine($"  Armatures générales par face : verticales {r.GeneralV} ({asV:0.00} cm²/m, requis p90 {r.GeneralAsV:0.00}) ; horizontales {r.GeneralH} ({asH:0.00} cm²/m, requis p90 {r.GeneralAsH:0.00})");
        sb.AppendLine($"  Maxima requis : verticales {r.AsV.DefaultIfEmpty(0).Max():0.00} cm²/m ; horizontales {r.AsH.DefaultIfEmpty(0).Max():0.00} cm²/m par face");
        sb.AppendLine($"  Compression max de membrane ≈ {r.SigC.DefaultIfEmpty(0).Max():0.0} MPa (fcd = {fcd:0.0} MPa)");
        if (w.EHorizKn != 0) sb.AppendLine($"  Cisaillement : τ = 1,4 V/(0,9 L e) = {r.Tau:0.00} MPa ≤ 0,2 fc28 = {r.TauLim:0.00} MPa");
        if (r.Zones.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("ZONES À RENFORCER (au-delà des armatures générales)");
            int k = 1;
            foreach (var z in r.Zones)
                sb.AppendLine($"  Z{k++} : x {z.X0:0.00}-{z.X1:0.00} m, z {z.Y0:0.00}-{z.Y1:0.00} m : AsV {z.AsV:0.00}, AsH {z.AsH:0.00} cm²/m par face → vertical {z.BarsV}, horizontal {z.BarsH}");
        }
        if (r.OpeningResults.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("OUVERTURES : CHAÎNAGES ET RENFORTS (à placer en plus des barres courantes, ancrés de 50 Ø au-delà de l'ouverture)");
            foreach (var q in r.OpeningResults)
                sb.AppendLine($"  {q.Opening.Name} : chaînage vertical de chaque côté (jambage) {q.Jamb} ; linteau {q.Lintel} ; allège {q.Sill} ; angles : {q.Corners}");
        }
        sb.AppendLine();
        foreach (var x in r.Warnings) sb.AppendLine("ATTENTION : " + x);
        sb.AppendLine("Les efforts sont ceux du centre des mailles ; affiner le maillage (≤ 0,20 m) près des angles d'ouvertures pour capter les concentrations.");
        return sb.ToString();
    }
}
