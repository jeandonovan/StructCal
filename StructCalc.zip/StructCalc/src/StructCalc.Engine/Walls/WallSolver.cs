using StructCalc.Core.Model;

namespace StructCalc.Engine.Walls;

public sealed class WallElem
{
    public int I, J;                  // indices de cellule
    public int[] N = new int[4];      // numéros de nœuds (0..n-1), sens trigonométrique à partir du coin bas-gauche
    public double A, B, Xc, Yc;       // dimensions et centre
    public double Nx, Ny, Nxy, Mx, My, Mxy, Qx, Qy;      // efforts de la combinaison courante
}

/// <summary>Maillage rectangulaire d'un voile avec ouvertures : lignes de maillage alignées sur les bords des ouvertures.</summary>
public sealed class WallMesh
{
    public List<double> Xs { get; } = new();
    public List<double> Ys { get; } = new();
    public List<(double X, double Y)> Nodes { get; } = new();
    public List<WallElem> Elems { get; } = new();
    public Dictionary<(int, int), int> NodeIndex { get; } = new();

    public static WallMesh Build(WallDef w)
    {
        var m = new WallMesh();
        m.Xs.AddRange(Breaks(0, w.LengthM, w.Openings.SelectMany(o => new[] { o.XM, o.XM + o.WidthM }), w.MeshM));
        m.Ys.AddRange(Breaks(0, w.HeightM, w.Openings.SelectMany(o => new[] { o.ZM, o.ZM + o.HeightM }), w.MeshM));
        int nx = m.Xs.Count - 1, ny = m.Ys.Count - 1;
        bool Active(int i, int j)
        {
            double cx = (m.Xs[i] + m.Xs[i + 1]) / 2, cy = (m.Ys[j] + m.Ys[j + 1]) / 2;
            foreach (var o in w.Openings)
                if (cx > o.XM && cx < o.XM + o.WidthM && cy > o.ZM && cy < o.ZM + o.HeightM) return false;
            return true;
        }
        // numérotation : l'indice rapide suit la plus petite dimension (largeur de bande réduite)
        bool fastY = ny <= nx;
        var used = new bool[nx + 1, ny + 1];
        var act = new bool[nx, ny];
        for (int i = 0; i < nx; i++) for (int j = 0; j < ny; j++)
            if (act[i, j] = Active(i, j)) { used[i, j] = used[i + 1, j] = used[i + 1, j + 1] = used[i, j + 1] = true; }
        var order = new List<(int, int)>();
        if (fastY) for (int i = 0; i <= nx; i++) for (int j = 0; j <= ny; j++) { if (used[i, j]) order.Add((i, j)); }
        else for (int j = 0; j <= ny; j++) for (int i = 0; i <= nx; i++) { if (used[i, j]) order.Add((i, j)); }
        foreach (var (i, j) in order) { m.NodeIndex[(i, j)] = m.Nodes.Count; m.Nodes.Add((m.Xs[i], m.Ys[j])); }
        for (int i = 0; i < nx; i++) for (int j = 0; j < ny; j++)
            if (act[i, j])
                m.Elems.Add(new WallElem
                {
                    I = i, J = j, A = m.Xs[i + 1] - m.Xs[i], B = m.Ys[j + 1] - m.Ys[j],
                    Xc = (m.Xs[i] + m.Xs[i + 1]) / 2, Yc = (m.Ys[j] + m.Ys[j + 1]) / 2,
                    N = new[] { m.NodeIndex[(i, j)], m.NodeIndex[(i + 1, j)], m.NodeIndex[(i + 1, j + 1)], m.NodeIndex[(i, j + 1)] }
                });
        return m;
    }

    private static List<double> Breaks(double a, double b, IEnumerable<double> forced, double h)
    {
        var pts = new SortedSet<double> { Math.Round(a, 6), Math.Round(b, 6) };
        foreach (var f in forced) if (f > a + 1e-6 && f < b - 1e-6) pts.Add(Math.Round(f, 6));
        var list = pts.ToList(); var res = new List<double> { list[0] };
        for (int k = 1; k < list.Count; k++)
        {
            double len = list[k] - list[k - 1];
            int n = Math.Max(1, (int)Math.Ceiling(len / Math.Max(h, 0.05) - 1e-9));
            for (int q = 1; q <= n; q++) res.Add(list[k - 1] + len * q / n);
        }
        return res;
    }
}

public sealed class WallCaseResult
{
    public double[] U = Array.Empty<double>();                 // 5 ddl par nœud
    public (double nx, double ny, double nxy, double mx, double my, double mxy, double qx, double qy)[] Forces = Array.Empty<(double, double, double, double, double, double, double, double)>();
    public double ReactionX, ReactionY, ReactionZ;             // réactions d'appui totales (N)
    public double MaxDisp;                                      // m
}

/// <summary>Solveur élastique linéaire d'un voile : assemblage en bande, Cholesky en bande factorisé une fois, plusieurs seconds membres.</summary>
public sealed class WallSolver
{
    private readonly WallDef _w;
    public WallMesh Mesh { get; }
    private readonly double _E, _nu = 0.2, _t;
    private readonly int _n, _bw;
    private double[] _L = Array.Empty<double>();           // bande inférieure (n x (bw+1)), L[i*(bw+1) + (bw - (i-j))]
    private readonly bool[] _fixed;
    public double E => _E;
    private readonly bool _tri;                          // maillage triangulé : 2 triangles CST + DKT par maille

    public WallSolver(WallDef w, double fc28, bool triangulated = false)
    {
        _w = w; _t = w.ThicknessM; _tri = triangulated;
        _E = 11000.0 * Math.Pow(fc28, 1.0 / 3.0) * 1e6;       // module instantané (BAEL), Pa
        Mesh = WallMesh.Build(w);
        _n = Mesh.Nodes.Count * 5;
        int span = 0;
        foreach (var e in Mesh.Elems) span = Math.Max(span, e.N.Max() - e.N.Min());
        _bw = 5 * span + 4;
        _fixed = new bool[_n];
        MarkFixed();
        Factor();
    }

    private void MarkFixed()
    {
        for (int k = 0; k < Mesh.Nodes.Count; k++)
        {
            double y = Mesh.Nodes[k].Y;
            if (y < 1e-6)
            {
                _fixed[5 * k] = _fixed[5 * k + 1] = _fixed[5 * k + 2] = true;
                if (_w.Base == WallBase.Encastre) _fixed[5 * k + 3] = _fixed[5 * k + 4] = true;
            }
            if (_w.TopHeldOutOfPlane && Math.Abs(y - _w.HeightM) < 1e-6) _fixed[5 * k + 2] = true;
        }
    }

    private int Idx(int i, int j) => i * (_bw + 1) + (_bw - (i - j));    // j ≤ i

    private void Factor()
    {
        var K = new double[(long)_n * (_bw + 1)];
        foreach (var e in Mesh.Elems)
        {
            var pr = new ShellElement.Props { A = e.A, B = e.B, T = _t, E = _E, Nu = _nu };
            var ke = _tri ? ShellTri.Stiffness(pr, (e.I + e.J) % 2 == 0) : ShellElement.Stiffness(pr);
            for (int na = 0; na < 4; na++)
                for (int ca = 0; ca < 5; ca++)
                {
                    int ra = 5 * e.N[na] + ca;
                    for (int nb = 0; nb < 4; nb++)
                        for (int cb = 0; cb < 5; cb++)
                        {
                            int rb = 5 * e.N[nb] + cb;
                            if (rb > ra) continue;
                            K[Idx(ra, rb)] += ke[5 * na + ca, 5 * nb + cb];
                        }
                }
        }
        // conditions aux limites : lignes/colonnes annulées, diagonale 1
        double dmax = 0; for (int i = 0; i < _n; i++) dmax = Math.Max(dmax, K[Idx(i, i)]);
        for (int d = 0; d < _n; d++)
        {
            if (!_fixed[d]) continue;
            for (int j = Math.Max(0, d - _bw); j <= d; j++) K[Idx(d, j)] = 0;
            for (int i = d + 1; i <= Math.Min(_n - 1, d + _bw); i++) K[Idx(i, d)] = 0;
            K[Idx(d, d)] = dmax;
        }
        // Cholesky en bande
        for (int j = 0; j < _n; j++)
        {
            int i0 = Math.Max(0, j - _bw);
            double s = K[Idx(j, j)];
            for (int k = i0; k < j; k++) { double l = K[Idx(j, k)]; s -= l * l; }
            if (s <= 1e-12 * dmax) throw new InvalidOperationException("Voile instable : vérifiez les appuis et les ouvertures (partie du voile non reliée).");
            double ljj = Math.Sqrt(s); K[Idx(j, j)] = ljj;
            for (int i = j + 1; i <= Math.Min(_n - 1, j + _bw); i++)
            {
                double t = K[Idx(i, j)];
                int kk0 = Math.Max(i - _bw, 0);
                for (int k = Math.Max(kk0, i0); k < j; k++) t -= K[Idx(i, k)] * K[Idx(j, k)];
                K[Idx(i, j)] = t / ljj;
            }
        }
        _L = K;
    }

    private double[] Solve(double[] f)
    {
        var x = new double[_n];
        for (int i = 0; i < _n; i++)
        {
            double y = f[i];
            for (int k = Math.Max(0, i - _bw); k < i; k++) y -= _L[Idx(i, k)] * x[k];
            x[i] = y / _L[Idx(i, i)];
        }
        for (int i = _n - 1; i >= 0; i--)
        {
            double s = x[i];
            for (int k = i + 1; k <= Math.Min(_n - 1, i + _bw); k++) s -= _L[Idx(k, i)] * x[k];
            x[i] = s / _L[Idx(i, i)];
        }
        return x;
    }

    public WallCaseResult SolveCase(double[] F)
    {
        var f = (double[])F.Clone();
        for (int d = 0; d < _n; d++) if (_fixed[d]) f[d] = 0;
        var u = Solve(f);
        var r = new WallCaseResult { U = u, Forces = new (double, double, double, double, double, double, double, double)[Mesh.Elems.Count] };
        for (int e = 0; e < Mesh.Elems.Count; e++)
        {
            var el = Mesh.Elems[e]; var ue = new double[20];
            for (int a = 0; a < 4; a++) for (int c = 0; c < 5; c++) ue[5 * a + c] = u[5 * el.N[a] + c];
            var pr = new ShellElement.Props { A = el.A, B = el.B, T = _t, E = _E, Nu = _nu };
            r.Forces[e] = _tri ? ShellTri.Recover(pr, ue, (el.I + el.J) % 2 == 0) : ShellElement.Recover(pr, ue);
        }
        for (int k = 0; k < Mesh.Nodes.Count; k++)
            r.MaxDisp = Math.Max(r.MaxDisp, Math.Sqrt(u[5 * k] * u[5 * k] + u[5 * k + 1] * u[5 * k + 1] + u[5 * k + 2] * u[5 * k + 2]));
        return r;
    }

    // ------------------------------------------------------------------ cas de charges (vecteurs nodaux, N et N/m)
    /// <summary>Charge verticale linéique en tête (N/m, positive vers le bas) répartie sur les arêtes supérieures des éléments.</summary>
    public double[] TopLineLoad(double nPerM, bool horizontal = false)
    {
        var F = new double[_n];
        foreach (var e in Mesh.Elems)
        {
            if (Math.Abs(Mesh.Ys[e.J + 1] - _w.HeightM) > 1e-6) continue;
            double q = nPerM * e.A / 2;
            foreach (int nd in new[] { e.N[3], e.N[2] })
                if (horizontal) F[5 * nd] += q; else F[5 * nd + 1] -= q;
        }
        return F;
    }

    /// <summary>Effort horizontal total (N) dans le plan, réparti sur la longueur des arêtes supérieures.</summary>
    public double[] TopHorizontal(double totalN)
    {
        double len = 0;
        foreach (var e in Mesh.Elems) if (Math.Abs(Mesh.Ys[e.J + 1] - _w.HeightM) < 1e-6) len += e.A;
        return len <= 0 ? new double[_n] : TopLineLoad(totalN / len, true);
    }

    public double[] SelfWeightLoad(double gammaKnM3)
    {
        var F = new double[_n];
        foreach (var e in Mesh.Elems)
        {
            double q = gammaKnM3 * 1000 * _t * e.A * e.B / 4;
            foreach (int nd in e.N) F[5 * nd + 1] -= q;
        }
        return F;
    }

    /// <summary>Pression uniforme hors plan (Pa, positive vers +w).</summary>
    public double[] Pressure(double pa)
    {
        var F = new double[_n];
        foreach (var e in Mesh.Elems)
        {
            double q = pa * e.A * e.B / 4;
            foreach (int nd in e.N) F[5 * nd + 2] += q;
        }
        return F;
    }

    /// <summary>Poussée des terres hors plan (Pa) : K (γ z + q) à la profondeur z sous le niveau de terre retenue (hauteur hSoil au-dessus du pied), nulle au-dessus.</summary>
    public double[] EarthPressure(double hSoil, double gammaKnM3, double k, double surchargeKPa)
    {
        var F = new double[_n];
        foreach (var e in Mesh.Elems)
        {
            double y = e.N.Average(nd => Mesh.Nodes[nd].Y);
            if (y > hSoil) continue;
            double pa = k * (gammaKnM3 * (hSoil - y) + surchargeKPa) * 1000.0;
            double q = pa * e.A * e.B / 4;
            foreach (int nd in e.N) F[5 * nd + 2] += q;
        }
        return F;
    }

    /// <summary>Réactions d'appui (somme sur le pied) : K u − F aux nœuds bloqués ; ici calculées par équilibre global des charges appliquées.</summary>
    public static (double fx, double fy, double fz) TotalLoad(double[] F, int nNodes)
    {
        double fx = 0, fy = 0, fz = 0;
        for (int k = 0; k < nNodes; k++) { fx += F[5 * k]; fy += F[5 * k + 1]; fz += F[5 * k + 2]; }
        return (fx, fy, fz);
    }
}
