namespace StructCalc.Engine.Walls;

/// <summary>Élément fini de coque plane rectangulaire à 4 nœuds, 5 ddl par nœud (u, v, w, φx, φy) :
/// membrane Q4 à modes incompatibles (Wilson QM6) + plaque de Mindlin MITC4 (Bathe-Dvorkin), dans le plan du voile (x horizontal, y vertical).
/// Validé contre : plaque appuyée de Navier (flèche centrale) et console courte (Timoshenko).</summary>
public static class ShellElement
{
    private static readonly double G = 1.0 / Math.Sqrt(3.0);
    private static readonly double[][] GP = { new[] { -G, -G }, new[] { G, -G }, new[] { G, G }, new[] { -G, G } };
    private static readonly int[] SX = { -1, 1, 1, -1 };
    private static readonly int[] SY = { -1, -1, 1, 1 };

    private static double Ni(int i, double xi, double eta) => (1 + SX[i] * xi) * (1 + SY[i] * eta) / 4.0;
    private static double DNxi(int i, double eta) => SX[i] * (1 + SY[i] * eta) / 4.0;
    private static double DNeta(int i, double xi) => SY[i] * (1 + SX[i] * xi) / 4.0;

    public sealed class Props
    {
        public double A, B, T, E, Nu, Ks = 5.0 / 6.0;
    }

    /// <summary>Matrice de rigidité 20x20 (ddl nœud i : 5i+0 u, 5i+1 v, 5i+2 w, 5i+3 φx, 5i+4 φy).</summary>
    public static double[,] Stiffness(Props p)
    {
        var K = new double[20, 20];
        var km = Membrane(p);
        var kp = Plate(p);
        for (int i = 0; i < 4; i++)
            for (int c = 0; c < 2; c++)
                for (int j = 0; j < 4; j++)
                    for (int d = 0; d < 2; d++)
                        K[5 * i + c, 5 * j + d] += km[2 * i + c, 2 * j + d];
        for (int i = 0; i < 4; i++)
            for (int c = 0; c < 3; c++)
                for (int j = 0; j < 4; j++)
                    for (int d = 0; d < 3; d++)
                        K[5 * i + 2 + c, 5 * j + 2 + d] += kp[3 * i + c, 3 * j + d];
        return K;
    }

    private static double[,] Membrane(Props p)
    {
        double a = p.A, b = p.B, t = p.T, E = p.E, nu = p.Nu;
        double c0 = E * t / (1 - nu * nu);
        double[,] D = { { c0, c0 * nu, 0 }, { c0 * nu, c0, 0 }, { 0, 0, c0 * (1 - nu) / 2 } };
        double jx = a / 2, jy = b / 2, det = jx * jy;
        var Kuu = new double[8, 8]; var Kua = new double[8, 4]; var Kaa = new double[4, 4];
        foreach (var g in GP)
        {
            double xi = g[0], eta = g[1];
            var B = new double[3, 8];
            for (int i = 0; i < 4; i++)
            {
                double dx = DNxi(i, eta) / jx, dy = DNeta(i, xi) / jy;
                B[0, 2 * i] = dx; B[1, 2 * i + 1] = dy; B[2, 2 * i] = dy; B[2, 2 * i + 1] = dx;
            }
            // modes incompatibles (1-ξ²) et (1-η²) pour u et v
            double d1x = -2 * xi / jx, d2y = -2 * eta / jy;
            var Bi = new double[3, 4];
            // colonnes : [u:φ1, u:φ2, v:φ1, v:φ2]
            Bi[0, 0] = d1x; Bi[0, 1] = 0; Bi[1, 2] = 0; Bi[1, 3] = d2y;
            Bi[2, 0] = 0; Bi[2, 1] = d2y; Bi[2, 2] = d1x; Bi[2, 3] = 0;
            var DB = Mul(D, B); var DBi = Mul(D, Bi);
            AddScaled(Kuu, MulTA(B, DB), det);
            AddScaled(Kua, MulTA(B, DBi), det);
            AddScaled(Kaa, MulTA(Bi, DBi), det);
        }
        // condensation statique : Kuu - Kua Kaa^-1 Kua^T
        var X = SolveSym(Kaa, Transpose(Kua));           // 4 x 8
        var corr = Mul(Kua, X);
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) Kuu[i, j] -= corr[i, j];
        return Kuu;
    }

    private static double[,] Plate(Props p)
    {
        double a = p.A, b = p.B, h = p.T, E = p.E, nu = p.Nu;
        double db = E * h * h * h / (12 * (1 - nu * nu));
        double[,] Db = { { db, db * nu, 0 }, { db * nu, db, 0 }, { 0, 0, db * (1 - nu) / 2 } };
        double Gm = E / (2 * (1 + nu)), Ds = p.Ks * Gm * h;
        double jx = a / 2, jy = b / 2, det = jx * jy;
        var K = new double[12, 12];
        foreach (var g in GP)
        {
            double xi = g[0], eta = g[1];
            var B = new double[3, 12];
            for (int i = 0; i < 4; i++)
            {
                double dx = DNxi(i, eta) / jx, dy = DNeta(i, xi) / jy;
                B[0, 3 * i + 1] = dx; B[1, 3 * i + 2] = dy; B[2, 3 * i + 1] = dy; B[2, 3 * i + 2] = dx;
            }
            AddScaled(K, MulTA(B, Mul(Db, B)), det);
        }
        foreach (var g in GP)
        {
            var Bs = ShearB(jx, jy, g[0], g[1]);
            AddScaled(K, MulTA(Bs, Bs), Ds * det);
        }
        return K;
    }

    /// <summary>B de cisaillement MITC4 (2 x 12) au point (ξ, η) : [γx; γy] = Bs · [w φx φy]ᵢ.</summary>
    private static double[,] ShearB(double jx, double jy, double xi, double eta)
    {
        var gA = CovXi(jx, 0, 1); var gB = CovXi(jx, 0, -1);
        var gC = CovEta(jy, 1, 0); var gD = CovEta(jy, -1, 0);
        var Bs = new double[2, 12];
        for (int k = 0; k < 12; k++)
        {
            double bxi = 0.5 * (1 + eta) * gA[k] + 0.5 * (1 - eta) * gB[k];
            double beta = 0.5 * (1 + xi) * gC[k] + 0.5 * (1 - xi) * gD[k];
            Bs[0, k] = bxi / jx;              // J = diag(jx, jy) pour un rectangle
            Bs[1, k] = beta / jy;
        }
        return Bs;
    }

    private static double[] CovXi(double jx, double xi, double eta)
    {
        var r = new double[12];
        for (int i = 0; i < 4; i++) { r[3 * i] = DNxi(i, eta); r[3 * i + 1] = jx * Ni(i, xi, eta); r[3 * i + 2] = 0; }
        return r;
    }

    private static double[] CovEta(double jy, double xi, double eta)
    {
        var r = new double[12];
        for (int i = 0; i < 4; i++) { r[3 * i] = DNeta(i, xi); r[3 * i + 1] = 0; r[3 * i + 2] = jy * Ni(i, xi, eta); }
        return r;
    }

    /// <summary>Efforts au centre de l'élément. n en N/m, m en N.m/m, q en N/m. <paramref name="u"/> : 20 déplacements locaux.</summary>
    public static (double nx, double ny, double nxy, double mx, double my, double mxy, double qx, double qy) Recover(Props p, double[] u)
    {
        double a = p.A, b = p.B, t = p.T, E = p.E, nu = p.Nu;
        double jx = a / 2, jy = b / 2;
        double exx = 0, eyy = 0, gxy = 0, kx = 0, ky = 0, kxy = 0;
        for (int i = 0; i < 4; i++)
        {
            double dx = DNxi(i, 0) / jx, dy = DNeta(i, 0) / jy;
            double ui = u[5 * i], vi = u[5 * i + 1], px = u[5 * i + 3], py = u[5 * i + 4];
            exx += dx * ui; eyy += dy * vi; gxy += dy * ui + dx * vi;
            kx += dx * px; ky += dy * py; kxy += dy * px + dx * py;
        }
        double c0 = E * t / (1 - nu * nu);
        double db = E * t * t * t / (12 * (1 - nu * nu));
        double nx = c0 * (exx + nu * eyy), ny = c0 * (nu * exx + eyy), nxy = c0 * (1 - nu) / 2 * gxy;
        double mx = db * (kx + nu * ky), my = db * (nu * kx + ky), mxy = db * (1 - nu) / 2 * kxy;
        var Bs = ShearB(jx, jy, 0, 0);
        double gx = 0, gy = 0;
        for (int i = 0; i < 4; i++)
            for (int c = 0; c < 3; c++)
            {
                double d = u[5 * i + 2 + c];
                gx += Bs[0, 3 * i + c] * d; gy += Bs[1, 3 * i + c] * d;
            }
        double ds = p.Ks * E / (2 * (1 + nu)) * t;
        return (nx, ny, nxy, mx, my, mxy, ds * gx, ds * gy);
    }

    // ----------------------------------------------------------------- petite algèbre dense
    private static double[,] Mul(double[,] A, double[,] B)
    {
        int n = A.GetLength(0), m = A.GetLength(1), p = B.GetLength(1);
        var C = new double[n, p];
        for (int i = 0; i < n; i++)
            for (int k = 0; k < m; k++)
            {
                double a = A[i, k]; if (a == 0) continue;
                for (int j = 0; j < p; j++) C[i, j] += a * B[k, j];
            }
        return C;
    }

    /// <summary>Aᵀ · B.</summary>
    private static double[,] MulTA(double[,] A, double[,] B)
    {
        int m = A.GetLength(0), n = A.GetLength(1), p = B.GetLength(1);
        var C = new double[n, p];
        for (int k = 0; k < m; k++)
            for (int i = 0; i < n; i++)
            {
                double a = A[k, i]; if (a == 0) continue;
                for (int j = 0; j < p; j++) C[i, j] += a * B[k, j];
            }
        return C;
    }

    private static double[,] Transpose(double[,] A)
    {
        int n = A.GetLength(0), m = A.GetLength(1);
        var T = new double[m, n];
        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) T[j, i] = A[i, j];
        return T;
    }

    private static void AddScaled(double[,] A, double[,] B, double s)
    {
        int n = A.GetLength(0), m = A.GetLength(1);
        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) A[i, j] += s * B[i, j];
    }

    /// <summary>Résout A X = B (A carrée petite) par élimination de Gauss avec pivot partiel.</summary>
    private static double[,] SolveSym(double[,] A0, double[,] B0)
    {
        int n = A0.GetLength(0), m = B0.GetLength(1);
        var A = (double[,])A0.Clone(); var B = (double[,])B0.Clone();
        for (int c = 0; c < n; c++)
        {
            int piv = c; double best = Math.Abs(A[c, c]);
            for (int r = c + 1; r < n; r++) if (Math.Abs(A[r, c]) > best) { best = Math.Abs(A[r, c]); piv = r; }
            if (best < 1e-30) throw new InvalidOperationException("Élément dégénéré.");
            if (piv != c)
            {
                for (int j = 0; j < n; j++) (A[c, j], A[piv, j]) = (A[piv, j], A[c, j]);
                for (int j = 0; j < m; j++) (B[c, j], B[piv, j]) = (B[piv, j], B[c, j]);
            }
            for (int r = c + 1; r < n; r++)
            {
                double f = A[r, c] / A[c, c]; if (f == 0) continue;
                for (int j = c; j < n; j++) A[r, j] -= f * A[c, j];
                for (int j = 0; j < m; j++) B[r, j] -= f * B[c, j];
            }
        }
        var X = new double[n, m];
        for (int j = 0; j < m; j++)
            for (int i = n - 1; i >= 0; i--)
            {
                double s = B[i, j];
                for (int k = i + 1; k < n; k++) s -= A[i, k] * X[k, j];
                X[i, j] = s / A[i, i];
            }
        return X;
    }
}
