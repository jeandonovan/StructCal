using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Recalage d'une dalle sur les axes des poutres qui la bordent. Une dalle dessinée (ou importée de Revit) sur les faces intérieures des poutres
/// a ses bords décalés d'une demi-largeur de poutre : les poutres ne seraient pas reconnues comme appuis. Les charges sont alors reportées sur les axes
/// (portées entre axes, usage courant en descente de charges) ; la dalle elle-même n'est pas modifiée.</summary>
public static class SlabSnap
{
    private const double Tol = 2e-3, Slack = 0.02, MinCover = 0.5;

    private sealed record BeamSeg(bool AlongY, double Pos, double Lo, double Hi, double Half);

    /// <summary>Emprise (x0, x1, y0, y1) de la dalle recalée sur les axes de poutres, ou son emprise propre si aucune poutre ne la borde de près.</summary>
    public static (double X0, double X1, double Y0, double Y1) Extent(StructModel m, SlabPanel s)
    {
        double x0 = s.X0, x1 = s.X0 + s.Lx, y0 = s.Y0, y1 = s.Y0 + s.Ly;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var segs = new List<BeamSeg>();
        foreach (var mem in m.Members)
        {
            if (mem.Type == MemberType.Column) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            if (Math.Abs(a.Z - s.Z) > Tol || Math.Abs(b.Z - s.Z) > Tol) continue;
            double w = Math.Max(mem.B, mem.H);
            double half = (w > 0.05 ? w : 0.30) / 2;
            if (Math.Abs(a.X - b.X) < Tol && Math.Abs(a.Y - b.Y) > Tol) segs.Add(new BeamSeg(true, a.X, Math.Min(a.Y, b.Y), Math.Max(a.Y, b.Y), half));
            else if (Math.Abs(a.Y - b.Y) < Tol && Math.Abs(a.X - b.X) > Tol) segs.Add(new BeamSeg(false, a.Y, Math.Min(a.X, b.X), Math.Max(a.X, b.X), half));
        }
        if (segs.Count == 0) return (x0, x1, y0, y1);
        double nx0 = Snap(segs, true, x0, y0, y1), nx1 = Snap(segs, true, x1, y0, y1);
        double ny0 = Snap(segs, false, y0, x0, x1), ny1 = Snap(segs, false, y1, x0, x1);
        return (nx0, nx1, ny0, ny1);
    }

    /// <summary>Position de l'axe de poutre le plus proche de <paramref name="edge"/> (de part et d'autre), à moins d'une demi-largeur de poutre.</summary>
    private static double Snap(List<BeamSeg> segs, bool alongY, double edge, double perpLo, double perpHi)
    {
        double need = MinCover * (perpHi - perpLo), best = edge, bestD = double.MaxValue;
        foreach (var grp in segs.Where(t => t.AlongY == alongY).GroupBy(t => Math.Round(t.Pos / Tol)))
        {
            double pos = grp.Average(t => t.Pos), half = grp.Max(t => t.Half);
            double d = Math.Abs(pos - edge);                      // dalle sur la face intérieure OU extérieure de la poutre
            if (d > half + Slack) continue;
            double covered = 0, cur = perpLo;
            foreach (var iv in grp.OrderBy(t => t.Lo))
            {
                double a = Math.Max(Math.Max(iv.Lo, perpLo), cur), b = Math.Min(iv.Hi, perpHi);
                if (b > a) { covered += b - a; cur = b; }
            }
            if (covered < need) continue;
            if (d < bestD) { bestD = d; best = pos; }
        }
        return best;
    }
}
