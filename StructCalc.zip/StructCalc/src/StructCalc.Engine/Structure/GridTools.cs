using System.Globalization;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Outils de définition des axes (grille) et des étages, façon « Robot » : travées saisies en texte, génération d'étages,
/// duplication d'un étage type, et génération automatique de l'ossature à partir de la grille et des niveaux.</summary>
public static class GridTools
{
    /// <summary>Lit une suite de travées : « 3x5 4.5 2x3.2 » = 5, 5, 5, 4.5, 3.2, 3.2. Séparateurs : espace, point-virgule ; la virgule est un séparateur décimal.</summary>
    public static List<double> ParseSpacings(string text, out string error)
    {
        error = "";
        var res = new List<double>();
        if (string.IsNullOrWhiteSpace(text)) return res;
        var parts = text.Split(new[] { ' ', ';', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (var raw in parts)
        {
            string p = raw.Replace(',', '.');
            int count = 1; string num = p;
            int x = p.IndexOfAny(new[] { 'x', 'X', '*' });
            if (x > 0)
            {
                if (!int.TryParse(p.Substring(0, x), NumberStyles.Integer, CultureInfo.InvariantCulture, out count) || count < 1 || count > 200)
                { error = $"« {raw} » : le nombre de travées avant « x » est incorrect."; return new List<double>(); }
                num = p.Substring(x + 1);
            }
            if (!double.TryParse(num, NumberStyles.Float, CultureInfo.InvariantCulture, out double v) || v <= 0.0001 || v > 1000)
            { error = $"« {raw} » : portée incorrecte (elle doit être > 0, en mètres)."; return new List<double>(); }
            for (int i = 0; i < count; i++) res.Add(v);
        }
        return res;
    }

    /// <summary>Axes à partir d'une origine et de travées. numbered = 1, 2, 3... sinon A, B, C...</summary>
    public static List<AxisDef> BuildAxes(double origin, IReadOnlyList<double> spacings, bool numbered, int firstIndex = 0, string prefix = "")
    {
        var res = new List<AxisDef>();
        double pos = origin;
        for (int i = 0; i <= spacings.Count; i++)
        {
            if (i > 0) pos += spacings[i - 1];
            int idx = firstIndex + i;
            string name = prefix + (numbered ? (idx + 1).ToString(CultureInfo.InvariantCulture) : StructureAnalyzer.AlphaName(idx));
            res.Add(new AxisDef { Name = name, Pos = Math.Round(pos, 4) });
        }
        return res;
    }

    /// <summary>Texte des travées d'une liste d'axes, regroupées (« 3x5 4.5 »), pour réafficher une grille existante dans la fenêtre.</summary>
    public static string SpacingText(IReadOnlyList<AxisDef> axes)
    {
        var sp = new List<double>();
        var s = axes.OrderBy(a => a.Pos).ToList();
        for (int i = 1; i < s.Count; i++) sp.Add(Math.Round(s[i].Pos - s[i - 1].Pos, 4));
        var parts = new List<string>();
        for (int i = 0; i < sp.Count;)
        {
            int j = i;
            while (j + 1 < sp.Count && Math.Abs(sp[j + 1] - sp[i]) < 1e-6) j++;
            int n = j - i + 1;
            string v = sp[i].ToString("0.####", CultureInfo.InvariantCulture);
            parts.Add(n > 1 ? $"{n}x{v}" : v);
            i = j + 1;
        }
        return string.Join(" ", parts);
    }

    /// <summary>Étages réguliers : le niveau 0 (« Base ») à baseZ, puis n niveaux de hauteur h (le dernier nommé « Terrasse » si demandé).</summary>
    public static List<StoreyDef> GenerateStoreys(int count, double baseZ, IReadOnlyList<double> heights, bool lastIsRoof = true)
    {
        var res = new List<StoreyDef> { new() { Name = "Base", Elevation = Math.Round(baseZ, 4) } };
        double z = baseZ;
        for (int i = 1; i <= count; i++)
        {
            double h = heights.Count == 0 ? 3.0 : heights[Math.Min(i - 1, heights.Count - 1)];
            z += h;
            string name = i == count && lastIsRoof && count > 1 ? "Terrasse" : $"Niveau {i}";
            res.Add(new StoreyDef { Name = name, Elevation = Math.Round(z, 4) });
        }
        return res;
    }

    // ------------------------------------------------------------------ ossature depuis la grille
    public sealed class FrameOptions
    {
        public double ColumnB { get; set; } = 0.30;
        public double ColumnH { get; set; } = 0.30;
        public double BeamB { get; set; } = 0.25;
        public double BeamH { get; set; } = 0.45;
        public bool Steel { get; set; }
        public string ColumnProfile { get; set; } = "HEA240";
        public string BeamProfile { get; set; } = "IPE300";
        public bool BeamsAlongX { get; set; } = true;       // poutres parallèles à X (le long des axes lettrés)
        public bool BeamsAlongY { get; set; } = true;
        public bool SupportsAtBase { get; set; } = true;
        public bool FixedSupports { get; set; } = true;
        public bool BeamsOnBaseLevel { get; set; } = false; // longrines au niveau de base
        public double G { get; set; }                       // charge permanente sur chaque poutre créée (kN/m), 0 = aucune
        public double Q { get; set; }                       // charge d'exploitation (kN/m)
    }

    public sealed record FrameResult(int NewNodes, int NewColumns, int NewBeams, int NewSupports);

    /// <summary>Crée poteaux (à chaque intersection d'axes, entre niveaux consécutifs), poutres (le long des axes à chaque niveau supérieur) et appuis à la base.
    /// Ne duplique jamais un nœud ou une barre existants.</summary>
    public static FrameResult GenerateFrame(StructModel m, FrameOptions o)
    {
        var levels = m.Levels.OrderBy(l => l.Elevation).Select(l => l.Elevation).ToList();
        var xs = m.Grid.XAxes.OrderBy(a => a.Pos).Select(a => a.Pos).ToList();
        var ys = m.Grid.YAxes.OrderBy(a => a.Pos).Select(a => a.Pos).ToList();
        if (levels.Count < 2 || xs.Count == 0 || ys.Count == 0) return new FrameResult(0, 0, 0, 0);

        int nn = 0, nc = 0, nb = 0, ns = 0;
        int nextNode = m.Nodes.Count == 0 ? 1 : m.Nodes.Max(n => n.Id) + 1;
        int nextMem = m.Members.Count == 0 ? 1 : m.Members.Max(n => n.Id) + 1;
        var byPos = new Dictionary<(long, long, long), int>();
        foreach (var n in m.Nodes) byPos[Key(n.X, n.Y, n.Z)] = n.Id;

        int GetNode(double x, double y, double z)
        {
            var k = Key(x, y, z);
            if (byPos.TryGetValue(k, out int id)) return id;
            id = nextNode++;
            m.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
            byPos[k] = id; nn++;
            return id;
        }
        var memberKeys = new HashSet<(int, int)>();
        foreach (var mm in m.Members) { memberKeys.Add((Math.Min(mm.NodeI, mm.NodeJ), Math.Max(mm.NodeI, mm.NodeJ))); }
        void Add(int a, int b, bool column)
        {
            var k = (Math.Min(a, b), Math.Max(a, b));
            if (a == b || !memberKeys.Add(k)) return;
            var mem = new Member
            {
                Id = nextMem++, NodeI = a, NodeJ = b,
                Type = column ? MemberType.Column : MemberType.Beam,
                Kind = o.Steel ? MaterialKind.Steel : MaterialKind.ReinforcedConcrete,
                B = column ? o.ColumnB : o.BeamB, H = column ? o.ColumnH : o.BeamH,
                Cover = (column ? m.Settings.CoverColumnCm : m.Settings.CoverBeamCm) / 100.0,
                CoverNomCm = column ? m.Settings.CoverNomColumnCm : m.Settings.CoverNomBeamCm,
                Profile = o.Steel ? (column ? o.ColumnProfile : o.BeamProfile) : "",
                LfFactor = o.Steel ? 1.0 : (column ? 0.7 : 1.0),
            };
            m.Members.Add(mem);
            if (column) nc++;
            else
            {
                nb++;
                if (o.G > 0) m.MemberLoads.Add(new MemberLoad { MemberId = mem.Id, Case = ActionType.G, Wz = -o.G });
                if (o.Q > 0) m.MemberLoads.Add(new MemberLoad { MemberId = mem.Id, Case = ActionType.Q, Wz = -o.Q });
            }
        }

        for (int k = 0; k < levels.Count; k++)
        {
            double z = levels[k];
            foreach (double x in xs)
                foreach (double y in ys)
                {
                    int top = GetNode(x, y, z);
                    if (k > 0) { int bot = GetNode(x, y, levels[k - 1]); Add(bot, top, true); }
                    if (k == 0 && o.SupportsAtBase && !m.Supports.Any(s => s.NodeId == top))
                    {
                        m.Supports.Add(o.FixedSupports ? new SupportDef { NodeId = top } : new SupportDef { NodeId = top, Rx = false, Ry = false, Rz = false });
                        ns++;
                    }
                }
            if (k == 0 && !o.BeamsOnBaseLevel) continue;
            if (o.BeamsAlongX)
                foreach (double y in ys)
                    for (int i = 0; i + 1 < xs.Count; i++) Add(GetNode(xs[i], y, z), GetNode(xs[i + 1], y, z), false);
            if (o.BeamsAlongY)
                foreach (double x in xs)
                    for (int j = 0; j + 1 < ys.Count; j++) Add(GetNode(x, ys[j], z), GetNode(x, ys[j + 1], z), false);
        }
        return new FrameResult(nn, nc, nb, ns);
    }

    private static (long, long, long) Key(double x, double y, double z) =>
        ((long)Math.Round(x * 1000), (long)Math.Round(y * 1000), (long)Math.Round(z * 1000));

    // ------------------------------------------------------------------ étage type dupliqué vers le haut
    /// <summary>Duplique un étage type (poutres du niveau + poteaux situés sous ce niveau) count fois au-dessus du dernier niveau.
    /// Ajoute aussi les niveaux correspondants dans la liste d'étages. Retourne (barres ajoutées, niveaux ajoutés).</summary>
    public static (int Members, int Levels) DuplicateTypicalStorey(StructModel m, int levelIndex, int count)
    {
        var info = StructureAnalyzer.Analyze(m);
        if (levelIndex < 1 || levelIndex >= info.Levels.Count || count < 1) return (0, 0);
        var low = info.Levels[levelIndex - 1]; var typ = info.Levels[levelIndex];
        double h = typ.Z - low.Z;
        if (h < 0.3) return (0, 0);
        double zTop = info.Levels[^1].Z;
        var srcMembers = typ.BeamIds.Concat(typ.ColumnIds).ToList();
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        int nextNode = m.Nodes.Max(n => n.Id) + 1, nextMem = m.Members.Count == 0 ? 1 : m.Members.Max(n => n.Id) + 1;
        var byPos = new Dictionary<(long, long, long), int>();
        foreach (var n in m.Nodes) byPos[Key(n.X, n.Y, n.Z)] = n.Id;
        int GetNode(double x, double y, double z)
        {
            var k = Key(x, y, z);
            if (byPos.TryGetValue(k, out int id)) return id;
            id = nextNode++;
            m.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
            byPos[k] = id;
            return id;
        }
        var existing = new HashSet<(int, int)>(m.Members.Select(q => (Math.Min(q.NodeI, q.NodeJ), Math.Max(q.NodeI, q.NodeJ))));
        int added = 0;
        for (int c = 1; c <= count; c++)
        {
            double dz = (zTop - low.Z) + (c - 1) * h;
            foreach (int id in srcMembers)
            {
                var src = m.Members.First(q => q.Id == id);
                var a = nodes[src.NodeI]; var b = nodes[src.NodeJ];
                int na = GetNode(a.X, a.Y, a.Z + dz), nb2 = GetNode(b.X, b.Y, b.Z + dz);
                if (!existing.Add((Math.Min(na, nb2), Math.Max(na, nb2)))) continue;
                int newId = nextMem++;
                m.Members.Add(new Member
                {
                    Id = newId, NodeI = na, NodeJ = nb2, Type = src.Type, Kind = src.Kind, B = src.B, H = src.H, Cover = src.Cover,
                    LfFactor = src.LfFactor, Crack = src.Crack, PropA = src.PropA, PropIy = src.PropIy, PropIz = src.PropIz, PropJ = src.PropJ, Profile = src.Profile
                });
                foreach (var l in m.MemberLoads.Where(q => q.MemberId == id).ToList()) m.MemberLoads.Add(l.Clone(newId));
                added++;
            }
            foreach (var sl in m.SurfaceLoads.Where(q => Math.Abs(q.Z - typ.Z) < 0.05).ToList())
                m.SurfaceLoads.Add(new SurfaceLoad { Name = sl.Name, Case = sl.Case, Q = sl.Q, Distribution = sl.Distribution, Z = Math.Round(sl.Z + dz, 6), X0 = sl.X0, X1 = sl.X1, Y0 = sl.Y0, Y1 = sl.Y1 });
        }
        int addedLevels = 0;
        if (m.Levels.Count > 0)
        {
            for (int c = 1; c <= count; c++) m.Levels.Add(new StoreyDef { Name = $"Niveau {m.Levels.Count}", Elevation = Math.Round(zTop + c * h, 4) });
            addedLevels = count;
        }
        return (added, addedLevels);
    }
}
