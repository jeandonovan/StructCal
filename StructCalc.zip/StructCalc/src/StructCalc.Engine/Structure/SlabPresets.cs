﻿using StructCalc.Core.Model;
using StructCalc.Engine.Floors;

namespace StructCalc.Engine.Structure;

/// <summary>Valeurs par défaut par type de dalle : épaisseur totale, poids propre équivalent (γ x h), part de béton et sens de portée usuel.</summary>
public static class SlabPresets
{
    public static string Name(SlabKind k) => k switch
    {
        SlabKind.CorpsCreux => "Plancher à corps creux (poutrelles + hourdis)",
        SlabKind.Predalle => "Prédalle + dalle de compression",
        SlabKind.Alveolee => "Dalle alvéolée précontrainte",
        SlabKind.Champignon => "Dalle champignon (plancher-dalle sans poutre)",
        SlabKind.Mixte => "Dalle mixte (bac acier collaborant)",
        _ => "Dalle pleine"
    };

    public static string Hint(SlabKind k) => k switch
    {
        SlabKind.CorpsCreux => "Portée dans le sens des poutrelles : les charges vont sur les poutres perpendiculaires. Poids du plancher selon le tableau usuel (hourdis + dalle de compression).",
        SlabKind.Predalle => "Prédalle préfabriquée (5 cm) + béton coulé en place : se comporte comme une dalle pleine monolithique, portant dans un ou deux sens.",
        SlabKind.Alveolee => "Éléments précontraints posés dans un sens : portée selon le sens des alvéoles. Les armatures sont fournies par le fabricant (pas de ferraillage calculé).",
        SlabKind.Champignon => "Plancher-dalle porté directement par les poteaux (chapiteaux). Dans le modèle barres, les charges sont reprises par les poutres ou bandes de rive que vous dessinez.",
        SlabKind.Mixte => "Bac acier collaborant et béton en place : portée dans le sens des nervures. Le poids du bac est compris dans le poids propre.",
        _ => "Dalle rectangulaire en béton armé, portant dans un ou deux sens selon Lx/Ly."
    };

    /// <summary>Sens de portée par défaut du type.</summary>
    public static SlabCalcMode DefaultMode(SlabKind k) => k switch
    {
        SlabKind.CorpsCreux or SlabKind.Alveolee or SlabKind.Mixte => SlabCalcMode.OneWayX,
        _ => SlabCalcMode.Bidirectional
    };

    public static double DefaultThicknessCm(SlabKind k) => k switch
    {
        SlabKind.CorpsCreux => 20, SlabKind.Predalle => 20, SlabKind.Alveolee => 20, SlabKind.Champignon => 22, SlabKind.Mixte => 13, _ => 16
    };

    /// <summary>Recalcule épaisseur totale H, poids volumique équivalent Gamma et part de béton à partir du type et de ses paramètres
    /// (corps creux : HourdisCm et ToppingCm ; autres types : H déjà saisi ; dalle pleine : Gamma conservé).</summary>
    public static void Apply(SlabPanel s)
    {
        switch (s.Kind)
        {
            case SlabKind.CorpsCreux:
            {
                if (s.HourdisCm <= 0) s.HourdisCm = 16;
                if (s.ToppingCm <= 0) s.ToppingCm = 4;
                s.H = (s.HourdisCm + s.ToppingCm) / 100.0;
                double sw = RibbedFloorDesigner.SelfWeight(s.HourdisCm, s.ToppingCm);       // kN/m² du tableau usuel
                s.Gamma = sw / s.H;
                const double web = 0.10, spacing = 0.65;                                    // nervure 10 cm, entraxe 65 cm
                s.VolumeFactor = (s.ToppingCm / 100.0 + web / spacing * s.HourdisCm / 100.0) / s.H;
                break;
            }
            case SlabKind.Alveolee:
                s.VolumeFactor = 0.55; s.Gamma = 25 * s.VolumeFactor; break;
            case SlabKind.Mixte:
                s.VolumeFactor = 0.72; s.Gamma = (0.72 * 25 * s.H + 0.15) / s.H; break;       // béton entre nervures + bac (0,15 kN/m²)
            case SlabKind.Predalle:
            case SlabKind.Champignon:
            case SlabKind.Pleine:
            default:
                s.VolumeFactor = 1; if (s.Gamma < 1) s.Gamma = 25; break;
        }
        if (s.Kind != SlabKind.CorpsCreux) { s.HourdisCm = 0; s.ToppingCm = 0; }
    }

    /// <summary>Le type est dimensionné comme une dalle pleine par le moteur (armatures calculées) ; les autres ne sont pris en compte que pour les charges et le métré.</summary>
    public static bool DesignedAsSolid(SlabKind k) => k is SlabKind.Pleine or SlabKind.Predalle or SlabKind.Champignon;
}
