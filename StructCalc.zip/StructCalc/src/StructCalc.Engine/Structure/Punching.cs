using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Résultat de la vérification au poinçonnement d'un poteau en béton armé qui porte directement une dalle (sans poutre).</summary>
public sealed class PunchingResult
{
    public string Column = "", Slab = "", Position = "", Rule = "";
    public double X, Y, Z;
    public double VEd, Beta, D, U0, U1, Util, UtilMax;
    public double StressEd, StressRdc, StressRdMax;           // MPa (EC2)
    public double AswCm2 = 0;                                  // armatures de poinçonnement par périmètre (cm²), 0 = non requises
    public bool NeedsShear, Ok = true;
    public string Text = "";
}

/// <summary>Poinçonnement des dalles sur les poteaux (appuis directs, plancher-dalle ou champignon) : charge reprise par zone d'influence, périmètre
/// critique selon la position (intérieur, rive, angle), EC2 6.4 (vRd,c, vRd,max, armatures) ou BAEL A.5.2,42.</summary>
public static class Punching
{
    private const double Tol = 2e-3;

    public static List<PunchingResult> Check(StructModel m, AnalysisOutput? output = null)
    {
        var res = new List<PunchingResult>();
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var cols = m.Members.Where(x => x.Type == MemberType.Column && x.Kind == MaterialKind.ReinforcedConcrete).ToList();
        if (cols.Count == 0) return res;
        var beams = m.Members.Where(x => x.Type != MemberType.Column).ToList();
        bool ec2 = m.RcCodeId is "EC2" or "EC8";

        foreach (var s in m.Slabs.Where(q => q.Placed && SlabPresets.DesignedAsSolid(q.Kind) && q.CalcMode != SlabCalcMode.MassOnly))
        {
            double x0 = s.X0, x1 = s.X0 + s.Lx, y0 = s.Y0, y1 = s.Y0 + s.Ly;
            // poteaux (par nœud) situés au niveau de la dalle et dans son emprise
            var sup = new List<(Member Col, Node N)>();
            foreach (var c in cols)
                foreach (int id in new[] { c.NodeI, c.NodeJ })
                    if (nodes.TryGetValue(id, out var n) && Math.Abs(n.Z - s.Z) < Tol && n.X >= x0 - Tol && n.X <= x1 + Tol && n.Y >= y0 - Tol && n.Y <= y1 + Tol
                        && !sup.Any(t => t.N.Id == n.Id))
                        sup.Add((c, n));
            if (sup.Count == 0) continue;
            var xs = Distinct(sup.Select(t => t.N.X)); var ys = Distinct(sup.Select(t => t.N.Y));
            double p = 1.35 * (s.SelfWeightKnM2 + s.GExtra) + 1.5 * s.Q;
            double cover = (s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm) / 100.0;
            double dSlab = Math.Max(0.05, s.H - Math.Max(cover, 0.02) - 0.01);
            double dCap = Math.Max(0.05, s.H + Math.Max(0, s.CapitalExtraCm) / 100.0 - Math.Max(cover, 0.02) - 0.01);
            // taux d'armatures tendues réel sur appui : ρl = √(ρlx ρly) d'après les aciers sur appuis calculés de la dalle (plafonné à 2 %)
            double rhoL = 0.005; string rhoNote = " ; valeur par défaut : dalle non calculée";
            var sres = output?.Slabs.FirstOrDefault(q => q.Element.StartsWith("Dalle " + s.Name + " ") || q.Element.StartsWith("Dalle " + s.Name + "("));
            if (sres != null && sres.Values.TryGetValue("Asx_appui_cm2m", out double asx) && sres.Values.TryGetValue("Asy_appui_cm2m", out double asy) && asx > 0 && asy > 0)
            {
                double rx = asx / (100.0 * dSlab * 100.0), ry = asy / (100.0 * dSlab * 100.0);
                rhoL = Math.Min(Math.Sqrt(rx * ry), 0.02); rhoNote = $" = √(ρlx ρly) avec As,appui = {asx:0.0} et {asy:0.0} cm²/m";
            }

            foreach (var (col, n) in sup)
            {
                // appui direct seulement : aucune poutre n'arrive à ce nœud
                bool hasBeam = beams.Any(bm => bm.NodeI == n.Id || bm.NodeJ == n.Id);
                if (hasBeam) continue;

                int ix = xs.FindIndex(q => Math.Abs(q - n.X) < Tol), iy = ys.FindIndex(q => Math.Abs(q - n.Y) < Tol);
                double left = ix > 0 ? (n.X - xs[ix - 1]) / 2 : Math.Max(0, n.X - x0);
                double right = ix < xs.Count - 1 ? (xs[ix + 1] - n.X) / 2 : Math.Max(0, x1 - n.X);
                double down = iy > 0 ? (n.Y - ys[iy - 1]) / 2 : Math.Max(0, n.Y - y0);
                double up = iy < ys.Count - 1 ? (ys[iy + 1] - n.Y) / 2 : Math.Max(0, y1 - n.Y);
                double area = (left + right) * (down + up);

                bool swap = Math.Abs(Math.Sin(col.Roll * Math.PI / 180.0)) > 0.7;
                double a0 = swap ? col.H : col.B, b0 = swap ? col.B : col.H;               // a // X, b // Y
                // chapiteau : deux contours (autour du chapiteau dans la dalle, et autour du poteau dans le chapiteau)
                var variants = new List<(string Tag, double A, double B, double D, double Hh)>();
                if (s.CapitalSide > Math.Max(a0, b0) + 1e-6 && s.CapitalExtraCm > 0)
                {
                    variants.Add((" - contour du chapiteau", s.CapitalSide, s.CapitalSide, dSlab, s.H));
                    variants.Add((" - sur le chapiteau", a0, b0, dCap, s.H + s.CapitalExtraCm / 100.0));
                }
                else variants.Add(("", a0, b0, dSlab, s.H));
                foreach (var (tag, a, b, d, hh) in variants)
                {
                double halfA = a / 2 + 0.05, halfB = b / 2 + 0.05;
                bool edgeX = left < halfA || right < halfA, edgeY = down < halfB || up < halfB;   // bord libre de dalle contre le poteau
                double c1, c2; string pos; double beta;
                if (edgeX && edgeY) { pos = "angle"; beta = 1.5; c1 = a; c2 = b; }
                else if (edgeX) { pos = "rive"; beta = 1.4; c1 = a; c2 = b; }
                else if (edgeY) { pos = "rive"; beta = 1.4; c1 = b; c2 = a; }
                else { pos = "intérieur"; beta = 1.15; c1 = a; c2 = b; }
                double v = p * area;
                if (v < 1e-6) continue;

                double u0 = pos == "intérieur" ? 2 * (a + b) : pos == "rive" ? c2 + 2 * c1 : c1 + c2;
                double u1 = pos == "intérieur" ? 2 * (a + b) + 4 * Math.PI * d : pos == "rive" ? c2 + 2 * c1 + 2 * Math.PI * d : c1 + c2 + Math.PI * d;
                var r = new PunchingResult { Column = $"Poteau {col.Id}{tag}", Slab = s.Name, Position = pos, X = n.X, Y = n.Y, Z = n.Z, VEd = v, Beta = beta, D = d, U0 = u0, U1 = u1 };
                var sb = new StringBuilder();
                sb.Append($"Poinçonnement {r.Column} ({n.X:0.##} ; {n.Y:0.##}) sous dalle {s.Name} h={hh * 100:0} cm, appui {pos} : zone {area:0.0} m², VEd = {v:0} kN, d = {d * 100:0.0} cm");
                if (ec2)
                {
                    r.Rule = "EC2 6.4";
                    double fck = m.Fc28, fcd = fck / 1.5, dmm = d * 1000;
                    double k = Math.Min(1 + Math.Sqrt(200.0 / dmm), 2.0), rho = rhoL;
                    double vRdc = Math.Max(0.18 / 1.5 * k * Math.Pow(100 * rho * fck, 1.0 / 3.0), 0.035 * Math.Pow(k, 1.5) * Math.Sqrt(fck));
                    double vEd = beta * v / (u1 * d) / 1000.0, vEd0 = beta * v / (u0 * d) / 1000.0;
                    double nu = 0.6 * (1 - fck / 250.0), vMax = 0.4 * nu * fcd;
                    r.StressEd = vEd; r.StressRdc = vRdc; r.StressRdMax = vMax;
                    r.Util = vEd / vRdc; r.UtilMax = vEd0 / vMax;
                    sb.Append($" ; β = {beta:0.00}, u1 = {u1:0.00} m : vEd = {vEd:0.00} MPa, vRd,c = {vRdc:0.00} MPa (ρl = {rhoL * 100:0.00} %{rhoNote}), vEd,0/vRd,max = {r.UtilMax:0.00}");
                    if (r.UtilMax > 1.0) { r.Ok = false; sb.Append(" -> ÉCRASEMENT des bielles au contact du poteau : augmentez l'épaisseur, la section du poteau ou ajoutez un chapiteau."); }
                    else if (vEd > vRdc)
                    {
                        r.NeedsShear = true;
                        double fywd = Math.Min(250 + 0.25 * dmm, m.Fe / 1.15);
                        double asw = Math.Max(0, (vEd - 0.75 * vRdc) * (u1 * 1000) * (0.75 * dmm) / (1.5 * fywd)) / 100.0;    // cm² par périmètre
                        r.AswCm2 = asw;
                        if (vEd > 1.5 * vRdc) { r.Ok = false; sb.Append($" -> vEd > 1,5 vRd,c : armatures de poinçonnement insuffisantes, épaississez la dalle ou ajoutez un chapiteau."); }
                        else sb.Append($" -> armatures de poinçonnement requises : Asw ≈ {asw:0.0} cm² par périmètre (espacement radial 0,75 d = {0.75 * d * 100:0} cm, fywd,ef = {fywd:0} MPa).");
                    }
                    else sb.Append(" -> pas d'armatures de poinçonnement.");
                }
                else
                {
                    r.Rule = "BAEL A.5.2,42";
                    double uc = pos == "intérieur" ? 2 * (a + b + 2 * hh) : pos == "rive" ? c2 + 2 * c1 + 2 * hh : c1 + c2 + hh;
                    double qLim = 0.045 * uc * hh * m.Fc28 / 1.5 * 1000.0;
                    r.Util = v / qLim; r.UtilMax = r.Util; r.StressEd = v; r.StressRdc = qLim; r.U1 = uc;
                    sb.Append($" ; contour à h/2 uc = {uc:0.00} m : Qu = {v:0} kN pour Qu,lim = 0,045 uc h fc28/γb = {qLim:0} kN (taux {r.Util:0.00})");
                    if (r.Util > 1.0) { r.Ok = false; sb.Append(" -> poinçonnement non vérifié : épaississez la dalle, élargissez le poteau ou ajoutez un chapiteau / des armatures spécifiques."); }
                    else sb.Append(" -> vérifié.");
                }
                r.Text = sb.ToString();
                res.Add(r);
                }
            }
        }
        return res;
    }

    private static List<double> Distinct(IEnumerable<double> v)
    {
        var l = new List<double>();
        foreach (double d in v.OrderBy(x => x)) if (l.Count == 0 || d - l[^1] > Tol) l.Add(d);
        return l;
    }
}
