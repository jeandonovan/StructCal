using System.Text;
using StructCalc.Core;
using StructCalc.Core.Codes.BAEL91;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Méthodes de calcul des dalles pleines en béton armé. Chaque méthode fournit les moments de travée et d'appui (kN.m/m, ELU) de chaque panneau
/// limité par les poutres (SlabCells) ; la dalle est dimensionnée avec l'enveloppe des panneaux, selon les mêmes règles (armatures minimales, tranchant,
/// choix des barres) que la méthode des coefficients.</summary>
public static class SlabMethods
{
    public static readonly (string Id, string Label, string Desc)[] All =
    {
        ("Coefficients", "Coefficients (BAEL Annexe E.3, Pigeaud) - par défaut", "Dalle rectangulaire articulée sur ses 4 côtés, coefficients μx, μy, puis réduction en travée / appui selon la continuité. Méthode usuelle et rapide."),
        ("Forfaitaire", "Forfaitaire (BAEL B.6.2,210)", "Dalle continue portant dans un sens : moments d'appui 0,6 / 0,5 / 0,4 M0 et de travée par la formule forfaitaire ; si ses conditions ne sont pas remplies (Q ≤ max(2G ; 5 kN/m²), portées voisines 0,8 à 1,25, fissuration peu préjudiciable), bascule sur Caquot."),
        ("Caquot", "Caquot", "Calcul élastique simplifié des moments d'appui (l' = 0,8 l sur les travées continues) et de travée avec chargement alterné ; adaptée aux charges d'exploitation élevées et quand la méthode forfaitaire ne s'applique pas."),
        ("CaquotMinoree", "Caquot minorée", "Caquot avec g' = 2/3 g pour les moments d'appui dus aux charges permanentes (effet de la continuité sur des inerties ou portées irrégulières) ; les moments de travée sont ensuite calculés avec g."),
        ("LignesRupture", "Lignes de rupture (Johansen)", "Méthode plastique : mécanisme à lignes de rupture (crête + diagonales) optimisé, armatures isotropes, rapport appui/travée réglable ; pour dalles faiblement armées de géométrie régulière."),
        ("Bandes", "Bandes (Hillerborg)", "Méthode des bandes : la charge est partagée entre les deux sens selon leur rigidité, chaque bande est une poutre de 1 m selon ses appuis (articulé / encastré)."),
        ("DDM", "Direct design method (planchers-dalles)", "Moment statique total M0 = pu ln² / 8 dans chaque sens, réparti appui/travée (0,65/0,35 intérieur ; 0/0,63/0,75 rive libre) puis entre bande sur appuis (75 % / 60 %) et bande centrale. Conçue pour planchers-dalles et planchers-champignons ; sur poutres, à titre de comparaison."),
        ("ElementsFinis", "Éléments finis (plaque, maillage choisi)", "Plaque élastique maillée (quadrangles en différences finies ou triangles DKT selon le réglage de maillage) ; moments de Wood-Armer ; la plus générale (cellules découpées par les poutres).")
    };

    public static string Label(string id) => All.FirstOrDefault(a => a.Id == id).Label ?? id;

    public static string Effective(StructModel m, SlabPanel s)
    {
        string id = string.IsNullOrEmpty(s.Method) || s.Method == "Projet" ? m.Settings.SlabMethod : s.Method;
        return All.Any(a => a.Id == id) ? id : "Coefficients";
    }

    public static DesignResult Design(StructModel m, SlabPanel s, IReinforcedConcreteCode rc, SlabInput input) => Design(m, s, rc, input, Effective(m, s));

    public static DesignResult Design(StructModel m, SlabPanel s, IReinforcedConcreteCode rc, SlabInput input, string id)
    {
        if (id == "Coefficients" || rc is not Bael91Code bc) return rc.DesignSlab(input);
        try
        {
            var mo = Moments(m, s, input, id);
            if (mo == null) return rc.DesignSlab(input);
            return bc.DesignSlabFromMoments(input, mo);
        }
        catch (Exception ex)
        {
            var r = rc.DesignSlab(input);
            r.Warnings.Add($"Méthode « {Label(id)} » impossible ({ex.Message}) : méthode des coefficients utilisée.");
            return r;
        }
    }

    // ------------------------------------------------------------------ panneaux
    private sealed class Cell
    {
        public double X0, Y0, Lx, Ly;
        public bool XlIn, XhIn, YlIn, YhIn;
        public bool[] Fixed = new bool[4];       // bords xl, xh, yl, yh : encastrement / continuité (vrai) ou appui simple (faux)
    }

    private static List<Cell> Cells(StructModel m, SlabPanel s)
    {
        List<SlabCell> src;
        if (s.Placed && s.Lx > 0.3 && s.Ly > 0.3) { try { src = SlabCells.Of(m, s); } catch { src = new(); } }
        else src = new();
        if (src.Count == 0) src.Add(new SlabCell(s.X0, s.Y0, s.Lx, s.Ly, false, false, false, false));
        var (xl, xh, yl, yh) = SlabFE.Conditions(s.Continuity);
        var res = new List<Cell>();
        foreach (var c in src)
            res.Add(new Cell
            {
                X0 = c.X0, Y0 = c.Y0, Lx = c.Lx, Ly = c.Ly, XlIn = c.XlIn, XhIn = c.XhIn, YlIn = c.YlIn, YhIn = c.YhIn,
                Fixed = new[] { c.XlIn || xl > 0, c.XhIn || xh > 0, c.YlIn || yl > 0, c.YhIn || yh > 0 }
            });
        return res;
    }

    /// <summary>Moments d'un panneau, dans le repère (petite portée, grande portée).</summary>
    private sealed class CellMoments
    {
        public double MtS, MaS, MtL, MaL, VS, VL;
        public List<string> Notes = new();
    }

    // ------------------------------------------------------------------ point d'entrée
    public static SlabMoments? Moments(StructModel m, SlabPanel s, SlabInput input, string id)
    {
        double h = input.H, g = 25.0 * h + input.GExtra, q = input.Q;
        double pu = 1.35 * g + 1.5 * q, ps = g + q;
        var cells = Cells(m, s);
        var mo = new SlabMoments { Method = Label(id) };
        double mt0 = 0, ma0 = 0, mt1 = 0, ma1 = 0, vs = 0, vl = 0;
        var notes = new List<string>();
        string effId = id;
        foreach (var c in cells)
        {
            CellMoments cm = id switch
            {
                "Forfaitaire" or "Caquot" or "CaquotMinoree" => ChainCell(cells, c, s, g, q, id, out effId),
                "LignesRupture" => YieldCell(c, pu, m.Settings.SlabYieldSupportRatio),
                "Bandes" => StripCell(c, pu),
                "DDM" => DdmCell(c, pu, m.Settings.SlabSupportWidthM),
                "ElementsFinis" => FemCell(m, s, c),
                _ => throw new InvalidOperationException("Méthode inconnue : " + id)
            };
            mt0 = Math.Max(mt0, cm.MtS); ma0 = Math.Max(ma0, cm.MaS); mt1 = Math.Max(mt1, cm.MtL); ma1 = Math.Max(ma1, cm.MaL);
            vs = Math.Max(vs, cm.VS); vl = Math.Max(vl, cm.VL);
            foreach (var n in cm.Notes) if (!notes.Contains(n)) notes.Add(n);
        }
        if (effId != id) mo.Method = $"{Label(id)} → {Label(effId)}";
        double k = ps / pu;
        mo.MtxU = mt0; mo.MtxS = mt0 * k; mo.MaxU = ma0; mo.MaxS = ma0 * k;
        mo.MtyU = mt1; mo.MtyS = mt1 * k; mo.MayU = ma1; mo.MayS = ma1 * k;
        mo.VuX = vs; mo.VuY = vl;
        mo.Notes.AddRange(notes);
        if (cells.Count > 1) mo.Notes.Add($"Dalle découpée en {cells.Count} panneaux par les poutres : enveloppe des panneaux retenue.");
        mo.Notes.Add("Moments de service pris proportionnels aux moments ultimes (pser / pu).");
        return mo;
    }

    private static bool ShortIsX(Cell c) => c.Lx <= c.Ly;
    /// <summary>Appuis (bas, haut) du panneau dans le sens court puis long : true = encastré / continu.</summary>
    private static (bool Lo, bool Hi) Edges(Cell c, bool shortDir) => shortDir == ShortIsX(c) ? (c.Fixed[0], c.Fixed[1]) : (c.Fixed[2], c.Fixed[3]);

    private static double[] Cfix(bool a, bool b) => a && b ? new[] { 1.0 / 384 } : a || b ? new[] { 1.0 / 185 } : new[] { 5.0 / 384 };

    // ------------------------------------------------------------------ poutre continue (Forfaitaire, Caquot, Caquot minorée)
    private sealed class ChainOut { public double[] Mw = Array.Empty<double>(), Me = Array.Empty<double>(), Mt = Array.Empty<double>(), V = Array.Empty<double>(); }

    private static CellMoments ChainCell(List<Cell> all, Cell c, SlabPanel s, double g, double q, string id, out string effective)
    {
        effective = id;
        var cm = new CellMoments();
        double lsh = Math.Min(c.Lx, c.Ly), llo = Math.Max(c.Lx, c.Ly), rho = lsh / llo;
        bool oneWay = rho < 0.4;
        // partage de charge entre les deux sens (flèches égales au centre) selon les appuis
        var (sLo, sHi) = Edges(c, true); var (lLo, lHi) = Edges(c, false);
        double cS = Cfix(sLo, sHi)[0], cL = Cfix(lLo, lHi)[0];
        double share = oneWay ? 1.0 : cL * Math.Pow(llo, 4) / (cS * Math.Pow(lsh, 4) + cL * Math.Pow(llo, 4));
        if (oneWay) cm.Notes.Add($"rho = {rho:F2} < 0,4 : la dalle porte dans la petite portée (charge entière) ; armatures de répartition = As/4.");
        else cm.Notes.Add($"Partage de la charge entre les deux sens (flèches égales) : {share * 100:0} % dans la petite portée, {(1 - share) * 100:0} % dans la grande.");

        // conditions de la méthode forfaitaire
        string method = id;
        if (id == "Forfaitaire")
        {
            var why = new List<string>();
            if (q > Math.Max(2 * g, 5.0)) why.Add($"Q = {q:0.##} > max(2G ; 5) = {Math.Max(2 * g, 5.0):0.##} kN/m²");
            if (s.Crack != CrackingClass.PeuPrejudiciable) why.Add("fissuration préjudiciable");
            var chS = ChainOf(all, c, ShortIsX(c));
            for (int k = 0; k + 1 < chS.Count; k++)
            {
                double r = SpanIn(chS[k], ShortIsX(c)) / SpanIn(chS[k + 1], ShortIsX(c));
                if (r < 0.8 || r > 1.25) { why.Add("rapport des portées voisines hors de 0,8 - 1,25"); break; }
            }
            if (why.Count > 0) { method = "Caquot"; effective = "Caquot"; cm.Notes.Add("Conditions de la méthode forfaitaire non remplies (" + string.Join(" ; ", why) + ") : méthode de Caquot appliquée."); }
        }

        for (int dir = 0; dir < 2; dir++)
        {
            bool shortDir = dir == 0;
            double sh = shortDir ? share : 1 - share;
            if (sh < 1e-6) continue;
            bool alongX = shortDir == ShortIsX(c);            // la direction du calcul est-elle l'axe X ?
            var chain = ChainOf(all, c, alongX);
            var spans = new List<double>(); int first = 0, idx = chain.IndexOf(c);
            var (eLo, eHi) = (alongX ? (chain[0].Fixed[0], chain[^1].Fixed[1]) : (chain[0].Fixed[2], chain[^1].Fixed[3]));
            foreach (var cc in chain) spans.Add(SpanIn(cc, alongX));
            if (eLo) { spans.Insert(0, spans[0]); first = 1; }
            if (eHi) spans.Add(spans[^1]);
            double pg = 1.35 * g * sh, pq = 1.5 * q * sh;
            ChainOut o = method == "Forfaitaire" ? Forfaitaire(spans.ToArray(), pg, pq, g, q) : Chain(spans.ToArray(), pg, pq, method == "CaquotMinoree");
            int k = first + idx;
            double mt = o.Mt[k], ma = Math.Max(o.Mw[k], o.Me[k]), v = o.V[k];
            if (shortDir) { cm.MtS = mt; cm.MaS = ma; cm.VS = v; } else { cm.MtL = mt; cm.MaL = ma; cm.VL = v; }
            cm.Notes.Add($"{(shortDir ? "Petite" : "Grande")} portée ({(alongX ? "sens X" : "sens Y")}), travée {idx + 1}/{chain.Count}{(eLo ? ", prolongée à gauche" : "")}{(eHi ? ", prolongée à droite" : "")} : Mt = {mt:F1}, appuis {o.Mw[k]:F1} / {o.Me[k]:F1} kN.m/m, V = {v:F1} kN/m");
        }
        if (oneWay) { cm.MtL = 0; cm.MaL = 0; cm.VL = 0; }
        return cm;
    }

    private static double SpanIn(Cell c, bool alongX) => alongX ? c.Lx : c.Ly;

    /// <summary>Panneaux alignés avec c selon l'axe choisi, dans l'ordre.</summary>
    private static List<Cell> ChainOf(List<Cell> all, Cell c, bool alongX)
    {
        var l = all.Where(o => alongX ? Math.Abs(o.Y0 - c.Y0) < 1e-3 && Math.Abs(o.Ly - c.Ly) < 1e-3 : Math.Abs(o.X0 - c.X0) < 1e-3 && Math.Abs(o.Lx - c.Lx) < 1e-3)
                   .OrderBy(o => alongX ? o.X0 : o.Y0).ToList();
        return l.Count == 0 ? new List<Cell> { c } : l;
    }

    private static double Cq(double lw, double le, double pw, double pe, bool contW, bool contE)
    {
        double a = contW ? 0.8 * lw : lw, b = contE ? 0.8 * le : le;
        return (pw * a * a * a + pe * b * b * b) / (8.5 * (a + b));
    }

    /// <summary>Caquot / Caquot minorée sur une poutre continue de largeur 1 m (charges en kN/m).</summary>
    private static ChainOut Chain(double[] l, double pg, double pq, bool minoree)
    {
        int n = l.Length;
        var o = new ChainOut { Mw = new double[n], Me = new double[n], Mt = new double[n], V = new double[n] };
        double fg = minoree ? 2.0 / 3.0 : 1.0;
        // moment sur l'appui k (0 = appui gauche de la travée 0 ... n = appui droit de la dernière), pour des charges p1 (travée k-1) et p2 (travée k)
        double Sup(int k, double p1, double p2) => k <= 0 || k >= n ? 0 : Cq(l[k - 1], l[k], p1, p2, k - 1 > 0, k < n - 1);
        for (int k = 0; k < n; k++)
        {
            double pAll = fg * pg + pq;
            double mwAll = Sup(k, pAll, pAll), meAll = Sup(k + 1, pAll, pAll);
            o.Mw[k] = mwAll; o.Me[k] = meAll;
            double pk = pg + pq;
            double mw = Sup(k, fg * pg, fg * pg + pq), me = Sup(k + 1, fg * pg + pq, fg * pg);   // travée chargée, voisines sans charge d'exploitation
            double span = l[k], best = 0;
            for (int t = 0; t <= 40; t++)
            {
                double x = span * t / 40.0;
                double mm = pk * x * (span - x) / 2 - mw * (1 - x / span) - me * x / span;
                best = Math.Max(best, mm);
            }
            o.Mt[k] = best;
            o.V[k] = Math.Max(pk * span / 2 + (mwAll - meAll) / span, pk * span / 2 + (meAll - mwAll) / span);
        }
        return o;
    }

    /// <summary>Méthode forfaitaire (BAEL B.6.2,210).</summary>
    private static ChainOut Forfaitaire(double[] l, double pg, double pq, double g, double q)
    {
        int n = l.Length;
        var o = new ChainOut { Mw = new double[n], Me = new double[n], Mt = new double[n], V = new double[n] };
        double alpha = q / (g + q), p = pg + pq;
        var m0 = l.Select(x => p * x * x / 8.0).ToArray();
        var sup = new double[n + 1];
        for (int k = 1; k < n; k++)
        {
            double mx = Math.Max(m0[k - 1], m0[k]);
            double f = n == 2 ? 0.6 : (k == 1 || k == n - 1) ? 0.5 : 0.4;
            sup[k] = f * mx;
        }
        for (int k = 0; k < n; k++)
        {
            double mw = sup[k], me = sup[k + 1];
            o.Mw[k] = mw; o.Me[k] = me;
            bool endSpan = k == 0 || k == n - 1;
            double mt = mw + me < 1e-9 ? m0[k] : Math.Max((1 + 0.3 * alpha) * m0[k], 1.05 * m0[k]) - (mw + me) / 2;
            double minT = (endSpan ? 1.2 + 0.3 * alpha : 1 + 0.3 * alpha) / 2 * m0[k];
            o.Mt[k] = mw + me < 1e-9 ? mt : Math.Max(mt, minT);
            o.V[k] = p * l[k] / 2 + Math.Abs(mw - me) / l[k];
        }
        return o;
    }

    // ------------------------------------------------------------------ lignes de rupture
    private static CellMoments YieldCell(Cell c, double pu, double iRatio)
    {
        var cm = new CellMoments();
        double S = Math.Min(c.Lx, c.Ly), L = Math.Max(c.Lx, c.Ly);
        var (sLo, sHi) = Edges(c, true); var (lLo, lHi) = Edges(c, false);
        double i = Math.Max(iRatio, 0.0);
        var fix = new[] { sLo ? i : 0, sHi ? i : 0, lLo ? i : 0, lHi ? i : 0 };   // bords longs (v=0, v=S) puis bords courts (u=0, u=L)
        double m = YieldMoment(S, L, pu, fix);
        cm.MtS = m; cm.MtL = m;
        cm.MaS = (sLo || sHi) ? i * m : 0; cm.MaL = (lLo || lHi) ? i * m : 0;
        cm.Notes.Add($"Lignes de rupture : panneau {S:F2} x {L:F2} m, armatures isotropes m = {m:F1} kN.m/m, appuis encastrés {(i * m):F1} kN.m/m (rapport appui/travée {i:0.##}).");
        return cm;
    }

    /// <summary>Moment résistant isotrope m (kN.m/m) pour un mécanisme à crête parallèle aux grands côtés (distances c1, c2 aux grands côtés ; a1, a2 aux petits côtés).</summary>
    public static double YieldMoment(double S, double L, double p, double[] fix)
    {
        double Eval(double c1, double a1, double a2)
        {
            double c2 = S - c1, lr = L - a1 - a2;
            if (lr < 0 || c1 < 1e-6 || c2 < 1e-6 || a1 < 1e-6 || a2 < 1e-6) return 0;
            double v = S * (3 * L - (a1 + a2)) / 6.0;
            double w = lr * (1 / c1 + 1 / c2)
                     + (a1 * a1 + c1 * c1) / (a1 * c1) + (a1 * a1 + c2 * c2) / (a1 * c2) + (a2 * a2 + c1 * c1) / (a2 * c1) + (a2 * a2 + c2 * c2) / (a2 * c2)
                     + fix[0] * L / c1 + fix[1] * L / c2 + fix[2] * S / a1 + fix[3] * S / a2;
            return p * v / w;
        }
        double best = 0;
        foreach (double c0 in new[] { 0.3, 0.4, 0.5, 0.6, 0.7 })
            foreach (double a0 in new[] { 0.25, 0.5, 0.75, 1.0 })
                foreach (double b0 in new[] { 0.25, 0.5, 0.75, 1.0 })
                {
                    double c1 = c0 * S, a1 = Math.Min(a0 * S, L / 2), a2 = Math.Min(b0 * S, L / 2), step = 0.1 * S;
                    double cur = Eval(c1, a1, a2);
                    for (int it = 0; it < 200; it++)
                    {
                        bool imp = false;
                        foreach (var (dc, da, db) in new[] { (step, 0.0, 0.0), (-step, 0.0, 0.0), (0.0, step, 0.0), (0.0, -step, 0.0), (0.0, 0.0, step), (0.0, 0.0, -step) })
                        {
                            double n1 = Math.Min(Math.Max(c1 + dc, 0.05 * S), 0.95 * S), n2 = Math.Min(Math.Max(a1 + da, 0.05 * S), L / 2), n3 = Math.Min(Math.Max(a2 + db, 0.05 * S), L / 2);
                            double val = Eval(n1, n2, n3);
                            if (val > cur + 1e-12) { cur = val; c1 = n1; a1 = n2; a2 = n3; imp = true; }
                        }
                        if (!imp) { step *= 0.5; if (step < 1e-5 * S) break; }
                    }
                    best = Math.Max(best, cur);
                }
        return best;
    }

    // ------------------------------------------------------------------ bandes (Hillerborg)
    private static CellMoments StripCell(Cell c, double pu)
    {
        var cm = new CellMoments();
        double lsh = Math.Min(c.Lx, c.Ly), llo = Math.Max(c.Lx, c.Ly);
        var (sLo, sHi) = Edges(c, true); var (lLo, lHi) = Edges(c, false);
        double cS = Cfix(sLo, sHi)[0], cL = Cfix(lLo, lHi)[0];
        double share = lsh / llo < 0.4 ? 1.0 : cL * Math.Pow(llo, 4) / (cS * Math.Pow(lsh, 4) + cL * Math.Pow(llo, 4));
        (cm.MtS, cm.MaS, cm.VS) = StripBeam(share * pu, lsh, sLo, sHi);
        (cm.MtL, cm.MaL, cm.VL) = StripBeam((1 - share) * pu, llo, lLo, lHi);
        cm.Notes.Add($"Bandes : {share * 100:0} % de la charge dans la petite portée ({lsh:F2} m), {(1 - share) * 100:0} % dans la grande ({llo:F2} m) ; moments de poutre de 1 m selon les appuis.");
        return cm;
    }

    private static (double Mt, double Ma, double V) StripBeam(double p, double l, bool lo, bool hi)
    {
        double w = p * l * l;
        if (lo && hi) return (w / 24, w / 12, p * l / 2);
        if (lo || hi) return (9 * w / 128, w / 8, 5 * p * l / 8);
        return (w / 8, 0, p * l / 2);
    }

    // ------------------------------------------------------------------ direct design method
    private static CellMoments DdmCell(Cell c, double pu, double supportWidth)
    {
        var cm = new CellMoments();
        double lsh = Math.Min(c.Lx, c.Ly), llo = Math.Max(c.Lx, c.Ly);
        for (int dir = 0; dir < 2; dir++)
        {
            bool shortDir = dir == 0;
            double l = shortDir ? lsh : llo, l2 = shortDir ? llo : lsh;
            var (lo, hi) = Edges(c, shortDir);
            double ln = Math.Max(l - Math.Max(supportWidth, 0), 0.65 * l);
            double m0 = pu * ln * ln / 8.0;                                   // moment statique total par mètre de largeur
            double neg, pos, negShare, posShare = 0.60;
            if (lo && hi) { neg = 0.65; pos = 0.35; negShare = 0.75; }
            else if (lo || hi) { neg = 0.75; pos = 0.63; negShare = 0.75; }   // appui intérieur 0,75 ; rive libre : travée 0,63
            else { neg = 0; pos = 1.0; negShare = 1.0; posShare = 1.0; }       // travée isolée
            double wcs = 0.5 * Math.Min(l, l2);                                // largeur de la bande sur appuis
            double kCs = l2 / wcs;                                             // moment par mètre de bande sur appuis / moment moyen par mètre
            double mt = pos * m0 * (posShare >= 1 ? 1.0 : posShare * kCs), ma = neg * m0 * (negShare >= 1 ? 1.0 : negShare * kCs);
            double mtMid = pos * m0 * (posShare >= 1 ? 1.0 : (1 - posShare) * l2 / Math.Max(l2 - wcs, 1e-6));
            double v = pu * ln / 2;
            if (shortDir) { cm.MtS = mt; cm.MaS = ma; cm.VS = v; } else { cm.MtL = mt; cm.MaL = ma; cm.VL = v; }
            cm.Notes.Add($"Direct design ({(shortDir ? "petite" : "grande")} portée {l:F2} m, portée libre {ln:F2} m) : M0 = {m0:F1} kN.m/m ; bande sur appuis : travée {mt:F1}, appui {ma:F1} kN.m/m (bande centrale : travée {mtMid:F1} kN.m/m) - armatures calculées avec la bande sur appuis.");
        }
        if (Math.Min(c.Lx, c.Ly) / Math.Max(c.Lx, c.Ly) < 0.5) cm.Notes.Add("Direct design : rapport des portées > 2, méthode hors de son domaine d'application.");
        return cm;
    }

    // ------------------------------------------------------------------ éléments finis
    private static CellMoments FemCell(StructModel m, SlabPanel s, Cell c)
    {
        var cm = new CellMoments();
        var f = SlabFE.Solve(m, s, new SlabCell(c.X0, c.Y0, c.Lx, c.Ly, c.XlIn, c.XhIn, c.YlIn, c.YhIn));
        var mx = f.Values[SlabFieldKind.Mx]; var my = f.Values[SlabFieldKind.My]; var mxy = f.Values[SlabFieldKind.Mxy];
        var vx = f.Values[SlabFieldKind.Vx]; var vy = f.Values[SlabFieldKind.Vy];
        int nx = f.Nx, ny = f.Ny;
        double tX = 0, tY = 0, aX = 0, aY = 0, vX = 0, vY = 0;
        for (int i = 0; i <= nx; i++)
            for (int j = 0; j <= ny; j++)
            {
                bool edgeX = i == 0 || i == nx, edgeY = j == 0 || j == ny;
                bool corner = (i <= 1 || i >= nx - 1) && (j <= 1 || j >= ny - 1);
                double t = Math.Abs(mxy[i, j]);
                if (!edgeX && !edgeY) { tX = Math.Max(tX, mx[i, j] + t); tY = Math.Max(tY, my[i, j] + t); }
                if (edgeX && !corner) aX = Math.Max(aX, -mx[i, j]);              // appuis sur les bords x = const
                if (edgeY && !corner) aY = Math.Max(aY, -my[i, j]);
                if (!edgeX && !edgeY) { aX = Math.Max(aX, -mx[i, j] + t); aY = Math.Max(aY, -my[i, j] + t); }
                vX = Math.Max(vX, Math.Abs(vx[i, j])); vY = Math.Max(vY, Math.Abs(vy[i, j]));
            }
        bool xShort = ShortIsX(c);
        if (xShort) { cm.MtS = tX; cm.MaS = aX; cm.MtL = tY; cm.MaL = aY; cm.VS = vX; cm.VL = vY; }
        else { cm.MtS = tY; cm.MaS = aY; cm.MtL = tX; cm.MaL = aX; cm.VS = vY; cm.VL = vX; }
        cm.Notes.Add($"Éléments finis : maillage {nx} x {ny}{(f.Triangulated ? " triangulé (DKT)" : " rectangulaire (différences finies)")}, moments de Wood-Armer ; appuis simples ou encastrés selon la continuité ; angles exclus (armatures de coin à prévoir).");
        return cm;
    }

    // ------------------------------------------------------------------ comparaison des méthodes
    public static string Compare(StructModel m, SlabPanel s, IReinforcedConcreteCode rc, bool includeFem = true)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Dalle {s.Name} ({s.Lx:0.00} x {s.Ly:0.00} m, h = {s.H * 100:0} cm) : section d'acier en cm²/m (travée x / travée y / appui x / appui y), x = petite portée");
        string current = Effective(m, s);
        foreach (var (id, label, _) in All)
        {
            if (id == "ElementsFinis" && !includeFem) continue;
            var input = new SlabInput(s.Lx, s.Ly, s.H, s.GExtra, s.Q, s.Continuity, m.Fc28, m.Fe, s.Crack, (s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm) / 100.0, m.Settings);
            DesignResult r;
            try { r = Design(m, s, rc, input, id); } catch (Exception ex) { sb.AppendLine($"  {label,-50} : échec ({ex.Message})"); continue; }
            double V(string k) => r.Values.TryGetValue(k, out var v) ? v : 0;
            sb.AppendLine($"  {(id == current ? "►" : " ")} {label,-50} : {V("Asx_travee_cm2m"):0.00} / {V("Asy_travee_cm2m"):0.00} / {V("Asx_appui_cm2m"):0.00} / {V("Asy_appui_cm2m"):0.00}   {(r.Ok ? "OK" : "NON OK")}");
        }
        sb.AppendLine("  (► = méthode retenue ; les écarts entre méthodes indiquent la sensibilité du résultat : en cas de doute, retenir la valeur la plus défavorable.)");
        return sb.ToString();
    }
}
