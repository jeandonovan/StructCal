using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.Engine.Structure;

/// <summary>Contrôles de cohérence de la chaîne de transmission dalle -> poutres -> poteaux -> semelles : surface reprise par chaque poteau comparée
/// aux efforts du calcul, équilibre vertical, recouvrement des semelles. Les écarts sont signalés, jamais corrigés en silence.</summary>
public static class InfluenceZones
{
    private const double Tol = 2e-3;

    public static List<string> Check(StructModel m, AnalysisOutput o)
    {
        var msgs = new List<string>();
        try { Columns(m, o, msgs); } catch { }
        try { Equilibrium(m, o, msgs); } catch { }
        try { Footings(m, o, msgs); } catch { }
        try { msgs.AddRange(WallInfluence.Check(m)); } catch { }
        return msgs;
    }

    private static long K(double v) => (long)Math.Round(v / Tol);

    private static void Columns(StructModel m, AnalysisOutput o, List<string> msgs)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var colNodes = new HashSet<int>();
        foreach (var mem in m.Members.Where(x => x.Type == MemberType.Column)) { colNodes.Add(mem.NodeI); colNodes.Add(mem.NodeJ); }
        var acc = new Dictionary<(long, long), List<(double Z, double Area, double P)>>();
        foreach (var s in m.Slabs.Where(q => q.Placed && q.CalcMode != SlabCalcMode.MassOnly))
        {
            double p = 1.35 * (s.SelfWeightKnM2 + s.GExtra) + 1.5 * s.Q;
            foreach (var c in SlabCells.Of(m, s))
            {
                var corners = new[] { (c.X0, c.Y0), (c.X0 + c.Lx, c.Y0), (c.X0 + c.Lx, c.Y0 + c.Ly), (c.X0, c.Y0 + c.Ly) };
                var found = corners.Where(k => nodes.Values.Any(n => colNodes.Contains(n.Id) && Math.Abs(n.Z - s.Z) < Tol && Math.Abs(n.X - k.Item1) < Tol && Math.Abs(n.Y - k.Item2) < Tol)).ToList();
                if (found.Count == 0) continue;
                double share = c.Lx * c.Ly / found.Count;
                foreach (var k in found)
                {
                    var key = (K(k.Item1), K(k.Item2));
                    if (!acc.TryGetValue(key, out var l)) acc[key] = l = new();
                    l.Add((s.Z, share, p));
                }
            }
        }
        if (acc.Count == 0) return;

        // effort normal de compression du calcul pour chaque poteau, repéré par (x, y) de son nœud haut
        var calc = new Dictionary<(long, long, long), double>();
        foreach (var mem in m.Members.Where(x => x.Type == MemberType.Column))
        {
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            var top = a.Z >= b.Z ? a : b;
            var r = o.Members.FirstOrDefault(x => x.MemberId == mem.Id);
            if (r == null || r.Skipped) continue;
            calc[(K(top.X), K(top.Y), K(top.Z))] = r.NuMax;
        }

        msgs.Add("Zones d'influence des poteaux : surface de plancher reprise (panneaux de dalle) et charge de planchers cumulée en ELU, comparée à l'effort normal du calcul :");
        int shown = 0, suspect = 0;
        foreach (var kv in acc.OrderBy(k => k.Key.Item1).ThenBy(k => k.Key.Item2))
        {
            if (shown++ >= 40) { msgs.Add("   ... (liste tronquée)"); break; }
            var levels = kv.Value.GroupBy(t => Math.Round(t.Z, 3)).OrderByDescending(g => g.Key).ToList();
            double cum = 0; var parts = new List<string>();
            foreach (var g in levels)
            {
                double a = g.Sum(t => t.Area), n = g.Sum(t => t.Area * t.P);
                cum += n;
                string cmp = "";
                if (calc.TryGetValue((kv.Key.Item1, kv.Key.Item2, K(g.Key)), out double nu) && nu > 0)
                {
                    double ratio = nu / cum;
                    if (ratio < 0.7) { cmp = $" ; calcul {nu:0} kN = {ratio * 100:0} % : charge peut-être non reprise par ce poteau (poutres, appuis ?)"; suspect++; }
                    else if (ratio > 1.8) { cmp = $" ; calcul {nu:0} kN = {ratio * 100:0} % : zone plus large que le panneau (poutres continues, console, séisme ?)"; suspect++; }
                    else cmp = $" ; calcul {nu:0} kN";
                }
                parts.Add($"z={g.Key:0.##} : {a:0.0} m², N planchers {cum:0} kN{cmp}");
            }
            msgs.Add($"   Poteau en ({kv.Key.Item1 * Tol:0.##} ; {kv.Key.Item2 * Tol:0.##}) : " + string.Join(" | ", parts));
        }
        if (suspect > 0) msgs.Add($"   {suspect} écart(s) à vérifier ci-dessus (la comparaison ignore le poids propre des barres et la continuité des poutres : tolérance de -30 % à +80 %).");
    }

    /// <summary>Les réactions verticales du cas G doivent au moins égaler les charges permanentes de dalles reportées sur les poutres.</summary>
    private static void Equilibrium(StructModel m, AnalysisOutput o, List<string> msgs)
    {
        if (o.Global == null) return;
        foreach (var act in new[] { ActionType.G, ActionType.Q })
        {
            double carried = 0, total = 0;
            foreach (var sl in m.SurfaceLoads.Where(l => l.Case == act))
            {
                var ex = LoadExpander.Expand(m, sl);
                carried += ex.CarriedKn; total += ex.TotalKn;
            }
            if (total < 1e-6) continue;
            if (!o.Global.TotalFzByCase.TryGetValue(act.ToString(), out double rz)) continue;
            rz = Math.Abs(rz);
            if (rz < 0.98 * carried)
                msgs.Add($"ATTENTION équilibre vertical cas {act} : réactions d'appui {rz:0} kN < charges de dalles reportées {carried:0} kN : une partie des charges ne descend pas jusqu'aux appuis (poutre non portée ou appui manquant).");
            else if (carried < 0.98 * total)
            {
                double onWalls = WallInfluence.CarriedKn(m, act), lost = total - carried;
                if (onWalls > 0.5)
                    msgs.Add($"Cas {act} : {lost:0} kN de charges de dalles ({(1 - carried / total) * 100:0} %) ne vont pas sur les poutres, dont {Math.Min(onWalls, lost):0} kN sur des voiles (à saisir en charge de tête du voile) ; le reste ({Math.Max(0, lost - onWalls):0} kN) n'est porté par rien et est absent du calcul.");
                else
                    msgs.Add($"Cas {act} : {lost:0} kN de charges de dalles ({(1 - carried / total) * 100:0} %) ne sont reportés sur aucune poutre (bords non portés) : ils sont absents du calcul.");
            }
            else
                msgs.Add($"Équilibre vertical cas {act} : réactions {rz:0} kN pour {carried:0} kN de charges de dalles reportées (écart = poids propre et autres charges).");
        }
    }

    private static void Footings(StructModel m, AnalysisOutput o, List<string> msgs)
    {
        var list = FootingPlacement.From(m, o);
        for (int i = 0; i < list.Count; i++)
            for (int j = i + 1; j < list.Count; j++)
            {
                var a = list[i]; var b = list[j];
                if (Math.Abs(a.ZTop - b.ZTop) > 0.5) continue;
                var (ax, ay) = FootingSolids.Shift(a.A, a.B, a.ColA, a.ColB, a.Glacis, m.FootingAlignX, m.FootingAlignY);
                var (bx, by) = FootingSolids.Shift(b.A, b.B, b.ColA, b.ColB, b.Glacis, m.FootingAlignX, m.FootingAlignY);
                double ox = Math.Min(a.X + ax + a.A / 2, b.X + bx + b.A / 2) - Math.Max(a.X + ax - a.A / 2, b.X + bx - b.A / 2);
                double oy = Math.Min(a.Y + ay + a.B / 2, b.Y + by + b.B / 2) - Math.Max(a.Y + ay - a.B / 2, b.Y + by - b.B / 2);
                if (ox > 1e-3 && oy > 1e-3)
                    msgs.Add($"ATTENTION : les semelles {a.Name} et {b.Name} se chevauchent ({ox:0.00} x {oy:0.00} m) : leurs zones d'influence sur le sol se superposent. Réduisez-les, excentrez-les ou regroupez-les en semelle filante ou radier.");
            }
    }
}
