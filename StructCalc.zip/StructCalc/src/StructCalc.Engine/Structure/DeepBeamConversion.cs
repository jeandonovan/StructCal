using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Résultat de la conversion d'une poutre très courte en voile.</summary>
public sealed record DeepBeamResult(bool Done, string Text);

/// <summary>Poutre dont L/h &lt; 2 : le modèle de poutre ne s'applique plus (poutre-voile). Elle est remplacée par un voile maillé de même hauteur et de même épaisseur
/// (largeur de la poutre), centré sur l'axe : les nœuds d'extrémité de la poutre sont conservés au milieu de la hauteur du voile, donc les poteaux restent reliés.
/// Les charges de barre saisies sont ramenées en charges nodales aux deux extrémités (même résultante, même moment d'appui).</summary>
public static class DeepBeamConversion
{
    public static DeepBeamResult ToWall(StructModel m, int memberId)
    {
        var mem = m.Members.FirstOrDefault(q => q.Id == memberId);
        if (mem == null) return new(false, $"Barre {memberId} introuvable.");
        if (mem.Type == MemberType.Column || mem.Kind != MaterialKind.ReinforcedConcrete) return new(false, $"Barre {memberId} : seule une poutre en béton armé peut devenir un voile.");
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        if (a == null || b == null) return new(false, $"Barre {memberId} : nœud manquant.");
        double L = Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
        if (L < 0.05) return new(false, $"Barre {memberId} : longueur nulle, supprimez-la.");
        if (Math.Abs(a.Z - b.Z) > 0.1 * L) return new(false, $"Barre {memberId} : poutre inclinée, la conversion en voile vertical n'est pas possible.");
        if (mem.H < 0.1 || mem.B < 0.05) return new(false, $"Barre {memberId} : section invalide, corrigez-la d'abord.");

        var loads = m.MemberLoads.Where(l => l.MemberId == memberId).ToList();
        foreach (var l in loads)
        {
            if (l.Kind is MemberLoadKind.Moment or MemberLoadKind.Thermal)
                return new(false, $"Barre {memberId} : elle porte un moment ou une charge thermique, qui ne se transmettent pas à un voile : supprimez-les ou déplacez-les avant de convertir.");
            if (l.Frame == LoadFrame.Local)
                return new(false, $"Barre {memberId} : elle porte une charge en axes locaux : passez-la en axes globaux avant de convertir.");
        }

        // charges de barre saisies -> charges nodales aux deux extrémités (résultante et position conservées)
        var nodal = new List<NodalLoad>();
        void Split(ActionType c, double fx, double fy, double fz, double pos)
        {
            double ti = 1 - pos / L, tj = pos / L;
            if (Math.Abs(fx) + Math.Abs(fy) + Math.Abs(fz) < 1e-12) return;
            nodal.Add(new NodalLoad { NodeId = a.Id, Case = c, Fx = fx * ti, Fy = fy * ti, Fz = fz * ti });
            nodal.Add(new NodalLoad { NodeId = b.Id, Case = c, Fx = fx * tj, Fy = fy * tj, Fz = fz * tj });
        }
        foreach (var l in loads)
        {
            switch (l.Kind)
            {
                case MemberLoadKind.Point:
                    Split(l.Case, l.Px, l.Py, l.Pz, LoadMath.Pos(l, l.A, L)); break;
                case MemberLoadKind.Trapezoid:
                {
                    double s0 = LoadMath.Pos(l, l.A, L), s1 = LoadMath.Pos(l, l.B, L);
                    double[] w1 = { l.Wx, l.Wy, l.Wz }, w2 = { l.Wx2, l.Wy2, l.Wz2 };
                    if (s1 < s0) { (s0, s1) = (s1, s0); (w1, w2) = (w2, w1); }
                    double len = s1 - s0; if (len < 1e-9) break;
                    var f = new double[3]; var xc = new double[3];
                    for (int k = 0; k < 3; k++)
                    {
                        f[k] = (w1[k] + w2[k]) / 2 * len;
                        xc[k] = Math.Abs(w1[k] + w2[k]) < 1e-12 ? s0 + len / 2 : s0 + len * (w1[k] + 2 * w2[k]) / (3 * (w1[k] + w2[k]));
                        xc[k] = Math.Clamp(xc[k], 0, L);
                    }
                    for (int k = 0; k < 3; k++)
                    {
                        var v = new double[3]; v[k] = f[k];
                        Split(l.Case, v[0], v[1], v[2], xc[k]);
                    }
                    break;
                }
                default:
                    Split(l.Case, l.Wx * L, l.Wy * L, l.Wz * L, L / 2); break;
            }
        }

        // part des charges de dalle portées par cette poutre : elles seront reportées sur les autres bords du panneau
        int slabLoads = 0;
        foreach (var s in m.SurfaceLoads)
            try { slabLoads += LoadExpander.Expand(m, s).Loads.Count(x => x.MemberId == memberId); } catch { }

        // voile maillé : 2 rangées sur la hauteur, de sorte que les nœuds de la poutre se trouvent au milieu
        double H = mem.H;
        int nx = Math.Max(1, (int)Math.Ceiling(L / (H / 2) - 1e-9));
        string name = "PV" + memberId;
        int k0 = 1; while (m.Shells.Any(q => q.Name == name)) name = "PV" + memberId + "_" + (++k0);
        int made = ShellMesh.AddRectangle(m, name, "Voile",
            new[] { a.X, a.Y, a.Z - H / 2 }, new[] { b.X, b.Y, b.Z - H / 2 }, new[] { a.X, a.Y, a.Z + H / 2 }, nx, 2, mem.B);

        foreach (var l in loads) m.MemberLoads.Remove(l);
        foreach (var n in nodal) m.NodalLoads.Add(n);
        m.Members.Remove(mem);

        string txt = $"Poutre {memberId} ({mem.B * 100:0} x {mem.H * 100:0} cm, L = {L:0.00} m) remplacée par le voile {name} ({made} mailles, épaisseur {mem.B * 100:0} cm, hauteur {H * 100:0} cm)" +
                     (loads.Count > 0 ? $" ; {loads.Count} charge(s) de barre ramenée(s) en charges nodales aux deux extrémités" : "") + ".";
        if (slabLoads > 0)
            txt += $" Attention : {slabLoads} charge(s) de dalle s'appuyaient sur cette poutre ; le logiciel ne reporte pas les dalles sur un voile, elles sont maintenant reportées sur les autres bords du panneau : vérifiez le total dans l'onglet « Dalles / Semelles / Alertes ». Le voile se ferraille en voile (assistant Voiles).";
        else txt += " Le voile se ferraille en voile (assistant Voiles).";
        return new DeepBeamResult(true, txt);
    }
}
