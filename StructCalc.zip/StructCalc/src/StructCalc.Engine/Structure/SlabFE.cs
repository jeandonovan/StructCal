using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Grandeurs affichables sur une dalle maillée.</summary>
public enum SlabFieldKind { None, Deflection, Mx, My, Mxy, Vx, Vy, AsXBot, AsYBot, AsXTop, AsYTop, M1, M2, SigmaX, SigmaY, TauXY, VonMises, TauV }

/// <summary>Résultat du calcul d'une dalle par différences finies : maillage régulier (Nx x Ny mailles) et valeurs aux nœuds [i, j].</summary>
public sealed class SlabField
{
    public string Name = "";
    public double X0, Y0, Z, Lx, Ly, H;
    public int Nx, Ny;
    public bool Partial;                       // panneau d'une dalle découpée par des poutres
    public bool OneWay; public char SpanDir = 'B';
    public bool Triangulated;                  // maillage triangulé (éléments DKT) au lieu du quadrillage rectangulaire (différences finies)
    public string Support = "";
    public double PUls, PSer;                 // kN/m²
    public double Span;                        // portée de référence pour la flèche admissible
    public bool OverStressed;                  // section insuffisante en flexion simple (mu > 0,372) quelque part
    public Dictionary<SlabFieldKind, double[,]> Values = new();

    public (double Min, double Max) Range(SlabFieldKind k)
    {
        if (!Values.TryGetValue(k, out var a)) return (0, 0);
        double mn = double.MaxValue, mx = double.MinValue;
        foreach (var v in a) { mn = Math.Min(mn, v); mx = Math.Max(mx, v); }
        return (mn, mx);
    }

    public static string Unit(SlabFieldKind k) => k switch
    {
        SlabFieldKind.Deflection => "mm",
        SlabFieldKind.Mx or SlabFieldKind.My or SlabFieldKind.Mxy => "kN·m/m",
        SlabFieldKind.Vx or SlabFieldKind.Vy => "kN/m",
        SlabFieldKind.M1 or SlabFieldKind.M2 => "kN·m/m",
        SlabFieldKind.SigmaX or SlabFieldKind.SigmaY or SlabFieldKind.TauXY or SlabFieldKind.VonMises or SlabFieldKind.TauV => "MPa",
        SlabFieldKind.None => "",
        _ => "cm²/m"
    };

    public static string Title(SlabFieldKind k) => k switch
    {
        SlabFieldKind.Deflection => "Flèche élastique ELS",
        SlabFieldKind.Mx => "Moment Mx (ELU)", SlabFieldKind.My => "Moment My (ELU)", SlabFieldKind.Mxy => "Moment de torsion Mxy (ELU)",
        SlabFieldKind.Vx => "Effort tranchant Vx (ELU)", SlabFieldKind.Vy => "Effort tranchant Vy (ELU)",
        SlabFieldKind.AsXBot => "Armatures inférieures // X", SlabFieldKind.AsYBot => "Armatures inférieures // Y",
        SlabFieldKind.AsXTop => "Armatures supérieures // X", SlabFieldKind.AsYTop => "Armatures supérieures // Y",
        SlabFieldKind.M1 => "Moment principal m1 (max, ELU)", SlabFieldKind.M2 => "Moment principal m2 (min, ELU)",
        SlabFieldKind.SigmaX => "Contrainte σxx (flexion, face inf. si > 0)", SlabFieldKind.SigmaY => "Contrainte σyy (flexion, face inf. si > 0)",
        SlabFieldKind.TauXY => "Contrainte de torsion τxy", SlabFieldKind.VonMises => "Contrainte de von Mises (faces)",
        SlabFieldKind.TauV => "Contrainte de cisaillement due à l'effort tranchant",
        _ => ""
    };
}

/// <summary>Calcul élastique des dalles dessinées : plaque mince (Kirchhoff) résolue par différences finies, sur un maillage régulier.
/// Les poutres sont supposées indéformables (appuis rigides) ; appui simple ou encastrement selon la continuité de la dalle.
/// Dalle en un sens : bande de largeur unitaire dans le sens de la portée. Résultats : flèche, moments, torsion, tranchants, armatures
/// (moments de Wood-Armer simplifiés).</summary>
public static class SlabFE
{
    public const double Nu = 0.2;

    public static (int Nx, int Ny) MeshCounts(SlabPanel s, double target = 0.25) => MeshCounts(s.Lx, s.Ly, target);

    public static (int Nx, int Ny) MeshCounts(double lx, double ly, double target = 0.25) =>
        (Math.Clamp((int)Math.Ceiling(lx / target), 4, 28), Math.Clamp((int)Math.Ceiling(ly / target), 4, 28));

    /// <summary>Conditions aux 4 bords (+1 encastré, -1 simplement appuyé) : X bas, X haut, Y bas, Y haut.</summary>
    public static (int Xl, int Xh, int Yl, int Yh) Conditions(SlabContinuity c) => c switch
    {
        SlabContinuity.Simple => (-1, -1, -1, -1),
        SlabContinuity.Rive => (-1, 1, -1, 1),
        _ => (1, 1, 1, 1)
    };

    private static string Describe(SlabContinuity c) => c switch
    {
        SlabContinuity.Simple => "4 bords simplement appuyés",
        SlabContinuity.Rive => "bords X min et Y min simplement appuyés (rive), les 2 autres encastrés (continuité)",
        _ => "4 bords encastrés (dalle continue)"
    };

    public static List<SlabField> SolveAll(StructModel m)
    {
        var res = new List<SlabField>();
        foreach (var s in m.Slabs.Where(q => q.Placed && q.CalcMode != SlabCalcMode.MassOnly && q.Lx > 0.3 && q.Ly > 0.3 && q.H > 0.02))
        {
            var cells = SlabCells.Of(m, s);
            foreach (var c in cells)
            {
                if (ConsoleDesigner.IsConsoleCell(m, s, c, out _)) continue;      // console : calculée à part (ConsoleDesigner), pas comme un panneau appuyé sur ses 4 bords
                try { var f = Solve(m, s, c); f.Partial = cells.Count > 1; res.Add(f); } catch { /* un panneau en échec n'empêche pas les autres */ }
            }
        }
        return res;
    }

    public static SlabField Solve(StructModel m, SlabPanel slab, SlabCell? cell = null)
    {
        cell ??= new SlabCell(slab.X0, slab.Y0, slab.Lx, slab.Ly, false, false, false, false);
        var s = new SlabPanel
        {
            Name = slab.Name, X0 = cell.X0, Y0 = cell.Y0, Lx = cell.Lx, Ly = cell.Ly, H = slab.H, GExtra = slab.GExtra, Q = slab.Q, Continuity = slab.Continuity,
            Crack = slab.Crack, Placed = true, Z = slab.Z, Gamma = slab.Gamma, CalcMode = slab.CalcMode, Kind = slab.Kind, HourdisCm = slab.HourdisCm,
            ToppingCm = slab.ToppingCm, VolumeFactor = slab.VolumeFactor, CoverCm = slab.CoverCm
        };
        var (nx, ny) = StructCalc.Core.MeshPresets.SlabCounts(m.Settings, s.Lx, s.Ly);
        var (xl, xh, yl, yh) = Conditions(s.Continuity);
        if (cell.XlIn) xl = 1; if (cell.XhIn) xh = 1; if (cell.YlIn) yl = 1; if (cell.YhIn) yh = 1;      // appuis intermédiaires : continuité
        double g = s.SelfWeightKnM2 + s.GExtra, q = s.Q;
        var f = new SlabField
        {
            Name = s.Name, X0 = s.X0, Y0 = s.Y0, Z = s.Z, Lx = s.Lx, Ly = s.Ly, H = s.H, Nx = nx, Ny = ny,
            PUls = 1.35 * g + 1.5 * q, PSer = g + q, Support = Describe(s.Continuity)
        };
        double hx = s.Lx / nx, hy = s.Ly / ny;
        double e = m.EcKNm2, d = e * Math.Pow(s.H, 3) / (12 * (1 - Nu * Nu));       // rigidité de flexion (kN·m)
        var W = new double[nx + 1, ny + 1]; var Mx = new double[nx + 1, ny + 1]; var My = new double[nx + 1, ny + 1]; var Mxy = new double[nx + 1, ny + 1];
        var Vx = new double[nx + 1, ny + 1]; var Vy = new double[nx + 1, ny + 1];

        if (s.CalcMode == SlabCalcMode.OneWayX || s.CalcMode == SlabCalcMode.OneWayY)
        {
            bool alongX = s.CalcMode == SlabCalcMode.OneWayX;
            int n = alongX ? nx : ny; double h = alongX ? hx : hy;
            int sl = alongX ? xl : yl, sh = alongX ? xh : yh;
            Strip(n, h, d, sl, sh, out var w1, out var m1, out var v1);     // pour une charge unitaire
            for (int i = 0; i <= nx; i++)
                for (int j = 0; j <= ny; j++)
                {
                    int k = alongX ? i : j;
                    W[i, j] = w1[k] * f.PSer * 1000.0;                       // mm
                    if (alongX) { Mx[i, j] = m1[k] * f.PUls; Vx[i, j] = v1[k] * f.PUls; }
                    else { My[i, j] = m1[k] * f.PUls; Vy[i, j] = v1[k] * f.PUls; }
                }
            f.OneWay = true; f.SpanDir = alongX ? 'X' : 'Y'; f.Span = alongX ? s.Lx : s.Ly;
        }
        else if (m.Settings.MeshElement == "Tri")
        {
            // maillage triangulé : plaque de Kirchhoff, éléments DKT (2 triangles par maille), charge unitaire puis mise à l'échelle
            SlabTri.Solve(nx, ny, hx, hy, d, Nu, xl, xh, yl, yh, out var w1, out var m1x, out var m1y, out var m1xy, out var v1x, out var v1y);
            for (int i = 0; i <= nx; i++)
                for (int j = 0; j <= ny; j++)
                {
                    W[i, j] = w1[i, j] * f.PSer * 1000.0;
                    Mx[i, j] = m1x[i, j] * f.PUls; My[i, j] = m1y[i, j] * f.PUls; Mxy[i, j] = m1xy[i, j] * f.PUls;
                    Vx[i, j] = v1x[i, j] * f.PUls; Vy[i, j] = v1y[i, j] * f.PUls;
                }
            f.Triangulated = true;
            f.Span = Math.Min(s.Lx, s.Ly);
        }
        else
        {
            Plate(nx, ny, hx, hy, d, xl, xh, yl, yh, out var w1);
            double Gv(int i, int j)
            {
                double c = 1;
                if (i < 0) { c *= xl; i = -i; } else if (i > nx) { c *= xh; i = 2 * nx - i; }
                if (j < 0) { c *= yl; j = -j; } else if (j > ny) { c *= yh; j = 2 * ny - j; }
                if (i == 0 || i == nx || j == 0 || j == ny) return 0;
                return c * w1[i, j];
            }
            var L = new double[nx + 1, ny + 1];
            for (int i = 0; i <= nx; i++)
                for (int j = 0; j <= ny; j++)
                {
                    double wxx = (Gv(i + 1, j) - 2 * Gv(i, j) + Gv(i - 1, j)) / (hx * hx);
                    double wyy = (Gv(i, j + 1) - 2 * Gv(i, j) + Gv(i, j - 1)) / (hy * hy);
                    double wxy = (Gv(i + 1, j + 1) - Gv(i - 1, j + 1) - Gv(i + 1, j - 1) + Gv(i - 1, j - 1)) / (4 * hx * hy);
                    W[i, j] = (i == 0 || i == nx || j == 0 || j == ny ? 0 : w1[i, j]) * f.PSer * 1000.0;
                    Mx[i, j] = -d * (wxx + Nu * wyy) * f.PUls;
                    My[i, j] = -d * (wyy + Nu * wxx) * f.PUls;
                    Mxy[i, j] = -d * (1 - Nu) * wxy * f.PUls;
                    L[i, j] = wxx + wyy;
                }
            for (int i = 0; i <= nx; i++)
                for (int j = 0; j <= ny; j++)
                {
                    Vx[i, j] = -d * Deriv(i, nx, hx, k => L[k, j]) * f.PUls;
                    Vy[i, j] = -d * Deriv(j, ny, hy, k => L[i, k]) * f.PUls;
                }
            f.Span = Math.Min(s.Lx, s.Ly);
        }

        f.Values[SlabFieldKind.Deflection] = W;
        f.Values[SlabFieldKind.Mx] = Mx; f.Values[SlabFieldKind.My] = My; f.Values[SlabFieldKind.Mxy] = Mxy;
        f.Values[SlabFieldKind.Vx] = Vx; f.Values[SlabFieldKind.Vy] = Vy;
        double cover = s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm;
        var axb = new double[nx + 1, ny + 1]; var ayb = new double[nx + 1, ny + 1]; var axt = new double[nx + 1, ny + 1]; var ayt = new double[nx + 1, ny + 1];
        bool over = false;
        for (int i = 0; i <= nx; i++)
            for (int j = 0; j <= ny; j++)
            {
                double t = Math.Abs(Mxy[i, j]), mx = Mx[i, j], my = My[i, j];
                axb[i, j] = AsCm2PerM(Math.Max(0, mx + t), s.H, cover, m.Fc28, m.Fe, ref over);
                ayb[i, j] = AsCm2PerM(Math.Max(0, my + t), s.H, cover, m.Fc28, m.Fe, ref over);
                axt[i, j] = AsCm2PerM(Math.Max(0, -mx + t), s.H, cover, m.Fc28, m.Fe, ref over);
                ayt[i, j] = AsCm2PerM(Math.Max(0, -my + t), s.H, cover, m.Fc28, m.Fe, ref over);
            }
        f.Values[SlabFieldKind.AsXBot] = axb; f.Values[SlabFieldKind.AsYBot] = ayb; f.Values[SlabFieldKind.AsXTop] = axt; f.Values[SlabFieldKind.AsYTop] = ayt;
        f.OverStressed = over;
        return f;
    }

    /// <summary>Section d'acier (cm²/m) pour un moment M (kN·m/m) : flexion simple, béton parabole-rectangle simplifié, avec minimum.</summary>
    public static double AsCm2PerM(double mKnm, double h, double coverCm, double fc, double fe, ref bool over)
    {
        double d = h - coverCm / 100.0 - 0.006;
        if (d < 0.03) return 0;
        double fcd = 0.85 * fc / 1.5, fyd = fe / 1.15;
        double fctm = 0.30 * Math.Pow(fc, 2.0 / 3.0);
        double asMin = Math.Max(0.26 * fctm / fe, 0.0013) * d * 1e4;
        if (mKnm <= 1e-9) return asMin;
        double mu = (mKnm / 1000.0) / (d * d * fcd);
        if (mu > 0.372) { over = true; mu = 0.372; }
        double omega = 1.25 * (1 - Math.Sqrt(1 - 2 * mu));
        return Math.Max(asMin, omega * d * fcd / fyd * 1e4);
    }

    private static double Deriv(int i, int n, double h, Func<int, double> f)
    {
        if (i == 0) return (-3 * f(0) + 4 * f(1) - f(2)) / (2 * h);
        if (i == n) return (3 * f(n) - 4 * f(n - 1) + f(n - 2)) / (2 * h);
        return (f(i + 1) - f(i - 1)) / (2 * h);
    }

    /// <summary>Bande de largeur 1 m, n mailles, charge unitaire 1 kN/m² : flèche (m), moment (kN·m/m) et tranchant (kN/m) aux nœuds.</summary>
    private static void Strip(int n, double h, double d, int sl, int sh, out double[] w, out double[] mom, out double[] shear)
    {
        int u = n - 1;
        var a = new double[u, u]; var b = new double[u];
        double h4 = Math.Pow(h, 4);
        for (int i = 1; i <= n - 1; i++)
        {
            b[i - 1] = 1.0 / d;
            foreach (var (di, c) in new[] { (-2, 1.0), (-1, -4.0), (0, 6.0), (1, -4.0), (2, 1.0) })
            {
                int k = i + di; double cc = c / h4;
                if (k < 0) { cc *= sl; k = -k; } else if (k > n) { cc *= sh; k = 2 * n - k; }
                if (k == 0 || k == n) continue;
                a[i - 1, k - 1] += cc;
            }
        }
        var x = Solve(a, b);
        var wl = new double[n + 1];
        for (int i = 1; i <= n - 1; i++) wl[i] = x[i - 1];
        w = wl;
        double G(int i)
        {
            double c = 1;
            if (i < 0) { c *= sl; i = -i; } else if (i > n) { c *= sh; i = 2 * n - i; }
            return i == 0 || i == n ? 0 : c * wl[i];
        }
        var wxx = new double[n + 1]; mom = new double[n + 1]; shear = new double[n + 1];
        for (int i = 0; i <= n; i++) { wxx[i] = (G(i + 1) - 2 * G(i) + G(i - 1)) / (h * h); mom[i] = -d * wxx[i]; }
        for (int i = 0; i <= n; i++) shear[i] = -d * Deriv(i, n, h, k => wxx[k]);
    }

    /// <summary>Plaque nx x ny mailles, charge unitaire 1 kN/m² (flèche en m aux nœuds, 0 sur les bords).</summary>
    private static void Plate(int nx, int ny, double hx, double hy, double d, int xl, int xh, int yl, int yh, out double[,] w)
    {
        int ux = nx - 1, uy = ny - 1, n = ux * uy;
        var a = new double[n, n]; var b = new double[n];
        double hx4 = Math.Pow(hx, 4), hy4 = Math.Pow(hy, 4), hxy = hx * hx * hy * hy;
        int Idx(int i, int j) => (i - 1) * uy + (j - 1);
        var stencil = new List<(int Di, int Dj, double C)>
        {
            (0, 0, 6 / hx4 + 6 / hy4 + 8 / hxy),
            (1, 0, -4 / hx4 - 4 / hxy), (-1, 0, -4 / hx4 - 4 / hxy),
            (0, 1, -4 / hy4 - 4 / hxy), (0, -1, -4 / hy4 - 4 / hxy),
            (2, 0, 1 / hx4), (-2, 0, 1 / hx4), (0, 2, 1 / hy4), (0, -2, 1 / hy4),
            (1, 1, 2 / hxy), (1, -1, 2 / hxy), (-1, 1, 2 / hxy), (-1, -1, 2 / hxy)
        };
        for (int i = 1; i <= nx - 1; i++)
            for (int j = 1; j <= ny - 1; j++)
            {
                int row = Idx(i, j);
                b[row] = 1.0 / d;
                foreach (var (di, dj, c0) in stencil)
                {
                    int ii = i + di, jj = j + dj; double c = c0;
                    if (ii < 0) { c *= xl; ii = -ii; } else if (ii > nx) { c *= xh; ii = 2 * nx - ii; }
                    if (jj < 0) { c *= yl; jj = -jj; } else if (jj > ny) { c *= yh; jj = 2 * ny - jj; }
                    if (ii == 0 || ii == nx || jj == 0 || jj == ny) continue;
                    a[row, Idx(ii, jj)] += c;
                }
            }
        var x = Solve(a, b);
        w = new double[nx + 1, ny + 1];
        for (int i = 1; i <= nx - 1; i++) for (int j = 1; j <= ny - 1; j++) w[i, j] = x[Idx(i, j)];
    }

    /// <summary>Résolution A x = b (élimination de Gauss, pivot partiel).</summary>
    private static double[] Solve(double[,] a, double[] b)
    {
        int n = b.Length;
        for (int c = 0; c < n; c++)
        {
            int p = c; double best = Math.Abs(a[c, c]);
            for (int r = c + 1; r < n; r++) if (Math.Abs(a[r, c]) > best) { best = Math.Abs(a[r, c]); p = r; }
            if (best < 1e-300) throw new InvalidOperationException("Système singulier.");
            if (p != c)
            {
                for (int k = c; k < n; k++) (a[c, k], a[p, k]) = (a[p, k], a[c, k]);
                (b[c], b[p]) = (b[p], b[c]);
            }
            double piv = a[c, c];
            for (int r = c + 1; r < n; r++)
            {
                double fct = a[r, c] / piv;
                if (fct == 0) continue;
                for (int k = c; k < n; k++) a[r, k] -= fct * a[c, k];
                b[r] -= fct * b[c];
            }
        }
        var x = new double[n];
        for (int r = n - 1; r >= 0; r--)
        {
            double sum = b[r];
            for (int k = r + 1; k < n; k++) sum -= a[r, k] * x[k];
            x[r] = sum / a[r, r];
        }
        return x;
    }

    /// <summary>Note de calcul résumée : maillage, charges, flèche, moments, tranchants et armatures maximales de chaque dalle.</summary>
    public static string Report(IEnumerable<SlabField> fields)
    {
        var sb = new StringBuilder();
        foreach (var f in fields)
        {
            sb.AppendLine($"Dalle {f.Name}{(f.Partial ? $" (panneau en x = {f.X0:0.##}, y = {f.Y0:0.##})" : "")} : {f.Lx:0.00} x {f.Ly:0.00} m, h = {f.H * 100:0} cm, maillage {f.Nx} x {f.Ny} ({f.Lx / f.Nx:0.00} x {f.Ly / f.Ny:0.00} m){(f.Triangulated ? ", triangulé (2 triangles DKT par maille)" : "")}");
            sb.AppendLine($"   {(f.OneWay ? $"porte dans le sens {f.SpanDir}" : "porte dans les deux sens")} ; {f.Support} ; pELU = {f.PUls:0.00} kN/m², pELS = {f.PSer:0.00} kN/m²");
            var (_, wmax) = f.Range(SlabFieldKind.Deflection);
            double lim = f.Span * 1000 / 250.0;
            sb.AppendLine($"   Flèche élastique instantanée max = {wmax:0.0} mm (admissible indicative L/250 = {lim:0.0} mm) {(wmax <= lim ? "OK" : "à vérifier (flèche différée et fissuration non incluses)")}");
            var (mxn, mxx) = f.Range(SlabFieldKind.Mx); var (myn, myx) = f.Range(SlabFieldKind.My); var (txn, txx) = f.Range(SlabFieldKind.Mxy);
            sb.AppendLine($"   Mx : {mxn:0.0} à {mxx:0.0} kN·m/m   My : {myn:0.0} à {myx:0.0} kN·m/m   Mxy max = {Math.Max(Math.Abs(txn), Math.Abs(txx)):0.0} kN·m/m");
            var (vxn, vxx) = f.Range(SlabFieldKind.Vx); var (vyn, vyx) = f.Range(SlabFieldKind.Vy);
            sb.AppendLine($"   Tranchant max : Vx = {Math.Max(Math.Abs(vxn), Math.Abs(vxx)):0.0} kN/m, Vy = {Math.Max(Math.Abs(vyn), Math.Abs(vyx)):0.0} kN/m (valeurs de bord = réactions sur les poutres)");
            sb.AppendLine($"   As inf. : X {f.Range(SlabFieldKind.AsXBot).Max:0.0}, Y {f.Range(SlabFieldKind.AsYBot).Max:0.0} cm²/m ; As sup. : X {f.Range(SlabFieldKind.AsXTop).Max:0.0}, Y {f.Range(SlabFieldKind.AsYTop).Max:0.0} cm²/m (minimum de non-fragilité inclus)");
            if (f.OverStressed) sb.AppendLine("   ATTENTION : en certains points la section est insuffisante en flexion simple (augmentez l'épaisseur).");
            sb.AppendLine();
        }
        if (sb.Length > 0)
            sb.Insert(0, "=== Dalles : maillage et efforts (plaque élastique : différences finies ou triangles DKT selon le réglage) ===\n(appuis rigides, ν = 0,2 ; les pics d'encastrement sont lissés par le maillage ; à recouper avec les autres méthodes de calcul de dalle)\n\n");
        return sb.ToString();
    }
}


/// <summary>Grandeurs dérivées des cartes de dalles : moments principaux et contraintes élastiques de flexion de la section brute non fissurée
/// (σ = 6 m / h² sur les faces, τ = 6 mxy / h², von Mises en état plan de contraintes), cisaillement dû à l'effort tranchant.</summary>
public static class SlabStress
{
    public static void Extend(SlabField f)
    {
        if (!f.Values.TryGetValue(SlabFieldKind.Mx, out var mx) || !f.Values.TryGetValue(SlabFieldKind.My, out var my) || !f.Values.TryGetValue(SlabFieldKind.Mxy, out var mxy)) return;
        int n0 = mx.GetLength(0), n1 = mx.GetLength(1);
        double h = Math.Max(f.H, 0.05);
        double k = 6.0 / (h * h) / 1000.0;                               // kN.m/m -> MPa
        var m1 = new double[n0, n1]; var m2 = new double[n0, n1]; var sx = new double[n0, n1]; var sy = new double[n0, n1];
        var tau = new double[n0, n1]; var vm = new double[n0, n1]; var tv = new double[n0, n1];
        f.Values.TryGetValue(SlabFieldKind.Vx, out var vx); f.Values.TryGetValue(SlabFieldKind.Vy, out var vy);
        for (int i = 0; i < n0; i++)
            for (int j = 0; j < n1; j++)
            {
                double a = mx[i, j], b = my[i, j], c = mxy[i, j];
                double mean = (a + b) / 2, rad = Math.Sqrt((a - b) * (a - b) / 4 + c * c);
                m1[i, j] = mean + rad; m2[i, j] = mean - rad;
                sx[i, j] = a * k; sy[i, j] = b * k; tau[i, j] = c * k;
                vm[i, j] = Math.Sqrt(sx[i, j] * sx[i, j] - sx[i, j] * sy[i, j] + sy[i, j] * sy[i, j] + 3 * tau[i, j] * tau[i, j]);
                double vxx = vx == null ? 0 : vx[i, j], vyy = vy == null ? 0 : vy[i, j];
                tv[i, j] = Math.Sqrt(vxx * vxx + vyy * vyy) / h / 1000.0;
            }
        f.Values[SlabFieldKind.M1] = m1; f.Values[SlabFieldKind.M2] = m2;
        f.Values[SlabFieldKind.SigmaX] = sx; f.Values[SlabFieldKind.SigmaY] = sy; f.Values[SlabFieldKind.TauXY] = tau;
        f.Values[SlabFieldKind.VonMises] = vm; f.Values[SlabFieldKind.TauV] = tv;
    }

    /// <summary>Valeur de la carte au point (x, y) absolu (interpolation bilinéaire), ou NaN hors de la dalle.</summary>
    public static double Sample(SlabField f, SlabFieldKind kind, double x, double y)
    {
        if (!f.Values.TryGetValue(kind, out var v)) return double.NaN;
        double u = (x - f.X0) / f.Lx * f.Nx, w = (y - f.Y0) / f.Ly * f.Ny;
        if (u < -1e-9 || w < -1e-9 || u > f.Nx + 1e-9 || w > f.Ny + 1e-9) return double.NaN;
        int i = Math.Clamp((int)Math.Floor(u), 0, f.Nx - 1), j = Math.Clamp((int)Math.Floor(w), 0, f.Ny - 1);
        double a = Math.Clamp(u - i, 0, 1), b = Math.Clamp(w - j, 0, 1);
        return v[i, j] * (1 - a) * (1 - b) + v[i + 1, j] * a * (1 - b) + v[i, j + 1] * (1 - a) * b + v[i + 1, j + 1] * a * b;
    }
}
