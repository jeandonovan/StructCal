using System.Globalization;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine.Structure;

/// <summary>Un niveau (plancher) détecté automatiquement : tous les nœuds situés à la même cote Z (à la tolérance près).</summary>
public sealed class LevelInfo
{
    public int Index { get; set; }
    public string Name { get; set; } = "";
    public double Z { get; set; }
    public double HeightToNext { get; set; }                 // hauteur d'étage jusqu'au niveau suivant (0 pour le dernier)
    public List<int> NodeIds { get; } = new();
    public List<int> BeamIds { get; } = new();               // poutres situées à ce niveau
    public List<int> ColumnIds { get; } = new();             // poteaux dont la tête est à ce niveau (l'étage situé sous le niveau)
    public string Label => $"{Name}  ({(Z >= 0 ? "+" : "")}{Z.ToString("0.00", CultureInfo.InvariantCulture)} m)";
}

/// <summary>Une file d'axes (« grid line ») : numérotée 1, 2, 3 (x constant) ou lettrée A, B, C (y constant).</summary>
public sealed class GridAxis
{
    public string Name { get; set; } = "";
    public bool ConstantX { get; set; }                      // true : ligne parallèle à Y située à x = Pos
    public double Pos { get; set; }
    public double SpacingToPrevious { get; set; }
    public List<int> NodeIds { get; } = new();
    public string Label => ConstantX ? $"{Name}   x = {Pos.ToString("0.00", CultureInfo.InvariantCulture)} m" : $"{Name}   y = {Pos.ToString("0.00", CultureInfo.InvariantCulture)} m";
}

public sealed class StructureInfo
{
    public List<LevelInfo> Levels { get; } = new();
    public List<GridAxis> XAxes { get; } = new();            // axes numérotés (x constant)
    public List<GridAxis> YAxes { get; } = new();            // axes lettrés (y constant)
    public Dictionary<int, int> MemberLevel { get; } = new();
    public Dictionary<int, int> NodeLevel { get; } = new();
    public double MinX, MaxX, MinY, MaxY, MinZ, MaxZ;
    public double Tolerance { get; set; } = 0.05;
    public bool UserLevels { get; set; }                    // niveaux définis dans la fenêtre « Étages »
    public bool UserGrid { get; set; }                      // axes définis dans la fenêtre « Grille »
    public bool IsEmpty => Levels.Count == 0 && XAxes.Count == 0 && YAxes.Count == 0;

    public LevelInfo? LevelOfMember(int memberId) => MemberLevel.TryGetValue(memberId, out int i) && i >= 0 && i < Levels.Count ? Levels[i] : null;

    /// <summary>Indice du niveau situé à la cote z (à la tolérance près), ou -1.</summary>
    public int LevelAtZ(double z)
    {
        for (int i = 0; i < Levels.Count; i++) if (Math.Abs(Levels[i].Z - z) <= Tolerance) return i;
        return -1;
    }

    /// <summary>Repère d'axes d'un point en plan : « B-2 » si le point est à l'intersection des axes B et 2, « B » ou « 2 » si un seul axe passe, "" sinon.</summary>
    public string AxisRef(double x, double y)
    {
        string xa = XAxes.FirstOrDefault(a => Math.Abs(a.Pos - x) <= Tolerance)?.Name ?? "";
        string ya = YAxes.FirstOrDefault(a => Math.Abs(a.Pos - y) <= Tolerance)?.Name ?? "";
        if (xa != "" && ya != "") return ya + "-" + xa;
        return ya != "" ? ya : xa;
    }
}

public sealed record LevelQuantities(double BeamLengthM, double ColumnLengthM, double ConcreteM3, double SteelKg);

/// <summary>Détection des niveaux et des axes à partir de la géométrie du modèle, et textes descriptifs pour l'arborescence.</summary>
public static class StructureAnalyzer
{
    public static string AlphaName(int i)
    {
        string s = "";
        i++;
        while (i > 0) { int r = (i - 1) % 26; s = (char)('A' + r) + s; i = (i - 1) / 26; }
        return s;
    }

    private static List<List<double>> Cluster(IEnumerable<double> values, double tol)
    {
        var res = new List<List<double>>();
        foreach (double v in values.OrderBy(x => x))
        {
            if (res.Count > 0 && v - res[^1][^1] <= tol) res[^1].Add(v);
            else res.Add(new List<double> { v });
        }
        return res;
    }

    public static StructureInfo Analyze(StructModel m, double tol = 0.05)
    {
        var info = new StructureInfo { Tolerance = tol };
        if (m.Nodes.Count == 0 && m.Levels.Count == 0 && m.Grid.IsEmpty) return info;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var xs0 = nodes.Values.Select(n => n.X).Concat(m.Grid.XAxes.Select(a => a.Pos)).DefaultIfEmpty(0).ToList();
        var ys0 = nodes.Values.Select(n => n.Y).Concat(m.Grid.YAxes.Select(a => a.Pos)).DefaultIfEmpty(0).ToList();
        var zs0 = nodes.Values.Select(n => n.Z).Concat(m.Levels.Select(l => l.Elevation)).DefaultIfEmpty(0).ToList();
        info.MinX = xs0.Min(); info.MaxX = xs0.Max();
        info.MinY = ys0.Min(); info.MaxY = ys0.Max();
        info.MinZ = zs0.Min(); info.MaxZ = zs0.Max();

        // ---- niveaux : définis par l'utilisateur, sinon détectés
        if (m.Levels.Count > 0)
        {
            var defs = m.Levels.OrderBy(l => l.Elevation).ToList();
            for (int i = 0; i < defs.Count; i++)
                info.Levels.Add(new LevelInfo { Index = i, Name = string.IsNullOrWhiteSpace(defs[i].Name) ? $"Niveau {i}" : defs[i].Name, Z = Math.Round(defs[i].Elevation, 3) });
            info.UserLevels = true;
        }
        else if (nodes.Count > 0)
        {
            var zc = Cluster(nodes.Values.Select(n => n.Z), tol);
            for (int i = 0; i < zc.Count; i++)
            {
                double z = Math.Round(zc[i].Average(), 3);
                string name = i == 0 ? "Base" : (i == zc.Count - 1 && zc.Count > 2 ? $"Niveau {i} (terrasse)" : $"Niveau {i}");
                info.Levels.Add(new LevelInfo { Index = i, Name = name, Z = z });
            }
        }
        for (int i = 0; i + 1 < info.Levels.Count; i++) info.Levels[i].HeightToNext = Math.Round(info.Levels[i + 1].Z - info.Levels[i].Z, 3);
        foreach (var n in nodes.Values)
        {
            int idx = info.LevelAtZ(n.Z);
            if (idx < 0) idx = NearestLevel(info, n.Z);
            info.NodeLevel[n.Id] = idx;
            info.Levels[idx].NodeIds.Add(n.Id);
        }

        // ---- rattachement des barres : une poutre appartient au niveau où elle est posée ; un poteau, au niveau de sa tête
        foreach (var mem in m.Members)
        {
            if (!nodes.ContainsKey(mem.NodeI) || !nodes.ContainsKey(mem.NodeJ)) continue;
            int la = info.NodeLevel[mem.NodeI], lb = info.NodeLevel[mem.NodeJ];
            int lv = Math.Max(la, lb);
            info.MemberLevel[mem.Id] = lv;
            if (mem.Type == MemberType.Column) info.Levels[lv].ColumnIds.Add(mem.Id);
            else info.Levels[lv].BeamIds.Add(mem.Id);
        }

        // ---- axes : on prend les positions des poteaux (à défaut, de tous les nœuds)
        var colNodeIds = m.Members.Where(x => x.Type == MemberType.Column).SelectMany(x => new[] { x.NodeI, x.NodeJ }).Where(nodes.ContainsKey).Distinct().ToList();
        var axNodes = (colNodeIds.Count > 0 ? colNodeIds.Select(id => nodes[id]) : nodes.Values).ToList();
        if (m.Grid.XAxes.Count > 0)
        {
            info.UserGrid = true;
            var xs = m.Grid.XAxes.OrderBy(q => q.Pos).ToList();
            for (int i = 0; i < xs.Count; i++)
            {
                var ax = new GridAxis { Name = string.IsNullOrWhiteSpace(xs[i].Name) ? (i + 1).ToString(CultureInfo.InvariantCulture) : xs[i].Name, ConstantX = true, Pos = Math.Round(xs[i].Pos, 3) };
                if (i > 0) ax.SpacingToPrevious = Math.Round(ax.Pos - info.XAxes[i - 1].Pos, 3);
                foreach (var an in nodes.Values.Where(q => Math.Abs(q.X - ax.Pos) <= tol)) ax.NodeIds.Add(an.Id);
                info.XAxes.Add(ax);
            }
        }
        else
        {
            var xc = Cluster(axNodes.Select(n => n.X), tol);
            for (int i = 0; i < xc.Count; i++)
            {
                var ax = new GridAxis { Name = (i + 1).ToString(CultureInfo.InvariantCulture), ConstantX = true, Pos = Math.Round(xc[i].Average(), 3) };
                if (i > 0) ax.SpacingToPrevious = Math.Round(ax.Pos - info.XAxes[i - 1].Pos, 3);
                foreach (var an in axNodes.Where(q => Math.Abs(q.X - ax.Pos) <= tol)) ax.NodeIds.Add(an.Id);
                info.XAxes.Add(ax);
            }
        }
        if (m.Grid.YAxes.Count > 0)
        {
            info.UserGrid = true;
            var ys = m.Grid.YAxes.OrderBy(q => q.Pos).ToList();
            for (int i = 0; i < ys.Count; i++)
            {
                var ax = new GridAxis { Name = string.IsNullOrWhiteSpace(ys[i].Name) ? AlphaName(i) : ys[i].Name, ConstantX = false, Pos = Math.Round(ys[i].Pos, 3) };
                if (i > 0) ax.SpacingToPrevious = Math.Round(ax.Pos - info.YAxes[i - 1].Pos, 3);
                foreach (var an in nodes.Values.Where(q => Math.Abs(q.Y - ax.Pos) <= tol)) ax.NodeIds.Add(an.Id);
                info.YAxes.Add(ax);
            }
        }
        else
        {
            var yc = Cluster(axNodes.Select(n => n.Y), tol);
            for (int i = 0; i < yc.Count; i++)
            {
                var ax = new GridAxis { Name = AlphaName(i), ConstantX = false, Pos = Math.Round(yc[i].Average(), 3) };
                if (i > 0) ax.SpacingToPrevious = Math.Round(ax.Pos - info.YAxes[i - 1].Pos, 3);
                foreach (var an in axNodes.Where(q => Math.Abs(q.Y - ax.Pos) <= tol)) ax.NodeIds.Add(an.Id);
                info.YAxes.Add(ax);
            }
        }
        return info;
    }

    private static int NearestLevel(StructureInfo info, double z)
    {
        int best = 0; double bd = double.MaxValue;
        for (int i = 0; i < info.Levels.Count; i++) { double d = Math.Abs(info.Levels[i].Z - z); if (d < bd) { bd = d; best = i; } }
        return best;
    }

    // ------------------------------------------------------------------ longueurs et quantités
    public static double MemberLength(StructModel m, Member mem)
    {
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        if (a == null || b == null) return 0;
        return Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y) + (a.Z - b.Z) * (a.Z - b.Z));
    }

    public static LevelQuantities Quantities(StructModel m, StructureInfo info, int levelIndex)
    {
        if (levelIndex < 0 || levelIndex >= info.Levels.Count) return new LevelQuantities(0, 0, 0, 0);
        var lv = info.Levels[levelIndex];
        double bl = 0, cl = 0, vol = 0, kg = 0;
        foreach (int id in lv.BeamIds.Concat(lv.ColumnIds))
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            double L = MemberLength(m, mem);
            if (mem.Type == MemberType.Column) cl += L; else bl += L;
            if (mem.Kind == MaterialKind.Steel) { if (SteelCatalog.TryGet(mem.Profile, out var p)) kg += p.MassKgPerM * L; }
            else vol += mem.B * mem.H * L;
        }
        return new LevelQuantities(bl, cl, vol, kg);
    }

    // ------------------------------------------------------------------ textes d'information
    private static string F(double v, string f = "0.00") => v.ToString(f, CultureInfo.InvariantCulture);

    public static string MemberTitle(StructModel m, int id, AnalysisOutput? o)
    {
        var mem = m.Members.FirstOrDefault(x => x.Id == id);
        if (mem == null) return "";
        string sec = mem.Kind == MaterialKind.Steel ? (string.IsNullOrEmpty(mem.Profile) ? "acier" : mem.Profile) : $"{mem.B * 100:0}x{mem.H * 100:0}";
        return $"{(mem.Type == MemberType.Column ? "P" : "B")}{mem.Id}  {sec}";
    }

    public static string DescribeMember(StructModel m, StructureInfo info, int id, AnalysisOutput? o)
    {
        var mem = m.Members.FirstOrDefault(x => x.Id == id);
        if (mem == null) return "";
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        var sb = new StringBuilder();
        string typ = mem.Type == MemberType.Column ? "Poteau" : "Poutre";
        sb.AppendLine($"{typ} {mem.Id} - {(mem.Kind == MaterialKind.Steel ? "acier" : "béton armé")}");
        sb.AppendLine($"Section : {MemberTitle(m, id, o).Split("  ", 2).LastOrDefault()}" + (mem.Kind == MaterialKind.Steel ? "" : " cm"));
        sb.AppendLine($"Longueur : {F(MemberLength(m, mem))} m");
        var lv = info.LevelOfMember(id);
        if (lv != null) sb.AppendLine($"Niveau : {lv.Label}");
        if (a != null) sb.AppendLine($"Nœud i : {a.Id}  ({F(a.X)} ; {F(a.Y)} ; {F(a.Z)})" + Ref(info, a));
        if (b != null) sb.AppendLine($"Nœud j : {b.Id}  ({F(b.X)} ; {F(b.Y)} ; {F(b.Z)})" + Ref(info, b));
        if (mem.Kind != MaterialKind.Steel) sb.AppendLine($"Volume béton : {F(mem.B * mem.H * MemberLength(m, mem), "0.000")} m³");
        else if (SteelCatalog.TryGet(mem.Profile, out var p)) sb.AppendLine($"Masse : {F(p.MassKgPerM * MemberLength(m, mem), "0")} kg ({F(p.MassKgPerM, "0.0")} kg/m)");
        var r = o?.Members.FirstOrDefault(x => x.MemberId == id);
        if (r == null) sb.AppendLine("Résultats : lancez le calcul (F5).");
        else if (r.Skipped) sb.AppendLine("Résultats : non traité.");
        else
        {
            sb.AppendLine($"État : {(r.Ok ? "OK" : "NON OK")}   taux {F(r.Utilization * 100, "0")} %");
            if (!string.IsNullOrEmpty(r.BarsBottom)) sb.AppendLine((mem.Type == MemberType.Column ? "Armatures : " : "Inf. : ") + r.BarsBottom);
            if (mem.Type == MemberType.Beam && !string.IsNullOrEmpty(r.BarsTop)) sb.AppendLine("Sup. : " + r.BarsTop);
            if (!string.IsNullOrEmpty(r.Stirrups)) sb.AppendLine("Transversales : " + r.Stirrups);
        }
        return sb.ToString().TrimEnd();
    }

    private static string Ref(StructureInfo info, Node n)
    {
        string r = info.AxisRef(n.X, n.Y);
        return r == "" ? "" : "   axes " + r;
    }

    public static string DescribeLevel(StructModel m, StructureInfo info, int idx)
    {
        if (idx < 0 || idx >= info.Levels.Count) return "";
        var lv = info.Levels[idx];
        var q = Quantities(m, info, idx);
        var sb = new StringBuilder();
        sb.AppendLine(lv.Label);
        sb.AppendLine($"Cote : {F(lv.Z)} m" + (lv.HeightToNext > 0 ? $"   hauteur d'étage au-dessus : {F(lv.HeightToNext)} m" : "   (dernier niveau)"));
        sb.AppendLine($"Nœuds : {lv.NodeIds.Count}   Poutres : {lv.BeamIds.Count}   Poteaux (étage sous ce niveau) : {lv.ColumnIds.Count}");
        sb.AppendLine($"Longueur de poutres : {F(q.BeamLengthM, "0.0")} m   de poteaux : {F(q.ColumnLengthM, "0.0")} m");
        if (q.ConcreteM3 > 0) sb.AppendLine($"Béton des barres : {F(q.ConcreteM3, "0.00")} m³");
        if (q.SteelKg > 0) sb.AppendLine($"Acier de construction : {F(q.SteelKg, "0")} kg");
        var slabs = m.Slabs.Where(s => s.Placed && Math.Abs(s.Z - lv.Z) < 0.05).ToList();
        if (slabs.Count > 0) sb.AppendLine($"Dalles : {slabs.Count}   surface {F(slabs.Sum(s => s.Lx * s.Ly), "0.0")} m²   béton {F(slabs.Sum(s => s.Volume), "0.00")} m³   poids propre {F(slabs.Sum(s => s.TotalWeightKn), "0")} kN");
        return sb.ToString().TrimEnd();
    }

    public static string DescribeAxis(StructureInfo info, string name)
    {
        var ax = info.XAxes.Concat(info.YAxes).FirstOrDefault(a => a.Name == name);
        if (ax == null) return "";
        var sb = new StringBuilder();
        sb.AppendLine($"Axe {ax.Name} - " + (ax.ConstantX ? $"parallèle à Y, x = {F(ax.Pos)} m" : $"parallèle à X, y = {F(ax.Pos)} m"));
        if (ax.SpacingToPrevious > 0) sb.AppendLine($"Entraxe avec l'axe précédent : {F(ax.SpacingToPrevious)} m");
        sb.AppendLine($"Nœuds de poteaux sur cet axe : {ax.NodeIds.Count}");
        return sb.ToString().TrimEnd();
    }

    public static string Overview(StructModel m, StructureInfo info)
    {
        if (info.IsEmpty) return "Modèle vide.";
        var sb = new StringBuilder();
        sb.AppendLine($"{info.Levels.Count} niveau(x)   -   {info.XAxes.Count} axe(s) numérotés x {info.YAxes.Count} axe(s) lettrés");
        sb.AppendLine($"Emprise : {F(info.MaxX - info.MinX, "0.0")} m x {F(info.MaxY - info.MinY, "0.0")} m, hauteur {F(info.MaxZ - info.MinZ, "0.0")} m");
        sb.AppendLine($"{m.Members.Count(x => x.Type == MemberType.Column)} poteau(x), {m.Members.Count(x => x.Type == MemberType.Beam)} poutre(s), {m.Supports.Count} appui(s)");
        return sb.ToString().TrimEnd();
    }
}
