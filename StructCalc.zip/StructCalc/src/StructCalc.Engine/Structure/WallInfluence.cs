using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Charges de planchers reçues par un voile (zone d'influence d'un voile : bords de dalles qui s'appuient sur lui, hors parties portées par une poutre).</summary>
public sealed class WallLoadResult
{
    public string Wall = "";
    public double Length, AreaM2, GKn, QKn;
    public double UluKnPerM => Length > 1e-9 ? (1.35 * GKn + 1.5 * QKn) / Length : 0;
    public double InputUluKnPerM;
    public List<string> Slabs = new();
}

/// <summary>Répartition des charges de dalles sur les voiles : même méthode des lignes de rupture à 45° que pour les poutres, appliquée aux bords de dalle
/// qui longent un voile dont la tête est au niveau de la dalle.</summary>
public static class WallInfluence
{
    private const double Tol = 2e-3;

    private sealed record Edge(double Sx, double Sy, double Dx, double Dy, double Le, double Lp, bool AlongX);

    private static double Weight(SurfaceDistribution mode, Edge e) => mode switch
    {
        SurfaceDistribution.OneWayX => e.AlongX ? 0 : e.Lp / 2,
        SurfaceDistribution.OneWayY => e.AlongX ? e.Lp / 2 : 0,
        _ => 0
    };

    /// <summary>Intégrale de la largeur d'influence w(s) sur [u0, u1] (m²) pour un bord de longueur Le.</summary>
    private static double Integrate(SurfaceDistribution mode, Edge e, double u0, double u1)
    {
        if (u1 - u0 < 1e-9) return 0;
        var pieces = new List<(double P0, double P1, double W0, double W1)>();
        if (mode == SurfaceDistribution.TwoWay)
        {
            double c = Math.Min(e.Lp / 2, e.Le / 2);
            pieces.Add((0, c, 0, c));
            if (e.Le - 2 * c > 1e-9) pieces.Add((c, e.Le - c, c, c));
            pieces.Add((e.Le - c, e.Le, c, 0));
        }
        else
        {
            double w = Weight(mode, e);
            if (w > 1e-12) pieces.Add((0, e.Le, w, w));
        }
        double total = 0;
        foreach (var pc in pieces)
        {
            double a = Math.Max(pc.P0, u0), b = Math.Min(pc.P1, u1);
            if (b - a < 1e-9) continue;
            double span = pc.P1 - pc.P0;
            double wa = pc.W0 + (pc.W1 - pc.W0) * (a - pc.P0) / span, wb = pc.W0 + (pc.W1 - pc.W0) * (b - pc.P0) / span;
            total += (wa + wb) / 2 * (b - a);
        }
        return total;
    }

    /// <summary>Part (kN) d'une charge surfacique reportée sur chaque voile.</summary>
    public static List<(WallDef Wall, double Kn, double AreaM2)> Shares(StructModel m, SurfaceLoad s)
    {
        var res = new List<(WallDef, double, double)>();
        if (m.Walls.Count == 0) return res;
        double x0 = Math.Min(s.X0, s.X1), x1 = Math.Max(s.X0, s.X1), y0 = Math.Min(s.Y0, s.Y1), y1 = Math.Max(s.Y0, s.Y1);
        double lx = x1 - x0, ly = y1 - y0;
        if (lx < 1e-6 || ly < 1e-6 || Math.Abs(s.Q) < 1e-12) return res;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var edges = new[]
        {
            new Edge(x0, y0, 1, 0, lx, ly, true), new Edge(x1, y0, 0, 1, ly, lx, false),
            new Edge(x0, y1, 1, 0, lx, ly, true), new Edge(x0, y0, 0, 1, ly, lx, false),
        };
        foreach (var w in m.Walls)
        {
            if (Math.Abs(w.Z + w.HeightM - s.Z) > 0.15) continue;                          // la tête du voile doit être au niveau de la dalle
            double ang = w.AngleDeg * Math.PI / 180.0, wdx = Math.Cos(ang), wdy = Math.Sin(ang);
            double tolAx = Math.Max(0.10, w.ThicknessM / 2 + 0.02);
            double area = 0;
            foreach (var e in edges)
            {
                if (Math.Abs(wdx * e.Dy - wdy * e.Dx) > 1e-3) continue;                      // non parallèle au bord
                double perp = Math.Abs((w.X - e.Sx) * e.Dy - (w.Y - e.Sy) * e.Dx);
                if (perp > tolAx) continue;
                double t0 = (w.X - e.Sx) * e.Dx + (w.Y - e.Sy) * e.Dy;
                double t1 = t0 + w.LengthM * (wdx * e.Dx + wdy * e.Dy);
                double lo = Math.Max(0, Math.Min(t0, t1)), hi = Math.Min(e.Le, Math.Max(t0, t1));
                if (hi - lo < 1e-6) continue;
                // retire les parties du bord déjà portées par une poutre
                var covered = new List<(double Lo, double Hi)>();
                foreach (var mem in m.Members)
                {
                    if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                    if (Math.Abs(a.Z - s.Z) > Tol || Math.Abs(b.Z - s.Z) > Tol) continue;
                    double pa = Math.Abs((a.X - e.Sx) * e.Dy - (a.Y - e.Sy) * e.Dx), pb = Math.Abs((b.X - e.Sx) * e.Dy - (b.Y - e.Sy) * e.Dx);
                    if (pa > Tol || pb > Tol) continue;
                    double ia = (a.X - e.Sx) * e.Dx + (a.Y - e.Sy) * e.Dy, ib = (b.X - e.Sx) * e.Dx + (b.Y - e.Sy) * e.Dy;
                    covered.Add((Math.Min(ia, ib), Math.Max(ia, ib)));
                }
                double cur = lo;
                foreach (var c in covered.OrderBy(q => q.Lo))
                {
                    if (c.Hi <= cur) continue;
                    if (c.Lo > cur) area += Integrate(s.Distribution, e, cur, Math.Min(c.Lo, hi));
                    cur = Math.Max(cur, c.Hi);
                    if (cur >= hi) break;
                }
                if (cur < hi) area += Integrate(s.Distribution, e, cur, hi);
            }
            if (area > 1e-9) res.Add((w, Math.Abs(s.Q) * area, area));
        }
        return res;
    }

    /// <summary>Charges de planchers reçues par chaque voile (G et Q en kN).</summary>
    public static List<WallLoadResult> Compute(StructModel m)
    {
        var res = new Dictionary<WallDef, WallLoadResult>();
        foreach (var s in m.SurfaceLoads)
            foreach (var (w, kn, area) in Shares(m, s))
            {
                if (!res.TryGetValue(w, out var r))
                    res[w] = r = new WallLoadResult { Wall = w.Name, Length = w.LengthM, InputUluKnPerM = 1.35 * w.GTopKnPerM + 1.5 * w.QTopKnPerM };
                if (s.Case == ActionType.G) r.GKn += kn; else if (s.Case == ActionType.Q) r.QKn += kn;
                if (s.Case == ActionType.G) r.AreaM2 += area;                       // la surface est comptée une fois (cas G)
                if (!string.IsNullOrEmpty(s.Name) && !r.Slabs.Contains(s.Name)) r.Slabs.Add(s.Name);
            }
        return res.Values.ToList();
    }

    /// <summary>Total des charges d'un cas reportées sur les voiles (kN).</summary>
    public static double CarriedKn(StructModel m, ActionType act)
    {
        double t = 0;
        foreach (var s in m.SurfaceLoads.Where(l => l.Case == act))
            foreach (var (_, kn, _) in Shares(m, s)) t += kn;
        return t;
    }

    public static List<string> Check(StructModel m)
    {
        var msgs = new List<string>();
        if (m.Walls.Count == 0) return msgs;
        try
        {
            var list = Compute(m);
            if (list.Count > 0)
                msgs.Add("Zones d'influence des voiles : charges de planchers reprises en tête (bords de dalle appuyés sur le voile, hors parties portées par des poutres) :");
            foreach (var r in list.OrderBy(x => x.Wall))
            {
                string line = $"   Voile {r.Wall} (L = {r.Length:0.##} m) : {r.AreaM2:0.0} m² de plancher, G = {r.GKn:0} kN, Q = {r.QKn:0} kN soit {r.UluKnPerM:0} kN/m en ELU ; charge de tête saisie : {r.InputUluKnPerM:0} kN/m";
                if (r.InputUluKnPerM < 0.9 * r.UluKnPerM)
                    line += " -> ATTENTION : la charge saisie est inférieure à celle des dalles ; mettez à jour le voile (assistant Voiles).";
                else if (r.InputUluKnPerM > 1.8 * r.UluKnPerM)
                    line += " -> la charge saisie dépasse largement celle des dalles (étages supérieurs, murs ?) : vérifiez.";
                msgs.Add(line);
            }
            var cols = m.Members.Where(x => x.Type == MemberType.Column).ToList();
            var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
            foreach (var w in m.Walls)
            {
                double ang = w.AngleDeg * Math.PI / 180.0, dx = Math.Cos(ang), dy = Math.Sin(ang);
                foreach (var c in cols)
                    foreach (int id in new[] { c.NodeI, c.NodeJ })
                    {
                        if (!nodes.TryGetValue(id, out var n)) continue;
                        if (n.Z < w.Z - 0.05 || n.Z > w.Z + w.HeightM + 0.05) continue;
                        double t = (n.X - w.X) * dx + (n.Y - w.Y) * dy, off = Math.Abs((n.X - w.X) * dy - (n.Y - w.Y) * dx);
                        if (t > -0.05 && t < w.LengthM + 0.05 && off < w.ThicknessM / 2 + 0.05)
                        {
                            msgs.Add($"ATTENTION : le poteau {c.Id} est dans l'emprise du voile {w.Name} : zones d'influence superposées (la même charge peut être comptée deux fois). Supprimez l'un des deux ou séparez-les.");
                            break;
                        }
                    }
            }
        }
        catch { }
        return msgs;
    }
}
