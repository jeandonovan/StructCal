namespace StructCalc.Engine.Structure;

/// <summary>Élément fini de plaque triangulaire DKT (Discrete Kirchhoff Triangle, Batoz-Bathe-Ho 1980) : 3 nœuds, 3 ddl par nœud (w, φx, φy),
/// avec φ = -grad w à la limite de Kirchhoff (mêmes conventions que l'élément de coque quadrangulaire du voile : κx = ∂φx/∂x, κy = ∂φy/∂y, κxy = ∂φx/∂y + ∂φy/∂x).
/// Les rotations φ sont quadratiques sur le triangle ; aux milieux des côtés, la rotation tangentielle est déduite de la flèche cubique le long du côté
/// et la rotation normale varie linéairement. Validé : patch tests de courbure constante, plaque carrée appuyée (w = 0,00405 q a⁴/D) et encastrée (0,00127).</summary>
public static class Dkt
{
    private static readonly double[][] Gp = { new[] { 1.0 / 6, 1.0 / 6 }, new[] { 2.0 / 3, 1.0 / 6 }, new[] { 1.0 / 6, 2.0 / 3 } };

    private static void Shapes(double xi, double eta, double[] n, double[,] dn)
    {
        n[0] = 2 * (1 - xi - eta) * (0.5 - xi - eta); n[1] = xi * (2 * xi - 1); n[2] = eta * (2 * eta - 1);
        n[3] = 4 * xi * eta; n[4] = 4 * eta * (1 - xi - eta); n[5] = 4 * xi * (1 - xi - eta);
        dn[0, 0] = -3 + 4 * xi + 4 * eta; dn[0, 1] = -3 + 4 * xi + 4 * eta;
        dn[1, 0] = 4 * xi - 1; dn[1, 1] = 0;
        dn[2, 0] = 0; dn[2, 1] = 4 * eta - 1;
        dn[3, 0] = 4 * eta; dn[3, 1] = 4 * xi;
        dn[4, 0] = -4 * eta; dn[4, 1] = 4 - 4 * xi - 8 * eta;
        dn[5, 0] = 4 - 8 * xi - 4 * eta; dn[5, 1] = -4 * xi;
    }

    /// <summary>Rotations au milieu des côtés (2 x 9 par côté 23, 31, 12) en fonction des 9 ddl.</summary>
    private static double[][,] MidMaps(double[] x, double[] y)
    {
        var maps = new double[3][,];
        int[][] sides = { new[] { 1, 2 }, new[] { 2, 0 }, new[] { 0, 1 } };
        for (int k = 0; k < 3; k++)
        {
            int i = sides[k][0], j = sides[k][1];
            double dx = x[j] - x[i], dy = y[j] - y[i], len = Math.Sqrt(dx * dx + dy * dy);
            double tx = dx / len, ty = dy / len, nx = -ty, ny = tx;
            var bs = new double[9]; var bn = new double[9];
            bs[3 * j] += -1.5 / len; bs[3 * i] += 1.5 / len;
            foreach (int nd in new[] { i, j })
            {
                bs[3 * nd + 1] += -tx / 4; bs[3 * nd + 2] += -ty / 4;
                bn[3 * nd + 1] += nx / 2; bn[3 * nd + 2] += ny / 2;
            }
            var m = new double[2, 9];
            for (int c = 0; c < 9; c++)
            {
                m[0, c] = tx * bs[c] + nx * bn[c];
                m[1, c] = ty * bs[c] + ny * bn[c];
            }
            maps[k] = m;
        }
        return maps;
    }

    /// <summary>Matrice B (3 x 9) des courbures [κx, κy, κxy] au point (ξ, η) de coordonnées de surface ; retourne le double de l'aire (déterminant).</summary>
    public static double CurvatureB(double[] x, double[] y, double xi, double eta, double[,] B, double[][,]? maps = null)
    {
        maps ??= MidMaps(x, y);
        var n = new double[6]; var dn = new double[6, 2];
        Shapes(xi, eta, n, dn);
        var d0 = new double[2, 9]; var d1 = new double[2, 9];           // dβ/dξ et dβ/dη (composante, ddl)
        for (int i = 0; i < 3; i++)
            for (int c = 0; c < 2; c++)
            {
                d0[c, 3 * i + 1 + c] += dn[i, 0];
                d1[c, 3 * i + 1 + c] += dn[i, 1];
            }
        for (int k = 0; k < 3; k++)
            for (int c = 0; c < 2; c++)
                for (int q = 0; q < 9; q++)
                {
                    d0[c, q] += dn[3 + k, 0] * maps[k][c, q];
                    d1[c, q] += dn[3 + k, 1] * maps[k][c, q];
                }
        double x21 = x[1] - x[0], x31 = x[2] - x[0], y21 = y[1] - y[0], y31 = y[2] - y[0], det = x21 * y31 - x31 * y21;
        for (int q = 0; q < 9; q++)
        {
            double bxx = (y31 * d0[0, q] - y21 * d1[0, q]) / det, bxy = (-x31 * d0[0, q] + x21 * d1[0, q]) / det;
            double byx = (y31 * d0[1, q] - y21 * d1[1, q]) / det, byy = (-x31 * d0[1, q] + x21 * d1[1, q]) / det;
            B[0, q] = bxx; B[1, q] = byy; B[2, q] = bxy + byx;
        }
        return det;
    }

    /// <summary>Rigidité 9 x 9 (db = E h³ / 12(1-ν²), ν). Les nœuds doivent être en sens trigonométrique.</summary>
    public static double[,] Stiffness(double[] x, double[] y, double db, double nu)
    {
        var K = new double[9, 9]; var B = new double[3, 9]; var maps = MidMaps(x, y);
        double c1 = db, c2 = db * nu, c3 = db * (1 - nu) / 2;
        foreach (var g in Gp)
        {
            double det = Math.Abs(CurvatureB(x, y, g[0], g[1], B, maps));
            double w = det / 6.0;
            for (int a = 0; a < 9; a++)
                for (int b = 0; b < 9; b++)
                {
                    double s = B[0, a] * (c1 * B[0, b] + c2 * B[1, b]) + B[1, a] * (c2 * B[0, b] + c1 * B[1, b]) + B[2, a] * c3 * B[2, b];
                    K[a, b] += w * s;
                }
        }
        return K;
    }

    /// <summary>Moments [mx, my, mxy] (même unité que db × courbure) aux trois sommets du triangle : le champ de courbure est linéaire dans l'élément.</summary>
    public static double[][] VertexMoments(double[] x, double[] y, double[] u9, double db, double nu)
    {
        var res = new double[3][]; var B = new double[3, 9]; var maps = MidMaps(x, y);
        double[][] pts = { new[] { 0.0, 0.0 }, new[] { 1.0, 0.0 }, new[] { 0.0, 1.0 } };
        for (int v = 0; v < 3; v++)
        {
            CurvatureB(x, y, pts[v][0], pts[v][1], B, maps);
            double kx = 0, ky = 0, kxy = 0;
            for (int q = 0; q < 9; q++) { kx += B[0, q] * u9[q]; ky += B[1, q] * u9[q]; kxy += B[2, q] * u9[q]; }
            res[v] = new[] { db * (kx + nu * ky), db * (nu * kx + ky), db * (1 - nu) / 2 * kxy };
        }
        return res;
    }

    /// <summary>Efforts tranchants (qx = ∂mx/∂x + ∂mxy/∂y, qy = ∂mxy/∂x + ∂my/∂y) constants dans le triangle, à partir des moments aux sommets.</summary>
    public static (double qx, double qy) Shear(double[] x, double[] y, double[][] mv)
    {
        double x21 = x[1] - x[0], x31 = x[2] - x[0], y21 = y[1] - y[0], y31 = y[2] - y[0], det = x21 * y31 - x31 * y21;
        double[] dxm = new double[3], dym = new double[3];
        for (int c = 0; c < 3; c++)
        {
            double a = mv[1][c] - mv[0][c], b = mv[2][c] - mv[0][c];
            dxm[c] = (y31 * a - y21 * b) / det;
            dym[c] = (-x31 * a + x21 * b) / det;
        }
        return (dxm[0] + dym[2], dxm[2] + dym[1]);
    }
}
