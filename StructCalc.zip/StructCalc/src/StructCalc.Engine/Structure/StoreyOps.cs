﻿using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Hauteurs d'étage et dalles rattachées aux niveaux : quand une hauteur change, tout ce qui est au-dessus suit (nœuds, niveaux,
/// dalles, charges surfaciques, planchers) et les charges des dalles sont régénérées à partir de leur volume et de leur mode de calcul.</summary>
public static class StoreyOps
{
    private const double Tol = 0.01;

    /// <summary>Recrée les charges surfaciques G et Q (« Dn-G », « Dn-Q ») d'une dalle dessinée : G = γ x h + charges permanentes, Q = exploitation,
    /// à la cote de la dalle, avec la répartition de son mode de calcul. Mode « métré seul » : aucune charge.</summary>
    public static void SyncSlabLoads(StructModel m, SlabPanel s)
    {
        RemoveSlabLoads(m, s.Name);
        if (!s.Placed || s.CalcMode == SlabCalcMode.MassOnly) return;
        var dist = s.CalcMode == SlabCalcMode.OneWayX ? SurfaceDistribution.OneWayX : s.CalcMode == SlabCalcMode.OneWayY ? SurfaceDistribution.OneWayY : SurfaceDistribution.TwoWay;
        // la dalle est découpée en panneaux par les poutres qui la traversent : chaque panneau charge SES poutres (zone d'influence)
        var cells = SlabCells.Of(m, s);
        for (int k = 0; k < cells.Count; k++)
        {
            var c = cells[k]; string suf = cells.Count > 1 ? "#" + (k + 1) : "";
            m.SurfaceLoads.Add(new SurfaceLoad { Name = s.Name + "-G" + suf, Case = ActionType.G, Q = s.SelfWeightKnM2 + s.GExtra, Distribution = dist, Z = s.Z, X0 = c.X0, Y0 = c.Y0, X1 = c.X0 + c.Lx, Y1 = c.Y0 + c.Ly });
            m.SurfaceLoads.Add(new SurfaceLoad { Name = s.Name + "-Q" + suf, Case = ActionType.Q, Q = s.Q, Distribution = dist, Z = s.Z, X0 = c.X0, Y0 = c.Y0, X1 = c.X0 + c.Lx, Y1 = c.Y0 + c.Ly });
        }
    }

    /// <summary>Supprime les charges surfaciques générées par une dalle (une seule ou une par panneau).</summary>
    public static void RemoveSlabLoads(StructModel m, string name) =>
        m.SurfaceLoads.RemoveAll(l => l.Name == name + "-G" || l.Name == name + "-Q" || l.Name.StartsWith(name + "-G#") || l.Name.StartsWith(name + "-Q#"));

    /// <summary>Régénère les charges de toutes les dalles dessinées (après un changement de cote, de dimensions ou de mode).</summary>
    public static void SyncAllSlabLoads(StructModel m)
    {
        foreach (var s in m.Slabs.Where(q => q.Placed).ToList()) SyncSlabLoads(m, s);
    }

    /// <summary>Hauteur (m) entre le niveau d'indice <paramref name="lowerIdx"/> et le suivant, ou 0 s'il n'y en a pas.</summary>
    public static double HeightAbove(StructureInfo info, int lowerIdx) =>
        lowerIdx >= 0 && lowerIdx + 1 < info.Levels.Count ? info.Levels[lowerIdx + 1].Z - info.Levels[lowerIdx].Z : 0;

    /// <summary>Fixe la hauteur de l'étage compris entre le niveau d'indice <paramref name="lowerIdx"/> et le suivant. Tout ce qui est au niveau
    /// supérieur ou au-dessus est décalé de la différence ; ce qui est entre les deux niveaux est étiré proportionnellement.</summary>
    public static bool SetHeight(StructModel m, StructureInfo info, int lowerIdx, double newH, out string msg)
    {
        if (lowerIdx < 0 || lowerIdx + 1 >= info.Levels.Count) { msg = "Il n'y a pas de niveau au-dessus : la hauteur d'étage n'existe pas."; return false; }
        if (double.IsNaN(newH) || newH < 0.2 || newH > 30) { msg = "Hauteur invalide (0,20 à 30 m)."; return false; }
        double z0 = info.Levels[lowerIdx].Z, z1 = info.Levels[lowerIdx + 1].Z, oldH = z1 - z0;
        if (Math.Abs(newH - oldH) < 1e-6) { msg = "Hauteur inchangée."; return true; }
        LevelOps.Materialize(m, info);
        double delta = newH - oldH, k = newH / oldH;
        double Map(double z) => z >= z1 - Tol ? Math.Round(z + delta, 6) : z > z0 + Tol ? Math.Round(z0 + (z - z0) * k, 6) : z;

        foreach (var n in m.Nodes) n.Z = Map(n.Z);
        foreach (var l in m.Levels) l.Elevation = Map(l.Elevation);
        foreach (var s in m.Slabs.Where(q => q.Placed)) s.Z = Map(s.Z);
        foreach (var l in m.SurfaceLoads) l.Z = Map(l.Z);
        foreach (var f in m.RibbedFloors) f.Z = Map(f.Z);
        SyncAllSlabLoads(m);
        string a = info.Levels[lowerIdx].Name, b = info.Levels[lowerIdx + 1].Name;
        msg = $"Hauteur entre « {a} » et « {b} » : {oldH:0.###} m → {newH:0.###} m ; les niveaux au-dessus sont décalés de {delta:+0.###;-0.###} m (nœuds, dalles et charges suivent).";
        return true;
    }

    /// <summary>Rattache une dalle à un niveau : sa cote devient celle du niveau et ses charges suivent.</summary>
    public static bool AttachSlab(StructModel m, StructureInfo info, SlabPanel s, int levelIdx)
    {
        if (levelIdx < 0 || levelIdx >= info.Levels.Count) return false;
        s.Z = Math.Round(info.Levels[levelIdx].Z, 6);
        SyncSlabLoads(m, s);
        return true;
    }

    /// <summary>Index du niveau auquel une dalle dessinée est rattachée (cote égale), ou -1.</summary>
    public static int LevelOf(StructureInfo info, SlabPanel s)
    {
        for (int i = 0; i < info.Levels.Count; i++) if (Math.Abs(info.Levels[i].Z - s.Z) < 0.05) return i;
        return -1;
    }
}
