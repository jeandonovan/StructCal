namespace StructCalc.Engine.Structure;

/// <summary>Dalle rectangulaire en plaque mince, maillage TRIANGULÉ (chaque maille du quadrillage est coupée en deux triangles, diagonale alternée) :
/// éléments DKT, charge unitaire de 1 kN/m². Appuis : bord simplement appuyé (w = 0 et rotation tangentielle nulle) ou encastré (w = φ = 0).
/// Moments aux nœuds = moyenne des valeurs extrapolées des triangles voisins (champ de courbure linéaire).</summary>
public static class SlabTri
{
    public static void Solve(int nx, int ny, double hx, double hy, double d, double nu, int xl, int xh, int yl, int yh,
                             out double[,] w, out double[,] mx, out double[,] my, out double[,] mxy, out double[,] vx, out double[,] vy)
    {
        int nnx = nx + 1, nny = ny + 1, nn = nnx * nny, n = 3 * nn;
        bool fastJ = ny <= nx;                                   // indice rapide selon la plus petite dimension (bande étroite)
        int Vid(int i, int j) => fastJ ? i * nny + j : j * nnx + i;
        int span = fastJ ? nny + 1 : nnx + 1;
        int bw = 3 * span + 2;
        var K = new BandSpd(n, bw);
        var F = new double[n];
        var tris = new List<int[]>();
        for (int i = 0; i < nx; i++)
            for (int j = 0; j < ny; j++)
            {
                int a = Vid(i, j), b = Vid(i + 1, j), c = Vid(i + 1, j + 1), e = Vid(i, j + 1);
                if ((i + j) % 2 == 0) { tris.Add(new[] { a, b, c }); tris.Add(new[] { a, c, e }); }
                else { tris.Add(new[] { a, b, e }); tris.Add(new[] { b, c, e }); }
            }
        double[] X = new double[nn], Y = new double[nn];
        for (int i = 0; i <= nx; i++) for (int j = 0; j <= ny; j++) { X[Vid(i, j)] = i * hx; Y[Vid(i, j)] = j * hy; }
        double db = d;
        foreach (var t in tris)
        {
            var x = new[] { X[t[0]], X[t[1]], X[t[2]] }; var y = new[] { Y[t[0]], Y[t[1]], Y[t[2]] };
            var ke = Dkt.Stiffness(x, y, db, nu);
            for (int a = 0; a < 3; a++) for (int ca = 0; ca < 3; ca++)
                for (int b = 0; b < 3; b++) for (int cb = 0; cb < 3; cb++)
                {
                    int ra = 3 * t[a] + ca, rb = 3 * t[b] + cb;
                    if (rb > ra) continue;
                    K.Add(ra, rb, ke[3 * a + ca, 3 * b + cb]);
                }
            double area = 0.5 * ((x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0]));
            for (int a = 0; a < 3; a++) F[3 * t[a]] += area / 3.0;                     // pression unitaire, charge nodale équivalente
        }
        // conditions aux limites
        var fixedDof = new bool[n];
        for (int i = 0; i <= nx; i++)
            for (int j = 0; j <= ny; j++)
            {
                int v = Vid(i, j);
                if (i == 0 || i == nx)
                {
                    int fix = i == 0 ? xl : xh;                                         // bord x = const (tangente // y) : φy = 0
                    fixedDof[3 * v] = true; fixedDof[3 * v + 2] = true;
                    if (fix > 0) fixedDof[3 * v + 1] = true;
                }
                if (j == 0 || j == ny)
                {
                    int fix = j == 0 ? yl : yh;                                         // bord y = const (tangente // x) : φx = 0
                    fixedDof[3 * v] = true; fixedDof[3 * v + 1] = true;
                    if (fix > 0) fixedDof[3 * v + 2] = true;
                }
            }
        double dmax = 0; for (int i = 0; i < n; i++) dmax = Math.Max(dmax, K.Diag(i));
        for (int i = 0; i < n; i++) if (fixedDof[i]) { K.Fix(i, dmax); F[i] = 0; }
        K.Factor();
        var u = K.Solve(F);

        w = new double[nnx, nny]; mx = new double[nnx, nny]; my = new double[nnx, nny]; mxy = new double[nnx, nny];
        vx = new double[nnx, nny]; vy = new double[nnx, nny];
        var cnt = new int[nn]; var M = new double[nn, 3]; var V = new double[nn, 2];
        foreach (var t in tris)
        {
            var x = new[] { X[t[0]], X[t[1]], X[t[2]] }; var y = new[] { Y[t[0]], Y[t[1]], Y[t[2]] };
            var u9 = new double[9];
            for (int a = 0; a < 3; a++) for (int c = 0; c < 3; c++) u9[3 * a + c] = u[3 * t[a] + c];
            var mv = Dkt.VertexMoments(x, y, u9, db, nu);
            var (qx, qy) = Dkt.Shear(x, y, mv);
            for (int a = 0; a < 3; a++)
            {
                for (int c = 0; c < 3; c++) M[t[a], c] += mv[a][c];
                V[t[a], 0] += qx; V[t[a], 1] += qy; cnt[t[a]]++;
            }
        }
        for (int i = 0; i <= nx; i++)
            for (int j = 0; j <= ny; j++)
            {
                int v = Vid(i, j), c = Math.Max(cnt[v], 1);
                w[i, j] = u[3 * v];
                mx[i, j] = M[v, 0] / c; my[i, j] = M[v, 1] / c; mxy[i, j] = M[v, 2] / c;
                vx[i, j] = V[v, 0] / c; vy[i, j] = V[v, 1] / c;
            }
    }
}
