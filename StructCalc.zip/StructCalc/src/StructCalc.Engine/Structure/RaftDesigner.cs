using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Geotech;

namespace StructCalc.Engine.Structure;

/// <summary>Charge ponctuelle transmise au radier (poteau, ou tronçon de voile) : position, effort ELU et ELS (kN) et dimensions du poteau.</summary>
public sealed class RaftLoad
{
    public string Name = "";
    public double X, Y, Nu, Ns, A = 0.30, B = 0.30;
    /// <summary>Vrai pour un poteau (vérifié au poinçonnement), faux pour un tronçon de voile.</summary>
    public bool Column;
}

public sealed class RaftResult
{
    public RaftDef Def = new();
    public DesignResult Design = new();
    public string Report = "";
    public double SigmaMax, SigmaMin, QAdm, SettlementMm, HRequired, ConcreteM3, SteelKg, SpanX, SpanY;
    public int Loads;
    public bool Ok => Design.Ok;
}

/// <summary>Radier général : pression de sol linéaire (radier rigide) vérifiée sur la capacité portante et le tassement, poinçonnement des poteaux (BAEL A.5.2,42),
/// ferraillage en dalle inversée sur la trame des poteaux : nappe inférieure sous les poteaux (appuis), nappe supérieure en travée.
/// Méthode simplifiée de prédimensionnement : le radier souple (sol à ressorts) n'est pas modélisé.</summary>
public static class RaftDesigner
{
    private static List<double> Distinct(IEnumerable<double> v, double tol = 0.05)
    {
        var r = new List<double>();
        foreach (double x in v.OrderBy(a => a)) if (r.Count == 0 || x - r[^1] > tol) r.Add(x);
        return r;
    }

    /// <summary>Charge d'un voile par mètre (kN/m) : ELU et ELS, avec son poids propre.</summary>
    public static (double Nu, double Ns) WallLine(WallDef w)
    {
        double sw = w.SelfWeight ? 25.0 * w.ThicknessM * w.HeightM : 0;
        return (1.35 * (w.GTopKnPerM + sw) + 1.5 * w.QTopKnPerM, w.GTopKnPerM + sw + w.QTopKnPerM);
    }

    /// <summary>Tronçons de charge d'un voile (un point tous les ~1 m le long de son axe) pour répartir sa charge sur le radier.</summary>
    public static List<RaftLoad> WallLoads(WallDef w)
    {
        var res = new List<RaftLoad>();
        var (nu, ns) = WallLine(w);
        int n = Math.Max(1, (int)Math.Ceiling(w.LengthM / 1.0));
        double seg = w.LengthM / n, ca = Math.Cos(w.AngleDeg * Math.PI / 180), sa = Math.Sin(w.AngleDeg * Math.PI / 180);
        for (int i = 0; i < n; i++)
        {
            double u = (i + 0.5) * seg;
            res.Add(new RaftLoad { Name = w.Name, X = w.X + u * ca, Y = w.Y + u * sa, Nu = nu * seg, Ns = ns * seg, A = Math.Max(w.ThicknessM, 0.2), B = seg });
        }
        return res;
    }

    /// <summary>Tronçons de charge d'une charge linéaire posée sur le radier (un point tous les ~1 m).</summary>
    public static List<RaftLoad> LineLoadLoads(RaftLineLoad l)
    {
        var res = new List<RaftLoad>();
        double len = l.Length;
        if (len < 1e-6) return res;
        double nu = 1.35 * l.GKnM + 1.5 * l.QKnM, ns = l.GKnM + l.QKnM;
        int n = Math.Max(1, (int)Math.Ceiling(len / 1.0));
        double seg = len / n;
        for (int i = 0; i < n; i++)
        {
            double t = (i + 0.5) / n;
            res.Add(new RaftLoad { Name = string.IsNullOrEmpty(l.Text) ? "Mur" : l.Text, X = l.X1 + t * (l.X2 - l.X1), Y = l.Y1 + t * (l.Y2 - l.Y1), Nu = nu * seg, Ns = ns * seg, A = 0.2, B = seg });
        }
        return res;
    }

    public static bool Contains(RaftDef r, double x, double y, double tol = 0.02) =>
        r.Panels.Any(p => x >= p.X0 - tol && x <= p.X0 + p.Lx + tol && y >= p.Y0 - tol && y <= p.Y0 + p.Ly + tol);

    public static RaftResult Design(RaftDef r, IList<RaftLoad> loads, SoilProfile soil, double sigmaSolKPa, IReinforcedConcreteCode rc, double fc28, double fe, DesignSettings? cfg = null)
    {
        var res = new RaftResult { Def = r, Loads = loads.Count };
        var dr = new DesignResult { Element = $"Radier {r.Name}" };
        res.Design = dr;
        var sb = new StringBuilder();
        double A = r.Area;
        if (A < 1 || r.Panels.Count == 0) { dr.Fail("Radier sans surface."); res.Report = "Radier sans surface."; return res; }
        sb.AppendLine($"RADIER {r.Name} : surface {A:0.0} m², épaisseur {r.H * 100:0} cm, cote du dessus {r.ZTop:0.00} m ; {loads.Count} charge(s) ponctuelle(s) (poteaux, voiles).");
        if (loads.Count == 0)
        {
            dr.Fail("Aucun poteau ni voile du modèle ne repose sur ce radier : charges inconnues.");
            res.Report = sb + "Aucune charge : ajoutez des appuis sous les poteaux ou vérifiez la cote des nœuds.";
            return res;
        }
        double cover = r.CoverCm / 100.0;
        double d = Math.Max(0.1, r.H - cover - 0.01);

        // ---- centre de gravité et inerties du contour
        double cx = r.Panels.Sum(p => p.Lx * p.Ly * (p.X0 + p.Lx / 2)) / A, cy = r.Panels.Sum(p => p.Lx * p.Ly * (p.Y0 + p.Ly / 2)) / A;
        double Ix = r.Panels.Sum(p => p.Lx * Math.Pow(p.Ly, 3) / 12 + p.Lx * p.Ly * Math.Pow(p.Y0 + p.Ly / 2 - cy, 2));
        double Iy = r.Panels.Sum(p => p.Ly * Math.Pow(p.Lx, 3) / 12 + p.Lx * p.Ly * Math.Pow(p.X0 + p.Lx / 2 - cx, 2));
        double sumNs = loads.Sum(l => l.Ns), sumNu = loads.Sum(l => l.Nu);
        double mxS = loads.Sum(l => l.Ns * (l.Y - cy)), myS = loads.Sum(l => l.Ns * (l.X - cx));
        double W = 25.0 * A * r.H;
        double ntot = sumNs + W;
        double Sigma(double x, double y) => ntot / A + mxS * (y - cy) / Ix + myS * (x - cx) / Iy;
        double smax = double.MinValue, smin = double.MaxValue;
        foreach (var p in r.Panels)
            foreach (double x in new[] { p.X0, p.X0 + p.Lx }) foreach (double y in new[] { p.Y0, p.Y0 + p.Ly })
            { double s = Sigma(x, y); smax = Math.Max(smax, s); smin = Math.Min(smin, s); }
        res.SigmaMax = smax; res.SigmaMin = smin;
        sb.AppendLine($"Charges : ΣNser = {sumNs:0} kN, ΣNu = {sumNu:0} kN ; poids du radier {W:0} kN ; centre des charges ({loads.Sum(l => l.Ns * l.X) / sumNs:0.00} ; {loads.Sum(l => l.Ns * l.Y) / sumNs:0.00}) m, centre du radier ({cx:0.00} ; {cy:0.00}) m.");
        sb.AppendLine($"Pression du sol (répartition linéaire) : σmax = {smax:0} kPa, σmin = {smin:0} kPa, moyenne {ntot / A:0} kPa.");
        if (smin < 0) { dr.Warnings.Add($"Décollement partiel du radier (σmin = {smin:0} kPa) : excentrement trop fort, élargissez le radier ou recentrez les charges."); }

        // ---- capacité portante et tassement
        double bx = r.Panels.Max(p => p.X0 + p.Lx) - r.Panels.Min(p => p.X0), by = r.Panels.Max(p => p.Y0 + p.Ly) - r.Panels.Min(p => p.Y0);
        double D = soil.FoundationDepthM;
        double qadm = 0; string note = "";
        if (soil.Enabled)
        {
            var br = SoilMechanics.Bearing(soil, Math.Min(bx, by), Math.Max(bx, by), D);
            qadm = br.QAdm; note = br.Note;
        }
        else if (sigmaSolKPa > 0) { qadm = sigmaSolKPa; note = "contrainte admissible générale du projet"; }
        res.QAdm = qadm;
        if (qadm > 0)
        {
            sb.AppendLine($"Capacité portante : q_adm = {qadm:0} kPa ({note}) -> σmax/q_adm = {smax / qadm:0.00}");
            if (smax > qadm + 1e-9) dr.Fail($"Contrainte du sol dépassée : σmax = {smax:0} kPa > q_adm = {qadm:0} kPa (radier trop petit ou trop chargé).");
        }
        else dr.Warnings.Add("Aucun sol ni contrainte admissible définis : la portance du radier n'est pas vérifiée.");
        if (soil.Enabled && soil.CheckSettlement)
        {
            double qNet = Math.Max(ntot / A - SoilMechanics.EffectiveStress(soil, D), 0);
            var st = SoilMechanics.Settlement(soil, Math.Min(bx, by), Math.Max(bx, by), D, qNet);
            res.SettlementMm = st.TotalMm;
            sb.AppendLine($"Tassement œdométrique ≈ {st.TotalMm:0.0} mm (limite {soil.SettlementLimitMm:0} mm).");
            if (st.TotalMm > soil.SettlementLimitMm) dr.Fail($"Tassement {st.TotalMm:0} mm > {soil.SettlementLimitMm:0} mm admissibles.");
        }

        // ---- poinçonnement des poteaux (BAEL A.5.2,42 : Qu' <= 0,045 uc h fc28/γb), pression nette ELU = ΣNu / A
        double puNet = sumNu / A;
        double hReq = 0; string worst = "";
        var cols = loads.Where(l => l.Column).ToList();
        double rxMin = r.Panels.Min(p => p.X0), rxMax = r.Panels.Max(p => p.X0 + p.Lx), ryMin = r.Panels.Min(p => p.Y0), ryMax = r.Panels.Max(p => p.Y0 + p.Ly);
        foreach (var l in cols)
        {
            for (double h = 0.20; h <= 2.5; h += 0.05)
            {
                // poteau de rive / d'angle : le périmètre critique (à h/2 des faces) est coupé par le bord du radier ; majoration β (1,15 rive, 1,4 angle)
                double eL = Math.Min(h / 2, Math.Max(0, l.X - l.A / 2 - rxMin)), eR = Math.Min(h / 2, Math.Max(0, rxMax - (l.X + l.A / 2)));
                double eD = Math.Min(h / 2, Math.Max(0, l.Y - l.B / 2 - ryMin)), eU = Math.Min(h / 2, Math.Max(0, ryMax - (l.Y + l.B / 2)));
                int cut = (eL < h / 2 - 1e-9 ? 1 : 0) + (eR < h / 2 - 1e-9 ? 1 : 0) + (eD < h / 2 - 1e-9 ? 1 : 0) + (eU < h / 2 - 1e-9 ? 1 : 0);
                double wW = l.A + eL + eR, hH = l.B + eD + eU;
                double uc = (eD >= h / 2 - 1e-9 ? wW : 0) + (eU >= h / 2 - 1e-9 ? wW : 0) + (eL >= h / 2 - 1e-9 ? hH : 0) + (eR >= h / 2 - 1e-9 ? hH : 0);
                if (cut == 0) uc = 2 * (l.A + l.B + 2 * h);
                double beta = cut >= 2 ? 1.4 : cut == 1 ? 1.15 : 1.0, inside = wW * hH;
                if (cut > 0) uc = Math.Max(uc, 0.5 * (l.A + l.B));
                double qu = beta * Math.Max(0, l.Nu - puNet * inside), lim = 0.045 * uc * h * fc28 / 1.5 * 1000.0;
                if (qu <= lim) { if (h > hReq) { hReq = h; worst = l.Name; } break; }
                if (h + 0.05 > 2.5) { hReq = 2.5; worst = l.Name; }
            }
        }
        res.HRequired = Math.Max(hReq, r.H);
        if (cols.Count > 0)
        {
            sb.AppendLine($"Poinçonnement : épaisseur minimale {Math.Max(hReq, 0):0.00} m (poteau le plus défavorable {worst}) pour h = {r.H:0.00} m.");
            if (hReq > r.H + 1e-9) dr.Fail($"Poinçonnement non vérifié : h = {r.H * 100:0} cm < {hReq * 100:0} cm requis (poteau {worst}). Épaissir le radier ou ajouter des chapiteaux.");
        }

        // ---- flexion : dalle inversée sur la trame des poteaux
        var xs = Distinct(cols.Select(l => l.X).DefaultIfEmpty(cx)); var ys = Distinct(cols.Select(l => l.Y).DefaultIfEmpty(cy));
        double SpanOf(List<double> v, double total) { double s = 0; for (int i = 1; i < v.Count; i++) s = Math.Max(s, v[i] - v[i - 1]); return s > 0.5 ? s : Math.Max(total / 2, 1.0); }
        double spX = SpanOf(xs, bx), spY = SpanOf(ys, by);
        res.SpanX = spX; res.SpanY = spY;
        double psNet = sumNs / A;
        double gEq = Math.Max(0, Math.Max(puNet / 1.35, psNet) - 25.0 * r.H);
        var input = new SlabInput(spX, spY, r.H, gEq, 0, SlabContinuity.Interieure, fc28, fe, CrackingClass.Prejudiciable, cover, cfg);
        var fl = rc.DesignSlab(input);
        sb.AppendLine($"Flexion (dalle inversée, pression nette ELU {puNet:0} kPa, travées {spX:0.00} x {spY:0.00} m) :");
        foreach (var n in fl.Notes) sb.AppendLine("  " + n);
        if (!fl.Ok) dr.Fail("Flexion : section insuffisante pour ce radier (augmenter l'épaisseur).");
        foreach (var w in fl.Warnings) if (!dr.Warnings.Contains(w)) dr.Warnings.Add(w);
        // lx = la plus courte des deux portées
        bool lxIsX = spX <= spY;
        string T(string key) => fl.Texts.TryGetValue(key, out var t) ? t : "";
        string tx = T("Travée sens lx"), ty = T("Travée sens ly"), ax = T("Appui sens lx"), ay = T("Appui sens ly");
        if (ax == "") ax = tx; if (ay == "") ay = ty;
        // nappe inférieure (sous les poteaux) = appuis ; nappe supérieure (entre poteaux) = travées
        dr.Texts["Inf X"] = lxIsX ? ax : ay; dr.Texts["Inf Y"] = lxIsX ? ay : ax;
        dr.Texts["Sup X"] = lxIsX ? tx : ty; dr.Texts["Sup Y"] = lxIsX ? ty : tx;
        sb.AppendLine($"Nappe inférieure : // X {dr.Texts["Inf X"]} ; // Y {dr.Texts["Inf Y"]}");
        sb.AppendLine($"Nappe supérieure : // X {dr.Texts["Sup X"]} ; // Y {dr.Texts["Sup Y"]}");
        dr.Values["h_m"] = r.H; dr.Values["sigma_max_kPa"] = smax; dr.Values["q_adm_kPa"] = qadm; dr.Values["h_req_m"] = res.HRequired;
        res.ConcreteM3 = A * r.H;
        double AsOf(string t)
        {
            var m = System.Text.RegularExpressions.Regex.Match(t, @"\(([\d.,]+)\s*cm²/m\)");
            return m.Success && double.TryParse(m.Groups[1].Value.Replace(',', '.'), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double v) ? v : 0;
        }
        res.SteelKg = (AsOf(dr.Texts["Inf X"]) + AsOf(dr.Texts["Inf Y"]) + AsOf(dr.Texts["Sup X"]) + AsOf(dr.Texts["Sup Y"])) * A * 0.785;
        sb.AppendLine("Dispositions : béton de propreté 5 cm, enrobage ≥ 5 cm ; armatures de poinçonnement ou chapiteaux si requis ; radier supposé rigide (étude du radier souple sur ressorts non faite).");
        if (!dr.Ok) sb.AppendLine("ATTENTION : " + string.Join(" ", dr.Warnings));
        res.Report = sb.ToString();
        return res;
    }
}
