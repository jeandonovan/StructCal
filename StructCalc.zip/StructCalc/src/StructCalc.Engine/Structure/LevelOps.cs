using System.Globalization;
using System.Text.Json;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Gestion des niveaux (étages) : création, renommage, génération d'étages et copie du contenu d'un niveau vers un autre.</summary>
public static class LevelOps
{
    private const double Tol = 1e-3;

    public sealed class CopyReport
    {
        public int Columns, Beams, Slabs;
        public List<string> Notes { get; } = new();
        public string Summary => $"{Columns} poteau(x), {Beams} poutre(s), {Slabs} dalle(s) copié(s)" + (Notes.Count > 0 ? " - " + string.Join(" ", Notes) : ".");
    }

    private static T Clone<T>(T o) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(o))!;

    /// <summary>Si les niveaux étaient détectés automatiquement, les fige dans le modèle pour pouvoir les nommer / en ajouter.</summary>
    public static void Materialize(StructModel m, StructureInfo info)
    {
        if (m.Levels.Count > 0) return;
        foreach (var lv in info.Levels) m.Levels.Add(new StoreyDef { Name = lv.Name, Elevation = lv.Z });
    }

    public static bool AddLevel(StructModel m, StructureInfo info, string name, double z, out string msg)
    {
        Materialize(m, info);
        if (m.Levels.Any(l => Math.Abs(l.Elevation - z) < Tol)) { msg = $"Un niveau existe déjà à la cote {z:0.###} m."; return false; }
        if (string.IsNullOrWhiteSpace(name)) name = $"Niveau {m.Levels.Count}";
        m.Levels.Add(new StoreyDef { Name = name.Trim(), Elevation = Math.Round(z, 3) });
        m.Levels = m.Levels.OrderBy(l => l.Elevation).ToList();
        msg = $"Niveau « {name.Trim()} » ajouté à la cote {z:0.###} m.";
        return true;
    }

    public static bool Rename(StructModel m, StructureInfo info, int idx, string name, out string msg)
    {
        if (idx < 0 || idx >= info.Levels.Count) { msg = $"Niveau {idx} inexistant."; return false; }
        if (string.IsNullOrWhiteSpace(name)) { msg = "Nom vide."; return false; }
        double z = info.Levels[idx].Z;
        Materialize(m, info);
        var def = m.Levels.FirstOrDefault(l => Math.Abs(l.Elevation - z) < Tol);
        if (def == null) { msg = "Niveau introuvable dans le modèle."; return false; }
        string old = def.Name;
        def.Name = name.Trim();
        msg = $"Niveau {idx} renommé : « {old} » → « {def.Name} ».";
        return true;
    }

    /// <summary>Crée une série d'étages : « Base » à la cote de départ, puis RDC, R+1, R+2... tous les <paramref name="height"/> m (les niveaux existants sont remplacés).</summary>
    public static void BuildFloors(StructModel m, int count, double height, double baseZ = 0)
    {
        var list = new List<StoreyDef> { new() { Name = "Base", Elevation = Math.Round(baseZ, 3) } };
        for (int i = 1; i <= count; i++)
            list.Add(new StoreyDef { Name = i == 1 ? "RDC" : $"R+{i - 1}", Elevation = Math.Round(baseZ + i * height, 3) });
        m.Levels = list;
    }

    private static int NodeAt(StructModel m, double x, double y, double z)
    {
        var n = m.Nodes.FirstOrDefault(q => Math.Abs(q.X - x) < Tol && Math.Abs(q.Y - y) < Tol && Math.Abs(q.Z - z) < Tol);
        if (n != null) return n.Id;
        int id = m.Nodes.Count == 0 ? 1 : m.Nodes.Max(q => q.Id) + 1;
        m.Nodes.Add(new Node { Id = id, X = Math.Round(x, 6), Y = Math.Round(y, 6), Z = Math.Round(z, 6) });
        return id;
    }

    private static int AddCopy(StructModel m, Member src, int ni, int nj)
    {
        if (ni == nj || m.Members.Any(q => (q.NodeI == ni && q.NodeJ == nj) || (q.NodeI == nj && q.NodeJ == ni))) return -1;
        var c = Clone(src);
        c.Id = m.Members.Count == 0 ? 1 : m.Members.Max(q => q.Id) + 1;
        c.NodeI = ni; c.NodeJ = nj; c.ExternalId = "";
        m.Members.Add(c);
        foreach (var l in m.MemberLoads.Where(q => q.MemberId == src.Id).ToList())
        {
            var cl = Clone(l); cl.MemberId = c.Id; m.MemberLoads.Add(cl);
        }
        return c.Id;
    }

    /// <summary>Copie le contenu d'un niveau vers un autre. Poutres : translatées de la différence de cote. Poteaux : recréés entre le niveau inférieur
    /// de la destination et la destination (donc correctement même si les hauteurs d'étage diffèrent). Dalles dessinées : copiées avec leurs charges.</summary>
    public static CopyReport Copy(StructModel m, StructureInfo info, int src, int dst, bool columns, bool beams, bool slabs)
    {
        var rep = new CopyReport();
        if (src < 0 || src >= info.Levels.Count || dst < 0 || dst >= info.Levels.Count) { rep.Notes.Add("Niveau source ou destination inexistant."); return rep; }
        if (src == dst) { rep.Notes.Add("Source et destination identiques."); return rep; }
        var ls = info.Levels[src]; var ld = info.Levels[dst];
        double dz = ld.Z - ls.Z;
        var nodes = m.Nodes.ToDictionary(n => n.Id);

        if (beams)
            foreach (int id in ls.BeamIds.ToList())
            {
                var mem = m.Members.FirstOrDefault(q => q.Id == id);
                if (mem == null || !nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                int ni = NodeAt(m, a.X, a.Y, a.Z + dz), nj = NodeAt(m, b.X, b.Y, b.Z + dz);
                if (AddCopy(m, mem, ni, nj) > 0) rep.Beams++;
            }
        if (columns)
        {
            if (dst == 0) rep.Notes.Add("Poteaux non copiés : la destination est le niveau le plus bas (aucun niveau en dessous).");
            else
            {
                double zBelow = info.Levels[dst - 1].Z;
                foreach (int id in ls.ColumnIds.ToList())
                {
                    var mem = m.Members.FirstOrDefault(q => q.Id == id);
                    if (mem == null || !nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                    var top = a.Z >= b.Z ? a : b; var bot = a.Z >= b.Z ? b : a;
                    int ntop = NodeAt(m, top.X, top.Y, ld.Z), nbot = NodeAt(m, bot.X, bot.Y, zBelow);
                    if (AddCopy(m, mem, nbot, ntop) > 0) rep.Columns++;
                }
            }
        }
        if (slabs)
            foreach (var s in m.Slabs.Where(q => q.Placed && Math.Abs(q.Z - ls.Z) < Tol).ToList())
            {
                var c = Clone(s);
                int n = 1; while (m.Slabs.Any(q => q.Name == "D" + n)) n++;
                c.Name = "D" + n; c.Z = ld.Z;
                m.Slabs.Add(c);
                StoreyOps.SyncSlabLoads(m, c);          // charges G et Q recalculées à la cote de la dalle copiée
                rep.Slabs++;
            }
        if (rep.Columns + rep.Beams + rep.Slabs == 0 && rep.Notes.Count == 0) rep.Notes.Add("Rien à copier (ou déjà présent à la destination).");
        return rep;
    }
}
