namespace StructCalc.Engine.Structure;

/// <summary>Matrice symétrique définie positive en bande : stockage de la partie inférieure, factorisation de Cholesky et résolution.</summary>
public sealed class BandSpd
{
    private readonly int _n, _bw;
    private readonly double[] _k;

    public BandSpd(int n, int bw) { _n = n; _bw = bw; _k = new double[(long)n * (bw + 1)]; }

    private long Idx(int i, int j) => (long)i * (_bw + 1) + (_bw - (i - j));      // j ≤ i

    public void Add(int i, int j, double v)
    {
        if (j > i) (i, j) = (j, i);
        if (i - j > _bw) throw new InvalidOperationException("Largeur de bande insuffisante.");
        _k[Idx(i, j)] += v;
    }

    public double Diag(int i) => _k[Idx(i, i)];

    /// <summary>Bloque le ddl d : ligne et colonne annulées, diagonale = diag.</summary>
    public void Fix(int d, double diag)
    {
        for (int j = Math.Max(0, d - _bw); j <= d; j++) _k[Idx(d, j)] = 0;
        for (int i = d + 1; i <= Math.Min(_n - 1, d + _bw); i++) _k[Idx(i, d)] = 0;
        _k[Idx(d, d)] = diag;
    }

    public void Factor()
    {
        double dmax = 0; for (int i = 0; i < _n; i++) dmax = Math.Max(dmax, _k[Idx(i, i)]);
        for (int j = 0; j < _n; j++)
        {
            int i0 = Math.Max(0, j - _bw);
            double s = _k[Idx(j, j)];
            for (int k = i0; k < j; k++) { double l = _k[Idx(j, k)]; s -= l * l; }
            if (s <= 1e-12 * dmax) throw new InvalidOperationException("Dalle instable : vérifiez les appuis.");
            double ljj = Math.Sqrt(s); _k[Idx(j, j)] = ljj;
            for (int i = j + 1; i <= Math.Min(_n - 1, j + _bw); i++)
            {
                double t = _k[Idx(i, j)];
                int kk0 = Math.Max(i - _bw, 0);
                for (int k = Math.Max(kk0, i0); k < j; k++) t -= _k[Idx(i, k)] * _k[Idx(j, k)];
                _k[Idx(i, j)] = t / ljj;
            }
        }
    }

    public double[] Solve(double[] f)
    {
        var x = new double[_n];
        for (int i = 0; i < _n; i++)
        {
            double y = f[i];
            for (int k = Math.Max(0, i - _bw); k < i; k++) y -= _k[Idx(i, k)] * x[k];
            x[i] = y / _k[Idx(i, i)];
        }
        for (int i = _n - 1; i >= 0; i--)
        {
            double s = x[i];
            for (int k = i + 1; k <= Math.Min(_n - 1, i + _bw); k++) s -= _k[Idx(k, i)] * x[k];
            x[i] = s / _k[Idx(i, i)];
        }
        return x;
    }
}
