using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Résultat de la création des poutres de contour (et poteaux d'angle) d'une dalle.</summary>
public sealed record PerimeterResult(int Beams, int Columns, int Nodes, int Supports, string Text);

/// <summary>Complète le contour d'une dalle : poutres sur les bords qui n'en ont pas (découpées aux nœuds existants), et, si demandé,
/// poteaux sous les angles qui ne sont pas déjà portés, jusqu'au niveau le plus bas du modèle, avec encastrement en pied.
/// Sections reprises de la section la plus fréquente du modèle (sinon 25 x 40 cm pour les poutres, 25 x 25 cm pour les poteaux).</summary>
public static class SlabPerimeter
{
    private const double Tol = 2e-3;

    private static int NextNode(StructModel m) => m.Nodes.Count == 0 ? 1 : m.Nodes.Max(n => n.Id) + 1;
    private static int NextMember(StructModel m) => m.Members.Count == 0 ? 1 : m.Members.Max(q => q.Id) + 1;

    private static (double B, double H) CommonSection(StructModel m, MemberType type, double defB, double defH)
    {
        var g = m.Members.Where(x => x.Type == type && x.Kind == MaterialKind.ReinforcedConcrete && x.B > 0.05 && x.H > 0.05)
                         .GroupBy(x => (Math.Round(x.B, 3), Math.Round(x.H, 3))).OrderByDescending(q => q.Count()).FirstOrDefault();
        return g == null ? (defB, defH) : (g.Key.Item1, g.Key.Item2);
    }

    private static int NodeAt(StructModel m, double x, double y, double z, ref int created)
    {
        var n = m.Nodes.FirstOrDefault(q => Math.Abs(q.X - x) < Tol && Math.Abs(q.Y - y) < Tol && Math.Abs(q.Z - z) < Tol);
        if (n != null) return n.Id;
        int id = NextNode(m);
        m.Nodes.Add(new Node { Id = id, X = Math.Round(x, 6), Y = Math.Round(y, 6), Z = Math.Round(z, 6) });
        created++;
        return id;
    }

    /// <summary>Poutres du modèle (barres horizontales) au niveau z, avec leurs extrémités.</summary>
    private static List<(Node A, Node B)> BeamsAt(StructModel m, double z)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var res = new List<(Node, Node)>();
        foreach (var mem in m.Members)
        {
            if (mem.Type == MemberType.Column) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            if (Math.Abs(a.Z - z) > Tol || Math.Abs(b.Z - z) > Tol) continue;
            res.Add((a, b));
        }
        return res;
    }

    /// <summary>Crée les poutres manquantes sur le contour de la dalle (emprise recalée sur les axes de poutres existants).</summary>
    public static PerimeterResult Create(StructModel m, SlabPanel s, bool withColumns)
    {
        var (x0, x1, y0, y1) = SlabSnap.Extent(m, s);
        double z = s.Z;
        int createdNodes = 0, beams = 0, columns = 0, supports = 0;
        var (bb, bh) = CommonSection(m, MemberType.Beam, 0.25, 0.40);
        var (cb, ch) = CommonSection(m, MemberType.Column, 0.25, 0.25);

        var corners = new[] { (x0, y0), (x1, y0), (x1, y1), (x0, y1) };
        foreach (var corner in corners) NodeAt(m, corner.Item1, corner.Item2, z, ref createdNodes);          // les quatre angles existent

        // ---- poutres de rive : un bord à la fois, découpé aux nœuds situés sur la ligne
        for (int e = 0; e < 4; e++)
        {
            var (ax, ay) = corners[e]; var (bx, by) = corners[(e + 1) % 4];
            bool alongX = Math.Abs(ay - by) < Tol;
            double lo = alongX ? Math.Min(ax, bx) : Math.Min(ay, by), hi = alongX ? Math.Max(ax, bx) : Math.Max(ay, by);
            double fixedC = alongX ? ay : ax;
            var existing = BeamsAt(m, z).Select(t => alongX
                ? (ok: Math.Abs(t.A.Y - fixedC) < Tol && Math.Abs(t.B.Y - fixedC) < Tol, l: Math.Min(t.A.X, t.B.X), h: Math.Max(t.A.X, t.B.X))
                : (ok: Math.Abs(t.A.X - fixedC) < Tol && Math.Abs(t.B.X - fixedC) < Tol, l: Math.Min(t.A.Y, t.B.Y), h: Math.Max(t.A.Y, t.B.Y)))
                .Where(t => t.ok).ToList();
            // abscisses des nœuds de la ligne : angles + nœuds au même niveau situés sur le bord
            var stops = new SortedSet<double> { lo, hi };
            foreach (var n in m.Nodes)
            {
                if (Math.Abs(n.Z - z) > Tol) continue;
                double on = alongX ? n.Y : n.X, along = alongX ? n.X : n.Y;
                if (Math.Abs(on - fixedC) < Tol && along > lo + Tol && along < hi - Tol) stops.Add(Math.Round(along, 6));
            }
            var pos = stops.ToList();
            for (int k = 0; k + 1 < pos.Count; k++)
            {
                double p0 = pos[k], p1 = pos[k + 1];
                if (p1 - p0 < 0.05) continue;
                double covered = existing.Sum(t => Math.Max(0, Math.Min(t.h, p1) - Math.Max(t.l, p0)));
                if (covered >= 0.5 * (p1 - p0)) continue;                       // déjà porté par une poutre existante
                int n0 = NodeAt(m, alongX ? p0 : fixedC, alongX ? fixedC : p0, z, ref createdNodes);
                int n1 = NodeAt(m, alongX ? p1 : fixedC, alongX ? fixedC : p1, z, ref createdNodes);
                m.Members.Add(new Member { Id = NextMember(m), NodeI = n0, NodeJ = n1, Type = MemberType.Beam, B = bb, H = bh });
                beams++;
            }
        }

        // ---- poteaux d'angle jusqu'au niveau le plus bas
        if (withColumns)
        {
            var below = m.Nodes.Select(n => Math.Round(n.Z, 3)).Distinct().Where(q => q < z - 0.05).OrderByDescending(q => q).ToList();
            double zBase = below.Count > 0 ? below.Min() : z - 3.0;
            var levels = below.Count > 0 ? below : new List<double> { zBase };
            foreach (var c in corners)
            {
                bool carried = m.Members.Any(mem =>
                {
                    var a = m.Nodes.FirstOrDefault(q => q.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(q => q.Id == mem.NodeJ);
                    if (a == null || b == null) return false;
                    bool atXY = Math.Abs(a.X - c.Item1) < Tol && Math.Abs(a.Y - c.Item2) < Tol && Math.Abs(b.X - c.Item1) < Tol && Math.Abs(b.Y - c.Item2) < Tol;
                    return atXY && Math.Abs(a.Z - b.Z) > 0.05 && Math.Min(a.Z, b.Z) < z - 0.05 && Math.Max(a.Z, b.Z) > z - Tol;
                });
                if (carried) continue;
                int top = NodeAt(m, c.Item1, c.Item2, z, ref createdNodes);
                foreach (double lz in levels)
                {
                    int low = NodeAt(m, c.Item1, c.Item2, lz, ref createdNodes);
                    m.Members.Add(new Member { Id = NextMember(m), NodeI = low, NodeJ = top, Type = MemberType.Column, B = cb, H = ch });
                    columns++;
                    top = low;
                }
                if (!m.Supports.Any(q => q.NodeId == top)) { m.Supports.Add(new SupportDef { NodeId = top }); supports++; }
            }
        }

        StoreyOps.SyncSlabLoads(m, s);
        string txt = $"Dalle {s.Name} : {beams} poutre(s) de rive créée(s) ({bb * 100:0} x {bh * 100:0} cm)" +
                     (withColumns ? $", {columns} poteau(x) d'angle ({cb * 100:0} x {ch * 100:0} cm) avec {supports} encastrement(s) en pied" : "") +
                     $", {createdNodes} nœud(s) créé(s). Les sections sont des valeurs de départ : lancez le calcul avec « Optimiser les sections ».";
        return new PerimeterResult(beams, columns, createdNodes, supports, txt);
    }
}
