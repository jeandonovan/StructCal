using StructCalc.Core.Model;

namespace StructCalc.Engine.Structure;

/// <summary>Panneau élémentaire d'une dalle : rectangle limité par les poutres. Les indicateurs « In » disent quel bord est un appui intermédiaire
/// (continuité avec le panneau voisin).</summary>
public sealed record SlabCell(double X0, double Y0, double Lx, double Ly, bool XlIn, bool XhIn, bool YlIn, bool YhIn);

/// <summary>Découpe d'une dalle en panneaux selon les poutres qui la traversent : chaque panneau reporte ses charges sur SES poutres
/// (zones d'influence), au lieu de tout renvoyer sur le contour de la dalle.</summary>
public static class SlabCells
{
    private const double Tol = 2e-3, MinSide = 0.3, MinEdge = 0.05, MinCover = 0.9;

    public static List<SlabCell> Of(StructModel m, SlabPanel s)
    {
        var (x0, x1, y0, y1) = SlabSnap.Extent(m, s);          // dalle sur les faces des poutres : recalée sur leurs axes
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var alongY = new List<(double X, double Lo, double Hi)>();     // poutres // Y situées à x = X
        var alongX = new List<(double Y, double Lo, double Hi)>();     // poutres // X situées à y = Y
        foreach (var mem in m.Members)
        {
            if (mem.Type == MemberType.Column) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            if (Math.Abs(a.Z - s.Z) > Tol || Math.Abs(b.Z - s.Z) > Tol) continue;
            if (Math.Abs(a.X - b.X) < Tol && Math.Abs(a.Y - b.Y) > Tol) alongY.Add((a.X, Math.Min(a.Y, b.Y), Math.Max(a.Y, b.Y)));
            else if (Math.Abs(a.Y - b.Y) < Tol && Math.Abs(a.X - b.X) > Tol) alongX.Add((a.Y, Math.Min(a.X, b.X), Math.Max(a.X, b.X)));
        }
        var cx = Cuts(alongY, x0, x1, y0, y1);
        var cy = Cuts(alongX, y0, y1, x0, x1);
        var xs = new List<double> { x0 }; xs.AddRange(cx); xs.Add(x1);
        var ys = new List<double> { y0 }; ys.AddRange(cy); ys.Add(y1);
        var res = new List<SlabCell>();
        for (int i = 0; i < xs.Count - 1; i++)
            for (int j = 0; j < ys.Count - 1; j++)
                res.Add(new SlabCell(xs[i], ys[j], xs[i + 1] - xs[i], ys[j + 1] - ys[j], i > 0, i < xs.Count - 2, j > 0, j < ys.Count - 2));
        return res;
    }

    /// <summary>Positions (strictement à l'intérieur) où des poutres couvrent au moins 90 % de la dimension perpendiculaire de la dalle.</summary>
    private static List<double> Cuts(List<(double Pos, double Lo, double Hi)> beams, double lo, double hi, double perpLo, double perpHi)
    {
        var cuts = new List<double>();
        double need = MinCover * (perpHi - perpLo);
        foreach (var grp in beams.Where(b => b.Pos > lo + MinEdge && b.Pos < hi - MinEdge).GroupBy(b => Math.Round(b.Pos / Tol)))
        {
            double covered = 0, cur = perpLo;
            foreach (var iv in grp.OrderBy(t => t.Lo))
            {
                double a = Math.Max(Math.Max(iv.Lo, perpLo), cur), b = Math.Min(iv.Hi, perpHi);
                if (b > a) { covered += b - a; cur = b; }
            }
            if (covered >= need) cuts.Add(grp.Average(t => t.Pos));
        }
        cuts.Sort();
        var clean = new List<double>();
        foreach (var c in cuts) if (clean.Count == 0 || c - clean[^1] > MinSide) clean.Add(c);
        return clean;
    }
}
