using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Floors;

/// <summary>Poutre continue à section constante : équation des trois moments pour des charges uniformes par travée (charges alternées possibles).</summary>
public static class ContinuousBeam
{
    /// <summary>Moments sur appuis (négatifs = fibre supérieure tendue) pour des charges w[i] par travée, appuis de rive articulés (M = 0) ou semi-encastrés (rive = -k x M0 donné).</summary>
    public static double[] SupportMoments(double[] L, double[] w, double[]? edgeMoments = null)
    {
        int n = L.Length;
        var M = new double[n + 1];
        if (edgeMoments != null) { M[0] = edgeMoments[0]; M[n] = edgeMoments[1]; }
        if (n == 1) return M;
        int m = n - 1;                    // appuis intermédiaires inconnus : 1..n-1
        var a = new double[m]; var b = new double[m]; var c = new double[m]; var r = new double[m];
        for (int i = 1; i <= n - 1; i++)
        {
            int k = i - 1;
            a[k] = L[i - 1]; b[k] = 2 * (L[i - 1] + L[i]); c[k] = L[i];
            r[k] = -(w[i - 1] * Math.Pow(L[i - 1], 3) + w[i] * Math.Pow(L[i], 3)) / 4.0;
            if (i == 1) r[k] -= L[0] * M[0];
            if (i == n - 1) r[k] -= L[n - 1] * M[n];
        }
        // Thomas
        for (int i = 1; i < m; i++) { double f = a[i] / b[i - 1]; b[i] -= f * c[i - 1]; r[i] -= f * r[i - 1]; }
        var x = new double[m];
        x[m - 1] = r[m - 1] / b[m - 1];
        for (int i = m - 2; i >= 0; i--) x[i] = (r[i] - c[i] * x[i + 1]) / b[i];
        for (int i = 0; i < m; i++) M[i + 1] = x[i];
        return M;
    }

    public static double SpanMoment(double L, double w, double ml, double mr, double x) => w * x * (L - x) / 2 + ml * (1 - x / L) + mr * x / L;
}

public sealed class RibbedSpanResult
{
    public int Index { get; set; }
    public double L { get; set; }
    public double M0u { get; set; }
    public double M0s { get; set; }
    public double MtU { get; set; }
    public double MtS { get; set; }
    public double TuW { get; set; }
    public double TuE { get; set; }
    public double AsT { get; set; }
    public string BarsT { get; set; } = "";
    public bool TSection { get; set; }
}

public sealed class RibbedSupportResult
{
    public int Index { get; set; }
    public double MuU { get; set; }       // valeur absolue
    public double MuS { get; set; }
    public double AsA { get; set; }
    public string Bars { get; set; } = "";
}

public sealed class RibbedFloorResult
{
    public RibbedFloorDef Def { get; set; } = new();
    public string Method { get; set; } = "";
    public double G { get; set; }
    public double Q { get; set; }
    public double Alpha { get; set; }
    public double QuU { get; set; }
    public double QuS { get; set; }
    public List<RibbedSpanResult> Spans { get; } = new();
    public List<RibbedSupportResult> Supports { get; } = new();
    public double Tau { get; set; }
    public double TauLim { get; set; }
    public string Stirrups { get; set; } = "";
    public double StirrupSt { get; set; }
    public string Mesh { get; set; } = "";
    public double MeshAreaPerp { get; set; }
    public List<string> Checks { get; } = new();
    public List<string> Warnings { get; } = new();
    public bool Ok { get; set; } = true;
    public string Report { get; set; } = "";
    public double ConcreteM3PerM2 { get; set; }
    public double SteelKgPerM { get; set; }
}

public static class RibbedFloorDesigner
{
    // poids propre des planchers à corps creux (hourdis + poutrelles + dalle de compression), kN/m² : (hauteur hourdis, dalle de compression)
    private static readonly (double Hh, double H0, double G)[] Table =
    {
        (12, 4, 2.60), (16, 4, 2.85), (20, 4, 3.30), (20, 5, 3.50), (25, 5, 4.00), (30, 5, 4.15),
    };

    /// <summary>Poids propre du plancher (kN/m²) : valeurs usuelles du tableau ; dalle de compression plus épaisse = +25 kN/m³ x écart.</summary>
    public static double SelfWeight(double hourdisCm, double toppingCm)
    {
        foreach (var t in Table) if (Math.Abs(t.Hh - hourdisCm) < 0.01 && Math.Abs(t.H0 - toppingCm) < 0.01) return t.G;
        // valeur de base avec 4 cm de dalle, interpolée
        var pts = Table.Where(t => t.H0 == 4).Select(t => (t.Hh, t.G)).ToList();
        pts.Add((25, 3.75)); pts.Add((30, 3.90));
        pts = pts.OrderBy(p => p.Hh).ToList();
        double g;
        if (hourdisCm <= pts[0].Hh) g = pts[0].G;
        else if (hourdisCm >= pts[^1].Hh) g = pts[^1].G + (hourdisCm - pts[^1].Hh) * 0.05;
        else
        {
            int i = 0; while (hourdisCm > pts[i + 1].Hh) i++;
            g = pts[i].G + (pts[i + 1].G - pts[i].G) * (hourdisCm - pts[i].Hh) / (pts[i + 1].Hh - pts[i].Hh);
        }
        return g + (toppingCm - 4) * 0.25;
    }

    public static string Name(double hourdisCm, double toppingCm) => $"{hourdisCm:0}+{toppingCm:0}";

    private static bool ForfaitaireConditions(RibbedFloorDef d, double G, List<string> why)
    {
        bool ok = true;
        if (d.QKnM2 > Math.Min(2 * G, 5)) { ok = false; why.Add($"Q = {d.QKnM2:0.##} > min(2G ; 5) = {Math.Min(2 * G, 5):0.##} kN/m²"); }
        for (int i = 0; i + 1 < d.Spans.Count; i++)
        {
            double r = d.Spans[i] / d.Spans[i + 1];
            if (r < 0.8 - 1e-9 || r > 1.25 + 1e-9) { ok = false; why.Add($"rapport des portées L{i + 1}/L{i + 2} = {r:0.00} hors de [0,8 ; 1,25]"); }
        }
        if (d.Crack != CrackingClass.PeuPrejudiciable) { ok = false; why.Add("fissuration préjudiciable"); }
        return ok;
    }

    public static RibbedFloorResult Design(RibbedFloorDef d, IReinforcedConcreteCode rc, double fc28, double fe, DesignSettings? cfg = null)
    {
        var res = new RibbedFloorResult { Def = d };
        int n = d.Spans.Count;
        if (n == 0) { res.Warnings.Add("Aucune travée définie."); res.Ok = false; return res; }
        double b = d.SpacingM, b0 = d.WebCm / 100, h = d.TotalHeightCm / 100, h0 = d.ToppingCm / 100;
        double cover = d.CoverCm / 100, dd = h - cover;
        double G = SelfWeight(d.HourdisCm, d.ToppingCm) + d.GExtraKnM2, Q = d.QKnM2;
        res.G = G; res.Q = Q; res.Alpha = Q / (G + Q);
        double qu = (1.35 * G + 1.5 * Q) * b, qs = (G + Q) * b;
        res.QuU = qu; res.QuS = qs;
        var L = d.Spans.ToArray();

        // ---- sollicitations
        var why = new List<string>();
        bool forf = ForfaitaireConditions(d, G, why);
        double[] MtU = new double[n], MtS = new double[n], MsU = new double[n + 1], MsS = new double[n + 1];
        double[] TwU = new double[n], TeU = new double[n];
        double[] M0u = L.Select(l => qu * l * l / 8).ToArray(), M0s = L.Select(l => qs * l * l / 8).ToArray();
        if (forf)
        {
            res.Method = "méthode forfaitaire (BAEL B.6.2,2)";
            void Compute(double[] M0, double[] Mt, double[] Ms)
            {
                double a = res.Alpha;
                // moments sur appuis
                for (int i = 0; i <= n; i++)
                {
                    if (i == 0 || i == n)
                    {
                        double m0 = i == 0 ? M0[0] : M0[n - 1];
                        Ms[i] = d.EdgeRestrained ? 0.15 * m0 : 0;
                        continue;
                    }
                    double mm = Math.Max(M0[i - 1], M0[i]);
                    double k;
                    if (n == 2) k = 0.6;
                    else if (i == 1 || i == n - 1) k = 0.5;
                    else k = 0.4;
                    Ms[i] = k * mm;
                }
                for (int i = 0; i < n; i++)
                {
                    double mw = Ms[i], me = Ms[i + 1];
                    double m1 = Math.Max((1 + 0.3 * a) * M0[i], 1.05 * M0[i]) - (mw + me) / 2;
                    double m2 = (i == 0 || i == n - 1 ? 1.2 + 0.3 * a : 1 + 0.3 * a) * M0[i] / 2;
                    Mt[i] = Math.Max(m1, m2);
                }
            }
            Compute(M0u, MtU, MsU); Compute(M0s, MtS, MsS);
            // efforts tranchants
            for (int i = 0; i < n; i++)
            {
                double t0 = qu * L[i] / 2; TwU[i] = t0; TeU[i] = t0;
            }
            double kInner = n == 2 ? 1.15 : 1.1;
            if (n >= 2)
            {
                TeU[0] = kInner * qu * L[0] / 2; TwU[1] = kInner * qu * L[1] / 2;
                if (n >= 3) { TeU[n - 2] = 1.1 * qu * L[n - 2] / 2; TwU[n - 1] = 1.1 * qu * L[n - 1] / 2; }
                else { TwU[1] = kInner * qu * L[1] / 2; }
            }
        }
        else
        {
            res.Method = "poutre continue à charges alternées (équation des trois moments) - conditions de la méthode forfaitaire non remplies : " + string.Join(" ; ", why);
            // enveloppe de toutes les dispositions de Q (n <= 9 : toutes ; sinon alternées)
            void Envelope(double gF, double qF, double[] Mt, double[] Ms, double[]? Tw, double[]? Te)
            {
                var pats = new List<bool[]>();
                if (n <= 9) for (int mask = 0; mask < (1 << n); mask++) pats.Add(Enumerable.Range(0, n).Select(i => (mask & (1 << i)) != 0).ToArray());
                else
                {
                    pats.Add(Enumerable.Repeat(true, n).ToArray());
                    pats.Add(Enumerable.Range(0, n).Select(i => i % 2 == 0).ToArray()); pats.Add(Enumerable.Range(0, n).Select(i => i % 2 == 1).ToArray());
                    for (int j = 0; j + 1 < n; j++) pats.Add(Enumerable.Range(0, n).Select(i => i == j || i == j + 1).ToArray());
                }
                for (int i = 0; i < n; i++) Mt[i] = 0;
                for (int i = 0; i <= n; i++) Ms[i] = 0;
                if (Tw != null) for (int i = 0; i < n; i++) { Tw[i] = 0; Te![i] = 0; }
                foreach (var p in pats)
                {
                    var w = Enumerable.Range(0, n).Select(i => (gF * G + (p[i] ? qF * Q : 0)) * b).ToArray();
                    double[] edge = new double[2];
                    if (d.EdgeRestrained) { edge[0] = -0.15 * w[0] * L[0] * L[0] / 8; edge[1] = -0.15 * w[n - 1] * L[n - 1] * L[n - 1] / 8; }
                    var M = ContinuousBeam.SupportMoments(L, w, edge);
                    for (int i = 0; i <= n; i++) Ms[i] = Math.Max(Ms[i], -M[i]);
                    for (int i = 0; i < n; i++)
                    {
                        double best = 0; double xm = 0;
                        for (int s = 0; s <= 40; s++)
                        {
                            double x = L[i] * s / 40; double m = ContinuousBeam.SpanMoment(L[i], w[i], M[i], M[i + 1], x);
                            if (m > best) { best = m; xm = x; }
                        }
                        Mt[i] = Math.Max(Mt[i], best);
                        if (Tw != null)
                        {
                            // tranchant aux appuis : V0 + (M_i+1 - M_i)/L  (moments sagging-positive)
                            double v0 = w[i] * L[i] / 2, dv = (M[i + 1] - M[i]) / L[i];
                            Tw[i] = Math.Max(Tw[i], Math.Abs(v0 + dv)); Te![i] = Math.Max(Te[i], Math.Abs(-v0 + dv));
                        }
                        _ = xm;
                    }
                }
            }
            Envelope(1.35, 1.5, MtU, MsU, TwU, TeU);
            Envelope(1.0, 1.0, MtS, MsS, null, null);
        }

        // ---- armatures
        var secT = new RcRectSection(b, h, cover, cover);
        var secW = new RcRectSection(b0, h, cover, cover);
        double fbc = 0.85 * fc28 / 1.5;
        double mTable = b * h0 * fbc * (dd - h0 / 2) * 1000;      // kN.m (b,h0 en m ; fbc en MPa -> MN.m x 1000)
        double asRef = 0;
        for (int i = 0; i < n; i++)
        {
            var sr = new RibbedSpanResult { Index = i + 1, L = L[i], M0u = M0u[i], M0s = M0s[i], MtU = MtU[i], MtS = MtS[i], TuW = TwU[i], TuE = TeU[i] };
            double mu = Math.Max(MtU[i], 0), ms = Math.Max(MtS[i], 0);
            double asT;
            if (mu <= mTable)
            {
                var dt = rc.DesignBeamFlexure(secT, fc28, fe, mu, ms, d.Crack);
                asT = dt.Values["As_cm2"];
                if (!dt.Ok) { res.Warnings.AddRange(dt.Warnings); res.Ok = false; }
            }
            else
            {
                sr.TSection = true;
                double m1 = (b - b0) * h0 * fbc * (dd - h0 / 2) * 1000;                   // ailes
                double fsu = fe / 1.15;
                double as1 = m1 / 1000 / ((dd - h0 / 2) * fsu) * 1e4;
                var dw = rc.DesignBeamFlexure(secW, fc28, fe, mu - m1, ms * (mu - m1) / Math.Max(mu, 1e-9), d.Crack);
                asT = as1 + dw.Values["As_cm2"];
                if (!dw.Ok) { res.Warnings.AddRange(dw.Warnings); res.Ok = false; }
            }
            sr.AsT = asT; sr.BarsT = Bars(asT, d, cfg); asRef = Math.Max(asRef, asT);
            res.Spans.Add(sr);
        }
        for (int i = 0; i <= n; i++)
        {
            var sp = new RibbedSupportResult { Index = i + 1, MuU = Math.Abs(MsU[i]), MuS = Math.Abs(MsS[i]) };
            if (sp.MuU > 1e-9)
            {
                var da = rc.DesignBeamFlexure(secW, fc28, fe, sp.MuU, sp.MuS, d.Crack);
                sp.AsA = da.Values["As_cm2"];
                if (!da.Ok) { res.Warnings.AddRange(da.Warnings); res.Ok = false; }
            }
            sp.Bars = sp.AsA > 0 ? Bars(sp.AsA, d, cfg) : "-";
            res.Supports.Add(sp);
        }

        // ---- effort tranchant
        double vmax = Math.Max(TwU.Max(), TeU.Max());
        var dsh = rc.DesignBeamShear(secW, fc28, fe, vmax, d.Crack);
        res.Tau = dsh.Values["tau_u"]; res.TauLim = dsh.Values["tau_lim"];
        if (!dsh.Ok) { res.Ok = false; res.Warnings.AddRange(dsh.Warnings); }
        double phiL = RebarDiaOf(res.Spans.Max(s => s.AsT) > 0 ? res.Spans.First(s => s.AsT == res.Spans.Max(q => q.AsT)).BarsT : "10");
        double phiT = Math.Floor(Math.Min(Math.Min(h * 1000 / 35, d.WebCm * 10 / 10), phiL));
        phiT = phiT >= 8 ? 8 : phiT >= 6 ? 6 : 6;
        double stMax = Math.Min(0.9 * dd * 100, 40);
        double atSt = dsh.Values["At_over_st_cm2_per_m"];
        var stir = RebarSelector.Stirrups(atSt, stMax, (int)phiT, cfg);
        res.Stirrups = $"cadre HA{stir.Dia} (2 brins)"; res.StirrupSt = Math.Floor(stir.SpacingCm);
        // compression de la bielle au droit des appuis : 2 Tu / (b0 0,9 d) <= 0,8 fc28 / gamma_b
        double sbc = 2 * vmax / 1000 / (b0 * 0.9 * dd);
        double sbcLim = 0.8 * fc28 / 1.5;
        res.Checks.Add($"Bielle d'about : σbc = {sbc:0.00} MPa ≤ {sbcLim:0.00} MPa → {(sbc <= sbcLim ? "vérifié" : "NON vérifié")}");
        if (sbc > sbcLim) { res.Ok = false; res.Warnings.Add("Compression de la bielle d'about excessive : augmenter b0 ou h."); }

        // ---- treillis soudé de la dalle de compression (BAEL B.6.8,423)
        double l = b * 100;
        double aPerp = 4 * l / fe;
        double aPar = aPerp / 2;
        res.MeshAreaPerp = aPerp;
        string mesh = "";
        foreach (var (dia, sp) in new[] { (5, 20), (5, 15), (6, 20), (6, 15), (7, 15), (8, 15) })
        {
            double a = RebarSelector.Area(dia) * 100 / sp;
            if (a >= aPerp) { mesh = $"TS Ø{dia} maille {sp} x {(dia == 5 ? 30 : 20)} cm (A⊥ ≥ {aPerp:0.00} cm²/m ; A// ≥ {aPar:0.00} cm²/m)"; break; }
        }
        res.Mesh = mesh == "" ? $"TS à dimensionner : A⊥ ≥ {aPerp:0.00} cm²/m" : mesh;

        // ---- vérifications de service
        double lmax = L.Max();
        bool c1 = h / lmax >= 1 / 22.5;
        double mtMax = MtS.Max(), m0Max = M0s.Max();
        bool c2 = h / lmax >= mtMax / (15 * m0Max);
        double rho = asRef / (b0 * 100 * dd * 100);
        bool c3 = rho <= 3.6 / fe;
        res.Checks.Add($"Flèche : h/L = 1/{1 / (h / lmax):0.0} ≥ 1/22,5 → {(c1 ? "vérifié" : "NON vérifié")} ; h/L ≥ Mt/(15 M0) = {mtMax / (15 * m0Max):0.0000} → {(c2 ? "vérifié" : "NON vérifié")} ; As/(b0 d) = {rho:0.0000} ≤ 3,6/fe = {3.6 / fe:0.0000} → {(c3 ? "vérifié" : "NON vérifié")}");
        if (!(c1 && c2 && c3)) res.Warnings.Add("Les conditions de dispense de calcul de la flèche ne sont pas toutes remplies : calculer la flèche ou augmenter la hauteur du plancher.");
        res.Checks.Add($"Épaisseur de la dalle de compression : {d.ToppingCm:0} cm {(d.ToppingCm >= 4 ? "(≥ 4 cm)" : "(< 4 cm : NON conforme)")}");
        if (d.ToppingCm < 4) { res.Ok = false; res.Warnings.Add("Dalle de compression inférieure à 4 cm."); }
        res.Checks.Add($"Contrainte tangente : τu = {res.Tau:0.00} MPa ≤ {res.TauLim:0.00} MPa → {(res.Tau <= res.TauLim ? "vérifié" : "NON vérifié")}");

        // ---- quantités (par mètre carré de plancher)
        res.ConcreteM3PerM2 = h0 + (b0 * (h - h0)) / b;
        res.SteelKgPerM = (res.Spans.Sum(s => s.AsT * s.L) + res.Supports.Sum(s => s.AsA * 0.3 * L.Average() * 2)) * 0.785 / Math.Max(L.Sum(), 1e-9);
        res.Report = Build(res);
        if (res.Warnings.Count > 0 && !res.Warnings.All(w => w.StartsWith("Les conditions de dispense"))) res.Ok = false;
        return res;
    }

    private static double RebarDiaOf(string bars)
    {
        int i = bars.IndexOf("HA", StringComparison.Ordinal);
        if (i < 0) return 10;
        string s = new string(bars.Skip(i + 2).TakeWhile(char.IsDigit).ToArray());
        return double.TryParse(s, out double v) ? v : 10;
    }

    private static string Bars(double asCm2, RibbedFloorDef d, DesignSettings? cfg)
    {
        // poutrelles : 1 ou 2 barres (ou plus) de diamètre 8 à 20
        foreach (int dia in new[] { 8, 10, 12, 14, 16, 20 })
            for (int n = 1; n <= 4; n++)
                if (n * RebarSelector.Area(dia) >= asCm2 - 1e-9 && (n <= 2 || dia >= 12)) return $"{n}HA{dia} ({n * RebarSelector.Area(dia):0.00} cm²)";
        return $"{Math.Ceiling(asCm2 / RebarSelector.Area(20)):0}HA20";
    }

    public static string Build(RibbedFloorResult r)
    {
        var d = r.Def; var sb = new StringBuilder();
        sb.AppendLine($"PLANCHER À CORPS CREUX {d.Name} - {Name(d.HourdisCm, d.ToppingCm)} (h = {d.TotalHeightCm:0} cm), entraxe {d.SpacingM:0.00} m, b0 = {d.WebCm:0} cm");
        sb.AppendLine($"Travées : {string.Join(" ; ", d.Spans.Select(x => x.ToString("0.00")))} m");
        sb.AppendLine($"Charges : G = {r.G:0.00} kN/m² (poids du plancher {SelfWeight(d.HourdisCm, d.ToppingCm):0.00} + revêtements/cloisons {d.GExtraKnM2:0.00}) ; Q = {r.Q:0.00} kN/m² ; α = Q/(G+Q) = {r.Alpha:0.000}");
        sb.AppendLine($"Par poutrelle : qu = (1,35G + 1,5Q) x {d.SpacingM:0.00} = {r.QuU:0.000} kN/m ; qser = {r.QuS:0.000} kN/m");
        sb.AppendLine($"Méthode : {r.Method}");
        sb.AppendLine();
        sb.AppendLine("Travées :   L (m)   M0u    Mt,u    Mt,ser   Tw      Te      As (cm²)   Armatures");
        foreach (var s in r.Spans)
            sb.AppendLine($"  {s.Index,-8}{s.L,6:0.00}{s.M0u,8:0.00}{s.MtU,8:0.00}{s.MtS,9:0.00}{s.TuW,8:0.0}{s.TuE,8:0.0}{s.AsT,9:0.00}   {s.BarsT}{(s.TSection ? "  (section en T)" : "")}");
        sb.AppendLine();
        sb.AppendLine("Appuis :    |Ma,u|  |Ma,ser|  As (cm²)  Armatures (chapeaux)");
        foreach (var s in r.Supports)
            sb.AppendLine($"  {s.Index,-8}{s.MuU,8:0.00}{s.MuS,9:0.00}{s.AsA,10:0.00}   {s.Bars}");
        sb.AppendLine();
        sb.AppendLine($"Effort tranchant : τu = {r.Tau:0.00} MPa (≤ {r.TauLim:0.00}) ; {r.Stirrups} espacés de {r.StirrupSt:0} cm");
        sb.AppendLine($"Dalle de compression : {r.Mesh}");
        foreach (var c in r.Checks) sb.AppendLine("  - " + c);
        foreach (var w in r.Warnings) sb.AppendLine("ATTENTION : " + w);
        sb.AppendLine();
        sb.AppendLine("Dispositions : poutrelles préfabriquées précontraintes ou BA ; aciers de chapeaux sur appuis de longueur ≈ 0,25 L (rive : 0,2 L) ; appuis de rive : chapeaux ≥ 0,15 M0.");
        return sb.ToString();
    }
}
