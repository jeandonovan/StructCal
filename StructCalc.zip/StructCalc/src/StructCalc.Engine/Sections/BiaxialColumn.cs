using StructCalc.Core;

namespace StructCalc.Engine.Sections;

/// <summary>Sollicitation d'un poteau : effort normal (kN, compression positive) et moments du premier ordre (kN·m, valeurs absolues) autour des deux axes.
/// My : autour de l'axe de largeur b (profondeur h) ; Mz : autour de l'axe de profondeur b.</summary>
public readonly record struct BiaxialDemand(double N, double My, double Mz);

public sealed class BiaxialResult
{
    public double Util = 0, Exponent = 1, NRd, MRdY, MRdZ, MEdY, MEdZ, NRatio;
    public bool Ok => Util <= 1.0 + 1e-9;
    public string Text = "";
}

/// <summary>Flexion composée déviée d'un poteau rectangulaire (EC2 5.8.9 : (MEdz/MRdz)^a + (MEdy/MRdy)^a ≤ 1), armatures réparties sur le pourtour.
/// Les moments résistants viennent de la méthode des fibres (compatibilité des déformations) dans chaque direction, à N constant.</summary>
public static class BiaxialColumn
{
    /// <summary>Exposant a : 1,0 si NEd/NRd ≤ 0,1 ; 1,5 à 0,7 ; 2,0 à 1,0 (interpolation linéaire).</summary>
    public static double Exponent(double nRatio) =>
        nRatio <= 0.1 ? 1.0 : nRatio >= 1.0 ? 2.0 : nRatio <= 0.7 ? 1.0 + 0.5 * (nRatio - 0.1) / 0.6 : 1.5 + 0.5 * (nRatio - 0.7) / 0.3;

    /// <summary>Nombre de barres du pourtour selon la taille de la section.</summary>
    public static int BarCount(double b, double h) => Math.Max(b, h) <= 0.45 ? 8 : Math.Max(b, h) <= 0.70 ? 12 : 16;

    /// <summary>Barres réparties sur le pourtour (4 angles obligatoires, nombre pair), x dans [0, b], y dans [0, h] ; aire totale asTotCm2.</summary>
    public static List<BarGroup> Ring(double b, double h, int n, double asTotCm2, double d1)
    {
        int ne = Math.Max(4, n % 2 == 0 ? n : n + 1);
        double a = asTotCm2 / ne;
        int extra = ne / 2 - 2;
        int ax = (int)Math.Round(extra * b / (b + h)), ay = extra - ax;
        var bars = new List<BarGroup>();
        for (int i = 0; i <= ax + 1; i++)
        {
            double x = d1 + (b - 2 * d1) * i / (ax + 1);
            bars.Add(new BarGroup(x, d1, a)); bars.Add(new BarGroup(x, h - d1, a));
        }
        for (int j = 1; j <= ay; j++)
        {
            double y = d1 + (h - 2 * d1) * j / (ay + 1);
            bars.Add(new BarGroup(d1, y, a)); bars.Add(new BarGroup(b - d1, y, a));
        }
        return bars;
    }

    private static List<(double N, double M)> CurveOf(double b, double h, List<BarGroup> bars, Mat mat) =>
        FiberSection.Curve(new SectionGeom { Shape = SectionShape.Rectangle, B = b, H = h }, bars, mat);

    /// <summary>Pire sollicitation de la liste pour la section b x h, As total (cm²) et d1 (distance bord-axe des barres, m). lf = longueur de flambement (m).</summary>
    public static BiaxialResult Evaluate(double b, double h, double asTotCm2, double d1, Mat mat, double lf, IReadOnlyList<BiaxialDemand> demands, double alphaPhi = 1.4)
    {
        int n = BarCount(b, h);
        var barsY = Ring(b, h, n, asTotCm2, d1);
        var barsZ = barsY.Select(g => new BarGroup(g.Y, g.X, g.AreaCm2)).ToList();         // axe permuté : profondeur b
        var cy = CurveOf(b, h, barsY, mat);
        var cz = CurveOf(h, b, barsZ, mat);
        double nrd = b * h * mat.Fcd * 1000.0 + asTotCm2 * 1e-4 * mat.Fyd * 1000.0;
        double ea = Math.Max(0.02, lf / 250.0);
        BiaxialResult? worst = null;
        foreach (var d in demands)
        {
            if (d.N <= 0) continue;
            double e2y = 3 * lf * lf * (2 + alphaPhi) / (1e4 * h), e2z = 3 * lf * lf * (2 + alphaPhi) / (1e4 * b);
            bool eaOnY = d.My / h >= d.Mz / b;                                             // imperfection dans la direction la plus défavorable seulement
            double medY = d.My + d.N * (e2y + (eaOnY ? ea : 0)), medZ = d.Mz + d.N * (e2z + (eaOnY ? 0 : ea));
            double mry = FiberSection.MomentAt(cy, d.N), mrz = FiberSection.MomentAt(cz, d.N);
            double ratio = d.N / nrd, a = Exponent(ratio);
            double u = (mry <= 1e-9 ? (medY > 1e-9 ? 99 : 0) : Math.Pow(medY / mry, a)) + (mrz <= 1e-9 ? (medZ > 1e-9 ? 99 : 0) : Math.Pow(medZ / mrz, a));
            if (worst == null || u > worst.Util)
                worst = new BiaxialResult { Util = u, Exponent = a, NRd = nrd, MRdY = mry, MRdZ = mrz, MEdY = medY, MEdZ = medZ, NRatio = ratio };
        }
        worst ??= new BiaxialResult { NRd = nrd };
        worst.Text = $"Flexion déviée EC2 5.8.9 : NEd/NRd = {worst.NRatio:0.00}, a = {worst.Exponent:0.00} ; MEdy/MRdy = {worst.MEdY:0.0}/{worst.MRdY:0.0}, MEdz/MRdz = {worst.MEdZ:0.0}/{worst.MRdZ:0.0} kN·m -> taux {worst.Util:0.00}";
        return worst;
    }

    /// <summary>Plus petite section d'acier (cm²) dans [asLo, asHi] qui vérifie la flexion déviée ; asHi avec Ok = false si même asHi ne suffit pas.</summary>
    public static double RequiredAs(double b, double h, double asLo, double asHi, double d1, Mat mat, double lf, IReadOnlyList<BiaxialDemand> demands, out BiaxialResult result)
    {
        result = Evaluate(b, h, asLo, d1, mat, lf, demands);
        if (result.Ok) return asLo;
        var top = Evaluate(b, h, asHi, d1, mat, lf, demands);
        if (!top.Ok) { result = top; return asHi; }
        double lo = asLo, hi = asHi; var best = top;
        for (int k = 0; k < 14; k++)
        {
            double mid = (lo + hi) / 2;
            var r = Evaluate(b, h, mid, d1, mat, lf, demands);
            if (r.Ok) { hi = mid; best = r; } else lo = mid;
        }
        result = best;
        return hi;
    }
}
