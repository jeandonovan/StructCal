using System.Text;
using StructCalc.Core;

namespace StructCalc.Engine.Sections;

public sealed class ColumnSectionInput
{
    public SectionShape Shape = SectionShape.Rectangle;      // Rectangle, Circle, Tee, Ell
    /// <summary>Rectangle : B x H ; cercle : B = diamètre ; T et L : B = table, Bw = âme, Hf = épaisseur de table.</summary>
    public double B = 0.30, H = 0.30, Bw = 0.30, Hf = 0.20;
    public double Nu = 1000, Mu = 40;                         // kN (compression), kN·m (1er ordre, autour de l'axe horizontal ; signe négatif = fibre supérieure tendue)
    public double MuZ = 0;                                     // moment du 1er ordre dans l'autre direction (kN·m) : flexion déviée EC2 5.8.9 (section rectangulaire)
    public double Lf = 3.0;                                    // longueur de flambement (m)
    public double Alpha = 0.7, Phi = 2.0;                      // Mg/(Mg+Mq) et rapport de fluage
    public double Dprime = 0.05;
    public double Fc = 25, Fe = 500;
    public int BarsCircle = 8;
}

public sealed class ColumnSectionResult
{
    public SectionGeom Geom = new();
    public double Area, Lambda, E1, Ea, E2, MTot, MRes, N0, AsReq, AsMin, AsMax, AsUsed;
    public RebarChoice? Bars;
    public List<BarGroup> BarPositions = new();
    public int TieDia; public double TieSpacingCm;
    public double BiaxUtil;                                     // taux de la vérification en flexion déviée (0 = non demandée)
    public bool Ok = true;
    public List<string> Warnings = new();
    public string Report = "";
}

/// <summary>Poteau rectangulaire, circulaire, en T ou en L sous compression et flexion : excentricités (accidentelle, second ordre forfaitaire), armatures par compatibilité des déformations.</summary>
public static class ColumnSectionDesigner
{
    public static List<BarGroup> Layout(SectionGeom g, double asTotCm2, int n, double dPrime)
    {
        var bars = new List<BarGroup>();
        if (g.Shape == SectionShape.Circle)
        {
            double r = g.B / 2, rb = r - dPrime, a = asTotCm2 / n;
            for (int i = 0; i < n; i++)
            {
                double th = 2 * Math.PI * i / n + Math.PI / n;
                bars.Add(new BarGroup(r + rb * Math.Sin(th), r - rb * Math.Cos(th), a));
            }
        }
        else
        {
            double h = g.Height;
            bars.Add(new BarGroup(g.B / 2, dPrime, asTotCm2 / 2));
            bars.Add(new BarGroup(g.B / 2, h - dPrime, asTotCm2 / 2));
        }
        return bars;
    }

    private static double Capacity(SectionGeom g, double asTot, int n, double dPrime, Mat mat, double nu)
    {
        var curve = FiberSection.Curve(g, Layout(g, asTot, n, dPrime), mat);
        return FiberSection.MomentAt(curve, nu);
    }

    public static ColumnSectionResult Design(ColumnSectionInput p)
    {
        var r = new ColumnSectionResult();
        var mat = new Mat { Fc = p.Fc, Fe = p.Fe };
        var g = new SectionGeom { Shape = p.Shape, B = p.B, H = p.Shape == SectionShape.Circle ? p.B : (p.Shape == SectionShape.Rectangle ? p.H : p.H), Bw = p.Bw, Hf = p.Hf, Flip = p.Mu < 0 };
        r.Geom = g;
        double a = g.Area, h = g.Height, inertia = g.Inertia, i = Math.Sqrt(inertia / a);
        r.Area = a;
        var sb = new StringBuilder();
        string name = p.Shape switch { SectionShape.Circle => $"POTEAU CIRCULAIRE  D = {p.B * 100:0} cm", SectionShape.Tee => $"POTEAU EN T  table {p.B * 100:0} x {p.Hf * 100:0} cm, âme {p.Bw * 100:0} cm, h = {p.H * 100:0} cm", SectionShape.Ell => $"POTEAU EN L  table {p.B * 100:0} x {p.Hf * 100:0} cm, âme {p.Bw * 100:0} cm, h = {p.H * 100:0} cm", _ => $"POTEAU RECTANGULAIRE  {p.B * 100:0} x {p.H * 100:0} cm" };
        sb.AppendLine(name);
        sb.AppendLine($"Section : A = {a * 1e4:0} cm², i = {i * 100:0.0} cm ; béton fc28 = {p.Fc:0} MPa (fbu = {mat.Fcd:0.00}), acier fe = {p.Fe:0} MPa");
        if (p.Nu <= 0) { r.Ok = false; r.Warnings.Add("Poteau comprimé attendu (Nu > 0) : pour une traction, utilisez l'assistant de poutre ou vérifiez les efforts."); }
        r.Lambda = p.Lf / i;
        sb.AppendLine($"Élancement λ = lf / i = {p.Lf:0.00} / {i:0.000} = {r.Lambda:0.0}");

        // excentricités (BAEL B.8 : méthode forfaitaire)
        double nu = Math.Max(p.Nu, 1e-6);
        r.E1 = Math.Abs(p.Mu) / nu; r.Ea = Math.Max(0.02, p.Lf / 250.0);
        r.E2 = 3 * p.Lf * p.Lf * (2 + p.Alpha * p.Phi) / (10000.0 * h);
        double lamLim = Math.Max(50, Math.Min(67 * (r.E1 + r.Ea) / h, 100));
        if (r.Lambda > lamLim) { r.Ok = false; r.Warnings.Add($"λ = {r.Lambda:0} > {lamLim:0} : méthode forfaitaire non applicable, augmentez la section ou réduisez lf."); }
        if (r.Lambda > 70) { r.Ok = false; r.Warnings.Add("λ > 70 : poteau trop élancé."); }
        r.MTot = Math.Max(Math.Abs(p.Mu), nu * (r.E1 + r.Ea + r.E2));
        sb.AppendLine($"Excentricités : e1 = Mu/Nu = {r.E1 * 100:0.0} cm ; accidentelle ea = max(2 cm ; lf/250) = {r.Ea * 100:0.0} cm ; 2e ordre e2 = 3 lf²(2+αφ)/(10⁴ h) = {r.E2 * 100:0.0} cm");
        sb.AppendLine($"Moment de calcul M = Nu x (e1 + ea + e2) = {p.Nu:0} x {(r.E1 + r.Ea + r.E2) * 100:0.0} cm = {r.MTot:0.0} kN·m");

        // armatures
        double perim = g.Perimeter;
        r.AsMin = Math.Max(4.0 * perim, 0.002 * a * 1e4);       // cm²
        r.AsMax = 0.05 * a * 1e4;
        int nb = p.Shape == SectionShape.Circle ? Math.Max(6, p.BarsCircle) : 2;
        double lo = 0, hi = r.AsMax;
        double mHi = Capacity(g, hi, nb, p.Dprime, mat, p.Nu);
        double asReq;
        if (mHi < r.MTot)
        {
            asReq = hi; r.Ok = false;
            r.Warnings.Add($"Section insuffisante : même avec 5 % d'acier le moment résistant ({mHi:0.#} kN·m) reste inférieur à M = {r.MTot:0.#} kN·m (augmentez la section ou la classe du béton).");
        }
        else
        {
            for (int k = 0; k < 40; k++)
            {
                double mid = (lo + hi) / 2;
                if (Capacity(g, Math.Max(mid, 1e-6), nb, p.Dprime, mat, p.Nu) >= r.MTot) hi = mid; else lo = mid;
            }
            asReq = hi;
        }
        r.AsReq = asReq;
        double asNeed = Math.Max(asReq, r.AsMin);
        bool biax = Math.Abs(p.MuZ) > 1e-9 && p.Shape == SectionShape.Rectangle && p.Nu > 0;
        string biaxNote = "";
        if (biax)
        {
            var dem = new[] { new BiaxialDemand(p.Nu, Math.Abs(p.Mu), Math.Abs(p.MuZ)) };
            double asBi = BiaxialColumn.RequiredAs(p.B, p.H, asNeed, Math.Max(asNeed, r.AsMax), p.Dprime, mat, p.Lf, dem, out var bres);
            biaxNote = bres.Text;
            if (!bres.Ok) { r.Ok = false; r.Warnings.Add("Flexion déviée : section insuffisante même avec 5 % d'acier (" + bres.Text + ")."); }
            asNeed = Math.Max(asNeed, asBi);
        }
        var choice = RebarSelector.ForColumn(asNeed);
        if (p.Shape == SectionShape.Circle)
        {
            int n = Math.Max(6, choice.Count);
            int dia = choice.Diameter;
            while (n * RebarSelector.Area(dia) < asNeed - 1e-9) dia = NextDia(dia);
            choice = new RebarChoice(n, dia, n * RebarSelector.Area(dia));
            nb = n;
        }
        r.Bars = choice; r.AsUsed = choice.AreaCm2;
        if (biax)
        {
            var fin = BiaxialColumn.Evaluate(p.B, p.H, choice.AreaCm2, p.Dprime, mat, p.Lf, new[] { new BiaxialDemand(p.Nu, Math.Abs(p.Mu), Math.Abs(p.MuZ)) });
            r.BiaxUtil = fin.Util; biaxNote = fin.Text;
            if (!fin.Ok) { r.Ok = false; r.Warnings.Add("Flexion déviée non vérifiée avec les barres choisies : augmentez le diamètre ou la section."); }
        }
        r.BarPositions = Layout(g, choice.AreaCm2, p.Shape == SectionShape.Circle ? choice.Count : 2, p.Dprime);
        var curve = FiberSection.Curve(g, r.BarPositions, mat);
        r.MRes = FiberSection.MomentAt(curve, p.Nu); r.N0 = FiberSection.N0(curve);
        sb.AppendLine();
        sb.AppendLine($"ARMATURES  As,min = max(4 cm²/m de périmètre ; 0,2 % B) = {r.AsMin:0.0} cm² ; As,max = 5 % B = {r.AsMax:0.0} cm²");
        sb.AppendLine($"   As nécessaire par compatibilité des déformations = {asReq:0.0} cm²");
        sb.AppendLine($"   Choix : {choice.Label} = {choice.AreaCm2:0.0} cm² ({choice.AreaCm2 / (a * 1e4) * 100:0.00} % de B)" + (p.Shape == SectionShape.Circle ? ", régulièrement réparties sur le cercle" : ", moitié sur chaque face extrême"));
        sb.AppendLine($"   Moment résistant à Nu = {p.Nu:0} kN : MRd = {r.MRes:0.0} kN·m pour M = {r.MTot:0.0} kN·m (taux {(r.MRes > 0 ? r.MTot / r.MRes : 99):0.00}) ; Nrd,max = {r.N0:0} kN");
        if (biax) sb.AppendLine("   " + biaxNote + " - armatures à répartir sur tout le pourtour (barres d'angle + faces).");
        if (r.MRes < r.MTot - 1e-6) { r.Ok = false; r.Warnings.Add("Le choix de barres ne couvre pas le moment : augmentez le diamètre ou la section."); }
        if (choice.AreaCm2 > r.AsMax + 1e-9) { r.Ok = false; r.Warnings.Add("Pourcentage d'acier supérieur à 5 %."); }

        // armatures transversales (BAEL A.8.1,3)
        int tie = Math.Max(6, (int)Math.Ceiling(choice.Diameter / 3.0 / 2.0) * 2);
        double sp = Math.Min(Math.Min(15 * choice.Diameter / 10.0, 40), (p.Shape == SectionShape.Circle ? p.B : Math.Min(p.B, p.Shape == SectionShape.Rectangle ? p.H : p.Bw)) * 100 + 10);
        r.TieDia = tie; r.TieSpacingCm = Math.Floor(sp);
        sb.AppendLine($"ARMATURES TRANSVERSALES  {(p.Shape == SectionShape.Circle ? "cerces ou spirale" : "cadres")} HA{tie}, espacement ≤ min(15 φl ; 40 cm ; a + 10 cm) = {r.TieSpacingCm:0} cm");
        if (p.Shape == SectionShape.Tee || p.Shape == SectionShape.Ell)
            sb.AppendLine("NB : section en T ou en L - flexion plane dans le plan de l'âme ; vérifiez séparément la flexion dans l'autre direction.");
        foreach (var w in r.Warnings) sb.AppendLine("ATTENTION : " + w);
        r.Report = sb.ToString();
        return r;
    }

    private static int NextDia(int d) => d switch { <= 12 => 14, 14 => 16, 16 => 20, 20 => 25, 25 => 32, _ => 40 };
}
