using System.Text;
using StructCalc.Core;

namespace StructCalc.Engine.Sections;

public enum SpanPosition { Isostatic, EndSpan, InteriorSpan, Cantilever }

public enum FlangeRule { Ec2, Bael }

public sealed class BeamSectionInput
{
    public SectionShape Shape = SectionShape.Rectangle;      // Rectangle, Tee, Ell
    public double Bw = 0.30, H = 0.50, Hf = 0.15;
    /// <summary>Demi-distances libres jusqu'aux poutres voisines (m) : bi côté gauche et droit de l'âme. Pour un L, seul le côté droit compte.</summary>
    public double BiLeft = 1.0, BiRight = 1.0;
    /// <summary>Largeur de table imposée (m), 0 = calculée.</summary>
    public double BImposed;
    public double Span = 6.0;
    public SpanPosition Position = SpanPosition.EndSpan;
    public FlangeRule Rule = FlangeRule.Ec2;
    public double MuSag = 150, MuHog = 0, Vu = 120, MserSag = 0;      // kN·m, kN
    public double Dprime = 0.05;                                       // bord -> axe des armatures (m)
    public double Fc = 25, Fe = 500;
    public CrackingClass Crack = CrackingClass.PeuPrejudiciable;
}

public sealed class BeamSectionResult
{
    public SectionGeom Geom = new();
    public double Beff, L0, D;
    public double AsBottom, AsTop, AsMin;                  // cm²
    public RebarChoice? Bottom, Top;
    public int StirDia; public double StirSpacingCm;
    public double TauU, TauLim;
    public double SigmaBc, SigmaS, SigmaBcLim, SigmaSLim;
    public bool Ok = true;
    public List<string> Warnings = new();
    public string Report = "";
}

/// <summary>Poutre rectangulaire, en T ou en L : largeur de table collaborante, armatures de flexion (section en T, armatures comprimées si besoin), effort tranchant et état limite de service.</summary>
public static class BeamSectionDesigner
{
    public static double TableWidth(BeamSectionInput p, out double l0, out string how)
    {
        l0 = p.Position switch { SpanPosition.EndSpan => 0.85 * p.Span, SpanPosition.InteriorSpan => 0.70 * p.Span, SpanPosition.Cantilever => 2.0 * p.Span, _ => p.Span };
        if (p.Shape == SectionShape.Rectangle) { how = "section rectangulaire"; return p.Bw; }
        if (p.BImposed > p.Bw) { how = "largeur imposée"; return p.BImposed; }
        double lz = l0;
        double One(double bi) => p.Rule == FlangeRule.Ec2 ? Math.Min(Math.Min(0.2 * bi + 0.1 * lz, 0.2 * lz), bi) : Math.Min(bi, lz / 10.0);
        double b = p.Bw + One(p.BiRight) + (p.Shape == SectionShape.Tee ? One(p.BiLeft) : 0);
        how = p.Rule == FlangeRule.Ec2 ? "EC2 5.3.2.1 : beff,i = min(0,2 bi + 0,1 l0 ; 0,2 l0 ; bi)" : "BAEL A.4.1,3 : b1 = min(bi ; l0/10)";
        return b;
    }

    /// <summary>Armatures tendues (et comprimées si nécessaire) pour une section en T ou rectangulaire (m, MPa, kN·m) ; retourne As, As' en cm².</summary>
    public static (double As, double AsComp, bool Doubly, string Note) Flexure(double b, double bw, double hf, double d, double dPrime, double mKnm, Mat mat)
    {
        double fbu = mat.Fcd, sig = mat.Fyd, mMN = mKnm / 1000.0;
        if (mMN <= 1e-9) return (0, 0, false, "pas de moment");
        double Mtab = hf > 0 && b > bw + 1e-9 ? b * hf * fbu * (d - hf / 2) : double.MaxValue;
        string note;
        if (mMN <= Mtab)
        {
            var r = Rect(hf > 0 && b > bw + 1e-9 ? b : bw, d, dPrime, mMN, mat);
            note = b > bw + 1e-9 && hf > 0 ? $"zone comprimée dans la table (M ≤ Mtable = {Mtab * 1000:0} kN·m) : calcul en section rectangulaire b = {b:0.00} m" : "section rectangulaire";
            return (r.As, r.AsComp, r.AsComp > 0, note);
        }
        double mWeb = mMN - (b - bw) * hf * fbu * (d - hf / 2);
        var w = Rect(bw, d, dPrime, mWeb, mat);
        double asFlange = (b - bw) * hf * fbu / sig * 1e4;
        note = $"axe neutre dans l'âme (M > Mtable = {Mtab * 1000:0} kN·m) : débord de table + âme";
        return (w.As + asFlange, w.AsComp, w.AsComp > 0, note);
    }

    private static (double As, double AsComp) Rect(double b, double d, double dPrime, double mMN, Mat mat)
    {
        double fbu = mat.Fcd, sig = mat.Fyd;
        double aL = 3.5 / (3.5 + 1000.0 * sig / mat.Es), muL = 0.8 * aL * (1 - 0.4 * aL);
        double mu = mMN / (b * d * d * fbu);
        if (mu <= muL)
        {
            double a = 1.25 * (1 - Math.Sqrt(1 - 2 * mu)), z = d * (1 - 0.4 * a);
            return (mMN / (z * sig) * 1e4, 0);
        }
        double ml = muL * b * d * d * fbu, dm = mMN - ml, zl = d * (1 - 0.4 * aL);
        double esc = 0.0035 * (1 - dPrime / (aL * d)), ssc = Math.Clamp(mat.Es * esc, 0, sig);
        if (ssc <= 1) ssc = sig;
        double asc = dm / ((d - dPrime) * ssc) * 1e4;
        double ast = (ml / (zl * sig) + dm / ((d - dPrime) * sig)) * 1e4;
        return (ast, asc);
    }

    public static BeamSectionResult Design(BeamSectionInput p)
    {
        var r = new BeamSectionResult();
        var mat = new Mat { Fc = p.Fc, Fe = p.Fe };
        var g = new SectionGeom { Shape = p.Shape, B = p.Bw, H = p.H, Bw = p.Bw, Hf = p.Hf };
        double beff = TableWidth(p, out double l0, out string how);
        if (p.Shape != SectionShape.Rectangle) { g.B = beff; }
        r.Geom = g; r.Beff = beff; r.L0 = l0;
        double d = p.H - p.Dprime; r.D = d;
        var sb = new StringBuilder();
        string name = p.Shape switch { SectionShape.Tee => "POUTRE EN T", SectionShape.Ell => "POUTRE EN L (rive)", _ => "POUTRE RECTANGULAIRE" };
        sb.AppendLine($"{name}  bw = {p.Bw * 100:0} cm, h = {p.H * 100:0} cm" + (p.Shape != SectionShape.Rectangle ? $", hf = {p.Hf * 100:0} cm" : "") + $", d = {d * 100:0.#} cm");
        sb.AppendLine($"Matériaux : fc28 = {p.Fc:0} MPa (fbu = {mat.Fcd:0.00} MPa), fe = {p.Fe:0} MPa (σs = {mat.Fyd:0} MPa)");
        if (p.Hf >= p.H && p.Shape != SectionShape.Rectangle) { r.Ok = false; r.Warnings.Add("L'épaisseur de table hf doit être inférieure à la hauteur h."); }
        if (p.Shape != SectionShape.Rectangle)
        {
            sb.AppendLine($"Table collaborante : l0 = {l0:0.00} m, b = {beff:0.00} m  ({how})");
            if (p.Shape == SectionShape.Tee) sb.AppendLine($"   bi gauche = {p.BiLeft:0.00} m, bi droite = {p.BiRight:0.00} m");
        }

        // flexion en travée : table comprimée
        var sag = Flexure(beff, p.Bw, p.Shape == SectionShape.Rectangle ? 0 : p.Hf, d, p.Dprime, p.MuSag, mat);
        // appui : table tendue, zone comprimée en bas de largeur bw
        var hog = Flexure(p.Bw, p.Bw, 0, d, p.Dprime, p.MuHog, mat);
        double asMin = 0.23 * mat.Ft28 / p.Fe * p.Bw * d * 1e4;
        r.AsMin = asMin;
        double asBot = Math.Max(sag.As, p.MuSag > 0 ? asMin : 0), asTop = Math.Max(hog.As, p.MuHog > 0 ? asMin : 0);
        asTop += sag.AsComp; asBot += hog.AsComp;      // armatures comprimées éventuelles : placées sur la face opposée
        r.AsBottom = asBot; r.AsTop = asTop;
        sb.AppendLine();
        sb.AppendLine($"FLEXION EN TRAVÉE  Mu = {p.MuSag:0.#} kN·m : {sag.Note}");
        sb.AppendLine($"   As inférieur = {sag.As:0.00} cm²" + (sag.Doubly ? $" ; armatures comprimées A's = {sag.AsComp:0.00} cm² (section doublement armée)" : "") + $" ; As,min = {asMin:0.00} cm²");
        if (p.MuHog > 0)
        {
            sb.AppendLine($"FLEXION SUR APPUI  Mu = {p.MuHog:0.#} kN·m (table tendue, section rectangulaire bw) : {hog.Note}");
            sb.AppendLine($"   As supérieur = {hog.As:0.00} cm²" + (hog.Doubly ? $" ; armatures comprimées en bas = {hog.AsComp:0.00} cm²" : ""));
        }
        var cfg = (DesignSettings?)null;
        if (asBot > 0) r.Bottom = RebarSelector.ForBeam(asBot, p.Bw, p.Dprime, cfg);
        if (asTop > 0) r.Top = RebarSelector.ForBeam(asTop, p.Bw, p.Dprime, cfg);
        if (r.Bottom != null) sb.AppendLine($"   Choix : inférieur {r.Bottom.Label} ({r.Bottom.AreaCm2:0.00} cm²)" + (r.Top != null ? $" ; supérieur {r.Top.Label} ({r.Top.AreaCm2:0.00} cm²)" : ""));

        // effort tranchant (BAEL A.5.1, inclinaison 90°)
        r.TauU = p.Vu / 1000.0 / (p.Bw * d);
        r.TauLim = p.Crack == CrackingClass.PeuPrejudiciable ? Math.Min(0.20 * p.Fc / 1.5, 5.0) : Math.Min(0.15 * p.Fc / 1.5, 4.0);
        sb.AppendLine();
        sb.AppendLine($"EFFORT TRANCHANT  Vu = {p.Vu:0.#} kN : τu = {r.TauU:0.00} MPa (limite {r.TauLim:0.00} MPa)");
        if (r.TauU > r.TauLim) { r.Ok = false; r.Warnings.Add($"τu = {r.TauU:0.00} MPa dépasse la limite {r.TauLim:0.00} MPa : augmentez bw ou h."); }
        double atSt = Math.Max(1.15 * (r.TauU - 0.3 * mat.Ft28) * p.Bw / (0.9 * p.Fe), 0.4 * p.Bw / p.Fe) * 1e4;      // cm²/m
        double stMax = Math.Min(0.9 * d, 0.40) * 100;
        var (dia, sp) = RebarSelector.Stirrups(atSt, stMax, 6, cfg);
        r.StirDia = dia; r.StirSpacingCm = sp;
        sb.AppendLine($"   At/st = {atSt:0.0} cm²/m ; cadres HA{dia} (2 brins) espacés de {sp:0} cm (st,max = {stMax:0} cm)");

        // service
        if (p.MserSag > 0 && r.Bottom != null)
        {
            const double n = 15;
            double b = p.Shape == SectionShape.Rectangle ? p.Bw : beff, hf = p.Shape == SectionShape.Rectangle ? 0 : p.Hf;
            double asT = r.Bottom.AreaCm2 * 1e-4, asC = (r.Top?.AreaCm2 ?? 0) * 1e-4;
            double Sc(double y1) => hf > 0 && y1 > hf ? b * hf * (y1 - hf / 2) + p.Bw * (y1 - hf) * (y1 - hf) / 2 : b * y1 * y1 / 2;
            double lo = 1e-4, hi = d;
            for (int i = 0; i < 80; i++)
            {
                double y = (lo + hi) / 2, f = Sc(y) + n * asC * (y - p.Dprime) - n * asT * (d - y);
                if (f > 0) hi = y; else lo = y;
            }
            double y1 = (lo + hi) / 2;
            double inertia = (hf > 0 && y1 > hf ? b * y1 * y1 * y1 / 3 - (b - p.Bw) * Math.Pow(y1 - hf, 3) / 3 : b * y1 * y1 * y1 / 3) + n * asC * (y1 - p.Dprime) * (y1 - p.Dprime) + n * asT * (d - y1) * (d - y1);
            double m = p.MserSag / 1000.0;
            r.SigmaBc = m * y1 / inertia; r.SigmaS = n * m * (d - y1) / inertia;
            r.SigmaBcLim = 0.6 * p.Fc;
            double ft = mat.Ft28;
            r.SigmaSLim = p.Crack == CrackingClass.PeuPrejudiciable ? p.Fe : Math.Min(2.0 / 3 * p.Fe, 110 * Math.Sqrt(1.6 * ft)) * (p.Crack == CrackingClass.TresPrejudiciable ? 0.8 : 1.0);
            sb.AppendLine();
            sb.AppendLine($"SERVICE  Mser = {p.MserSag:0.#} kN·m (section fissurée, n = 15) : axe neutre y1 = {y1 * 100:0.#} cm");
            sb.AppendLine($"   σbc = {r.SigmaBc:0.0} MPa (limite {r.SigmaBcLim:0.0}) ; σs = {r.SigmaS:0} MPa (limite {r.SigmaSLim:0})");
            if (r.SigmaBc > r.SigmaBcLim) { r.Ok = false; r.Warnings.Add("Compression du béton à l'ELS trop élevée."); }
            if (r.SigmaS > r.SigmaSLim) { r.Ok = false; r.Warnings.Add($"Contrainte de l'acier à l'ELS trop élevée ({r.SigmaS:0} > {r.SigmaSLim:0} MPa) : ajoutez de l'acier."); }
        }
        foreach (var w in r.Warnings) sb.AppendLine("ATTENTION : " + w);
        r.Report = sb.ToString();
        return r;
    }
}
