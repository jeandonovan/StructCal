namespace StructCalc.Engine.Sections;

public enum SectionShape { Rectangle, Tee, Ell, Circle }

/// <summary>Géométrie d'une section de béton : rectangle, T, L (table à droite de l'âme) ou cercle. y se mesure vers le bas depuis la fibre supérieure.</summary>
public sealed class SectionGeom
{
    public SectionShape Shape;
    /// <summary>Largeur (rectangle), largeur de table (T, L) ou diamètre (cercle), en m.</summary>
    public double B;
    /// <summary>Hauteur totale (rectangle, T, L), en m. Ignorée pour le cercle.</summary>
    public double H;
    /// <summary>Largeur de l'âme (T, L) et épaisseur de la table (T, L), en m.</summary>
    public double Bw, Hf;
    /// <summary>Section retournée (fibre supérieure en bas) : moment de signe opposé.</summary>
    public bool Flip;

    public double Height => Shape == SectionShape.Circle ? B : H;

    public double WidthAt(double y)
    {
        double yy = Flip ? Height - y : y;
        switch (Shape)
        {
            case SectionShape.Rectangle: return yy >= 0 && yy <= H ? B : 0;
            case SectionShape.Tee:
            case SectionShape.Ell: return yy < 0 || yy > H ? 0 : yy < Hf ? B : Bw;
            default:
                double r = B / 2, t = yy - r;
                return Math.Abs(t) >= r ? 0 : 2 * Math.Sqrt(r * r - t * t);
        }
    }

    private const int N = 400;

    public double Area { get { double a = 0, dy = Height / N; for (int i = 0; i < N; i++) a += WidthAt((i + 0.5) * dy) * dy; return a; } }

    /// <summary>Distance du centre de gravité à la fibre supérieure (m).</summary>
    public double CentroidY
    {
        get { double a = 0, s = 0, dy = Height / N; for (int i = 0; i < N; i++) { double y = (i + 0.5) * dy, w = WidthAt(y); a += w * dy; s += w * dy * y; } return s / a; }
    }

    /// <summary>Moment d'inertie centroïdal (m⁴) autour de l'axe horizontal.</summary>
    public double Inertia
    {
        get
        {
            double yc = CentroidY, dy = Height / N, i = 0;
            for (int k = 0; k < N; k++) { double y = (k + 0.5) * dy, w = WidthAt(y); i += w * dy * (y - yc) * (y - yc) + w * dy * dy * dy / 12; }
            return i;
        }
    }

    public double MinWidth => Shape == SectionShape.Rectangle ? B : Shape == SectionShape.Circle ? B : Bw;

    /// <summary>Périmètre (m).</summary>
    public double Perimeter
    {
        get
        {
            if (Shape == SectionShape.Circle) return Math.PI * B;
            var p = Outline(); double s = 0;
            for (int i = 0; i < p.Count; i++) { var a = p[i]; var b = p[(i + 1) % p.Count]; s += Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y)); }
            return s;
        }
    }

    /// <summary>Contour polygonal (x vers la droite depuis le bord gauche, y vers le bas) ; vide pour le cercle.</summary>
    public List<(double X, double Y)> Outline()
    {
        switch (Shape)
        {
            case SectionShape.Rectangle: return new() { (0, 0), (B, 0), (B, H), (0, H) };
            case SectionShape.Tee:
            {
                double x0 = (B - Bw) / 2;
                return new() { (0, 0), (B, 0), (B, Hf), (x0 + Bw, Hf), (x0 + Bw, H), (x0, H), (x0, Hf), (0, Hf) };
            }
            case SectionShape.Ell: return new() { (0, 0), (B, 0), (B, Hf), (Bw, Hf), (Bw, H), (0, H) };
            default: return new();
        }
    }

    /// <summary>Même contour avec y retourné si <see cref="Flip"/>.</summary>
    public List<(double X, double Y)> OutlineShown() => Flip ? Outline().Select(p => (p.X, Height - p.Y)).ToList() : Outline();
}

/// <summary>Matériaux : béton parabole-rectangle, acier bilinéaire.</summary>
public sealed class Mat
{
    public double Fc = 25, Fe = 500, GammaC = 1.5, GammaS = 1.15, Acc = 0.85, Es = 200000;
    public double Fcd => Acc * Fc / GammaC;
    public double Fyd => Fe / GammaS;
    public double Ft28 => 0.6 + 0.06 * Fc;
}

/// <summary>Groupe de barres (aire en cm²) à la profondeur y depuis la fibre supérieure.</summary>
public readonly record struct BarGroup(double X, double Y, double AreaCm2);

/// <summary>Résistance d'une section par compatibilité des déformations (méthode des fibres), flexion plane. Compression positive ; moments (kN·m) positifs = fibre supérieure comprimée.</summary>
public static class FiberSection
{
    private const int Strips = 300;

    public static (double N, double M) Resultants(SectionGeom g, IReadOnlyList<BarGroup> bars, Mat mat, Func<double, double> strain)
    {
        double h = g.Height, dy = h / Strips, yc = g.CentroidY, n = 0, m = 0;
        for (int i = 0; i < Strips; i++)
        {
            double y = (i + 0.5) * dy, e = strain(y);
            if (e <= 0) continue;
            double s = ConcreteStress(e, mat), f = s * g.WidthAt(y) * dy * 1000.0;          // kN
            n += f; m += f * (yc - y);
        }
        foreach (var b in bars)
        {
            double e = strain(b.Y), s = Math.Clamp(mat.Es * e, -mat.Fyd, mat.Fyd);
            if (e > 0) s -= ConcreteStress(e, mat);                                            // béton déplacé
            double f = s * b.AreaCm2 * 1e-4 * 1000.0;
            n += f; m += f * (yc - b.Y);
        }
        return (n, m);
    }

    public static double ConcreteStress(double e, Mat mat) => e <= 0 ? 0 : e >= 0.002 ? mat.Fcd : mat.Fcd * (1 - Math.Pow(1 - e / 0.002, 2));

    /// <summary>Courbe d'interaction (N, M) de la flexion positive, N croissant (de la traction à la compression centrée).</summary>
    public static List<(double N, double M)> Curve(SectionGeom g, IReadOnlyList<BarGroup> bars, Mat mat)
    {
        double h = g.Height, dMax = bars.Count > 0 ? bars.Max(b => b.Y) : 0.9 * h;
        double xAB = 3.5 / (3.5 + 10.0) * dMax;
        var xs = new List<double>();
        for (int i = 60; i >= 1; i--) xs.Add(-dMax * Math.Pow(1.12, i) * 0.02);               // axe neutre au-dessus de la section : traction
        for (int i = 0; i <= 40; i++) xs.Add(xAB * i / 40.0 + 1e-6);
        for (int i = 1; i <= 60; i++) xs.Add(xAB + (h - xAB) * i / 60.0);
        for (int i = 1; i <= 60; i++) xs.Add(h * Math.Pow(1.10, i));
        xs.Sort();
        var res = new List<(double, double)>();
        foreach (double x in xs)
        {
            Func<double, double> eps;
            if (x <= xAB) { double k = 0.010 / (dMax - x); eps = y => k * (x - y); }
            else if (x <= h) eps = y => 0.0035 * (x - y) / x;
            else eps = y => 0.002 * (x - y) / (x - 3.0 / 7 * h);
            res.Add(Resultants(g, bars, mat, eps));
        }
        return res;
    }

    /// <summary>Moment résistant (kN·m, ≥ 0) pour l'effort normal N (kN, compression +) ; 0 si N est hors du domaine.</summary>
    public static double MomentAt(List<(double N, double M)> curve, double n)
    {
        for (int i = 0; i < curve.Count - 1; i++)
        {
            var a = curve[i]; var b = curve[i + 1];
            if ((a.N - n) * (b.N - n) <= 0 && Math.Abs(b.N - a.N) > 1e-12)
            {
                double t = (n - a.N) / (b.N - a.N);
                return Math.Max(0, a.M + t * (b.M - a.M));
            }
        }
        return 0;
    }

    public static double N0(List<(double N, double M)> curve) => curve.Max(p => p.N);
}
