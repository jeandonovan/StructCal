using System.Text.Json;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Identifiant Revit d'un élément créé depuis StructCalc : « Member » (clé = Id de la barre) ou « Slab » (clé = nom de la dalle).</summary>
public sealed class CreatedId
{
    public string Kind { get; set; } = "";
    public string Key { get; set; } = "";
    public string ExternalId { get; set; } = "";
}

/// <summary>Compte rendu de la création dans Revit, relu par StructCalc.</summary>
public sealed class CreatedIdsFile
{
    public List<CreatedId> Items { get; set; } = new();
    public List<string> Notes { get; set; } = new();

    public static void Save(CreatedIdsFile f, string path) => File.WriteAllText(path, JsonSerializer.Serialize(f, new JsonSerializerOptions { WriteIndented = true }));
    public static CreatedIdsFile Load(string path) => JsonSerializer.Deserialize<CreatedIdsFile>(File.ReadAllText(path)) ?? new();

    /// <summary>Reporte les identifiants Revit sur le modèle (barres par Id ; dalles, voiles et radiers par nom). Renvoie le nombre d'éléments liés.
    /// Un élément déjà lié à un autre identifiant n'est pas écrasé.</summary>
    public int ApplyTo(StructModel m)
    {
        int n = 0;
        foreach (var it in Items)
        {
            if (it.Kind == "Member" && int.TryParse(it.Key, out int id))
            {
                var mem = m.Members.FirstOrDefault(x => x.Id == id);
                if (mem != null && string.IsNullOrEmpty(mem.ExternalId)) { mem.ExternalId = it.ExternalId; n++; }
            }
            else if (it.Kind == "Slab")
            {
                var sl = m.Slabs.FirstOrDefault(x => x.Name == it.Key);
                if (sl != null && string.IsNullOrEmpty(sl.ExternalId)) { sl.ExternalId = it.ExternalId; n++; }
            }
            else if (it.Kind == "Wall")
            {
                var w = m.Walls.FirstOrDefault(x => x.Name == it.Key);
                if (w != null && string.IsNullOrEmpty(w.ExternalId)) { w.ExternalId = it.ExternalId; n++; }
            }
            else if (it.Kind == "Raft")
            {
                var r = m.Rafts.FirstOrDefault(x => x.Name == it.Key);
                if (r != null && string.IsNullOrEmpty(r.ExternalId)) { r.ExternalId = it.ExternalId; n++; }
            }
        }
        return n;
    }
}
