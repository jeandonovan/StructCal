using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed class StationForces
{
    public double X, N, Vy, Vz, T, My, Mz;
}

public sealed class CaseResult
{
    public Dictionary<int, double[]> NodeDisp { get; } = new();
    public Dictionary<int, double[]> Reactions { get; } = new();
    public Dictionary<int, StationForces[]> Members { get; } = new();
    /// <summary>Efforts des coques (voiles, dalles maillées) au centre de chaque élément, par Id de coque.</summary>
    public Dictionary<int, ShellForces> Shells { get; } = new();
}

/// <summary>
/// Solveur statique linéaire 3D de portiques (barres d'Euler-Bernoulli, 6 ddl/nœud). Unités : kN, m.
/// Convention : N>0 traction ; My>0 = fibre supérieure tendue (moment sur appui) pour z local vers le haut,
/// donc la flexion en travée vaut -My. Vy, Vz, T positifs dans le sens des axes locaux sur la face +x.
/// </summary>
public static class FrameSolver
{
    public const int Stations = 21;
    public const double ConcreteUnitWeight = 25.0;

    private sealed class Elem
    {
        public Member M = null!;
        public int I, J;
        public double L;
        public double[,] R = null!, K = null!, T = null!;
        public double[] Feq = null!, Xs = null!;
        public LocalLoads LL = null!;
    }

    public static (double L, double[,] R) LocalAxes(Node a, Node b, double rollDeg = 0)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y, dz = b.Z - a.Z;
        double L = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        if (L < 1e-9) throw new InvalidOperationException("Barre de longueur nulle.");
        double[] x = { dx / L, dy / L, dz / L };
        double[] y, z;
        if (Math.Abs(x[2]) > 0.999)
        {
            y = new[] { 1.0, 0.0, 0.0 };
            z = Cross(x, y);
        }
        else
        {
            double d = x[2];
            z = Normalize(new[] { -d * x[0], -d * x[1], 1 - d * x[2] });
            y = Cross(z, x);
        }
        if (Math.Abs(rollDeg) > 1e-9)
        {
            double c = Math.Cos(rollDeg * Math.PI / 180), s = Math.Sin(rollDeg * Math.PI / 180);
            var y2 = new double[3]; var z2 = new double[3];
            for (int k = 0; k < 3; k++) { y2[k] = c * y[k] + s * z[k]; z2[k] = -s * y[k] + c * z[k]; }
            y = y2; z = z2;
        }
        var R = new double[3, 3];
        for (int k = 0; k < 3; k++) { R[0, k] = x[k]; R[1, k] = y[k]; R[2, k] = z[k]; }
        return (L, R);
    }

    private static double[] Cross(double[] a, double[] b) => new[]
    {
        a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]
    };
    private static double[] Normalize(double[] v)
    {
        double n = Math.Sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return new[] { v[0] / n, v[1] / n, v[2] / n };
    }

    public static double TorsionConstant(double b, double h)
    {
        double a = Math.Max(b, h), t = Math.Min(b, h);
        return a * t * t * t * (1.0 / 3.0 - 0.21 * (t / a) * (1.0 - Math.Pow(t, 4) / (12.0 * Math.Pow(a, 4))));
    }

    private static double[,] LocalStiffness(double E, double G, double A, double Iy, double Iz, double J, double L)
    {
        var k = new double[12, 12];
        double ea = E * A / L, gj = G * J / L;
        k[0, 0] = k[6, 6] = ea; k[0, 6] = k[6, 0] = -ea;
        k[3, 3] = k[9, 9] = gj; k[3, 9] = k[9, 3] = -gj;
        // flexion plan xy (v, theta_z) : ddl 1,5,7,11
        double a = E * Iz / (L * L * L);
        int[] p = { 1, 5, 7, 11 };
        double[,] bz =
        {
            {  12,     6 * L, -12,     6 * L },
            {  6 * L,  4 * L * L, -6 * L,  2 * L * L },
            { -12,    -6 * L,  12,    -6 * L },
            {  6 * L,  2 * L * L, -6 * L,  4 * L * L }
        };
        for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) k[p[r], p[c]] += a * bz[r, c];
        // flexion plan xz (w, theta_y) : ddl 2,4,8,10
        double a2 = E * Iy / (L * L * L);
        int[] q = { 2, 4, 8, 10 };
        double[,] by =
        {
            {  12,    -6 * L, -12,    -6 * L },
            { -6 * L,  4 * L * L,  6 * L,  2 * L * L },
            { -12,     6 * L,  12,     6 * L },
            { -6 * L,  2 * L * L,  6 * L,  4 * L * L }
        };
        for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) k[q[r], q[c]] += a2 * by[r, c];
        return k;
    }

    private sealed class ShellData
    {
        public ShellPanel Panel = null!;
        public ShellGeo Geo = null!;
        public int[] Ni = new int[4];
        public int[] Dofs = new int[24];
        public double[,] Kg = null!;
        public double[] Fg = null!;
    }

    private static List<ShellData> BuildShells(StructModel m, Dictionary<int, int> idx, ActionType c)
    {
        var list = new List<ShellData>();
        foreach (var sh in m.Shells)
        {
            var ids = new[] { sh.N1, sh.N2, sh.N3, sh.N4 };
            var sd = new ShellData { Panel = sh };
            for (int q = 0; q < 4; q++)
            {
                if (!idx.TryGetValue(ids[q], out int ni)) throw new InvalidOperationException($"Coque {sh.Id} : nœud {ids[q]} inexistant.");
                sd.Ni[q] = ni;
                for (int d = 0; d < 6; d++) sd.Dofs[6 * q + d] = 6 * ni + d;
            }
            sd.Geo = ShellFem.Geometry(m.Nodes[sd.Ni[0]], m.Nodes[sd.Ni[1]], m.Nodes[sd.Ni[2]], m.Nodes[sd.Ni[3]]);
            if (sd.Geo.Area < 1e-9) throw new InvalidOperationException($"Coque {sh.Id} : surface nulle.");
            sd.Kg = ShellFem.GlobalStiffness(sd.Geo, m.EcKNm2, sh.T);
            sd.Fg = ShellFem.EquivalentLoad(m, sh, sd.Geo, c);
            list.Add(sd);
        }
        return list;
    }

    private static Elem BuildElem(StructModel m, Member mem, Dictionary<int, int> idx, ActionType c, Dictionary<int, List<MemberLoad>> byMember)
    {
        if (!idx.TryGetValue(mem.NodeI, out int ii) || !idx.TryGetValue(mem.NodeJ, out int jj))
            throw new InvalidOperationException($"Barre {mem.Id} : nœud inexistant.");
        var (L, R) = LocalAxes(m.Nodes[ii], m.Nodes[jj], mem.Roll);
        bool rc = mem.Kind == MaterialKind.ReinforcedConcrete;
        double A = mem.PropA > 0 ? mem.PropA : mem.B * mem.H;
        double Iy = mem.PropIy > 0 ? mem.PropIy : mem.B * Math.Pow(mem.H, 3) / 12.0;
        double Iz = mem.PropIz > 0 ? mem.PropIz : mem.H * Math.Pow(mem.B, 3) / 12.0;
        double J = mem.PropJ > 0 ? mem.PropJ : TorsionConstant(mem.B, mem.H);
        double hSec = mem.H;
        if (!rc && mem.PropA <= 0 && StructCalc.Core.Steel.SteelCatalog.TryGet(mem.Profile, out var prof))
        {
            A = prof.A; Iy = prof.Iy; Iz = prof.Iz; J = prof.J; hSec = prof.H / 1000.0;
        }
        double E = rc ? m.EcKNm2 : 210e6;
        double G = E / (2.0 * (1.0 + (rc ? 0.2 : 0.3)));
        var K = LocalStiffness(E, G, A, Iy, Iz, J, L);
        var T = new double[12, 12];
        for (int b = 0; b < 4; b++)
            for (int r = 0; r < 3; r++)
                for (int cc = 0; cc < 3; cc++) T[3 * b + r, 3 * b + cc] = R[r, cc];

        byMember.TryGetValue(mem.Id, out var own);
        var ll = LoadMath.ToLocalLoads((own ?? new List<MemberLoad>()).Where(l => l.Case == c), L, R);
        if (m.IncludeSelfWeight && c == ActionType.G)
        {
            var sw = LoadMath.ToLocal(R, 0, 0, -(rc ? ConcreteUnitWeight : 78.5) * A);
            ll.Segs.Add(new LoadSeg { A = 0, B = L, Q1 = sw, Q2 = (double[])sw.Clone() });
        }
        var feq = LoadMath.FixedEnd(ll, L, E, A, Iy, hSec, rc ? 1.0e-5 : 1.2e-5);
        var xs = LoadMath.StationXs(own ?? new List<MemberLoad>(), L, Stations);
        return new Elem { M = mem, I = ii, J = jj, L = L, R = R, K = K, T = T, Feq = feq, LL = ll, Xs = xs };
    }

    /// <summary>Matrice de rigidité réduite (ddl libres seulement, stockage ligne par ligne nf x nf) pour l'analyse modale.
    /// idx : nœud -> position ; map : ddl global (6 par nœud) -> ddl libre (-1 si bloqué).</summary>
    internal static double[] AssembleStiffness(StructModel m, out Dictionary<int, int> idx, out int[] map, out int nf)
    {
        var ix = new Dictionary<int, int>();
        for (int i = 0; i < m.Nodes.Count; i++)
        {
            if (ix.ContainsKey(m.Nodes[i].Id)) throw new InvalidOperationException($"Nœud {m.Nodes[i].Id} en double.");
            ix[m.Nodes[i].Id] = i;
        }
        idx = ix;
        int nd = 6 * m.Nodes.Count;
        var isFixed = new bool[nd];
        foreach (var s in m.Supports)
        {
            if (!ix.TryGetValue(s.NodeId, out int k)) throw new InvalidOperationException($"Appui sur nœud {s.NodeId} inexistant.");
            bool[] fl = { s.Ux, s.Uy, s.Uz, s.Rx, s.Ry, s.Rz };
            for (int d = 0; d < 6; d++) if (fl[d]) isFixed[6 * k + d] = true;
        }
        var byMember = LoadExpander.MemberLoadsOf(m).GroupBy(l => l.MemberId).ToDictionary(g => g.Key, g => g.ToList());
        var elems = m.Members.Select(mem => BuildElem(m, mem, ix, ActionType.G, byMember)).ToList();
        map = new int[nd];
        nf = 0;
        for (int d = 0; d < nd; d++) map[d] = isFixed[d] ? -1 : nf++;
        var Kr = new double[nf * nf];
        foreach (var sd in BuildShells(m, ix, ActionType.G))
            for (int a = 0; a < 24; a++)
            {
                int ra = map[sd.Dofs[a]];
                if (ra < 0) continue;
                for (int b = 0; b < 24; b++)
                {
                    int rb = map[sd.Dofs[b]];
                    if (rb >= 0) Kr[ra * nf + rb] += sd.Kg[a, b];
                }
            }
        foreach (var e in elems)
        {
            var dofs = new int[12];
            for (int a = 0; a < 12; a++) dofs[a] = a < 6 ? 6 * e.I + a : 6 * e.J + (a - 6);
            var KT = new double[12, 12];
            for (int a = 0; a < 12; a++)
                for (int b = 0; b < 12; b++)
                {
                    double s = 0;
                    for (int k = 0; k < 12; k++) s += e.K[a, k] * e.T[k, b];
                    KT[a, b] = s;
                }
            for (int a = 0; a < 12; a++)
            {
                int ra = map[dofs[a]];
                if (ra < 0) continue;
                for (int b = 0; b < 12; b++)
                {
                    int rb = map[dofs[b]];
                    if (rb < 0) continue;
                    double s = 0;
                    for (int k = 0; k < 12; k++) s += e.T[k, a] * KT[k, b];
                    Kr[ra * nf + rb] += s;
                }
            }
        }
        return Kr;
    }

    public static CaseResult Solve(StructModel m, ActionType c, IEnumerable<NodalLoad>? extraLoads = null)
    {
        var idx = new Dictionary<int, int>();
        for (int i = 0; i < m.Nodes.Count; i++)
        {
            if (idx.ContainsKey(m.Nodes[i].Id)) throw new InvalidOperationException($"Nœud {m.Nodes[i].Id} en double.");
            idx[m.Nodes[i].Id] = i;
        }
        int nd = 6 * m.Nodes.Count;
        var isFixed = new bool[nd];
        foreach (var s in m.Supports)
        {
            if (!idx.TryGetValue(s.NodeId, out int k)) throw new InvalidOperationException($"Appui sur nœud {s.NodeId} inexistant.");
            bool[] fl = { s.Ux, s.Uy, s.Uz, s.Rx, s.Ry, s.Rz };
            for (int d = 0; d < 6; d++) if (fl[d]) isFixed[6 * k + d] = true;
        }
        var Fnod = new double[nd];
        foreach (var l in extraLoads == null ? m.NodalLoads : m.NodalLoads.Concat(extraLoads))
        {
            if (l.Case != c) continue;
            if (!idx.TryGetValue(l.NodeId, out int k)) throw new InvalidOperationException($"Charge sur nœud {l.NodeId} inexistant.");
            Fnod[6 * k] += l.Fx; Fnod[6 * k + 1] += l.Fy; Fnod[6 * k + 2] += l.Fz;
            Fnod[6 * k + 3] += l.Mx; Fnod[6 * k + 4] += l.My; Fnod[6 * k + 5] += l.Mz;
        }
        var byMember = LoadExpander.MemberLoadsOf(m).GroupBy(l => l.MemberId).ToDictionary(g => g.Key, g => g.ToList());
        var elems = m.Members.Select(mem => BuildElem(m, mem, idx, c, byMember)).ToList();
        var F = (double[])Fnod.Clone();

        // coques : rigidité globale 24 x 24 et charges équivalentes
        var shells = BuildShells(m, idx, c);

        // numérotation des ddl libres dans l'ordre de Cuthill-McKee inversé des nœuds : bande étroite, stockage en bande
        var edges = elems.Select(e => (e.I, e.J)).ToList();
        foreach (var sd in shells)
            for (int p = 0; p < 4; p++) for (int q = p + 1; q < 4; q++) edges.Add((sd.Ni[p], sd.Ni[q]));
        var order = Reorder.Rcm(m.Nodes.Count, edges);
        var map = new int[nd];
        int nf = 0;
        foreach (int ni in order)
            for (int d = 0; d < 6; d++)
            {
                int g = 6 * ni + d;
                map[g] = isFixed[g] ? -1 : nf++;
            }
        var dofsOf = new Dictionary<Elem, int[]>();
        int bw = 0;
        foreach (var e in elems)
        {
            var dofs = new int[12];
            for (int a = 0; a < 12; a++) dofs[a] = a < 6 ? 6 * e.I + a : 6 * e.J + (a - 6);
            dofsOf[e] = dofs;
            int lo = int.MaxValue, hi = -1;
            foreach (int g in dofs) { int r = map[g]; if (r < 0) continue; lo = Math.Min(lo, r); hi = Math.Max(hi, r); }
            if (hi >= 0) bw = Math.Max(bw, hi - lo);
        }
        foreach (var sd in shells)
        {
            int lo = int.MaxValue, hi = -1;
            foreach (int gdof in sd.Dofs) { int r = map[gdof]; if (r < 0) continue; lo = Math.Min(lo, r); hi = Math.Max(hi, r); }
            if (hi >= 0) bw = Math.Max(bw, hi - lo);
        }
        int w = bw + 1;
        var Kb = new double[(long)nf * w];
        foreach (var e in elems)
        {
            var dofs = dofsOf[e];
            // kg = T^T K T
            var KT = new double[12, 12];
            for (int a = 0; a < 12; a++)
                for (int b = 0; b < 12; b++)
                {
                    double s = 0;
                    for (int k = 0; k < 12; k++) s += e.K[a, k] * e.T[k, b];
                    KT[a, b] = s;
                }
            for (int a = 0; a < 12; a++)
            {
                int ra = map[dofs[a]];
                if (ra < 0) continue;
                for (int b = 0; b < 12; b++)
                {
                    int rb = map[dofs[b]];
                    if (rb < 0 || rb > ra) continue;                       // triangle inférieur seulement
                    double s = 0;
                    for (int k = 0; k < 12; k++) s += e.T[k, a] * KT[k, b];
                    Kb[(long)ra * w + (ra - rb)] += s;
                }
            }
            for (int a = 0; a < 12; a++)
            {
                double s = 0;
                for (int k = 0; k < 12; k++) s += e.T[k, a] * e.Feq[k];
                F[dofs[a]] += s;
            }
        }

        foreach (var sd in shells)
        {
            for (int a = 0; a < 24; a++)
            {
                int ra = map[sd.Dofs[a]];
                F[sd.Dofs[a]] += sd.Fg[a];
                if (ra < 0) continue;
                for (int b = 0; b < 24; b++)
                {
                    int rb = map[sd.Dofs[b]];
                    if (rb < 0 || rb > ra) continue;
                    Kb[(long)ra * w + (ra - rb)] += sd.Kg[a, b];
                }
            }
        }

        var u = new double[nd];
        if (nf > 0)
        {
            var Fr = new double[nf];
            for (int d = 0; d < nd; d++) if (map[d] >= 0) Fr[map[d]] = F[d];
            var ur = BandSolver.Solve(Kb, Fr, nf, bw);
            for (int d = 0; d < nd; d++) if (map[d] >= 0) u[d] = ur[map[d]];
        }

        var res = new CaseResult();
        for (int i = 0; i < m.Nodes.Count; i++)
        {
            var disp = new double[6];
            Array.Copy(u, 6 * i, disp, 0, 6);
            res.NodeDisp[m.Nodes[i].Id] = disp;
        }
        var reac = new double[nd];
        foreach (var e in elems)
        {
            var dofs = dofsOf[e];
            var ug = new double[12];
            for (int a = 0; a < 12; a++) ug[a] = u[dofs[a]];
            var dl = new double[12];
            for (int a = 0; a < 12; a++) { double s = 0; for (int k = 0; k < 12; k++) s += e.T[a, k] * ug[k]; dl[a] = s; }
            var f = new double[12];
            for (int a = 0; a < 12; a++) { double s = 0; for (int k = 0; k < 12; k++) s += e.K[a, k] * dl[k]; f[a] = s - e.Feq[a]; }

            var st = new StationForces[Stations];
            double L = e.L;
            var cumF = new double[3]; var cumM = new double[3]; var cumP = new double[3];
            for (int k = 0; k < Stations; k++)
            {
                double x = e.Xs[k];
                LoadMath.Cumulate(e.LL, x, cumF, cumM, cumP);
                st[k] = new StationForces
                {
                    X = x,
                    N = -f[0] - cumF[0],
                    Vy = -f[1] - cumF[1],
                    Vz = -f[2] - cumF[2],
                    T = -f[3] - cumP[0],
                    Mz = -f[5] + x * f[1] + cumM[1] - cumP[2],
                    My = -f[4] - x * f[2] - cumM[2] - cumP[1],
                };
            }
            res.Members[e.M.Id] = st;

            for (int a = 0; a < 12; a++)
            {
                if (!isFixed[dofs[a]]) continue;
                double s = 0;
                for (int k = 0; k < 12; k++) s += e.T[k, a] * f[k];
                reac[dofs[a]] += s;
            }
        }
        foreach (var sd in shells)
        {
            var ug = new double[24];
            for (int a = 0; a < 24; a++) ug[a] = u[sd.Dofs[a]];
            res.Shells[sd.Panel.Id] = ShellFem.Recover(sd.Geo, m.EcKNm2, sd.Panel.T, ug);
            for (int a = 0; a < 24; a++)
            {
                if (!isFixed[sd.Dofs[a]]) continue;
                double fa = -sd.Fg[a];
                for (int b = 0; b < 24; b++) fa += sd.Kg[a, b] * ug[b];
                reac[sd.Dofs[a]] += fa;
            }
        }
        for (int d = 0; d < nd; d++) if (isFixed[d]) reac[d] -= Fnod[d];
        for (int i = 0; i < m.Nodes.Count; i++)
        {
            bool any = false;
            for (int d = 0; d < 6; d++) if (isFixed[6 * i + d]) any = true;
            if (!any) continue;
            var rr = new double[6];
            Array.Copy(reac, 6 * i, rr, 0, 6);
            res.Reactions[m.Nodes[i].Id] = rr;
        }
        return res;
    }
}
