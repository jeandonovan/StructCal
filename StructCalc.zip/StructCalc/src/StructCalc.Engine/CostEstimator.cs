using System.Globalization;
using System.Text;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed record CostLine(string Label, double Quantity, string Unit, double UnitPrice)
{
    public double Total => Quantity * UnitPrice;
}

/// <summary>Métré chiffré : quantités du métré estimatif × bordereau de prix, avec pertes d'acier, frais généraux, bénéfice et aléas.</summary>
public sealed class CostResult
{
    public List<CostLine> Lines { get; } = new();
    public double Subtotal => Lines.Sum(l => l.Total);
    public double Overhead { get; set; }
    public double Profit { get; set; }
    public double Contingency { get; set; }
    public double Total => Subtotal + Overhead + Profit + Contingency;
    public string Currency { get; set; } = "";

    public string ToText()
    {
        var ci = CultureInfo.GetCultureInfo("fr-FR");
        string F(double v) => v.ToString("N0", ci);
        var sb = new StringBuilder();
        sb.AppendLine("MÉTRÉ CHIFFRÉ (estimation, à ajuster avec vos prix réels)");
        sb.AppendLine(new string('-', 78));
        foreach (var l in Lines)
            sb.AppendLine($"{l.Label,-34}{l.Quantity,10:N1} {l.Unit,-5} x {F(l.UnitPrice),10}  = {F(l.Total),14} {Currency}");
        sb.AppendLine(new string('-', 78));
        sb.AppendLine($"{"Sous-total",-34}{"",30}  = {F(Subtotal),14} {Currency}");
        sb.AppendLine($"{"Frais généraux",-34}{"",30}  = {F(Overhead),14} {Currency}");
        sb.AppendLine($"{"Bénéfice",-34}{"",30}  = {F(Profit),14} {Currency}");
        sb.AppendLine($"{"Aléas",-34}{"",30}  = {F(Contingency),14} {Currency}");
        sb.AppendLine($"{"TOTAL HT",-34}{"",30}  = {F(Total),14} {Currency}");
        return sb.ToString();
    }

    public string ToCsv()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Designation;Quantite;Unite;Prix unitaire;Total");
        string N(double v) => v.ToString("0.##", CultureInfo.InvariantCulture);
        foreach (var l in Lines) sb.AppendLine($"{l.Label};{N(l.Quantity)};{l.Unit};{N(l.UnitPrice)};{N(l.Total)}");
        sb.AppendLine($"Sous-total;;;;{N(Subtotal)}");
        sb.AppendLine($"Frais generaux;;;;{N(Overhead)}");
        sb.AppendLine($"Benefice;;;;{N(Profit)}");
        sb.AppendLine($"Aleas;;;;{N(Contingency)}");
        sb.AppendLine($"TOTAL HT ({Currency});;;;{N(Total)}");
        return sb.ToString();
    }
}

public static class CostEstimator
{
    public static CostResult Compute(Quantities q, PriceList p)
    {
        var r = new CostResult { Currency = p.Currency };
        double rebar = (q.RebarKg + q.StirrupKg) * (1 + p.RebarWastePercent / 100.0);
        if (q.ConcreteM3 > 0) r.Lines.Add(new CostLine("Béton armé (béton)", q.ConcreteM3, "m³", p.ConcretePerM3));
        if (q.FormworkM2 > 0) r.Lines.Add(new CostLine("Coffrage", q.FormworkM2, "m²", p.FormworkPerM2));
        if (rebar > 0) r.Lines.Add(new CostLine($"Aciers HA (+{p.RebarWastePercent:0}% pertes)", rebar, "kg", p.RebarPerKg));
        if (q.ProfileKg > 0) r.Lines.Add(new CostLine("Charpente métallique", q.ProfileKg, "kg", p.ProfilePerKg));
        double sub = r.Subtotal;
        r.Overhead = sub * p.OverheadPercent / 100.0;
        r.Profit = (sub + r.Overhead) * p.ProfitPercent / 100.0;
        r.Contingency = (sub + r.Overhead + r.Profit) * p.ContingencyPercent / 100.0;
        return r;
    }
}
