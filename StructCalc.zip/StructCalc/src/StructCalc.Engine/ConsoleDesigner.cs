using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine;

/// <summary>Résultat du calcul d'une dalle console (porte-à-faux) : bande de 1 m encastrée dans la poutre d'appui.</summary>
public sealed class SlabConsoleResult
{
    public string Slab { get; set; } = "";
    public double L { get; set; }            // portée de la console (m)
    public double W { get; set; }            // largeur le long de la poutre d'appui (m)
    public double H { get; set; }
    public double Mu { get; set; }           // kN·m/m
    public double Vu { get; set; }           // kN/m
    public double AsTop { get; set; }        // cm²/m
    public bool Ok { get; set; } = true;
    public string Text { get; set; } = "";
}

/// <summary>Calcul des consoles : dalles en porte-à-faux (bande de 1 m, flexion, tranchant, flèche, ancrage, torsion de la poutre d'appui) et poutres console
/// (contrôles complémentaires : élancement, flèche sur 2 L, ancrage). Règles BAEL 91 (parabole-rectangle simplifiée) ; EC2 donne des valeurs voisines.</summary>
public static class ConsoleDesigner
{
    private const double Tol = 2e-3;

    // ------------------------------------------------------------------ détection
    private static double Cover(StructModel m, Dictionary<int, Node> nodes, double z, bool alongX, double fixedCoord, double lo, double hi)
    {
        var iv = new List<(double Lo, double Hi)>();
        foreach (var mem in m.Members)
        {
            if (mem.Type == MemberType.Column) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            if (Math.Abs(a.Z - z) > Tol || Math.Abs(b.Z - z) > Tol) continue;
            double l, h;
            if (alongX) { if (Math.Abs(a.Y - fixedCoord) > Tol || Math.Abs(b.Y - fixedCoord) > Tol) continue; l = Math.Min(a.X, b.X); h = Math.Max(a.X, b.X); }
            else { if (Math.Abs(a.X - fixedCoord) > Tol || Math.Abs(b.X - fixedCoord) > Tol) continue; l = Math.Min(a.Y, b.Y); h = Math.Max(a.Y, b.Y); }
            if (h - l < 1e-6) continue;
            double l2 = Math.Max(l, lo), h2 = Math.Min(h, hi);
            if (h2 > l2) iv.Add((l2, h2));
        }
        double covered = 0, cur = lo;
        foreach (var t in iv.OrderBy(q => q.Lo)) { if (t.Hi > cur) { covered += t.Hi - Math.Max(cur, t.Lo); cur = t.Hi; } }
        return hi - lo > 0 ? Math.Min(1, covered / (hi - lo)) : 1;
    }

    /// <summary>Un panneau est une console s'il n'est porté que par une poutre sur un seul de ses quatre bords. <paramref name="edge"/> : 0 = bord y0, 1 = x1, 2 = y1, 3 = x0.</summary>
    public static bool IsConsoleCell(StructModel m, SlabPanel s, SlabCell c, out int edge)
    {
        edge = -1;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        double x0 = c.X0, x1 = c.X0 + c.Lx, y0 = c.Y0, y1 = c.Y0 + c.Ly;
        double[] cov =
        {
            Cover(m, nodes, s.Z, true, y0, x0, x1), Cover(m, nodes, s.Z, false, x1, y0, y1),
            Cover(m, nodes, s.Z, true, y1, x0, x1), Cover(m, nodes, s.Z, false, x0, y0, y1)
        };
        int sup = 0;
        for (int i = 0; i < 4; i++) if (cov[i] >= 0.5) { sup++; edge = i; }
        if (sup != 1) { edge = -1; return false; }
        for (int i = 0; i < 4; i++) if (i != edge && cov[i] >= 0.05) { edge = -1; return false; }
        return true;
    }

    /// <summary>Poutre horizontale dont une extrémité est libre (aucune autre barre, aucun appui, aucune coque) et l'autre est reliée à la structure.</summary>
    public static bool IsCantileverBeam(StructModel m, Member b)
    {
        if (b.Type != MemberType.Beam) return false;
        var na = m.Nodes.FirstOrDefault(n => n.Id == b.NodeI); var nb = m.Nodes.FirstOrDefault(n => n.Id == b.NodeJ);
        if (na == null || nb == null) return false;
        double len = Math.Sqrt(Math.Pow(na.X - nb.X, 2) + Math.Pow(na.Y - nb.Y, 2) + Math.Pow(na.Z - nb.Z, 2));
        if (len < 1e-6 || Math.Abs(na.Z - nb.Z) > 0.1 * len) return false;
        bool Linked(int nid) => m.Supports.Any(q => q.NodeId == nid) || m.Members.Any(x => x.Id != b.Id && (x.NodeI == nid || x.NodeJ == nid))
                                || m.Shells.Any(sh => sh.N1 == nid || sh.N2 == nid || sh.N3 == nid || sh.N4 == nid);
        bool li = Linked(b.NodeI), lj = Linked(b.NodeJ);
        return li != lj;
    }

    // ------------------------------------------------------------------ dalles console
    private static readonly int[] Dias = { 8, 10, 12, 14, 16, 20 };

    private static string Pick(double asCm2, double maxSpacingCm, out double provided)
    {
        foreach (int phi in Dias)
        {
            double a1 = Math.PI * phi * phi / 400.0;                 // cm²
            double sp = Math.Floor(100.0 * a1 / asCm2);
            if (sp < 10 && phi != Dias[^1]) continue;
            sp = Math.Clamp(sp, 5, maxSpacingCm);
            provided = a1 * 100.0 / sp;
            return $"HA{phi} e = {sp:0} cm";
        }
        provided = asCm2; return "";
    }

    public static List<SlabConsoleResult> Slabs(StructModel m)
    {
        var res = new List<SlabConsoleResult>();
        foreach (var s in m.Slabs.Where(q => q.Placed && q.CalcMode != SlabCalcMode.MassOnly && q.Lx > 0.3 && q.Ly > 0.3 && q.H > 0.02))
            foreach (var c in SlabCells.Of(m, s))
            {
                if (!IsConsoleCell(m, s, c, out int edge)) continue;
                bool alongX = edge == 0 || edge == 2;                // bord porteur parallèle à X : la console se développe selon Y
                double L = alongX ? c.Ly : c.Lx, W = alongX ? c.Lx : c.Ly;
                res.Add(DesignSlab(m, s, L, W));
            }
        return res;
    }

    private static SlabConsoleResult DesignSlab(StructModel m, SlabPanel s, double L, double W)
    {
        var r = new SlabConsoleResult { Slab = s.Name, L = L, W = W, H = s.H };
        double fc = m.Fc28, fe = m.Fe, h = s.H;
        double g = s.SelfWeightKnM2 + s.GExtra, q = s.Q, tip = s.CantileverTipKnM;
        double pu = 1.35 * g + 1.5 * q, ps = g + q, Pu = 1.35 * tip, Ps = tip;
        double mu = pu * L * L / 2 + Pu * L, vu = pu * L + Pu;
        double cover = (s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm) / 100.0;
        double d = Math.Max(h - cover - 0.006, 0.05);
        double asReq = ShellDesigner.AsFlexion(mu, d, fc, fe, out bool over);
        double ft28 = 0.6 + 0.06 * fc;
        double asMin = 0.23 * d * ft28 / fe * 1e4;                   // cm²/m
        double asUse = Math.Max(asReq, asMin);
        string top = Pick(asUse, Math.Min(25, 33), out double asProv);
        double ar = Math.Max(asProv / 4.0, 0.0008 * h * 1e4);
        string dist = Pick(ar, 25, out _);
        double tau = vu / (d * 1000.0), tauLim = 0.07 * fc / 1.5;
        double hMin = L / 10.0;
        double ev = m.EcKNm2 / 3.0, ieff = Math.Pow(h, 3) / 12.0 * 0.5;
        double defl = (ps * Math.Pow(L, 4) / 8.0 + Ps * Math.Pow(L, 3) / 3.0) / (ev * ieff) * 1000.0;     // mm
        double deflLim = 2 * L * 1000.0 / 250.0;
        double tauS = 0.6 * 1.5 * 1.5 * ft28;
        int phiTop = Dias.FirstOrDefault(p => top.StartsWith("HA" + p + " ")); if (phiTop == 0) phiTop = 12;
        double ls = phiTop * fe / (4 * tauS) / 10.0;                 // cm
        double mt = mu, tEnd = mt * W / 2.0;

        var warn = new List<string>();
        if (over) warn.Add("section insuffisante en flexion : augmentez l'épaisseur");
        if (tau > tauLim) warn.Add($"tranchant τu = {tau:0.00} MPa > {tauLim:0.00} MPa (dalle sans armatures d'effort tranchant) : augmentez l'épaisseur");
        if (h < hMin - 1e-9) warn.Add($"épaisseur {h * 100:0} cm < L/10 = {hMin * 100:0} cm (élancement de console)");
        if (defl > deflLim) warn.Add($"flèche estimée {defl:0.0} mm > 2L/250 = {deflLim:0.0} mm");
        r.Mu = mu; r.Vu = vu; r.AsTop = asUse; r.Ok = warn.Count == 0;
        r.Text =
            $"Console de dalle {s.Name} : L = {L:0.00} m, largeur {W:0.00} m, h = {h * 100:0} cm, d = {d * 100:0.0} cm.\n" +
            $"  Charges : G = {g:0.00}, Q = {q:0.00} kN/m²" + (tip > 0 ? $", charge de bout {tip:0.00} kN/m" : "") + $"  →  pu = {pu:0.00} kN/m², ps = {ps:0.00} kN/m².\n" +
            $"  Mu = pu·L²/2" + (tip > 0 ? " + Pu·L" : "") + $" = {mu:0.00} kN·m/m ; Vu = {vu:0.0} kN/m ; τu = {tau:0.00} MPa (limite {tauLim:0.00}).\n" +
            $"  Armatures SUPÉRIEURES (chapeaux) : As = {asReq:0.00} cm²/m (mini {asMin:0.00}) → {top} ({asProv:0.00} cm²/m) ; répartition : {dist}.\n" +
            $"  Ancrage : ls ≈ {ls:0} cm ; les chapeaux traversent la poutre d'appui et se prolongent dans la dalle voisine d'au moins max(L ; ls) = {Math.Max(L * 100, ls):0} cm ; retour (crochet) en rive libre.\n" +
            $"  Flèche estimée en bout : {defl:0.0} mm (limite 2L/250 = {deflLim:0.0} mm ; E long terme = Ec/3, I = 0,5·Ig).\n" +
            $"  Poutre d'appui : torsion linéique mt = {mt:0.00} kN·m/m ; moment de torsion d'extrémité Tu ≈ mt·W/2 = {tEnd:0.0} kN·m (à vérifier : cadres et aciers longitudinaux de torsion).";
        if (warn.Count > 0) r.Text += "\n  ⚠ " + string.Join(" ; ", warn) + ".";
        return r;
    }

    // ------------------------------------------------------------------ calcul d'ensemble
    public static ExtraDesign? Compute(StructModel m, AnalysisOutput o)
    {
        var parts = new List<string>();
        bool ok = true;

        foreach (var r in Slabs(m)) { parts.Add(r.Text); ok &= r.Ok; }

        foreach (var mem in m.Members.Where(x => x.Kind == MaterialKind.ReinforcedConcrete && IsCantileverBeam(m, x)))
        {
            var r = o.Members.FirstOrDefault(x => x.MemberId == mem.Id);
            if (r == null || r.Skipped) continue;
            r.Cantilever = true;
            double L = r.Length, h = r.H;
            double mu = Math.Max(Math.Abs(r.MuHog), Math.Abs(r.MuSag));
            var warn = new List<string>();
            if (h < L / 8.0 - 1e-9) warn.Add($"hauteur {h * 100:0} cm < L/8 = {L / 8 * 100:0} cm (élancement de console)");
            string defl = "";
            var row = o.Global?.Deflections.FirstOrDefault(x => x.MemberId == mem.Id);
            if (row != null)
            {
                double lim = 2 * L * 1000.0 / Math.Max(m.DeflectionLimitDenominator, 1);
                row.LimitMm = lim; row.Ok = row.DeltaMm <= lim + 1e-9;       // console : la flèche limite se rapporte à 2L
                defl = $"flèche en bout {row.DeltaMm:0.0} mm (limite 2L/{m.DeflectionLimitDenominator:0} = {lim:0.0} mm, combinaison {row.Combo})";
                if (!row.Ok) warn.Add($"flèche {row.DeltaMm:0.0} mm > {lim:0.0} mm");
            }
            double ft28 = 0.6 + 0.06 * m.Fc28;
            double ls = r.TopDia * m.Fe / (4 * 0.6 * 1.5 * 1.5 * ft28) / 10.0;
            if (!r.Ok) warn.Add("sections ou armatures non conformes (voir le tableau des barres)");
            parts.Add(
                $"Poutre console {mem.Id} ({r.B * 100:0}x{r.H * 100:0} cm, L = {L:0.00} m) : Mu(encastrement) = {mu:0.0} kN·m, Vu = {Math.Abs(r.Vu):0.0} kN ; chapeaux {r.TopN} HA{r.TopDia} ({r.AsTop:0.0} cm²) sur TOUTE la longueur (aucune coupure d'armatures) ;\n" +
                $"  ancrage dans le poteau / la poutre d'appui : ls ≈ {ls:0} cm (crochets si l'appui est plus court) ; cadres rapprochés à l'encastrement ; " + (defl != "" ? defl + "." : "flèche non disponible."));
            if (warn.Count > 0) { parts[^1] += "\n  ⚠ " + string.Join(" ; ", warn) + "."; ok = false; }
        }

        if (parts.Count == 0) return null;
        return new ExtraDesign { Title = "Consoles : dalles en porte-à-faux et poutres console", Ok = ok, Text = string.Join("\n\n", parts) };
    }
}
