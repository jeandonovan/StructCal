using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine;

/// <summary>Opérations sur un ensemble de barres sélectionnées : copie avec décalage (et répétition), symétrie, déplacement, suppression,
/// charge répartie, sélection par règle. Les nœuds sont fusionnés par position pour que les copies se raccordent à l'existant.</summary>
public static class SelectionTools
{
    private static (long, long, long) Key(double x, double y, double z) => ((long)Math.Round(x * 1000), (long)Math.Round(y * 1000), (long)Math.Round(z * 1000));

    private sealed class NodePool
    {
        private readonly StructModel _m;
        private readonly Dictionary<(long, long, long), int> _by = new();
        private int _next;
        public NodePool(StructModel m)
        {
            _m = m;
            foreach (var n in m.Nodes) _by[Key(n.X, n.Y, n.Z)] = n.Id;
            _next = m.Nodes.Count == 0 ? 1 : m.Nodes.Max(n => n.Id) + 1;
        }
        public int Get(double x, double y, double z)
        {
            var k = Key(x, y, z);
            if (_by.TryGetValue(k, out int id)) return id;
            id = _next++;
            _m.Nodes.Add(new Node { Id = id, X = Math.Round(x, 6), Y = Math.Round(y, 6), Z = Math.Round(z, 6) });
            _by[k] = id;
            return id;
        }
    }

    public static List<int> NodesOf(StructModel m, IEnumerable<int> memberIds)
    {
        var set = new HashSet<int>(memberIds);
        return m.Members.Where(x => set.Contains(x.Id)).SelectMany(x => new[] { x.NodeI, x.NodeJ }).Distinct().ToList();
    }

    private static Member CloneMember(Member s, int id, int a, int b) => new()
    {
        Id = id, NodeI = a, NodeJ = b, Type = s.Type, Kind = s.Kind, B = s.B, H = s.H, Cover = s.Cover, LfFactor = s.LfFactor,
        Crack = s.Crack, PropA = s.PropA, PropIy = s.PropIy, PropIz = s.PropIz, PropJ = s.PropJ, Profile = s.Profile
    };

    /// <summary>Copie les barres count fois, décalées de (dx,dy,dz) à chaque copie. Retourne les identifiants des nouvelles barres.</summary>
    public static List<int> Copy(StructModel m, IEnumerable<int> memberIds, double dx, double dy, double dz, int count, bool copyLoads = true, bool copySupports = false)
    {
        var ids = memberIds.ToList();
        var created = new List<int>();
        var pool = new NodePool(m);
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var existing = new HashSet<(int, int)>(m.Members.Select(q => (Math.Min(q.NodeI, q.NodeJ), Math.Max(q.NodeI, q.NodeJ))));
        int nextMem = m.Members.Count == 0 ? 1 : m.Members.Max(q => q.Id) + 1;
        var srcMembers = m.Members.Where(q => ids.Contains(q.Id) && nodes.ContainsKey(q.NodeI) && nodes.ContainsKey(q.NodeJ)).ToList();
        var srcNodeIds = srcMembers.SelectMany(q => new[] { q.NodeI, q.NodeJ }).Distinct().ToList();
        for (int c = 1; c <= Math.Max(1, count); c++)
        {
            var map = new Dictionary<int, int>();
            foreach (int nid in srcNodeIds)
            {
                var n = nodes[nid];
                map[nid] = pool.Get(n.X + dx * c, n.Y + dy * c, n.Z + dz * c);
            }
            foreach (var s in srcMembers)
            {
                int a = map[s.NodeI], b = map[s.NodeJ];
                if (a == b || !existing.Add((Math.Min(a, b), Math.Max(a, b)))) continue;
                var nm = CloneMember(s, nextMem++, a, b);
                m.Members.Add(nm); created.Add(nm.Id);
                if (copyLoads)
                    foreach (var l in m.MemberLoads.Where(q => q.MemberId == s.Id).ToList())
                        m.MemberLoads.Add(l.Clone(nm.Id));
            }
            if (copyLoads)
                foreach (var sl in m.SurfaceLoads.ToList())
                {
                    var corners = new[] { (sl.X0, sl.Y0), (sl.X1, sl.Y0), (sl.X1, sl.Y1), (sl.X0, sl.Y1) };
                    bool all = corners.All(cn => srcNodeIds.Any(nid => Math.Abs(nodes[nid].X - cn.Item1) < 2e-3 && Math.Abs(nodes[nid].Y - cn.Item2) < 2e-3 && Math.Abs(nodes[nid].Z - sl.Z) < 2e-3));
                    if (!all) continue;
                    var cp = new SurfaceLoad { Name = sl.Name, Case = sl.Case, Q = sl.Q, Distribution = sl.Distribution, Z = Math.Round(sl.Z + dz * c, 6),
                                               X0 = sl.X0 + dx * c, X1 = sl.X1 + dx * c, Y0 = sl.Y0 + dy * c, Y1 = sl.Y1 + dy * c };
                    if (!m.SurfaceLoads.Any(q => q.Case == cp.Case && Math.Abs(q.Z - cp.Z) < 2e-3 && Math.Abs(q.X0 - cp.X0) < 2e-3 && Math.Abs(q.Y0 - cp.Y0) < 2e-3 && Math.Abs(q.X1 - cp.X1) < 2e-3 && Math.Abs(q.Y1 - cp.Y1) < 2e-3))
                        m.SurfaceLoads.Add(cp);
                }
            if (copyLoads)
                foreach (int nid in srcNodeIds)
                    foreach (var l in m.NodalLoads.Where(q => q.NodeId == nid).ToList())
                        if (!m.NodalLoads.Any(q => q.NodeId == map[nid] && q.Case == l.Case)) m.NodalLoads.Add(new NodalLoad { NodeId = map[nid], Case = l.Case, Fx = l.Fx, Fy = l.Fy, Fz = l.Fz, Mx = l.Mx, My = l.My, Mz = l.Mz });
            if (copySupports)
                foreach (int nid in srcNodeIds)
                {
                    var sp = m.Supports.FirstOrDefault(q => q.NodeId == nid);
                    if (sp != null && !m.Supports.Any(q => q.NodeId == map[nid]))
                        m.Supports.Add(new SupportDef { NodeId = map[nid], Ux = sp.Ux, Uy = sp.Uy, Uz = sp.Uz, Rx = sp.Rx, Ry = sp.Ry, Rz = sp.Rz });
                }
        }
        return created;
    }

    /// <summary>Charge de barre symétrique : composantes globales dans le sens de la normale inversées ; les moments (pseudo-vecteurs) suivent la règle inverse.</summary>
    private static MemberLoad MirrorLoad(MemberLoad l, int newId, char axis)
    {
        var c = l.Clone(newId);
        if (c.Frame == LoadFrame.Local) return c;
        if (axis == 'x') { c.Wx = -c.Wx; c.Wx2 = -c.Wx2; c.Px = -c.Px; c.My = -c.My; c.Mz = -c.Mz; }
        else { c.Wy = -c.Wy; c.Wy2 = -c.Wy2; c.Py = -c.Py; c.Mx = -c.Mx; c.Mz = -c.Mz; }
        return c;
    }

    /// <summary>Symétrie par rapport au plan x = coord (axis 'x') ou y = coord (axis 'y'). keepOriginal = false : les barres d'origine sont remplacées.</summary>
    public static List<int> Mirror(StructModel m, IEnumerable<int> memberIds, char axis, double coord, bool keepOriginal = true)
    {
        var ids = memberIds.ToList();
        var pool = new NodePool(m);
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var existing = new HashSet<(int, int)>(m.Members.Select(q => (Math.Min(q.NodeI, q.NodeJ), Math.Max(q.NodeI, q.NodeJ))));
        int nextMem = m.Members.Count == 0 ? 1 : m.Members.Max(q => q.Id) + 1;
        var created = new List<int>();
        var src = m.Members.Where(q => ids.Contains(q.Id) && nodes.ContainsKey(q.NodeI) && nodes.ContainsKey(q.NodeJ)).ToList();
        var map = new Dictionary<int, int>();
        foreach (int nid in src.SelectMany(q => new[] { q.NodeI, q.NodeJ }).Distinct().ToList())
        {
            var n = nodes[nid];
            double x = axis == 'x' ? 2 * coord - n.X : n.X, y = axis == 'y' ? 2 * coord - n.Y : n.Y;
            map[nid] = pool.Get(x, y, n.Z);
        }
        foreach (var s in src)
        {
            int a = map[s.NodeI], b = map[s.NodeJ];
            if (a == b || !existing.Add((Math.Min(a, b), Math.Max(a, b)))) continue;
            var nm = CloneMember(s, nextMem++, a, b);
            m.Members.Add(nm); created.Add(nm.Id);
            foreach (var l in m.MemberLoads.Where(q => q.MemberId == s.Id).ToList())
                m.MemberLoads.Add(MirrorLoad(l, nm.Id, axis));
        }
        foreach (var kv in map)
        {
            var sp = m.Supports.FirstOrDefault(q => q.NodeId == kv.Key);
            if (sp != null && !m.Supports.Any(q => q.NodeId == kv.Value))
                m.Supports.Add(new SupportDef { NodeId = kv.Value, Ux = sp.Ux, Uy = sp.Uy, Uz = sp.Uz, Rx = sp.Rx, Ry = sp.Ry, Rz = sp.Rz });
        }
        if (!keepOriginal) Delete(m, src.Select(q => q.Id).Where(id => !created.Contains(id)));
        return created;
    }

    /// <summary>Déplace tous les nœuds des barres choisies (les barres voisines qui partagent ces nœuds suivent). Retourne le nombre de nœuds déplacés.</summary>
    public static int Move(StructModel m, IEnumerable<int> memberIds, double dx, double dy, double dz)
    {
        var set = new HashSet<int>(NodesOf(m, memberIds));
        int n = 0;
        var moved = m.Nodes.Where(q => set.Contains(q.Id)).Select(q => (q.X, q.Y, q.Z)).ToList();
        foreach (var sl in m.SurfaceLoads)
        {
            var corners = new[] { (sl.X0, sl.Y0), (sl.X1, sl.Y0), (sl.X1, sl.Y1), (sl.X0, sl.Y1) };
            if (!corners.All(cn => moved.Any(q => Math.Abs(q.X - cn.Item1) < 2e-3 && Math.Abs(q.Y - cn.Item2) < 2e-3 && Math.Abs(q.Z - sl.Z) < 2e-3))) continue;
            sl.X0 += dx; sl.X1 += dx; sl.Y0 += dy; sl.Y1 += dy; sl.Z += dz;
        }
        foreach (var nd in m.Nodes.Where(q => set.Contains(q.Id))) { nd.X = Math.Round(nd.X + dx, 6); nd.Y = Math.Round(nd.Y + dy, 6); nd.Z = Math.Round(nd.Z + dz, 6); n++; }
        return n;
    }

    /// <summary>Supprime les barres (et leurs charges) puis les nœuds devenus inutiles (sans barre, appui ni charge).</summary>
    public static int Delete(StructModel m, IEnumerable<int> memberIds, bool removeOrphanNodes = true)
    {
        var ids = new HashSet<int>(memberIds);
        var nodesTouched = NodesOf(m, ids);
        int n = 0;
        foreach (var mem in m.Members.Where(q => ids.Contains(q.Id)).ToList())
        {
            foreach (var l in m.MemberLoads.Where(q => q.MemberId == mem.Id).ToList()) m.MemberLoads.Remove(l);
            m.Members.Remove(mem); n++;
        }
        if (removeOrphanNodes)
            foreach (int nid in nodesTouched)
            {
                bool used = m.Members.Any(q => q.NodeI == nid || q.NodeJ == nid) || m.Supports.Any(q => q.NodeId == nid) || m.NodalLoads.Any(q => q.NodeId == nid);
                if (used) continue;
                var nd = m.Nodes.FirstOrDefault(q => q.Id == nid);
                if (nd != null) m.Nodes.Remove(nd);
            }
        return n;
    }

    /// <summary>Ajoute une charge répartie verticale (kN/m, positive vers le bas) à chaque barre.</summary>
    public static int AddMemberLoad(StructModel m, IEnumerable<int> memberIds, ActionType c, double downKnPerM)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            if (!m.Members.Any(q => q.Id == id)) continue;
            m.MemberLoads.Add(new MemberLoad { MemberId = id, Case = c, Wz = -downKnPerM });
            n++;
        }
        return n;
    }

    /// <summary>Barres correspondant à une règle : all, columns, beams, steel, concrete, sameSection (comme refMember), sameLevel (niveau de refMember).</summary>
    public static List<int> SelectWhere(StructModel m, string rule, int refMember = -1)
    {
        var info = StructureAnalyzer.Analyze(m);
        var rf = m.Members.FirstOrDefault(q => q.Id == refMember);
        IEnumerable<Member> q0 = m.Members;
        switch (rule)
        {
            case "columns": q0 = q0.Where(q => q.Type == MemberType.Column); break;
            case "beams": q0 = q0.Where(q => q.Type == MemberType.Beam); break;
            case "steel": q0 = q0.Where(q => q.Kind == MaterialKind.Steel); break;
            case "concrete": q0 = q0.Where(q => q.Kind == MaterialKind.ReinforcedConcrete); break;
            case "sameSection":
                if (rf == null) return new List<int>();
                q0 = q0.Where(q => q.Kind == rf.Kind && q.Type == rf.Type && (rf.Kind == MaterialKind.Steel ? q.Profile == rf.Profile : Math.Abs(q.B - rf.B) < 1e-6 && Math.Abs(q.H - rf.H) < 1e-6));
                break;
            case "sameLevel":
                if (rf == null || !info.MemberLevel.TryGetValue(rf.Id, out int lv)) return new List<int>();
                q0 = q0.Where(q => info.MemberLevel.TryGetValue(q.Id, out int l2) && l2 == lv);
                break;
        }
        return q0.Select(q => q.Id).ToList();
    }
}
