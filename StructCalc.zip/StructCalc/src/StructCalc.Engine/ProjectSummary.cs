using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Synthèse du projet après calcul : état global, éléments critiques, résultats globaux, quantités, alertes.</summary>
public static class ProjectSummary
{
    private static string Sec(MemberDesignResult r) => r.Kind == MaterialKind.Steel ? r.Profile : $"{r.B * 100:0}x{r.H * 100:0}";

    public static List<string> Alerts(StructModel m, AnalysisOutput o)
    {
        var a = new List<string>();
        foreach (var r in o.Members.Where(x => !x.Ok && !x.Skipped)) a.Add($"Barre {r.MemberId} ({Sec(r)}) non vérifiée : {(r.Warnings.Count > 0 ? r.Warnings[0] : "voir détail")}");
        foreach (var r in o.Members.Where(x => x.Skipped)) a.Add($"Barre {r.MemberId} non traitée : {(r.Warnings.Count > 0 ? r.Warnings[0] : "norme indisponible")}");
        if (o.Global != null)
        {
            foreach (var d in o.Global.Deflections.Where(x => !x.Ok)) a.Add($"Flèche excessive barre {d.MemberId} : {d.DeltaMm:0.0} mm > {d.LimitMm:0.0} mm (L/{m.DeflectionLimitDenominator:0}).");
            foreach (var d in o.Global.Drifts.Where(x => !x.Ok)) a.Add($"Déplacement d'étage {d.Level} ({d.Basis}) : h/{d.Ratio:0} < h/{d.LimitDenominator:0}.");
        }
        var q = Quantities.Compute(m, o);
        if (q.ConcreteM3 > 1 && (q.RebarRatioKgM3 > 220)) a.Add($"Ratio d'acier élevé ({q.RebarRatioKgM3:0} kg/m³) : sections probablement trop petites.");
        if (q.ConcreteM3 > 1 && q.RebarRatioKgM3 > 0 && q.RebarRatioKgM3 < 45) a.Add($"Ratio d'acier faible ({q.RebarRatioKgM3:0} kg/m³) : vérifiez les charges, ou sections surdimensionnées.");
        if (m.Supports.Count == 0) a.Add("Aucun appui défini.");
        if (!m.NodalLoads.Any() && !m.MemberLoads.Any() && !m.SurfaceLoads.Any() && !m.Slabs.Any()) a.Add("Aucune charge saisie (seul le poids propre est pris en compte).");
        return a;
    }

    public static string Build(StructModel m, AnalysisOutput o)
    {
        var sb = new StringBuilder();
        var q = Quantities.Compute(m, o);
        int ok = o.Members.Count(r => r.Ok && !r.Skipped), ko = o.Members.Count(r => !r.Ok && !r.Skipped), sk = o.Members.Count(r => r.Skipped);
        sb.AppendLine($"SYNTHÈSE DU PROJET - {m.Name}");
        sb.AppendLine(new string('=', 60));
        sb.AppendLine($"Nœuds : {m.Nodes.Count}   Barres : {m.Members.Count}   Appuis : {m.Supports.Count}   Dalles : {m.Slabs.Count}");
        sb.AppendLine($"Normes : BA {o.RcCode}   CM {o.SteelCode}");
        sb.AppendLine($"Résultat : {(o.AllOk ? "TOUT EST VÉRIFIÉ ✔" : "DES ÉLÉMENTS NE SONT PAS VÉRIFIÉS ✖")}   ({ok} barres OK, {ko} non OK, {sk} non traitées)");
        var nok = NonOkReport.Collect(o);
        if (nok.Count > 0) sb.AppendLine($"ÉLÉMENTS NON OK : {nok.Count} (" + string.Join(", ", NonOkReport.ByType(nok).Select(t => $"{t.Type} {t.Count}")) + ")");
        sb.AppendLine();
        var steel = o.Members.Where(r => r.Kind == MaterialKind.Steel && !r.Skipped).OrderByDescending(r => r.Utilization).Take(5).ToList();
        if (steel.Count > 0)
        {
            sb.AppendLine("Barres acier les plus chargées :");
            foreach (var r in steel) sb.AppendLine($"  Barre {r.MemberId,3}  {r.Profile,-10} taux de travail {r.Utilization:P0}");
            sb.AppendLine();
        }
        if (o.Global != null)
        {
            var g = o.Global;
            sb.AppendLine("Résultats globaux :");
            sb.AppendLine($"  Déplacement maximal de service : {g.MaxDisplacementMm:0.0} mm ({g.DeformedCombo})");
            if (g.Deflections.Count > 0)
            {
                var w = g.Deflections.OrderByDescending(d => d.DeltaMm / Math.Max(d.LimitMm, 1e-9)).First();
                sb.AppendLine($"  Flèche la plus défavorable : barre {w.MemberId}, {w.DeltaMm:0.0} mm (L/{w.Ratio:0}, limite L/{m.DeflectionLimitDenominator:0})  {(w.Ok ? "OK" : "NON OK")}");
            }
            foreach (var d in g.Drifts.OrderByDescending(x => x.DeltaMm / x.HeightM).Take(2))
                sb.AppendLine($"  Déplacement d'étage ({d.Basis}) {d.Level} : {d.DeltaMm:0.0} mm = h/{d.Ratio:0} (limite h/{d.LimitDenominator:0})  {(d.Ok ? "OK" : "NON OK")}");
            foreach (var kv in g.TotalFzByCase) sb.AppendLine($"  Somme des réactions verticales, cas {kv.Key} : {kv.Value:0.0} kN");
            sb.AppendLine();
        }
        sb.AppendLine("Quantités (estimation) :");
        sb.AppendLine($"  Béton {q.ConcreteM3:0.0} m³   Coffrage {q.FormworkM2:0} m²   Aciers HA {q.RebarKg + q.StirrupKg:0} kg   Charpente {q.ProfileKg:0} kg");
        if (q.ConcreteM3 > 0) sb.AppendLine($"  Ratio d'acier : {q.RebarRatioKgM3:0} kg/m³ de béton");
        var alerts = Alerts(m, o);
        sb.AppendLine();
        sb.AppendLine(alerts.Count == 0 ? "Aucune alerte." : $"ALERTES ({alerts.Count}) :");
        foreach (var al in alerts.Take(30)) sb.AppendLine("  ! " + al);
        if (alerts.Count > 30) sb.AppendLine($"  ... et {alerts.Count - 30} autre(s).");
        return sb.ToString();
    }
}
