using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Choix faits dans la fenêtre « Nouveau projet ».</summary>
public sealed class NewProjectOptions
{
    public string Name { get; set; } = "Nouveau projet";
    public string Folder { get; set; } = "";
    /// <summary>Bâtiment, Fondations, Ouvrage industriel ou Autre.</summary>
    public string ProjectType { get; set; } = "Bâtiment";
    /// <summary>m, cm ou mm.</summary>
    public string Unit { get; set; } = "m";
    /// <summary>« Béton armé », « Acier » ou « Mixte ».</summary>
    public string StructuralSystem { get; set; } = "Béton armé";
    /// <summary>BAEL91, EC2 ou CM66.</summary>
    public string Norm { get; set; } = "BAEL91";
    /// <summary>« Vierge » ou « Exemple ».</summary>
    public string Template { get; set; } = "Vierge";
    /// <summary>Nom d'un modèle du catalogue <see cref="ProjectTemplates"/> (page « Modèles » de l'accueil) ; vide = utiliser <see cref="Template"/>.</summary>
    public string TemplateName { get; set; } = "";
}

/// <summary>Création d'un projet : modèle de départ, réglages choisis, fichier enregistré. Sans interface, donc testable.</summary>
public static class ProjectFactory
{
    public static readonly string[] ProjectTypes = { "Bâtiment", "Fondations", "Ouvrage industriel", "Autre" };
    public static readonly string[] Units = { "m", "cm", "mm" };
    public static readonly string[] Systems = { "Béton armé", "Acier", "Mixte" };
    public static readonly string[] Norms = { "BAEL91", "EC2", "CM66" };

    /// <summary>Dossier proposé par défaut : Documents\StructCalc.</summary>
    public static string DefaultFolder() => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "StructCalc");

    /// <summary>Norme par défaut qui va avec un système constructif.</summary>
    public static string DefaultNormFor(string system) => system == "Acier" ? "CM66" : "BAEL91";

    public static string PathOf(NewProjectOptions o) =>
        System.IO.Path.Combine(o.Folder.Trim(), FileName(o.Name) + AppInfo.FileExt);

    private static string FileName(string name)
    {
        foreach (char c in System.IO.Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
        return name.Trim().TrimEnd('.');
    }

    /// <summary>Message d'erreur en français si les choix ne permettent pas de créer le projet, null sinon.</summary>
    public static string? Validate(NewProjectOptions o)
    {
        if (string.IsNullOrWhiteSpace(o.Name) || FileName(o.Name) == "") return "Donnez un nom au projet.";
        if (string.IsNullOrWhiteSpace(o.Folder)) return "Choisissez un emplacement d'enregistrement.";
        string full;
        try { full = PathOf(o); } catch { return "L'emplacement n'est pas valide."; }
        if (File.Exists(full)) return "Un projet porte déjà ce nom à cet emplacement. Changez le nom ou l'emplacement.";
        if (!Units.Contains(o.Unit)) return "Unité inconnue.";
        if (!Systems.Contains(o.StructuralSystem)) return "Système structurel inconnu.";
        if (!Norms.Contains(o.Norm)) return "Norme inconnue.";
        return null;
    }

    /// <summary>Construit le modèle de départ avec les réglages choisis (sans écrire de fichier).</summary>
    public static StructModel Build(NewProjectOptions o)
    {
        StructModel m;
        var catalog = string.IsNullOrEmpty(o.TemplateName) ? null : ProjectTemplates.All.FirstOrDefault(t => t.Name == o.TemplateName);
        if (catalog != null) m = catalog.Make();
        else if (o.Template == "Exemple") m = o.StructuralSystem == "Acier" ? ExampleModels.SteelPortal() : ExampleModels.Portal();
        else m = new StructModel();
        m.Name = o.Name.Trim();
        m.Info ??= new ProjectInfo();
        m.Info.ProjectType = o.ProjectType;
        if (o.Norm == "CM66") m.SteelCodeId = "CM66";
        else m.RcCodeId = o.Norm;                                  // BAEL91 ou EC2
        m.Settings ??= new DesignSettings();
        m.Settings.UnitLength = o.Unit;
        m.Settings.UnitSection = o.Unit == "mm" ? "mm" : "cm";
        return m;
    }

    /// <summary>Valide, crée le dossier, construit le modèle et l'enregistre. Retourne le modèle et le chemin ; lève une exception avec un message clair en cas d'échec.</summary>
    public static (StructModel Model, string Path) Create(NewProjectOptions o)
    {
        string? err = Validate(o);
        if (err != null) throw new InvalidOperationException(err);
        Directory.CreateDirectory(o.Folder.Trim());
        var m = Build(o);
        string path = PathOf(o);
        ModelIO.Save(m, path);
        return (m, path);
    }
}
