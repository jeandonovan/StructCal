namespace StructCalc.Engine;

/// <summary>Résolution dense par Cholesky (matrice symétrique définie positive, stockage ligne par ligne).</summary>
internal static class Dense
{
    public static double[] SolveSpd(double[] a, double[] b, int n)
    {
        double maxDiag = 0;
        for (int i = 0; i < n; i++) maxDiag = Math.Max(maxDiag, a[i * n + i]);
        double tol = 1e-12 * Math.Max(maxDiag, 1e-30);
        for (int j = 0; j < n; j++)
        {
            double s = a[j * n + j];
            for (int k = 0; k < j; k++) s -= a[j * n + k] * a[j * n + k];
            if (s <= tol)
                throw new InvalidOperationException("Structure instable ou mal appuyée (matrice de rigidité singulière). Vérifiez les appuis et les liaisons.");
            double ljj = Math.Sqrt(s);
            a[j * n + j] = ljj;
            for (int i = j + 1; i < n; i++)
            {
                double t = a[i * n + j];
                for (int k = 0; k < j; k++) t -= a[i * n + k] * a[j * n + k];
                a[i * n + j] = t / ljj;
            }
        }
        var x = new double[n];
        for (int i = 0; i < n; i++)
        {
            double y = b[i];
            for (int k = 0; k < i; k++) y -= a[i * n + k] * x[k];
            x[i] = y / a[i * n + i];
        }
        for (int i = n - 1; i >= 0; i--)
        {
            double s = x[i];
            for (int k = i + 1; k < n; k++) s -= a[k * n + i] * x[k];
            x[i] = s / a[i * n + i];
        }
        return x;
    }
}

/// <summary>Résolution par Cholesky en bande (matrice symétrique définie positive stockée par ligne, triangle inférieur :
/// a[i * (bw+1) + (i-j)] = A(i,j) pour i-bw <= j <= i). Coût en n·bw² au lieu de n³ : l'essentiel pour les grands bâtiments.</summary>
internal static class BandSolver
{
    public static double[] Solve(double[] a, double[] b, int n, int bw)
    {
        int w = bw + 1;
        double maxDiag = 0;
        for (int i = 0; i < n; i++) maxDiag = Math.Max(maxDiag, a[(long)i * w]);
        double tol = 1e-12 * Math.Max(maxDiag, 1e-30);
        for (int i = 0; i < n; i++)
        {
            int j0 = Math.Max(0, i - bw);
            for (int j = j0; j <= i; j++)
            {
                double s = a[(long)i * w + (i - j)];
                int k0 = Math.Max(j0, j - bw);
                for (int k = k0; k < j; k++) s -= a[(long)i * w + (i - k)] * a[(long)j * w + (j - k)];
                if (j == i)
                {
                    if (s <= tol)
                        throw new InvalidOperationException("Structure instable ou mal appuyée (matrice de rigidité singulière). Vérifiez les appuis et les liaisons.");
                    a[(long)i * w] = Math.Sqrt(s);
                }
                else a[(long)i * w + (i - j)] = s / a[(long)j * w];
            }
        }
        var x = new double[n];
        for (int i = 0; i < n; i++)
        {
            double y = b[i];
            for (int k = Math.Max(0, i - bw); k < i; k++) y -= a[(long)i * w + (i - k)] * x[k];
            x[i] = y / a[(long)i * w];
        }
        for (int i = n - 1; i >= 0; i--)
        {
            double s = x[i];
            int kmax = Math.Min(n - 1, i + bw);
            for (int k = i + 1; k <= kmax; k++) s -= a[(long)k * w + (k - i)] * x[k];
            x[i] = s / a[(long)i * w];
        }
        return x;
    }
}

/// <summary>Numérotation de Cuthill-McKee inversée des nœuds : réduit la largeur de bande de la matrice de rigidité.</summary>
internal static class Reorder
{
    /// <summary>Retourne order : order[k] = indice du nœud placé en position k.</summary>
    public static int[] Rcm(int n, IEnumerable<(int A, int B)> edges)
    {
        var adj = new HashSet<int>[n];
        for (int i = 0; i < n; i++) adj[i] = new HashSet<int>();
        foreach (var (a, b) in edges)
        {
            if (a == b || a < 0 || b < 0 || a >= n || b >= n) continue;
            adj[a].Add(b); adj[b].Add(a);
        }
        var starts = Enumerable.Range(0, n).OrderBy(i => adj[i].Count).ToList();
        var seen = new bool[n];
        var order = new List<int>(n);
        foreach (int s in starts)
        {
            if (seen[s]) continue;
            var q = new Queue<int>();
            q.Enqueue(s); seen[s] = true;
            while (q.Count > 0)
            {
                int u = q.Dequeue();
                order.Add(u);
                foreach (int v in adj[u].OrderBy(v => adj[v].Count))
                    if (!seen[v]) { seen[v] = true; q.Enqueue(v); }
            }
        }
        order.Reverse();
        return order.ToArray();
    }
}
