using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Une section proposée pour une barre.</summary>
public sealed class PreDesignItem
{
    public int MemberId { get; set; }
    public string Label { get; set; } = "";
    public double OldB { get; set; }
    public double OldH { get; set; }
    public double NewB { get; set; }
    public double NewH { get; set; }
    public bool Changes => Math.Abs(OldB - NewB) > 1e-6 || Math.Abs(OldH - NewH) > 1e-6;
}

/// <summary>Résultat d'un prédimensionnement : sections proposées + explication à afficher avant d'appliquer.</summary>
public sealed class PreDesignReport
{
    public List<PreDesignItem> Items { get; } = new();
    public List<string> Lines { get; } = new();
    public string Title { get; set; } = "";
    public bool UsedResults { get; set; }
    public bool AnyChange => Items.Any(i => i.Changes);
    public string Text => string.Join("\n", Lines);
}

/// <summary>Proposition pour une dalle, un escalier ou une semelle (valeurs à appliquer par l'appelant).</summary>
public sealed class PreDesignValues
{
    public string Title { get; set; } = "";
    public List<string> Lines { get; } = new();
    public Dictionary<string, double> V { get; } = new();
    public string Text => string.Join("\n", Lines);
}

/// <summary>
/// Prédimensionnement rapide (règles de pratique BAEL / RPA 99 / EC2) des poutres, poteaux, dalles, escaliers et semelles.
/// Les poutres qui se suivent (continues) et les poteaux superposés verticalement sont traités ensemble : section uniforme
/// pour une poutre continue, section jamais plus petite en bas qu'en haut pour une pile de poteaux. Après F5, les efforts
/// calculés (Mu, Vu, Nu) affinent les règles géométriques.
/// </summary>
public static class PreDesign
{
    private static double Ceil5(double v) => Math.Ceiling(v / 0.05 - 1e-9) * 0.05;
    private static double Round3(double v) => Math.Round(v, 3);

    private static Node? N(StructModel m, int id) => m.Nodes.FirstOrDefault(n => n.Id == id);

    public static double Length(StructModel m, Member b)
    {
        var a = N(m, b.NodeI); var c = N(m, b.NodeJ);
        if (a == null || c == null) return 0;
        double dx = c.X - a.X, dy = c.Y - a.Y, dz = c.Z - a.Z;
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static double[] Dir(StructModel m, Member b)
    {
        var a = N(m, b.NodeI); var c = N(m, b.NodeJ);
        if (a == null || c == null) return new double[3];
        double dx = c.X - a.X, dy = c.Y - a.Y, dz = c.Z - a.Z;
        double l = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        return l < 1e-9 ? new double[3] : new[] { dx / l, dy / l, dz / l };
    }

    private static bool IsRc(Member b) => b.Kind == MaterialKind.ReinforcedConcrete;

    // ------------------------------------------------------------------ chaînes
    /// <summary>Poutres qui se suivent : même direction (écart &lt; 10°) et nœud commun, sans tenir compte des poteaux ni des poutres perpendiculaires.</summary>
    public static List<int> BeamChain(StructModel m, int memberId)
    {
        var start = m.Members.FirstOrDefault(x => x.Id == memberId);
        if (start == null || start.Type != MemberType.Beam || !IsRc(start)) return new List<int> { memberId };
        var chain = new List<Member> { start };
        var seen = new HashSet<int> { start.Id };
        var front = new Queue<Member>(); front.Enqueue(start);
        while (front.Count > 0)
        {
            var cur = front.Dequeue();
            var d0 = Dir(m, cur);
            foreach (int node in new[] { cur.NodeI, cur.NodeJ })
            {
                foreach (var o in m.Members)
                {
                    if (seen.Contains(o.Id) || o.Type != MemberType.Beam || !IsRc(o)) continue;
                    if (o.NodeI != node && o.NodeJ != node) continue;
                    var d1 = Dir(m, o);
                    double dot = Math.Abs(d0[0] * d1[0] + d0[1] * d1[1] + d0[2] * d1[2]);
                    if (dot < Math.Cos(10 * Math.PI / 180)) continue;
                    seen.Add(o.Id); chain.Add(o); front.Enqueue(o);
                }
            }
        }
        var ds = Dir(m, start);
        return chain.OrderBy(x => Pos(m, x, ds)).Select(x => x.Id).ToList();
    }

    private static double Pos(StructModel m, Member b, double[] d)
    {
        var a = N(m, b.NodeI); var c = N(m, b.NodeJ);
        if (a == null || c == null) return 0;
        double pa = a.X * d[0] + a.Y * d[1] + a.Z * d[2];
        double pc = c.X * d[0] + c.Y * d[1] + c.Z * d[2];
        return (pa + pc) / 2;
    }

    /// <summary>Poteaux superposés verticalement (même nœud entre deux poteaux verticaux), du bas vers le haut.</summary>
    public static List<int> ColumnStack(StructModel m, int memberId)
    {
        var start = m.Members.FirstOrDefault(x => x.Id == memberId);
        if (start == null || start.Type != MemberType.Column || !IsRc(start) || !IsVertical(m, start)) return new List<int> { memberId };
        var stack = new List<Member> { start };
        var seen = new HashSet<int> { start.Id };
        var front = new Queue<Member>(); front.Enqueue(start);
        while (front.Count > 0)
        {
            var cur = front.Dequeue();
            foreach (int node in new[] { cur.NodeI, cur.NodeJ })
                foreach (var o in m.Members)
                {
                    if (seen.Contains(o.Id) || o.Type != MemberType.Column || !IsRc(o) || !IsVertical(m, o)) continue;
                    if (o.NodeI != node && o.NodeJ != node) continue;
                    seen.Add(o.Id); stack.Add(o); front.Enqueue(o);
                }
        }
        return stack.OrderBy(x => Math.Min(N(m, x.NodeI)?.Z ?? 0, N(m, x.NodeJ)?.Z ?? 0)).Select(x => x.Id).ToList();
    }

    private static bool IsVertical(StructModel m, Member b)
    {
        var d = Dir(m, b);
        return Math.Abs(d[2]) > 0.95;
    }

    // ------------------------------------------------------------------ poutres et poteaux
    private static (double Nmin, string Zone) MinColumn(StructModel m)
    {
        if (!m.Seismic.Enabled) return (0.25, "");
        return m.Seismic.Zone switch { "I" => (0.25, "zone I"), "III" => (0.35, "zone III"), _ => (0.30, "zone " + m.Seismic.Zone) };
    }

    /// <summary>Prédimensionne des poutres et des poteaux. <paramref name="chains"/> : regroupe les poutres continues et les poteaux superposés.</summary>
    public static PreDesignReport Members(StructModel m, IEnumerable<int> ids, AnalysisOutput? o, bool chains)
    {
        var rep = new PreDesignReport { Title = "Prédimensionnement des barres", UsedResults = o != null && o.Members.Count > 0 };
        var done = new HashSet<int>();
        foreach (int id in ids.ToList())
        {
            if (done.Contains(id)) continue;
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            if (!IsRc(mem)) { rep.Lines.Add($"Barre {id} : acier, prédimensionnement non traité ici (choix automatique du profilé au calcul)."); done.Add(id); continue; }
            var group = new List<int> { id };
            if (chains) group = mem.Type == MemberType.Column ? ColumnStack(m, id) : BeamChain(m, id);
            foreach (int g in group) done.Add(g);
            if (mem.Type == MemberType.Column) Columns(m, group, o, rep); else Beams(m, group, o, rep);
        }
        if (rep.Items.Count == 0 && rep.Lines.Count == 0) rep.Lines.Add("Aucune barre en béton armé à prédimensionner.");
        if (!rep.UsedResults) rep.Lines.Add("Calcul non lancé : règles géométriques seules. Après F5 (puis nouveau prédimensionnement), les efforts calculés sont pris en compte.");
        return rep;
    }

    private static void Beams(StructModel m, List<int> group, AnalysisOutput? o, PreDesignReport rep)
    {
        var mems = group.Select(i => m.Members.First(x => x.Id == i)).ToList();
        double Lmax = mems.Max(x => Length(m, x));
        bool cont = mems.Count > 1;
        double hGeo = Lmax / (cont ? 13.0 : 11.0);
        double fbu = 0.85 * m.Fc28 / 1.5;                  // MPa
        double tauLim = Math.Min(0.2 * m.Fc28 / 1.5, 5.0);
        double Mu = 0, Vu = 0;
        if (o != null)
            foreach (var mm in mems)
            {
                var r = o.Members.FirstOrDefault(x => x.MemberId == mm.Id);
                if (r == null) continue;
                Mu = Math.Max(Mu, Math.Max(Math.Abs(r.MuSag), Math.Abs(r.MuHog)));
                Vu = Math.Max(Vu, Math.Abs(r.Vu));
            }
        double cover = mems.Max(x => x.Cover);
        double h = Math.Max(0.30, Ceil5(hGeo)), b = 0.25;
        for (int k = 0; k < 60; k++)
        {
            b = Math.Clamp(Ceil5(0.4 * h), 0.25, 0.50);
            double d = h - cover;
            bool okM = Mu <= 0 || Mu / 1000.0 <= 0.30 * b * d * d * fbu * 1.0;
            bool okV = Vu <= 0 || Vu / 1000.0 / (b * d) <= tauLim;
            if (okM && okV) break;
            h += 0.05;
        }
        string basis = $"h = L/{(cont ? 13 : 11)} = {Round3(hGeo) * 100:0} cm" + (Mu > 0 ? $" ; flexion Mu = {Mu:0} kN·m, Vu = {Vu:0} kN" : "");
        rep.Lines.Add((cont ? $"Poutre continue ({mems.Count} travées : {string.Join(", ", group)}), portée max {Lmax:0.00} m" : $"Poutre {group[0]}, portée {Lmax:0.00} m") + $" → {b * 100:0}x{h * 100:0} cm  ({basis}).");
        foreach (var mm in mems)
            rep.Items.Add(new PreDesignItem { MemberId = mm.Id, Label = "Poutre " + mm.Id, OldB = mm.B, OldH = mm.H, NewB = b, NewH = h });
    }

    private static void Columns(StructModel m, List<int> group, AnalysisOutput? o, PreDesignReport rep)
    {
        var mems = group.Select(i => m.Members.First(x => x.Id == i)).ToList();      // bas -> haut
        var (nmin, zone) = MinColumn(m);
        double nuLim = 0.40;                                                          // Nu (ELU) / (B·fc28)
        var req = new List<(double B, double H, double A, double Nu, double he)>();
        foreach (var mm in mems)
        {
            double he = Math.Max(Length(m, mm) - 0.40, 1.0);
            double minD = Math.Max(nmin, Ceil5(he / 20.0));
            double Nu = 0;
            if (o != null) { var r = o.Members.FirstOrDefault(x => x.MemberId == mm.Id); if (r != null) Nu = Math.Abs(r.NuMax); }
            double A = Nu > 0 ? Nu / (nuLim * m.Fc28 * 1000.0) : 0;
            double ratio = Math.Clamp(mm.H / Math.Max(mm.B, 0.05), 0.5, 2.0);
            double bb = Math.Max(minD, Ceil5(Math.Sqrt(A / ratio)));
            double hh = Math.Max(minD, Ceil5(Math.Max(A / bb, bb * ratio * 0.999)));
            req.Add((bb, hh, A, Nu, he));
        }
        // jamais plus petit en bas qu'au-dessus : on remonte les maxima du haut vers le bas
        for (int i = req.Count - 2; i >= 0; i--)
        {
            var up = req[i + 1]; var me = req[i];
            req[i] = (Math.Max(me.B, up.B), Math.Max(me.H, up.H), me.A, me.Nu, me.he);
        }
        // rapport RPA : 1/4 < b/h < 4
        for (int i = 0; i < req.Count; i++)
        {
            var q = req[i];
            double bb = q.B, hh = q.H;
            if (bb / hh >= 4) hh = Ceil5(bb / 3.9); else if (hh / bb >= 4) bb = Ceil5(hh / 3.9);
            req[i] = (bb, hh, q.A, q.Nu, q.he);
        }
        bool stack = mems.Count > 1;
        rep.Lines.Add((stack ? $"Poteaux superposés ({mems.Count} niveaux, bas → haut : {string.Join(", ", group)})" : $"Poteau {group[0]}") + $" - minimum {Math.Max(nmin, 0) * 100:0} cm" + (zone != "" ? $" ({zone}, RPA 99 art. 7.4.1)" : "") + ", min(b,h) ≥ he/20, 1/4 < b/h < 4, ν = Nu/(B·fc28) ≤ " + nuLim.ToString("0.00") + (rep.UsedResults ? "." : " (sans effort calculé)."));
        for (int i = 0; i < mems.Count; i++)
        {
            var q = req[i];
            rep.Items.Add(new PreDesignItem { MemberId = mems[i].Id, Label = "Poteau " + mems[i].Id, OldB = mems[i].B, OldH = mems[i].H, NewB = q.B, NewH = q.H });
            rep.Lines.Add($"   • poteau {mems[i].Id} : he ≈ {q.he:0.00} m" + (q.Nu > 0 ? $", Nu = {q.Nu:0} kN → Bmin = {q.A * 1e4:0} cm²" : "") + $"  →  {q.B * 100:0}x{q.H * 100:0} cm.");
        }
    }

    // ------------------------------------------------------------------ dalle
    /// <summary>Épaisseur proposée pour une dalle (m) et, pour un corps creux, la décomposition hourdis + dalle de compression (cm).</summary>
    public static PreDesignValues Slab(StructModel m, SlabPanel s)
    {
        var r = new PreDesignValues { Title = $"Prédimensionnement de la dalle {s.Name}" };
        double lx = Math.Min(s.Lx, s.Ly), ly = Math.Max(s.Lx, s.Ly);
        double span = lx; string way;
        if (s.CalcMode == SlabCalcMode.OneWayX) { span = s.Lx; way = "portant dans le sens X"; }
        else if (s.CalcMode == SlabCalcMode.OneWayY) { span = s.Ly; way = "portant dans le sens Y"; }
        else way = lx / ly < 0.4 ? "portant dans un sens (Lx/Ly < 0,4)" : "portant dans deux sens (Lx/Ly = " + (lx / ly).ToString("0.00") + ")";
        bool oneWay = s.CalcMode is SlabCalcMode.OneWayX or SlabCalcMode.OneWayY || lx / ly < 0.4;
        double h;
        if (s.Kind == SlabKind.CorpsCreux)
        {
            double need = span / 22.5;
            (double hr, double top)[] std = { (16, 4), (20, 4), (25, 5), (30, 5), (35, 5) };
            var pick = std.FirstOrDefault(t => (t.hr + t.top) / 100.0 >= need - 1e-9);
            if (pick.hr == 0) pick = std[^1];
            r.V["HourdisCm"] = pick.hr; r.V["ToppingCm"] = pick.top;
            h = (pick.hr + pick.top) / 100.0;
            r.Lines.Add($"Plancher à corps creux, portée des poutrelles {span:0.00} m : h ≥ L/22,5 = {need * 100:0.0} cm → {pick.hr:0}+{pick.top:0} = {h * 100:0} cm.");
        }
        else
        {
            double den = oneWay ? s.Continuity switch { SlabContinuity.Simple => 20.0, SlabContinuity.Rive => 25.0, _ => 30.0 }
                                : s.Continuity switch { SlabContinuity.Simple => 35.0, SlabContinuity.Rive => 40.0, _ => 45.0 };
            double e = span / den;
            h = Math.Max(0.12, Math.Ceiling(e * 100 - 1e-9) / 100.0);
            r.Lines.Add($"Dalle {s.Kind.ToString().ToLowerInvariant()} {way}, appuis : {s.Continuity.ToString().ToLowerInvariant()} : h ≥ L/{den:0} = {e * 100:0.0} cm (minimum 12 cm) → {h * 100:0} cm.");
        }
        r.V["H"] = h;
        r.Lines.Add($"Épaisseur actuelle : {s.H * 100:0} cm. Poids propre à {h * 100:0} cm : {s.Gamma * h:0.00} kN/m².");
        r.Lines.Add("Règles de pratique : la flèche et le poinçonnement sont vérifiés ensuite par le calcul (F5).");
        return r;
    }

    // ------------------------------------------------------------------ semelle
    public static PreDesignValues Footing(StructModel m, int nodeId, AnalysisOutput? o)
    {
        var r = new PreDesignValues { Title = $"Prédimensionnement de la semelle sous le nœud {nodeId}" };
        var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && IsRc(x) && (x.NodeI == nodeId || x.NodeJ == nodeId));
        double a = col?.B ?? 0.30, b = col?.H ?? 0.30;
        var rr = o?.Global?.Reactions.FirstOrDefault(x => x.NodeId == nodeId);
        double nser = rr != null ? (rr.FzService > 0 ? rr.FzService : rr.Max[2] / 1.4) : 0;
        double sigma = m.SigmaSolKPa > 0 ? m.SigmaSolKPa : 150;
        string sigTxt = m.SigmaSolKPa > 0 ? $"{sigma:0} kPa (données du projet)" : "150 kPa (valeur de défaut : renseignez la contrainte admissible du sol)";
        if (nser <= 0) { r.Lines.Add("Aucune réaction d'appui connue pour ce nœud : lancez le calcul (F5), puis recommencez."); r.V["Valid"] = 0; return r; }
        double S = 1.1 * nser / sigma;                     // 10 % pour le poids de la semelle et des terres
        double bb = Math.Max(0.6, Ceil5(Math.Sqrt(S * b / a)));
        double aa = Math.Max(0.6, Ceil5(S / bb));
        aa = Math.Max(aa, Ceil5(a + 0.10)); bb = Math.Max(bb, Ceil5(b + 0.10));
        double hmin = Math.Max(0.30, Ceil5(Math.Max((aa - a) / 4.0, (bb - b) / 4.0) + 0.05));
        r.V["Valid"] = 1; r.V["A"] = aa; r.V["B"] = bb; r.V["H"] = hmin; r.V["Nser"] = nser; r.V["ColA"] = a; r.V["ColB"] = b;
        r.Lines.Add($"Poteau {a * 100:0}x{b * 100:0} cm, Nser = {nser:0} kN, contrainte admissible {sigTxt}.");
        r.Lines.Add($"Surface S ≥ 1,10·Nser/σ = {S:0.00} m² → semelle {aa:0.00} x {bb:0.00} m (homothétique au poteau, débords ≥ 5 cm).");
        r.Lines.Add($"Hauteur utile d ≥ max(A−a, B−b)/4 → h ≈ {hmin * 100:0} cm (min 30 cm).");
        r.Lines.Add("Les moments, l'excentrement et le ferraillage sont traités par l'assistant Sol et semelles.");
        return r;
    }

    // ------------------------------------------------------------------ escalier
    public static PreDesignValues Stair(StairDef d)
    {
        var r = new PreDesignValues { Title = $"Prédimensionnement de l'escalier {d.Name}" };
        double H = d.HeightM > 0.5 ? d.HeightM : 3.06;
        double target = Math.Clamp(d.TargetRiserCm, 15, 18) / 100.0;
        int n = Math.Max(2, (int)Math.Round(H / target));
        double rise = H / n;
        double g = Math.Clamp(0.64 - 2 * rise, 0.25, 0.32);             // Blondel : 2h + g ≈ 64 cm
        int flights = d.Layout switch { StairLayout.Droit or StairLayout.Helicoidal => 1, StairLayout.DoubleQuartPalier => 3, _ => 2 };
        int perFlight = (int)Math.Ceiling(n / (double)flights);
        double landing = flights > 1 ? Math.Max(d.MidLandingM, 1.0) : 0;
        double run = perFlight * g + landing * 0.5;
        double slope = Math.Atan2(rise, g);
        double thk = Math.Max(0.12, Math.Ceiling(run / 30.0 * 100 - 1e-9) / 100.0);   // paillasse e ≈ L/30
        double minW = d.Usage switch { StairUsage.Habitation => 0.90, StairUsage.Bureaux => 1.20, StairUsage.Public => 1.40, _ => 1.00 };
        double w = Math.Max(d.WidthM, minW);
        r.V["RiserCm"] = Math.Round(rise * 100, 1); r.V["TreadCm"] = Math.Round(g * 100, 1);
        r.V["SlabCm"] = Math.Round(thk * 100, 0); r.V["WidthM"] = w; r.V["Steps"] = n;
        r.Lines.Add($"Hauteur à franchir {H:0.00} m → {n} contremarches de {rise * 100:0.0} cm.");
        r.Lines.Add($"Giron (Blondel 2h + g ≈ 64 cm) : {g * 100:0.0} cm → 2h + g = {(2 * rise + g) * 100:0.0} cm ; pente {slope * 180 / Math.PI:0}°.");
        r.Lines.Add($"{flights} volée(s) de {perFlight} marches ; portée de calcul ≈ {run:0.00} m → paillasse e ≈ L/30 = {thk * 100:0} cm.");
        r.Lines.Add($"Emmarchement minimal ({d.Usage}) : {minW:0.00} m" + (w > d.WidthM + 1e-9 ? $" → porté de {d.WidthM:0.00} à {w:0.00} m." : " : respecté."));
        return r;
    }

    // ------------------------------------------------------------------ voile / dalle maillée
    /// <summary>Épaisseur proposée pour un groupe de coques (toutes les mailles de même nom).</summary>
    public static PreDesignValues Shell(StructModel m, string name)
    {
        var r = new PreDesignValues { Title = $"Prédimensionnement de {name}" };
        var group = m.Shells.Where(x => x.Name == name).ToList();
        var ids = group.SelectMany(x => new[] { x.N1, x.N2, x.N3, x.N4 }).Distinct().ToList();
        var pts = ids.Select(i => N(m, i)).Where(n => n != null).Select(n => n!).ToList();
        if (group.Count == 0 || pts.Count < 4) { r.V["Valid"] = 0; r.Lines.Add("Groupe de coques introuvable."); return r; }
        bool wall = group[0].Kind == "Voile";
        double dz = pts.Max(n => n.Z) - pts.Min(n => n.Z);
        double dx = pts.Max(n => n.X) - pts.Min(n => n.X), dy = pts.Max(n => n.Y) - pts.Min(n => n.Y);
        double t;
        if (wall)
        {
            double he = Math.Max(dz, 1.0);
            double e = Math.Max(0.15, he / 20.0);
            t = Math.Ceiling(e * 100 / 2.5 - 1e-9) * 2.5 / 100.0;           // multiple de 2,5 cm
            double hub = Math.Max(dx, dy);
            r.Lines.Add($"Voile {name} ({group.Count} mailles), hauteur libre he ≈ {he:0.00} m, longueur {hub:0.00} m.");
            r.Lines.Add($"RPA 99 art. 7.7.1 : e ≥ max(15 cm ; he/20 = {he / 20 * 100:0.0} cm) → {t * 100:0.0} cm.");
            if (hub < 4 * t) r.Lines.Add("Attention : longueur < 4·e, l'élément se comporte comme un poteau (non un voile).");
        }
        else
        {
            double lx = Math.Min(dx, dy), ly = Math.Max(dx, dy);
            bool one = lx / Math.Max(ly, 1e-6) < 0.4;
            double den = one ? 25.0 : 40.0;
            t = Math.Max(0.12, Math.Ceiling(lx / den * 100 - 1e-9) / 100.0);
            r.Lines.Add($"Dalle {name} ({group.Count} mailles), {lx:0.00} x {ly:0.00} m ({(one ? "un sens" : "deux sens")}).");
            r.Lines.Add($"h ≥ L/{den:0} = {lx / den * 100:0.0} cm (minimum 12 cm) → {t * 100:0} cm.");
        }
        r.V["Valid"] = 1; r.V["T"] = t;
        r.Lines.Add($"Épaisseur actuelle : {group[0].T * 100:0.0} cm. Le calcul (F5) vérifie ensuite contraintes, flèche et armatures.");
        return r;
    }
}
