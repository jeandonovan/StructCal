using System.Globalization;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public enum RevitChangeKind { Added, Updated, Removed }

/// <summary>Une différence entre le modèle StructCalc et un nouvel export Revit.</summary>
public sealed class RevitChange
{
    public RevitChangeKind Kind { get; init; }
    /// <summary>Famille : « Barre », « Dalle », « Voile », « Radier », « Escalier », « Semelle ».</summary>
    public string Family { get; init; } = "";
    public string ExternalId { get; init; } = "";
    public string Name { get; init; } = "";
    /// <summary>Ce qui a changé, en clair (ex. « section 30x50 -> 30x60 cm »).</summary>
    public string Detail { get; init; } = "";
    public override string ToString() => $"{Family} {Name} (Revit #{ExternalId}) : {Detail}";
}

public sealed class RevitSyncReport
{
    public List<RevitChange> Added { get; } = new();
    public List<RevitChange> Updated { get; } = new();
    /// <summary>Éléments liés à Revit qui n'existent plus dans le nouvel export. Jamais supprimés automatiquement.</summary>
    public List<RevitChange> Removed { get; } = new();
    public List<string> Warnings { get; } = new();
    public int Unchanged { get; set; }
    public bool HasChanges => Added.Count + Updated.Count + Removed.Count > 0;

    public string Summary()
    {
        var sb = new StringBuilder();
        sb.Append($"{Added.Count} ajouté(s), {Updated.Count} modifié(s), {Removed.Count} absent(s) de Revit, {Unchanged} inchangé(s).");
        return sb.ToString();
    }

    public string Details()
    {
        var sb = new StringBuilder(Summary());
        void Block(string title, List<RevitChange> l) { if (l.Count == 0) return; sb.AppendLine().AppendLine().Append(title).Append(" :"); foreach (var c in l.Take(40)) sb.AppendLine().Append("  • ").Append(c); if (l.Count > 40) sb.AppendLine().Append("  … et ").Append(l.Count - 40).Append(" autre(s)"); }
        Block("Ajoutés", Added); Block("Modifiés", Updated);
        Block("Absents du nouvel export (conservés dans StructCalc : à vérifier, supprimez-les vous-même si Revit les a vraiment supprimés)", Removed);
        if (Warnings.Count > 0) { sb.AppendLine().AppendLine().Append("Avertissements :"); foreach (var w in Warnings.Take(20)) sb.AppendLine().Append("  • ").Append(w); }
        return sb.ToString();
    }
}

/// <summary>Mise à jour d'un projet StructCalc à partir d'un nouvel export Revit, sans doublon : les éléments sont appariés par identifiant Revit (ExternalId).
/// Seules les données que Revit possède (géométrie, section, matériau, profil) sont mises à jour ; les charges, appuis, hypothèses et réglages saisis dans StructCalc sont conservés.
/// Un élément disparu de Revit n'est jamais supprimé automatiquement : il est signalé.</summary>
public static class RevitSync
{
    private const double TolM = 0.001;       // 1 mm

    /// <summary>Compare sans rien modifier.</summary>
    public static RevitSyncReport Diff(StructModel current, StructModel incoming)
    {
        var copy = ModelIO.FromJson(ModelIO.ToJson(current));
        return Merge(copy, incoming);
    }

    /// <summary>Fusionne l'export Revit dans le modèle courant (modifié sur place) et renvoie le compte rendu.</summary>
    public static RevitSyncReport Merge(StructModel cur, StructModel inc)
    {
        var rep = new RevitSyncReport();
        MergeMembers(cur, inc, rep);
        MergeSlabs(cur, inc, rep);
        MergeWalls(cur, inc, rep);
        MergeRafts(cur, inc, rep);
        MergeStairs(cur, inc, rep);
        MergeFootings(cur, inc, rep);
        return rep;
    }

    // ------------------------------------------------------------------ nœuds
    private static bool Same(double a, double b) => Math.Abs(a - b) <= TolM;
    private static bool Same(Node a, double x, double y, double z) => Same(a.X, x) && Same(a.Y, y) && Same(a.Z, z);

    private static int NodeAt(StructModel m, double x, double y, double z)
    {
        var n = m.Nodes.FirstOrDefault(q => Same(q, x, y, z));
        if (n != null) return n.Id;
        int id = m.Nodes.Count == 0 ? 1 : m.Nodes.Max(q => q.Id) + 1;
        m.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
        return id;
    }

    private static Node? Find(StructModel m, int id) => m.Nodes.FirstOrDefault(q => q.Id == id);

    private static string F(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);
    private static string Cm(double m) => (m * 100).ToString("0.#", CultureInfo.InvariantCulture);

    // ------------------------------------------------------------------ barres
    private static void MergeMembers(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var im in inc.Members.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(im.ExternalId);
            var ni = Find(inc, im.NodeI); var nj = Find(inc, im.NodeJ);
            if (ni == null || nj == null) { rep.Warnings.Add($"Barre Revit #{im.ExternalId} : nœud introuvable dans l'export, ignorée."); continue; }
            var cm = cur.Members.FirstOrDefault(x => x.ExternalId == im.ExternalId);
            if (cm == null)
            {
                int id = cur.Members.Count == 0 ? 1 : cur.Members.Max(q => q.Id) + 1;
                cur.Members.Add(new Member
                {
                    Id = id, NodeI = NodeAt(cur, ni.X, ni.Y, ni.Z), NodeJ = NodeAt(cur, nj.X, nj.Y, nj.Z), Type = im.Type, Kind = im.Kind, B = im.B, H = im.H,
                    Cover = im.Cover, CoverNomCm = im.CoverNomCm, Profile = im.Profile, Roll = im.Roll, ExternalId = im.ExternalId, LfFactor = im.LfFactor
                });
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Barre", ExternalId = im.ExternalId, Name = "B" + id, Detail = $"{(im.Type == MemberType.Column ? "poteau" : "poutre")} {Cm(im.B)}x{Cm(im.H)} cm" });
                continue;
            }
            var ci = Find(cur, cm.NodeI); var cj = Find(cur, cm.NodeJ);
            var what = new List<string>();
            if (ci == null || cj == null || !Same(ci, ni.X, ni.Y, ni.Z) || !Same(cj, nj.X, nj.Y, nj.Z)) what.Add("position / longueur");
            if (!Same(cm.B, im.B) || !Same(cm.H, im.H)) what.Add($"section {Cm(cm.B)}x{Cm(cm.H)} -> {Cm(im.B)}x{Cm(im.H)} cm");
            if (cm.Type != im.Type) what.Add("type " + (im.Type == MemberType.Column ? "poteau" : "poutre"));
            if (cm.Kind != im.Kind) what.Add("matériau");
            if (!string.Equals(cm.Profile, im.Profile, StringComparison.OrdinalIgnoreCase)) what.Add($"profil « {cm.Profile} » -> « {im.Profile} »");
            if (!Same(cm.Roll, im.Roll)) what.Add("rotation de section");
            if (what.Count == 0) { rep.Unchanged++; continue; }

            bool moved = what.Contains("position / longueur");
            if (moved)
            {
                cm.NodeI = NodeAt(cur, ni.X, ni.Y, ni.Z); cm.NodeJ = NodeAt(cur, nj.X, nj.Y, nj.Z);
                foreach (var oldId in new[] { ci?.Id ?? -1, cj?.Id ?? -1 })
                    if (oldId >= 0 && oldId != cm.NodeI && oldId != cm.NodeJ) HandleOrphan(cur, oldId, cm, rep);
            }
            cm.B = im.B; cm.H = im.H; cm.Type = im.Type; cm.Kind = im.Kind; cm.Profile = im.Profile; cm.Roll = im.Roll;
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Barre", ExternalId = cm.ExternalId, Name = "B" + cm.Id, Detail = string.Join(" ; ", what) });
        }
        foreach (var cm in cur.Members.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Barre", ExternalId = cm.ExternalId, Name = "B" + cm.Id, Detail = "n'existe plus dans l'export Revit" });

        // appuis venus de Revit : ajoutés seulement là où le modèle n'en a pas (ceux saisis dans StructCalc ne sont jamais écrasés)
        foreach (var s in inc.Supports)
        {
            var n = Find(inc, s.NodeId); if (n == null) continue;
            int nid = cur.Nodes.FirstOrDefault(q => Same(q, n.X, n.Y, n.Z))?.Id ?? -1;
            if (nid < 0 || cur.Supports.Any(q => q.NodeId == nid)) continue;
            if (!cur.Members.Any(q => q.NodeI == nid || q.NodeJ == nid)) continue;
            cur.Supports.Add(new SupportDef { NodeId = nid, Ux = s.Ux, Uy = s.Uy, Uz = s.Uz, Rx = s.Rx, Ry = s.Ry, Rz = s.Rz });
        }
    }

    private static void HandleOrphan(StructModel cur, int nodeId, Member by, RevitSyncReport rep)
    {
        if (cur.Members.Any(q => q.Id != by.Id && (q.NodeI == nodeId || q.NodeJ == nodeId))) return;           // encore utilisé
        bool support = cur.Supports.Any(q => q.NodeId == nodeId);
        bool loaded = cur.NodalLoads.Any(q => q.NodeId == nodeId);
        if (support || loaded)
        {
            rep.Warnings.Add($"Nœud {nodeId} : l'ancienne extrémité de la barre B{by.Id} porte {(support ? "un appui" : "")}{(support && loaded ? " et " : "")}{(loaded ? "une charge nodale" : "")} et n'est plus relié à rien. " +
                             "Déplacez ces données vers le nouveau nœud ou supprimez-les.");
            return;
        }
        foreach (var dead in cur.Nodes.Where(q => q.Id == nodeId).ToList()) cur.Nodes.Remove(dead);
    }

    // ------------------------------------------------------------------ dalles
    private static void MergeSlabs(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var s in inc.Slabs.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(s.ExternalId);
            var c = cur.Slabs.FirstOrDefault(x => x.ExternalId == s.ExternalId);
            if (c == null)
            {
                string name = Unique(cur.Slabs.Select(q => q.Name), "D");
                cur.Slabs.Add(new SlabPanel { Name = name, ExternalId = s.ExternalId, Placed = s.Placed, X0 = s.X0, Y0 = s.Y0, Lx = s.Lx, Ly = s.Ly, Z = s.Z, H = s.H, Kind = s.Kind });
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Dalle", ExternalId = s.ExternalId, Name = name, Detail = $"{F(s.Lx)} x {F(s.Ly)} m, h = {Cm(s.H)} cm" });
                continue;
            }
            var w = new List<string>();
            if (!Same(c.Lx, s.Lx) || !Same(c.Ly, s.Ly)) w.Add($"dimensions {F(c.Lx)}x{F(c.Ly)} -> {F(s.Lx)}x{F(s.Ly)} m");
            if (!Same(c.H, s.H)) w.Add($"épaisseur {Cm(c.H)} -> {Cm(s.H)} cm");
            if (!Same(c.X0, s.X0) || !Same(c.Y0, s.Y0) || !Same(c.Z, s.Z)) w.Add("position / cote");
            if (w.Count == 0) { rep.Unchanged++; continue; }
            c.Lx = s.Lx; c.Ly = s.Ly; c.H = s.H; c.X0 = s.X0; c.Y0 = s.Y0; c.Z = s.Z; c.Placed = s.Placed;
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Dalle", ExternalId = c.ExternalId, Name = c.Name, Detail = string.Join(" ; ", w) });
        }
        foreach (var c in cur.Slabs.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Dalle", ExternalId = c.ExternalId, Name = c.Name, Detail = "n'existe plus dans l'export Revit" });
    }

    // ------------------------------------------------------------------ voiles
    private static void MergeWalls(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var s in inc.Walls.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(s.ExternalId);
            var c = cur.Walls.FirstOrDefault(x => x.ExternalId == s.ExternalId);
            if (c == null)
            {
                string name = Unique(cur.Walls.Select(q => q.Name), "V");
                var n = new WallDef { Name = name, ExternalId = s.ExternalId };
                CopyWall(s, n);
                n.Openings = s.Openings.Select(o => o.Clone()).ToList();
                cur.Walls.Add(n);
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Voile", ExternalId = s.ExternalId, Name = name, Detail = $"{F(s.LengthM)} x {F(s.HeightM)} m, e = {Cm(s.ThicknessM)} cm" });
                continue;
            }
            var w = new List<string>();
            if (!Same(c.LengthM, s.LengthM) || !Same(c.HeightM, s.HeightM)) w.Add($"dimensions {F(c.LengthM)}x{F(c.HeightM)} -> {F(s.LengthM)}x{F(s.HeightM)} m");
            if (!Same(c.ThicknessM, s.ThicknessM)) w.Add($"épaisseur {Cm(c.ThicknessM)} -> {Cm(s.ThicknessM)} cm");
            if (!Same(c.X, s.X) || !Same(c.Y, s.Y) || !Same(c.Z, s.Z) || Math.Abs(c.AngleDeg - s.AngleDeg) > 0.01) w.Add("position / orientation");
            if (!SameOpenings(c.Openings, s.Openings)) w.Add($"ouvertures ({c.Openings.Count} -> {s.Openings.Count})");
            if (w.Count == 0) { rep.Unchanged++; continue; }
            CopyWall(s, c);
            c.Openings = s.Openings.Select(o => o.Clone()).ToList();
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Voile", ExternalId = c.ExternalId, Name = c.Name, Detail = string.Join(" ; ", w) });
        }
        foreach (var c in cur.Walls.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Voile", ExternalId = c.ExternalId, Name = c.Name, Detail = "n'existe plus dans l'export Revit" });
    }

    private static void CopyWall(WallDef from, WallDef to) { to.X = from.X; to.Y = from.Y; to.Z = from.Z; to.AngleDeg = from.AngleDeg; to.LengthM = from.LengthM; to.HeightM = from.HeightM; to.ThicknessM = from.ThicknessM; }

    private static bool SameOpenings(List<WallOpening> a, List<WallOpening> b)
    {
        if (a.Count != b.Count) return false;
        for (int i = 0; i < a.Count; i++)
            if (!Same(a[i].XM, b[i].XM) || !Same(a[i].ZM, b[i].ZM) || !Same(a[i].WidthM, b[i].WidthM) || !Same(a[i].HeightM, b[i].HeightM)) return false;
        return true;
    }

    // ------------------------------------------------------------------ radiers
    private static void MergeRafts(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var s in inc.Rafts.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(s.ExternalId);
            var c = cur.Rafts.FirstOrDefault(x => x.ExternalId == s.ExternalId);
            if (c == null)
            {
                string name = Unique(cur.Rafts.Select(q => q.Name), "R");
                var n = s.Clone(); n.Name = name; cur.Rafts.Add(n);
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Radier", ExternalId = s.ExternalId, Name = name, Detail = $"{s.Area:0.0} m², e = {Cm(s.H)} cm" });
                continue;
            }
            var w = new List<string>();
            if (!Same(c.H, s.H)) w.Add($"épaisseur {Cm(c.H)} -> {Cm(s.H)} cm");
            if (!Same(c.ZTop, s.ZTop)) w.Add("cote du dessus");
            if (!SamePanels(c.Panels, s.Panels)) w.Add($"contour ({c.Area:0.0} -> {s.Area:0.0} m²)");
            if (w.Count == 0) { rep.Unchanged++; continue; }
            c.H = s.H; c.ZTop = s.ZTop; c.Panels = s.Panels.Select(p => new RaftPanel { X0 = p.X0, Y0 = p.Y0, Lx = p.Lx, Ly = p.Ly }).ToList();
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Radier", ExternalId = c.ExternalId, Name = c.Name, Detail = string.Join(" ; ", w) });
        }
        foreach (var c in cur.Rafts.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Radier", ExternalId = c.ExternalId, Name = c.Name, Detail = "n'existe plus dans l'export Revit" });
    }

    private static bool SamePanels(List<RaftPanel> a, List<RaftPanel> b)
    {
        if (a.Count != b.Count) return false;
        for (int i = 0; i < a.Count; i++)
            if (!Same(a[i].X0, b[i].X0) || !Same(a[i].Y0, b[i].Y0) || !Same(a[i].Lx, b[i].Lx) || !Same(a[i].Ly, b[i].Ly)) return false;
        return true;
    }

    // ------------------------------------------------------------------ escaliers
    private static void MergeStairs(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var s in inc.Stairs.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(s.ExternalId);
            var c = cur.Stairs.FirstOrDefault(x => x.ExternalId == s.ExternalId);
            if (c == null)
            {
                string name = Unique(cur.Stairs.Select(q => q.Name), "E");
                var n = new StairDef { Name = name, ExternalId = s.ExternalId };
                CopyStair(s, n); cur.Stairs.Add(n);
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Escalier", ExternalId = s.ExternalId, Name = name, Detail = $"hauteur {F(s.HeightM)} m, emmarchement {F(s.WidthM)} m" });
                continue;
            }
            var w = new List<string>();
            if (!Same(c.HeightM, s.HeightM)) w.Add($"hauteur {F(c.HeightM)} -> {F(s.HeightM)} m");
            if (!Same(c.WidthM, s.WidthM)) w.Add($"emmarchement {F(c.WidthM)} -> {F(s.WidthM)} m");
            if (c.Layout != s.Layout) w.Add("disposition");
            if (!Same(c.Z, s.Z) || !Same(c.X, s.X) || !Same(c.Y, s.Y) || Math.Abs(c.AngleDeg - s.AngleDeg) > 0.01) w.Add("position / cote de départ");
            if (Math.Abs(c.TargetRiserCm - s.TargetRiserCm) > 0.05 || Math.Abs(c.TargetTreadCm - s.TargetTreadCm) > 0.05) w.Add($"marches {c.TargetRiserCm:0.#}/{c.TargetTreadCm:0.#} -> {s.TargetRiserCm:0.#}/{s.TargetTreadCm:0.#} cm");
            if (w.Count == 0) { rep.Unchanged++; continue; }
            CopyStair(s, c);
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Escalier", ExternalId = c.ExternalId, Name = c.Name, Detail = string.Join(" ; ", w) });
        }
        foreach (var c in cur.Stairs.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Escalier", ExternalId = c.ExternalId, Name = c.Name, Detail = "n'existe plus dans l'export Revit" });
    }

    private static void CopyStair(StairDef f, StairDef t)
    {
        t.Layout = f.Layout; t.HeightM = f.HeightM; t.WidthM = f.WidthM; t.TargetRiserCm = f.TargetRiserCm; t.TargetTreadCm = f.TargetTreadCm;
        t.Z = f.Z; t.X = f.X; t.Y = f.Y; t.AngleDeg = f.AngleDeg; t.Placed = f.Placed; t.InnerRadiusM = f.InnerRadiusM; t.TurnAngleDeg = f.TurnAngleDeg; t.Mirror = f.Mirror;
    }

    // ------------------------------------------------------------------ semelles
    private static void MergeFootings(StructModel cur, StructModel inc, RevitSyncReport rep)
    {
        var seen = new HashSet<string>();
        foreach (var s in inc.FootingDefs.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
        {
            seen.Add(s.ExternalId);
            var c = cur.FootingDefs.FirstOrDefault(x => x.ExternalId == s.ExternalId);
            if (c == null)
            {
                string name = Unique(cur.FootingDefs.Select(q => q.Name), "SR");
                var n = (FootingDef)s.Clone(); n.Name = name; cur.FootingDefs.Add(n);
                rep.Added.Add(new RevitChange { Kind = RevitChangeKind.Added, Family = "Semelle", ExternalId = s.ExternalId, Name = name, Detail = $"{F(s.FixedA)} x {F(s.FixedB)} m" });
                continue;
            }
            if (Same(c.FixedA, s.FixedA) && Same(c.FixedB, s.FixedB)) { rep.Unchanged++; continue; }
            string d = $"dimensions {F(c.FixedA)}x{F(c.FixedB)} -> {F(s.FixedA)}x{F(s.FixedB)} m";
            c.FixedA = s.FixedA; c.FixedB = s.FixedB;
            rep.Updated.Add(new RevitChange { Kind = RevitChangeKind.Updated, Family = "Semelle", ExternalId = c.ExternalId, Name = c.Name, Detail = d });
        }
        foreach (var c in cur.FootingDefs.Where(x => !string.IsNullOrEmpty(x.ExternalId) && !seen.Contains(x.ExternalId)))
            rep.Removed.Add(new RevitChange { Kind = RevitChangeKind.Removed, Family = "Semelle", ExternalId = c.ExternalId, Name = c.Name, Detail = "n'existe plus dans l'export Revit" });
    }

    private static string Unique(IEnumerable<string> names, string prefix)
    {
        var set = new HashSet<string>(names);
        int k = 1; while (set.Contains(prefix + k)) k++;
        return prefix + k;
    }
}
