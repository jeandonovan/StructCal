using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed record VariantResult(string Name, double Fc28, double Fe, double SectionFactor, bool Ok, int Failing,
                                   double ConcreteM3, double SteelKg, double FormworkM2, double Cost, string Currency, string Error = "");

/// <summary>Compare plusieurs variantes du même projet : résistance du béton, nuance d'acier, taille des sections de départ.
/// Chaque variante est calculée sur une copie du modèle (le projet n'est pas modifié).</summary>
public static class VariantComparer
{
    public static List<VariantResult> Run(StructModel baseModel, IEnumerable<double> fc28s, IEnumerable<double> fes, IEnumerable<double> factors,
                                          bool optimize = true, Action<string>? progress = null)
    {
        string json = ModelIO.ToJson(baseModel);
        var res = new List<VariantResult>();
        foreach (double fc in fc28s)
            foreach (double fe in fes)
                foreach (double k in factors)
                {
                    string name = $"fc28 {fc:0.#} / fe {fe:0} / sections x{k:0.##}";
                    progress?.Invoke(name);
                    try
                    {
                        var m = ModelIO.FromJson(json);
                        m.Fc28 = fc; m.Fe = fe;
                        foreach (var mem in m.Members.Where(x => x.Kind == MaterialKind.ReinforcedConcrete))
                        {
                            mem.B = Math.Round(mem.B * k / 0.025) * 0.025;
                            mem.H = Math.Round(mem.H * k / 0.025) * 0.025;
                            if (mem.B < 0.15) mem.B = 0.15;
                            if (mem.H < 0.15) mem.H = 0.15;
                        }
                        var o = ProjectAnalyzer.Run(m, optimize);
                        var q = Quantities.Compute(m, o);
                        double cost = 0; string cur = "";
                        try { var c = CostEstimator.Compute(q, m.Prices); cost = c.Total; cur = c.Currency; } catch { }
                        int bad = o.Members.Count(r => !r.Ok && !r.Skipped);
                        res.Add(new VariantResult(name, fc, fe, k, o.AllOk, bad, q.ConcreteM3, q.RebarKg + q.StirrupKg + q.ProfileKg, q.FormworkM2, cost, cur));
                    }
                    catch (Exception ex)
                    {
                        res.Add(new VariantResult(name, fc, fe, k, false, 0, 0, 0, 0, 0, "", ex.Message));
                    }
                }
        return res;
    }
}
