using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Modèle de départ proposé dans l'écran d'accueil.</summary>
public sealed record ProjectTemplate(string Name, string Description, string System, Func<StructModel> Make);

/// <summary>Catalogue des modèles de projet (ossatures types générées par <see cref="FrameGenerator"/>).</summary>
public static class ProjectTemplates
{
    private static StructModel Frame(FrameSpec spec, string name) { var m = FrameGenerator.Generate(spec); m.Name = name; return m; }

    public static IReadOnlyList<ProjectTemplate> All { get; } = new List<ProjectTemplate>
    {
        new("Projet vierge", "Repartir de zéro.", "Béton armé", () => new StructModel()),
        new("Villa R+1", "3 travées de 4,50 m, 2 niveaux de 3,00 m, portique plan.", "Béton armé",
            () => Frame(new FrameSpec { BaysX = 3, Storeys = 2, SpanX = 4.5, StoreyHeight = 3.0, ColB = 0.25, ColH = 0.25, BeamB = 0.25, BeamH = 0.40, G = 16, Q = 4 }, "Villa R+1")),
        new("Immeuble R+4", "3 travées de 5,00 m, 5 niveaux de 3,06 m, poteaux 30x30.", "Béton armé",
            () => Frame(new FrameSpec { BaysX = 3, Storeys = 5, SpanX = 5.0, StoreyHeight = 3.06, ColB = 0.30, ColH = 0.30, BeamB = 0.25, BeamH = 0.45, G = 20, Q = 6 }, "Immeuble R+4")),
        new("Bâtiment 3D R+2", "3 x 3 travées de 5,00 m, 3 niveaux : ossature spatiale.", "Béton armé",
            () => Frame(new FrameSpec { BaysX = 3, BaysY = 3, Storeys = 3, SpanX = 5.0, SpanY = 5.0, StoreyHeight = 3.06, ColB = 0.30, ColH = 0.30, BeamB = 0.25, BeamH = 0.45, G = 18, Q = 5 }, "Bâtiment 3D R+2")),
        new("Hangar acier", "2 travées de 10 m, hauteur 6 m, HEA 300 / IPE 400.", "Acier",
            () => Frame(new FrameSpec { BaysX = 2, Storeys = 1, SpanX = 10, StoreyHeight = 6, Steel = true, ColProfile = "HEA300", BeamProfile = "IPE400", G = 6, Q = 4 }, "Hangar acier")),
        new("Projet pilote R+1", "Bâtiment R+1 complet : ossature 3D, dalles, semelles, escalier, voile. Scénario de bout en bout.", "Béton armé", () => ExampleModels.Pilot()),
        new("Portique béton (exemple)", "Exemple du logiciel : portique 2 travées / 2 niveaux.", "Béton armé", () => ExampleModels.Portal()),
    };
}
