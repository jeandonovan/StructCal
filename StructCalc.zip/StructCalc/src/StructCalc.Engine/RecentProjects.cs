using System.Text.Json;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Un projet récent : de quoi l'afficher dans l'écran d'accueil sans rouvrir le fichier.</summary>
public sealed class RecentEntry
{
    public string Path { get; set; } = "";
    public string Name { get; set; } = "";
    /// <summary>« Béton armé », « Acier », « Mixte » ou « Projet vide ».</summary>
    public string SystemType { get; set; } = "";
    /// <summary>Type de projet choisi à la création (Bâtiment, Fondations...), vide si inconnu.</summary>
    public string ProjectType { get; set; } = "";
    public int Elements { get; set; }
    public DateTime LastOpened { get; set; } = DateTime.Now;
    /// <summary>Miniature : largeur, hauteur puis x1, y1, x2, y2 de chaque barre (coordonnées 0..1, y vers le bas). Vide si non disponible.</summary>
    public double[] Thumb { get; set; } = Array.Empty<double>();

    /// <summary>Date de dernière modification du fichier (lue sur le disque, non enregistrée).</summary>
    [System.Text.Json.Serialization.JsonIgnore] public DateTime LastModified => File.Exists(Path) ? File.GetLastWriteTime(Path) : DateTime.MinValue;
}

/// <summary>Liste des projets récents (JSON dans le dossier de données) et opérations sur les fichiers listés : dupliquer, renommer, supprimer.</summary>
public sealed class RecentProjects
{
    public const int MaxEntries = 20;
    private readonly string _file, _legacy;
    private static readonly JsonSerializerOptions Opt = new() { WriteIndented = true };

    /// <param name="jsonFile">Fichier de la liste (recent.json).</param>
    /// <param name="legacyTextFile">Ancienne liste (recent.txt, un chemin par ligne), lue une fois si la nouvelle n'existe pas encore ; "" = aucune.</param>
    public RecentProjects(string jsonFile, string legacyTextFile = "") { _file = jsonFile; _legacy = legacyTextFile; }

    // ------------------------------------------------------------------ lecture / écriture
    private List<RecentEntry> Read()
    {
        try
        {
            if (File.Exists(_file)) return JsonSerializer.Deserialize<List<RecentEntry>>(File.ReadAllText(_file)) ?? new List<RecentEntry>();
            if (_legacy != "" && File.Exists(_legacy))
                return File.ReadAllLines(_legacy).Where(l => l.Trim() != "" && File.Exists(l.Trim()))
                           .Select((l, i) => { var e = Describe(l.Trim()); e.LastOpened = File.GetLastWriteTime(l.Trim()).AddSeconds(-i); return e; }).ToList();
        }
        catch { }
        return new List<RecentEntry>();
    }

    private void Write(List<RecentEntry> l)
    {
        try
        {
            string? dir = System.IO.Path.GetDirectoryName(_file);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(_file, JsonSerializer.Serialize(l.Take(MaxEntries).ToList(), Opt));
        }
        catch { }
    }

    private static bool Same(string a, string b) => string.Equals(System.IO.Path.GetFullPath(a), System.IO.Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);

    /// <summary>Projets récents dont le fichier existe encore, du plus récent au plus ancien.</summary>
    public List<RecentEntry> Load() => Read().Where(e => e.Path != "" && File.Exists(e.Path)).OrderByDescending(e => e.LastOpened).Take(MaxEntries).ToList();

    /// <summary>Ajoute (ou remonte en tête) un projet. Si le modèle est fourni, la description vient de lui, sinon du fichier.</summary>
    public RecentEntry Add(string path, StructModel? model = null)
    {
        var l = Read();
        l.RemoveAll(e => e.Path != "" && Same(e.Path, path));
        var entry = model != null ? Describe(path, model) : Describe(path);
        entry.LastOpened = DateTime.Now;
        l.Insert(0, entry);
        Write(l);
        return entry;
    }

    /// <summary>Retire un projet de la liste (le fichier n'est pas touché).</summary>
    public void Remove(string path)
    {
        var l = Read();
        l.RemoveAll(e => e.Path != "" && Same(e.Path, path));
        Write(l);
    }

    // ------------------------------------------------------------------ opérations sur les fichiers
    private static string Sanitize(string name)
    {
        foreach (char c in System.IO.Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
        return name.Trim().TrimEnd('.');
    }

    /// <summary>Premier nom libre « base - copie », « base - copie 2 »... dans le même dossier.</summary>
    public static string FreeCopyPath(string path)
    {
        string dir = System.IO.Path.GetDirectoryName(path) ?? "", baseName = System.IO.Path.GetFileNameWithoutExtension(path), ext = System.IO.Path.GetExtension(path);
        string cand = System.IO.Path.Combine(dir, baseName + " - copie" + ext);
        for (int i = 2; File.Exists(cand); i++) cand = System.IO.Path.Combine(dir, $"{baseName} - copie {i}{ext}");
        return cand;
    }

    /// <summary>Copie le fichier à côté de l'original, et la met dans la liste. Retourne le nouveau chemin.</summary>
    public string Duplicate(string path)
    {
        string dst = FreeCopyPath(path);
        File.Copy(path, dst, false);
        Add(dst);
        return dst;
    }

    /// <summary>Renomme le fichier (même dossier, même extension) et met la liste à jour. Retourne le nouveau chemin ; lève une exception si le nom existe déjà ou est vide.</summary>
    public string RenameFile(string path, string newName)
    {
        string clean = Sanitize(newName);
        if (clean == "") throw new InvalidOperationException("Le nom est vide.");
        string dst = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(path) ?? "", clean + System.IO.Path.GetExtension(path));
        if (!Same(path, dst))
        {
            if (File.Exists(dst)) throw new InvalidOperationException("Un fichier porte déjà ce nom.");
            File.Move(path, dst);
        }
        var l = Read();
        foreach (var e in l.Where(e => e.Path != "" && Same(e.Path, path))) { e.Path = dst; e.Name = clean; }
        Write(l);
        return dst;
    }

    /// <summary>Supprime le fichier du disque et le retire de la liste.</summary>
    public void DeleteFile(string path)
    {
        if (File.Exists(path)) File.Delete(path);
        Remove(path);
    }

    // ------------------------------------------------------------------ description
    /// <summary>Description d'un fichier de projet (ouvre le fichier). En cas d'illisibilité : nom du fichier seul.</summary>
    public static RecentEntry Describe(string path)
    {
        try { return Describe(path, ModelIO.Load(path)); }
        catch { return new RecentEntry { Path = path, Name = System.IO.Path.GetFileNameWithoutExtension(path), SystemType = "", Elements = 0 }; }
    }

    public static RecentEntry Describe(string path, StructModel m)
    {
        return new RecentEntry
        {
            Path = path,
            Name = string.IsNullOrWhiteSpace(m.Name) ? System.IO.Path.GetFileNameWithoutExtension(path) : m.Name,
            SystemType = SystemOf(m),
            ProjectType = m.Info?.ProjectType ?? "",
            Elements = m.Members.Count + m.Slabs.Count,
            Thumb = Thumbnail(m)
        };
    }

    public static string SystemOf(StructModel m)
    {
        bool steel = m.Members.Any(x => x.Kind == MaterialKind.Steel), rc = m.Members.Any(x => x.Kind == MaterialKind.ReinforcedConcrete) || m.Slabs.Count > 0;
        return steel && rc ? "Mixte" : steel ? "Acier" : rc ? "Béton armé" : "Projet vide";
    }

    /// <summary>Miniature filaire : [largeur, hauteur, x1, y1, x2, y2, ...] en coordonnées 0..1 (y vers le bas), au plus 80 barres ; vide si aucune barre.</summary>
    public static double[] Thumbnail(StructModel m, int maxMembers = 80)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var segs = m.Members.Where(x => nodes.ContainsKey(x.NodeI) && nodes.ContainsKey(x.NodeJ)).Take(maxMembers)
                            .Select(x => (A: nodes[x.NodeI], B: nodes[x.NodeJ])).ToList();
        if (segs.Count == 0) return Array.Empty<double>();
        var all = segs.SelectMany(s => new[] { s.A, s.B }).ToList();
        double rx = all.Max(n => n.X) - all.Min(n => n.X), ry = all.Max(n => n.Y) - all.Min(n => n.Y), rz = all.Max(n => n.Z) - all.Min(n => n.Z);
        // plan vertical X-Z (ou Y-Z) ; à défaut, plan horizontal X-Y
        Func<Node, double> h, v; double rh, rv; bool flipV;
        if (rz < 1e-6) { h = n => n.X; v = n => n.Y; rh = rx; rv = ry; flipV = true; }
        else if (rx >= ry) { h = n => n.X; v = n => n.Z; rh = rx; rv = rz; flipV = true; }
        else { h = n => n.Y; v = n => n.Z; rh = ry; rv = rz; flipV = true; }
        double scale = Math.Max(Math.Max(rh, rv), 1e-6);
        double h0 = all.Min(h), vMin = all.Min(v), vMax = all.Max(v);
        var res = new List<double> { Math.Round(rh / scale, 3), Math.Round(rv / scale, 3) };
        foreach (var (a, b) in segs)
        {
            double Y(Node n) => flipV ? (vMax - v(n)) / scale : (v(n) - vMin) / scale;
            res.Add(Math.Round((h(a) - h0) / scale, 3)); res.Add(Math.Round(Y(a), 3));
            res.Add(Math.Round((h(b) - h0) / scale, 3)); res.Add(Math.Round(Y(b), 3));
        }
        return res.ToArray();
    }
}
