using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Longueurs de flambement des poteaux d'ossature : méthode de l'Annexe E de l'EC3 (cours ISA, §8.2.2) :
/// eta = (Kc + K1)/(Kc + K1 + K11 + K12), lk/l0 = (1+0,145(e1+e2)-0,265 e1 e2)/(2-0,364(e1+e2)-0,247 e1 e2) (noeuds fixes) ou
/// sqrt((1-0,2(e1+e2)-0,12 e1 e2)/(1-0,8(e1+e2)+0,6 e1 e2)) (noeuds déplaçables).
/// Rigidités effectives des poutres, par sécurité : 0,5 I/L (noeuds fixes, simple courbure) et 1,0 I/L (noeuds déplaçables, extrémité opposée encastrée).
/// Pied encastré : eta = 0,1 ; pied articulé : eta = 1,0. Hypothèse : plans de flambement orthogonaux (ossature orthogonale).</summary>
public static class EffectiveLengths
{
    private static double[] Axes(Node a, Node b, out double L)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y, dz = b.Z - a.Z;
        L = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        return new[] { dx / L, dy / L, dz / L };
    }

    /// <summary>Rapport lk/l0 pour le flambement autour de l'axe local y (plan xz) ou z (plan xy) du poteau.</summary>
    public static double Ratio(StructModel m, Member col, bool aboutY, bool sway)
    {
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var (L, R) = FrameSolver.LocalAxes(nodes[col.NodeI], nodes[col.NodeJ], col.Roll);
        double[] dirPlane = aboutY ? new[] { R[2, 0], R[2, 1], R[2, 2] } : new[] { R[1, 0], R[1, 1], R[1, 2] };
        if (m.BracedOutOfPlane && !HasBeam(m, nodes, col, col.NodeI, dirPlane) && !HasBeam(m, nodes, col, col.NodeJ, dirPlane))
            return 1.0;       // plan sans poutre : poteau supposé maintenu (contreventement hors plan)
        double Ic = Inertia(col, aboutY);
        double Kc = Ic / L;
        double e1 = Eta(m, nodes, col, col.NodeI, Kc, dirPlane, aboutY, sway);
        double e2 = Eta(m, nodes, col, col.NodeJ, Kc, dirPlane, aboutY, sway);
        double ratio;
        if (!sway)
            ratio = (1 + 0.145 * (e1 + e2) - 0.265 * e1 * e2) / (2 - 0.364 * (e1 + e2) - 0.247 * e1 * e2);
        else
        {
            double den = 1 - 0.8 * (e1 + e2) + 0.6 * e1 * e2;
            ratio = den <= 0.01 ? 10.0 : Math.Sqrt(Math.Max((1 - 0.2 * (e1 + e2) - 0.12 * e1 * e2) / den, 1.0));
        }
        return Math.Min(Math.Max(ratio, 0.5), 10.0);
    }

    private static bool HasBeam(StructModel m, Dictionary<int, Node> nodes, Member col, int nodeId, double[] dirPlane)
    {
        foreach (var o in m.Members.Where(x => x.Id != col.Id && (x.NodeI == nodeId || x.NodeJ == nodeId)))
        {
            var d = Axes(nodes[o.NodeI], nodes[o.NodeJ], out _);
            if (Math.Abs(d[2]) >= 0.5) continue;
            if (Math.Abs(d[0] * dirPlane[0] + d[1] * dirPlane[1] + d[2] * dirPlane[2]) >= 0.7) return true;
        }
        return false;
    }

    private static double Inertia(Member mem, bool aboutY)
    {
        if (mem.Kind == MaterialKind.Steel && StructCalc.Core.Steel.SteelCatalog.TryGet(mem.Profile, out var p))
            return aboutY ? p.Iy : p.Iz;
        return aboutY ? mem.B * Math.Pow(mem.H, 3) / 12.0 : mem.H * Math.Pow(mem.B, 3) / 12.0;
    }

    private static double Eta(StructModel m, Dictionary<int, Node> nodes, Member col, int nodeId, double Kc,
                              double[] dirPlane, bool aboutY, bool sway)
    {
        var sup = m.Supports.FirstOrDefault(s => s.NodeId == nodeId);
        if (sup != null) return (sup.Rx && sup.Ry && sup.Rz) ? 0.1 : 1.0;
        double k1 = 0, kb = 0;
        foreach (var o in m.Members.Where(x => x.Id != col.Id && (x.NodeI == nodeId || x.NodeJ == nodeId)))
        {
            var d = Axes(nodes[o.NodeI], nodes[o.NodeJ], out double Lo);
            bool horizontal = Math.Abs(d[2]) < 0.5;
            if (!horizontal) { k1 += Inertia(o, aboutY) / Lo; continue; }
            double proj = Math.Abs(d[0] * dirPlane[0] + d[1] * dirPlane[1] + d[2] * dirPlane[2]);
            if (proj < 0.7) continue;
            double Ib = o.Kind == MaterialKind.Steel && StructCalc.Core.Steel.SteelCatalog.TryGet(o.Profile, out var pb)
                ? pb.Iy : o.B * Math.Pow(o.H, 3) / 12.0;       // flexion verticale de la poutre
            kb += (sway ? 1.0 : 0.5) * Ib / Lo;
        }
        if (kb <= 0) return 1.0;
        return (Kc + k1) / (Kc + k1 + kb);
    }
}
