using System.Text;
using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine.Results;

namespace StructCalc.Engine;

/// <summary>Un échelon d'une solution de dimensionnement : texte de la modification et action qui l'applique à un modèle (le vrai, ou une copie d'essai).</summary>
public sealed class FixStep
{
    public string Text { get; set; } = "";
    public Action<StructModel> Apply { get; set; } = _ => { };
}

/// <summary>Lecture, dans un résultat de calcul, de l'élément visé : trouvé ? conforme ? taux de travail.</summary>
public readonly record struct FixReading(bool Found, bool Ok, double Util);

/// <summary>L'élément en alerte : son état actuel et la façon de relire son état dans un nouveau calcul.</summary>
public sealed class FixTarget
{
    public string Title { get; set; } = "";
    public bool HasUtil { get; set; }
    public double Before { get; set; }
    public bool BeforeOk { get; set; }
    /// <summary>Valeurs calculées actuelles (texte multi-lignes) : efforts, taux, causes de la non-conformité.</summary>
    public string Detail { get; set; } = "";
    public Func<AnalysisOutput, FixReading> Read { get; set; } = _ => new FixReading(false, false, 0);
    /// <summary>Description de la section obtenue sur une copie d'essai (« 30x40 → 30x45 cm »), pour les solutions dont le résultat n'est pas connu d'avance.</summary>
    public Func<StructModel, string>? Section { get; set; }
}

/// <summary>Une solution proposée : une suite d'échelons essayés dans l'ordre, chacun par un vrai recalcul sur une copie du modèle, jusqu'au premier qui vérifie l'élément.</summary>
public sealed class FixOption
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Scope { get; set; } = "";
    public string Note { get; set; } = "";
    /// <summary>Afficher la section obtenue plutôt que le texte de l'échelon (optimisation).</summary>
    public bool ShowSection { get; set; }
    public List<FixStep> Steps { get; } = new();

    // ---- renseigné par DesignFixes.Evaluate
    public bool Computed { get; set; }
    public int Chosen { get; set; } = -1;
    public bool Reached { get; set; }
    public double After { get; set; }
    public int NonOkAfter { get; set; }
    public string Final { get; set; } = "";
    public string Result { get; set; } = "";

    public FixStep? Step => Chosen >= 0 && Chosen < Steps.Count ? Steps[Chosen] : null;
    public string Change => ShowSection && Final != "" ? Final : (Step?.Text ?? "");
}

/// <summary>Solutions de dimensionnement des alertes « NON OK » (barres, dalles, poinçonnement) : on ne modifie jamais le modèle ici,
/// on calcule seulement ce qui se passerait (taux avant / après) ; l'application revient à l'utilisateur.</summary>
public static class DesignFixes
{
    private static readonly Dictionary<int, string> ConcreteNames = new()
    {
        { 20, "C20/25" }, { 25, "C25/30" }, { 30, "C30/37" }, { 35, "C35/45" }, { 40, "C40/50" }, { 45, "C45/55" }, { 50, "C50/60" }
    };

    /// <summary>Nombre d'éléments non conformes dans un calcul (barres, dalles, semelles, modules, poinçonnement).</summary>
    public static int NonOkCount(AnalysisOutput o) =>
        o.Members.Count(r => !r.Ok && !r.Skipped) + o.Slabs.Count(s => !s.Ok) + o.Footings.Count(f => !f.Ok)
        + o.Extras.Count(x => !x.Ok) + o.Punching.Count(p => !p.Ok);

    private static string Cm(double m) => (m * 100).ToString("0.#");
    private static Member MemOf(StructModel model, int id) => model.Members.First(x => x.Id == id);
    private static string SectionText(Member mem) => mem.Kind == MaterialKind.Steel ? mem.Profile : $"{Cm(mem.B)}x{Cm(mem.H)} cm";

    private static FixOption Opt(string id, string label, string scope, string note = "") =>
        new() { Id = id, Label = label, Scope = scope, Note = note };

    // ====================================================================== évaluation (recalcul réel sur une copie)
    /// <summary>Essaie les échelons dans l'ordre sur une copie du modèle (JSON pris avant, sur le fil de l'interface) ; garde le premier qui vérifie l'élément,
    /// sinon le dernier essayé. Le modèle de l'utilisateur n'est jamais touché.</summary>
    public static void Evaluate(string modelJson, FixOption f, FixTarget t, int nonOkBefore, CancellationToken ct)
    {
        f.Computed = false; f.Chosen = -1; f.Reached = false; f.Result = ""; f.Final = "";
        string lastError = "";
        for (int i = 0; i < f.Steps.Count; i++)
        {
            ct.ThrowIfCancellationRequested();
            StructModel copy;
            try { copy = ModelIO.FromJson(modelJson); f.Steps[i].Apply(copy); }
            catch (Exception ex) { lastError = "Non applicable : " + ex.Message; continue; }
            AnalysisOutput res;
            try { res = ProjectAnalyzer.Run(copy, false, 1); }
            catch (Exception ex) { lastError = "Calcul impossible avec cette modification : " + ex.Message; continue; }
            var rd = t.Read(res);
            f.Chosen = i;
            f.After = rd.Util;
            f.NonOkAfter = NonOkCount(res);
            f.Final = t.Section?.Invoke(copy) ?? "";
            f.Reached = rd.Found && rd.Ok;
            if (f.Reached) break;
        }
        f.Computed = true;
        if (f.Chosen < 0) { f.Result = lastError != "" ? lastError : "Aucune modification possible."; return; }
        string util = t.HasUtil ? $"taux {f.After * 100:0} %" : "conforme";
        string net = $"Alertes dans le projet : {nonOkBefore} → {f.NonOkAfter}.";
        f.Result = f.Reached ? $"Vérifié ({util}). " + net : $"Encore NON OK avec le plus grand échelon essayé ({util}). " + net;
    }

    /// <summary>Même chose, avec le nombre d'alertes d'avant (fixé une fois par série d'évaluations).</summary>
    public static void EvaluateAll(string modelJson, IEnumerable<FixOption> options, FixTarget t, int nonOkBefore, CancellationToken ct, Action<FixOption>? progress = null)
    {
        foreach (var o in options)
        {
            ct.ThrowIfCancellationRequested();
            Evaluate(modelJson, o, t, nonOkBefore, ct);
            progress?.Invoke(o);
        }
    }

    // ====================================================================== solutions communes
    private static FixOption? ConcreteOption(StructModel m)
    {
        var o = Opt("FC", "Augmenter la classe de béton", "Toute la structure", "La classe s'applique à tout le projet (poutres, poteaux, dalles, semelles, voiles).");
        foreach (double v in new[] { 20.0, 25, 30, 35, 40, 45, 50 }.Where(x => x > m.Fc28 + 0.1).Take(3))
        {
            double vv = v;
            string name = ConcreteNames.TryGetValue((int)v, out var nm) ? " (" + nm + ")" : "";
            o.Steps.Add(new FixStep { Text = $"fc28 : {m.Fc28:0.#} → {vv:0.#} MPa{name}", Apply = mdl => mdl.Fc28 = vv });
        }
        return o.Steps.Count > 0 ? o : null;
    }

    private static FixOption? SteelGradeOption(StructModel m)
    {
        if (m.Fe >= 500) return null;
        var o = Opt("FE", "Augmenter la nuance des aciers (Fe)", "Toute la structure", "Vérifiez la disponibilité de la nuance sur le chantier.");
        o.Steps.Add(new FixStep { Text = $"Fe : {m.Fe:0} → 500 MPa", Apply = mdl => mdl.Fe = 500 });
        return o;
    }

    // ====================================================================== barres
    private static string MemberDetail(MemberDesignResult r)
    {
        var sb = new StringBuilder();
        string typ = r.Type == MemberType.Column ? "Poteau" : "Poutre";
        sb.AppendLine($"{typ} {r.MemberId} - {(r.Kind == MaterialKind.Steel ? r.Profile : $"{Cm(r.B)}x{Cm(r.H)} cm")} - L = {r.Length:0.00} m - état : {r.Status}");
        if (r.Kind == MaterialKind.Steel) sb.AppendLine($"Taux de travail : {r.Utilization * 100:0} % (limite 100 %)");
        else if (r.Type == MemberType.Column) sb.AppendLine($"Taux (armatures nécessaires / maximales) : {r.Utilization * 100:0} % (limite 100 %) ; Nu max = {r.NuMax:0} kN");
        else sb.AppendLine($"Taux de travail : {r.Utilization * 100:0} % (limite 100 %) ; Mu travée = {r.MuSag:0.0} kN.m, Mu appui = {r.MuHog:0.0} kN.m, Vu = {r.Vu:0.0} kN");
        if (!string.IsNullOrWhiteSpace(r.Summary) && !r.Skipped) sb.AppendLine(r.Summary);
        foreach (var w in r.Warnings) sb.AppendLine("- " + w);
        return sb.ToString().TrimEnd();
    }

    /// <summary>Cible et solutions pour une barre NON OK.</summary>
    public static (FixTarget Target, List<FixOption> Options) ForMember(StructModel m, AnalysisOutput cur, int id, bool byDeflection = false)
    {
        var r = cur.Members.FirstOrDefault(x => x.MemberId == id);
        var mem = m.Members.FirstOrDefault(x => x.Id == id);
        string before = mem == null ? "" : SectionText(mem);
        var t = new FixTarget
        {
            Title = $"Barre {id}",
            HasUtil = true,
            Before = r?.Utilization ?? 0,
            BeforeOk = r != null && (r.Ok || r.Skipped),
            Detail = r == null ? "" : MemberDetail(r),
            Read = ao =>
            {
                var q = ao.Members.FirstOrDefault(x => x.MemberId == id);
                return q == null ? new FixReading(false, false, 0) : new FixReading(true, q.Ok && !q.Skipped, q.Utilization);
            },
            Section = mdl => { var sm = mdl.Members.FirstOrDefault(x => x.Id == id); return sm == null ? "" : before + " → " + SectionText(sm); }
        };
        if (byDeflection && cur.Global != null)
        {
            var dr = cur.Global.Deflections.FirstOrDefault(x => x.MemberId == id);
            if (dr != null)
            {
                t.Before = dr.DeltaMm / Math.Max(dr.LimitMm, 1e-9); t.BeforeOk = dr.Ok;
                t.Detail = $"Flèche de service {dr.DeltaMm:0.0} mm pour une limite de {dr.LimitMm:0.0} mm (L/{dr.Ratio:0}), combinaison {dr.Combo}\n" + t.Detail;
                t.Read = ao =>
                {
                    var q = ao.Global?.Deflections.FirstOrDefault(x => x.MemberId == id);
                    return q == null ? new FixReading(false, false, 0) : new FixReading(true, q.Ok, q.DeltaMm / Math.Max(q.LimitMm, 1e-9));
                };
            }
        }
        var L = new List<FixOption>();
        if (mem == null) return (t, L);
        bool col = mem.Type == MemberType.Column;

        if (mem.Kind == MaterialKind.Steel)
        {
            var op = Opt("PROFILE", "Passer au profilé supérieur", "Cette barre", "Profilés du catalogue, du plus léger au plus lourd de la famille.");
            string cur2 = mem.Profile;
            for (int k = 0; k < 5 && !string.IsNullOrWhiteSpace(cur2); k++)
            {
                var next = SteelCatalog.Next(cur2);
                if (next == null) break;
                string to = next.Name;
                cur2 = to;
                op.Steps.Add(new FixStep { Text = $"profilé {mem.Profile} → {to}", Apply = mdl => MemOf(mdl, id).Profile = to });
            }
            if (op.Steps.Count > 0) L.Add(op);
            return (t, L);
        }

        // ---- hauteur
        {
            var oh = Opt("H", "Augmenter la hauteur de la section", "Cette barre");
            foreach (double dlt in new[] { 0.05, 0.10, 0.15, 0.20, 0.30 })
            {
                double nh = Math.Round(mem.H + dlt, 3);
                if (nh > 1.5) break;
                oh.Steps.Add(new FixStep { Text = $"h : {Cm(mem.H)} → {Cm(nh)} cm", Apply = mdl => MemOf(mdl, id).H = nh });
            }
            if (oh.Steps.Count > 0) L.Add(oh);
        }
        // ---- largeur
        {
            var ob = Opt("B", "Augmenter la largeur de la section", "Cette barre");
            foreach (double dlt in new[] { 0.05, 0.10, 0.15, 0.20 })
            {
                double nb = Math.Round(mem.B + dlt, 3);
                if (nb > 1.5) break;
                ob.Steps.Add(new FixStep { Text = $"b : {Cm(mem.B)} → {Cm(nb)} cm", Apply = mdl => MemOf(mdl, id).B = nb });
            }
            if (ob.Steps.Count > 0) L.Add(ob);
        }
        // ---- poteau : b et h ensemble
        if (col)
        {
            var os = Opt("SEC", "Augmenter la section (b et h)", "Cette barre");
            foreach (double dlt in new[] { 0.05, 0.10, 0.15, 0.20, 0.30 })
            {
                double nb = Math.Round(mem.B + dlt, 3), nh = Math.Round(mem.H + dlt, 3);
                if (nb > 1.5 || nh > 1.5) break;
                os.Steps.Add(new FixStep { Text = $"b x h : {Cm(mem.B)}x{Cm(mem.H)} → {Cm(nb)}x{Cm(nh)} cm", Apply = mdl => { var sm = MemOf(mdl, id); sm.B = nb; sm.H = nh; } });
            }
            if (os.Steps.Count > 0) L.Add(os);
        }
        // ---- béton, acier
        var fc = ConcreteOption(m); if (fc != null) L.Add(fc);
        var fy = SteelGradeOption(m); if (fy != null) L.Add(fy);

        // ---- nombre / diamètre des barres : réglages du projet que le calcul respecte
        if (col)
        {
            int n0 = m.Settings.MaxColumnBars;
            var on = Opt("BARS", "Autoriser plus de barres longitudinales", "Réglage du projet", "Les barres sont choisies par le calcul dans les limites des réglages (onglet Réglages). Cette solution relève la limite du nombre de barres des poteaux.");
            foreach (int add in new[] { 4, 8 }) { int nv = n0 + add; on.Steps.Add(new FixStep { Text = $"barres max par poteau : {n0} → {nv}", Apply = mdl => mdl.Settings.MaxColumnBars = nv }); }
            L.Add(on);
            if (m.Settings.ColumnDiameters.Length > 0 && m.Settings.ColumnDiameters.Max() < 40)
            {
                var od = Opt("DIA", "Autoriser le diamètre HA40", "Réglage du projet", "HA40 est rare et difficile à façonner : à réserver aux gros poteaux.");
                od.Steps.Add(new FixStep { Text = "diamètres des poteaux : ajout du HA40", Apply = mdl => mdl.Settings.ColumnDiameters = mdl.Settings.ColumnDiameters.Append(40).ToArray() });
                L.Add(od);
            }
        }
        else
        {
            int n0 = m.Settings.MaxBarsPerLayer;
            var on = Opt("BARS", "Autoriser plus de barres par lit", "Réglage du projet", "Les barres sont choisies par le calcul dans les limites des réglages. Cette solution relève la limite du nombre de barres par lit (vérifiez la largeur de la poutre).");
            foreach (int add in new[] { 2, 4 }) { int nv = n0 + add; on.Steps.Add(new FixStep { Text = $"barres max par lit : {n0} → {nv}", Apply = mdl => mdl.Settings.MaxBarsPerLayer = nv }); }
            L.Add(on);
            if (m.Settings.BeamDiameters.Length > 0 && m.Settings.BeamDiameters.Max() < 40)
            {
                var od = Opt("DIA", "Autoriser le diamètre HA40", "Réglage du projet", "HA40 est rare et difficile à façonner : à réserver aux grosses poutres.");
                od.Steps.Add(new FixStep { Text = "diamètres des poutres : ajout du HA40", Apply = mdl => mdl.Settings.BeamDiameters = mdl.Settings.BeamDiameters.Append(40).ToArray() });
                L.Add(od);
            }
        }
        // ---- enrobage
        bool nominal = mem.CoverNomCm > 0;
        if (nominal ? mem.CoverNomCm > 2.55 : mem.Cover > 0.045)
        {
            var oc = Opt("COVER", "Réduire l'enrobage", "Cette barre", "Vérifiez que la classe d'exposition (durabilité) autorise cet enrobage.");
            if (nominal) oc.Steps.Add(new FixStep { Text = $"enrobage nominal : {mem.CoverNomCm:0.#} → 2,5 cm", Apply = mdl => MemOf(mdl, id).CoverNomCm = 2.5 });
            else oc.Steps.Add(new FixStep { Text = $"enrobage à l'axe : {Cm(mem.Cover)} → 4 cm", Apply = mdl => MemOf(mdl, id).Cover = 0.04 });
            L.Add(oc);
        }
        // ---- optimiseur
        {
            var oo = Opt("OPTIM", "Relancer l'optimisation de cette barre", "Cette barre", "Même règle que « Optimiser les sections » : la section grandit par pas jusqu'à ce que la barre soit vérifiée.");
            oo.ShowSection = true;
            for (int k = 1; k <= 6; k++)
            {
                int steps = k;
                oo.Steps.Add(new FixStep
                {
                    Text = $"{steps} pas d'optimisation",
                    Apply = mdl => { var um = MemOf(mdl, id); for (int qi = 0; qi < steps; qi++) if (!ProjectAnalyzer.Upsize(um)) break; }
                });
            }
            L.Add(oo);
        }
        return (t, L);
    }

    /// <summary>Solution « autre section » avec des dimensions choisies par l'utilisateur (cm).</summary>
    public static FixOption CustomSection(StructModel m, int id, double bCm, double hCm)
    {
        var o = Opt("CUSTOM", "Section choisie", "Cette barre");
        var mem = m.Members.FirstOrDefault(x => x.Id == id);
        string from = mem == null ? "" : SectionText(mem);
        double nb = bCm / 100.0, nh = hCm / 100.0;
        o.Steps.Add(new FixStep { Text = $"section : {from} → {Cm(nb)}x{Cm(nh)} cm", Apply = mdl => { var sm = MemOf(mdl, id); sm.B = nb; sm.H = nh; } });
        return o;
    }

    // ====================================================================== dalles
    public static (FixTarget Target, List<FixOption> Options) ForSlab(StructModel m, AnalysisOutput cur, string slabName)
    {
        string prefix = $"Dalle {slabName} (";
        var d = cur.Slabs.FirstOrDefault(x => x.Element.StartsWith(prefix, StringComparison.Ordinal));
        var t = new FixTarget
        {
            Title = $"Dalle {slabName}",
            HasUtil = false,
            BeforeOk = d?.Ok ?? true,
            Detail = d == null ? "" : SlabChecks(d),
            Read = ao =>
            {
                var q = ao.Slabs.FirstOrDefault(x => x.Element.StartsWith(prefix, StringComparison.Ordinal));
                return q == null ? new FixReading(false, false, 0) : new FixReading(true, q.Ok, 0);
            }
        };
        var L = new List<FixOption>();
        var s = m.Slabs.FirstOrDefault(x => x.Name == slabName);
        if (s != null) L.Add(SlabThickness(s, "Augmenter l'épaisseur de la dalle"));
        var fc = ConcreteOption(m); if (fc != null) L.Add(fc);
        var fy = SteelGradeOption(m); if (fy != null) L.Add(fy);
        return (t, L);
    }

    /// <summary>Combinaison qui gouverne le calcul d'une dalle (méthodes de dalles : charge surfacique de calcul ELU et ELS).</summary>
    public const string SlabCombo = "ELU 1,35 G + 1,5 Q (flexion, tranchant) ; ELS G + Q (flèche)";

    /// <summary>Vérifications d'une dalle, une par ligne : vérification concernée, valeur calculée, valeur limite, statut, combinaison critique.</summary>
    public static string SlabChecks(DesignResult d)
    {
        var sb = new StringBuilder();
        sb.AppendLine(d.Element + (d.Ok ? " - conforme" : " - NON OK"));
        sb.AppendLine("Combinaison critique : " + SlabCombo + (d.Values.TryGetValue("pu", out var pu) && d.Values.TryGetValue("ps", out var ps) ? $" ; charge de calcul pu = {pu:0.00} kN/m², ps = {ps:0.00} kN/m²" : ""));
        string Flex(bool bad) => bad ? "NON OK" : "OK";
        bool flexBad = d.Warnings.Any(w => w.StartsWith("Section de dalle insuffisante", StringComparison.Ordinal));
        string moments = d.Notes.FirstOrDefault(n => n.StartsWith("Moments retenus", StringComparison.Ordinal)) ?? "";
        sb.AppendLine($"- Flexion : {Flex(flexBad)}" + (moments != "" ? " ; " + moments : "") +
                      (d.Values.TryGetValue("Asx_travee_cm2m", out var ax) && d.Values.TryGetValue("Asy_travee_cm2m", out var ay) ? $" ; As travée = {ax:0.00} / {ay:0.00} cm²/m" : ""));
        if (d.Values.TryGetValue("tau_u", out var tu) && d.Values.TryGetValue("tau_lim", out var tl))
            sb.AppendLine($"- Effort tranchant : {(tu > tl ? "NON OK" : "OK")} ; τu = {tu:0.000} MPa, limite τlim = {tl:0.000} MPa (taux {tu / Math.Max(tl, 1e-9) * 100:0} %)");
        if (d.Values.TryGetValue("needs_deflection_calc", out var nd))
            sb.AppendLine($"- Flèche : {(nd > 0 ? "à vérifier par un calcul de flèche (conditions forfaitaires non satisfaites)" : "OK (conditions forfaitaires satisfaites)")}");
        foreach (var w in d.Warnings.Distinct()) sb.AppendLine("- Alerte : " + w);
        sb.Append("Le résultat d'une modification n'est définitif qu'après relance du calcul.");
        return sb.ToString();
    }

    private static FixOption SlabThickness(SlabPanel s, string label)
    {
        string name = s.Name;
        var o = Opt("SLABH", label, "Dalle " + name, "Le poids propre de la dalle augmente : les charges descendues sont recalculées.");
        foreach (double dlt in new[] { 0.02, 0.04, 0.06, 0.08, 0.10 })
        {
            double nh = Math.Round(s.H + dlt, 3);
            if (nh > 0.40) break;
            o.Steps.Add(new FixStep { Text = $"épaisseur : {Cm(s.H)} → {Cm(nh)} cm", Apply = mdl => { var sl = mdl.Slabs.First(x => x.Name == name); sl.H = nh; } });
        }
        return o;
    }

    // ====================================================================== poinçonnement
    public static (FixTarget Target, List<FixOption> Options) ForPunching(StructModel m, AnalysisOutput cur, StructCalc.Engine.Structure.PunchingResult p)
    {
        string colName = p.Column, slabName = p.Slab;
        var sb = new StringBuilder();
        sb.AppendLine($"{p.Column} sous la dalle {p.Slab} ({p.Position}, {p.Rule})");
        sb.AppendLine($"V_Ed = {p.VEd:0.#} kN ; hauteur utile d = {p.D * 100:0.#} cm ; périmètre critique u1 = {p.U1:0.00} m ; β = {p.Beta:0.00}");
        sb.AppendLine($"Contrainte v_Ed = {p.StressEd:0.00} MPa ; sans armatures v_Rd,c = {p.StressRdc:0.00} MPa ; maximale v_Rd,max = {p.StressRdMax:0.00} MPa");
        sb.AppendLine(p.NeedsShear ? $"Armatures de poinçonnement requises : Asw = {p.AswCm2:0.0} cm² par périmètre" : "Pas d'armatures de poinçonnement requises");
        sb.AppendLine($"Taux : {p.Util * 100:0} % (limite 100 %) ; taux vis-à-vis du maximum : {p.UtilMax * 100:0} %");
        var t = new FixTarget
        {
            Title = $"Poinçonnement {p.Column} / dalle {p.Slab}",
            HasUtil = true,
            Before = Math.Max(p.Util, p.UtilMax),
            BeforeOk = p.Ok,
            Detail = sb.ToString().TrimEnd(),
            Read = ao =>
            {
                var q = ao.Punching.FirstOrDefault(x => x.Column == colName && x.Slab == slabName);
                return q == null ? new FixReading(false, false, 0) : new FixReading(true, q.Ok, Math.Max(q.Util, q.UtilMax));
            }
        };
        var L = new List<FixOption>();
        var s = m.Slabs.FirstOrDefault(x => x.Name == slabName);
        var mt = Regex.Match(colName ?? "", @"^Poteau\s+(\d+)");
        Member? col = mt.Success && int.TryParse(mt.Groups[1].Value, out int cid) ? m.Members.FirstOrDefault(x => x.Id == cid) : null;
        if (s != null) L.Add(SlabThickness(s, "Augmenter l'épaisseur de la dalle"));
        if (s != null)
        {
            double cdim = col == null ? 0.30 : Math.Max(col.B, col.H);
            var oc = Opt("CAP", "Ajouter ou agrandir un chapiteau", "Dalle " + slabName, "Chapiteau carré sous la dalle au droit des poteaux ; le poinçonnement est vérifié sur son contour.");
            foreach (var (add, extra) in new[] { (0.60, 15.0), (1.00, 20.0), (1.40, 25.0) })
            {
                double side = Math.Round(cdim + add, 2), ex = extra;
                if (s.CapitalSide >= side && s.CapitalExtraCm >= ex) continue;
                oc.Steps.Add(new FixStep { Text = $"chapiteau {side:0.00} x {side:0.00} m, surépaisseur {ex:0} cm", Apply = mdl => { var sl = mdl.Slabs.First(x => x.Name == slabName); sl.CapitalSide = side; sl.CapitalExtraCm = ex; } });
            }
            if (oc.Steps.Count > 0) L.Add(oc);
        }
        if (col != null)
        {
            int cid2 = col.Id;
            var os = Opt("SEC", "Augmenter la section du poteau", "Poteau " + cid2);
            foreach (double dlt in new[] { 0.05, 0.10, 0.15, 0.20 })
            {
                double nb = Math.Round(col.B + dlt, 3), nh = Math.Round(col.H + dlt, 3);
                os.Steps.Add(new FixStep { Text = $"poteau {cid2} : {Cm(col.B)}x{Cm(col.H)} → {Cm(nb)}x{Cm(nh)} cm", Apply = mdl => { var sm = MemOf(mdl, cid2); sm.B = nb; sm.H = nh; } });
            }
            L.Add(os);
        }
        var fc = ConcreteOption(m); if (fc != null) L.Add(fc);
        return (t, L);
    }

    // ====================================================================== semelles et autres modules : diagnostic seulement
    public static FixTarget ForFooting(DesignResult f)
    {
        var sb = new StringBuilder();
        sb.AppendLine(f.Element);
        foreach (var kv in f.Values.Where(v => v.Key is "A_m" or "B_m" or "h_m" or "sigma_ser_kPa")) sb.AppendLine($"{kv.Key} = {kv.Value:0.##}");
        foreach (var n in f.Notes.Take(4)) sb.AppendLine(n);
        foreach (var w in f.Warnings) sb.AppendLine("- " + w);
        if (f.Texts.TryGetValue("Cause du NON OK", out var cz)) sb.AppendLine("Cause du NON OK : " + cz);
        if (f.Texts.TryGetValue("Hypothèses géotechniques", out var hy)) sb.AppendLine("Hypothèses géotechniques : " + hy);
        return new FixTarget { Title = f.Element, BeforeOk = f.Ok, Detail = sb.ToString().TrimEnd() };
    }

    // ====================================================================== combinaison critique
    public sealed record CriticalInfo(string Text, string MomentCombo, string ShearCombo, string NormalCombo);

    private static (double V, string Combo, double X) Peak(ForceSeries s)
    {
        if (s.X.Length == 0 || s.Max.Length == 0) return (0, "", 0);
        int a = s.IndexOfMax(), b = s.IndexOfMin();
        return Math.Abs(s.Max[a]) >= Math.Abs(s.Min[b]) ? (s.Max[a], s.MaxCombo[a], s.X[a]) : (s.Min[b], s.MinCombo[b], s.X[b]);
    }

    /// <summary>Combinaisons ELU qui gouvernent la barre : moment, tranchant, effort normal (valeur absolue maximale, position, combinaison).</summary>
    public static CriticalInfo Critical(AnalysisOutput o, int memberId)
    {
        var st = o.Store;
        if (st == null) return new CriticalInfo("Résultats détaillés indisponibles : relancez le calcul.", "", "", "");
        var my = Peak(st.Series(ResultsStore.EnvUls, memberId, ForceQty.My));
        var mz = Peak(st.Series(ResultsStore.EnvUls, memberId, ForceQty.Mz));
        var vz = Peak(st.Series(ResultsStore.EnvUls, memberId, ForceQty.Vz));
        var vy = Peak(st.Series(ResultsStore.EnvUls, memberId, ForceQty.Vy));
        var nn = Peak(st.Series(ResultsStore.EnvUls, memberId, ForceQty.N));
        var m = Math.Abs(my.V) >= Math.Abs(mz.V) ? (Q: "My", P: my) : (Q: "Mz", P: mz);
        var v = Math.Abs(vz.V) >= Math.Abs(vy.V) ? (Q: "Vz", P: vz) : (Q: "Vy", P: vy);
        var sb = new StringBuilder();
        sb.AppendLine($"Barre {memberId} - combinaisons ELU / accidentelles qui gouvernent :");
        sb.AppendLine($"  Moment {m.Q} max = {m.P.V:0.0} kN.m à x = {m.P.X:0.00} m : {m.P.Combo}");
        sb.AppendLine($"  Tranchant {v.Q} max = {v.P.V:0.0} kN à x = {v.P.X:0.00} m : {v.P.Combo}");
        sb.AppendLine($"  Effort normal max = {nn.V:0.0} kN (négatif = compression) à x = {nn.X:0.00} m : {nn.Combo}");
        return new CriticalInfo(sb.ToString().TrimEnd(), m.P.Combo, v.P.Combo, nn.Combo);
    }
}
