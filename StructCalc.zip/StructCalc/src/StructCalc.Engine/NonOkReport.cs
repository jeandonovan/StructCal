using System.Net;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Un élément NON OK : type, libellé, cause.</summary>
public sealed record NonOkEntry(string Type, string Label, string Cause);

/// <summary>Éléments non vérifiés d'un calcul, comptés et listés par type (poutre, poteau, dalle, semelle, voile, escalier...) pour les rapports et la synthèse.
/// Un NON OK de dimensionnement ne bloque ni le calcul ni les rapports : il y est simplement très visible, et n'est jamais présenté comme validé.</summary>
public static class NonOkReport
{
    private static string First(IEnumerable<string> w, string dflt) => w.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? dflt;

    private static string ExtraType(string title)
    {
        string t = (title ?? "").ToLowerInvariant();
        if (t.StartsWith("escalier") || t.Contains("escalier")) return "Escalier";
        if (t.StartsWith("voile") || t.Contains("voile") || t.Contains("noyau")) return "Voile";
        if (t.StartsWith("radier")) return "Radier";
        if (t.Contains("plancher") || t.Contains("nervur") || t.Contains("poutrelle")) return "Plancher";
        if (t.Contains("semelle") || t.Contains("fondation") || t.Contains("pieu")) return "Fondation";
        return "Autre module";
    }

    public static List<NonOkEntry> Collect(AnalysisOutput o)
    {
        var L = new List<NonOkEntry>();
        foreach (var r in o.Members.Where(x => !x.Ok && !x.Skipped))
            L.Add(new NonOkEntry(r.Type == MemberType.Column ? "Poteau" : "Poutre", "Barre " + r.MemberId + " (" + r.SectionText + ")",
                First(r.Warnings, "taux de travail supérieur à 100 % ou ferraillage impossible") + (r.Utilization > 0 ? $" - taux {r.Utilization * 100:0} %" : "")));
        foreach (var s in o.Slabs.Where(x => !x.Ok)) L.Add(new NonOkEntry("Dalle", s.Element, First(s.Warnings, "section ou ferraillage insuffisant")));
        foreach (var f in o.Footings.Where(x => !x.Ok)) L.Add(new NonOkEntry("Semelle", f.Element, First(f.Warnings, "sol ou section insuffisant")));
        foreach (var p in o.Punching.Where(x => !x.Ok))
            L.Add(new NonOkEntry("Poinçonnement", $"{p.Column} / dalle {p.Slab}", $"v_Ed = {p.StressEd:0.00} MPa pour v_Rd,c = {p.StressRdc:0.00} MPa et v_Rd,max = {p.StressRdMax:0.00} MPa - taux {Math.Max(p.Util, p.UtilMax) * 100:0} %"));
        foreach (var x in o.Extras.Where(q => !q.Ok))
        {
            string line = (x.Text ?? "").Split('\n').Select(l => l.Trim()).FirstOrDefault(l => l.Contains("NON", StringComparison.OrdinalIgnoreCase) || l.Contains("insuffisant", StringComparison.OrdinalIgnoreCase)) ?? "voir le détail du module";
            L.Add(new NonOkEntry(ExtraType(x.Title), x.Title, line));
        }
        return L;
    }

    /// <summary>Total, puis nombre par type (ordre décroissant).</summary>
    public static List<(string Type, int Count)> ByType(IEnumerable<NonOkEntry> e) =>
        e.GroupBy(x => x.Type).Select(g => (g.Key, g.Count())).OrderByDescending(t => t.Item2).ThenBy(t => t.Key).ToList();

    public static string ToText(AnalysisOutput o)
    {
        var e = Collect(o);
        var sb = new StringBuilder();
        if (e.Count == 0) { sb.AppendLine("Éléments NON OK : aucun."); return sb.ToString(); }
        sb.AppendLine($"!!! {e.Count} ÉLÉMENT(S) NON OK - le projet n'est PAS vérifié !!!");
        sb.AppendLine("Par type : " + string.Join(", ", ByType(e).Select(t => $"{t.Type} {t.Count}")));
        foreach (var g in e.GroupBy(x => x.Type))
        {
            sb.AppendLine($"  {g.Key} :");
            foreach (var x in g) sb.AppendLine($"    - {x.Label} : {x.Cause}");
        }
        return sb.ToString();
    }

    public static string ToHtml(AnalysisOutput o)
    {
        var e = Collect(o);
        var sb = new StringBuilder();
        if (e.Count == 0)
        {
            sb.AppendLine("<div style='border:2px solid #0a7a2f;background:#e8f5e9;padding:8px 12px;margin:14px 0'><b>Éléments NON OK : aucun.</b> Cette conclusion vaut pour les vérifications effectuées par ce calcul ; elle est à confirmer par l'ingénieur responsable.</div>");
            return sb.ToString();
        }
        string H(string s) => WebUtility.HtmlEncode(s);
        sb.AppendLine("<div style='border:4px solid #c00;background:#fdecea;padding:10px 14px;margin:14px 0'>");
        sb.AppendLine($"<h2 style='color:#c00;border:none;margin:0 0 6px 0'>&#9888; {e.Count} élément(s) NON OK - le projet n'est pas vérifié</h2>");
        sb.AppendLine("<p style='margin:4px 0'><b>Par type :</b> " + H(string.Join(", ", ByType(e).Select(t => $"{t.Type} : {t.Count}"))) + "</p>");
        sb.AppendLine("<table><tr><th>Type</th><th>Élément</th><th>Cause</th></tr>");
        foreach (var x in e.OrderBy(q => q.Type).ThenBy(q => q.Label)) sb.AppendLine($"<tr><td><b>{H(x.Type)}</b></td><td class='ko'>{H(x.Label)}</td><td>{H(x.Cause)}</td></tr>");
        sb.AppendLine("</table><p style='margin:6px 0 0 0;font-size:12px'>Un élément NON OK ne bloque pas le calcul ni ce rapport, mais ne doit pas être considéré comme validé : voir les solutions proposées dans le logiciel.</p></div>");
        return sb.ToString();
    }
}
