using System.Globalization;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Choix des barres cibles d'une charge.</summary>
public enum LoadTarget { Selection, AllMembers, AllBeams, AllColumns, Level }

/// <summary>Création de charges (assistant « Charges » façon Robot) : nodales, réparties, trapézoïdales, ponctuelles à distance, moments, thermiques, surfaciques.
/// Les distances se mesurent depuis le nœud i ou j, en mètres ou en pourcentage de la longueur.</summary>
public static class LoadBuilder
{
    private static double Length(StructModel m, Member mem)
    {
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        if (a == null || b == null) return 0;
        return Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
    }

    /// <summary>Barres visées : sélection, toutes, poutres, poteaux, ou barres du niveau (dont le centre est à la cote donnée ± 5 cm : poutres du niveau).</summary>
    public static List<int> ResolveMembers(StructModel m, LoadTarget target, IEnumerable<int>? selection, double levelZ = 0)
    {
        switch (target)
        {
            case LoadTarget.Selection:
                var set = new HashSet<int>(selection ?? Array.Empty<int>());
                return m.Members.Where(x => set.Contains(x.Id)).Select(x => x.Id).ToList();
            case LoadTarget.AllBeams: return m.Members.Where(x => x.Type == MemberType.Beam).Select(x => x.Id).ToList();
            case LoadTarget.AllColumns: return m.Members.Where(x => x.Type == MemberType.Column).Select(x => x.Id).ToList();
            case LoadTarget.Level:
            {
                var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
                var r = new List<int>();
                foreach (var mem in m.Members)
                {
                    if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                    if (Math.Abs(a.Z - levelZ) < 0.05 && Math.Abs(b.Z - levelZ) < 0.05) r.Add(mem.Id);
                }
                return r;
            }
            default: return m.Members.Select(x => x.Id).ToList();
        }
    }

    // ------------------------------------------------------------------ nodales
    public static int AddNodal(StructModel m, IEnumerable<int> nodeIds, ActionType c, double fx, double fy, double fz, double mx, double my, double mz)
    {
        int n = 0;
        foreach (int id in nodeIds.Distinct())
        {
            if (!m.Nodes.Any(x => x.Id == id)) continue;
            var ex = m.NodalLoads.FirstOrDefault(l => l.NodeId == id && l.Case == c);
            if (ex != null) { ex.Fx += fx; ex.Fy += fy; ex.Fz += fz; ex.Mx += mx; ex.My += my; ex.Mz += mz; }
            else m.NodalLoads.Add(new NodalLoad { NodeId = id, Case = c, Fx = fx, Fy = fy, Fz = fz, Mx = mx, My = my, Mz = mz });
            n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ sur barre
    /// <summary>Charge répartie uniforme (toute la barre) dans le repère choisi. Valeurs en kN/m.</summary>
    public static int AddUniform(StructModel m, IEnumerable<int> memberIds, ActionType c, LoadFrame frame, double wx, double wy, double wz)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            if (m.Members.All(x => x.Id != id)) continue;
            m.MemberLoads.Add(new MemberLoad { MemberId = id, Case = c, Frame = frame, Wx = wx, Wy = wy, Wz = wz });
            n++;
        }
        return n;
    }

    /// <summary>Charge répartie linéaire (trapèze, triangle, partielle) entre a et b, mesurées depuis le nœud i (fromEndJ = false) ou le nœud j.
    /// w1 est l'intensité du côté de a, w2 celle du côté de b (a et b étant toujours comptés depuis l'origine choisie).</summary>
    public static int AddTrapezoid(StructModel m, IEnumerable<int> memberIds, ActionType c, LoadFrame frame, double a, double b, bool relative, bool fromEndJ,
                                   double[] w1, double[] w2)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            double L = Length(m, mem); if (L < 1e-9) continue;
            double aa = relative ? a : a / L, bb = relative ? b : b / L;     // fractions
            if (relative) { aa = a; bb = b; }
            var ld = new MemberLoad { MemberId = id, Case = c, Kind = MemberLoadKind.Trapezoid, Frame = frame, Relative = true };
            if (!fromEndJ) { ld.A = aa; ld.B = bb; ld.Wx = w1[0]; ld.Wy = w1[1]; ld.Wz = w1[2]; ld.Wx2 = w2[0]; ld.Wy2 = w2[1]; ld.Wz2 = w2[2]; }
            else
            {
                // depuis j : l'abscisse depuis i vaut 1 - a ; l'intensité « côté a » devient l'intensité du côté de la fin
                ld.A = 1 - bb; ld.B = 1 - aa;
                ld.Wx = w2[0]; ld.Wy = w2[1]; ld.Wz = w2[2]; ld.Wx2 = w1[0]; ld.Wy2 = w1[1]; ld.Wz2 = w1[2];
            }
            m.MemberLoads.Add(ld);
            n++;
        }
        return n;
    }

    /// <summary>Force concentrée à la distance d du nœud i (ou j), en mètres ou en fraction (0-1) de la longueur.</summary>
    public static int AddPointForce(StructModel m, IEnumerable<int> memberIds, ActionType c, LoadFrame frame, double d, bool relative, bool fromEndJ, double px, double py, double pz)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            double L = Length(m, mem); if (L < 1e-9) continue;
            double frac = relative ? d : d / L;
            if (fromEndJ) frac = 1 - frac;
            m.MemberLoads.Add(new MemberLoad { MemberId = id, Case = c, Kind = MemberLoadKind.Point, Frame = frame, Relative = true, A = Math.Max(0, Math.Min(1, frac)), Px = px, Py = py, Pz = pz });
            n++;
        }
        return n;
    }

    public static int AddPointMoment(StructModel m, IEnumerable<int> memberIds, ActionType c, LoadFrame frame, double d, bool relative, bool fromEndJ, double mx, double my, double mz)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == id);
            if (mem == null) continue;
            double L = Length(m, mem); if (L < 1e-9) continue;
            double frac = relative ? d : d / L;
            if (fromEndJ) frac = 1 - frac;
            m.MemberLoads.Add(new MemberLoad { MemberId = id, Case = c, Kind = MemberLoadKind.Moment, Frame = frame, Relative = true, A = Math.Max(0, Math.Min(1, frac)), Mx = mx, My = my, Mz = mz });
            n++;
        }
        return n;
    }

    public static int AddThermal(StructModel m, IEnumerable<int> memberIds, ActionType c, double dt, double dg)
    {
        int n = 0;
        foreach (int id in memberIds.Distinct())
        {
            if (m.Members.All(x => x.Id != id)) continue;
            m.MemberLoads.Add(new MemberLoad { MemberId = id, Case = c, Kind = MemberLoadKind.Thermal, Dt = dt, Dg = dg });
            n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ surfaciques
    public static SurfaceLoad AddSurface(StructModel m, ActionType c, double q, SurfaceDistribution mode, double z, double x0, double y0, double x1, double y1)
    {
        var s = new SurfaceLoad
        {
            Name = "S" + (m.SurfaceLoads.Count + 1), Case = c, Q = q, Distribution = mode, Z = z,
            X0 = Math.Min(x0, x1), X1 = Math.Max(x0, x1), Y0 = Math.Min(y0, y1), Y1 = Math.Max(y0, y1)
        };
        m.SurfaceLoads.Add(s);
        return s;
    }

    /// <summary>Panneau défini par 4 nœuds : doit former un rectangle horizontal aligné sur X et Y. Retourne null et un message sinon.</summary>
    public static SurfaceLoad? AddSurfaceFromNodes(StructModel m, IEnumerable<int> nodeIds, ActionType c, double q, SurfaceDistribution mode, out string message)
    {
        var pts = nodeIds.Distinct().Select(id => m.Nodes.FirstOrDefault(n => n.Id == id)).Where(n => n != null).Select(n => n!).ToList();
        message = "";
        if (pts.Count < 3) { message = "Choisissez au moins 3 nœuds (les coins du panneau)."; return null; }
        double z = pts[0].Z;
        if (pts.Any(p => Math.Abs(p.Z - z) > 2e-3)) { message = "Les nœuds doivent être à la même cote Z (panneau horizontal)."; return null; }
        double x0 = pts.Min(p => p.X), x1 = pts.Max(p => p.X), y0 = pts.Min(p => p.Y), y1 = pts.Max(p => p.Y);
        if (x1 - x0 < 0.1 || y1 - y0 < 0.1) { message = "Panneau dégénéré (les nœuds sont alignés)."; return null; }
        foreach (var p in pts)
            if (!(Math.Abs(p.X - x0) < 2e-3 || Math.Abs(p.X - x1) < 2e-3) || !(Math.Abs(p.Y - y0) < 2e-3 || Math.Abs(p.Y - y1) < 2e-3))
            { message = "Les nœuds doivent être les coins d'un rectangle aligné sur les axes X et Y."; return null; }
        return AddSurface(m, c, q, mode, z, x0, y0, x1, y1);
    }

    /// <summary>Ajoute une charge surfacique sur chaque panneau détecté (dont la cote est dans zLevels si la liste n'est pas vide).</summary>
    public static int AddSurfaceAuto(StructModel m, ActionType c, double q, SurfaceDistribution mode, IEnumerable<double>? zLevels)
    {
        var levels = zLevels?.ToList() ?? new List<double>();
        int n = 0;
        foreach (var p in LoadExpander.DetectPanels(m))
        {
            if (levels.Count > 0 && !levels.Any(z => Math.Abs(z - p.Z) < 0.05)) continue;
            if (m.SurfaceLoads.Any(s => s.Case == c && Math.Abs(s.Z - p.Z) < 2e-3 && Math.Abs(s.X0 - p.X0) < 2e-3 && Math.Abs(s.X1 - p.X1) < 2e-3
                                        && Math.Abs(s.Y0 - p.Y0) < 2e-3 && Math.Abs(s.Y1 - p.Y1) < 2e-3)) continue;      // déjà chargé
            AddSurface(m, c, q, mode, p.Z, p.X0, p.Y0, p.X1, p.Y1);
            n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ suppression
    /// <summary>Supprime les charges d'un cas (ou de tous si c est null) sur les barres choisies ; si memberIds est null : tout le modèle, y compris nodales et surfaciques.</summary>
    public static int Clear(StructModel m, IEnumerable<int>? memberIds, ActionType? c)
    {
        int n = 0;
        var set = memberIds == null ? null : new HashSet<int>(memberIds);
        foreach (var l in m.MemberLoads.Where(l => (set == null || set.Contains(l.MemberId)) && (c == null || l.Case == c)).ToList()) { m.MemberLoads.Remove(l); n++; }
        if (set == null)
        {
            foreach (var l in m.NodalLoads.Where(l => c == null || l.Case == c).ToList()) { m.NodalLoads.Remove(l); n++; }
            n += m.SurfaceLoads.RemoveAll(s => c == null || s.Case == c);
        }
        return n;
    }
}

/// <summary>Descriptions lisibles des charges (liste, info-bulles, légendes).</summary>
public static class LoadDescriber
{
    private static string F(double v) => v.ToString("0.##", CultureInfo.InvariantCulture);

    private static string Comp(string unit, double x, double y, double z, string px = "x", string py = "y", string pz = "z")
    {
        var parts = new List<string>();
        if (Math.Abs(x) > 1e-12) parts.Add($"{px}={F(x)}");
        if (Math.Abs(y) > 1e-12) parts.Add($"{py}={F(y)}");
        if (Math.Abs(z) > 1e-12) parts.Add($"{pz}={F(z)}");
        return parts.Count == 0 ? "0 " + unit : string.Join(", ", parts) + " " + unit;
    }

    private static string Where(MemberLoad l)
    {
        string a = l.Relative ? $"{F(l.A * 100)} %" : $"{F(l.A)} m";
        string b = l.Relative ? $"{F(l.B * 100)} %" : $"{F(l.B)} m";
        return l.Kind == MemberLoadKind.Trapezoid ? $"de {a} à {b}" : $"à {a} du nœud i";
    }

    public static string Describe(MemberLoad l)
    {
        string fr = l.Frame == LoadFrame.Local ? " (axes locaux)" : "";
        switch (l.Kind)
        {
            case MemberLoadKind.Uniform: return $"Répartie uniforme {Comp("kN/m", l.Wx, l.Wy, l.Wz)}{fr}";
            case MemberLoadKind.Trapezoid:
                return $"Répartie linéaire {Where(l)} : {Comp("kN/m", l.Wx, l.Wy, l.Wz)} → {Comp("kN/m", l.Wx2, l.Wy2, l.Wz2)}{fr}";
            case MemberLoadKind.Point: return $"Force ponctuelle {Where(l)} : {Comp("kN", l.Px, l.Py, l.Pz, "Fx", "Fy", "Fz")}{fr}";
            case MemberLoadKind.Moment: return $"Moment ponctuel {Where(l)} : {Comp("kN.m", l.Mx, l.My, l.Mz, "Mx", "My", "Mz")}{fr}";
            default: return $"Température : ΔT uniforme {F(l.Dt)} °C, gradient {F(l.Dg)} °C";
        }
    }

    public static string Describe(NodalLoad l) =>
        (Math.Abs(l.Fx) + Math.Abs(l.Fy) + Math.Abs(l.Fz) > 0 ? "Force " + Comp("kN", l.Fx, l.Fy, l.Fz, "Fx", "Fy", "Fz") : "") +
        (Math.Abs(l.Mx) + Math.Abs(l.My) + Math.Abs(l.Mz) > 0 ? (Math.Abs(l.Fx) + Math.Abs(l.Fy) + Math.Abs(l.Fz) > 0 ? " ; " : "") + "Moment " + Comp("kN.m", l.Mx, l.My, l.Mz, "Mx", "My", "Mz") : "");

    public static string Describe(SurfaceLoad s)
    {
        string mode = s.Distribution switch { SurfaceDistribution.OneWayX => "portée en X", SurfaceDistribution.OneWayY => "portée en Y", _ => "2 sens (45°)" };
        return $"Surfacique {F(s.Q)} kN/m² ({mode}) sur panneau {F(s.X1 - s.X0)} x {F(s.Y1 - s.Y0)} m, Z = {F(s.Z)} m";
    }
}
