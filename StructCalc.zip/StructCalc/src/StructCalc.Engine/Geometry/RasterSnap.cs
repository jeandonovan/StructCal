namespace StructCalc.Engine.Geometry;

public enum RasterSnapKind { None, Line, End, Corner, Cross }

/// <summary>Accrochage sur un fond raster (PDF rendu en image, image) : détecte à partir des pixels « encre » les extrémités, coins,
/// intersections et traits à proximité d'un point. Fonctionne en coordonnées pixel (y vers le bas).</summary>
public static class RasterSnap
{
    private const int RingSamples = 24;
    private const double RingRadius = 4.0;

    private static readonly (double Dx, double Dy)[] Ring = BuildRing();
    private static (double, double)[] BuildRing()
    {
        var r = new (double, double)[RingSamples];
        for (int i = 0; i < RingSamples; i++) { double a = 2 * Math.PI * i / RingSamples; r[i] = (RingRadius * Math.Cos(a), RingRadius * Math.Sin(a)); }
        return r;
    }

    private static bool Ink(byte[] ink, int w, int h, int x, int y) => x >= 0 && y >= 0 && x < w && y < h && ink[y * w + x] != 0;

    /// <summary>Classe le pixel (x,y) d'après l'anneau d'encre qui l'entoure. Retourne le nombre d'arcs (0 = pas de trait ou surface pleine) et l'angle entre arcs pour 2 arcs.</summary>
    private static RasterSnapKind Classify(byte[] ink, int w, int h, int x, int y)
    {
        var on = new bool[RingSamples];
        int count = 0;
        for (int i = 0; i < RingSamples; i++)
        {
            on[i] = Ink(ink, w, h, (int)Math.Round(x + Ring[i].Dx), (int)Math.Round(y + Ring[i].Dy));
            if (on[i]) count++;
        }
        if (count == 0 || count == RingSamples) return RasterSnapKind.None;     // pixel isolé ou surface pleine
        // arcs = nombre de transitions faux -> vrai
        var starts = new List<int>();
        var lens = new List<int>();
        for (int i = 0; i < RingSamples; i++)
            if (on[i] && !on[(i + RingSamples - 1) % RingSamples])
            {
                int len = 0;
                while (on[(i + len) % RingSamples] && len < RingSamples) len++;
                starts.Add(i); lens.Add(len);
            }
        if (starts.Count >= 3) return RasterSnapKind.Cross;
        if (starts.Count == 1) return count <= RingSamples / 2 + 1 ? RasterSnapKind.End : RasterSnapKind.Corner;
        if (starts.Count == 2)
        {
            double m0 = starts[0] + (lens[0] - 1) / 2.0, m1 = starts[1] + (lens[1] - 1) / 2.0;
            double d = Math.Abs(m1 - m0); if (d > RingSamples / 2.0) d = RingSamples - d;
            // 12 échantillons = 180° : on tolère ±3 échantillons (45°) pour un simple trait
            return Math.Abs(d - RingSamples / 2.0) <= 3 ? RasterSnapKind.Line : RasterSnapKind.Corner;
        }
        return RasterSnapKind.None;
    }

    private static double Bonus(RasterSnapKind k) => k switch { RasterSnapKind.Cross => 7, RasterSnapKind.Corner => 6, RasterSnapKind.End => 5, _ => 0 };

    /// <summary>Cherche le meilleur point d'accrochage autour de (cx, cy) dans un rayon (pixels).</summary>
    public static bool Find(byte[] ink, int w, int h, double cx, double cy, int radius, out double fx, out double fy, out RasterSnapKind kind)
    {
        fx = cx; fy = cy; kind = RasterSnapKind.None;
        if (ink.Length < w * h || w < 8 || h < 8) return false;
        radius = Math.Max(2, Math.Min(radius, 40));
        int x0 = Math.Max(0, (int)Math.Floor(cx) - radius), x1 = Math.Min(w - 1, (int)Math.Ceiling(cx) + radius);
        int y0 = Math.Max(0, (int)Math.Floor(cy) - radius), y1 = Math.Min(h - 1, (int)Math.Ceiling(cy) + radius);
        int stride = radius > 14 ? 2 : 1;
        double bestScore = double.MaxValue; int bx = 0, by = 0; RasterSnapKind bk = RasterSnapKind.None;
        var feats = new List<(int X, int Y, RasterSnapKind K)>();
        double nearestInk = double.MaxValue; int nx = 0, ny = 0;
        for (int y = y0; y <= y1; y += stride)
            for (int x = x0; x <= x1; x += stride)
            {
                if (ink[y * w + x] == 0) continue;
                double d = Math.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
                if (d > radius) continue;
                if (d < nearestInk) { nearestInk = d; nx = x; ny = y; }
                var k = Classify(ink, w, h, x, y);
                if (k == RasterSnapKind.None || k == RasterSnapKind.Line) continue;
                feats.Add((x, y, k));
                double score = d - Bonus(k);
                if (score < bestScore) { bestScore = score; bx = x; by = y; bk = k; }
            }
        if (bk != RasterSnapKind.None)
        {
            // centre de gravité des pixels voisins de même nature (le point trouvé est en général sur le bord du trait)
            double sx = 0, sy = 0; int n = 0;
            foreach (var f in feats)
                if (f.K == bk && Math.Abs(f.X - bx) <= 4 && Math.Abs(f.Y - by) <= 4) { sx += f.X; sy += f.Y; n++; }
            fx = n > 0 ? sx / n : bx; fy = n > 0 ? sy / n : by; kind = bk;
            return true;
        }
        if (nearestInk < double.MaxValue)
        {
            // sur le trait : centre de l'encre dans un petit voisinage
            double sx = 0, sy = 0; int n = 0;
            for (int y = ny - 2; y <= ny + 2; y++)
                for (int x = nx - 2; x <= nx + 2; x++)
                    if (Ink(ink, w, h, x, y)) { sx += x; sy += y; n++; }
            fx = n > 0 ? sx / n : nx; fy = n > 0 ? sy / n : ny; kind = RasterSnapKind.Line;
            return true;
        }
        return false;
    }
}
