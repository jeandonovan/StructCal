using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Drawing;

namespace StructCalc.Engine.Geometry;

public enum RebarRole { Bottom, Top, Mounting, ColumnBar, Stirrup, Tie }

/// <summary>Une armature en 3D : polyligne (ouverte pour une barre, fermée pour un cadre) de diamètre DiaMm.</summary>
public sealed class RebarPath
{
    public int MemberId { get; set; }
    public RebarRole Role { get; set; }
    public int DiaMm { get; set; }
    public bool Closed { get; set; }
    public Vec3[] Pts { get; set; } = Array.Empty<Vec3>();
    public double LengthM { get; set; }
}

/// <summary>Construit le ferraillage 3D (barres longitudinales, chapeaux, cadres, épingles) à partir des résultats de dimensionnement.
/// Les positions suivent les nomenclatures des plans (mêmes nombres, diamètres et espacements).</summary>
public static class RebarModel
{
    private static double Len(Vec3[] p, bool closed)
    {
        double l = 0;
        for (int i = 0; i + 1 < p.Length; i++) l += (p[i + 1] - p[i]).Length;
        if (closed && p.Length > 2) l += (p[0] - p[^1]).Length;
        return l;
    }

    private static List<double> Spread(int n, double half)
    {
        var res = new List<double>();
        if (n <= 0) return res;
        if (n == 1) { res.Add(0); return res; }
        for (int i = 0; i < n; i++) res.Add(-half + 2 * half * i / (n - 1));
        return res;
    }

    public static List<RebarPath> Build(StructModel m, AnalysisOutput o)
    {
        var res = new List<RebarPath>();
        var cfg = m.Settings;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        foreach (var r in o.Members)
        {
            if (r.Skipped || r.Kind != MaterialKind.ReinforcedConcrete || r.BotN <= 0) continue;
            var mem = m.Members.FirstOrDefault(x => x.Id == r.MemberId);
            if (mem == null || !nodes.TryGetValue(mem.NodeI, out var na) || !nodes.TryGetValue(mem.NodeJ, out var nb)) continue;
            var a = new Vec3(na.X, na.Y, na.Z); var b = new Vec3(nb.X, nb.Y, nb.Z);
            double L = (b - a).Length;
            if (L < 0.3) continue;
            var (ex, ey, ez) = MemberSolids.Frame(a, b, mem.Roll);
            double bw = r.B > 0 ? r.B : mem.B, h = r.H > 0 ? r.H : mem.H;
            double cov = r.CoverM > 0 ? r.CoverM : (mem.Type == MemberType.Column ? 0.04 : 0.05);
            bool isCol = mem.Type == MemberType.Column;
            var lay = RebarLayout.Of(isCol, bw, h, cov, isCol ? Math.Max(4, r.BotN) : r.BotN, r.BotDia, r.TopN, r.StirDia);
            double sy = lay.StirY, sz = lay.StirZ;
            Vec3 P(double s, double y, double z) => a + ex * s + ey * y + ez * z;
            void Add(RebarRole role, int dia, bool closed, params Vec3[] pts)
            {
                var path = new RebarPath { MemberId = r.MemberId, Role = role, DiaMm = dia, Closed = closed, Pts = pts };
                path.LengthM = Len(pts, closed);
                res.Add(path);
            }

            if (!isCol)
            {
                foreach (var (y, z) in lay.Bottom)
                    Add(RebarRole.Bottom, r.BotDia, false, P(0.03, y, z), P(L - 0.03, y, z));
                if (r.TopN > 0)
                {
                    double lh = Math.Min(cfg.BeamTopBarFactor * L + 0.30, L - 0.06);
                    foreach (var (y, z) in lay.Top)
                    {
                        if (r.Cantilever) { Add(RebarRole.Top, r.TopDia, false, P(0.03, y, z), P(L - 0.03, y, z)); continue; }       // console : chapeaux sur toute la longueur
                        Add(RebarRole.Top, r.TopDia, false, P(0.03, y, z), P(0.03 + lh, y, z));
                        Add(RebarRole.Top, r.TopDia, false, P(L - 0.03 - lh, y, z), P(L - 0.03, y, z));
                    }
                }
                foreach (var (y, z) in lay.Mounting)
                    Add(RebarRole.Mounting, cfg.MountingBarDiaMm, false, P(0.03, y, z), P(L - 0.03, y, z));
                if (r.StirDia > 0)
                    foreach (double p in RcSheets.StirrupPositions(Math.Max(L - 0.30, 0.5), Math.Max(r.StirSpacingCm, 5) / 100.0, r.NodalZoneM, r.NodalSpacingCm / 100.0))
                    {
                        double s = 0.15 + p;
                        Add(RebarRole.Stirrup, r.StirDia, true, P(s, -sy, -sz), P(s, sy, -sz), P(s, sy, sz), P(s, -sy, sz));
                    }
            }
            else
            {
                foreach (var (by, bz) in lay.Column)
                    Add(RebarRole.ColumnBar, r.BotDia, false, P(0.02, by, bz), P(L - 0.02, by, bz));
                if (r.StirDia > 0)
                {
                    foreach (double p in RcSheets.StirrupPositions(L, Math.Max(r.StirSpacingCm, 5) / 100.0, r.NodalZoneM, r.NodalSpacingCm / 100.0))
                    {
                        Add(RebarRole.Stirrup, r.StirDia, true, P(p, -sy, -sz), P(p, sy, -sz), P(p, sy, sz), P(p, -sy, sz));
                        foreach (double y in lay.TiesY) Add(RebarRole.Tie, r.StirDia, false, P(p, y, -sz), P(p, y, sz));
                        foreach (double z in lay.TiesZ) Add(RebarRole.Tie, r.StirDia, false, P(p, -sy, z), P(p, sy, z));
                    }
                }
            }
        }
        AddSlabBars(m, o, res);
        AddFootingBars(m, o, res);
        AddStripBars(m, o, res);
        AddRaftBars(m, o, res);
        AddWallBars(m, o, res);
        return res;
    }

    private static readonly System.Text.RegularExpressions.Regex BarRx = new(@"HA\s*(\d+)\s*e\s*=\s*(\d+(?:[.,]\d+)?)", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

    /// <summary>Lit « HA10 e=15 cm (...) » : diamètre (mm) et espacement (m).</summary>
    private static bool ParseBars(string? txt, out int dia, out double sp)
    {
        dia = 0; sp = 0;
        var mt = BarRx.Match(txt ?? "");
        if (!mt.Success) return false;
        dia = int.Parse(mt.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
        sp = double.Parse(mt.Groups[2].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture) / 100.0;
        return dia > 0 && sp >= 0.04;
    }

    /// <summary>Barres parallèles à X (ou à Y) de a à b, réparties tous les sp entre c0 et c1 dans l'autre direction (au plus 250 barres).</summary>
    private static void Layer(List<RebarPath> res, RebarRole role, int dia, bool alongX, double a, double b, double c0, double c1, double sp, double z)
    {
        if (b - a < 0.05 || c1 - c0 < 0) return;
        int n = (int)Math.Floor((c1 - c0) / sp + 1e-6) + 1;
        if (n > 250) { n = 250; sp = (c1 - c0) / 249.0; }
        double off = n > 1 ? ((c1 - c0) - (n - 1) * sp) / 2 : (c1 - c0) / 2;
        for (int i = 0; i < n; i++)
        {
            double c = c0 + off + i * sp;
            var pts = alongX ? new[] { new Vec3(a, c, z), new Vec3(b, c, z) } : new[] { new Vec3(c, a, z), new Vec3(c, b, z) };
            res.Add(new RebarPath { MemberId = -1, Role = role, DiaMm = dia, Pts = pts, LengthM = b - a });
        }
    }

    /// <summary>Armatures des dalles : nappe inférieure dans les deux sens sur le panneau, chapeaux sur appuis (0,25 x portée depuis chaque rive) ; mêmes valeurs que les plans et que Revit.</summary>
    private static void AddSlabBars(StructModel m, AnalysisOutput o, List<RebarPath> res)
    {
        foreach (var s in m.Slabs.Where(q => q.Placed))
        {
            var d = o.Slabs.FirstOrDefault(x => x.Element.StartsWith($"Dalle {s.Name} ("));
            if (d == null) continue;
            double cov = (s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm) / 100.0;
            double x0 = s.X0 + cov, x1 = s.X0 + s.Lx - cov, y0 = s.Y0 + cov, y1 = s.Y0 + s.Ly - cov;
            double zb = s.Z - s.H + cov, zt = s.Z - cov;
            bool sw = s.Lx > s.Ly;      // « sens lx » du calcul = portée la plus courte : si elle est suivant Y, ces barres courent suivant Y
            bool tx = ParseBars(d.Texts.GetValueOrDefault(sw ? "Travée sens ly" : "Travée sens lx"), out int dTx, out double sTx);
            bool ty = ParseBars(d.Texts.GetValueOrDefault(sw ? "Travée sens lx" : "Travée sens ly"), out int dTy, out double sTy);
            bool ax = ParseBars(d.Texts.GetValueOrDefault(sw ? "Appui sens ly" : "Appui sens lx"), out int dAx, out double sAx);
            bool ay = ParseBars(d.Texts.GetValueOrDefault(sw ? "Appui sens lx" : "Appui sens ly"), out int dAy, out double sAy);
            if (tx) Layer(res, RebarRole.Bottom, dTx, true, x0, x1, y0, y1, sTx, zb + dTx / 2000.0);
            if (ty) Layer(res, RebarRole.Bottom, dTy, false, y0, y1, x0, x1, sTy, zb + (tx ? dTx / 1000.0 : 0) + dTy / 2000.0);
            if (ax)
            {
                double band = 0.25 * s.Lx, z = zt - dAx / 2000.0;
                Layer(res, RebarRole.Top, dAx, true, x0, s.X0 + band, y0, y1, sAx, z);
                Layer(res, RebarRole.Top, dAx, true, s.X0 + s.Lx - band, x1, y0, y1, sAx, z);
            }
            if (ay)
            {
                double band = 0.25 * s.Ly, z = zt - (ax ? dAx / 1000.0 : 0) - dAy / 2000.0;
                Layer(res, RebarRole.Top, dAy, false, y0, s.Y0 + band, x0, x1, sAy, z);
                Layer(res, RebarRole.Top, dAy, false, s.Y0 + s.Ly - band, y1, x0, x1, sAy, z);
            }
        }
    }

    /// <summary>Armatures des semelles isolées : deux nappes inférieures croisées (// A le long de X, // B le long de Y).</summary>
    private static void AddFootingBars(StructModel m, AnalysisOutput o, List<RebarPath> res)
    {
        foreach (var pf in FootingPlacement.From(m, o))
        {
            var f = o.Footings.FirstOrDefault(x => FootingPlacement.NodeIdOf(x.Element) == pf.NodeId);
            if (f == null) continue;
            bool okA = ParseBars(f.Texts.GetValueOrDefault("Nappe // A"), out int dA, out double sA);
            bool okB = ParseBars(f.Texts.GetValueOrDefault("Nappe // B"), out int dB, out double sB);
            if (!okA && !okB) continue;
            var (ox, oy) = FootingSolids.Shift(pf.A, pf.B, pf.ColA, pf.ColB, pf.Glacis, m.FootingAlignX, m.FootingAlignY);
            double cv = m.Settings.CoverFootingCm / 100.0;
            double x0 = pf.X + ox - pf.A / 2 + cv, x1 = pf.X + ox + pf.A / 2 - cv, y0 = pf.Y + oy - pf.B / 2 + cv, y1 = pf.Y + oy + pf.B / 2 - cv;
            double zb = pf.ZTop - pf.H + cv;
            bool aLower = (x1 - x0) >= (y1 - y0);
            double zA = zb + (okA ? dA / 2000.0 : 0) + (!aLower && okB ? dB / 1000.0 : 0);
            double zB = zb + (okB ? dB / 2000.0 : 0) + (aLower && okA ? dA / 1000.0 : 0);
            if (okA) Layer(res, RebarRole.Bottom, dA, true, x0, x1, y0, y1, sA, zA);
            if (okB) Layer(res, RebarRole.Bottom, dB, false, y0, y1, x0, x1, sB, zB);
        }
    }

    /// <summary>Armatures des semelles filantes posées : transversales (// largeur) tous les e, barres de répartition longitudinales.</summary>
    private static void AddStripBars(StructModel m, AnalysisOutput o, List<RebarPath> res)
    {
        foreach (var fd in m.FootingDefs.Where(f => f.Kind == FootingKind.Filante && f.LengthM > 0.5))
        {
            var x = o.Extras.FirstOrDefault(e => e.Data.GetValueOrDefault("Name") == fd.Name && e.Data.GetValueOrDefault("Strip") == "1");
            if (x == null) continue;
            bool okA = ParseBars(x.Data.GetValueOrDefault("NappeA"), out int dA, out double sA), okB = ParseBars(x.Data.GetValueOrDefault("NappeB"), out int dB, out double sB);
            double cv = m.Settings.CoverFootingCm / 100.0, A = fd.FixedA > 0 ? fd.FixedA : 0.8, h = fd.ThicknessM > 0 ? fd.ThicknessM : 0.4;
            double ca = Math.Cos(fd.AngleDeg * Math.PI / 180), sa = Math.Sin(fd.AngleDeg * Math.PI / 180);
            Vec3 P(double u, double v, double z) => new Vec3(fd.X0 + u * ca - v * sa, fd.Y0 + u * sa + v * ca, z);
            double zb = fd.ZTop - h + cv;
            if (okA)
            {
                int n = 0;
                for (double u = cv; u <= fd.LengthM - cv + 1e-6 && n < 250; u += sA, n++)
                    res.Add(new RebarPath { MemberId = -1, Role = RebarRole.Bottom, DiaMm = dA, Pts = new[] { P(u, -A / 2 + cv, zb + dA / 2000.0), P(u, A / 2 - cv, zb + dA / 2000.0) }, LengthM = A - 2 * cv });
            }
            if (okB)
            {
                int cnt = Math.Max(2, (int)Math.Floor((A - 2 * cv) / sB) + 1);
                for (int i = 0; i < cnt && i < 60; i++)
                {
                    double v = -A / 2 + cv + (cnt > 1 ? (A - 2 * cv) * i / (cnt - 1) : 0), z = zb + (okA ? dA / 1000.0 : 0) + dB / 2000.0;
                    res.Add(new RebarPath { MemberId = -1, Role = RebarRole.Bottom, DiaMm = dB, Pts = new[] { P(cv, v, z), P(fd.LengthM - cv, v, z) }, LengthM = fd.LengthM - 2 * cv });
                }
            }
        }
    }

    /// <summary>Armatures des radiers : nappes inférieure et supérieure dans les deux sens, sur chaque rectangle du radier.</summary>
    private static void AddRaftBars(StructModel m, AnalysisOutput o, List<RebarPath> res)
    {
        foreach (var rf in m.Rafts)
        {
            var rr = o.Rafts.FirstOrDefault(q => q.Def.Name == rf.Name);
            if (rr == null) continue;
            double cov = rf.CoverCm / 100.0;
            bool iX = ParseBars(rr.Design.Texts.GetValueOrDefault("Inf X"), out int dIX, out double sIX), iY = ParseBars(rr.Design.Texts.GetValueOrDefault("Inf Y"), out int dIY, out double sIY);
            bool sX = ParseBars(rr.Design.Texts.GetValueOrDefault("Sup X"), out int dSX, out double sSX), sY = ParseBars(rr.Design.Texts.GetValueOrDefault("Sup Y"), out int dSY, out double sSY);
            foreach (var p in rf.Panels)
            {
                double x0 = p.X0 + cov, x1 = p.X0 + p.Lx - cov, y0 = p.Y0 + cov, y1 = p.Y0 + p.Ly - cov;
                double zb = rf.ZTop - rf.H + cov, zt = rf.ZTop - cov;
                if (iX) Layer(res, RebarRole.Bottom, dIX, true, x0, x1, y0, y1, sIX, zb + dIX / 2000.0);
                if (iY) Layer(res, RebarRole.Bottom, dIY, false, y0, y1, x0, x1, sIY, zb + (iX ? dIX / 1000.0 : 0) + dIY / 2000.0);
                if (sX) Layer(res, RebarRole.Top, dSX, true, x0, x1, y0, y1, sSX, zt - dSX / 2000.0);
                if (sY) Layer(res, RebarRole.Top, dSY, false, y0, y1, x0, x1, sSY, zt - (sX ? dSX / 1000.0 : 0) - dSY / 2000.0);
            }
        }
    }

    /// <summary>Armatures des voiles : barres verticales et horizontales sur chaque face, interrompues par les ouvertures (élévation découpée en rectangles).</summary>
    private static void AddWallBars(StructModel m, AnalysisOutput o, List<RebarPath> res)
    {
        foreach (var wr in o.Walls)
        {
            var w = wr.Def;
            bool okV = ParseBars(wr.GeneralV, out int dV, out double sV), okH = ParseBars(wr.GeneralH, out int dH, out double sH);
            if (!okV && !okH) continue;
            double ca = Math.Cos(w.AngleDeg * Math.PI / 180), sa = Math.Sin(w.AngleDeg * Math.PI / 180), cov = w.CoverCm / 100.0;
            var outer = new List<(double X, double Y)> { (0, 0), (w.LengthM, 0), (w.LengthM, w.HeightM), (0, w.HeightM) };
            var loops = new List<IList<(double X, double Y)>> { outer };
            foreach (var op in w.Openings)
                loops.Add(new List<(double X, double Y)> { (op.XM, op.ZM), (op.XM + op.WidthM, op.ZM), (op.XM + op.WidthM, op.ZM + op.HeightM), (op.XM, op.ZM + op.HeightM) });
            var rects = RectDecomposer.Decompose(loops, 0.02, 0.15);
            double off = w.ThicknessM / 2 - cov;
            Vec3 P(double u, double z, double face) => new Vec3(w.X + u * ca - face * sa, w.Y + u * sa + face * ca, w.Z + z);
            foreach (double face in new[] { -off, off })
                foreach (var r in rects)
                {
                    int guard = 0;
                    if (okV)
                        for (double u = r.X0 + cov; u <= r.X1 - cov + 1e-6 && guard < 250; u += sV, guard++)
                            res.Add(new RebarPath { MemberId = -1, Role = RebarRole.ColumnBar, DiaMm = dV, Pts = new[] { P(u, r.Y0 + cov, face), P(u, r.Y1 - cov, face) }, LengthM = r.H - 2 * cov });
                    guard = 0;
                    if (okH)
                        for (double z = r.Y0 + cov; z <= r.Y1 - cov + 1e-6 && guard < 250; z += sH, guard++)
                            res.Add(new RebarPath { MemberId = -1, Role = RebarRole.Mounting, DiaMm = dH, Pts = new[] { P(r.X0 + cov, z, face), P(r.X1 - cov, z, face) }, LengthM = r.W - 2 * cov });
                }
        }
    }

    /// <summary>Masse d'acier (kg) de toutes les armatures modélisées (7850 kg/m³).</summary>
    public static double MassKg(IEnumerable<RebarPath> bars) =>
        bars.Sum(p => p.LengthM * Math.PI * (p.DiaMm / 1000.0) * (p.DiaMm / 1000.0) / 4 * 7850);
}
