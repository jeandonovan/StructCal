namespace StructCalc.Engine.Geometry;

/// <summary>Découpe une surface plane (contour extérieur + trous, polylignes) en rectangles alignés sur les axes.
/// Sert à reprendre dans StructCalc, sans l'approcher par un rectangle englobant, une dalle Revit de forme quelconque ou percée de trémies :
/// chaque rectangle devient un panneau de dalle, les trémies restent vides. Les bords obliques sont suivis en escalier.</summary>
public static class RectDecomposer
{
    public readonly record struct Rect(double X0, double Y0, double X1, double Y1)
    {
        public double W => X1 - X0;
        public double H => Y1 - Y0;
        public double Area => W * H;
    }

    private static List<double> Cluster(IEnumerable<double> vals, double tol)
    {
        var res = new List<double>();
        foreach (double v in vals.OrderBy(x => x))
            if (res.Count == 0 || v - res[^1] > tol) res.Add(v);
        return res;
    }

    private static bool Inside(IList<(double X, double Y)> poly, double x, double y)
    {
        bool c = false;
        for (int i = 0, j = poly.Count - 1; i < poly.Count; j = i++)
        {
            var (xi, yi) = poly[i]; var (xj, yj) = poly[j];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
        }
        return c;
    }

    /// <param name="loops">tous les contours (extérieur et trous) : un point est dans la surface s'il est dans un nombre impair de contours.</param>
    /// <param name="tol">tolérance de regroupement des coordonnées (m).</param>
    /// <param name="minSide">les rectangles dont un côté est plus petit sont ignorés (m).</param>
    public static List<Rect> Decompose(IList<IList<(double X, double Y)>> loops, double tol = 0.02, double minSide = 0.30)
    {
        var res = new List<Rect>();
        var all = loops.Where(l => l.Count >= 3).ToList();
        if (all.Count == 0) return res;
        var xs = Cluster(all.SelectMany(l => l.Select(p => p.X)), tol);
        var ys = Cluster(all.SelectMany(l => l.Select(p => p.Y)), tol);
        if (xs.Count < 2 || ys.Count < 2) return res;
        if ((long)xs.Count * ys.Count > 90000) return res;
        int nx = xs.Count - 1, ny = ys.Count - 1;
        var inside = new bool[nx, ny];
        for (int i = 0; i < nx; i++)
            for (int j = 0; j < ny; j++)
            {
                double cx = (xs[i] + xs[i + 1]) / 2, cy = (ys[j] + ys[j + 1]) / 2;
                int n = 0;
                foreach (var l in all) if (Inside(l, cx, cy)) n++;
                inside[i, j] = (n & 1) == 1;
            }
        var done = new bool[nx, ny];
        for (int j = 0; j < ny; j++)
            for (int i = 0; i < nx; i++)
            {
                if (!inside[i, j] || done[i, j]) continue;
                int i2 = i;
                while (i2 + 1 < nx && inside[i2 + 1, j] && !done[i2 + 1, j]) i2++;
                int j2 = j;
                while (j2 + 1 < ny)
                {
                    bool ok = true;
                    for (int k = i; k <= i2 && ok; k++) ok = inside[k, j2 + 1] && !done[k, j2 + 1];
                    if (!ok) break;
                    j2++;
                }
                for (int a = i; a <= i2; a++) for (int b = j; b <= j2; b++) done[a, b] = true;
                var r = new Rect(Math.Round(xs[i], 3), Math.Round(ys[j], 3), Math.Round(xs[i2 + 1], 3), Math.Round(ys[j2 + 1], 3));
                if (r.W >= minSide && r.H >= minSide) res.Add(r);
            }
        return res;
    }
}
