using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine.Geometry;

public readonly struct Vec3
{
    public readonly double X, Y, Z;
    public Vec3(double x, double y, double z) { X = x; Y = y; Z = z; }
    public static Vec3 operator +(Vec3 a, Vec3 b) => new(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
    public static Vec3 operator -(Vec3 a, Vec3 b) => new(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
    public static Vec3 operator *(Vec3 a, double k) => new(a.X * k, a.Y * k, a.Z * k);
    public double Dot(Vec3 b) => X * b.X + Y * b.Y + Z * b.Z;
    public Vec3 Cross(Vec3 b) => new(Y * b.Z - Z * b.Y, Z * b.X - X * b.Z, X * b.Y - Y * b.X);
    public double Length => Math.Sqrt(X * X + Y * Y + Z * Z);
    public Vec3 Unit() { double l = Length; return l < 1e-12 ? new Vec3(0, 0, 1) : new Vec3(X / l, Y / l, Z / l); }
}

/// <summary>Facette plane d'un solide de barre. <c>EdgeMask</c> : bit i = l'arête P[i] -> P[i+1] est une arête « franche » à tracer.</summary>
public sealed class Face
{
    public Vec3[] P { get; set; } = Array.Empty<Vec3>();
    public Vec3 N { get; set; }
    public int MemberId { get; set; }
    public int EdgeMask { get; set; }
    public bool Cap { get; set; }
}

/// <summary>Construit les solides des barres : prisme rectangulaire pour le béton armé, profilé en I pour l'acier.
/// Repère local : x le long de la barre ; pour un poteau vertical y = X global, z = Y global ; sinon z = « vers le haut ».</summary>
public static class MemberSolids
{
    public static (Vec3 Ex, Vec3 Ey, Vec3 Ez) Frame(Vec3 a, Vec3 b, double rollDeg = 0)
    {
        var (ex, ey, ez) = FrameBase(a, b);
        if (Math.Abs(rollDeg) < 1e-9) return (ex, ey, ez);
        double c = Math.Cos(rollDeg * Math.PI / 180), s = Math.Sin(rollDeg * Math.PI / 180);
        return (ex, ey * c + ez * s, ey * (-s) + ez * c);
    }

    private static (Vec3 Ex, Vec3 Ey, Vec3 Ez) FrameBase(Vec3 a, Vec3 b)
    {
        var ex = (b - a).Unit();
        if (Math.Abs(ex.Z) > 0.999)
        {
            var ey = new Vec3(1, 0, 0);
            return (ex, ey, ex.Cross(ey));
        }
        var up = new Vec3(0, 0, 1);
        var ez = (up - ex * up.Dot(ex)).Unit();
        return (ex, ez.Cross(ex), ez);
    }

    /// <summary>Contour de la section (y, z) en mètres, orienté dans le sens trigonométrique.</summary>
    public static List<(double Y, double Z)> Outline(Member mem)
    {
        var pts = new List<(double, double)>();
        SteelProfile? prof = null;
        if (mem.Kind == MaterialKind.Steel && !string.IsNullOrWhiteSpace(mem.Profile)) SteelCatalog.TryGet(mem.Profile, out prof);
        if (prof != null)
        {
            double bf = prof.B / 2000.0, hh = prof.H / 2000.0, tw = prof.Tw / 2000.0, zi = hh - prof.Tf / 1000.0;
            pts.AddRange(new[]
            {
                (-bf, -hh), (bf, -hh), (bf, -zi), (tw, -zi), (tw, zi), (bf, zi),
                (bf, hh), (-bf, hh), (-bf, zi), (-tw, zi), (-tw, -zi), (-bf, -zi)
            });
        }
        else
        {
            double b = Math.Max(mem.B, 0.05) / 2, h = Math.Max(mem.H, 0.05) / 2;
            pts.AddRange(new[] { (-b, -h), (b, -h), (b, h), (-b, h) });
        }
        double area = 0;
        for (int i = 0; i < pts.Count; i++) { var p = pts[i]; var q = pts[(i + 1) % pts.Count]; area += p.Item1 * q.Item2 - q.Item1 * p.Item2; }
        if (area < 0) pts.Reverse();
        return pts;
    }

    public static int SegmentsFor(double length, bool steel, bool subdivide)
    {
        if (!subdivide) return 1;
        return steel ? Math.Clamp((int)Math.Ceiling(length / 1.5), 1, 8) : Math.Clamp((int)Math.Ceiling(length / 0.9), 1, 12);
    }

    public static List<Face> BuildMember(Member mem, Node na, Node nb, bool subdivide)
    {
        var faces = new List<Face>();
        var a = new Vec3(na.X, na.Y, na.Z); var b = new Vec3(nb.X, nb.Y, nb.Z);
        double L = (b - a).Length;
        if (L < 1e-6) return faces;
        var (ex, ey, ez) = Frame(a, b, mem.Roll);
        var outline = Outline(mem);
        int n = outline.Count;
        int seg = SegmentsFor(L, mem.Kind == MaterialKind.Steel, subdivide);

        Vec3 At(double s, int i) => a + ex * (L * s) + ey * outline[i].Y + ez * outline[i].Z;

        for (int i = 0; i < n; i++)
        {
            var p = outline[i]; var q = outline[(i + 1) % n];
            double dy = q.Y - p.Y, dz = q.Z - p.Z, len = Math.Sqrt(dy * dy + dz * dz);
            if (len < 1e-9) continue;
            var normal = (ey * (dz / len) + ez * (-dy / len)).Unit();    // normale sortante (contour trigonométrique)
            for (int k = 0; k < seg; k++)
            {
                double s0 = (double)k / seg, s1 = (double)(k + 1) / seg;
                faces.Add(new Face
                {
                    P = new[] { At(s0, i), At(s0, (i + 1) % n), At(s1, (i + 1) % n), At(s1, i) },
                    N = normal, MemberId = mem.Id, EdgeMask = 0b1010
                });
            }
        }
        int fullMask = (1 << n) - 1;
        faces.Add(new Face { P = Enumerable.Range(0, n).Select(i => At(0, i)).ToArray(), N = ex * -1.0, MemberId = mem.Id, EdgeMask = fullMask, Cap = true });
        faces.Add(new Face { P = Enumerable.Range(0, n).Select(i => At(1, i)).ToArray(), N = ex, MemberId = mem.Id, EdgeMask = fullMask, Cap = true });
        return faces;
    }

    public static List<Face> Build(StructModel m, bool subdivide = true)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var res = new List<Face>();
        foreach (var mem in m.Members)
            if (nodes.TryGetValue(mem.NodeI, out var na) && nodes.TryGetValue(mem.NodeJ, out var nb))
                res.AddRange(BuildMember(mem, na, nb, subdivide));
        return res;
    }

    public static (Vec3 Min, Vec3 Max) Bounds(IEnumerable<Face> faces)
    {
        double x0 = double.MaxValue, y0 = double.MaxValue, z0 = double.MaxValue, x1 = double.MinValue, y1 = double.MinValue, z1 = double.MinValue;
        foreach (var f in faces)
            foreach (var p in f.P)
            {
                x0 = Math.Min(x0, p.X); y0 = Math.Min(y0, p.Y); z0 = Math.Min(z0, p.Z);
                x1 = Math.Max(x1, p.X); y1 = Math.Max(y1, p.Y); z1 = Math.Max(z1, p.Z);
            }
        return (new Vec3(x0, y0, z0), new Vec3(x1, y1, z1));
    }
}
