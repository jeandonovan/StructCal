using StructCalc.Core.Model;

namespace StructCalc.Engine.Geometry;

/// <summary>Placement, calage d'échelle, déplacement et alignement d'un fond de plan. Les coordonnées « source » sont celles du DXF, ou
/// (pixel x, hauteur − pixel y) pour un PDF / une image (axe y vers le haut).</summary>
public static class UnderlayMath
{
    public static (double X, double Y) ToModel(UnderlayDef u, double sx, double sy)
    {
        double a = u.Rotation * Math.PI / 180, c = Math.Cos(a), s = Math.Sin(a);
        double x = sx * u.Scale, y = sy * u.Scale;
        return (u.OriginX + x * c - y * s, u.OriginY + x * s + y * c);
    }

    public static (double X, double Y) FromModel(UnderlayDef u, double mx, double my)
    {
        double a = u.Rotation * Math.PI / 180, c = Math.Cos(a), s = Math.Sin(a);
        double dx = mx - u.OriginX, dy = my - u.OriginY;
        double x = dx * c + dy * s, y = -dx * s + dy * c;
        return (x / u.Scale, y / u.Scale);
    }

    /// <summary>Met à l'échelle pour que la distance mesurée entre deux points (coordonnées modèle) devienne realMeters. Le premier point reste fixe.</summary>
    public static bool Calibrate(UnderlayDef u, (double X, double Y) p1, (double X, double Y) p2, double realMeters)
    {
        double d = Math.Sqrt((p2.X - p1.X) * (p2.X - p1.X) + (p2.Y - p1.Y) * (p2.Y - p1.Y));
        if (d < 1e-9 || realMeters <= 0) return false;
        double f = realMeters / d;
        u.Scale *= f;
        u.OriginX = p1.X + f * (u.OriginX - p1.X);
        u.OriginY = p1.Y + f * (u.OriginY - p1.Y);
        return true;
    }

    public static void Translate(UnderlayDef u, double dx, double dy) { u.OriginX += dx; u.OriginY += dy; }

    /// <summary>Tourne le fond autour de p1 pour que la droite p1→p2 devienne horizontale (ou verticale si vertical = true).</summary>
    public static bool Align(UnderlayDef u, (double X, double Y) p1, (double X, double Y) p2, bool vertical = false)
    {
        double dx = p2.X - p1.X, dy = p2.Y - p1.Y;
        if (Math.Sqrt(dx * dx + dy * dy) < 1e-9) return false;
        double target = vertical ? Math.PI / 2 : 0;
        double delta = target - Math.Atan2(dy, dx);
        // normalisation : toujours la plus petite rotation
        while (delta > Math.PI / 2) delta -= Math.PI;
        while (delta < -Math.PI / 2) delta += Math.PI;
        double c = Math.Cos(delta), s = Math.Sin(delta);
        double ox = u.OriginX - p1.X, oy = u.OriginY - p1.Y;
        u.OriginX = p1.X + ox * c - oy * s;
        u.OriginY = p1.Y + ox * s + oy * c;
        u.Rotation += delta * 180 / Math.PI;
        return true;
    }

    /// <summary>Déplace le fond pour que le point source « from » (modèle) coïncide avec « to » (modèle).</summary>
    public static void MoveTo(UnderlayDef u, (double X, double Y) from, (double X, double Y) to) => Translate(u, to.X - from.X, to.Y - from.Y);

    /// <summary>PDF imprimé à l'échelle 1/denominator : mètres par pixel d'après la largeur de feuille (mm).</summary>
    public static double PdfScale(double pageWidthMm, int pixelWidth, double denominator)
        => pixelWidth <= 0 ? 1 : pageWidthMm / 1000.0 * denominator / pixelWidth;

    /// <summary>Échelle initiale d'un DXF : $INSUNITS si connu, sinon déduite de l'étendue (grand nombre = millimètres).</summary>
    public static double DxfInitialScale(DxfDrawing d)
    {
        if (d.MetersPerUnit > 0) return d.MetersPerUnit;
        double w = Math.Max(d.MaxX - d.MinX, d.MaxY - d.MinY);
        if (w > 2000) return 0.001;
        if (w > 200 && w <= 2000) return 0.01;
        return 1.0;
    }
}
