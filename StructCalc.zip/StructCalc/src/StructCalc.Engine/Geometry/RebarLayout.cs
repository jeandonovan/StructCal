using StructCalc.Core;
using StructCalc.Engine.Drawing;

namespace StructCalc.Engine.Geometry;

/// <summary>Disposition des armatures dans une section (une seule règle pour les plans d'exécution, la fiche de l'élément et le ferraillage 3D).
/// Repère de la section : Y = largeur (de -b/2 à +b/2), Z = hauteur (vers le haut, de -h/2 à +h/2). Positions = axes des barres.</summary>
public sealed class SectionLayout
{
    public bool IsColumn { get; init; }
    public double B { get; init; }
    public double H { get; init; }
    /// <summary>Demi-largeur / demi-hauteur du lit d'armatures (axe des barres d'angle).</summary>
    public double YB { get; init; }
    public double ZB { get; init; }
    /// <summary>Demi-dimensions de l'axe des cadres.</summary>
    public double StirY { get; init; }
    public double StirZ { get; init; }
    public List<(double Y, double Z)> Bottom { get; } = new();      // poutre : lit inférieur
    public List<(double Y, double Z)> Top { get; } = new();         // poutre : chapeaux (entre les barres de montage)
    public List<(double Y, double Z)> Mounting { get; } = new();    // poutre : barres de montage (angles supérieurs)
    public List<(double Y, double Z)> Column { get; } = new();      // poteau : toutes les barres longitudinales
    public List<double> TiesY { get; } = new();                     // poteau : épingles verticales (position en Y)
    public List<double> TiesZ { get; } = new();                     // poteau : épingles horizontales (position en Z)
}

public static class RebarLayout
{
    public static SectionLayout Of(bool column, double b, double h, double cover, int botN, int botDia, int topN, int stirDia)
    {
        double yb = Math.Max(b / 2 - cover, 0.02), zb = Math.Max(h / 2 - cover, 0.02);
        double inset = Math.Max(cover - botDia / 2000.0, 0.02);
        var L = new SectionLayout { IsColumn = column, B = b, H = h, YB = yb, ZB = zb, StirY = b / 2 - inset, StirZ = h / 2 - inset };
        if (!column)
        {
            for (int i = 0; i < botN; i++) L.Bottom.Add((botN == 1 ? 0 : -yb + 2 * yb * i / (botN - 1), -zb));
            L.Mounting.Add((-yb, zb)); L.Mounting.Add((yb, zb));
            for (int i = 1; i <= topN; i++) L.Top.Add((-yb + 2 * yb * i / (topN + 1), zb));
        }
        else
        {
            var (t, sd) = RcSheets.ColumnTies(botN, b, h);
            L.Column.Add((-yb, -zb)); L.Column.Add((yb, -zb)); L.Column.Add((yb, zb)); L.Column.Add((-yb, zb));
            for (int i = 1; i <= t; i++) { double y = -yb + 2 * yb * i / (t + 1); L.Column.Add((y, -zb)); L.Column.Add((y, zb)); L.TiesY.Add(y); }
            for (int i = 1; i <= sd; i++) { double z = -zb + 2 * zb * i / (sd + 1); L.Column.Add((-yb, z)); L.Column.Add((yb, z)); L.TiesZ.Add(z); }
        }
        return L;
    }
}
