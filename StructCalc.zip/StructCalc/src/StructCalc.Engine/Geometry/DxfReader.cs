using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace StructCalc.Engine.Geometry;

public sealed class DxfLayer
{
    public string Name { get; set; } = "0";
    public int Color { get; set; } = 7;             // indice AutoCAD (ACI)
    public bool Off { get; set; }                   // gelé ou éteint
    public int Count { get; set; }                  // nombre de segments
}

public sealed class DxfSegment
{
    public double X1, Y1, X2, Y2;
    public int Layer;                                // indice dans DxfDrawing.Layers
    public int Rgb;                                  // 0xRRGGBB
    public bool Curve;                               // fragment d'arc / cercle / spline (pas d'accrochage sur ses sommets intermédiaires)
}

public sealed class DxfText
{
    public double X, Y, Height, Rotation;
    public string Text = "";
    public int Layer;
}

public sealed class DxfDrawing
{
    public List<DxfLayer> Layers { get; } = new();
    public List<DxfSegment> Segments { get; } = new();
    public List<DxfText> Texts { get; } = new();
    public List<(double X, double Y)> Points { get; } = new();   // points remarquables : centres de cercles/arcs, extrémités d'arcs
    public int InsUnits { get; set; }                // $INSUNITS : 1 pouce, 4 mm, 5 cm, 6 m
    public double MinX, MinY, MaxX, MaxY;
    public bool IsEmpty => Segments.Count == 0;

    /// <summary>Mètres par unité de dessin d'après $INSUNITS (0 = inconnu → on suppose des mètres).</summary>
    public double MetersPerUnit => InsUnits switch { 1 => 0.0254, 2 => 0.3048, 4 => 0.001, 5 => 0.01, 6 => 1.0, 14 => 0.1, _ => 0 };
}

/// <summary>Lecteur DXF ASCII (R12 à 2018) : LINE, LWPOLYLINE, POLYLINE, CIRCLE, ARC, ELLIPSE, SPLINE (approchée), SOLID, 3DFACE,
/// INSERT (blocs imbriqués), DIMENSION (bloc anonyme), TEXT, MTEXT. Tout est converti en segments 2D (plan XY) pour l'affichage et l'accrochage.</summary>
public static class DxfReader
{
    private readonly record struct Pair(int Code, string Value);

    private sealed class Ent
    {
        public string Type = "";
        public List<Pair> Data = new();
        public List<Ent> Vertices = new();           // POLYLINE
    }

    private readonly record struct Mat(double A, double B, double C, double D, double Tx, double Ty)
    {
        public static Mat Identity => new(1, 0, 0, 1, 0, 0);
        public (double X, double Y) Apply(double x, double y) => (A * x + C * y + Tx, B * x + D * y + Ty);
        /// <summary>this puis other.</summary>
        public Mat Then(Mat o) => new(o.A * A + o.C * B, o.B * A + o.D * B, o.A * C + o.C * D, o.B * C + o.D * D,
                                      o.A * Tx + o.C * Ty + o.Tx, o.B * Tx + o.D * Ty + o.Ty);
    }

    private sealed class Ctx
    {
        public DxfDrawing Dr = new();
        public Dictionary<string, int> LayerIndex = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, List<Ent>> Blocks = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, (double X, double Y)> BlockBase = new(StringComparer.OrdinalIgnoreCase);
        public int MaxSegments = 3_000_000;
    }

    public static DxfDrawing Read(string path)
    {
        byte[] bytes = File.ReadAllBytes(path);
        string text = Encoding.UTF8.GetString(bytes);
        if (text.Contains('�')) text = Encoding.Latin1.GetString(bytes);
        return Parse(text);
    }

    public static DxfDrawing Parse(string text)
    {
        var lines = text.Split('\n');
        var pairs = new List<Pair>(lines.Length / 2);
        for (int i = 0; i + 1 < lines.Length; i += 2)
        {
            if (!int.TryParse(lines[i].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int code)) { i--; continue; }
            pairs.Add(new Pair(code, lines[i + 1].TrimEnd('\r')));
        }
        var ctx = new Ctx();
        var topEntities = new List<Ent>();

        int p = 0;
        while (p < pairs.Count)
        {
            if (pairs[p].Code == 0 && pairs[p].Value.Trim() == "SECTION" && p + 1 < pairs.Count && pairs[p + 1].Code == 2)
            {
                string sec = pairs[p + 1].Value.Trim();
                p += 2;
                int start = p;
                while (p < pairs.Count && !(pairs[p].Code == 0 && pairs[p].Value.Trim() == "ENDSEC")) p++;
                var slice = pairs.GetRange(start, p - start);
                switch (sec)
                {
                    case "HEADER": ReadHeader(slice, ctx); break;
                    case "TABLES": ReadTables(slice, ctx); break;
                    case "BLOCKS": ReadBlocks(slice, ctx); break;
                    case "ENTITIES": topEntities = ReadEntities(slice, 0); break;
                }
            }
            p++;
        }
        if (ctx.Dr.Layers.Count == 0) LayerOf(ctx, "0");
        foreach (var e in topEntities) Emit(ctx, e, Mat.Identity, 0, -1, 7);

        var d = ctx.Dr;
        if (d.Segments.Count > 0)
        {
            d.MinX = d.Segments.Min(s => Math.Min(s.X1, s.X2)); d.MaxX = d.Segments.Max(s => Math.Max(s.X1, s.X2));
            d.MinY = d.Segments.Min(s => Math.Min(s.Y1, s.Y2)); d.MaxY = d.Segments.Max(s => Math.Max(s.Y1, s.Y2));
        }
        foreach (var s in d.Segments) d.Layers[s.Layer].Count++;
        return d;
    }

    // ------------------------------------------------------------------ sections
    private static void ReadHeader(List<Pair> sl, Ctx ctx)
    {
        for (int i = 0; i + 1 < sl.Count; i++)
            if (sl[i].Code == 9 && sl[i].Value.Trim() == "$INSUNITS" && sl[i + 1].Code == 70)
            {
                int.TryParse(sl[i + 1].Value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int units);
                ctx.Dr.InsUnits = units;
            }
    }

    private static void ReadTables(List<Pair> sl, Ctx ctx)
    {
        for (int i = 0; i < sl.Count; i++)
        {
            if (sl[i].Code != 0 || sl[i].Value.Trim() != "LAYER") continue;
            string name = "0"; int color = 7, flags = 0;
            int j = i + 1;
            for (; j < sl.Count && sl[j].Code != 0; j++)
            {
                if (sl[j].Code == 2) name = sl[j].Value.Trim();
                else if (sl[j].Code == 62) int.TryParse(sl[j].Value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out color);
                else if (sl[j].Code == 70) int.TryParse(sl[j].Value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out flags);
            }
            int idx = LayerOf(ctx, name);
            ctx.Dr.Layers[idx].Color = Math.Abs(color) == 0 ? 7 : Math.Abs(color);
            ctx.Dr.Layers[idx].Off = color < 0 || (flags & 1) != 0;
            i = j - 1;
        }
    }

    private static void ReadBlocks(List<Pair> sl, Ctx ctx)
    {
        int i = 0;
        while (i < sl.Count)
        {
            if (sl[i].Code == 0 && sl[i].Value.Trim() == "BLOCK")
            {
                string name = ""; double bx = 0, by = 0;
                int j = i + 1;
                for (; j < sl.Count && sl[j].Code != 0; j++)
                {
                    if (sl[j].Code == 2 && name == "") name = sl[j].Value.Trim();
                    else if (sl[j].Code == 10) bx = Num(sl[j].Value);
                    else if (sl[j].Code == 20) by = Num(sl[j].Value);
                }
                int k = j;
                while (k < sl.Count && !(sl[k].Code == 0 && sl[k].Value.Trim() == "ENDBLK")) k++;
                ctx.Blocks[name] = ReadEntities(sl.GetRange(j, k - j), 0);
                ctx.BlockBase[name] = (bx, by);
                i = k;
            }
            i++;
        }
    }

    private static List<Ent> ReadEntities(List<Pair> sl, int from)
    {
        var res = new List<Ent>();
        Ent? cur = null, poly = null;
        for (int i = from; i < sl.Count; i++)
        {
            if (sl[i].Code == 0)
            {
                string t = sl[i].Value.Trim();
                if (t == "VERTEX" && poly != null) { cur = new Ent { Type = t }; poly.Vertices.Add(cur); continue; }
                if (t == "SEQEND") { poly = null; cur = null; continue; }
                cur = new Ent { Type = t };
                res.Add(cur);
                if (t == "POLYLINE") poly = cur;
                continue;
            }
            cur?.Data.Add(sl[i]);
        }
        return res;
    }

    // ------------------------------------------------------------------ entités
    private static int LayerOf(Ctx ctx, string name)
    {
        if (ctx.LayerIndex.TryGetValue(name, out int i)) return i;
        ctx.Dr.Layers.Add(new DxfLayer { Name = name });
        ctx.LayerIndex[name] = ctx.Dr.Layers.Count - 1;
        return ctx.Dr.Layers.Count - 1;
    }

    private static double Num(string s) => double.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out double v) ? v : 0;
    private static double Get(Ent e, int code, double def = 0)
    {
        foreach (var p in e.Data) if (p.Code == code) return Num(p.Value);
        return def;
    }
    private static string GetS(Ent e, int code)
    {
        foreach (var p in e.Data) if (p.Code == code) return p.Value;
        return "";
    }

    private static void Emit(Ctx ctx, Ent e, Mat m, int depth, int parentLayer, int parentColor)
    {
        if (ctx.Dr.Segments.Count > ctx.MaxSegments || depth > 6) return;
        string ln = GetS(e, 8).Trim();
        int layer;
        if (ln == "" || (ln == "0" && parentLayer >= 0)) layer = parentLayer >= 0 ? parentLayer : LayerOf(ctx, "0");
        else layer = LayerOf(ctx, ln);
        int aci = e.Data.Any(q => q.Code == 62) ? (int)Get(e, 62, 256) : 256;
        int color = aci > 0 && aci < 256 ? aci : ctx.Dr.Layers[layer].Color;
        if (aci == 0) color = parentColor;
        if (ctx.Dr.Layers[layer].Off && depth == 0) return;

        void SegC(double x1, double y1, double x2, double y2, bool curve)
        {
            var a = m.Apply(x1, y1); var b = m.Apply(x2, y2);
            if (Math.Abs(a.X - b.X) + Math.Abs(a.Y - b.Y) < 1e-9) return;
            ctx.Dr.Segments.Add(new DxfSegment { X1 = a.X, Y1 = a.Y, X2 = b.X, Y2 = b.Y, Layer = layer, Rgb = AciToRgb(color), Curve = curve });
        }
        void Seg(double x1, double y1, double x2, double y2) => SegC(x1, y1, x2, y2, false);
        void Pt(double x, double y) { var q = m.Apply(x, y); ctx.Dr.Points.Add((q.X, q.Y)); }
        void Poly(List<(double X, double Y)> pts, bool closed, bool curve = false)
        {
            for (int i = 0; i + 1 < pts.Count; i++) SegC(pts[i].X, pts[i].Y, pts[i + 1].X, pts[i + 1].Y, curve);
            if (closed && pts.Count > 2) SegC(pts[^1].X, pts[^1].Y, pts[0].X, pts[0].Y, curve);
            if (curve && pts.Count > 1 && !closed) { Pt(pts[0].X, pts[0].Y); Pt(pts[^1].X, pts[^1].Y); }
        }

        switch (e.Type)
        {
            case "LINE":
                Seg(Get(e, 10), Get(e, 20), Get(e, 11), Get(e, 21));
                break;
            case "CIRCLE":
                Poly(Arc(Get(e, 10), Get(e, 20), Get(e, 40), 0, 2 * Math.PI, 7.5), false, true);
                Pt(Get(e, 10), Get(e, 20));
                break;
            case "ARC":
            {
                double a0 = Get(e, 50) * Math.PI / 180, a1 = Get(e, 51) * Math.PI / 180;
                while (a1 <= a0) a1 += 2 * Math.PI;
                Poly(Arc(Get(e, 10), Get(e, 20), Get(e, 40), a0, a1, 7.5), false, true);
                Pt(Get(e, 10), Get(e, 20));
                break;
            }
            case "ELLIPSE":
            {
                double cx = Get(e, 10), cy = Get(e, 20), mx = Get(e, 11), my = Get(e, 21), ratio = Get(e, 40, 1);
                double t0 = Get(e, 41, 0), t1 = Get(e, 42, 2 * Math.PI);
                while (t1 <= t0) t1 += 2 * Math.PI;
                int n = Math.Max(8, (int)Math.Ceiling((t1 - t0) / (Math.PI / 24)));
                var pts = new List<(double, double)>();
                for (int i = 0; i <= n; i++)
                {
                    double t = t0 + (t1 - t0) * i / n, c = Math.Cos(t), s = Math.Sin(t);
                    pts.Add((cx + mx * c - my * ratio * s, cy + my * c + mx * ratio * s));
                }
                Poly(pts, false, true);
                Pt(cx, cy);
                break;
            }
            case "LWPOLYLINE":
            {
                var v = new List<(double X, double Y, double B)>();
                foreach (var p in e.Data)
                {
                    if (p.Code == 10) v.Add((Num(p.Value), 0, 0));
                    else if (p.Code == 20 && v.Count > 0) v[^1] = (v[^1].X, Num(p.Value), v[^1].B);
                    else if (p.Code == 42 && v.Count > 0) v[^1] = (v[^1].X, v[^1].Y, Num(p.Value));
                }
                bool closed = ((int)Get(e, 70) & 1) != 0;
                PolyBulge(v, closed, SegC, Pt);
                break;
            }
            case "POLYLINE":
            {
                var v = e.Vertices.Where(q => ((int)Get(q, 70) & 16) == 0)    // on ignore les sommets de contrôle de courbe
                                  .Select(q => (Get(q, 10), Get(q, 20), Get(q, 42))).ToList();
                bool closed = ((int)Get(e, 70) & 1) != 0;
                PolyBulge(v, closed, SegC, Pt);
                break;
            }
            case "SPLINE":
            {
                var fit = new List<(double, double)>(); var ctl = new List<(double, double)>();
                double cx = 0; bool haveC = false; double fx = 0; bool haveF = false;
                foreach (var p in e.Data)
                {
                    if (p.Code == 10) { cx = Num(p.Value); haveC = true; }
                    else if (p.Code == 20 && haveC) { ctl.Add((cx, Num(p.Value))); haveC = false; }
                    else if (p.Code == 11) { fx = Num(p.Value); haveF = true; }
                    else if (p.Code == 21 && haveF) { fit.Add((fx, Num(p.Value))); haveF = false; }
                }
                Poly(fit.Count > 1 ? fit : ctl, ((int)Get(e, 70) & 1) != 0, true);
                break;
            }
            case "SOLID":
            case "TRACE":
            case "3DFACE":
            {
                var c = new List<(double, double)> { (Get(e, 10), Get(e, 20)), (Get(e, 11), Get(e, 21)), (Get(e, 13), Get(e, 23)), (Get(e, 12), Get(e, 22)) };
                Poly(c, true);
                break;
            }
            case "TEXT":
            case "MTEXT":
            {
                if (ctx.Dr.Texts.Count >= 6000) break;
                string t = CleanText(GetS(e, 1) + string.Concat(e.Data.Where(q => q.Code == 3).Select(q => q.Value)));
                if (t.Length == 0) break;
                var pt = m.Apply(Get(e, 10), Get(e, 20));
                double rot = Get(e, 50) + Math.Atan2(m.B, m.A) * 180 / Math.PI;
                if (e.Type == "MTEXT" && e.Data.Any(q => q.Code == 11)) rot = Math.Atan2(Get(e, 21), Get(e, 11)) * 180 / Math.PI;
                double h = Get(e, 40, 1) * Math.Sqrt(m.A * m.A + m.B * m.B);
                ctx.Dr.Texts.Add(new DxfText { X = pt.X, Y = pt.Y, Height = h, Rotation = rot, Text = t, Layer = layer });
                break;
            }
            case "INSERT":
            case "DIMENSION":
            {
                string bn = GetS(e, 2).Trim();
                if (!ctx.Blocks.TryGetValue(bn, out var ents)) break;
                var bb = ctx.BlockBase.TryGetValue(bn, out var b0) ? b0 : (0, 0);
                Mat child = Mat.Identity;
                if (e.Type == "INSERT")
                {
                    double sx = Get(e, 41, 1), sy = Get(e, 42, 1), rot = Get(e, 50) * Math.PI / 180, c = Math.Cos(rot), s = Math.Sin(rot);
                    double ix = Get(e, 10), iy = Get(e, 20);
                    // point bloc (x,y) -> (x-bx)*sx, (y-by)*sy -> rotation -> + insertion
                    var move = new Mat(1, 0, 0, 1, -bb.Item1, -bb.Item2);
                    var scale = new Mat(sx, 0, 0, sy, 0, 0);
                    var rotM = new Mat(c, s, -s, c, ix, iy);
                    child = move.Then(scale).Then(rotM);
                }
                var full = child.Then(m);
                foreach (var sub in ents) Emit(ctx, sub, full, depth + 1, layer, color);
                break;
            }
        }
    }

    private static void PolyBulge(List<(double X, double Y, double B)> v, bool closed, Action<double, double, double, double, bool> seg, Action<double, double> pt)
    {
        int n = v.Count;
        int last = closed ? n : n - 1;
        for (int i = 0; i < last; i++)
        {
            var a = v[i]; var b = v[(i + 1) % n];
            if (Math.Abs(a.B) < 1e-9) { seg(a.X, a.Y, b.X, b.Y, false); continue; }
            double dx = b.X - a.X, dy = b.Y - a.Y, c = Math.Sqrt(dx * dx + dy * dy);
            if (c < 1e-12) continue;
            pt(a.X, a.Y); pt(b.X, b.Y);
            double half = c / 2, apothem = half * (1 - a.B * a.B) / (2 * a.B);
            double cx = (a.X + b.X) / 2 + (-dy / c) * apothem, cy = (a.Y + b.Y) / 2 + (dx / c) * apothem;
            double r = Math.Sqrt(half * half + apothem * apothem);
            double a0 = Math.Atan2(a.Y - cy, a.X - cx), sweep = 4 * Math.Atan(a.B);
            int steps = Math.Max(2, (int)Math.Ceiling(Math.Abs(sweep) / (Math.PI / 24)));
            double px = a.X, py = a.Y;
            for (int k = 1; k <= steps; k++)
            {
                double ang = a0 + sweep * k / steps;
                double qx = k == steps ? b.X : cx + r * Math.Cos(ang), qy = k == steps ? b.Y : cy + r * Math.Sin(ang);
                seg(px, py, qx, qy, true);
                px = qx; py = qy;
            }
        }
    }

    private static List<(double X, double Y)> Arc(double cx, double cy, double r, double a0, double a1, double stepDeg)
    {
        int n = Math.Max(4, (int)Math.Ceiling((a1 - a0) / (stepDeg * Math.PI / 180) - 1e-9));
        var res = new List<(double, double)>();
        for (int i = 0; i <= n; i++) { double a = a0 + (a1 - a0) * i / n; res.Add((cx + r * Math.Cos(a), cy + r * Math.Sin(a))); }
        return res;
    }

    private static string CleanText(string s)
    {
        s = s.Replace("\\P", " ").Replace("\\~", " ");
        s = Regex.Replace(s, @"\\[A-Za-z][^;\\]*;", "");
        s = s.Replace("{", "").Replace("}", "").Replace("%%c", "Ø").Replace("%%d", "°").Replace("%%p", "±");
        return s.Trim();
    }

    // ------------------------------------------------------------------ couleurs AutoCAD
    public static int AciToRgb(int i)
    {
        switch (i)
        {
            case 1: return 0xFF0000; case 2: return 0xC8A800; case 3: return 0x00A000; case 4: return 0x00A0A8; case 5: return 0x0000FF;
            case 6: return 0xC000C0; case 7: return 0x303030; case 8: return 0x808080; case 9: return 0xB0B0B0;
        }
        if (i >= 250 && i <= 255) { int g = 51 + (i - 250) * 36; return (g << 16) | (g << 8) | g; }
        if (i < 10 || i > 249) return 0x303030;
        int n = i - 10, hueGroup = n / 10, k = n % 10;
        double hue = hueGroup * 15.0;
        double[] sat = { 1, 0.5, 1, 0.5, 1, 0.5, 1, 0.5, 1, 0.5 };
        double[] val = { 1, 1, 0.65, 0.65, 0.5, 0.5, 0.3, 0.3, 0.15, 0.15 };
        return Hsv(hue, sat[k], Math.Min(val[k], 0.85));
    }

    private static int Hsv(double h, double s, double v)
    {
        double c = v * s, x = c * (1 - Math.Abs((h / 60) % 2 - 1)), m = v - c, r, g, b;
        if (h < 60) (r, g, b) = (c, x, 0); else if (h < 120) (r, g, b) = (x, c, 0); else if (h < 180) (r, g, b) = (0, c, x);
        else if (h < 240) (r, g, b) = (0, x, c); else if (h < 300) (r, g, b) = (x, 0, c); else (r, g, b) = (c, 0, x);
        return ((int)((r + m) * 255) << 16) | ((int)((g + m) * 255) << 8) | (int)((b + m) * 255);
    }
}
