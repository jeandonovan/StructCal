﻿using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Geometry;

/// <summary>Solide d'une semelle isolée : bloc rectangulaire, ou semelle à glacis (bord vertical de faible épaisseur puis dessus en pente
/// jusqu'à un plateau un peu plus grand que le poteau). Le dessus est à la cote ztop ; la semelle descend de h.</summary>
public static class FootingSolids
{
    /// <summary>Épaisseur minimale au bord d'un glacis (m).</summary>
    public const double MinEdge = 0.20;
    /// <summary>Débord du plateau du glacis autour du poteau, de chaque côté (m).</summary>
    public const double PlateauMargin = 0.15;

    /// <summary>Épaisseur utile au bord (m) pour un glacis : au moins 20 cm, au plus la hauteur totale.</summary>
    public static double EdgeThickness(double h, double edgeCm) => Math.Min(h, Math.Max(MinEdge, edgeCm / 100.0));

    /// <summary>Volume de béton (m³) : bloc A x B x h, ou bord + tronc de pyramide si glacis.</summary>
    public static double Volume(double a, double b, double h, double colA, double colB, bool glacis, double edgeCm)
    {
        double e = EdgeThickness(h, edgeCm);
        if (!glacis || h - e < 0.03) return a * b * h;
        double pa = Math.Min(a, colA + 2 * PlateauMargin), pb = Math.Min(b, colB + 2 * PlateauMargin);
        double s1 = a * b, s2 = pa * pb, hh = h - e;
        return s1 * e + hh / 3.0 * (s1 + s2 + Math.Sqrt(s1 * s2));
    }

    private static Vec3 NormalOut(Vec3[] p, Vec3 center)
    {
        var n = (p[1] - p[0]).Cross(p[2] - p[0]).Unit();
        var c = new Vec3(0, 0, 0);
        foreach (var q in p) c = c + q;
        c = c * (1.0 / p.Length);
        return n.Dot(c - center) < 0 ? n * -1.0 : n;
    }

    /// <summary>Facettes de la semelle centrée en (cx, cy), dessus à ztop. A suivant X, B suivant Y.</summary>
    /// <summary>Demi-dimensions du plateau (ou du poteau si pas de glacis) sur le dessus de la semelle.</summary>
    private static (double Pa, double Pb) Plateau(double a, double b, double colA, double colB, bool glacis) =>
        glacis ? (Math.Min(a, colA + 2 * PlateauMargin) / 2, Math.Min(b, colB + 2 * PlateauMargin) / 2) : (Math.Min(a, colA) / 2, Math.Min(b, colB) / 2);

    /// <summary>Décalage (m) du centre de la semelle par rapport à l'axe du poteau selon la position choisie : alignX / alignY = 0 centré,
    /// +1 poteau côté +X (ou +Y) de la semelle, -1 côté opposé. Le poteau reste collé au bord : ox = -align x (A/2 - plateau).</summary>
    public static (double Ox, double Oy) Shift(double a, double b, double colA, double colB, bool glacis, int alignX, int alignY)
    {
        var (pa, pb) = Plateau(a, b, colA, colB, glacis);
        return (-Math.Sign(alignX) * Math.Max(0, a / 2 - pa), -Math.Sign(alignY) * Math.Max(0, b / 2 - pb));
    }

    /// <summary>Facettes de la semelle dont le poteau est en (px, py) ; alignX/alignY règlent la position du poteau (0 = centré, ±1 = excentré vers un bord).</summary>
    public static List<Face> Build(double px, double py, double ztop, double a, double b, double h, double colA, double colB, bool glacis, double edgeCm, int alignX = 0, int alignY = 0)
    {
        var (ox, oy) = Shift(a, b, colA, colB, glacis, alignX, alignY);
        double cx = px + ox, cy = py + oy;
        var faces = new List<Face>();
        double zb = ztop - h, e = EdgeThickness(h, edgeCm);
        var center = new Vec3(cx, cy, zb + h / 2);
        void Quad(Vec3 p0, Vec3 p1, Vec3 p2, Vec3 p3)
        {
            var pts = new[] { p0, p1, p2, p3 };
            faces.Add(new Face { P = pts, N = NormalOut(pts, center), MemberId = -1, EdgeMask = 0b1111 });
        }
        Vec3 V(double x, double y, double z) => new(cx + x, cy + y, z);
        double ha = a / 2, hb = b / 2;
        bool slope = glacis && h - e >= 0.03;
        double zEdge = slope ? zb + e : ztop;
        // flancs verticaux (jusqu'au bord haut)
        Quad(V(-ha, -hb, zb), V(ha, -hb, zb), V(ha, -hb, zEdge), V(-ha, -hb, zEdge));
        Quad(V(ha, -hb, zb), V(ha, hb, zb), V(ha, hb, zEdge), V(ha, -hb, zEdge));
        Quad(V(ha, hb, zb), V(-ha, hb, zb), V(-ha, hb, zEdge), V(ha, hb, zEdge));
        Quad(V(-ha, hb, zb), V(-ha, -hb, zb), V(-ha, -hb, zEdge), V(-ha, hb, zEdge));
        // dessous
        Quad(V(-ha, -hb, zb), V(-ha, hb, zb), V(ha, hb, zb), V(ha, -hb, zb));
        if (!slope)
        {
            Quad(V(-ha, -hb, ztop), V(ha, -hb, ztop), V(ha, hb, ztop), V(-ha, hb, ztop));
            return faces;
        }
        var (pa, pb) = Plateau(a, b, colA, colB, true);
        double qx = -ox, qy = -oy;                                   // centre du plateau (axe du poteau) par rapport au centre de la semelle
        // glacis : du bord haut vers le plateau (centré ou excentré)
        Quad(V(-ha, -hb, zEdge), V(ha, -hb, zEdge), V(qx + pa, qy - pb, ztop), V(qx - pa, qy - pb, ztop));
        Quad(V(ha, -hb, zEdge), V(ha, hb, zEdge), V(qx + pa, qy + pb, ztop), V(qx + pa, qy - pb, ztop));
        Quad(V(ha, hb, zEdge), V(-ha, hb, zEdge), V(qx - pa, qy + pb, ztop), V(qx + pa, qy + pb, ztop));
        Quad(V(-ha, hb, zEdge), V(-ha, -hb, zEdge), V(qx - pa, qy - pb, ztop), V(qx - pa, qy + pb, ztop));
        Quad(V(qx - pa, qy - pb, ztop), V(qx + pa, qy - pb, ztop), V(qx + pa, qy + pb, ztop), V(qx - pa, qy + pb, ztop));
        return faces;
    }
}

/// <summary>Une semelle dimensionnée sous un appui, prête à être dessinée en 3D.</summary>
public sealed class PlacedFooting
{
    public int NodeId;
    public double X, Y, ZTop, A, B, H, ColA, ColB;
    public bool Ok;
    public string Name = "";
    /// <summary>Semelle à glacis et épaisseur au bord (cm) : celle de la semelle définie dans l'assistant si elle existe, sinon le réglage général du modèle.</summary>
    public bool Glacis;
    public double EdgeCm = 20;
    /// <summary>Vrai si la semelle vient d'une définition de l'assistant Sol et semelles (même nom Sn).</summary>
    public bool FromAssistant;
}

public static class FootingPlacement
{
    private static readonly Regex NodeRx = new(@"n\S*ud\s+(\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>Numéro du nœud cité dans « Semelle sous nœud 5 (...) », ou -1.</summary>
    public static int NodeIdOf(string element)
    {
        var m = NodeRx.Match(element ?? "");
        return m.Success && int.TryParse(m.Groups[1].Value, out int id) ? id : -1;
    }

    /// <summary>Semelles isolées dimensionnées (résultats du calcul) avec leur position : dessus à la cote du nœud d'appui, A suivant X, B suivant Y.</summary>
    public static List<PlacedFooting> From(StructModel m, AnalysisOutput? o)
    {
        var res = new List<PlacedFooting>();
        if (o == null) return res;
        foreach (var f in o.Footings)
        {
            if (!f.Values.TryGetValue("A_m", out double a) || !f.Values.TryGetValue("B_m", out double b) || !f.Values.TryGetValue("h_m", out double h)) continue;
            int id = NodeIdOf(f.Element);
            var n = m.Nodes.FirstOrDefault(q => q.Id == id);
            if (n == null || a <= 0 || b <= 0 || h <= 0) continue;
            var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && (x.NodeI == id || x.NodeJ == id));
            var fd = m.FootingDefs.FirstOrDefault(x => x.Name == "S" + id && x.Kind == FootingKind.Isolee);
            res.Add(new PlacedFooting { NodeId = id, X = n.X, Y = n.Y, ZTop = n.Z, A = a, B = b, H = h, ColA = col?.B ?? 0.3, ColB = col?.H ?? 0.3, Ok = f.Ok, Name = "S" + id,
                Glacis = fd != null ? fd.Glacis : m.FootingGlacis, EdgeCm = fd != null ? fd.GlacisEdgeCm : m.FootingGlacisEdgeCm, FromAssistant = fd != null });
        }
        return res;
    }
}
