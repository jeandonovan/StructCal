using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed class ModeInfo
{
    public int Index;
    public double Omega, FreqHz, Period;
    /// <summary>Facteurs de participation et fractions de masse modale effective suivant X et Y.</summary>
    public double GammaX, GammaY, RatioX, RatioY;
    /// <summary>Facteur de participation et fraction de masse effective verticale (analyse modale verticale seulement).</summary>
    public double GammaZ, RatioZ;
    /// <summary>Forme propre : composantes (ux, uy) par nœud.</summary>
    public Dictionary<int, (double Ux, double Uy)> Shape { get; } = new();
}

public sealed class ModalResult
{
    public List<ModeInfo> Modes { get; } = new();
    public double TotalMassTonnes;
    public double CumulX, CumulY, CumulZ;
    public bool Vertical;
    public string Report = "";
    public string Note = "";

    /// <summary>Période du mode qui mobilise le plus de masse dans la direction demandée.</summary>
    public double DominantPeriod(SeismicDirection d)
    {
        if (Modes.Count == 0) return 0;
        var best = d == SeismicDirection.X ? Modes.OrderByDescending(x => x.RatioX).First() : Modes.OrderByDescending(x => x.RatioY).First();
        return best.Period;
    }
}

/// <summary>Analyse modale : fréquences propres et formes propres du portique (masses concentrées aux nœuds, translations horizontales X et Y).
/// Les ddl sans masse (rotations, translation verticale) sont éliminés par condensation statique (exacte pour ces ddl sans masse) ;
/// le problème réduit est résolu par la méthode de Jacobi. Limite : 450 ddl massiques horizontaux.</summary>
public static class ModalAnalysis
{
    public const double G = 9.81;
    public const int MaxMassDofs = 450;

    /// <summary>Poids (kN) concentré à chaque nœud : poids propre, charges permanentes et psi x charges d'exploitation des barres (moitié à chaque extrémité), charges nodales verticales.</summary>
    public static Dictionary<int, double> NodalWeights(StructModel m, double psi)
    {
        var w = new Dictionary<int, double>();
        void Add(int id, double v) { w[id] = (w.TryGetValue(id, out var x) ? x : 0) + v; }
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var loads = LoadExpander.MemberLoadsOf(m);
        foreach (var mem in m.Members)
        {
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            double L = Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
            if (L < 1e-9) continue;
            double wz = 0;
            var (_, Rm) = FrameSolver.LocalAxes(a, b, mem.Roll);
            foreach (var l in loads.Where(l => l.MemberId == mem.Id))
            {
                double down = -LoadMath.VerticalResultant(l, L, Rm) / L;
                if (l.Case == ActionType.G) wz += down;
                else if (l.Case == ActionType.Q) wz += psi * down;
            }
            if (m.IncludeSelfWeight)
            {
                bool rc = mem.Kind == MaterialKind.ReinforcedConcrete;
                double area = mem.PropA > 0 ? mem.PropA : mem.B * mem.H;
                if (!rc && mem.PropA <= 0 && StructCalc.Core.Steel.SteelCatalog.TryGet(mem.Profile, out var pr)) area = pr.A;
                wz += (rc ? 25.0 : 78.5) * area;
            }
            Add(mem.NodeI, wz * L / 2); Add(mem.NodeJ, wz * L / 2);
        }
        foreach (var l in m.NodalLoads)
        {
            if (!nodes.ContainsKey(l.NodeId)) continue;
            if (l.Case == ActionType.G) Add(l.NodeId, -l.Fz);
            else if (l.Case == ActionType.Q) Add(l.NodeId, psi * -l.Fz);
        }
        foreach (var kv in ShellFem.NodalWeights(m, psi)) Add(kv.Key, kv.Value);
        return w;
    }

    /// <summary>Analyse modale horizontale (translations X et Y) ou, avec <paramref name="vertical"/>, verticale (translation Z : flexion des planchers et des poutres).</summary>
    public static ModalResult Compute(StructModel m, int nModes = 6, bool vertical = false)
    {
        var res = new ModalResult { Vertical = vertical };
        double psi = m.Seismic.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase) ? m.Seismic.PsiE : m.Seismic.Beta;
        var weights = NodalWeights(m, psi);
        res.TotalMassTonnes = weights.Values.Where(v => v > 0).Sum() / G;
        if ((m.Members.Count == 0 && m.Shells.Count == 0) || m.Supports.Count == 0) { res.Note = "Modèle sans barres ou sans appuis."; res.Report = res.Note; return res; }

        double[] Kr = FrameSolver.AssembleStiffness(m, out var idx, out var map, out int nf);
        // ddl massiques : translations X et Y libres des nœuds chargés
        var tDof = new List<int>();          // indice réduit
        var tMass = new List<double>();      // tonnes
        var tNode = new List<int>();
        var tDir = new List<int>();          // 0 = X, 1 = Y
        foreach (var n in m.Nodes)
        {
            if (!weights.TryGetValue(n.Id, out var wk) || wk <= 1e-9) continue;
            int i = idx[n.Id];
            for (int dir = vertical ? 2 : 0; dir < (vertical ? 3 : 2); dir++)
            {
                int r = map[6 * i + dir];
                if (r < 0) continue;
                tDof.Add(r); tMass.Add(wk / G); tNode.Add(n.Id); tDir.Add(dir);
            }
        }
        int nt = tDof.Count;
        if (nt == 0) { res.Note = "Aucune masse horizontale libre (pas de charges permanentes ou nœuds tous bloqués)."; res.Report = res.Note; return res; }
        if (nt > MaxMassDofs)
        {
            res.Note = $"Modèle trop grand pour l'analyse modale intégrée ({nt} ddl massiques, limite {MaxMassDofs}).";
            res.Report = res.Note; return res;
        }

        // partition t (massique) / r (le reste des ddl libres)
        var isT = new bool[nf];
        foreach (int r in tDof) isT[r] = true;
        var rList = new List<int>();
        for (int d = 0; d < nf; d++) if (!isT[d]) rList.Add(d);
        int nr = rList.Count;
        var kmm = new double[nt, nt];
        for (int a = 0; a < nt; a++)
            for (int b = 0; b < nt; b++) kmm[a, b] = Kr[tDof[a] * nf + tDof[b]];
        if (nr > 0)
        {
            // Krr = L L^T
            var krr = new double[nr * nr];
            for (int a = 0; a < nr; a++) for (int b = 0; b < nr; b++) krr[a * nr + b] = Kr[rList[a] * nf + rList[b]];
            Cholesky(krr, nr);
            // X = Krr^-1 Krt (nr x nt), colonne par colonne
            var X = new double[nr, nt];
            var col = new double[nr];
            for (int b = 0; b < nt; b++)
            {
                for (int a = 0; a < nr; a++) col[a] = Kr[rList[a] * nf + tDof[b]];
                CholSolve(krr, nr, col);
                for (int a = 0; a < nr; a++) X[a, b] = col[a];
            }
            // Kmm = Ktt - Ktr X
            for (int a = 0; a < nt; a++)
                for (int b = 0; b < nt; b++)
                {
                    double s = 0;
                    for (int k = 0; k < nr; k++) s += Kr[tDof[a] * nf + rList[k]] * X[k, b];
                    kmm[a, b] -= s;
                }
        }
        // S = M^-1/2 Kmm M^-1/2 (symétrisée)
        var S = new double[nt, nt];
        for (int a = 0; a < nt; a++)
            for (int b = 0; b < nt; b++)
                S[a, b] = 0.5 * (kmm[a, b] + kmm[b, a]) / Math.Sqrt(tMass[a] * tMass[b]);
        Jacobi(S, nt, out var lam, out var V);

        var order = Enumerable.Range(0, nt).Where(i => lam[i] > 1e-9).OrderBy(i => lam[i]).Take(nModes).ToList();
        double mTot = Math.Max(res.TotalMassTonnes, 1e-9);
        int mi = 0;
        foreach (int j in order)
        {
            var mode = new ModeInfo { Index = ++mi, Omega = Math.Sqrt(lam[j]) };
            mode.FreqHz = mode.Omega / (2 * Math.PI); mode.Period = 1.0 / mode.FreqHz;
            double gx = 0, gy = 0, gz = 0;
            for (int a = 0; a < nt; a++)
            {
                double phi = V[a, j] / Math.Sqrt(tMass[a]);       // forme normalisée à la masse : phi^T M phi = 1
                if (tDir[a] == 2) { gz += tMass[a] * phi; continue; }
                if (tDir[a] == 0) gx += tMass[a] * phi; else gy += tMass[a] * phi;
                var cur = mode.Shape.TryGetValue(tNode[a], out var sv) ? sv : (0.0, 0.0);
                mode.Shape[tNode[a]] = tDir[a] == 0 ? (phi, cur.Item2) : (cur.Item1, phi);
            }
            mode.GammaX = gx; mode.GammaY = gy; mode.RatioX = gx * gx / mTot; mode.RatioY = gy * gy / mTot;
            mode.GammaZ = gz; mode.RatioZ = gz * gz / mTot;
            res.Modes.Add(mode);
        }
        res.CumulX = res.Modes.Sum(x => x.RatioX); res.CumulY = res.Modes.Sum(x => x.RatioY); res.CumulZ = res.Modes.Sum(x => x.RatioZ);
        if (vertical)
        {
            var sv2 = new StringBuilder();
            sv2.AppendLine("ANALYSE MODALE VERTICALE (masses concentrées aux nœuds, translation Z)");
            sv2.AppendLine($"Masse totale = {res.TotalMassTonnes:0.0} t ; {nt} ddl massiques verticaux.");
            sv2.AppendLine("Mode   Période (s)   Fréq. (Hz)   Masse eff. Z   Cumul Z");
            double cz = 0;
            foreach (var md in res.Modes) { cz += md.RatioZ; sv2.AppendLine($"{md.Index,4}   {md.Period,10:0.000}   {md.FreqHz,9:0.000}   {md.RatioZ * 100,9:0.0} %   {cz * 100,6:0} %"); }
            res.Report = sv2.ToString();
            return res;
        }

        var sb = new StringBuilder();
        sb.AppendLine("ANALYSE MODALE (masses horizontales concentrées aux nœuds)");
        sb.AppendLine($"Masse totale = {res.TotalMassTonnes:0.0} t (poids sismique {res.TotalMassTonnes * G:0} kN) ; {nt} ddl massiques, {nr} ddl condensés.");
        sb.AppendLine();
        sb.AppendLine("Mode   Période (s)   Fréq. (Hz)   Masse eff. X   Masse eff. Y   Cumul X   Cumul Y");
        double cx = 0, cy = 0;
        foreach (var md in res.Modes)
        {
            cx += md.RatioX; cy += md.RatioY;
            sb.AppendLine($"{md.Index,4}   {md.Period,10:0.000}   {md.FreqHz,9:0.000}   {md.RatioX * 100,9:0.0} %   {md.RatioY * 100,9:0.0} %   {cx * 100,6:0} %   {cy * 100,6:0} %");
        }
        sb.AppendLine();
        sb.AppendLine(cx >= 0.9 && cy >= 0.9
            ? "✔ Plus de 90 % de la masse est mobilisée dans chaque direction (critère courant RPA 99 / EC8)."
            : $"⚠ Masse mobilisée : {cx * 100:0} % en X, {cy * 100:0} % en Y : moins de 90 %. Augmentez le nombre de modes ou vérifiez le modèle.");
        sb.AppendLine("Les planchers sont supposés rigides dans leur plan par la répartition des masses aux nœuds ; la flexion verticale des planchers n'est pas dans cette analyse.");
        res.Report = sb.ToString();
        return res;
    }

    // ---------------------------------------------------------------- algèbre dense
    /// <summary>Factorisation de Cholesky en place (triangle inférieur).</summary>
    private static void Cholesky(double[] a, int n)
    {
        for (int j = 0; j < n; j++)
        {
            double s = a[j * n + j];
            for (int k = 0; k < j; k++) s -= a[j * n + k] * a[j * n + k];
            if (s <= 1e-30) throw new InvalidOperationException("Structure instable ou mal appuyée (matrice de rigidité singulière) : analyse modale impossible.");
            double l = Math.Sqrt(s);
            a[j * n + j] = l;
            for (int i = j + 1; i < n; i++)
            {
                double t = a[i * n + j];
                for (int k = 0; k < j; k++) t -= a[i * n + k] * a[j * n + k];
                a[i * n + j] = t / l;
            }
        }
    }

    private static void CholSolve(double[] l, int n, double[] b)
    {
        for (int i = 0; i < n; i++)
        {
            double y = b[i];
            for (int k = 0; k < i; k++) y -= l[i * n + k] * b[k];
            b[i] = y / l[i * n + i];
        }
        for (int i = n - 1; i >= 0; i--)
        {
            double s = b[i];
            for (int k = i + 1; k < n; k++) s -= l[k * n + i] * b[k];
            b[i] = s / l[i * n + i];
        }
    }

    /// <summary>Valeurs et vecteurs propres d'une matrice symétrique (Jacobi cyclique). a est détruite ; v : vecteurs en colonnes.</summary>
    private static void Jacobi(double[,] a, int n, out double[] w, out double[,] v)
    {
        v = new double[n, n];
        for (int i = 0; i < n; i++) v[i, i] = 1;
        double scale = 0;
        for (int i = 0; i < n; i++) scale += a[i, i] * a[i, i];
        scale = Math.Max(scale, 1e-300);
        for (int sweep = 0; sweep < 80; sweep++)
        {
            double off = 0;
            for (int p = 0; p < n; p++) for (int q = p + 1; q < n; q++) off += a[p, q] * a[p, q];
            if (off < 1e-26 * scale) break;
            for (int p = 0; p < n - 1; p++)
                for (int q = p + 1; q < n; q++)
                {
                    double apq = a[p, q];
                    if (Math.Abs(apq) < 1e-300) continue;
                    double theta = (a[q, q] - a[p, p]) / (2 * apq);
                    double t = (theta >= 0 ? 1.0 : -1.0) / (Math.Abs(theta) + Math.Sqrt(theta * theta + 1));
                    double c = 1 / Math.Sqrt(t * t + 1), s = t * c;
                    for (int k = 0; k < n; k++)
                    {
                        double akp = a[k, p], akq = a[k, q];
                        a[k, p] = c * akp - s * akq; a[k, q] = s * akp + c * akq;
                    }
                    for (int k = 0; k < n; k++)
                    {
                        double apk = a[p, k], aqk = a[q, k];
                        a[p, k] = c * apk - s * aqk; a[q, k] = s * apk + c * aqk;
                    }
                    for (int k = 0; k < n; k++)
                    {
                        double vkp = v[k, p], vkq = v[k, q];
                        v[k, p] = c * vkp - s * vkq; v[k, q] = s * vkp + c * vkq;
                    }
                }
        }
        w = new double[n];
        for (int i = 0; i < n; i++) w[i] = a[i, i];
    }
}

/// <summary>Déplacements inter-étages et effet P-Δ sous l'action sismique (RPA 99 art. 5.9, EC8 4.4.2.2) : θ = P.dr / (V.h).</summary>
public static class StoreyChecks
{
    public static ExtraDesign? Compute(StructModel m, CaseResult e, IEnumerable<NodalLoad> eLoads)
    {
        var sp = m.Seismic;
        bool ec8 = sp.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase);
        double amp = ec8 ? sp.BehaviorQ : sp.R;          // déplacements réels = q (EC8) ou R (RPA) x déplacements élastiques
        var loads = eLoads.ToList();
        if (m.Nodes.Count == 0 || loads.Count == 0) return null;
        bool dirX = sp.Enabled ? sp.Direction == SeismicDirection.X : loads.Sum(l => Math.Abs(l.Fx)) >= loads.Sum(l => Math.Abs(l.Fy));
        int comp = dirX ? 0 : 1;
        double psi = ec8 ? sp.PsiE : sp.Beta;
        var weights = ModalAnalysis.NodalWeights(m, psi);
        long Key(double z) => (long)Math.Round(z * 1000.0);
        var levels = m.Nodes.GroupBy(n => Key(n.Z)).OrderBy(g => g.Key).ToList();
        if (levels.Count < 2) return null;
        var nodeLevel = new Dictionary<int, long>();
        foreach (var g in levels) foreach (var n in g) nodeLevel[n.Id] = g.Key;

        double Disp(IGrouping<long, Node> g)
        {
            var vals = g.Where(n => e.NodeDisp.ContainsKey(n.Id)).Select(n => e.NodeDisp[n.Id][comp]).ToList();
            return vals.Count == 0 ? 0 : vals.Average();
        }

        var sb = new System.Text.StringBuilder();
        sb.AppendLine($"DÉPLACEMENTS INTER-ÉTAGES ET EFFET P-Δ (séisme suivant {(dirX ? "X" : "Y")}, déplacements réels = {amp:0.##} x élastiques)");
        sb.AppendLine("Niveau     h (m)   V (kN)   P (kN)   dr él. (mm)   dr réel (mm)   dr/h     θ      Verdict");
        bool ok = true;
        double prevD = 0, prevZ = levels[0].Key / 1000.0;
        for (int i = 1; i < levels.Count; i++)
        {
            long k = levels[i].Key;
            double h = k / 1000.0 - prevZ;
            double d = Disp(levels[i]);
            double drEl = d - prevD;
            double dr = drEl * amp;
            double v = Math.Abs(loads.Where(l => nodeLevel.TryGetValue(l.NodeId, out var lk) && lk >= k).Sum(l => dirX ? l.Fx : l.Fy));
            double p = m.Nodes.Where(n => nodeLevel[n.Id] >= k && weights.ContainsKey(n.Id)).Sum(n => weights[n.Id]);
            double ratio = h > 1e-6 ? Math.Abs(dr) / h : 0;
            double theta = v > 1e-6 && h > 1e-6 ? p * Math.Abs(dr) / (v * h) : 0;
            string verdict;
            if (ratio > 0.01) { verdict = "✖ dr > 1 % h"; ok = false; }
            else if (theta > 0.2) { verdict = "✖ θ > 0,2 : 2e ordre"; ok = false; }
            else if (theta > 0.1) verdict = $"⚠ amplifier x{1 / (1 - theta):0.00}";
            else verdict = "✔";
            string name = m.Levels.OrderBy(s => Math.Abs(s.Elevation - k / 1000.0)).FirstOrDefault(s => Math.Abs(s.Elevation - k / 1000.0) < 0.05)?.Name ?? $"z={k / 1000.0:0.00}";
            sb.AppendLine($"{name,-9} {h,6:0.00} {v,8:0} {p,8:0} {drEl * 1000,12:0.00} {dr * 1000,13:0.00} {ratio * 100,6:0.00}% {theta,6:0.000}   {verdict}");
            prevD = d; prevZ = k / 1000.0;
        }
        sb.AppendLine();
        sb.AppendLine("Limite de déplacement : dr <= 1 % de la hauteur d'étage. θ <= 0,10 : effets du 2e ordre négligés ; 0,10 < θ <= 0,20 : effets sismiques multipliés par 1/(1-θ) ; θ > 0,20 : analyse du 2e ordre nécessaire.");
        return new ExtraDesign { Title = "Déplacements inter-étages et effet P-Δ", Text = sb.ToString(), Ok = ok };
    }
}

public sealed class SpectrumResult
{
    public CaseResult Case { get; } = new();
    /// <summary>Forces nodales combinées (X, Y) : servent au calcul des efforts tranchants d'étage.</summary>
    public List<NodalLoad> NodalForces { get; } = new();
    public double VDynamic, VStatic, Scale = 1, VFinal;
    public string Report = "";
    public int ModesUsed;
    public double MassRatio;
}

/// <summary>Analyse modale spectrale : pour chaque mode, forces équivalentes Γ·m·φ·Sa appliquées à la structure, puis combinaison quadratique complète (CQC)
/// des déplacements, réactions et efforts des barres. Le signe de chaque grandeur est celui du mode qui y contribue le plus (les combinaisons ±E couvrent les deux sens).</summary>
public static class ResponseSpectrum
{
    public static SpectrumResult? Compute(StructModel m, ModalResult modal, double staticBaseShear)
    {
        var sp = m.Seismic;
        bool ec8 = sp.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase);
        bool dirX = sp.Direction == SeismicDirection.X;
        if (modal.Modes.Count == 0) return null;

        // modes retenus : jusqu'à mobiliser 90 % de la masse dans la direction (au moins 3 si possible)
        var used = new List<ModeInfo>();
        double cum = 0;
        foreach (var md in modal.Modes)
        {
            used.Add(md);
            cum += dirX ? md.RatioX : md.RatioY;
            if (cum >= 0.9 && used.Count >= Math.Min(3, modal.Modes.Count)) break;
        }
        int n = used.Count;

        double psi = ec8 ? sp.PsiE : sp.Beta;
        var weights = ModalAnalysis.NodalWeights(m, psi);
        double xi = ec8 ? 0.05 : Math.Max(0.02, sp.XiPercent / 100.0);

        // corrélation CQC
        var rho = new double[n, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            {
                double r = used[j].Omega / used[i].Omega;
                double num = 8 * xi * xi * (1 + r) * Math.Pow(r, 1.5);
                double den = Math.Pow(1 - r * r, 2) + 4 * xi * xi * r * Math.Pow(1 + r, 2);
                rho[i, j] = i == j ? 1.0 : (den > 1e-12 ? num / den : 1.0);
            }

        // un calcul statique par mode
        var cases = new List<CaseResult>();
        var vi = new double[n];
        var fx = new List<Dictionary<int, double>>();
        var fy = new List<Dictionary<int, double>>();
        var sb = new StringBuilder();
        sb.AppendLine($"ANALYSE MODALE SPECTRALE ({(ec8 ? "EC8 type 1" : "RPA 99 v2003")}, direction {(dirX ? "X" : "Y")}, amortissement {xi * 100:0.#} %, combinaison CQC)");
        sb.AppendLine("Mode   T (s)    Sa/g     Γ (t^0,5)   Masse eff.   V mode (kN)");
        for (int i = 0; i < n; i++)
        {
            var md = used[i];
            double saG = SeismicLoads.SpectrumOverG(m, md.Period);
            double sa = saG * ModalAnalysis.G;
            double gamma = dirX ? md.GammaX : md.GammaY;
            vi[i] = gamma * gamma * sa;
            var loads = new List<NodalLoad>();
            var dx = new Dictionary<int, double>(); var dy = new Dictionary<int, double>();
            foreach (var kv in md.Shape)
            {
                if (!weights.TryGetValue(kv.Key, out var wk) || wk <= 0) continue;
                double mk = wk / ModalAnalysis.G;
                double fxk = gamma * mk * kv.Value.Ux * sa, fyk = gamma * mk * kv.Value.Uy * sa;
                loads.Add(new NodalLoad { NodeId = kv.Key, Case = ActionType.E, Fx = fxk, Fy = fyk });
                dx[kv.Key] = fxk; dy[kv.Key] = fyk;
            }
            cases.Add(FrameSolver.Solve(m, ActionType.E, loads));
            fx.Add(dx); fy.Add(dy);
            sb.AppendLine($"{md.Index,4}   {md.Period,6:0.000}  {saG,7:0.0000}  {gamma,10:0.00}  {(dirX ? md.RatioX : md.RatioY) * 100,9:0.0} %  {vi[i],11:0.0}");
        }

        double Cqc(double[] v)
        {
            double q = 0;
            for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) q += rho[i, j] * v[i] * v[j];
            double mag = Math.Sqrt(Math.Max(q, 0));
            int dom = 0;
            for (int i = 1; i < n; i++) if (Math.Abs(v[i]) > Math.Abs(v[dom])) dom = i;
            return v[dom] < 0 ? -mag : mag;
        }

        var res = new SpectrumResult { ModesUsed = n, MassRatio = cum };
        double vdyn = Math.Sqrt(Enumerable.Range(0, n).Sum(i => Enumerable.Range(0, n).Sum(j => rho[i, j] * vi[i] * vi[j])));
        res.VDynamic = vdyn; res.VStatic = staticBaseShear;
        if (!ec8 && staticBaseShear > 0 && vdyn > 1e-9 && vdyn < 0.8 * staticBaseShear) res.Scale = 0.8 * staticBaseShear / vdyn;
        res.VFinal = vdyn * res.Scale;
        double sc = res.Scale;

        var tmp = new double[n];
        foreach (var node in m.Nodes)
        {
            if (cases[0].NodeDisp.ContainsKey(node.Id))
            {
                var d = new double[6];
                for (int c = 0; c < 6; c++) { for (int i = 0; i < n; i++) tmp[i] = cases[i].NodeDisp[node.Id][c]; d[c] = Cqc(tmp) * sc; }
                res.Case.NodeDisp[node.Id] = d;
            }
            if (cases[0].Reactions.ContainsKey(node.Id))
            {
                var r = new double[6];
                for (int c = 0; c < 6; c++) { for (int i = 0; i < n; i++) tmp[i] = cases[i].Reactions[node.Id][c]; r[c] = Cqc(tmp) * sc; }
                res.Case.Reactions[node.Id] = r;
            }
            double cfx = 0, cfy = 0;
            for (int i = 0; i < n; i++) tmp[i] = fx[i].TryGetValue(node.Id, out var a) ? a : 0;
            cfx = Cqc(tmp) * sc;
            for (int i = 0; i < n; i++) tmp[i] = fy[i].TryGetValue(node.Id, out var b) ? b : 0;
            cfy = Cqc(tmp) * sc;
            if (Math.Abs(cfx) > 1e-12 || Math.Abs(cfy) > 1e-12) res.NodalForces.Add(new NodalLoad { NodeId = node.Id, Case = ActionType.E, Fx = cfx, Fy = cfy });
        }
        foreach (var mem in m.Members)
        {
            if (!cases[0].Members.ContainsKey(mem.Id)) continue;
            int ns = cases[0].Members[mem.Id].Length;
            var st = new StationForces[ns];
            for (int k = 0; k < ns; k++)
            {
                var o = new StationForces { X = cases[0].Members[mem.Id][k].X };
                double V(Func<StationForces, double> sel) { for (int i = 0; i < n; i++) tmp[i] = sel(cases[i].Members[mem.Id][k]); return Cqc(tmp) * sc; }
                o.N = V(f => f.N); o.Vy = V(f => f.Vy); o.Vz = V(f => f.Vz); o.T = V(f => f.T); o.My = V(f => f.My); o.Mz = V(f => f.Mz);
                st[k] = o;
            }
            res.Case.Members[mem.Id] = st;
        }

        sb.AppendLine();
        sb.AppendLine($"Modes retenus : {n} (masse mobilisée {cum * 100:0} % dans la direction étudiée).");
        sb.AppendLine($"Effort tranchant à la base : V dynamique (CQC) = {vdyn:0.0} kN ; V statique de référence = {staticBaseShear:0.0} kN" +
                      (staticBaseShear > 0 ? $" (rapport {vdyn / staticBaseShear:0.00})." : "."));
        if (res.Scale > 1) sb.AppendLine($"⚠ RPA 99 art. 4.3.6 : V dynamique < 0,8 V statique : toutes les réponses sont multipliées par {res.Scale:0.000} (V retenu = {res.VFinal:0.0} kN).");
        else if (!ec8) sb.AppendLine("✔ RPA 99 art. 4.3.6 : V dynamique >= 0,8 V statique.");
        if (cum < 0.9) sb.AppendLine($"⚠ Moins de 90 % de la masse est mobilisée par les modes calculés ({cum * 100:0} %) : vérifiez le modèle (masses, appuis).");
        res.Report = sb.ToString();
        return res;
    }
}
