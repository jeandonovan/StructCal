using System.Globalization;
using System.Net;
using System.Text;

namespace StructCalc.Engine;

/// <summary>Une vérification lisible d'un élément (escalier, voile, radier, plancher nervuré) : valeur calculée, limite, verdict.</summary>
public sealed record SurfaceCheck(string Element, string Check, string Value, string Limit, bool Ok)
{
    public string Verdict => Ok ? "OK" : "NON OK";
}

/// <summary>Tableau de vérifications des éléments surfaciques et des escaliers : une ligne par vérification, avec valeur, limite et verdict,
/// construit uniquement à partir des résultats du calcul (aucune valeur inventée). Utilisé par la note de calcul.</summary>
public static class SurfaceChecks
{
    private static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");
    private static string N(double v, string f = "0.##") => v.ToString(f, Fr);

    public static List<SurfaceCheck> Collect(AnalysisOutput o)
    {
        var L = new List<SurfaceCheck>();

        foreach (var s in o.Stairs)
        {
            string e = "Escalier " + s.Def.Name;
            if (s.Geo.Risers > 0)
            {
                L.Add(new SurfaceCheck(e, "Formule de Blondel 2h + g", N(s.Geo.Blondel * 100, "0.0#") + " cm", "59 à 64 cm", s.Geo.BlondelOk));
                L.Add(new SurfaceCheck(e, "Contremarche", N(s.Geo.RiserM * 100, "0.#") + " cm", "14 à 20 cm", s.Geo.RiserM >= 0.14 - 1e-6 && s.Geo.RiserM <= 0.20 + 1e-6));
            }
            foreach (var el in s.Elements)
            {
                if (el.TauLim > 0) L.Add(new SurfaceCheck(e + " - " + el.Name, "Cisaillement τu", N(el.Tau) + " MPa", "≤ " + N(el.TauLim) + " MPa", el.Tau <= el.TauLim + 1e-9));
                L.Add(new SurfaceCheck(e + " - " + el.Name, "Dimensionnement de l'élément", el.BarsT.Length > 0 ? el.BarsT : "-", "armatures calculées", el.Ok));
            }
            foreach (var w in s.Warnings.Concat(s.Geo.Warnings).Distinct())
                L.Add(new SurfaceCheck(e, "Avertissement", w, "aucun", false));
        }

        foreach (var w in o.Walls)
        {
            string e = "Voile " + w.Def.Name;
            if (w.TauLim > 0) L.Add(new SurfaceCheck(e, "Cisaillement moyen", N(w.Tau) + " MPa", "≤ " + N(w.TauLim) + " MPa", w.Tau <= w.TauLim + 1e-9));
            if (w.MinAs > 0) L.Add(new SurfaceCheck(e, "Armature verticale générale ≥ minimum", N(w.GeneralAsV) + " cm²/m", "≥ " + N(w.MinAs) + " cm²/m", w.GeneralAsV + 1e-9 >= w.MinAs));
            foreach (var x in w.Warnings) L.Add(new SurfaceCheck(e, "Avertissement", x, "aucun", false));
            if (w.Warnings.Count == 0) L.Add(new SurfaceCheck(e, "Dimensionnement du voile", w.GeneralV.Length > 0 ? w.GeneralV : "-", "armatures calculées", w.Ok));
        }

        foreach (var r in o.Rafts)
        {
            string e = "Radier " + r.Def.Name;
            if (r.QAdm > 0) L.Add(new SurfaceCheck(e, "Contrainte maximale du sol", N(r.SigmaMax, "0.#") + " kPa", "≤ " + N(r.QAdm, "0.#") + " kPa", r.SigmaMax <= r.QAdm + 1e-9));
            if (r.HRequired > 0) L.Add(new SurfaceCheck(e, "Épaisseur (poinçonnement)", N(r.Def.H * 100, "0") + " cm", "≥ " + N(r.HRequired * 100, "0") + " cm", r.Def.H + 1e-9 >= r.HRequired));
            L.Add(new SurfaceCheck(e, "Dimensionnement du radier", r.Ok ? "armatures calculées" : "à reprendre", "toutes vérifications", r.Ok));
        }

        foreach (var f in o.RibbedFloors)
        {
            string e = "Plancher " + f.Def.Name;
            if (f.TauLim > 0) L.Add(new SurfaceCheck(e, "Cisaillement poutrelle", N(f.Tau) + " MPa", "≤ " + N(f.TauLim) + " MPa", f.Tau <= f.TauLim + 1e-9));
            foreach (var w in f.Warnings) L.Add(new SurfaceCheck(e, "Avertissement", w, "aucun", false));
            if (f.Warnings.Count == 0) L.Add(new SurfaceCheck(e, "Dimensionnement du plancher", f.Spans.Count + " travée(s)", "armatures calculées", f.Ok));
        }
        return L;
    }

    public static string ToText(AnalysisOutput o)
    {
        var rows = Collect(o);
        if (rows.Count == 0) return "Aucun escalier, voile, radier ou plancher nervuré calculé.";
        var sb = new StringBuilder();
        foreach (var r in rows) sb.AppendLine($"{r.Element} | {r.Check} | {r.Value} | {r.Limit} | {r.Verdict}");
        return sb.ToString();
    }

    public static string ToHtml(AnalysisOutput o)
    {
        var rows = Collect(o);
        if (rows.Count == 0) return "";
        var sb = new StringBuilder();
        sb.AppendLine("<h2>5b. Vérifications des escaliers, voiles, radiers et planchers</h2>");
        sb.AppendLine("<table><tr><th>Élément</th><th>Vérification</th><th>Valeur</th><th>Limite</th><th>Verdict</th></tr>");
        foreach (var r in rows)
            sb.AppendLine($"<tr><td>{WebUtility.HtmlEncode(r.Element)}</td><td>{WebUtility.HtmlEncode(r.Check)}</td><td>{WebUtility.HtmlEncode(r.Value)}</td><td>{WebUtility.HtmlEncode(r.Limit)}</td><td class='{(r.Ok ? "ok" : "ko")}'>{r.Verdict}</td></tr>");
        sb.AppendLine("</table>");
        return sb.ToString();
    }
}
