using System.Globalization;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Note de calcul en PDF, écrite directement (aucune dépendance) : texte à chasse fixe sur A4, en-tête avec logo JPEG facultatif, pagination.</summary>
public static class PdfReport
{
    // ------------------------------------------------------------------ texte de la note
    public static string BuildText(StructModel m, AnalysisOutput o)
    {
        var sb = new StringBuilder();
        var inv = CultureInfo.InvariantCulture;
        sb.AppendLine($"Date : {DateTime.Now:dd/MM/yyyy HH:mm}");
        sb.AppendLine($"Norme BA : {o.RcCode}   Norme CM : {o.SteelCode}");
        sb.AppendLine($"fc28 = {m.Fc28} MPa ; fe = {m.Fe} MPa ; fy = {m.SteelFy} MPa ; poids propre {(m.IncludeSelfWeight ? "inclus" : "non inclus")} ; itérations : {o.Iterations}");
        if (m.UseCustomCombos && m.CustomCombos.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("COMBINAISONS D'ACTIONS (définies pour ce projet)");
            foreach (var c in m.CustomCombos)
                sb.AppendLine($"  {c.State,-10} {c.Name}  :  G x{c.G.ToString("0.##", inv)}  Q x{c.Q.ToString("0.##", inv)}  W x{c.W.ToString("0.##", inv)}  S x{c.S.ToString("0.##", inv)}  E x{c.E.ToString("0.##", inv)}");
        }
        sb.AppendLine();
        foreach (var msg in o.Messages) sb.AppendLine("* " + msg);

        sb.AppendLine();
        sb.AppendLine("1. SYNTHESE DES BARRES");
        sb.AppendLine(new string('-', 100));
        foreach (var r in o.Members)
        {
            string typ = (r.Type == MemberType.Column ? "Poteau" : "Poutre") + (r.Kind == MaterialKind.Steel ? " acier" : " BA");
            sb.AppendLine($"Barre {r.MemberId,-4} {typ,-13} {r.SectionText,-18} L = {r.Length.ToString("0.00", inv)} m   [{r.Status}]");
            sb.AppendLine($"    Mu trav. {r.MuSag.ToString("0.0", inv)} kN.m | Mu appui {r.MuHog.ToString("0.0", inv)} kN.m | Vu {r.Vu.ToString("0.0", inv)} kN | Nu {r.NuMax.ToString("0", inv)} kN");
            sb.AppendLine($"    Inf./long. : {r.BarsBottom}   Sup. : {(r.Type == MemberType.Column ? "-" : r.BarsTop)}   Transv. : {r.Stirrups}");
        }

        sb.AppendLine();
        sb.AppendLine("2. DETAIL DES CALCULS");
        sb.AppendLine(new string('-', 100));
        foreach (var r in o.Members)
        {
            sb.AppendLine($"Barre {r.MemberId} - {r.Type} {r.SectionText}");
            foreach (var n in r.Notes) sb.AppendLine("   " + n);
            foreach (var w in r.Warnings.Distinct()) sb.AppendLine("   ATTENTION : " + w);
            sb.AppendLine();
        }

        sb.AppendLine("3. DALLES, FONDATIONS ET AUTRES ELEMENTS");
        sb.AppendLine(new string('-', 100));
        sb.Append(ReportWriter.ToText(o));
        try
        {
            var inv2 = CultureInfo.InvariantCulture;
            if (o.Store != null)
            {
                sb.AppendLine();
                sb.AppendLine("4. REACTIONS D'APPUI (enveloppe ELU)");
                sb.AppendLine(new string('-', 100));
                foreach (var r in o.Store.Reactions(StructCalc.Engine.Results.ResultsStore.EnvUls))
                    sb.AppendLine($"Noeud {r.NodeId,-5} Fz max {r.Max[2].ToString("0.0", inv2),9} kN [{r.MaxCombo[2]}]   Fz min {r.Min[2].ToString("0.0", inv2),9} [{r.MinCombo[2]}]   Fx {r.Min[0].ToString("0.0", inv2)}/{r.Max[0].ToString("0.0", inv2)}   Fy {r.Min[1].ToString("0.0", inv2)}/{r.Max[1].ToString("0.0", inv2)}");
            }
            var comp = StructCalc.Engine.Results.ResultTables.Compliance(m, o);
            var (ok, lim, ko, man) = StructCalc.Engine.Results.ResultTables.ComplianceCounts(comp);
            sb.AppendLine();
            sb.AppendLine("5. VERIFICATIONS DE CONFORMITE");
            sb.AppendLine(new string('-', 100));
            sb.AppendLine($"Verifie : {ok}   A la limite : {lim}   Non verifie : {ko}   A controler manuellement : {man}");
            foreach (var r in comp.Rows.Where(x => (x[^1] as string) != "Vérifié").Take(120))
                sb.AppendLine($"[{r[^1]}] {r[0]} - {r[1]}   calcule : {comp.CellText(r[2])}  limite : {comp.CellText(r[3])}  ratio : {comp.CellText(r[4])}  {r[5]}");
        }
        catch (Exception ex) { sb.AppendLine("Resultats detailles indisponibles : " + ex.Message); }
        return sb.ToString();
    }

    // ------------------------------------------------------------------ PDF
    private const double PageW = 595.28, PageH = 841.89, Margin = 42, FontPt = 8.2, Lead = 10.2;
    private static readonly int CharsPerLine = (int)((PageW - 2 * Margin) / (FontPt * 0.6));

    public static byte[] Build(StructModel m, AnalysisOutput o, byte[]? logoJpeg, string company)
    {
        var inf = m.Info ?? new ProjectInfo();
        var head = new List<(string, string)>();
        void H(string k, string v) { if (!string.IsNullOrWhiteSpace(v)) head.Add((k, v)); }
        H("Maître d'ouvrage", inf.Client); H("Site", inf.Site);
        H("Bureau d'études", string.IsNullOrWhiteSpace(inf.Designer) ? company : inf.Designer);
        H("Référence", inf.Reference); H("Indice", inf.Revision); H("Remarques", inf.Notes);
        return Render("Note de calcul - " + m.Name, head, BuildText(m, o), logoJpeg, AppInfo.Name + " " + AppInfo.Version);
    }

    private static string Win(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (char c in s)
        {
            switch (c)
            {
                case '✔': sb.Append("OK"); break;
                case '✖': sb.Append("NON OK"); break;
                case '⚠': sb.Append('!'); break;
                case '≥': sb.Append(">="); break;
                case '≤': sb.Append("<="); break;
                case 'μ': sb.Append('µ'); break;
                case 'σ': sb.Append("sigma"); break;
                case 'τ': sb.Append("tau"); break;
                case 'φ': case 'Ø': sb.Append("phi"); break;
                case 'ε': sb.Append("eps"); break;
                case 'γ': sb.Append("gamma"); break;
                case 'λ': sb.Append("lambda"); break;
                case 'Σ': sb.Append("Somme"); break;
                case '›': sb.Append('>'); break;
                case 'œ': sb.Append("oe"); break;
                case 'Œ': sb.Append("OE"); break;
                case '’': case '‘': sb.Append('\''); break;
                case '“': case '”': sb.Append('"'); break;
                case '–': case '—': case '−': sb.Append('-'); break;
                case '…': sb.Append("..."); break;
                case '•': case '·': sb.Append('-'); break;
                case '\t': sb.Append("    "); break;
                default: sb.Append(c < 256 && (c >= 32 || c == '\n') ? c : '?'); break;
            }
        }
        return sb.ToString();
    }

    private static string Esc(string s) => s.Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)");

    private static IEnumerable<string> Wrap(string text)
    {
        foreach (var raw in Win(text).Replace("\r", "").Split('\n'))
        {
            string line = raw.TrimEnd();
            if (line.Length <= CharsPerLine) { yield return line; continue; }
            int indent = line.Length - line.TrimStart().Length;
            string pad = new string(' ', Math.Min(indent + 3, 12));
            string cur = line;
            bool first = true;
            while (cur.Length > CharsPerLine)
            {
                int cut = cur.LastIndexOf(' ', CharsPerLine - 1);
                if (cut < (first ? indent + 10 : pad.Length + 10)) cut = CharsPerLine;
                yield return cur[..cut].TrimEnd();
                cur = pad + cur[cut..].TrimStart();
                first = false;
            }
            yield return cur;
        }
    }

    private static bool JpegSize(byte[] b, out int w, out int h, out int comps)
    {
        w = h = comps = 0;
        if (b.Length < 4 || b[0] != 0xFF || b[1] != 0xD8) return false;
        int i = 2;
        while (i + 9 < b.Length)
        {
            if (b[i] != 0xFF) { i++; continue; }
            int mk = b[i + 1];
            if (mk == 0xD8 || mk == 0x01 || (mk >= 0xD0 && mk <= 0xD7)) { i += 2; continue; }
            int len = (b[i + 2] << 8) | b[i + 3];
            if (mk >= 0xC0 && mk <= 0xCF && mk != 0xC4 && mk != 0xC8 && mk != 0xCC)
            {
                h = (b[i + 5] << 8) | b[i + 6]; w = (b[i + 7] << 8) | b[i + 8]; comps = b[i + 9];
                return w > 0 && h > 0;
            }
            i += 2 + len;
        }
        return false;
    }

    private static byte[] Render(string title, List<(string, string)> head, string body, byte[]? logo, string footer)
    {
        bool hasLogo = logo != null && JpegSize(logo, out _, out _, out int cc) && (cc == 1 || cc == 3);
        int lw = 0, lh = 0, lc = 0;
        if (hasLogo) JpegSize(logo!, out lw, out lh, out lc);

        // ---- mise en page : lignes par page
        var lines = Wrap(body).ToList();
        var pages = new List<List<string>>();
        double headH = 66 + head.Count * 11.5;
        int firstCap = (int)((PageH - Margin - headH - Margin - 14) / Lead);
        int nextCap = (int)((PageH - 2 * Margin - 28) / Lead);
        int idx = 0;
        while (idx < lines.Count || pages.Count == 0)
        {
            int cap = pages.Count == 0 ? firstCap : nextCap;
            pages.Add(lines.Skip(idx).Take(cap).ToList());
            idx += cap;
        }

        // ---- objets PDF
        var objs = new List<byte[]>();      // index 0 = objet 1
        byte[] Latin(string s) => Encoding.Latin1.GetBytes(s);
        int imgObj = hasLogo ? 6 : 0;
        int firstPageObj = hasLogo ? 7 : 6;
        var kids = new StringBuilder();
        for (int p = 0; p < pages.Count; p++) kids.Append($"{firstPageObj + 2 * p} 0 R ");
        objs.Add(Latin("<< /Type /Catalog /Pages 2 0 R >>"));
        objs.Add(Latin($"<< /Type /Pages /Kids [{kids}] /Count {pages.Count} >>"));
        objs.Add(Latin("<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>"));
        objs.Add(Latin("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"));
        objs.Add(Latin("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"));
        if (hasLogo)
        {
            string cs = lc == 1 ? "/DeviceGray" : "/DeviceRGB";
            var hdr = Latin($"<< /Type /XObject /Subtype /Image /Width {lw} /Height {lh} /ColorSpace {cs} /BitsPerComponent 8 /Filter /DCTDecode /Length {logo!.Length} >>\nstream\n");
            var tail = Latin("\nendstream");
            objs.Add(hdr.Concat(logo).Concat(tail).ToArray());
        }
        var inv = CultureInfo.InvariantCulture;
        string F(double d) => d.ToString("0.##", inv);
        for (int p = 0; p < pages.Count; p++)
        {
            int contentObj = firstPageObj + 2 * p + 1;
            string xo = hasLogo ? $" /XObject << /Im1 {imgObj} 0 R >>" : "";
            objs.Add(Latin($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {F(PageW)} {F(PageH)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >>{xo} >> /Contents {contentObj} 0 R >>"));
            var c = new StringBuilder();
            double y;
            if (p == 0)
            {
                double x = Margin;
                if (hasLogo)
                {
                    double maxW = 120, maxH = 48, sc = Math.Min(maxW / lw, maxH / lh);
                    double w = lw * sc, h = lh * sc;
                    c.Append($"q {F(w)} 0 0 {F(h)} {F(Margin)} {F(PageH - Margin - h)} cm /Im1 Do Q\n");
                    x = Margin + w + 14;
                }
                c.Append($"BT /F3 15 Tf {F(x)} {F(PageH - Margin - 14)} Td ({Esc(Win(title))}) Tj ET\n");
                c.Append($"BT /F1 8 Tf {F(x)} {F(PageH - Margin - 28)} Td ({Esc(Win(footer))}) Tj ET\n");
                double hy = PageH - Margin - 62;
                foreach (var (k, v) in head)
                {
                    c.Append($"BT /F3 9 Tf {F(Margin)} {F(hy)} Td ({Esc(Win(k))} :) Tj ET\n");
                    c.Append($"BT /F2 9 Tf {F(Margin + 110)} {F(hy)} Td ({Esc(Win(v.Replace('\n', ' ')))}) Tj ET\n");
                    hy -= 11.5;
                }
                double ly = hy - 2;
                c.Append($"0.5 w {F(Margin)} {F(ly)} m {F(PageW - Margin)} {F(ly)} l S\n");
                y = ly - 12;
            }
            else
            {
                c.Append($"BT /F2 8 Tf {F(Margin)} {F(PageH - Margin + 4)} Td ({Esc(Win(title))}) Tj ET\n");
                c.Append($"0.4 w {F(Margin)} {F(PageH - Margin)} m {F(PageW - Margin)} {F(PageH - Margin)} l S\n");
                y = PageH - Margin - 14;
            }
            c.Append($"BT /F1 {F(FontPt)} Tf {F(Lead)} TL {F(Margin)} {F(y)} Td\n");
            foreach (var ln in pages[p]) c.Append($"({Esc(ln)}) '\n");
            c.Append("ET\n");
            c.Append($"0.4 w {F(Margin)} {F(Margin - 6)} m {F(PageW - Margin)} {F(Margin - 6)} l S\n");
            c.Append($"BT /F2 8 Tf {F(Margin)} {F(Margin - 18)} Td ({Esc(Win(footer))}) Tj ET\n");
            c.Append($"BT /F2 8 Tf {F(PageW - Margin - 60)} {F(Margin - 18)} Td (Page {p + 1} / {pages.Count}) Tj ET\n");
            var content = Latin(c.ToString());
            var h2 = Latin($"<< /Length {content.Length} >>\nstream\n");
            objs.Add(h2.Concat(content).Concat(Latin("\nendstream")).ToArray());
        }

        // ---- fichier
        using var ms = new MemoryStream();
        void W(byte[] b) => ms.Write(b, 0, b.Length);
        W(Latin("%PDF-1.4\n%âãÏÓ\n"));
        var offs = new List<long>();
        for (int i = 0; i < objs.Count; i++)
        {
            offs.Add(ms.Position);
            W(Latin($"{i + 1} 0 obj\n")); W(objs[i]); W(Latin("\nendobj\n"));
        }
        long xref = ms.Position;
        W(Latin($"xref\n0 {objs.Count + 1}\n0000000000 65535 f \n"));
        foreach (var o in offs) W(Latin(o.ToString("0000000000", inv) + " 00000 n \n"));
        W(Latin($"trailer\n<< /Size {objs.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"));
        return ms.ToArray();
    }
}
