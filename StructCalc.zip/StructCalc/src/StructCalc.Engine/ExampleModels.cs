using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public static class ExampleModels
{
    /// <summary>Portique plan (plan XZ) : 2 travées de 5 m, 2 niveaux de 3,20 m. Charges G, Q et vent W.</summary>
    public static StructModel Portal()
    {
        var m = new StructModel { Name = "Portique 2 travées / 2 niveaux", SigmaSolKPa = 200 };
        double[] xs = { 0, 5, 10 };
        double[] zs = { 0, 3.2, 6.4 };
        var grid = new int[3, 3];
        int id = 1;
        for (int iz = 0; iz < 3; iz++)
            for (int ix = 0; ix < 3; ix++)
            {
                m.Nodes.Add(new Node { Id = id, X = xs[ix], Y = 0, Z = zs[iz] });
                grid[iz, ix] = id++;
            }
        int mid = 1;
        for (int iz = 0; iz < 2; iz++)
            for (int ix = 0; ix < 3; ix++)
                m.Members.Add(new Member { Id = mid++, NodeI = grid[iz, ix], NodeJ = grid[iz + 1, ix], Type = MemberType.Column, B = 0.30, H = 0.30, Cover = 0.04 });
        for (int iz = 1; iz < 3; iz++)
            for (int ix = 0; ix < 2; ix++)
            {
                int bid = mid++;
                m.Members.Add(new Member { Id = bid, NodeI = grid[iz, ix], NodeJ = grid[iz, ix + 1], Type = MemberType.Beam, B = 0.25, H = 0.45, Cover = 0.05 });
                double g = iz == 2 ? 15 : 18, q = iz == 2 ? 3 : 6;
                m.MemberLoads.Add(new MemberLoad { MemberId = bid, Case = ActionType.G, Wz = -g });
                m.MemberLoads.Add(new MemberLoad { MemberId = bid, Case = ActionType.Q, Wz = -q });
            }
        for (int ix = 0; ix < 3; ix++) m.Supports.Add(new SupportDef { NodeId = grid[0, ix] });
        m.NodalLoads.Add(new NodalLoad { NodeId = grid[1, 0], Case = ActionType.W, Fx = 15 });
        m.NodalLoads.Add(new NodalLoad { NodeId = grid[2, 0], Case = ActionType.W, Fx = 25 });
        m.Slabs.Add(new SlabPanel { Name = "D1", Lx = 4.0, Ly = 5.0, H = 0.16, GExtra = 1.5, Q = 2.5 });
        return m;
    }

    /// <summary>Portique acier plan : 1 travée de 8 m, hauteur 4 m, avec vent W. Profils choisis automatiquement (IPE300 / HEA240 puis optimisation).</summary>
    public static StructModel SteelPortal()
    {
        var m = new StructModel { Name = "Portique acier 8 m x 4 m", SteelCodeId = "EC3", SteelFy = 275 };
        m.Nodes.Add(new Node { Id = 1, X = 0, Y = 0, Z = 0 });
        m.Nodes.Add(new Node { Id = 2, X = 0, Y = 0, Z = 4 });
        m.Nodes.Add(new Node { Id = 3, X = 8, Y = 0, Z = 4 });
        m.Nodes.Add(new Node { Id = 4, X = 8, Y = 0, Z = 0 });
        m.Members.Add(new Member { Id = 1, NodeI = 1, NodeJ = 2, Type = MemberType.Column, Kind = MaterialKind.Steel, Profile = "HEA200", LfFactor = 1.0 });
        m.Members.Add(new Member { Id = 2, NodeI = 2, NodeJ = 3, Type = MemberType.Beam, Kind = MaterialKind.Steel, Profile = "IPE240", LfFactor = 1.0 });
        m.Members.Add(new Member { Id = 3, NodeI = 4, NodeJ = 3, Type = MemberType.Column, Kind = MaterialKind.Steel, Profile = "HEA200", LfFactor = 1.0 });
        m.Supports.Add(new SupportDef { NodeId = 1 });
        m.Supports.Add(new SupportDef { NodeId = 4 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 2, Case = ActionType.G, Wz = -12 });
        m.MemberLoads.Add(new MemberLoad { MemberId = 2, Case = ActionType.Q, Wz = -8 });
        m.NodalLoads.Add(new NodalLoad { NodeId = 2, Case = ActionType.W, Fx = 12 });
        return m;
    }

    /// <summary>Projet pilote : petit bâtiment R+1 en béton armé, ossature 3D (2 x 1 travées, 2 niveaux), 4 dalles posées, semelles sous poteaux (calculées après le calcul),
    /// un escalier à deux volées et un voile. Sert de scénario complet de bout en bout (calcul, vérifications, ferraillage, export Revit, plans, note de calcul).</summary>
    public static StructModel Pilot()
    {
        var m = FrameGenerator.Generate(new FrameSpec
        {
            BaysX = 2, BaysY = 1, Storeys = 2, SpanX = 4.5, SpanY = 4.0, StoreyHeight = 3.0,
            ColB = 0.25, ColH = 0.25, BeamB = 0.25, BeamH = 0.40, G = 0, Q = 0
        });
        m.Name = "Projet pilote R+1";
        m.SigmaSolKPa = 200;
        m.Info.Client = "Projet pilote";
        for (int level = 1; level <= 2; level++)
            for (int i = 0; i < 2; i++)
                m.Slabs.Add(new SlabPanel
                {
                    Name = $"D{(level - 1) * 2 + i + 1}", Placed = true, X0 = i * 4.5, Y0 = 0, Lx = 4.5, Ly = 4.0, Z = level * 3.0, H = 0.16,
                    GExtra = 1.5, Q = level == 2 ? 1.0 : 2.5, Kind = SlabKind.Pleine
                });
        m.Stairs.Add(new StairDef { Name = "E1", Layout = StairLayout.DroitPalier, HeightM = 3.0, WidthM = 1.1, Placed = true, X = 0, Y = 5, Z = 0 });
        // voile à l'écart de l'ossature (x = 10,5 m) : posé sur les poteaux il créerait des zones d'influence superposées
        m.Walls.Add(new WallDef { Name = "V1", X = 10.5, Y = 0, Z = 0, AngleDeg = 90, LengthM = 4.0, HeightM = 3.0, ThicknessM = 0.20 });
        return m;
    }
}
