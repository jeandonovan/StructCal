using System.Net;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Licensing;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Note de calcul : HTML (imprimable en PDF), CSV (Excel), texte.</summary>
public static class ReportWriter
{
    private static string E(string s) => WebUtility.HtmlEncode(s);

    public static string ToHtml(StructModel m, AnalysisOutput o)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<!DOCTYPE html><html lang='fr'><head><meta charset='utf-8'><title>Note de calcul</title>");
        sb.AppendLine("<style>body{font-family:Segoe UI,Arial,sans-serif;margin:30px;color:#222}h1{color:#1f3a5f}h2{border-bottom:2px solid #1f3a5f;padding-bottom:3px;margin-top:28px}" +
                      "table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #bbb;padding:4px 6px;text-align:left}th{background:#e8eef6}" +
                      ".ok{color:#0a7a2f;font-weight:bold}.ko{color:#c00;font-weight:bold}.sk{color:#b36b00;font-weight:bold}pre{background:#f6f6f6;padding:8px;font-size:12px;white-space:pre-wrap}</style></head><body>");
        if (!LicenseManager.Current.IsFull)
            sb.AppendLine("<div style='position:fixed;top:38%;left:8%;font-size:72px;font-weight:bold;color:rgba(200,0,0,.13);transform:rotate(-24deg);z-index:-1'>VERSION D'ÉVALUATION</div>");
        sb.AppendLine($"<h1>Note de calcul - {E(m.Name)}</h1>");
        var inf = m.Info;
        if (inf != null && !string.IsNullOrWhiteSpace(inf.Client + inf.Site + inf.Designer + inf.Reference + inf.Revision + inf.Notes))
        {
            sb.AppendLine("<table style='width:auto;margin-bottom:10px'>");
            void Row(string k, string v) { if (!string.IsNullOrWhiteSpace(v)) sb.AppendLine($"<tr><th>{k}</th><td>{E(v)}</td></tr>"); }
            Row("Maître d'ouvrage", inf.Client); Row("Site", inf.Site); Row("Bureau d'études", inf.Designer);
            Row("Référence", inf.Reference); Row("Indice", inf.Revision); Row("Remarques", inf.Notes);
            sb.AppendLine("</table>");
        }
        sb.AppendLine($"<p>Date : {DateTime.Now:dd/MM/yyyy HH:mm}<br>Norme BA : <b>{E(o.RcCode)}</b> ; norme CM : <b>{E(o.SteelCode)}</b> ; fy = {m.SteelFy} MPa ; fc28 = {m.Fc28} MPa ; fe = {m.Fe} MPa ; " +
                      $"poids propre : {(m.IncludeSelfWeight ? "inclus" : "non inclus")} ; itérations d'optimisation : {o.Iterations}</p>");
        sb.Append(NonOkReport.ToHtml(o));
        foreach (var msg in o.Messages) sb.AppendLine($"<p>&bull; {E(msg)}</p>");

        sb.AppendLine("<h2>1. Synthèse des barres</h2><table><tr><th>Barre</th><th>Type</th><th>Section (cm)</th><th>L (m)</th><th>Mu trav.</th><th>Mu appui</th><th>Vu</th><th>Nu</th><th>Armatures inf./long.</th><th>Armatures sup.</th><th>Transversales</th><th>État</th></tr>");
        foreach (var r in o.Members)
        {
            string cls = r.Skipped ? "sk" : r.Ok ? "ok" : "ko";
            sb.AppendLine($"<tr><td>{r.MemberId}</td><td>{r.Type}</td><td>{E(r.SectionText)}</td><td>{r.Length:F2}</td><td>{r.MuSag:F1}</td><td>{r.MuHog:F1}</td><td>{r.Vu:F1}</td><td>{r.NuMax:F0}</td><td>{E(r.BarsBottom)}</td><td>{(r.Type == MemberType.Column ? "-" : E(r.BarsTop))}</td><td>{E(r.Stirrups)}</td><td class='{cls}'>{r.Status}</td></tr>");
        }
        sb.AppendLine("</table>");

        sb.AppendLine("<h2>2. Détail des calculs</h2>");
        foreach (var r in o.Members)
        {
            sb.AppendLine($"<h3>Barre {r.MemberId} - {r.Type} {E(r.SectionText)}</h3><pre>");
            foreach (var n in r.Notes) sb.AppendLine(E(n));
            foreach (var w in r.Warnings) sb.AppendLine("ATTENTION : " + E(w));
            sb.AppendLine("</pre>");
        }

        if (o.Slabs.Count > 0)
        {
            sb.AppendLine("<h2>3. Dalles</h2>");
            foreach (var s in o.Slabs) AppendDesign(sb, s);
        }
        if (o.Footings.Count > 0)
        {
            sb.AppendLine("<h2>4. Semelles</h2>");
            foreach (var s in o.Footings) AppendDesign(sb, s);
        }
        if (o.Extras.Count > 0)
        {
            sb.AppendLine("<h2>5. Escaliers, planchers, voiles et fondations (assistants)</h2>");
            foreach (var x in o.Extras)
                sb.AppendLine($"<h3>{E(x.Title)} - <span class='{(x.Ok ? "ok" : "ko")}'>{(x.Ok ? "OK" : "A VERIFIER")}</span></h3><pre>{E(x.Text)}</pre>");
        }
        sb.AppendLine(SurfaceChecks.ToHtml(o));
        sb.AppendLine(StructCalc.Engine.Detailing.SupportAnchorage.ToHtml(m, o));
        sb.AppendLine(StructCalc.Engine.Detailing.ConfinementZones.ToHtml(o));
        sb.AppendLine(DetailedSections(m, o, StructCalc.Engine.Results.ResultsStore.EnvUls, false));
        sb.AppendLine($"<p style='margin-top:30px;font-size:12px;color:#666'>Document généré automatiquement par {E(AppInfo.Banner)} - Auteur : {E(AppInfo.ContactLine)}. À vérifier par l'ingénieur responsable avant exécution.</p></body></html>");
        return sb.ToString();
    }

    /// <summary>Résultats détaillés pour le rapport : réactions, enveloppes, flèches, étages, ferraillage, poinçonnement, sismique, conformité.</summary>
    public static string DetailedSections(StructModel m, AnalysisOutput o, string source, bool everything)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<h2>Résultats détaillés</h2>");
        var tables = new List<StructCalc.Engine.Results.TableData>();
        try
        {
            if (everything) tables.AddRange(StructCalc.Engine.Results.ResultTables.All(m, o, source));
            else
            {
                var f = new StructCalc.Engine.Results.ResultFilter();
                foreach (var sp in StructCalc.Engine.Results.ResultTables.Catalog(m, o, source, f))
                    if (sp.Name is "Réactions d'appui" or "Réaction totale par cas / combinaison" or "Enveloppes ELU par barre" or "Flèches des poutres" or "Déplacements d'étage" or "Ferraillage des barres"
                        or "Poinçonnement" or "Voiles et noyaux" or "Efforts sismiques par niveau" or "Analyse modale" or "Vérifications de conformité")
                    {
                        var td = sp.Build();
                        if (td.Rows.Count > 0 || sp.Name == "Vérifications de conformité") tables.Add(td);
                    }
            }
        }
        catch (Exception ex) { sb.AppendLine($"<p>Résultats détaillés indisponibles : {E(ex.Message)}</p>"); }
        foreach (var t in tables) sb.AppendLine(t.ToHtml());
        return sb.ToString();
    }

    /// <summary>Page HTML autonome de tous les résultats détaillés (source choisie).</summary>
    public static string DetailedHtml(StructModel m, AnalysisOutput o, string source)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<!DOCTYPE html><html lang='fr'><head><meta charset='utf-8'><title>Résultats détaillés</title>");
        sb.AppendLine("<style>body{font-family:Segoe UI,Arial,sans-serif;margin:30px;color:#222}h1{color:#1f3a5f}h2{border-bottom:2px solid #1f3a5f;padding-bottom:3px;margin-top:28px}h3{margin-top:22px}" +
                      "table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #bbb;padding:3px 5px;text-align:left}th{background:#e8eef6}.ok{color:#0a7a2f;font-weight:bold}.ko{color:#c00;font-weight:bold}.sk{color:#b36b00;font-weight:bold}</style></head><body>");
        sb.AppendLine($"<h1>Résultats détaillés - {E(m.Name)}</h1><p>Source : {E(source)}</p>");
        sb.AppendLine(DetailedSections(m, o, source, true));
        sb.AppendLine("</body></html>");
        return sb.ToString();
    }

    private static void AppendDesign(StringBuilder sb, DesignResult d)
    {
        sb.AppendLine($"<h3>{E(d.Element)} - <span class='{(d.Ok ? "ok" : "ko")}'>{(d.Ok ? "OK" : "NON OK")}</span></h3><pre>");
        foreach (var n in d.Notes.Where(x => !x.StartsWith("fbu"))) sb.AppendLine(E(n));
        foreach (var t in d.Texts) sb.AppendLine($"{E(t.Key)} : {E(t.Value)}");
        foreach (var w in d.Warnings.Distinct()) sb.AppendLine("ATTENTION : " + E(w));
        sb.AppendLine("</pre>");
    }

    public static string ToCsv(AnalysisOutput o)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Barre;Type;b (cm);h (cm);L (m);Mu travee (kN.m);Mu appui (kN.m);Vu (kN);Nu (kN);As inf/long (cm2);As sup (cm2);Armatures inf/long;Armatures sup;Transversales;Etat");
        foreach (var r in o.Members)
            sb.AppendLine(string.Join(";", r.MemberId, r.Type, (r.B * 100).ToString("F0"), (r.H * 100).ToString("F0"), r.Length.ToString("F2"),
                r.MuSag.ToString("F1"), r.MuHog.ToString("F1"), r.Vu.ToString("F1"), r.NuMax.ToString("F0"),
                r.AsBottom.ToString("F2"), r.AsTop.ToString("F2"), r.BarsBottom, r.BarsTop, r.Stirrups, r.Status));
        return sb.ToString();
    }

    public static string ToText(AnalysisOutput o)
    {
        var sb = new StringBuilder();
        sb.Append(NonOkReport.ToText(o));
        foreach (var msg in o.Messages) sb.AppendLine("* " + msg);
        foreach (var group in new[] { o.Slabs, o.Footings })
            foreach (var d in group)
            {
                sb.AppendLine($"== {d.Element} : {(d.Ok ? "OK" : "NON OK")}");
                foreach (var n in d.Notes.Where(x => !x.StartsWith("fbu"))) sb.AppendLine("   " + n);
                foreach (var t in d.Texts) sb.AppendLine($"   {t.Key} : {t.Value}");
                foreach (var w in d.Warnings.Distinct()) sb.AppendLine("   ATTENTION : " + w);
            }
        foreach (var x in o.Extras)
        {
            sb.AppendLine($"== {x.Title} : {(x.Ok ? "OK" : "A VERIFIER")}");
            foreach (var line in x.Text.Split('\n')) sb.AppendLine("   " + line.TrimEnd('\r'));
        }
        foreach (var r in o.Members.Where(r => r.Warnings.Count > 0))
        {
            sb.AppendLine($"== Barre {r.MemberId} :");
            foreach (var w in r.Warnings.Distinct()) sb.AppendLine("   ATTENTION : " + w);
        }
        return sb.ToString();
    }
}
