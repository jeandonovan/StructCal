using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Combinaisons d'actions : celles de la norme, ou celles définies par l'utilisateur dans le projet.</summary>
public static class CombinationSet
{
    public static IReadOnlyList<Combination> For(StructModel m, IReadOnlyList<Combination> code)
    {
        if (!m.UseCustomCombos || m.CustomCombos.Count == 0) return code;
        return m.CustomCombos.Select(c => c.ToCombination()).ToList();
    }

    /// <summary>Copie les combinaisons de la norme dans la liste modifiable du projet.</summary>
    public static List<CustomCombo> FromCode(IEnumerable<Combination> code) =>
        code.Select(c => new CustomCombo
        {
            Name = c.Name, State = c.State,
            G = c.Factors.GetValueOrDefault(ActionType.G), Q = c.Factors.GetValueOrDefault(ActionType.Q),
            W = c.Factors.GetValueOrDefault(ActionType.W), S = c.Factors.GetValueOrDefault(ActionType.S), E = c.Factors.GetValueOrDefault(ActionType.E)
        }).ToList();
}

/// <summary>Contrôle indicatif de stabilité d'ensemble à partir des réactions d'appui : soulèvement, excentrement de la résultante, glissement.</summary>
public static class StabilityCheck
{
    public static ExtraDesign? Compute(StructModel m, IReadOnlyList<Combination> combos, Dictionary<ActionType, CaseResult> cases)
    {
        if (m.Supports.Count == 0 || combos.Count == 0) return null;
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var sup = m.Supports.Where(s => nodes.ContainsKey(s.NodeId)).ToList();
        if (sup.Count == 0) return null;
        double xmin = sup.Min(s => nodes[s.NodeId].X), xmax = sup.Max(s => nodes[s.NodeId].X);
        double ymin = sup.Min(s => nodes[s.NodeId].Y), ymax = sup.Max(s => nodes[s.NodeId].Y);
        double xc = (xmin + xmax) / 2, yc = (ymin + ymax) / 2, bx = xmax - xmin, by = ymax - ymin;
        double mu = m.BaseFriction > 0 ? m.BaseFriction : 0.5;
        const double fsReq = 1.5;
        var sb = new StringBuilder();
        sb.AppendLine("CONTRÔLE DE STABILITÉ D'ENSEMBLE (indicatif, d'après les réactions d'appui)");
        sb.AppendLine($"Emprise des appuis : {bx:0.00} m x {by:0.00} m ; coefficient de frottement semelle/sol μ = {mu:0.00} ; coefficient de sécurité au glissement exigé ≥ {fsReq:0.0}.");
        bool ok = true;
        double worstFs = double.MaxValue, worstEx = 0, worstEy = 0; string wFs = "", wEx = "", wUp = "";
        double minFz = double.MaxValue;
        var serv = combos.Where(c => c.State == LimitState.ELS).ToList();
        if (serv.Count == 0) serv = combos.ToList();
        foreach (var c in serv)
        {
            double fx = 0, fy = 0, fz = 0, mx = 0, my = 0, minNode = double.MaxValue;
            foreach (var s in sup)
            {
                double rx = 0, ry = 0, rz = 0;
                foreach (var kv in c.Factors)
                {
                    if (kv.Value == 0 || !cases.TryGetValue(kv.Key, out var cr) || !cr.Reactions.TryGetValue(s.NodeId, out var rr) || rr.Length < 3) continue;
                    rx += kv.Value * rr[0]; ry += kv.Value * rr[1]; rz += kv.Value * rr[2];
                }
                fx += rx; fy += ry; fz += rz;
                var n = nodes[s.NodeId];
                mx += rz * (n.Y - yc); my += rz * (n.X - xc);
                minNode = Math.Min(minNode, rz);
            }
            if (minNode < minFz) { minFz = minNode; wUp = c.Name; }
            double h = Math.Sqrt(fx * fx + fy * fy);
            if (h > 1e-6 && fz > 0)
            {
                double fs = mu * fz / h;
                if (fs < worstFs) { worstFs = fs; wFs = c.Name; }
            }
            if (fz > 1e-6)
            {
                double ex = my / fz, ey = mx / fz;
                if (Math.Abs(ex) > Math.Abs(worstEx)) { worstEx = ex; wEx = c.Name; }
                if (Math.Abs(ey) > Math.Abs(worstEy)) { worstEy = ey; }
            }
        }
        sb.AppendLine();
        if (minFz < -1e-6)
        {
            ok = false;
            sb.AppendLine($"✖ Soulèvement : un appui est en traction ({minFz:0.0} kN) pour « {wUp} » : prévoir un lestage ou un ancrage des fondations.");
        }
        else sb.AppendLine($"✔ Aucun soulèvement : réaction verticale minimale d'un appui = {minFz:0.0} kN.");
        if (worstFs == double.MaxValue) sb.AppendLine("✔ Glissement : pas d'effort horizontal d'ensemble significatif.");
        else
        {
            bool g = worstFs >= fsReq; ok &= g;
            sb.AppendLine($"{(g ? "✔" : "✖")} Glissement : coefficient de sécurité minimal = {worstFs:0.00} (combinaison « {wFs} »), exigé ≥ {fsReq:0.0}.");
        }
        if (bx > 1e-6 && by > 1e-6)
        {
            double rx = Math.Abs(worstEx) / bx, ry = Math.Abs(worstEy) / by;
            bool core = rx <= 1.0 / 6 && ry <= 1.0 / 6;
            sb.AppendLine($"{(core ? "✔" : "⚠")} Excentrement de la résultante verticale : e,x = {worstEx:0.00} m ({rx * 100:0}% de la largeur), e,y = {worstEy:0.00} m ({ry * 100:0}% de la largeur) ; limite du noyau central = 17%." +
                          (core ? "" : " L'ensemble tend à se soulever d'un côté : vérifier le renversement."));
        }
        sb.AppendLine();
        sb.AppendLine("Le frottement sol/béton et l'excentrement sont à ajuster aux données géotechniques (Propriétés du projet).");
        return new ExtraDesign { Title = "Stabilité d'ensemble", Text = sb.ToString(), Ok = ok };
    }
}
