using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine;

/// <summary>Critères du filtre de sélection (tous les critères actifs se cumulent : ET).</summary>
public sealed class SelectionFilterSpec
{
    public bool Beams { get; set; } = true;
    public bool Columns { get; set; } = true;
    public bool Concrete { get; set; } = true;
    public bool Steel { get; set; } = true;
    public bool AlongX { get; set; } = true;          // barres horizontales parallèles à X
    public bool AlongY { get; set; } = true;          // barres horizontales parallèles à Y
    public bool Vertical { get; set; } = true;
    public bool Inclined { get; set; } = true;        // toute autre direction
    public HashSet<int>? Levels { get; set; }          // indices de niveaux (barres dont le nœud le plus bas est à ce niveau) ; null = tous
    public string Section { get; set; } = "";          // texte contenu dans la section ou le profilé (« 30x50 », « IPE »...)
    public double MinLength { get; set; } = 0;
    public double MaxLength { get; set; } = 0;         // 0 = pas de limite
    public bool FailingOnly { get; set; }              // barres non conformes après calcul
    public double MinUtilization { get; set; } = 0;    // taux minimal (0 à 1+), après calcul
    public string Ids { get; set; } = "";              // liste « 1-5, 9, 12 »
    public int Loads { get; set; }                     // 0 = indifférent, 1 = avec charge, 2 = sans charge
}

public static class SelectionFilter
{
    private static List<int> ParseIds(string? text)
    {
        var res = new List<int>();
        foreach (var tok in (text ?? "").Split(new[] { ' ', ',', ';', '\t' }, StringSplitOptions.RemoveEmptyEntries))
        {
            var p = tok.Split('-');
            if (p.Length == 2 && int.TryParse(p[0], out int a) && int.TryParse(p[1], out int b) && b >= a && b - a < 20000) for (int i = a; i <= b; i++) res.Add(i);
            else if (int.TryParse(tok, out int v)) res.Add(v);
        }
        return res;
    }

    /// <summary>Barres vérifiant tous les critères, parmi baseIds (ou tout le modèle si baseIds est null).</summary>
    public static List<int> Apply(StructModel m, AnalysisOutput? o, SelectionFilterSpec f, IEnumerable<int>? baseIds = null)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var info = f.Levels != null ? StructureAnalyzer.Analyze(m) : null;
        HashSet<int>? only = baseIds == null ? null : new HashSet<int>(baseIds);
        var ids = string.IsNullOrWhiteSpace(f.Ids) ? null : new HashSet<int>(ParseIds(f.Ids));
        var loaded = new HashSet<int>(LoadExpander.MemberLoadsOf(m).Select(l => l.MemberId));
        string sec = (f.Section ?? "").Trim().ToLowerInvariant().Replace(" ", "");
        var res = new List<int>();
        foreach (var mem in m.Members)
        {
            if (only != null && !only.Contains(mem.Id)) continue;
            if (ids != null && !ids.Contains(mem.Id)) continue;
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            bool col = mem.Type == MemberType.Column;
            if (col && !f.Columns) continue;
            if (!col && !f.Beams) continue;
            bool steel = mem.Kind == MaterialKind.Steel;
            if (steel && !f.Steel) continue;
            if (!steel && !f.Concrete) continue;
            double dx = b.X - a.X, dy = b.Y - a.Y, dz = b.Z - a.Z, L = Math.Sqrt(dx * dx + dy * dy + dz * dz);
            bool vert = Math.Abs(dx) < 1e-3 && Math.Abs(dy) < 1e-3;
            bool ax = Math.Abs(dz) < 1e-3 && Math.Abs(dy) < 1e-3 && Math.Abs(dx) >= 1e-3;
            bool ay = Math.Abs(dz) < 1e-3 && Math.Abs(dx) < 1e-3 && Math.Abs(dy) >= 1e-3;
            bool ok = vert ? f.Vertical : ax ? f.AlongX : ay ? f.AlongY : f.Inclined;
            if (!ok) continue;
            if (L < f.MinLength - 1e-9) continue;
            if (f.MaxLength > 0 && L > f.MaxLength + 1e-9) continue;
            if (sec.Length > 0)
            {
                string txt = (steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}").ToLowerInvariant().Replace(" ", "");
                var r0 = o?.Members.FirstOrDefault(r => r.MemberId == mem.Id);
                if (r0 != null) txt += "|" + (r0.SectionText ?? "").ToLowerInvariant().Replace(" ", "");
                if (!txt.Contains(sec)) continue;
            }
            if (f.Levels != null && info != null)
            {
                int lv = info.MemberLevel.TryGetValue(mem.Id, out int li) ? li : -1;
                if (!f.Levels.Contains(lv)) continue;
            }
            if (f.Loads == 1 && !loaded.Contains(mem.Id)) continue;
            if (f.Loads == 2 && loaded.Contains(mem.Id)) continue;
            if (f.FailingOnly || f.MinUtilization > 0)
            {
                var r = o?.Members.FirstOrDefault(x => x.MemberId == mem.Id);
                if (r == null || r.Skipped) continue;
                if (f.FailingOnly && r.Ok) continue;
                if (r.Utilization < f.MinUtilization) continue;
            }
            res.Add(mem.Id);
        }
        return res;
    }
}
