namespace StructCalc.Engine;

/// <summary>Un pli contrôlé d'une barre : angle, rayon réel/minimal, longueurs droites, poussée au vide, statut.</summary>
public sealed record BendCheckResult(string BendType, double AngleDeg, double RReal, double RMin, double StrBefore, double StrAfter, double StrMin,
                                     string Direction, string Risk, string Status, string Comment);

/// <summary>Contrôles d'armatures purs (sans Revit) : longueur d'ancrage et de recouvrement (BAEL A.6.1,22) et cintrage. Utilisés par le complément Revit et testés dans le projet de tests.</summary>
public static class RebarChecks
{
    /// <summary>« Vérifiée » si disponible ≥ requis, « À la limite » si ≥ 90 % du requis, sinon « Non vérifiée ».</summary>
    public static string Verdict(double avail, double req) => avail >= req - 1e-6 ? "Vérifiée" : avail >= 0.9 * req ? "À la limite" : "Non vérifiée";

    /// <summary>Longueur d'ancrage de scellement droit : ls = phi.fe / (4 tau_su), tau_su = 0,6 psi_s² ft28, psi_s = 1,5 (HA). Retourne (ls en mm, tau_su en MPa, fsd en MPa).</summary>
    public static (double Ls, double Tau, double Fsd) Anchorage(int dia, double fe, double fc)
    {
        double ft28 = 0.6 + 0.06 * fc, tau = 0.6 * 1.5 * 1.5 * ft28;
        return (dia * fe / (4 * tau), tau, fe / 1.15);
    }

    /// <summary>Recouvrement requis : lr = ls (barres au même niveau, espacement ≤ 5 phi).</summary>
    public static double LapLength(int dia, double fe, double fc) => Anchorage(dia, fe, fc).Ls;

    /// <summary>Mandrin minimal : 4 phi (phi ≤ 16 mm) ou 7 phi ; le rayon minimal est la moitié.</summary>
    public static double MinBendRadius(int dia) => (dia <= 16 ? 4.0 : 7.0) * dia / 2;

    private static (double X, double Y, double Z) Sub((double X, double Y, double Z) a, (double X, double Y, double Z) b) => (a.X - b.X, a.Y - b.Y, a.Z - b.Z);
    private static double Len((double X, double Y, double Z) a) => Math.Sqrt(a.X * a.X + a.Y * a.Y + a.Z * a.Z);
    private static (double X, double Y, double Z) Unit((double X, double Y, double Z) a) { double l = Len(a); return l > 1e-9 ? (a.X / l, a.Y / l, a.Z / l) : (1, 0, 0); }
    private static double Dot((double X, double Y, double Z) a, (double X, double Y, double Z) b) => a.X * b.X + a.Y * b.Y + a.Z * b.Z;

    /// <summary>Contrôle chaque pli d'une barre polyligne (points en mm). nearFaceOut : direction de la face de béton la plus proche (vers l'extérieur) ;
    /// bendDiaMm : diamètre de cintrage du type d'armature (0 = inconnu).</summary>
    public static List<BendCheckResult> Bends(int dia, IList<(double X, double Y, double Z)> polyMm, (double X, double Y, double Z) nearFaceOut, double bendDiaMm,
                                              double coverMm, double coverMinMm, bool tension, bool hasTransverse, bool closedLoop = false)
    {
        var res = new List<BendCheckResult>();
        int n = polyMm.Count;
        if (n < 3) return res;
        double phi = dia, rMin = MinBendRadius(dia), rReal = bendDiaMm > 0 ? bendDiaMm / 2 : 0;
        var lens = new List<double>(); var dirs = new List<(double X, double Y, double Z)>();
        for (int i = 0; i + 1 < n; i++) { var d = Sub(polyMm[i + 1], polyMm[i]); lens.Add(Len(d)); dirs.Add(Unit(d)); }
        var theta = new double[n];
        for (int i = 1; i < n - 1; i++) theta[i] = Math.Acos(Math.Clamp(Dot(dirs[i - 1], dirs[i]), -1, 1));
        double Tan(int i) => i >= 1 && i <= n - 2 ? Math.Max(rReal, rMin) * Math.Tan(theta[i] / 2) : 0;
        for (int i = 1; i < n - 1; i++)
        {
            double deg = theta[i] * 180 / Math.PI;
            if (deg < 5) continue;
            bool endLeg = i == 1 || i == n - 2;
            string type = closedLoop ? "Cadre (coin)" : deg >= 80 ? (endLeg ? "Équerre / retour d'extrémité" : "Pliage à angle droit") : "Pliage de rupture de pente";
            double before = lens[i - 1] - Tan(i - 1) - Tan(i), after = lens[i] - Tan(i) - Tan(i + 1);
            double strMin = deg >= 45 ? 5 * phi : 0;
            var inward = Sub(dirs[i], dirs[i - 1]);
            bool outward = tension && !closedLoop && Len(inward) > 1e-9 && Dot(Unit(inward), nearFaceOut) > 0.15;
            var bad = new List<string>(); var chk = new List<string>();
            if (rReal <= 0) chk.Add("rayon de cintrage du type d'armature inconnu");
            else if (rReal < rMin - 0.5) bad.Add($"rayon {rReal:0} mm < {rMin:0} mm");
            if (strMin > 0 && before < strMin - 0.5) bad.Add($"longueur droite avant {before:0} mm < {strMin:0} mm");
            if (strMin > 0 && after < strMin - 0.5) bad.Add($"longueur droite après {after:0} mm < {strMin:0} mm");
            if (coverMm + 0.5 < coverMinMm) bad.Add($"cintrage trop proche du parement ({coverMm:0} mm < {coverMinMm:0} mm)");
            if (outward && !hasTransverse) bad.Add("barre tendue pliée vers l'extérieur sans étriers/épingles");
            else if (outward) chk.Add("poussée au vide à confirmer");
            string status = bad.Count > 0 ? "Non conforme" : chk.Count > 0 ? "À vérifier" : "Conforme";
            res.Add(new BendCheckResult(type, deg, rReal, rMin, before, after, strMin,
                tension ? "Traction fibre " + (nearFaceOut.Z < 0 ? "inférieure" : "supérieure") : "Maintien / confinement",
                outward ? (hasTransverse ? "Poussée au vide - équilibrée par étriers/épingles" : "Poussée au vide - NON équilibrée") : "Aucune (pliage vers l'intérieur)",
                status, string.Join(" ; ", bad.Concat(chk))));
        }
        return res;
    }
}
