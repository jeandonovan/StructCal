using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Famille d'un message : détermine le comportement du clic droit (correction, diagnostic, solutions de dimensionnement, affichage seul).</summary>
public enum MsgFamily { Modele, Calcul, Dimensionnement, Information }

/// <summary>Origine du message.</summary>
public enum MsgSource { Modele, Calcul, Dimensionnement, Journal, Revit }

/// <summary>Un message de la liste unique : vérification du modèle, moteur de calcul, alerte de dimensionnement, information.</summary>
public sealed class AppMessage
{
    public string Key { get; set; } = "";
    public MsgFamily Family { get; set; }
    public MsgSource Source { get; set; }
    public IssueLevel Level { get; set; }
    /// <summary>Erreur qui empêche le calcul (erreurs de modèle).</summary>
    public bool Blocking { get; set; }
    public string Category { get; set; } = "";
    public string ElementKind { get; set; } = "";
    public string ElementLabel { get; set; } = "";
    public string Position { get; set; } = "";
    public string Text { get; set; } = "";
    public string Combo { get; set; } = "";
    public int? NodeId { get; set; }
    public int? MemberId { get; set; }
    /// <summary>Objet visé : ModelIssue, MemberDesignResult, DesignResult, PunchingResult, ExtraDesign, int[] (nœuds), DeflectionRow, DriftRow...</summary>
    public object? Subject { get; set; }
    public DateTime Time { get; set; } = DateTime.Now;

    public string LevelText => Blocking ? "Erreur bloquante" : Level == IssueLevel.Error ? "Erreur" : Level == IssueLevel.Warning ? "Avertissement" : "Information";
    public string SourceText => Source switch
    {
        MsgSource.Modele => "Modèle", MsgSource.Calcul => "Calcul", MsgSource.Dimensionnement => "Dimensionnement", MsgSource.Revit => "Revit", _ => "Journal"
    };
}

/// <summary>Assemble tous les messages du logiciel en une seule liste classée par famille, niveau, source, catégorie et élément.</summary>
public static class MessageCenter
{
    private static readonly Regex MemberRx = new(@"[Bb]arre\s+(\d+)", RegexOptions.Compiled);
    private static readonly Regex NodeRx = new(@"[Nn]œud\s+(\d+)", RegexOptions.Compiled);
    private static readonly Regex WarnRx = new(@"non réalisée|indisponible|impossible|inconnue|non disponible|ATTENTION|[Ee]rreur|instab|insuffisant|annulé", RegexOptions.Compiled);
    private static readonly Regex SlabRx = new(@"^Dalle\s+(\S+)", RegexOptions.Compiled);

    private static string Pos(double x, double y, double z) => $"({x:0.00} ; {y:0.00} ; {z:0.00})";

    private static string MemberPos(StructModel m, int id)
    {
        var mem = m.Members.FirstOrDefault(q => q.Id == id);
        if (mem == null) return "";
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        return a == null || b == null ? "" : Pos((a.X + b.X) / 2, (a.Y + b.Y) / 2, (a.Z + b.Z) / 2);
    }

    private static string NodePos(StructModel m, int id)
    {
        var n = m.Nodes.FirstOrDefault(q => q.Id == id);
        return n == null ? "" : Pos(n.X, n.Y, n.Z);
    }

    private static string SlabPos(SlabPanel s) => Pos(s.X0 + s.Lx / 2, s.Y0 + s.Ly / 2, s.Z);

    private static string CategoryOfCode(string code) => code switch
    {
        "NODE_DUP" or "NODE_ISOLATED" or "NODE_OVERLAP" or "MEM_DUP" or "MEM_NODE_MISSING" or "MEM_SAME_NODES" or "MEM_ZERO" => "Géométrie",
        "SEC_INVALID" or "COVER_BIG" or "BEAM_SHORT" or "PROFILE_UNKNOWN" or "SHELL_THIN" => "Section",
        "LOAD_MEM_MISSING" or "LOAD_OUTSIDE" or "LOAD_TRAP_OUT" or "LOAD_TRAP_ZERO" or "NLOAD_NODE" or "NO_LOAD" or "SURF_OVERLAP" => "Charge",
        "SURF_NOBEAM" or "SURF_FREE_EDGES" or "SURF_PARTIAL" => "Dalle / charge de surface",
        "SUPPORT_NODE" or "NO_SUPPORT" or "MECHANISM" or "UNSUPPORTED" => "Appui / stabilité",
        "SLAB_DIM" or "SLAB_THIN" or "SLAB_EDGE" or "SLAB_OVERLAP" => "Dalle",
        "SHELL_NODE" => "Maillage",
        _ => "Modèle"
    };

    private static string KindOfSubject(object? s) => s switch
    {
        SlabPanel => "Dalle", SurfaceLoad => "Charge de surface", MemberLoad => "Charge de barre", NodalLoad => "Charge nodale",
        SupportDef => "Appui", ShellPanel => "Coque", int[] => "Nœuds", _ => ""
    };

    /// <summary>Message issu de la vérification du modèle (avant calcul).</summary>
    public static AppMessage FromIssue(StructModel m, ModelIssue i)
    {
        var msg = new AppMessage
        {
            Key = i.Code + "|" + i.Message,
            Family = MsgFamily.Modele, Source = MsgSource.Modele, Level = i.Level, Blocking = i.Level == IssueLevel.Error,
            Category = CategoryOfCode(i.Code), Text = i.Message, NodeId = i.NodeId, MemberId = i.MemberId, Subject = i
        };
        if (i.MemberId is int mid) { msg.ElementKind = "Barre"; msg.ElementLabel = "Barre " + mid; msg.Position = MemberPos(m, mid); }
        else if (i.NodeId is int nid) { msg.ElementKind = "Nœud"; msg.ElementLabel = "Nœud " + nid; msg.Position = NodePos(m, nid); }
        switch (i.Subject)
        {
            case SlabPanel s: msg.ElementKind = "Dalle"; msg.ElementLabel = "Dalle " + s.Name; msg.Position = SlabPos(s); break;
            case SurfaceLoad sl: msg.ElementKind = "Charge de surface"; msg.ElementLabel = sl.Name; break;
            case int[] ns when ns.Length > 0: msg.ElementKind = "Nœuds"; msg.ElementLabel = "Nœuds " + string.Join(", ", ns.Take(4)) + (ns.Length > 4 ? "…" : ""); msg.Position = NodePos(m, ns[0]); break;
            case MemberLoad ml when msg.ElementKind == "": msg.ElementKind = "Charge de barre"; msg.ElementLabel = "Charge sur barre " + ml.MemberId; break;
            case ShellPanel sh: msg.ElementKind = "Coque"; msg.ElementLabel = "Coque " + sh.Name; break;
            default:
                if (msg.ElementKind == "") { msg.ElementKind = KindOfSubject(i.Subject); }
                break;
        }
        return msg;
    }

    private static string MemberCategory(MemberDesignResult r)
    {
        string w = string.Join(" ", r.Warnings).ToLowerInvariant();
        if (w.Contains("élanc") || w.Contains("flambement")) return "Stabilité (élancement)";
        if (w.Contains("tau") || w.Contains("tranchant") || w.Contains("v_ed")) return "Effort tranchant";
        if (w.Contains("flèche")) return "Flèche";
        if (w.Contains("flexion") || w.Contains("as >") || w.Contains("ferraill") || w.Contains("armature")) return "Ferraillage";
        return "Section";
    }

    /// <summary>Liste complète des messages. <paramref name="journal"/> : lignes du journal ; <paramref name="advices"/> : conseils de réglage.</summary>
    public static List<AppMessage> Build(StructModel m, AnalysisOutput? o, IEnumerable<ModelIssue> issues, IEnumerable<string> advices, IEnumerable<string> journal)
    {
        var L = new List<AppMessage>();
        foreach (var i in issues) L.Add(FromIssue(m, i));

        var seenCalc = new HashSet<string>();
        if (o != null)
        {
            // ---- dimensionnement : barres
            foreach (var r in o.Members)
            {
                string pos = MemberPos(m, r.MemberId);
                if (r.Skipped)
                {
                    L.Add(new AppMessage
                    {
                        Key = $"CALC|Norme|barre {r.MemberId} non traitée", Family = MsgFamily.Calcul, Source = MsgSource.Calcul, Level = IssueLevel.Warning, Category = "Norme",
                        ElementKind = "Barre", ElementLabel = "Barre " + r.MemberId, Position = pos, MemberId = r.MemberId, Subject = r,
                        Text = $"Barre {r.MemberId} non traitée : {(r.Warnings.Count > 0 ? r.Warnings[0] : "norme indisponible")}"
                    });
                    continue;
                }
                if (!r.Ok)
                {
                    string typ = r.Type == MemberType.Column ? "Poteau" : "Poutre";
                    string why = r.Warnings.Count > 0 ? " " + r.Warnings[0] : "";
                    string combo = "";
                    try { combo = DesignFixes.Critical(o, r.MemberId).MomentCombo; } catch { }
                    L.Add(new AppMessage
                    {
                        Key = $"DIM|{MemberCategory(r)}|barre {r.MemberId}", Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error,
                        Category = MemberCategory(r), ElementKind = "Barre", ElementLabel = "Barre " + r.MemberId, Position = pos, MemberId = r.MemberId, Subject = r, Combo = combo,
                        Text = $"{typ} {r.MemberId} ({r.SectionText}) NON OK : taux de travail {r.Utilization * 100:0} %." + why
                    });
                }
                else
                    foreach (var w in r.Warnings)
                        L.Add(new AppMessage
                        {
                            Key = $"DIM|Avertissement|barre {r.MemberId}|{w}", Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Warning,
                            Category = "Avertissement de calcul", ElementKind = "Barre", ElementLabel = "Barre " + r.MemberId, Position = pos, MemberId = r.MemberId, Subject = r,
                            Text = $"Barre {r.MemberId} : {w}"
                        });
            }
            // ---- dalles
            foreach (var s in o.Slabs.Where(x => !x.Ok))
            {
                var mt = SlabRx.Match(s.Element ?? "");
                var slab = mt.Success ? m.Slabs.FirstOrDefault(q => q.Name == mt.Groups[1].Value) : null;
                L.Add(new AppMessage
                {
                    Key = "DIM|Dalle|" + s.Element, Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Dalle",
                    ElementKind = "Dalle", ElementLabel = slab is { } sp ? "Dalle " + sp.Name : (s.Element ?? ""), Position = slab != null ? SlabPos(slab) : "", Subject = s,
                    Combo = DesignFixes.SlabCombo,
                    Text = $"{s.Element} NON OK : " + (s.Warnings.Count > 0 ? string.Join(" ", s.Warnings) : "section ou ferraillage insuffisant.")
                });
            }
            // ---- semelles
            foreach (var f in o.Footings.Where(x => !x.Ok))
            {
                int nid = StructCalc.Engine.Geometry.FootingPlacement.NodeIdOf(f.Element);
                L.Add(new AppMessage
                {
                    Key = "DIM|Semelle|" + f.Element, Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Semelle / sol",
                    ElementKind = "Semelle", ElementLabel = f.Element, NodeId = nid > 0 ? nid : null, Position = nid > 0 ? NodePos(m, nid) : "", Subject = f,
                    Text = $"{f.Element} NON OK : " + (f.Warnings.Count > 0 ? string.Join(" ", f.Warnings) : "capacité portante insuffisante.")
                });
            }
            // ---- poinçonnement
            foreach (var p in o.Punching.Where(x => !x.Ok))
                L.Add(new AppMessage
                {
                    Key = $"DIM|Poinçonnement|{p.Column}|{p.Slab}", Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Poinçonnement",
                    ElementKind = "Dalle / poteau", ElementLabel = $"{p.Column} / dalle {p.Slab}", Position = Pos(p.X, p.Y, p.Z), Subject = p,
                    Text = $"Poinçonnement NON OK : {p.Column} sous la dalle {p.Slab} ({p.Position}) : v_Ed = {p.StressEd:0.00} MPa pour v_Rd,max = {p.StressRdMax:0.00} MPa, taux {Math.Max(p.Util, p.UtilMax) * 100:0} %."
                });
            // ---- autres modules (escaliers, voiles, radiers, planchers, coques, consoles, stabilité...)
            foreach (var x in o.Extras.Where(e => !e.Ok))
            {
                string line = (x.Text ?? "").Split('\n').Select(t => t.Trim()).FirstOrDefault(t => t.Contains("NON OK") || t.Contains("ATTENTION") || t.Contains("non vérifi") || t.Contains("insuffisan")) ?? "";
                L.Add(new AppMessage
                {
                    Key = "DIM|Module|" + x.Title, Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Module : " + x.Title.Split(' ')[0],
                    ElementKind = "Module", ElementLabel = x.Title, Subject = x,
                    Text = $"{x.Title} NON OK" + (line != "" ? " : " + line : " (voir l'onglet Dalles / Semelles / Alertes).")
                });
            }
            // ---- global : flèches et déplacements inter-étages
            if (o.Global != null)
            {
                foreach (var d in o.Global.Deflections.Where(q => !q.Ok))
                    L.Add(new AppMessage
                    {
                        Key = $"DIM|Flèche|barre {d.MemberId}", Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Flèche",
                        ElementKind = "Barre", ElementLabel = "Barre " + d.MemberId, Position = MemberPos(m, d.MemberId), MemberId = d.MemberId, Subject = d, Combo = d.Combo,
                        Text = $"Barre {d.MemberId} : flèche de service {d.DeltaMm:0.0} mm > limite {d.LimitMm:0.0} mm (L/{d.Ratio:0})."
                    });
                foreach (var d in o.Global.Drifts.Where(q => !q.Ok))
                    L.Add(new AppMessage
                    {
                        Key = $"DIM|Stabilité|{d.Level}", Family = MsgFamily.Dimensionnement, Source = MsgSource.Dimensionnement, Level = IssueLevel.Error, Category = "Stabilité (déplacement d'étage)",
                        ElementKind = "Niveau", ElementLabel = "Niveau " + d.Level, Subject = d, Combo = d.Combo,
                        Text = $"Niveau {d.Level} : déplacement inter-étage {d.DeltaMm:0.0} mm, h/δ = {d.Ratio:0} < {d.LimitDenominator:0} ({d.Basis})."
                    });
                AddAnomalies(m, o, L);
            }
            // ---- messages du moteur de calcul
            foreach (var raw in o.Messages)
            {
                string line = raw.TrimEnd();
                if (line.Trim().Length == 0 || line.Contains("NON OK") || line.TrimStart().StartsWith("ATTENTION")) continue;      // déjà représentés ci-dessus
                if (!seenCalc.Add(line)) continue;
                bool warn = WarnRx.IsMatch(line);
                var msg = new AppMessage
                {
                    Key = "CALC|" + line, Family = warn ? MsgFamily.Calcul : MsgFamily.Information, Source = MsgSource.Calcul, Level = warn ? IssueLevel.Warning : IssueLevel.Info,
                    Category = line.StartsWith("Itération") ? "Optimisation" : warn ? "Moteur de calcul" : "Hypothèse / information", Text = line.Trim()
                };
                var mm = MemberRx.Match(line); var nm = NodeRx.Match(line);
                if (mm.Success && int.TryParse(mm.Groups[1].Value, out int mid)) { msg.MemberId = mid; msg.ElementKind = "Barre"; msg.ElementLabel = "Barre " + mid; msg.Position = MemberPos(m, mid); }
                else if (nm.Success && int.TryParse(nm.Groups[1].Value, out int nid)) { msg.NodeId = nid; msg.ElementKind = "Nœud"; msg.ElementLabel = "Nœud " + nid; msg.Position = NodePos(m, nid); }
                L.Add(msg);
            }
        }
        // ---- conseils et journal
        foreach (var a in advices)
            L.Add(new AppMessage { Key = "JRN|Conseil|" + a, Family = MsgFamily.Information, Source = MsgSource.Journal, Level = IssueLevel.Info, Category = "Conseil de réglage", Text = a });
        foreach (var raw in journal)
        {
            string line = raw.Trim();
            if (line.Length == 0 || line.StartsWith("Conseil : ") || (o != null && o.Messages.Any(q => q.Trim() == line))) continue;
            bool revit = line.Contains("Revit");
            bool warn = WarnRx.IsMatch(line);
            L.Add(new AppMessage
            {
                Key = "JRN|" + line, Family = MsgFamily.Information, Source = revit ? MsgSource.Revit : MsgSource.Journal, Level = warn ? IssueLevel.Warning : IssueLevel.Info,
                Category = revit ? "Complément Revit" : "Journal", Text = line
            });
        }
        return L;
    }

    /// <summary>Déplacements et rotations anormalement grands (garde-fous sur un modèle qui « calcule » mais qui est peut-être mal posé).</summary>
    private static void AddAnomalies(StructModel m, AnalysisOutput o, List<AppMessage> L)
    {
        var g = o.Global!;
        if (m.Nodes.Count == 0) return;
        double dx = m.Nodes.Max(n => n.X) - m.Nodes.Min(n => n.X), dy = m.Nodes.Max(n => n.Y) - m.Nodes.Min(n => n.Y), dz = m.Nodes.Max(n => n.Z) - m.Nodes.Min(n => n.Z);
        double size = Math.Max(1.0, Math.Max(dx, Math.Max(dy, dz)));
        double warnMm = size * 1000 / 200.0, errMm = size * 1000 / 50.0;
        foreach (var d in g.Displacements.Where(q => q.Total > warnMm).OrderByDescending(q => q.Total).Take(3))
            L.Add(new AppMessage
            {
                Key = $"CALC|Déplacement|nœud {d.NodeId}", Family = MsgFamily.Calcul, Source = MsgSource.Calcul, Level = d.Total > errMm ? IssueLevel.Error : IssueLevel.Warning,
                Category = "Déplacement anormal", ElementKind = "Nœud", ElementLabel = "Nœud " + d.NodeId, Position = NodePos(m, d.NodeId), NodeId = d.NodeId, Subject = new[] { d.NodeId }, Combo = d.Combo,
                Text = $"Nœud {d.NodeId} : déplacement anormalement grand ({d.Total:0.0} mm, soit 1/{size * 1000 / Math.Max(d.Total, 1e-9):0} de la plus grande dimension de la structure). Cherchez une barre trop souple, un appui manquant ou une charge démesurée."
            });
        foreach (var kv in g.Deformed)
        {
            if (kv.Value.Length < 6) continue;
            double rot = Math.Sqrt(kv.Value[3] * kv.Value[3] + kv.Value[4] * kv.Value[4] + kv.Value[5] * kv.Value[5]);
            if (rot <= 0.03) continue;
            L.Add(new AppMessage
            {
                Key = $"CALC|Rotation|nœud {kv.Key}", Family = MsgFamily.Calcul, Source = MsgSource.Calcul, Level = rot > 0.1 ? IssueLevel.Error : IssueLevel.Warning,
                Category = "Rotation anormale", ElementKind = "Nœud", ElementLabel = "Nœud " + kv.Key, Position = NodePos(m, kv.Key), NodeId = kv.Key, Subject = new[] { kv.Key }, Combo = g.DeformedCombo,
                Text = $"Nœud {kv.Key} : rotation anormalement grande ({rot:0.000} rad, {rot * 180 / Math.PI:0.0}°). Vérifiez les libérations, les appuis et la rigidité des barres reliées."
            });
            if (L.Count(q => q.Category == "Rotation anormale") >= 3) break;
        }
    }
}
