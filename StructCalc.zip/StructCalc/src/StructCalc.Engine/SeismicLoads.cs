using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed class SeismicResult
{
    public List<NodalLoad> Loads { get; } = new();
    public string Info { get; set; } = "";
    public double BaseShear { get; set; }
    public double Period { get; set; }
    public double TotalWeight { get; set; }
}

/// <summary>Force sismique statique équivalente (RPA 99 v2003 art. 4.2 ou EC8 4.3.3.2), appliquée comme cas E aux noeuds de chaque niveau.
/// Simplifications : une seule direction, répartition égale sur les noeuds d'un niveau, pas de torsion accidentelle, période par formule empirique
/// (pas d'analyse modale), régularité supposée.</summary>
public static class SeismicLoads
{
    private static readonly Dictionary<string, double> RpaA = new()
    {
        { "1A|I", 0.15 }, { "1A|IIa", 0.25 }, { "1A|IIb", 0.30 }, { "1A|III", 0.40 },
        { "1B|I", 0.12 }, { "1B|IIa", 0.20 }, { "1B|IIb", 0.25 }, { "1B|III", 0.30 },
        { "2|I", 0.10 },  { "2|IIa", 0.15 },  { "2|IIb", 0.20 },  { "2|III", 0.25 },
        { "3|I", 0.07 },  { "3|IIa", 0.10 },  { "3|IIb", 0.14 },  { "3|III", 0.18 },
    };
    private static readonly Dictionary<string, (double t1, double t2)> RpaSite = new()
    {
        { "S1", (0.15, 0.30) }, { "S2", (0.15, 0.40) }, { "S3", (0.15, 0.50) }, { "S4", (0.15, 0.70) },
    };
    private static readonly Dictionary<string, (double S, double TB, double TC, double TD)> Ec8Ground = new()
    {
        { "A", (1.00, 0.15, 0.40, 2.0) }, { "B", (1.20, 0.15, 0.50, 2.0) }, { "C", (1.15, 0.20, 0.60, 2.0) },
        { "D", (1.35, 0.20, 0.80, 2.0) }, { "E", (1.40, 0.15, 0.50, 2.0) },
    };

    public static double RpaD(double T, string site, double xiPercent)
    {
        double eta = Math.Max(0.7, Math.Sqrt(7.0 / (2.0 + xiPercent)));
        double t2 = RpaSite.TryGetValue(site, out var v) ? v.t2 : 0.5;
        if (T <= t2) return 2.5 * eta;
        if (T <= 3.0) return 2.5 * eta * Math.Pow(t2 / T, 2.0 / 3.0);
        return 2.5 * eta * Math.Pow(t2 / 3.0, 2.0 / 3.0) * Math.Pow(3.0 / T, 5.0 / 3.0);
    }

    /// <summary>Ordonnée Sd(T)/g du spectre de calcul EC8 type 1.</summary>
    public static double Ec8Sd(double T, double agOverG, string ground, double q)
    {
        var g = Ec8Ground.TryGetValue(ground, out var v) ? v : Ec8Ground["B"];
        double sd;
        if (T <= g.TB) sd = agOverG * g.S * (2.0 / 3.0 + T / g.TB * (2.5 / q - 2.0 / 3.0));
        else if (T <= g.TC) sd = agOverG * g.S * 2.5 / q;
        else if (T <= g.TD) sd = agOverG * g.S * 2.5 / q * (g.TC / T);
        else sd = agOverG * g.S * 2.5 / q * (g.TC * g.TD / (T * T));
        return Math.Max(sd, 0.2 * agOverG);
    }

    /// <summary>Spectre de calcul RPA 99 v2003 art. 4.3.3 : Sa/g en fonction de la période T.</summary>
    public static double RpaSpectrum(StructModel m, double T)
    {
        var sp = m.Seismic;
        double A = RpaA.TryGetValue($"{sp.Group}|{sp.Zone}", out var a0) ? a0 : 0.15;
        var (t1, t2) = RpaSite.TryGetValue(sp.Site, out var v) ? v : (0.15, 0.5);
        double eta = Math.Max(0.7, Math.Sqrt(7.0 / (2.0 + sp.XiPercent)));
        double qr = sp.Q / sp.R;
        if (T <= t1) return 1.25 * A * (1 + T / t1 * (2.5 * eta * qr - 1));
        if (T <= t2) return 2.5 * eta * 1.25 * A * qr;
        if (T <= 3.0) return 2.5 * eta * 1.25 * A * qr * Math.Pow(t2 / T, 2.0 / 3.0);
        return 2.5 * eta * 1.25 * A * qr * Math.Pow(t2 / 3.0, 2.0 / 3.0) * Math.Pow(3.0 / T, 5.0 / 3.0);
    }

    /// <summary>Sa/g du spectre de calcul de la norme choisie (RPA 99 ou EC8 type 1).</summary>
    public static double SpectrumOverG(StructModel m, double T)
    {
        var sp = m.Seismic;
        return sp.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase)
            ? Ec8Sd(T, sp.AgOverG * sp.ImportanceGamma, sp.Ground, sp.BehaviorQ)
            : RpaSpectrum(m, T);
    }

    public static SeismicResult Compute(StructModel m, double? periodOverride = null)
    {
        var res = new SeismicResult();
        var sp = m.Seismic;
        bool ec8 = sp.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase);
        double psi = ec8 ? sp.PsiE : sp.Beta;

        var nodes = m.Nodes.ToDictionary(n => n.Id);
        double zmin = m.Nodes.Min(n => n.Z), zmax = m.Nodes.Max(n => n.Z);
        double hn = zmax - zmin;
        if (hn < 0.5) { res.Info = "Séisme ignoré : hauteur du bâtiment nulle."; return res; }

        // poids par niveau (kN) : moitié de chaque barre à chaque extrémité + charges nodales verticales
        var weight = new Dictionary<long, double>();
        long Key(double z) => (long)Math.Round(z * 1000.0);
        void Add(Node n, double w) { long k = Key(n.Z); weight[k] = (weight.TryGetValue(k, out var v) ? v : 0) + w; }

        var allMemberLoads = LoadExpander.MemberLoadsOf(m);
        foreach (var mem in m.Members)
        {
            var a = nodes[mem.NodeI]; var b = nodes[mem.NodeJ];
            double L = Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
            double wz = 0;
            var (_, Rm) = FrameSolver.LocalAxes(a, b, mem.Roll);
            foreach (var l in allMemberLoads.Where(l => l.MemberId == mem.Id))
            {
                double down = -LoadMath.VerticalResultant(l, L, Rm) / L;       // kN/m équivalents, vers le bas positif
                if (l.Case == ActionType.G) wz += down;
                else if (l.Case == ActionType.Q) wz += psi * down;
            }
            if (m.IncludeSelfWeight)
            {
                bool rc = mem.Kind == MaterialKind.ReinforcedConcrete;
                double area = mem.PropA > 0 ? mem.PropA : mem.B * mem.H;
                if (!rc && mem.PropA <= 0 && StructCalc.Core.Steel.SteelCatalog.TryGet(mem.Profile, out var pr)) area = pr.A;
                wz += (rc ? 25.0 : 78.5) * area;
            }
            Add(a, wz * L / 2); Add(b, wz * L / 2);
        }
        foreach (var l in m.NodalLoads)
        {
            if (!nodes.TryGetValue(l.NodeId, out var n)) continue;
            if (l.Case == ActionType.G) Add(n, -l.Fz);
            else if (l.Case == ActionType.Q) Add(n, psi * -l.Fz);
        }
        foreach (var kv in ShellFem.NodalWeights(m, psi))
            if (nodes.TryGetValue(kv.Key, out var sn)) Add(sn, kv.Value);

        var levels = weight.Where(kv => kv.Key > Key(zmin)).OrderBy(kv => kv.Key).ToList();
        double W = levels.Sum(kv => kv.Value);
        res.TotalWeight = W;
        if (W <= 0) { res.Info = "Séisme : poids sismique nul (aucune charge verticale)."; return res; }

        double Tempirical = sp.Ct * Math.Pow(hn, 0.75);
        double T = Tempirical;
        string periodSrc = "";
        if (periodOverride.HasValue && periodOverride.Value > 0.02)
        {
            T = periodOverride.Value;
            periodSrc = $" (période de l'analyse modale ; formule empirique : {Tempirical:F2} s)";
        }
        res.Period = T;
        double V;
        string info;
        if (ec8)
        {
            double sd = Ec8Sd(T, sp.AgOverG * sp.ImportanceGamma, sp.Ground, sp.BehaviorQ);
            double lambda = (T <= 2 * (Ec8Ground.TryGetValue(sp.Ground, out var g) ? g.TC : 0.5) && levels.Count > 2) ? 0.85 : 1.0;
            V = sd * W * lambda;
            info = $"Séisme EC8 (force latérale) : T1={T:F2} s, Sd/g={sd:F3}, lambda={lambda}, W={W:F0} kN, Fb={V:F0} kN";
        }
        else
        {
            double A = RpaA.TryGetValue($"{sp.Group}|{sp.Zone}", out var a0) ? a0 : 0.15;
            double D = RpaD(T, sp.Site, sp.XiPercent);
            V = A * D * sp.Q * W / sp.R;
            info = $"Séisme RPA99 : A={A:F2}, D={D:F2}, Q={sp.Q}, R={sp.R}, T={T:F2} s, W={W:F0} kN, V={V:F0} kN";
        }
        res.BaseShear = V;
        res.Info = info + periodSrc;

        // répartition : Ft au sommet (RPA, T>0.7 s) + répartition triangulaire en W_i h_i
        double ft = (!ec8 && T > 0.7) ? Math.Min(0.07 * T * V, 0.25 * V) : 0;
        double sumWh = levels.Sum(kv => kv.Value * (kv.Key / 1000.0 - zmin));
        foreach (var kv in levels)
        {
            double h = kv.Key / 1000.0 - zmin;
            double Fi = (V - ft) * kv.Value * h / sumWh + (kv.Key == levels.Last().Key ? ft : 0);
            var onLevel = m.Nodes.Where(n => Key(n.Z) == kv.Key).ToList();
            foreach (var n in onLevel)
            {
                var nl = new NodalLoad { NodeId = n.Id, Case = ActionType.E };
                if (sp.Direction == SeismicDirection.X) nl.Fx = Fi / onLevel.Count; else nl.Fy = Fi / onLevel.Count;
                res.Loads.Add(nl);
            }
        }
        return res;
    }
}
