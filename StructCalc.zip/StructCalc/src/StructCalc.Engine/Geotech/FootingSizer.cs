using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Geotech;

public sealed class FootingSizing
{
    public DesignResult Design { get; set; } = new();
    public string Report { get; set; } = "";
    public double A { get; set; }
    public double B { get; set; }
    public double H { get; set; }
    public double QAdm { get; set; }
    public double SigmaMax { get; set; }
    public double SettlementMm { get; set; }
    public double ConcreteM3 { get; set; }
    public double SteelKg { get; set; }
    public bool Ok => Design.Ok;
}

/// <summary>Dimensionnement de semelles (isolée / filante) en tenant compte du sol : capacité portante avec excentrement, couche sous-jacente, tassement ; ferraillage par la méthode des bielles.</summary>
public static class FootingSizer
{
    private static double Ceil5(double v) => Math.Ceiling(v / 0.05 - 1e-9) * 0.05;

    public static FootingSizing Design(FootingDef fIn, SoilProfile soil, IReinforcedConcreteCode rc, double fc28, double fe, double coverM, DesignSettings? cfg = null)
    {
        var f = fIn.WithWallLoads();
        var dr = new DesignResult { Element = $"Semelle {f.Name}" };
        var o = new FootingSizing { Design = dr };
        var sb = new StringBuilder();
        bool strip = f.Kind == FootingKind.Filante;
        double D = f.DepthM > 0 ? f.DepthM : soil.FoundationDepthM;
        double a = f.ColA, b = strip ? 1.0 : f.ColB;
        bool useSoil = soil.Enabled && f.QAdmOverrideKPa <= 0;
        if (!useSoil && f.QAdmOverrideKPa <= 0) { dr.Fail("Aucun sol défini : renseignez la coupe de sol ou une contrainte admissible."); o.Report = "Sol non défini."; return o; }

        sb.AppendLine($"{(strip ? "SEMELLE FILANTE" : "SEMELLE ISOLÉE")} {f.Name} - profondeur d'assise D = {D:0.00} m");
        sb.AppendLine($"Charges : Nu = {f.NuKN:0.#} kN{(strip ? "/m" : "")}, Nser = {f.NserKN:0.#} kN{(strip ? "/m" : "")}" + (strip ? "" : $", Ma = {f.MaKNm:0.#}, Mb = {f.MbKNm:0.#} kN.m (ELS)"));
        foreach (var w in fIn.WallLoads) sb.AppendLine($"  dont charge linéaire « {w.Text} » : G = {w.GKnM:0.##}, Q = {w.QKnM:0.##} kN/m");
        if (useSoil)
        {
            foreach (var l in soil.Layers) sb.AppendLine($"  Sol : {l.Name} {(l.ThicknessM > 0 ? l.ThicknessM.ToString("0.0#") + " m" : "(semi-infinie)")}, γ = {l.GammaKnM3:0.#}/{l.GammaSatKnM3:0.#} kN/m³, φ = {l.PhiDeg:0.#}°, c = {l.CKPa:0.#} kPa, Eoed = {l.EoedMPa:0.#} MPa");
            sb.AppendLine(soil.WaterDepthM >= 0 ? $"  Nappe à {soil.WaterDepthM:0.0#} m du terrain naturel ; Fs = {soil.FsServ:0.#}" : $"  Pas de nappe ; Fs = {soil.FsServ:0.#}");
        }
        else sb.AppendLine($"Contrainte admissible imposée : {f.QAdmOverrideKPa:0} kPa");
        sb.AppendLine();

        // --- dimensions
        double A = f.FixedA > 0 ? f.FixedA : Math.Max(Ceil5(a + 0.10), 0.6);
        double B = strip ? 1.0 : (f.FixedB > 0 ? f.FixedB : Math.Max(Ceil5(b + 0.10), 0.6));
        double ratio = strip ? 0 : (a > 0 && b > 0 ? a / b : 1);
        double h = 0.30, qadm = 0, sigmax = 0, settle = 0; string noteB = "", noteU = ""; double eA = 0, eB = 0;
        bool ok = false;
        var lastCauses = new List<string>();
        for (int it = 0; it < 400; it++)
        {
            double dNeed = strip ? (A - a) / 4 : Math.Max((A - a) / 4, (B - b) / 4);
            h = Math.Max(0.30, Ceil5(dNeed + coverM));
            double W = 25.0 * A * B * h;
            // poids des terres sur la semelle et surcharge de remblai
            double fill = useSoil ? EffFill(soil, D, h) * (A * B) : 18.0 * Math.Max(D - h, 0) * A * B;
            double Ntot = f.NserKN + W + fill;
            if (strip) Ntot = f.NserKN + 25.0 * A * h + (useSoil ? EffFill(soil, D, h) : 18.0 * Math.Max(D - h, 0)) * A;
            eA = f.MaKNm / Math.Max(Ntot, 1e-6); eB = strip ? 0 : f.MbKNm / Math.Max(Ntot, 1e-6);
            double Ae = A - 2 * Math.Abs(eA), Be = strip ? 1.0 : B - 2 * Math.Abs(eB);
            if (Ae <= 0.2 || Be <= 0.2) { lastCauses = new List<string> { "excentrement excessif : la surface efficace de la semelle devient trop petite" }; Grow(ref A, ref B, ratio, strip, f); continue; }
            double Bmin = Math.Min(Ae, Be), Lmax = strip ? 10 * Ae : Math.Max(Ae, Be);
            double qa;
            if (useSoil) { var br = SoilMechanics.Bearing(soil, strip ? Ae : Bmin, strip ? 100 : Lmax, D); qa = br.QAdm; noteB = br.Note; }
            else { qa = f.QAdmOverrideKPa; noteB = "contrainte admissible imposée"; }
            qadm = qa;
            // contrainte appliquée (Meyerhof) : N / (A' B')
            double area = strip ? Ae : Ae * Be;
            double sigEff = Ntot / area;
            // contrainte maximale (distribution linéaire, sans traction)
            sigmax = strip ? Ntot / A * (1 + 6 * Math.Abs(eA) / A) : Ntot / (A * B) * (1 + 6 * Math.Abs(eA) / A + 6 * Math.Abs(eB) / B);
            bool tension = Math.Abs(eA) > A / 6 + 1e-9 || (!strip && Math.Abs(eB) > B / 6 + 1e-9);
            if (tension) { lastCauses = new List<string> { "excentrement / stabilité : la résultante sort du noyau central (décollement sous la semelle)" }; Grow(ref A, ref B, ratio, strip, f); continue; }
            double sigDesign = Math.Min(sigmax, sigEff);
            // vérification de l'effet de l'excentrement : sigma moyen (3σmax+σmin)/4 <= qadm
            double sigmin = strip ? Ntot / A * (1 - 6 * Math.Abs(eA) / A) : Ntot / (A * B) * (1 - 6 * Math.Abs(eA) / A - 6 * Math.Abs(eB) / B);
            double sig34 = (3 * sigmax + Math.Max(sigmin, 0)) / 4;
            bool okQ = Math.Max(sigEff, sig34) <= qa + 1e-9;
            _ = sigDesign;
            double ratioU = 0; noteU = "";
            if (useSoil) (ratioU, noteU) = SoilMechanics.Underlying(soil, A, strip ? 1.0 : B, D, Ntot / (A * (strip ? 1.0 : B)));
            bool okU = ratioU <= 1.0;
            double qNet = Ntot / (A * (strip ? 1.0 : B)) - (useSoil ? SoilMechanics.EffectiveStress(soil, D) : 0);
            bool okS = true; settle = 0;
            if (useSoil && soil.CheckSettlement)
            {
                var st = SoilMechanics.Settlement(soil, A, strip ? Math.Max(A * 10, 10) : B, D, Math.Max(qNet, 0));
                settle = st.TotalMm; okS = settle <= soil.SettlementLimitMm;
            }
            lastCauses = new List<string>();
            if (!okQ) lastCauses.Add($"contrainte admissible dépassée : {Math.Max(sigEff, sig34):0} kPa > q_adm = {qa:0} kPa");
            if (!okU) lastCauses.Add($"couche sous-jacente surchargée (taux {ratioU:0.00} > 1)");
            if (!okS) lastCauses.Add($"tassement excessif : {settle:0.0} mm > {soil.SettlementLimitMm:0} mm");
            if (okQ && okU && okS) { ok = true; break; }
            Grow(ref A, ref B, ratio, strip, f);
            if (f.FixedA > 0 && (strip || f.FixedB > 0)) break;
        }
        string cause = lastCauses.Count > 0 ? string.Join(" ; ", lastCauses) : "dimensions imposées insuffisantes";
        if (!ok)
        {
            dr.Fail("Impossible de satisfaire la capacité portante / le tassement avec des dimensions raisonnables (ou dimensions imposées insuffisantes). Cause : " + cause + ".");
            dr.Texts["Cause du NON OK"] = cause;
        }
        // trace des hypothèses géotechniques utilisées pour ce résultat
        var hyp = new StringBuilder();
        hyp.Append($"profondeur d'assise D = {D:0.00} m ; Nu = {f.NuKN:0.#} kN, Nser = {f.NserKN:0.#} kN, Ma = {f.MaKNm:0.#}, Mb = {f.MbKNm:0.#} kN.m ; ");
        if (useSoil) hyp.Append("sol : " + string.Join(" / ", soil.Layers.Select(l => $"{l.Name} γ={l.GammaKnM3:0.#} φ={l.PhiDeg:0.#}° c={l.CKPa:0.#} kPa Eoed={l.EoedMPa:0.#} MPa")) +
                                 $" ; nappe {(soil.WaterDepthM >= 0 ? soil.WaterDepthM.ToString("0.0#") + " m" : "absente")} ; Fs = {soil.FsServ:0.#} ; tassement {(soil.CheckSettlement ? "limité à " + soil.SettlementLimitMm.ToString("0") + " mm" : "non vérifié")}");
        else hyp.Append($"contrainte admissible imposée = {f.QAdmOverrideKPa:0} kPa");
        hyp.Append($" ; fc28 = {fc28:0.#} MPa, fe = {fe:0} MPa, enrobage {coverM * 100:0} cm");
        dr.Texts["Hypothèses géotechniques"] = hyp.ToString();

        o.A = A; o.B = B; o.H = h; o.QAdm = qadm; o.SigmaMax = sigmax; o.SettlementMm = settle;
        double d = h - coverM;
        sb.AppendLine($"Capacité portante : {noteB}");
        sb.AppendLine($"  q_adm (ELS) = {qadm:0} kPa ; σmax = {sigmax:0} kPa ; excentricités eA = {eA:0.000} m, eB = {eB:0.000} m");
        if (noteU != "") sb.AppendLine("  Diffusion à 27° : " + noteU);
        if (useSoil && soil.CheckSettlement) sb.AppendLine($"  Tassement œdométrique ≈ {settle:0.0} mm (limite {soil.SettlementLimitMm:0} mm)");
        sb.AppendLine($"Dimensions : A x B = {A:0.00} x {(strip ? "1.00 (par m)" : B.ToString("0.00"))} m, h = {h:0.00} m, d = {d:0.00} m");

        // --- ferraillage (bielles)
        double fsu = fe / 1.15, ft = 0.6 + 0.06 * fc28;
        double ss = Math.Min(2.0 / 3 * fe, Math.Max(0.5 * fe, 110 * Math.Sqrt(1.6 * ft)));
        double nu = f.NuKN / 1000, ns = f.NserKN / 1000;
        double kEA = 1 + 3 * Math.Abs(f.MaKNm / Math.Max(f.NserKN, 1e-6)) / A;     // majoration pour excentrement (σ à A/4)
        double kEB = strip ? 1 : 1 + 3 * Math.Abs(f.MbKNm / Math.Max(f.NserKN, 1e-6)) / B;
        double asAU = nu * kEA * (A - a) / (8 * d * fsu) * 1e4, asAS = ns * kEA * (A - a) / (8 * d * ss) * 1e4;
        double asA, asB;
        if (strip)
        {
            asA = Math.Max(Math.Max(asAU, asAS), 0.23 * 1.0 * d * ft / fe * 1e4);
            asB = asA / 4;     // armatures de répartition longitudinales (≥ As/4)
        }
        else
        {
            double asBU = nu * kEB * (B - b) / (8 * d * fsu) * 1e4, asBS = ns * kEB * (B - b) / (8 * d * ss) * 1e4;
            asA = Math.Max(Math.Max(asAU, asAS), 0.23 * B * d * ft / fe * 1e4);
            asB = Math.Max(Math.Max(asBU, asBS), 0.23 * A * d * ft / fe * 1e4);
        }
        // poinçonnement (vérification simplifiée BAEL A.5.2,42 pour semelles isolées) : non nécessaire si la méthode des bielles est applicable (d ≥ (A-a)/4)
        sb.AppendLine($"Ferraillage (bielles, d ≥ (A-a)/4) : nappe // A : {asA:0.00} cm²{(strip ? "/m" : "")} ; {(strip ? "armatures de répartition" : "nappe // B")} : {asB:0.00} cm²{(strip ? "/m" : "")}");
        var sa = RebarSelector.Spacing(strip ? asA : asA / B, 25, cfg);
        var sbb = RebarSelector.Spacing(strip ? asB : asB / A, 25, cfg);
        dr.Texts["Nappe // A"] = $"HA{sa.Dia} e={sa.SpacingCm:F0} cm";
        dr.Texts["Nappe // B"] = $"HA{sbb.Dia} e={sbb.SpacingCm:F0} cm";
        sb.AppendLine($"  Nappe // A : HA{sa.Dia} e = {sa.SpacingCm:0} cm ; Nappe // B : HA{sbb.Dia} e = {sbb.SpacingCm:0} cm");
        dr.Values["A_m"] = A; dr.Values["B_m"] = B; dr.Values["h_m"] = h; dr.Values["d_m"] = d;
        dr.Values["As_A_cm2"] = asA; dr.Values["As_B_cm2"] = asB; dr.Values["sigma_ser_kPa"] = sigmax;
        dr.Values["q_adm_kPa"] = qadm; dr.Values["settlement_mm"] = settle;
        dr.Notes.Add($"A x B = {A:0.00} x {B:0.00} m, h = {h:0.00} m ; q_adm = {qadm:0} kPa ; tassement {settle:0.0} mm");
        if (!dr.Ok)
        {
            sb.AppendLine("ATTENTION : " + string.Join(" ", dr.Warnings));
            sb.AppendLine("CAUSE DU NON OK : " + (dr.Texts.TryGetValue("Cause du NON OK", out var cz) ? cz : string.Join(" ", dr.Warnings)));
            sb.AppendLine("Pistes (à décider par l'ingénieur ; rien n'est modifié automatiquement) : augmenter la surface ou la profondeur d'assise, améliorer ou remplacer le sol, réduire les charges, changer de type de fondation (radier, pieux).");
        }
        sb.AppendLine("HYPOTHÈSES GÉOTECHNIQUES : " + dr.Texts["Hypothèses géotechniques"]);
        sb.AppendLine("Dispositions : béton de propreté 5 cm, enrobage ≥ 5 cm, crochets ou ancrage droit selon ls ; vérifier la portance du poinçonnement si h < (A-a)/4.");

        double vol = A * (strip ? 1.0 : B) * h;
        if (f.Glacis && !strip)
        {
            // --- vérifications propres au glacis : épaisseur au bord et effort tranchant sur la section réelle (plus mince que h)
            double e = StructCalc.Engine.Geometry.FootingSolids.EdgeThickness(h, f.GlacisEdgeCm);
            double pa = Math.Min(A, a + 2 * StructCalc.Engine.Geometry.FootingSolids.PlateauMargin) / 2, pb = Math.Min(B, b + 2 * StructCalc.Engine.Geometry.FootingSolids.PlateauMargin) / 2;
            double Thick(double y, double half, double plat)   // épaisseur à la distance y du bord, demi-dimension half, demi-plateau plat
            {
                double run = half - plat;
                return run <= 1e-6 || y >= run ? h : e + (h - e) * y / run;
            }
            double q = nu / (A * B);                              // contrainte ELU moyenne (MN/m²)
            double tauLim = 0.07 * fc28 / 1.5;                    // BAEL A.5.2,2 : sans armatures d'effort tranchant
            string worst = "";
            double worstRatio = 0;
            foreach (var (nm, len, col, plat, other) in new[] { ("A", A, a, pa, B), ("B", B, b, pb, A) })
            {
                double y = len / 2 - col / 2 - d;                // section à d de la face du poteau, comptée depuis le bord
                if (y <= 0) continue;
                double hs = Thick(y, len / 2, plat), ds = Math.Max(hs - coverM, 0.05);
                double vu = q * y * other;                       // MN
                double tau = vu / (other * ds);
                double rr = tau / tauLim;
                worst += $"  sens {nm} : section à d = {d * 100:0} cm de la face, épaisseur locale {hs * 100:0} cm, τu = {tau:0.00} MPa (limite {tauLim:0.00}) -> {rr:0.00}\n";
                worstRatio = Math.Max(worstRatio, rr);
            }
            sb.Append("Vérification du glacis (effort tranchant sur la section épaissie) :\n" + worst);
            if (f.GlacisEdgeCm < StructCalc.Engine.Geometry.FootingSolids.MinEdge * 100 - 1e-9)
                { sb.AppendLine($"  Épaisseur au bord saisie {f.GlacisEdgeCm:0} cm portée à {e * 100:0} cm (minimum {StructCalc.Engine.Geometry.FootingSolids.MinEdge * 100:0} cm ; 25 cm conseillés en bâtiment courant)."); }
            // ancrage des nappes : épaisseur au bord ≥ 6 Φ + 6 cm
            int phiMax = Math.Max(sa.Dia, sbb.Dia);
            double eMin = (0.6 * phiMax + 6) / 100.0;
            sb.AppendLine($"  Ancrage des nappes : épaisseur au bord {e * 100:0} cm pour 6Φ + 6 cm = {eMin * 100:0} cm (Φ{phiMax}).");
            if (e < eMin - 1e-9) dr.Fail($"Glacis : épaisseur au bord {e * 100:0} cm < 6Φ + 6 cm = {eMin * 100:0} cm (ancrage des nappes).");
            // poinçonnement au nu du poteau (BAEL A.5.2,42) : Qu' ≤ 0,045 uc h fc28/γb, contour à h/2 de la face du poteau
            {
                double uc = 2 * (a + b + 2 * h), inside = (a + h) * (b + h);
                if (a + h <= A && b + h <= B)
                {
                    double qMoy = f.NuKN / (A * B);
                    double quP = Math.Max(0, f.NuKN - qMoy * inside);
                    double qLimP = 0.045 * uc * h * fc28 / 1.5 * 1000.0;
                    sb.AppendLine($"  Poinçonnement au nu du poteau : Qu' = {quP:0} kN pour 0,045 uc h fc28/γb = {qLimP:0} kN (uc = {uc:0.00} m) -> {(quP <= qLimP ? "vérifié" : "NON vérifié")}.");
                    if (quP > qLimP) dr.Fail("Glacis : poinçonnement au nu du poteau non vérifié ; augmentez la hauteur h.");
                }
            }
            if (worstRatio > 1.0 + 1e-9) dr.Fail("Glacis : effort tranchant excessif sur la section amincie ; augmentez l'épaisseur au bord ou réduisez le glacis.");
            dr.Values["glacis"] = 1; dr.Values["glacis_edge_m"] = e; dr.Values["glacis_tau_ratio"] = worstRatio;
            dr.Notes.Add($"Glacis : bord {e * 100:0} cm, plateau {pa * 200:0} x {pb * 200:0} cm (poteau + {StructCalc.Engine.Geometry.FootingSolids.PlateauMargin * 100:0} cm de chaque côté), τ/τlim = {worstRatio:0.00}");
            double vg = StructCalc.Engine.Geometry.FootingSolids.Volume(A, B, h, a, b, true, f.GlacisEdgeCm);
            sb.AppendLine($"Semelle à glacis : épaisseur au bord {StructCalc.Engine.Geometry.FootingSolids.EdgeThickness(h, f.GlacisEdgeCm) * 100:0} cm, dessus en pente jusqu'à un plateau de {pa * 200:0} x {pb * 200:0} cm ; volume de béton {vg:0.000} m³ (bloc : {vol:0.000} m³).");
            vol = vg;
        }
        else if (f.Glacis) sb.AppendLine("Glacis ignoré pour une semelle filante (bloc rectangulaire).");
        o.ConcreteM3 = vol;
        o.SteelKg = strip ? (asA * A + asB) * 0.785 : (asA * A + asB * B) * 0.785;
        o.Report = sb.ToString();
        return o;
    }

    private static double EffFill(SoilProfile s, double D, double h) => D > h ? FillWeight(s, D, h) : 0;

    /// <summary>Poids des terres au-dessus de la semelle par m² (de la surface à la face supérieure).</summary>
    private static double FillWeight(SoilProfile s, double D, double h) => SoilMechanics.EffectiveStress(s, D - h);

    private static void Grow(ref double A, ref double B, double ratio, bool strip, FootingDef f)
    {
        if (strip) { if (f.FixedA <= 0) A += 0.05; return; }
        if (f.FixedA <= 0 && f.FixedB <= 0)
        {
            if (A >= B * ratio || ratio <= 0) { A += 0.05; B = Math.Max(B, Ceil5(A / Math.Max(ratio, 0.01))); }
            else B += 0.05;
            A = Math.Max(A, Ceil5(B * ratio));
        }
        else { if (f.FixedA <= 0) A += 0.05; if (f.FixedB <= 0) B += 0.05; }
    }
}
