using StructCalc.Core.Model;

namespace StructCalc.Engine.Geotech;

public sealed class BearingResult
{
    public double Qu { get; set; }            // contrainte de rupture (kPa)
    public double QNet { get; set; }
    public double QAdm { get; set; }          // contrainte admissible ELS (kPa)
    public double Q0 { get; set; }            // contrainte verticale au niveau de la base (kPa)
    public double Nq { get; set; }
    public double Nc { get; set; }
    public double Ng { get; set; }
    public string Note { get; set; } = "";
}

public sealed class SettlementResult
{
    public double TotalMm { get; set; }
    public double DepthM { get; set; }
    public List<string> Lines { get; } = new();
}

/// <summary>Mécanique des sols : capacité portante (Terzaghi/Meyerhof/Vesic, formules DTU 13.12), diffusion à 27°, tassement œdométrique.</summary>
public static class SoilMechanics
{
    private const double Gw = 10.0;           // poids volumique de l'eau (kN/m³)

    public static (double Nq, double Nc, double Ng) Factors(double phiDeg)
    {
        double p = phiDeg * Math.PI / 180;
        if (phiDeg < 0.5) return (1.0, 5.14, 0.0);
        double nq = Math.Exp(Math.PI * Math.Tan(p)) * Math.Pow(Math.Tan(Math.PI / 4 + p / 2), 2);
        double nc = (nq - 1) / Math.Tan(p);
        double ng = 2 * (nq + 1) * Math.Tan(p);          // Vesic
        return (nq, nc, ng);
    }

    /// <summary>Couche contenant la profondeur z (m depuis le terrain naturel) et son épaisseur restante.</summary>
    public static SoilLayer LayerAt(SoilProfile s, double z)
    {
        double top = 0;
        foreach (var l in s.Layers)
        {
            double bot = l.ThicknessM <= 0 ? double.MaxValue : top + l.ThicknessM;
            if (z < bot - 1e-9) return l;
            top = bot;
        }
        return s.Layers[^1];
    }

    private static double GammaAt(SoilProfile s, double z)
    {
        var l = LayerAt(s, z);
        return s.WaterDepthM >= 0 && z >= s.WaterDepthM ? l.GammaSatKnM3 - Gw : l.GammaKnM3;
    }

    /// <summary>Contrainte verticale effective (kPa) à la profondeur z, par intégration des couches.</summary>
    public static double EffectiveStress(SoilProfile s, double z)
    {
        double sig = 0; const double dz = 0.05;
        for (double t = 0; t < z - 1e-9; t += dz)
        {
            double h = Math.Min(dz, z - t);
            sig += GammaAt(s, t + h / 2) * h;
        }
        return sig;
    }

    /// <summary>Capacité portante d'une semelle de base B' x L' (dimensions effectives) posée à la profondeur D, sur la couche en place.</summary>
    public static BearingResult Bearing(SoilProfile s, double Beff, double Leff, double D)
    {
        var l = LayerAt(s, D);
        var (nq, nc, ng) = Factors(l.PhiDeg);
        double q0 = EffectiveStress(s, D);
        double ratio = Math.Min(1.0, Beff / Math.Max(Leff, Beff));
        double tanp = Math.Tan(l.PhiDeg * Math.PI / 180);
        double sq = 1 + ratio * tanp, sg = 1 - 0.4 * ratio, sc = l.PhiDeg < 0.5 ? 1 + 0.2 * ratio : 1 + ratio * nq / nc;
        // poids volumique sous la base (jusqu'à B sous la semelle)
        double gammaBelow = 0; int n = 0;
        for (double z = D + Beff / 8; z < D + Beff; z += Beff / 4) { gammaBelow += GammaAt(s, z); n++; }
        gammaBelow = n > 0 ? gammaBelow / n : GammaAt(s, D);
        // facteur de profondeur de Hansen limité pour rester prudent
        double k = Math.Min(D / Math.Max(Beff, 0.1), 1.0);
        double dq = 1 + 2 * tanp * Math.Pow(1 - Math.Sin(l.PhiDeg * Math.PI / 180), 2) * Math.Atan(k) ;
        if (l.PhiDeg < 0.5) dq = 1;
        double dc = l.PhiDeg < 0.5 ? 1 + 0.4 * Math.Atan(k) : dq - (1 - dq) / (nc * Math.Max(tanp, 1e-6));
        dc = Math.Max(dc, 1.0);
        double qu = 0.5 * gammaBelow * Beff * ng * sg + q0 * (nq * sq * dq) + l.CKPa * nc * sc * dc;
        if (l.PhiDeg < 0.5) qu = l.CKPa * nc * sc * dc + q0;
        var r = new BearingResult { Qu = qu, Q0 = q0, Nq = nq, Nc = nc, Ng = ng };
        r.QNet = qu - q0;
        r.QAdm = r.QNet / s.FsServ + q0;
        r.Note = $"couche « {l.Name} » (φ = {l.PhiDeg:0.#}°, c = {l.CKPa:0.#} kPa) : Nq = {nq:0.00}, Nc = {nc:0.00}, Nγ = {ng:0.00} ; q0 = {q0:0.0} kPa";
        return r;
    }

    /// <summary>Vérification de la couche sous-jacente par diffusion des charges à 27° (pente 2:1) : retourne le rapport q_appliquée / q_adm de cette couche, la plus défavorable.</summary>
    public static (double Ratio, string Note) Underlying(SoilProfile s, double A, double B, double D, double qBase)
    {
        double worst = 0; string note = "";
        double top = 0;
        foreach (var l in s.Layers)
        {
            double bot = l.ThicknessM <= 0 ? double.MaxValue : top + l.ThicknessM;
            if (bot > D + 1e-9 && top > D - 1e-9 && top > D)
            {
                double z = top - D;
                if (z > 2 * Math.Min(A, B)) break;
                double A2 = A + z, B2 = B + z;
                double qApp = qBase * A * B / (A2 * B2);
                var br = Bearing(s, B2, A2, top);
                double ratio = (qApp + EffectiveStress(s, top) - br.Q0) / Math.Max(br.QAdm - br.Q0, 1e-6);
                if (ratio > worst) { worst = ratio; note = $"couche « {l.Name} » à {z:0.00} m sous la base : q diffusée = {qApp:0} kPa (semelle fictive {A2:0.00} x {B2:0.00}) ≤ {br.QAdm - br.Q0:0} kPa ?"; }
            }
            top = bot;
        }
        return (worst, note);
    }

    /// <summary>Tassement œdométrique : sous-couches de 0,5 m jusqu'à 2B (ou Δσ &lt; 20 % de σ'v0), diffusion 2:1.</summary>
    public static SettlementResult Settlement(SoilProfile s, double A, double B, double D, double qNet)
    {
        var res = new SettlementResult();
        double zMax = Math.Min(4 * Math.Min(A, B), 15), dz = 0.5, tot = 0;
        for (double z = 0; z < zMax; z += dz)
        {
            double zm = z + dz / 2;
            double dsig = qNet * A * B / ((A + zm) * (B + zm));
            double sv0 = EffectiveStress(s, D + zm);
            if (dsig < 0.2 * sv0) { res.DepthM = z; break; }
            var l = LayerAt(s, D + zm);
            double ds;
            if (l.Cc > 0) ds = dz * l.Cc / (1 + l.E0) * Math.Log10((sv0 + dsig) / Math.Max(sv0, 1e-3));
            else ds = dsig * dz / (Math.Max(l.EoedMPa, 0.1) * 1000);
            tot += ds; res.DepthM = z + dz;
        }
        res.TotalMm = tot * 1000;
        res.Lines.Add($"Profondeur d'influence ≈ {res.DepthM:0.0} m sous la base ; tassement total ≈ {res.TotalMm:0.0} mm");
        return res;
    }
}
