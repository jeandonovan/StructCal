using StructCalc.Core.Model;

namespace StructCalc.Engine.Stairs;

/// <summary>Une volée (ou la ligne de foulée développée pour un escalier balancé / hélicoïdal).</summary>
public sealed class FlightGeo
{
    public int Index { get; set; }
    public int Steps { get; set; }                 // nombre de contremarches de la volée
    public double RunM { get; set; }               // projection horizontale de la volée (m)
    public double RiseM { get; set; }              // dénivelé franchi
    public double InclinedM { get; set; }          // longueur inclinée de la paillasse
    public double AngleDeg { get; set; }
    public string Kind { get; set; } = "Volée";
}

public sealed class StairGeometry
{
    public int Risers { get; set; }
    public double RiserM { get; set; }
    public double TreadM { get; set; }
    public double AngleDeg { get; set; }
    public double Blondel => 2 * RiserM + TreadM;
    public bool BlondelOk => Blondel >= 0.59 - 1e-6 && Blondel <= 0.64 + 1e-6;
    public double ThicknessM { get; set; }
    public List<FlightGeo> Flights { get; } = new();
    public double TotalRunM { get; set; }
    public double WalkLineM { get; set; }
    public List<string> Notes { get; } = new();
    public List<string> Warnings { get; } = new();
    public bool Ok => Warnings.Count == 0;
}

public static class StairGeometryBuilder
{
    /// <summary>Nombre de volées droites selon la disposition (hors marches balancées).</summary>
    public static int FlightCount(StairLayout l) => l switch
    {
        StairLayout.Droit => 1,
        StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier => 2,
        StairLayout.DoubleQuartPalier => 3,
        StairLayout.QuartBalance or StairLayout.DemiBalance => 2,
        _ => 1,
    };

    public static int WinderCount(StairLayout l) => l switch { StairLayout.QuartBalance => 3, StairLayout.DemiBalance => 6, _ => 0 };

    public static double LiveLoad(StairDef d) => d.QKnPerM2 > 0 ? d.QKnPerM2 : d.Usage switch
    {
        StairUsage.Habitation => 2.5, StairUsage.Bureaux => 3.0, StairUsage.Public => 4.0, _ => 5.0,
    };

    public static StairGeometry Build(StairDef d)
    {
        var g = new StairGeometry();
        double H = d.HeightM, w = d.WidthM;
        if (H < 0.5) { g.Warnings.Add("Hauteur à franchir trop faible."); return g; }
        // ---- nombre de marches : contremarche proche de la valeur visée, entre 14 et 20 cm
        double target = Math.Max(0.14, Math.Min(0.20, d.TargetRiserCm / 100.0));
        int n = Math.Max(2, (int)Math.Round(H / target));
        while (H / n > 0.20 && n < 200) n++;
        while (H / n < 0.14 && n > 2) n--;
        int nFlights = FlightCount(d.Layout), nw = WinderCount(d.Layout);
        if (d.Layout == StairLayout.Helicoidal) { nFlights = 1; }
        g.Risers = n; g.RiserM = H / n;

        // ---- répartition des marches par volée (les marches balancées comptent dans le total)
        // convention : n contremarches => n-1 girons (le dernier niveau est le plancher haut) ; les marches balancées sont des girons.
        bool balanced = nw > 0;
        int straight = balanced ? n - 1 - nw : n;          // balancé : nombre de girons DROITS (hors marches balancées)
        var counts = new List<int>();
        if (d.Layout == StairLayout.Helicoidal) counts.Add(n);
        else
        {
            int baseN = straight / nFlights;
            for (int i = 0; i < nFlights; i++) counts.Add(baseN);
            for (int i = 0, left = straight - baseN * nFlights; left > 0; i = (i + 1) % nFlights, left--) counts[i]++;
        }

        // ---- giron
        bool landings = d.Layout is StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier or StairLayout.DoubleQuartPalier;
        double treads = landings ? counts.Sum(c => c - 1) : (d.Layout == StairLayout.Droit ? counts[0] - 1 : (balanced ? counts.Sum() : n - 1));
        double tread = d.TargetTreadCm > 0 ? d.TargetTreadCm / 100.0 : Math.Max(0.22, Math.Min(0.32, 0.63 - 2 * g.RiserM));
        if (d.RunM > 0 && d.Layout != StairLayout.Helicoidal)
        {
            double midTotal = landings ? d.MidLandingM * (nFlights - 1) : 0;
            double avail = d.RunM - midTotal;
            if (d.Layout is StairLayout.QuartPalier or StairLayout.DemiPalier) avail = d.RunM;     // les volées sont dans des directions différentes : la reculée donnée concerne une volée
            if (treads > 0 && avail > 0)
            {
                double t2 = (d.Layout is StairLayout.QuartPalier or StairLayout.DemiPalier) ? avail / Math.Max(1, counts[0] - 1) : avail / treads;
                if (Math.Abs(t2 - tread) > 0.005) g.Notes.Add($"Giron imposé par la reculée disponible : {t2 * 100:0.0} cm (visé {tread * 100:0.0} cm).");
                tread = t2;
            }
        }
        g.TreadM = tread;
        g.AngleDeg = Math.Atan2(g.RiserM, tread) * 180 / Math.PI;

        // ---- volées
        double cosA = Math.Cos(g.AngleDeg * Math.PI / 180);
        double walk = 0;
        if (d.Layout == StairLayout.Helicoidal)
        {
            double rwl = d.InnerRadiusM + w / 2;
            double th = d.TurnAngleDeg * Math.PI / 180;
            double wl = rwl * th;                                  // ligne de foulée développée
            g.TreadM = wl / Math.Max(1, n - 1);
            g.AngleDeg = Math.Atan2(g.RiserM, g.TreadM) * 180 / Math.PI;
            cosA = Math.Cos(g.AngleDeg * Math.PI / 180);
            var f = new FlightGeo { Index = 1, Steps = n, RunM = wl, RiseM = H, InclinedM = wl / cosA, AngleDeg = g.AngleDeg, Kind = "Hélice (ligne de foulée)" };
            g.Flights.Add(f); walk = wl;
            if (rwl - 0 < 0.2) g.Warnings.Add("Rayon de la ligne de foulée trop petit.");
        }
        else if (nw > 0)
        {
            // marches balancées : une seule paillasse le long de la ligne de foulée (au milieu de l'emmarchement)
            double wlStraight = counts.Sum() * g.TreadM;           // girons droits = n - 1 - nw
            double corner = (nw == 3 ? Math.PI / 2 : Math.PI) * (w / 2);          // arc de la ligne de foulée dans le virage
            double wl = wlStraight + corner;
            // paillasse équivalente : (n-1) girons développés sur wl, dénivelé (n-1)h entre le pied de la 1re et de la dernière contremarche
            double eqAng = Math.Atan2((n - 1) * g.RiserM, wl);
            g.AngleDeg = eqAng * 180 / Math.PI;
            var f = new FlightGeo { Index = 1, Steps = n, RunM = wl, RiseM = H, InclinedM = Math.Sqrt(wl * wl + Math.Pow((n - 1) * g.RiserM, 2)), AngleDeg = g.AngleDeg, Kind = "Paillasse balancée (ligne de foulée)" };
            g.Flights.Add(f); walk = wl;
            double gw = corner / nw;
            g.Notes.Add($"Marches balancées : giron à la ligne de foulée ≈ {gw * 100:0.0} cm (minimum conseillé 22 cm)." );
            if (gw < 0.22) g.Warnings.Add($"Giron des marches balancées trop faible ({gw * 100:0.0} cm) : élargir l'emmarchement ou ajouter un palier.");
            if (counts.Any(c => c < 1) || straight < 2) g.Warnings.Add("Pas assez de marches droites pour les deux volées.");
        }
        else
        {
            for (int i = 0; i < counts.Count; i++)
            {
                int k = counts[i];
                double run = (landings || d.Layout == StairLayout.Droit ? k - 1 : k) * g.TreadM;
                var f = new FlightGeo { Index = i + 1, Steps = k, RunM = run, RiseM = k * g.RiserM, InclinedM = run / cosA, AngleDeg = g.AngleDeg, Kind = $"Volée {i + 1}" };
                g.Flights.Add(f); walk += run;
            }
        }
        g.TotalRunM = g.Flights.Sum(f => f.RunM);
        g.WalkLineM = walk;

        // ---- épaisseur de la paillasse : L/30 <= e <= L/20 avec L = longueur développée (volée inclinée + paliers attenants)
        double Lmax = 0;
        foreach (var f in g.Flights)
        {
            int idx = f.Index - 1; int last = g.Flights.Count - 1;
            double before = idx == 0 ? d.StartLandingM : 0, after = idx == last ? d.EndLandingM : (landings ? d.MidLandingM : 0);
            Lmax = Math.Max(Lmax, f.InclinedM + before + after);
        }
        // escalier large ou très chargé : e >= 15 cm et L/22 ; courant : e >= 12 cm et L/25 (le palier a au moins l'épaisseur de la paillasse)
        bool heavy = d.WidthM > 1.5 || LiveLoad(d) >= 4.0 - 1e-9;
        double eAuto = heavy ? Math.Max(0.15, Math.Ceiling(Lmax / 22.0 * 100) / 100.0) : Math.Max(0.12, Math.Ceiling(Lmax / 25.0 * 100) / 100.0);
        g.ThicknessM = d.SlabThicknessCm > 0 ? d.SlabThicknessCm / 100.0 : eAuto;
        g.Notes.Add($"Épaisseur de la paillasse : L = {Lmax:0.00} m → L/25 = {Lmax / 25 * 100:0.0} cm ≤ e ≤ L/20 = {Lmax / 20 * 100:0.0} cm (12 à 15 cm courant, 15 à 20 cm si large ou très chargé) ; retenue e = {g.ThicknessM * 100:0} cm.");

        // ---- contrôles
        if (!g.BlondelOk) g.Warnings.Add($"Formule de Blondel non respectée : 2h + g = {g.Blondel * 100:0.0} cm (attendu 59 à 64 cm).");
        if (g.RiserM < 0.16 - 1e-6 || g.RiserM > 0.18 + 1e-6) g.Notes.Add($"Contremarche {g.RiserM * 100:0.0} cm (confort habituel 16 à 18 cm).");
        if (g.TreadM < 0.25 - 1e-6 && d.Layout != StairLayout.Helicoidal) g.Warnings.Add($"Giron {g.TreadM * 100:0.0} cm < 25 cm.");
        if (d.Usage == StairUsage.Public && g.RiserM > 0.17 + 1e-6) g.Warnings.Add("Établissement recevant du public : contremarche ≤ 17 cm.");
        if (w < 0.80) g.Warnings.Add("Emmarchement < 0,80 m.");
        else if (w < 1.0 && d.Usage != StairUsage.Habitation) g.Warnings.Add("Emmarchement < 1,00 m pour un usage hors habitation.");
        if (g.AngleDeg > 45) g.Warnings.Add($"Pente de {g.AngleDeg:0}° trop forte.");
        g.Notes.Add($"{n} contremarches de {g.RiserM * 100:0.0} cm, giron {g.TreadM * 100:0.0} cm, pente {g.AngleDeg:0.0}°, Blondel 2h+g = {g.Blondel * 100:0.0} cm.");
        g.Notes.Add("Échappée libre à vérifier : ≥ 1,90 m (2,00 à 2,10 m en établissement recevant du public).");
        return g;
    }
}
