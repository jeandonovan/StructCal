using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Stairs;

/// <summary>Charges permanentes détaillées (kN/m² de projection horizontale) : paillasse, palier.</summary>
public sealed class StairLoadTable
{
    public List<(string Label, double Value)> Flight { get; } = new();
    public List<(string Label, double Value)> Landing { get; } = new();
    public double GFlight => Flight.Sum(x => x.Value);
    public double GLanding => Landing.Sum(x => x.Value);
    public double Q { get; set; }
}

public sealed class StairElementResult
{
    public string Name { get; set; } = "";
    public List<LoadSeg> SegsU { get; } = new();
    public double SpanM { get; set; }
    public double M0u { get; set; }
    public double MtU { get; set; }
    public double MtS { get; set; }
    public double MaU { get; set; }
    public double MbU { get; set; }
    public double Vu { get; set; }
    public double AsT { get; set; }
    public double AsA { get; set; }
    public double AsB { get; set; }
    public double AsDistr { get; set; }
    public string BarsT { get; set; } = "";
    public string BarsA { get; set; } = "";
    public string BarsB { get; set; } = "";
    public string BarsDistr { get; set; } = "";
    public double SpacingT { get; set; }
    public double Tau { get; set; }
    public double TauLim { get; set; }
    public double ReactionA { get; set; }       // kN/m, ELS
    public double ReactionB { get; set; }
    public bool Ok { get; set; } = true;
    public List<string> Notes { get; } = new();
    public double[] X { get; set; } = Array.Empty<double>();
    public double[] MU { get; set; } = Array.Empty<double>();
    public double[] VU { get; set; } = Array.Empty<double>();
    public double BeforeM { get; set; }
    public double RunM { get; set; }
    public double AfterM { get; set; }
}

public sealed class StairResult
{
    public StairDef Def { get; set; } = new();
    public StairGeometry Geo { get; set; } = new();
    public StairLoadTable Loads { get; set; } = new();
    public List<StairElementResult> Elements { get; } = new();
    public double ConcreteM3 { get; set; }
    public double SteelKg { get; set; }
    public double FormworkM2 { get; set; }
    public List<string> Warnings { get; } = new();
    public bool Ok => Warnings.Count == 0 && Elements.All(e => e.Ok) && Geo.Ok;
    public string Report { get; set; } = "";
}

public static class StairDesigner
{
    public static StairLoadTable Loads(StairDef d, StairGeometry geo)
    {
        var t = new StairLoadTable { Q = StairGeometryBuilder.LiveLoad(d) };
        double a = geo.AngleDeg * Math.PI / 180, cos = Math.Cos(a);
        double e = geo.ThicknessM, h = geo.RiserM, g = Math.Max(geo.TreadM, 0.1);
        double rail = d.WidthM > 0 ? d.RailingKnPerM / d.WidthM : 0;
        t.Flight.Add(($"Paillasse béton armé e = {e * 100:0} cm : 25 x e / cos α", 25 * e / cos));
        if (d.StepsFilled) t.Flight.Add(($"Marches en béton : {d.StepDensity:0} x h/2", d.StepDensity * h / 2));
        if (d.TreadCoverCm > 0) t.Flight.Add(($"Revêtement des marches e = {d.TreadCoverCm:0.#} cm", d.CoverDensity * d.TreadCoverCm / 100));
        if (d.MortarCm > 0) t.Flight.Add(($"Mortier de pose (horizontal) e = {d.MortarCm:0.#} cm", d.MortarDensity * d.MortarCm / 100));
        if (d.RiserCoverCm > 0) t.Flight.Add(($"Revêtement des contremarches e = {d.RiserCoverCm:0.#} cm : x h/g", d.CoverDensity * d.RiserCoverCm / 100 * h / g));
        if (d.MortarCm > 0 && d.RiserCoverCm > 0) t.Flight.Add(($"Mortier de pose (vertical) : x h/g", d.MortarDensity * d.MortarCm / 100 * h / g));
        if (d.PlasterCm > 0) t.Flight.Add(($"Enduit sous paillasse e = {d.PlasterCm:0.#} cm / cos α", d.PlasterDensity * d.PlasterCm / 100 / cos));
        if (rail > 0) t.Flight.Add(("Garde-corps", rail));

        t.Landing.Add(($"Palier béton armé e = {e * 100:0} cm : 25 x e", 25 * e));
        if (d.TreadCoverCm > 0) t.Landing.Add(($"Revêtement e = {d.TreadCoverCm:0.#} cm", d.CoverDensity * d.TreadCoverCm / 100));
        if (d.MortarCm > 0) t.Landing.Add(($"Mortier de pose e = {d.MortarCm:0.#} cm", d.MortarDensity * d.MortarCm / 100));
        if (d.PlasterCm > 0) t.Landing.Add(($"Enduit sous palier e = {d.PlasterCm:0.#} cm", d.PlasterDensity * d.PlasterCm / 100));
        if (rail > 0) t.Landing.Add(("Garde-corps", rail * 0.5));
        return t;
    }

    private static (int Dia, double Sp) Bars(double as1m, double maxSp, DesignSettings? cfg) => RebarSelector.Spacing(as1m, maxSp, cfg);
    private static string Txt((int Dia, double Sp) b) => $"HA{b.Dia} e={b.Sp:0} cm";

    public static StairResult Design(StairDef d, IReinforcedConcreteCode rc, double fc28, double fe, DesignSettings? cfg = null)
    {
        var res = new StairResult { Def = d };
        var geo = StairGeometryBuilder.Build(d);
        res.Geo = geo;
        if (geo.Flights.Count == 0) { res.Warnings.AddRange(geo.Warnings); res.Report = "Géométrie impossible."; return res; }
        var lt = Loads(d, geo); res.Loads = lt;
        double e = geo.ThicknessM, cover = Math.Max(d.CoverCm / 100.0, 0.02), dEff = e - cover;
        double gF = lt.GFlight, gP = lt.GLanding, q = lt.Q;
        bool landings = d.Layout is StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier or StairLayout.DoubleQuartPalier;
        int nF = geo.Flights.Count;
        double Factor(StairEnd t) => t == StairEnd.Simple ? 0 : t == StairEnd.SemiEncastre ? d.SemiFactor : 0;

        for (int i = 0; i < nF; i++)
        {
            var f = geo.Flights[i];
            double before = i == 0 ? d.StartLandingM : 0;
            double after = i == nF - 1 ? d.EndLandingM : (landings ? d.MidLandingM : 0);
            var el = new StairElementResult { Name = nF == 1 ? "Paillasse" : $"Volée {i + 1}", BeforeM = before, RunM = f.RunM, AfterM = after };
            // appui de gauche : pour la 2e volée et suivantes, l'appui est la poutre palière (semi-encastrée par défaut)
            var segsU = new List<LoadSeg>(); var segsS = new List<LoadSeg>();
            void Add(double len, double g, string kind)
            {
                if (len < 1e-6) return;
                segsU.Add(new LoadSeg(len, 1.35 * g + 1.5 * q, kind)); segsS.Add(new LoadSeg(len, g + q, kind));
            }
            Add(before, gP, "palier"); Add(f.RunM, gF, "volée"); Add(after, gP, "palier");
            el.SegsU.AddRange(segsU);
            StairEnd left = i == 0 ? d.StartSupport : StairEnd.SemiEncastre, right = i == nF - 1 ? d.EndSupport : StairEnd.SemiEncastre;
            if (landings && nF > 1 && i > 0) left = StairEnd.SemiEncastre;
            var bu = new BeamStatics(segsU, Factor(left), Factor(right), left == StairEnd.Encastre, right == StairEnd.Encastre);
            var bs = new BeamStatics(segsS, Factor(left), Factor(right), left == StairEnd.Encastre, right == StairEnd.Encastre);
            el.SpanM = bu.L; el.M0u = bu.M0Max;
            double restr = (left != StairEnd.Simple ? 1 : 0) + (right != StairEnd.Simple ? 1 : 0);
            // moment en travée : minimum forfaitaire 1,05 M0 - (Ma+Mb)/2 (BAEL B.6.2,21) lorsque les appuis sont partiellement encastrés
            el.MtU = Math.Max(bu.MtMax, restr > 0 ? 1.05 * bu.M0Max - (bu.Ma + bu.Mb) / 2 : 0);
            el.MtS = Math.Max(bs.MtMax, restr > 0 ? 1.05 * bs.M0Max - (bs.Ma + bs.Mb) / 2 : 0);
            // chapeaux : au moins 0,15 M0 même sur appui simple (encastrement partiel non nul en pratique)
            double MaU = Math.Max(bu.Ma, 0.15 * bu.M0Max), MbU = Math.Max(bu.Mb, 0.15 * bu.M0Max);
            double MaS = Math.Max(bs.Ma, 0.15 * bs.M0Max), MbS = Math.Max(bs.Mb, 0.15 * bs.M0Max);
            el.MaU = MaU; el.MbU = MbU;
            el.Vu = bu.VMax;
            el.ReactionA = bs.RA + (bs.Ma - bs.Mb) / bs.L; el.ReactionB = bs.RB - (bs.Ma - bs.Mb) / bs.L;
            el.X = bu.X; el.MU = bu.M; el.VU = bu.V;
            var sec = new RcRectSection(1.0, e, cover, cover);
            var dt = rc.DesignBeamFlexure(sec, fc28, fe, el.MtU, el.MtS, d.Crack);
            var da = rc.DesignBeamFlexure(sec, fc28, fe, MaU, MaS, d.Crack);
            var db = rc.DesignBeamFlexure(sec, fc28, fe, MbU, MbS, d.Crack);
            el.AsT = dt.Values["As_cm2"];
            el.AsA = Math.Max(da.Values["As_cm2"], 0.15 * el.AsT);
            el.AsB = Math.Max(db.Values["As_cm2"], 0.15 * el.AsT);
            if (!dt.Ok) { el.Ok = false; el.Notes.AddRange(dt.Warnings); }
            double maxMain = Math.Min(3 * e * 100, 33), maxDistr = Math.Min(4 * e * 100, 45);
            var bt = Bars(el.AsT, maxMain, cfg); el.BarsT = Txt(bt); el.SpacingT = bt.Sp;
            el.BarsA = Txt(Bars(el.AsA, maxMain, cfg)); el.BarsB = Txt(Bars(el.AsB, maxMain, cfg));
            el.AsDistr = Math.Max(el.AsT / 4, 0.8 * 0.0001 * 100 * e * 100);
            el.BarsDistr = Txt(Bars(el.AsDistr, maxDistr, cfg));
            // effort tranchant : dalle sans armatures d'effort tranchant si tau_u <= 0,07 fc28 / gamma_b
            el.Tau = el.Vu / 1000.0 / dEff;
            el.TauLim = 0.07 * fc28 / 1.5;
            if (el.Tau > el.TauLim)
            {
                el.Ok = false;
                el.Notes.Add($"τu = {el.Tau:0.00} MPa > {el.TauLim:0.00} MPa : augmenter l'épaisseur (pas d'armatures d'effort tranchant dans une dalle).");
            }
            // flèche : h/L >= 1/20 pour une dalle sur appuis simples, 1/25 si semi-encastrée (BAEL B.7.5)
            double lim = restr > 0 ? 1.0 / 25 : 1.0 / 20;
            double hl = e / el.SpanM;
            if (hl < lim) el.Notes.Add($"Flèche : h/L = 1/{1 / hl:0.0} < 1/{1 / lim:0} : vérifier la flèche par le calcul (ou augmenter e).");
            // ancrage (BAEL A.6.1,22) : ls = phi.fe / (4 tau_su), tau_su = 0,6 psi_s² ft28, psi_s = 1,5
            double ft28 = 0.6 + 0.06 * fc28, tauSu = 0.6 * 1.5 * 1.5 * ft28;
            int diaMain = int.TryParse(System.Text.RegularExpressions.Regex.Match(el.BarsT, @"HA(\d+)").Groups[1].Value, out var dm) ? dm : 0;
            if (diaMain > 0) el.Notes.Add($"Ancrage des principales HA{diaMain} : ls = {diaMain * fe / (4 * tauSu) / 10:0} cm (barre droite) ; équerres ou nappe pliée prolongée dans les paliers et appuis.");
            // flèche ELS : estimation élastique avec I fissurée ≈ 0,5 Ig et module différé (à confirmer par le calcul BAEL B.6.5)
            {
                double Ev = 3700 * Math.Pow(fc28, 1.0 / 3.0), Ig = e * e * e / 12.0;
                double fl = 5 * el.MtS * 1e3 * el.SpanM * el.SpanM / (48 * Ev * 1e6 * 0.5 * Ig) * 1000;   // mm
                double fAdm = (el.SpanM <= 5 ? el.SpanM / 500.0 : 0.005 + el.SpanM / 1000.0) * 1000;
                el.Notes.Add($"Flèche ELS estimée f ≈ {fl:0.0} mm pour f adm = {fAdm:0.0} mm : {(fl <= fAdm ? "acceptable" : "à vérifier par le calcul de flèche complet")}.");
            }
            el.Notes.Add($"Portée L = {el.SpanM:0.00} m (palier départ {before:0.00} + volée {f.RunM:0.00} + palier arrivée {after:0.00}) ; M0 = {el.M0u:0.0} kN.m/m ; appuis : {left} / {right}.");
            res.Elements.Add(el);
        }

        // ---- quantités
        double width = d.WidthM;
        double conc = 0, steel = 0, form = 0;
        foreach (var el in res.Elements)
        {
            var f = geo.Flights[res.Elements.IndexOf(el)];
            double lf = f.InclinedM, lp = el.BeforeM + el.AfterM;
            conc += e * (lf + lp) * width;
            form += (lf + lp) * width;
            // masse = section (cm²) x longueur (m) x 0,785 kg/(cm².m)
            steel += (el.AsT * 1.0 + (el.AsA + el.AsB) * 0.25 + el.AsDistr) * width * el.SpanM * 0.785;
        }
        // marches en béton
        if (d.StepsFilled) conc += geo.Flights.Sum(fl => fl.Steps - 1) * 0.5 * geo.RiserM * geo.TreadM * width;   // k contremarches = k-1 girons = k-1 triangles posés sur la paillasse
        res.ConcreteM3 = conc; res.FormworkM2 = form; res.SteelKg = steel * 1.15;     // + recouvrements, crochets
        foreach (var w in geo.Warnings) res.Warnings.Add(w);
        if (d.Layout is StairLayout.Helicoidal or StairLayout.QuartBalance or StairLayout.DemiBalance)
            res.Warnings.Add("Escalier balancé ou hélicoïdal : calcul équivalent sur la ligne de foulée, à confirmer par un modèle en coques (torsion de la paillasse).");
        if (d.Layout is StairLayout.QuartPalier or StairLayout.DemiPalier or StairLayout.DoubleQuartPalier)
            res.Notes_Add("Palier d'angle : à vérifier dans le sens transversal (appuis sur les murs) en plus du calcul des volées.");
        res.Report = BuildReport(res);
        return res;
    }

    private static void Notes_Add(this StairResult r, string s) => r.Geo.Notes.Add(s);

    public static string BuildReport(StairResult r)
    {
        var d = r.Def; var g = r.Geo; var sb = new StringBuilder();
        sb.AppendLine($"ESCALIER {d.Name} - {Layouts.Name(d.Layout)}");
        sb.AppendLine($"Hauteur {d.HeightM:0.00} m ; emmarchement {d.WidthM:0.00} m ; {g.Risers} contremarches de {g.RiserM * 100:0.0} cm ; giron {g.TreadM * 100:0.0} cm ; pente {g.AngleDeg:0.0}° ; 2h+g = {g.Blondel * 100:0.0} cm {(g.BlondelOk ? "(Blondel vérifié)" : "(Blondel NON vérifié)")}");
        foreach (var n in g.Notes) sb.AppendLine("  - " + n);
        sb.AppendLine();
        sb.AppendLine($"Charges (par m² de projection horizontale) : G paillasse = {r.Loads.GFlight:0.00} ; G palier = {r.Loads.GLanding:0.00} ; Q = {r.Loads.Q:0.00} kN/m²");
        foreach (var l in r.Loads.Flight) sb.AppendLine($"    paillasse : {l.Label} = {l.Value:0.00}");
        foreach (var l in r.Loads.Landing) sb.AppendLine($"    palier    : {l.Label} = {l.Value:0.00}");
        sb.AppendLine();
        foreach (var e in r.Elements)
        {
            sb.AppendLine($"{e.Name} (bande de 1 m) - {(e.Ok ? "OK" : "NON OK")}");
            sb.AppendLine($"  Mt(ELU) = {e.MtU:0.00} kN.m/m ; Mt(ELS) = {e.MtS:0.00} ; Ma = {e.MaU:0.00} ; Mb = {e.MbU:0.00} ; Vu = {e.Vu:0.00} kN/m ; τu = {e.Tau:0.00} MPa (≤ {e.TauLim:0.00})");
            sb.AppendLine($"  Armatures principales en travée : {e.AsT:0.00} cm²/m → {e.BarsT}");
            sb.AppendLine($"  Chapeaux appui A : {e.AsA:0.00} cm²/m → {e.BarsA} ; appui B : {e.AsB:0.00} cm²/m → {e.BarsB}");
            sb.AppendLine($"  Armatures de répartition : {e.AsDistr:0.00} cm²/m → {e.BarsDistr}");
            foreach (var n in e.Notes) sb.AppendLine("  ! " + n);
        }
        sb.AppendLine();
        sb.AppendLine($"Quantités approchées : béton {r.ConcreteM3:0.00} m³ ; coffrage {r.FormworkM2:0.0} m² ; acier {r.SteelKg:0} kg");
        foreach (var w in r.Warnings) sb.AppendLine("ATTENTION : " + w);
        return sb.ToString();
    }
}

public static class Layouts
{
    public static string Name(StairLayout l) => l switch
    {
        StairLayout.Droit => "droit (une volée)",
        StairLayout.DroitPalier => "droit avec palier intermédiaire",
        StairLayout.QuartPalier => "quart tournant avec palier d'angle",
        StairLayout.DemiPalier => "demi-tournant avec palier",
        StairLayout.DoubleQuartPalier => "double quart tournant (3 volées)",
        StairLayout.QuartBalance => "quart tournant balancé",
        StairLayout.DemiBalance => "demi-tournant balancé",
        _ => "hélicoïdal",
    };
}
