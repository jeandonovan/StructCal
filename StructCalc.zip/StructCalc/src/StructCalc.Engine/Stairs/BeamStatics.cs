namespace StructCalc.Engine.Stairs;

/// <summary>Un tronçon de charge uniforme sur la projection horizontale (kN par mètre horizontal, pour une bande de 1 m).</summary>
public sealed record LoadSeg(double Len, double Value, string Kind = "");

/// <summary>Poutre (bande de 1 m) sur deux appuis : moments isostatiques exacts pour des charges uniformes par tronçons + charges ponctuelles,
/// moments d'appui (semi-encastrement ou encastrement parfait par la méthode des forces).</summary>
public sealed class BeamStatics
{
    public double L { get; }
    public double RA { get; private set; }
    public double RB { get; private set; }
    public double[] X { get; }
    public double[] M0 { get; }
    public double[] V0 { get; }
    public double M0Max { get; private set; }
    public double Ma { get; private set; }          // moment d'appui gauche (valeur positive = fibres supérieures tendues)
    public double Mb { get; private set; }
    public double[] M { get; private set; }
    public double[] V { get; private set; }
    public double MtMax { get; private set; }
    public double XMt { get; private set; }
    public double VMax { get; private set; }

    public BeamStatics(IReadOnlyList<LoadSeg> segs, double endLeftFactor, double endRightFactor, bool fixedLeft, bool fixedRight, int n = 400, IReadOnlyList<(double X, double P)>? points = null)
    {
        L = segs.Sum(s => s.Len);
        X = new double[n + 1]; M0 = new double[n + 1]; V0 = new double[n + 1]; M = new double[n + 1]; V = new double[n + 1];
        var starts = new List<double>(); double acc = 0;
        foreach (var s in segs) { starts.Add(acc); acc += s.Len; }
        points ??= Array.Empty<(double, double)>();
        // réactions
        double total = segs.Sum(s => s.Value * s.Len) + points.Sum(p => p.P);
        double momA = 0;
        for (int i = 0; i < segs.Count; i++) momA += segs[i].Value * segs[i].Len * (starts[i] + segs[i].Len / 2);
        foreach (var p in points) momA += p.P * p.X;
        RB = L > 0 ? momA / L : 0; RA = total - RB;
        for (int k = 0; k <= n; k++)
        {
            double x = L * k / n; X[k] = x;
            double v = RA, m = RA * x;
            for (int i = 0; i < segs.Count; i++)
            {
                double a = starts[i];
                if (x <= a) break;
                double len = Math.Min(x, a + segs[i].Len) - a;
                v -= segs[i].Value * len;
                m -= segs[i].Value * len * (x - a - len / 2);
            }
            foreach (var p in points) if (x > p.X) { v -= p.P; m -= p.P * (x - p.X); }
            V0[k] = v; M0[k] = m;
        }
        M0Max = M0.Max();
        // moments d'appui
        double ma = 0, mb = 0;
        if (fixedLeft || fixedRight)
        {
            // méthode des forces : rotations nulles aux appuis encastrés ; EI constant
            double f11 = 0, f12 = 0, f22 = 0, d1 = 0, d2 = 0;
            for (int k = 0; k < n; k++)
            {
                double x = 0.5 * (X[k] + X[k + 1]), dx = X[k + 1] - X[k];
                double m0 = 0.5 * (M0[k] + M0[k + 1]), ua = 1 - x / L, ub = x / L;
                f11 += ua * ua * dx; f12 += ua * ub * dx; f22 += ub * ub * dx; d1 += m0 * ua * dx; d2 += m0 * ub * dx;
            }
            if (fixedLeft && fixedRight)
            {
                double det = f11 * f22 - f12 * f12;
                ma = (d1 * f22 - d2 * f12) / det; mb = (f11 * d2 - f12 * d1) / det;
            }
            else if (fixedLeft) { mb = endRightFactor * M0Max; ma = (d1 - f12 * mb) / f11; }
            else { ma = endLeftFactor * M0Max; mb = (d2 - f12 * ma) / f22; }
        }
        else { ma = endLeftFactor * M0Max; mb = endRightFactor * M0Max; }
        Ma = Math.Max(0, ma); Mb = Math.Max(0, mb);
        double mtmax = double.MinValue; double xm = 0; double vmax = 0;
        for (int k = 0; k <= n; k++)
        {
            double x = X[k];
            M[k] = M0[k] - Ma * (1 - x / L) - Mb * (x / L);
            V[k] = V0[k] + (Ma - Mb) / L;
            if (M[k] > mtmax) { mtmax = M[k]; xm = x; }
            vmax = Math.Max(vmax, Math.Abs(V[k]));
        }
        MtMax = Math.Max(0, mtmax); XMt = xm; VMax = vmax;
    }
}
