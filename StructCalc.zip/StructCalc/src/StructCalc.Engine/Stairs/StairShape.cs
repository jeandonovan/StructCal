using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.Engine.Stairs;

/// <summary>Nature d'une facette d'escalier.</summary>
public enum StairFaceKind { Tread, Riser, Landing, Waist, Rail }

/// <summary>Facette plane d'un escalier (sommets en coordonnées du projet).</summary>
public sealed class StairFace
{
    public StairFaceKind Kind { get; init; }
    public Vec3[] Pts { get; init; } = Array.Empty<Vec3>();
}

/// <summary>Forme 3D d'un escalier pour le modèle d'ensemble : marches, contremarches et paliers de tous les types
/// (droit, palier, quart et demi-tournant, double quart, balancé, hélicoïdal), posés à (X, Y, Z) et tournés de AngleDeg.</summary>
public static class StairShape
{
    public static List<StairFace> Build(StairDef d)
    {
        var faces = new List<StairFace>();
        var g = StairGeometryBuilder.Build(d);
        if (g.Risers < 2 || g.RiserM <= 0 || g.TreadM <= 0 && d.Layout != StairLayout.Helicoidal) return faces;
        double w = Math.Max(0.4, d.WidthM), h = g.RiserM, t = g.TreadM;
        int n = g.Risers;
        double e = Math.Max(0.08, g.ThicknessM);                 // épaisseur de la paillasse / du palier (m)
        double ang = d.AngleDeg * Math.PI / 180, ca = Math.Cos(ang), sa = Math.Sin(ang);
        Vec3 G(double x, double y0, double z)
        {
            double y = d.Mirror ? -y0 : y0;                // escalier symétrique (virage à droite)
            return new Vec3(d.X + x * ca - y * sa, d.Y + x * sa + y * ca, d.Z + z);
        }
        void Add(StairFaceKind k, params (double X, double Y, double Z)[] p) => faces.Add(new StairFace { Kind = k, Pts = p.Select(q => G(q.X, q.Y, q.Z)).ToArray() });

        // volée droite : origine (ox, oy), direction th, k contremarches, niveau de départ z0 ; retourne le niveau d'arrivée et la fin de la volée
        void Flight(double ox, double oy, double th, int treads, double z0, int firstJ = 1)
        {
            double c = Math.Cos(th), s = Math.Sin(th);
            (double, double, double) P(double u, double v, double z) => (ox + u * c - v * s, oy + u * s + v * c, z);
            for (int j = firstJ; j <= treads; j++)
            {
                double u0 = (j - firstJ) * t, u1 = u0 + t, zt = z0 + j * h;
                Add(StairFaceKind.Tread, P(u0, 0, zt), P(u1, 0, zt), P(u1, w, zt), P(u0, w, zt));
                Add(StairFaceKind.Riser, P(u0, 0, zt - h), P(u0, w, zt - h), P(u0, w, zt), P(u0, 0, zt));
            }
            // garde-corps : panneau de 0,90 m le long de chaque rive de la volée
            if (treads - firstJ + 1 >= 1)
            {
                double lr = (treads - firstJ + 1) * t, zr = z0 + (firstJ - 1) * h + h, sl = h / t;
                foreach (double vv in new[] { 0.0, w })
                    Add(StairFaceKind.Rail, P(0, vv, zr), P(lr, vv, zr + sl * lr), P(lr, vv, zr + sl * lr + 0.90), P(0, vv, zr + 0.90));
            }
            // paillasse : dalle inclinée sous les marches (dessus = ligne des angles rentrants, épaisseur e mesurée perpendiculairement), jamais sous le plancher bas
            int cnt = treads - firstJ + 1;
            if (cnt >= 1)
            {
                double lu = cnt * t, za = z0 + (firstJ - 1) * h, slope = h / t, ev = e * Math.Sqrt(t * t + h * h) / t;
                double us = za - ev < 0 ? (ev - za) / slope : 0;
                if (us < lu - 0.05)
                {
                    double Zl(double u) => Math.Max(0, za - ev + slope * u);
                    Add(StairFaceKind.Waist, P(us, 0, Zl(us)), P(lu, 0, Zl(lu)), P(lu, w, Zl(lu)), P(us, w, Zl(us)));
                    // rives pleines : sous chaque marche, de la face inférieure de la paillasse jusqu'au dessus de la marche (volée monolithique, sans vide entre les marches)
                    for (int j = firstJ; j <= treads; j++)
                    {
                        double a0 = (j - firstJ) * t, a1 = a0 + t, zt = z0 + j * h;
                        foreach (double vv in new[] { 0.0, w })
                            Add(StairFaceKind.Waist, P(a0, vv, Zl(a0)), P(a1, vv, Zl(a1)), P(a1, vv, zt), P(a0, vv, zt));
                    }
                }
            }
        }
        void Landing(double ox, double oy, double th, double len, double wid, double z, bool riserFront = true)
        {
            double c = Math.Cos(th), s = Math.Sin(th);
            (double, double, double) P(double u, double v, double zz) => (ox + u * c - v * s, oy + u * s + v * c, zz);
            Add(StairFaceKind.Landing, P(0, 0, z), P(len, 0, z), P(len, wid, z), P(0, wid, z));
            if (riserFront) Add(StairFaceKind.Riser, P(0, 0, z - h), P(0, wid, z - h), P(0, wid, z), P(0, 0, z));
            // épaisseur du palier : dessous et quatre rives
            double zb = Math.Max(0, z - e);
            Add(StairFaceKind.Waist, P(0, 0, zb), P(len, 0, zb), P(len, wid, zb), P(0, wid, zb));
            Add(StairFaceKind.Waist, P(0, 0, z), P(len, 0, z), P(len, 0, zb), P(0, 0, zb));
            Add(StairFaceKind.Waist, P(0, wid, z), P(len, wid, z), P(len, wid, zb), P(0, wid, zb));
            Add(StairFaceKind.Waist, P(len, 0, z), P(len, wid, z), P(len, wid, zb), P(len, 0, zb));
        }

        var lay = d.Layout;
        int fl = StairGeometryBuilder.FlightCount(lay), nw = StairGeometryBuilder.WinderCount(lay);
        bool landings = lay is StairLayout.DroitPalier or StairLayout.QuartPalier or StairLayout.DemiPalier or StairLayout.DoubleQuartPalier;
        int straight = nw > 0 ? n - 1 - nw : n;
        var counts = new List<int>();
        if (lay != StairLayout.Helicoidal)
        {
            int b = straight / fl; for (int i = 0; i < fl; i++) counts.Add(b);
            for (int i = 0, left = straight - b * fl; left > 0; i = (i + 1) % fl, left--) counts[i]++;
        }
        double top = n * h, endLen = Math.Max(0.3, d.EndLandingM);

        switch (lay)
        {
            case StairLayout.Droit:
            {
                int k = counts[0]; Flight(0, 0, 0, k - 1, 0);
                Landing((k - 1) * t, 0, 0, endLen, w, k * h);
                break;
            }
            case StairLayout.DroitPalier:
            {
                int k1 = counts[0], k2 = counts[1]; double mid = Math.Max(0.3, d.MidLandingM);
                Flight(0, 0, 0, k1 - 1, 0);
                double x1 = (k1 - 1) * t; Landing(x1, 0, 0, mid, w, k1 * h);
                Flight(x1 + mid, 0, 0, k2 - 1, k1 * h);
                Landing(x1 + mid + (k2 - 1) * t, 0, 0, endLen, w, top);
                break;
            }
            case StairLayout.QuartPalier:
            {
                int k1 = counts[0], k2 = counts[1];
                Flight(0, 0, 0, k1 - 1, 0);
                double x1 = (k1 - 1) * t; Landing(x1, 0, 0, w, w, k1 * h);
                Flight(x1 + w, w, Math.PI / 2, k2 - 1, k1 * h);
                Landing(x1 + w, w + (k2 - 1) * t, Math.PI / 2, endLen, w, top);
                break;
            }
            case StairLayout.DemiPalier:
            {
                int k1 = counts[0], k2 = counts[1]; double gap = Math.Max(0.02, d.GapM), lm = Math.Max(w, d.MidLandingM);
                Flight(0, 0, 0, k1 - 1, 0);
                double x1 = (k1 - 1) * t; Landing(x1, 0, 0, lm, 2 * w + gap, k1 * h);
                Flight(x1, 2 * w + gap, Math.PI, k2 - 1, k1 * h);
                Landing(x1 - (k2 - 1) * t, 2 * w + gap, Math.PI, endLen, w, top);
                break;
            }
            case StairLayout.DoubleQuartPalier:
            {
                int k1 = counts[0], k2 = counts[1], k3 = counts[2];
                Flight(0, 0, 0, k1 - 1, 0);
                double x1 = (k1 - 1) * t; Landing(x1, 0, 0, w, w, k1 * h);
                Flight(x1 + w, w, Math.PI / 2, k2 - 1, k1 * h);
                double y2 = w + (k2 - 1) * t; Landing(x1, y2, 0, w, w, (k1 + k2) * h);
                Flight(x1, y2 + w, Math.PI, k3 - 1, (k1 + k2) * h);
                Landing(x1 - (k3 - 1) * t, y2 + w, Math.PI, endLen, w, top);
                break;
            }
            case StairLayout.QuartBalance:
            case StairLayout.DemiBalance:
            {
                int k1 = counts[0], k2 = counts[1]; bool demi = lay == StairLayout.DemiBalance;
                Flight(0, 0, 0, k1, 0);
                double x1 = k1 * t;
                double gap = demi ? Math.Max(0.02, d.GapM) : 0, wid = demi ? 2 * w + gap : w;
                // centre du virage et rectangle (relatif au centre)
                double cx = x1, cy = demi ? w + gap / 2 : w;
                double rx0 = 0, rx1 = w, ry0 = demi ? -(w + gap / 2) : -w, ry1 = demi ? (w + gap / 2) : 0;
                double a0 = demi ? -Math.PI / 2 : -Math.PI / 2, span = demi ? Math.PI : Math.PI / 2;
                for (int m = 1; m <= nw; m++)
                {
                    double s0 = a0 + span * (m - 1) / nw, s1 = a0 + span * m / nw, zt = (k1 + m) * h;
                    var poly = SectorInRect(s0, s1, rx0, rx1, ry0, ry1);
                    Add(StairFaceKind.Tread, poly.Select(q => (cx + q.X, cy + q.Y, zt)).ToArray());
                    // contremarche au début de la marche balancée (du centre du virage au bord de la zone)
                    Add(StairFaceKind.Riser, (cx + poly[0].X, cy + poly[0].Y, zt - h), (cx + poly[1].X, cy + poly[1].Y, zt - h), (cx + poly[1].X, cy + poly[1].Y, zt), (cx + poly[0].X, cy + poly[0].Y, zt));
                    // paillasse sous la zone de giration : surface qui monte avec l'angle (dessus = pied des contremarches), épaisseur e
                    double evw = e * Math.Sqrt(t * t + h * h) / t;
                    double ZRef(int i) => i == 0 ? (k1 + nw / 2.0) * h : (k1 + nw * Math.Clamp((Math.Atan2(poly[i].Y, poly[i].X) - a0) / span, 0, 1)) * h;
                    double ZUn(int i) => Math.Max(0, ZRef(i) - evw);
                    Add(StairFaceKind.Waist, poly.Select((q, i) => (cx + q.X, cy + q.Y, ZUn(i))).ToArray());
                    for (int i = 1; i < poly.Count - 1; i++)
                        Add(StairFaceKind.Waist, (cx + poly[i].X, cy + poly[i].Y, zt), (cx + poly[i + 1].X, cy + poly[i + 1].Y, zt), (cx + poly[i + 1].X, cy + poly[i + 1].Y, ZUn(i + 1)), (cx + poly[i].X, cy + poly[i].Y, ZUn(i)));
                }
                int z2 = k1 + nw;
                if (!demi)
                {
                    Flight(x1 + w, w, Math.PI / 2, k2, z2 * h);
                    Landing(x1 + w, w + k2 * t, Math.PI / 2, endLen, w, top);
                }
                else
                {
                    Flight(x1, 2 * w + gap, Math.PI, k2, z2 * h);
                    Landing(x1 - k2 * t, 2 * w + gap, Math.PI, endLen, w, top);
                }
                break;
            }
            case StairLayout.Helicoidal:
            {
                double ri = Math.Max(0.05, d.InnerRadiusM), ro = ri + w, tot = d.TurnAngleDeg * Math.PI / 180;
                int steps = n - 1;
                for (int m = 1; m <= steps; m++)
                {
                    double s0 = tot * (m - 1) / steps, s1 = tot * m / steps, zt = m * h;
                    var pts = new List<(double, double, double)>();
                    int sub = Math.Max(1, (int)Math.Ceiling((s1 - s0) / (Math.PI / 12)));
                    for (int q = 0; q <= sub; q++) { double a = s0 + (s1 - s0) * q / sub; pts.Add((ro * Math.Cos(a), ro * Math.Sin(a), zt)); }
                    for (int q = sub; q >= 0; q--) { double a = s0 + (s1 - s0) * q / sub; pts.Add((ri * Math.Cos(a), ri * Math.Sin(a), zt)); }
                    Add(StairFaceKind.Tread, pts.ToArray());
                    double sa0 = s0;
                    // paillasse hélicoïdale : sous chaque marche, dessous et rives intérieure et extérieure
                    double rm = (ri + ro) / 2, tt = Math.Max(0.05, rm * (s1 - s0)), evh = e * Math.Sqrt(tt * tt + h * h) / tt;
                    double zr0 = (m - 1) * h, zr1 = m * h;
                    double Un(double z) => Math.Max(0, z - evh);
                    (double, double, double) Hp(double r, double a, double z) => (r * Math.Cos(a), r * Math.Sin(a), z);
                    Add(StairFaceKind.Waist, Hp(ro, s0, Un(zr0)), Hp(ro, s1, Un(zr1)), Hp(ri, s1, Un(zr1)), Hp(ri, s0, Un(zr0)));
                    Add(StairFaceKind.Waist, Hp(ro, s0, zr1), Hp(ro, s1, zr1), Hp(ro, s1, Un(zr1)), Hp(ro, s0, Un(zr0)));
                    Add(StairFaceKind.Waist, Hp(ri, s0, zr1), Hp(ri, s1, zr1), Hp(ri, s1, Un(zr1)), Hp(ri, s0, Un(zr0)));
                    Add(StairFaceKind.Riser, (ri * Math.Cos(sa0), ri * Math.Sin(sa0), zt - h), (ro * Math.Cos(sa0), ro * Math.Sin(sa0), zt - h), (ro * Math.Cos(sa0), ro * Math.Sin(sa0), zt), (ri * Math.Cos(sa0), ri * Math.Sin(sa0), zt));
                }
                // palier d'arrivée : dernier secteur au niveau haut
                double e0 = tot, e1 = tot + Math.Max(Math.PI / 6, endLen / ((ri + ro) / 2));
                var lp = new List<(double, double, double)>();
                int sb = 4;
                for (int q = 0; q <= sb; q++) { double a = e0 + (e1 - e0) * q / sb; lp.Add((ro * Math.Cos(a), ro * Math.Sin(a), top)); }
                for (int q = sb; q >= 0; q--) { double a = e0 + (e1 - e0) * q / sb; lp.Add((ri * Math.Cos(a), ri * Math.Sin(a), top)); }
                Add(StairFaceKind.Landing, lp.ToArray());
                double zlb = Math.Max(0, top - e);
                Add(StairFaceKind.Waist, lp.Select(q => (q.Item1, q.Item2, zlb)).ToArray());
                for (int i = 0; i < lp.Count; i++)
                {
                    var qa = lp[i]; var qb = lp[(i + 1) % lp.Count];
                    Add(StairFaceKind.Waist, (qa.Item1, qa.Item2, top), (qb.Item1, qb.Item2, top), (qb.Item1, qb.Item2, zlb), (qa.Item1, qa.Item2, zlb));
                }
                break;
            }
        }
        return faces;
    }

    /// <summary>Secteur d'angles [a0, a1] issu du centre (0,0), découpé par le rectangle [x0,x1] x [y0,y1] qui contient le centre sur son bord.</summary>
    private static List<(double X, double Y)> SectorInRect(double a0, double a1, double x0, double x1, double y0, double y1)
    {
        (double, double) Hit(double a)
        {
            double c = Math.Cos(a), s = Math.Sin(a), tmax = double.MaxValue;
            if (c > 1e-9) tmax = Math.Min(tmax, x1 / c); else if (c < -1e-9) tmax = Math.Min(tmax, x0 / c);
            if (s > 1e-9) tmax = Math.Min(tmax, y1 / s); else if (s < -1e-9) tmax = Math.Min(tmax, y0 / s);
            return (c * tmax, s * tmax);
        }
        var r = new List<(double X, double Y)> { (0, 0) };
        var p0 = Hit(a0); r.Add(p0);
        foreach (var (cx, cy) in new[] { (x1, y0), (x1, y1) })
        {
            double ac = Math.Atan2(cy, cx);
            if (ac > a0 + 1e-9 && ac < a1 - 1e-9) r.Add((cx, cy));
        }
        r.Add(Hit(a1));
        return r;
    }
}
