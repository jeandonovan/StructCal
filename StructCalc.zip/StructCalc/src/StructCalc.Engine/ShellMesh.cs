using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Génération de maillages de coques (voiles verticaux et dalles horizontales) dans le modèle 3D. Les nœuds existants (poteaux, poutres) sont réutilisés
/// s'ils coïncident avec les nœuds du maillage (tolérance 2 mm), ce qui couple la coque à l'ossature.</summary>
public static class ShellMesh
{
    private const double Tol = 0.002;

    private static int NodeAt(StructModel m, double x, double y, double z, Dictionary<(long, long, long), int> cache)
    {
        var key = ((long)Math.Round(x / Tol), (long)Math.Round(y / Tol), (long)Math.Round(z / Tol));
        if (cache.TryGetValue(key, out int id)) return id;
        foreach (var n in m.Nodes)
            if (Math.Abs(n.X - x) <= Tol && Math.Abs(n.Y - y) <= Tol && Math.Abs(n.Z - z) <= Tol) { cache[key] = n.Id; return n.Id; }
        id = (m.Nodes.Count == 0 ? 0 : m.Nodes.Max(n => n.Id)) + 1;
        m.Nodes.Add(new Node { Id = id, X = x, Y = y, Z = z });
        cache[key] = id;
        return id;
    }

    /// <summary>Maille le rectangle défini par p0 (origine), le vecteur long (p0→p1) et le vecteur court (p0→p3), en nx x ny éléments.
    /// Les éléments sont orientés pour que la normale soit (p1-p0) x (p3-p0). Retourne le nombre d'éléments créés.</summary>
    public static int AddRectangle(StructModel m, string name, string kind, double[] p0, double[] p1, double[] p3, int nx, int ny, double thickness,
        double gExtra = 0, double q = 0)
    {
        nx = Math.Max(1, nx); ny = Math.Max(1, ny);
        var cache = new Dictionary<(long, long, long), int>();
        var grid = new int[nx + 1, ny + 1];
        for (int i = 0; i <= nx; i++)
            for (int j = 0; j <= ny; j++)
            {
                double u = (double)i / nx, v = (double)j / ny;
                grid[i, j] = NodeAt(m,
                    p0[0] + u * (p1[0] - p0[0]) + v * (p3[0] - p0[0]),
                    p0[1] + u * (p1[1] - p0[1]) + v * (p3[1] - p0[1]),
                    p0[2] + u * (p1[2] - p0[2]) + v * (p3[2] - p0[2]), cache);
            }
        int id = m.Shells.Count == 0 ? 0 : m.Shells.Max(s => s.Id);
        int count = 0;
        for (int i = 0; i < nx; i++)
            for (int j = 0; j < ny; j++)
            {
                m.Shells.Add(new ShellPanel
                {
                    Id = ++id, Name = name, Kind = kind, T = thickness, GExtra = gExtra, Q = q,
                    N1 = grid[i, j], N2 = grid[i + 1, j], N3 = grid[i + 1, j + 1], N4 = grid[i, j + 1]
                });
                count++;
            }
        return count;
    }

    /// <summary>Voile vertical : origine (x, y, z du pied gauche), longueur le long de la direction angleDeg dans le plan XY, hauteur selon Z.</summary>
    public static int AddWall(StructModel m, string name, double x, double y, double z, double angleDeg, double length, double height, double thickness, double meshSize)
    {
        double a = angleDeg * Math.PI / 180.0, dx = Math.Cos(a), dy = Math.Sin(a);
        int nx = (int)Math.Ceiling(length / Math.Max(meshSize, 0.05) - 1e-9), ny = (int)Math.Ceiling(height / Math.Max(meshSize, 0.05) - 1e-9);
        return AddRectangle(m, name, "Voile", new[] { x, y, z }, new[] { x + length * dx, y + length * dy, z }, new[] { x, y, z + height }, nx, ny, thickness);
    }

    /// <summary>Dalle horizontale rectangulaire (normale vers le haut), coin minimal (x0, y0), cote z.</summary>
    public static int AddSlab(StructModel m, string name, double x0, double y0, double z, double lx, double ly, double thickness, double meshSize, double gExtra, double q)
    {
        int nx = (int)Math.Ceiling(lx / Math.Max(meshSize, 0.05) - 1e-9), ny = (int)Math.Ceiling(ly / Math.Max(meshSize, 0.05) - 1e-9);
        return AddRectangle(m, name, "Dalle", new[] { x0, y0, z }, new[] { x0 + lx, y0, z }, new[] { x0, y0 + ly, z }, nx, ny, thickness, gExtra, q);
    }

    /// <summary>Supprime les coques d'un groupe (ou toutes) et les nœuds qu'elles utilisaient s'ils sont devenus orphelins (sans barre, appui, charge ni autre coque).</summary>
    public static int Remove(StructModel m, string? name)
    {
        var touched = new HashSet<int>();
        foreach (var s in m.Shells.Where(q => name == null || q.Name == name)) { touched.Add(s.N1); touched.Add(s.N2); touched.Add(s.N3); touched.Add(s.N4); }
        int n = m.Shells.RemoveAll(q => name == null || q.Name == name);
        var used = new HashSet<int>();
        foreach (var mem in m.Members) { used.Add(mem.NodeI); used.Add(mem.NodeJ); }
        foreach (var sp in m.Supports) used.Add(sp.NodeId);
        foreach (var l in m.NodalLoads) used.Add(l.NodeId);
        foreach (var s in m.Shells) { used.Add(s.N1); used.Add(s.N2); used.Add(s.N3); used.Add(s.N4); }
        for (int i = m.Nodes.Count - 1; i >= 0; i--)
            if (touched.Contains(m.Nodes[i].Id) && !used.Contains(m.Nodes[i].Id)) m.Nodes.RemoveAt(i);
        return n;
    }
}
