using System.Globalization;
using System.Text;
using StructCalc.Core;

namespace StructCalc.Engine.Drawing;

public enum EntKind { Line, Circle, Text }

public sealed class DrawEntity
{
    public EntKind Kind;
    public string Layer = "";
    public double X1, Y1, X2, Y2, R, H, Rot;
    public bool Fill;                 // cercle plein (barre en coupe)
    public string Text = "";
    public object? Owner;             // tableau propriétaire (regénéré quand on redimensionne le tableau)
    /// <summary>Élément du dessin proprement dit (mis à l'échelle et centré par SheetLayout) ; Block = cadre, cartouche, filigrane (jamais déplacés).</summary>
    public bool Content, Block;
    /// <summary>Coordonnées d'origine (à la génération) et largeur estimée du texte, pour recalculer la mise à l'échelle sans cumul d'erreurs.</summary>
    public double OX1, OY1, OX2, OY2, OR, TW;
}

public static class Layers
{
    /// <summary>Calques et couleurs ACI (AutoCAD Color Index).</summary>
    public static readonly (string Name, int Color)[] All =
    {
        ("CONTOUR", 7), ("BETON", 7), ("ARMATURES", 1), ("ARMATURES2", 30), ("ARMATURES_HAUTES", 6), ("CADRES", 3), ("COTES", 5),
        ("TEXTE", 7), ("AXES", 4), ("ACIER", 2), ("BOULONS", 6), ("SOUDURES", 1), ("CARTOUCHE", 7), ("FILIGRANE", 8),
        ("COUPES", 1), ("REPERES", 2), ("TABLEAU", 7), ("HACHURES", 9),
    };
    public static int ColorOf(string layer) => All.FirstOrDefault(l => l.Name == layer).Color is int c && c != 0 ? c : 7;
}

/// <summary>Planche de dessin : coordonnées en millimètres de papier (origine en bas à gauche), format A3 paysage par défaut.</summary>
public sealed class Sheet
{
    public string Name = "", Title = "", Number = "", ScaleText = "";
    public double Width = 420, Height = 297;
    // mise en page dynamique (voir SheetLayout)
    public bool Prepared, AutoScale = true;
    public double BaseDen, Factor = 1, ManualFactor = 1, C0X, C0Y;
    public string BaseScaleText = "";
    /// <summary>Redessine le cartouche (échelle affichée à jour) ; défini par TitleBlock.Add.</summary>
    public Action? RebuildTitle;
    public List<DrawEntity> Items { get; } = new();
    public List<SheetTable> Tables { get; } = new();

    /// <summary>Ajoute un tableau ancré en haut à droite du cadre et le dessine.</summary>
    public void AddTable(SheetTable t) { Tables.Add(t); t.Rebuild(this); }

    public void Line(double x1, double y1, double x2, double y2, string layer = "CONTOUR") =>
        Items.Add(new DrawEntity { Kind = EntKind.Line, Layer = layer, X1 = x1, Y1 = y1, X2 = x2, Y2 = y2 });

    public void Rect(double x, double y, double w, double h, string layer = "CONTOUR")
    {
        Line(x, y, x + w, y, layer); Line(x + w, y, x + w, y + h, layer);
        Line(x + w, y + h, x, y + h, layer); Line(x, y + h, x, y, layer);
    }

    public void Circle(double cx, double cy, double r, string layer = "ARMATURES") =>
        Items.Add(new DrawEntity { Kind = EntKind.Circle, Layer = layer, X1 = cx, Y1 = cy, R = Math.Max(r, 0.2) });

    public void Text(double x, double y, double h, string t, string layer = "TEXTE", double rot = 0) =>
        Items.Add(new DrawEntity { Kind = EntKind.Text, Layer = layer, X1 = x, Y1 = y, H = h, Text = t, Rot = rot });

    public void DashLine(double x1, double y1, double x2, double y2, string layer, double dash = 3, double gap = 1.5)
    {
        double dx = x2 - x1, dy = y2 - y1, len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 1e-6) return;
        double ux = dx / len, uy = dy / len, p = 0;
        while (p < len)
        {
            double q = Math.Min(p + dash, len);
            Line(x1 + ux * p, y1 + uy * p, x1 + ux * q, y1 + uy * q, layer);
            p = q + gap;
        }
    }

    /// <summary>Cotation simple horizontale ou verticale avec traits d'extrémité.</summary>
    public void DimH(double x1, double x2, double y, string label, double textH = 2.5)
    {
        Line(x1, y, x2, y, "COTES"); Line(x1, y - 1.5, x1, y + 1.5, "COTES"); Line(x2, y - 1.5, x2, y + 1.5, "COTES");
        Text((x1 + x2) / 2 - label.Length * textH * 0.3, y + 0.8, textH, label, "COTES");
    }
    public void DimV(double x, double y1, double y2, string label, double textH = 2.5)
    {
        Line(x, y1, x, y2, "COTES"); Line(x - 1.5, y1, x + 1.5, y1, "COTES"); Line(x - 1.5, y2, x + 1.5, y2, "COTES");
        Text(x + 1, (y1 + y2) / 2, textH, label, "COTES", 90);
    }
}

/// <summary>Cartouche, cadre, mention de l'auteur et filigrane d'évaluation.</summary>
public static class TitleBlock
{
    /// <summary>Hauteur du cartouche (mm) : le dessin doit rester au-dessus de y = 70.</summary>
    public const double Height = 56;

    /// <summary>Cellule de cartouche : étiquette en petit en haut à gauche, valeur dessous. Le texte est mis en page DANS la cellule :
    /// retour à la ligne aux espaces, hauteur réduite si nécessaire, coupé avec « ... » en dernier recours. Rien ne déborde du cadre.</summary>
    public static void Cell(Sheet s, double x, double y, double w, double h, string label, string value, double textH = 3.2, bool bold = false)
    {
        const double pad = 1.6;
        double labH = 1.7;
        if (!string.IsNullOrEmpty(label)) s.Text(x + pad, y + h - pad - labH * 0.75, labH, label.ToUpperInvariant(), "CARTOUCHE");
        double top = string.IsNullOrEmpty(label) ? y + h - pad : y + h - pad - labH - 0.9;
        double availW = w - 2 * pad, availH = top - (y + pad * 0.6);
        value = (value ?? "").Trim();
        if (value.Length == 0 || availW <= 1 || availH <= 1) return;
        double th = textH;
        List<string> lines;
        while (true)
        {
            lines = Wrap(value, availW, th);
            double need = lines.Count * th * 1.3;
            if (need <= availH + 0.01 || th <= 1.9) break;
            th = Math.Max(1.9, th - 0.2);
        }
        int maxLines = Math.Max(1, (int)Math.Floor(availH / (th * 1.3)));
        if (lines.Count > maxLines)
        {
            lines = lines.Take(maxLines).ToList();
            string last = lines[^1];
            while (last.Length > 1 && Detailing.TextWidth(last + "...", th) > availW) last = last[..^1];
            lines[^1] = last.TrimEnd() + "...";
        }
        for (int i = 0; i < lines.Count; i++)
            s.Text(x + pad, top - th * 0.95 - i * th * 1.3, th, lines[i], "CARTOUCHE");
    }

    /// <summary>Coupe le texte en lignes dont la largeur estimée ne dépasse pas maxW (mots trop longs coupés).</summary>
    public static List<string> Wrap(string t, double maxW, double h)
    {
        var res = new List<string>();
        string cur = "";
        foreach (var word0 in t.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            string word = word0;
            while (Detailing.TextWidth(word, h) > maxW && word.Length > 1)
            {
                int n = Math.Max(1, (int)(maxW / (h * 0.70)) - 1);
                if (cur.Length > 0) { res.Add(cur); cur = ""; }
                res.Add(word[..Math.Min(n, word.Length)] + "-");
                word = word[Math.Min(n, word.Length)..];
            }
            string trial = cur.Length == 0 ? word : cur + " " + word;
            if (Detailing.TextWidth(trial, h) <= maxW) cur = trial;
            else { if (cur.Length > 0) res.Add(cur); cur = word; }
        }
        if (cur.Length > 0) res.Add(cur);
        return res;
    }

    public static void Add(Sheet s, string project, string norms, bool licensed, DesignSettings? cfg = null)
    {
        cfg ??= new DesignSettings();
        int start = s.Items.Count;
        s.RebuildTitle = () => { s.Items.RemoveAll(e => e.Block); Add(s, project, norms, licensed, cfg); };
        s.Rect(10, 10, s.Width - 20, s.Height - 20, "CARTOUCHE");
        double w = 200, h = Height, x0 = s.Width - 10 - w, y0 = 10, top = y0 + h;
        s.Rect(x0, y0, w, h, "CARTOUCHE");
        // lignes du cartouche (hauteurs en mm, du haut vers le bas)
        double[] rows = { 11, 13, 9, 9, 8, 6 };
        double[] ys = new double[rows.Length + 1];
        ys[0] = top;
        for (int i = 0; i < rows.Length; i++) ys[i + 1] = ys[i] - rows[i];
        for (int i = 1; i < rows.Length; i++) s.Line(x0, ys[i], x0 + w, ys[i], "CARTOUCHE");
        string proj = project + (string.IsNullOrWhiteSpace(cfg.SiteName) ? "" : " - " + cfg.SiteName);
        // ligne 1 : projet | indice
        s.Line(x0 + 150, ys[0], x0 + 150, ys[1], "CARTOUCHE");
        Cell(s, x0, ys[1], 150, rows[0], "Projet", proj, 3.4);
        Cell(s, x0 + 150, ys[1], 50, rows[0], "Indice / révision", cfg.Revision ?? "", 3.4);
        // ligne 2 : titre de la planche
        Cell(s, x0, ys[2], w, rows[1], "Titre de la planche", s.Title, 4.2);
        // ligne 3 : numéro | échelle | date | format
        s.Line(x0 + 30, ys[2], x0 + 30, ys[3], "CARTOUCHE"); s.Line(x0 + 100, ys[2], x0 + 100, ys[3], "CARTOUCHE"); s.Line(x0 + 150, ys[2], x0 + 150, ys[3], "CARTOUCHE");
        Cell(s, x0, ys[3], 30, rows[2], "Planche N°", s.Number, 3.6);
        Cell(s, x0 + 30, ys[3], 70, rows[2], "Échelle", s.ScaleText, 3.2);
        Cell(s, x0 + 100, ys[3], 50, rows[2], "Date", DateTime.Now.ToString("dd/MM/yyyy"), 3.2);
        Cell(s, x0 + 150, ys[3], 50, rows[2], "Format", $"{s.Width:0} x {s.Height:0}", 3.2);
        // ligne 4 : client | ingénieur
        s.Line(x0 + 100, ys[3], x0 + 100, ys[4], "CARTOUCHE");
        Cell(s, x0, ys[4], 100, rows[3], "Maître d'ouvrage / client", string.IsNullOrWhiteSpace(cfg.Client) ? "-" : cfg.Client, 3.0);
        string eng = (string.IsNullOrWhiteSpace(cfg.Engineer) ? "-" : cfg.Engineer) + (string.IsNullOrWhiteSpace(cfg.Company) ? "" : " - " + cfg.Company);
        Cell(s, x0 + 100, ys[4], 100, rows[3], "Ingénieur / bureau d'études", eng, 3.0);
        // ligne 5 : normes
        Cell(s, x0, ys[5], w, rows[4], "Normes de calcul", norms, 2.8);
        // ligne 6 : logiciel
        Cell(s, x0, y0, w, rows[5], "", $"{AppInfo.Name} {AppInfo.Version} - {AppInfo.Author} - {AppInfo.Email} - {AppInfo.Phones}", 2.2);
        s.TextFit(15, 13, 2.2, "Plan généré automatiquement par StructCalc : à vérifier et à valider par l'ingénieur responsable avant exécution.", "CARTOUCHE", x0 - 22);
        if (!licensed)
            for (int i = 0; i < 6; i++)
                s.Text(30 + i * 62, 70 + (i % 2) * 70, 14, "EVALUATION - StructCalc", "FILIGRANE", 30);
        for (int i = start; i < s.Items.Count; i++) s.Items[i].Block = true;
    }
}

public static class DxfWriter
{
    private static string F(double v) => v.ToString("0.####", CultureInfo.InvariantCulture);

    public static string Ascii(string t)
    {
        var n = t.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (char c in n)
        {
            if (System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(c switch { 'œ' => "oe", 'Œ' => "OE", '²' => "2", '³' => "3", '°' => "deg", 'Ø' => "D", 'ø' => "d", '≥' => ">=", '≤' => "<=", '×' => "x", '·' => ".", '—' => "-", '–' => "-", '’' => "'", '€' => "EUR", _ => c.ToString() });
        }
        return new string(sb.ToString().Where(c => c >= 32 && c < 127).ToArray());
    }

    /// <summary>DXF ASCII format R12 (AC1009) : lu par toutes les versions d'AutoCAD, BricsCAD, LibreCAD, Revit (Insérer > Importer CAO) etc.</summary>
    public static string ToDxf(Sheet s)
    {
        var sb = new StringBuilder();
        void W(int code, string val) { sb.Append(code).Append("\r\n").Append(val).Append("\r\n"); }
        void W0(string val) => W(0, val);
        W0("SECTION"); W(2, "HEADER"); W(9, "$ACADVER"); W(1, "AC1009");
        W(9, "$EXTMIN"); W(10, "0"); W(20, "0"); W(9, "$EXTMAX"); W(10, F(s.Width)); W(20, F(s.Height)); W0("ENDSEC");
        W0("SECTION"); W(2, "TABLES");
        W0("TABLE"); W(2, "LTYPE"); W(70, "1");
        W0("LTYPE"); W(2, "CONTINUOUS"); W(70, "0"); W(3, "Solid line"); W(72, "65"); W(73, "0"); W(40, "0.0"); W0("ENDTAB");
        W0("TABLE"); W(2, "LAYER"); W(70, Layers.All.Length.ToString());
        foreach (var (name, color) in Layers.All) { W0("LAYER"); W(2, name); W(70, "0"); W(62, color.ToString()); W(6, "CONTINUOUS"); }
        W0("ENDTAB");
        W0("TABLE"); W(2, "STYLE"); W(70, "1");
        W0("STYLE"); W(2, "STANDARD"); W(70, "0"); W(40, "0.0"); W(41, "1.0"); W(50, "0.0"); W(71, "0"); W(42, "2.5"); W(3, "txt"); W(4, ""); W0("ENDTAB");
        W0("ENDSEC");
        W0("SECTION"); W(2, "ENTITIES");
        foreach (var e in s.Items)
        {
            switch (e.Kind)
            {
                case EntKind.Line:
                    W0("LINE"); W(8, e.Layer); W(10, F(e.X1)); W(20, F(e.Y1)); W(30, "0.0"); W(11, F(e.X2)); W(21, F(e.Y2)); W(31, "0.0"); break;
                case EntKind.Circle:
                    W0("CIRCLE"); W(8, e.Layer); W(10, F(e.X1)); W(20, F(e.Y1)); W(30, "0.0"); W(40, F(e.R));
                    if (e.Fill)
                        foreach (double f in new[] { 0.7, 0.4, 0.15 })
                        { W0("CIRCLE"); W(8, e.Layer); W(10, F(e.X1)); W(20, F(e.Y1)); W(30, "0.0"); W(40, F(e.R * f)); }
                    break;
                case EntKind.Text:
                    W0("TEXT"); W(8, e.Layer); W(10, F(e.X1)); W(20, F(e.Y1)); W(30, "0.0"); W(40, F(e.H)); W(1, Ascii(e.Text));
                    if (Math.Abs(e.Rot) > 1e-9) W(50, F(e.Rot));
                    break;
            }
        }
        W0("ENDSEC"); W0("EOF");
        return sb.ToString();
    }

    public static void Save(Sheet s, string path) => File.WriteAllText(path, ToDxf(s), Encoding.ASCII);
}
