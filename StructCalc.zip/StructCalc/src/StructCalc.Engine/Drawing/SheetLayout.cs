using System.Globalization;
using System.Text.RegularExpressions;

namespace StructCalc.Engine.Drawing;

/// <summary>Mise en page dynamique des planches : le dessin (tout sauf cadre, cartouche, titre et tableaux) est mis à l'échelle et centré dans la zone libre,
/// sans jamais déborder du cadre, du cartouche ni des tableaux. Mode « Auto » : la plus grande échelle normalisée qui tient ; ou échelle choisie dans la liste.
/// Les textes gardent leur hauteur (lisibilité) ; positions, longueurs et rayons suivent l'échelle ; les échelles affichées (1:20, coupes 1:10...) sont réécrites.</summary>
public static class SheetLayout
{
    public static readonly double[] Standard = { 1, 2, 2.5, 5, 10, 15, 20, 25, 30, 40, 50, 60, 75, 100, 125, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000 };
    private const double Margin = 6;

    public readonly record struct Region(double X0, double Y0, double X1, double Y1);

    private sealed class Bx
    {
        public double MinX = double.MaxValue, MaxX = double.MinValue, MinY = double.MaxValue, MaxY = double.MinValue;
        public void P(double x, double y) { MinX = Math.Min(MinX, x); MaxX = Math.Max(MaxX, x); MinY = Math.Min(MinY, y); MaxY = Math.Max(MaxY, y); }
        public bool Empty => MinX > MaxX;
    }

    private static bool IsHeading(Sheet s, DrawEntity e) =>
        e.Kind == EntKind.Text && !e.Block && e.Owner == null && e.Layer != "CARTOUCHE" && e.Layer != "FILIGRANE" && e.Y1 > s.Height - 30 && e.Text.Trim().Length > 3;   // pas les numéros de repères ni les lettres de coupe

    /// <summary>À appeler une fois la planche dessinée et AVANT le cartouche.</summary>
    public static void Prepare(Sheet s)
    {
        if (s.Prepared) return;
        var bx = new Bx();
        foreach (var e in s.Items)
        {
            if (e.Owner != null || e.Block || e.Layer == "CARTOUCHE" || e.Layer == "FILIGRANE" || IsHeading(s, e)) continue;
            e.Content = true;
            e.OX1 = e.X1; e.OY1 = e.Y1; e.OX2 = e.X2; e.OY2 = e.Y2; e.OR = e.R;
            if (e.Kind == EntKind.Text) e.TW = Detailing.TextWidth(e.Text, e.H);
            Ext(e, 1, 0, 0, bx);
        }
        s.Prepared = true;
        if (bx.Empty) return;                                   // aucun dessin (planche de tableaux)
        s.C0X = (bx.MinX + bx.MaxX) / 2; s.C0Y = (bx.MinY + bx.MaxY) / 2;
        s.BaseScaleText = s.ScaleText;
        var m = Regex.Match(s.ScaleText ?? "", @"^\s*1\s*:\s*(\d+(?:[.,]\d+)?)");
        s.BaseDen = m.Success ? double.Parse(m.Groups[1].Value.Replace(',', '.'), CultureInfo.InvariantCulture) : 0;
        Update(s);
    }

    public static bool HasContent(Sheet s) => s.Prepared && s.Items.Any(e => e.Content);

    // ------------------------------------------------------------------ géométrie
    /// <summary>Étendue d'une entité (d'après ses coordonnées d'origine) pour un facteur k, relativement au centre (cx, cy) du dessin d'origine.</summary>
    private static void Ext(DrawEntity e, double k, double cx, double cy, Bx b)
    {
        switch (e.Kind)
        {
            case EntKind.Line:
                b.P((e.OX1 - cx) * k, (e.OY1 - cy) * k); b.P((e.OX2 - cx) * k, (e.OY2 - cy) * k); break;
            case EntKind.Circle:
                b.P((e.OX1 - cx) * k - e.OR * k, (e.OY1 - cy) * k - e.OR * k); b.P((e.OX1 - cx) * k + e.OR * k, (e.OY1 - cy) * k + e.OR * k); break;
            default:
                TextExt(e, e.TW > 0 ? e.TW : Detailing.TextWidth(e.Text, e.H), (e.OX1 - cx) * k, (e.OY1 - cy) * k, b.P); break;
        }
    }

    private static void TextExt(DrawEntity e, double w, double ax, double ay, Action<double, double> p)
    {
        double c = Math.Cos(e.Rot * Math.PI / 180), sn = Math.Sin(e.Rot * Math.PI / 180);
        foreach (var (x, y) in new[] { (0.0, -0.3 * e.H), (w, -0.3 * e.H), (w, e.H), (0.0, e.H) })
            p(ax + x * c - y * sn, ay + x * sn + y * c);
    }

    private static (double MinX, double MaxX, double MinY, double MaxY) Extent(Sheet s, double k)
    {
        var bx = new Bx();
        foreach (var e in s.Items) if (e.Content) Ext(e, k, s.C0X, s.C0Y, bx);
        return (bx.MinX, bx.MaxX, bx.MinY, bx.MaxY);
    }

    /// <summary>Plus grand facteur d'échelle pour lequel le dessin tient dans la zone (recherche par dichotomie ; l'étendue est convexe en k).</summary>
    private static double KMax(Sheet s, Region r)
    {
        double aw = r.X1 - r.X0, ah = r.Y1 - r.Y0;
        if (aw <= 1 || ah <= 1) return 0.02;
        bool Fits(double k) { var e = Extent(s, k); return e.MaxX - e.MinX <= aw && e.MaxY - e.MinY <= ah; }
        if (!Fits(0.02)) return 0.02;
        if (Fits(50)) return 50;
        double lo = 0.02, hi = 50;
        for (int i = 0; i < 45; i++) { double mid = (lo + hi) / 2; if (Fits(mid)) lo = mid; else hi = mid; }
        return lo;
    }

    /// <summary>Zones libres candidates : au-dessus du cartouche sur toute la largeur, ou à gauche du cartouche ; sous les tableaux ou à leur gauche.</summary>
    public static List<Region> Regions(Sheet s)
    {
        double left = 10 + Margin, right = s.Width - 10 - Margin;
        var heads = s.Items.Where(e => IsHeading(s, e)).ToList();
        double top = heads.Count > 0 ? heads.Min(e => e.Y1 - 0.3 * e.H) - 4 : s.Height - 10 - Margin;
        double bottomFull = 10 + TitleBlock.Height + 8;
        double bottomLeft = 24, rightLeft = s.Width - 10 - 200 - 8;
        var res = new List<Region>();
        var tables = s.Tables;
        foreach (var (bot, rt) in new[] { (bottomFull, right), (bottomLeft, rightLeft) })
        {
            if (tables.Count == 0) { res.Add(new Region(left, bot, rt, top)); continue; }
            double tBottom = tables.Min(t => t.Bottom), tLeft = tables.Min(t => t.X0);
            res.Add(new Region(left, bot, rt, Math.Min(top, tBottom - 6)));                       // sous les tableaux
            res.Add(new Region(left, bot, Math.Min(rt, tLeft - 6), top));                          // à gauche des tableaux
        }
        return res;
    }

    private static Region Best(Sheet s, out double kmax)
    {
        var regs = Regions(s);
        var best = regs[0]; kmax = -1;
        foreach (var r in regs)
        {
            double k = KMax(s, r);
            if (k > kmax + 1e-9) { kmax = k; best = r; }
        }
        return best;
    }

    // ------------------------------------------------------------------ échelles
    private static double SnapUp(double need)
    {
        foreach (var d in Standard) if (d >= need - 1e-9) return d;
        return Standard[^1];
    }

    /// <summary>Échelles normalisées proposées (1:d) pour lesquelles le dessin tient dans la zone libre. Vide si la planche n'a pas d'échelle numérique.</summary>
    public static List<double> Options(Sheet s)
    {
        var res = new List<double>();
        if (!HasContent(s) || s.BaseDen <= 0) return res;
        Best(s, out double kmax);
        foreach (var d in Standard) if (s.BaseDen / d <= kmax + 1e-6) res.Add(d);
        return res;
    }

    public static double CurrentDen(Sheet s) => s.BaseDen > 0 ? s.BaseDen / s.Factor : 0;

    public static void SetAuto(Sheet s) { s.AutoScale = true; Update(s); }

    /// <summary>Échelle choisie : 1:den (mise à l'échelle du dessin, ramenée au plus grand format qui tient).</summary>
    public static void SetDenominator(Sheet s, double den)
    {
        if (s.BaseDen <= 0 || den <= 0) return;
        s.AutoScale = false; s.ManualFactor = s.BaseDen / den; Update(s);
    }

    /// <summary>Facteur libre (planche sans échelle numérique, ou étirement à la souris).</summary>
    public static void SetFactor(Sheet s, double factor)
    {
        s.AutoScale = false; s.ManualFactor = Math.Max(0.05, factor); Update(s);
    }

    /// <summary>Recalcule la mise à l'échelle et le centrage (après un changement de tableau, d'échelle ou de mode).</summary>
    public static void Update(Sheet s)
    {
        if (!HasContent(s)) return;
        var reg = Best(s, out double kmax);
        double f;
        if (s.AutoScale)
            f = s.BaseDen > 0 ? s.BaseDen / SnapUp(s.BaseDen / kmax) : Math.Min(1.0, kmax);
        else
        {
            f = s.ManualFactor;
            if (f > kmax) f = s.BaseDen > 0 ? s.BaseDen / SnapUp(s.BaseDen / kmax) : kmax;
        }
        Apply(s, f, reg);
    }

    private static void Apply(Sheet s, double f, Region r)
    {
        var e0 = Extent(s, f);
        double tx = (r.X0 + r.X1) / 2 - (e0.MinX + e0.MaxX) / 2, ty = (r.Y0 + r.Y1) / 2 - (e0.MinY + e0.MaxY) / 2;
        foreach (var e in s.Items)
        {
            if (!e.Content) continue;
            e.X1 = tx + (e.OX1 - s.C0X) * f; e.Y1 = ty + (e.OY1 - s.C0Y) * f;
            if (e.Kind == EntKind.Line) { e.X2 = tx + (e.OX2 - s.C0X) * f; e.Y2 = ty + (e.OY2 - s.C0Y) * f; }
            else if (e.Kind == EntKind.Circle) e.R = Math.Max(e.OR * f, 0.2);
        }
        s.Factor = f;
        if (s.BaseDen > 0) s.ScaleText = Regex.Replace(s.BaseScaleText, @"1\s*:\s*(\d+(?:[.,]\d+)?)", m =>
        {
            double d = double.Parse(m.Groups[1].Value.Replace(',', '.'), CultureInfo.InvariantCulture) / f;
            return "1:" + (Math.Abs(d - Math.Round(d)) < 0.05 ? Math.Round(d).ToString("0", CultureInfo.InvariantCulture) : d.ToString("0.#", CultureInfo.InvariantCulture));
        });
        s.RebuildTitle?.Invoke();
    }

    /// <summary>Rectangle englobant le dessin à son état actuel (mm de papier), ou null.</summary>
    public static (double X0, double Y0, double X1, double Y1)? ContentBox(Sheet s)
    {
        if (!HasContent(s)) return null;
        var bx = new Bx();
        foreach (var e in s.Items)
        {
            if (!e.Content) continue;
            switch (e.Kind)
            {
                case EntKind.Line: bx.P(e.X1, e.Y1); bx.P(e.X2, e.Y2); break;
                case EntKind.Circle: bx.P(e.X1 - e.R, e.Y1 - e.R); bx.P(e.X1 + e.R, e.Y1 + e.R); break;
                default: TextExt(e, e.TW > 0 ? e.TW : Detailing.TextWidth(e.Text, e.H), e.X1, e.Y1, bx.P); break;
            }
        }
        return (bx.MinX, bx.MinY, bx.MaxX, bx.MaxY);
    }
}
