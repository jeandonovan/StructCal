using System.Globalization;
using StructCalc.Core.Model;
using StructCalc.Engine.Stairs;

namespace StructCalc.Engine.Drawing;

/// <summary>Planche d'un escalier : plan avec marches, coupe longitudinale ferraillée, tableau des résultats.</summary>
public static class StairSheets
{
    private static string F(double v, string f = "0.0#") => v.ToString(f, CultureInfo.InvariantCulture);

    public static IEnumerable<Sheet> Build(AnalysisOutput o)
    {
        foreach (var r in o.Stairs)
        {
            if (r.Geo.Flights.Count == 0) continue;
            var s = new Sheet { Name = "Escalier " + r.Def.Name, Title = $"ESCALIER {r.Def.Name} - plan, coupe, ferraillage", ScaleText = "voir cotes" };
            var tab = BuildTable(r);
            DrawPlan(s, r);
            DrawSections(s, r, tab.Bottom);
            s.AddTable(tab);
            yield return s;
        }
    }

    // ---------------------------------------------------------------- plan
    private readonly record struct Point2(double X, double Y);
    private sealed class Poly { public List<(double X, double Y)> P = new(); }

    private static void DrawPlan(Sheet s, StairResult r)
    {
        var d = r.Def; var g = r.Geo; double w = d.WidthM;
        var lines = new List<(double X1, double Y1, double X2, double Y2, string L)>();
        var texts = new List<(double X, double Y, string T)>();
        int fl = 0;
        (double X0, double X1, double Y, int K)? firstRun = null;
        void Arr(double x1, double y1, double x2, double y2)
        {
            lines.Add((x1, y1, x2, y2, "COTES"));
            double a = Math.Atan2(y2 - y1, x2 - x1), dd = 0.17;
            lines.Add((x2, y2, x2 - dd * Math.Cos(a - 0.45), y2 - dd * Math.Sin(a - 0.45), "COTES"));
            lines.Add((x2, y2, x2 - dd * Math.Cos(a + 0.45), y2 - dd * Math.Sin(a + 0.45), "COTES"));
        }
        void Rect(double x, double y, double ww, double hh, string layer = "BETON")
        {
            lines.Add((x, y, x + ww, y, layer)); lines.Add((x + ww, y, x + ww, y + hh, layer));
            lines.Add((x + ww, y + hh, x, y + hh, layer)); lines.Add((x, y + hh, x, y, layer));
        }
        void FlightX(double x0, double y0, int dir, int k, double gg, double ww)   // volée le long de X (dir=+1/-1), contremarches k
        {
            double run = (k - 1) * gg;
            double xa = dir > 0 ? x0 : x0 - run;
            Rect(xa, y0, run, ww);
            for (int i = 1; i < k - 1 + 1; i++) { double x = dir > 0 ? x0 + i * gg : x0 - i * gg; if (i < k) lines.Add((x, y0, x, y0 + ww, "HACHURES")); }
            if (firstRun == null) firstRun = (Math.Min(x0, x0 + dir * run), Math.Max(x0, x0 + dir * run), y0, k);
            fl++; Arr(x0, y0 + ww / 2, x0 + dir * run, y0 + ww / 2);
            texts.Add((xa + run / 2 - 0.45, y0 + ww / 2 + 0.07, $"V{fl} : {k} marches"));
        }
        void Landing(double x, double y, double ww, double hh)
        {
            Rect(x, y, ww, hh);
            if (ww > 0.01 && hh > 0.01) texts.Add((x + ww / 2 - 0.22, y + hh / 2 - 0.05, "palier"));
        }
        void FlightY(double x0, double y0, int k, double gg, double ww)
        {
            double run = (k - 1) * gg;
            Rect(x0, y0, ww, run);
            for (int i = 1; i < k; i++) lines.Add((x0, y0 + i * gg, x0 + ww, y0 + i * gg, "HACHURES"));
            fl++; Arr(x0 + ww / 2, y0, x0 + ww / 2, y0 + run);
            texts.Add((x0 + ww / 2 + 0.08, y0 + run / 2, $"V{fl} : {k} marches"));
        }
        (double X, double Y) RayToRect(double cx, double cy, double a, double x0, double y0, double x1, double y1)
        {
            double dx = Math.Cos(a), dy = Math.Sin(a), t = double.MaxValue;
            if (dx > 1e-9) t = Math.Min(t, (x1 - cx) / dx); else if (dx < -1e-9) t = Math.Min(t, (x0 - cx) / dx);
            if (dy > 1e-9) t = Math.Min(t, (y1 - cy) / dy); else if (dy < -1e-9) t = Math.Min(t, (y0 - cy) / dy);
            return (cx + dx * t, cy + dy * t);
        }
        void WalkArc(double cx, double cy, double rad, double a0, double a1)
        {
            int n = 14;
            for (int i = 0; i < n; i++)
            {
                double u0 = a0 + (a1 - a0) * i / n, u1 = a0 + (a1 - a0) * (i + 1) / n;
                lines.Add((cx + rad * Math.Cos(u0), cy + rad * Math.Sin(u0), cx + rad * Math.Cos(u1), cy + rad * Math.Sin(u1), "COTES"));
            }
            double ae = a1, tx = cx + rad * Math.Cos(ae), ty = cy + rad * Math.Sin(ae), dir = a1 > a0 ? 1 : -1;
            double ta = ae + dir * Math.PI / 2, dd = 0.17;
            lines.Add((tx, ty, tx - dd * Math.Cos(ta - 0.45), ty - dd * Math.Sin(ta - 0.45), "COTES"));
            lines.Add((tx, ty, tx - dd * Math.Cos(ta + 0.45), ty - dd * Math.Sin(ta + 0.45), "COTES"));
        }
        double gk = g.TreadM;
        double maxX = 1, maxY = 1;
        string note = "";
        switch (d.Layout)
        {
            case StairLayout.Droit:
            {
                int k = g.Flights[0].Steps;
                if (d.StartLandingM > 0) Landing(-d.StartLandingM, 0, d.StartLandingM, w);
                FlightX(0, 0, 1, k, gk, w);
                double run = g.Flights[0].RunM;
                if (d.EndLandingM > 0) Landing(run, 0, d.EndLandingM, w);
                maxX = run + d.EndLandingM + Math.Max(0, d.StartLandingM); maxY = w; note = "→";
                break;
            }
            case StairLayout.DroitPalier:
            {
                int k1 = g.Flights[0].Steps, k2 = g.Flights[1].Steps;
                double r1 = g.Flights[0].RunM, r2 = g.Flights[1].RunM;
                FlightX(0, 0, 1, k1, gk, w); Landing(r1, 0, d.MidLandingM, w); FlightX(r1 + d.MidLandingM, 0, 1, k2, gk, w);
                Landing(r1 + d.MidLandingM + r2, 0, d.EndLandingM, w);
                maxX = r1 + d.MidLandingM + r2 + d.EndLandingM; maxY = w; break;
            }
            case StairLayout.QuartPalier:
            {
                int k1 = g.Flights[0].Steps, k2 = g.Flights[1].Steps;
                double r1 = g.Flights[0].RunM, r2 = g.Flights[1].RunM;
                FlightX(0, 0, 1, k1, gk, w); Landing(r1, 0, w, w); FlightY(r1, w, k2, gk, w);
                Landing(r1, w + r2, w, d.EndLandingM);
                maxX = r1 + w; maxY = w + r2 + d.EndLandingM; break;
            }
            case StairLayout.DemiPalier:
            {
                int k1 = g.Flights[0].Steps, k2 = g.Flights[1].Steps;
                double r1 = g.Flights[0].RunM, r2 = g.Flights[1].RunM;
                double depth = 2 * w + d.GapM;
                FlightX(0, 0, 1, k1, gk, w); Landing(r1, 0, w, depth);
                FlightX(r1, w + d.GapM, -1, k2, gk, w);
                maxX = r1 + w; maxY = depth; break;
            }
            case StairLayout.DoubleQuartPalier:
            {
                int k1 = g.Flights[0].Steps, k2 = g.Flights[1].Steps, k3 = g.Flights[2].Steps;
                double r1 = g.Flights[0].RunM, r2 = g.Flights[1].RunM, r3 = g.Flights[2].RunM;
                FlightX(0, 0, 1, k1, gk, w); Landing(r1, 0, w, w); FlightY(r1, w, k2, gk, w); Landing(r1, w + r2, w, w);
                FlightX(r1, w + r2, -1, k3, gk, w);
                maxX = r1 + w; maxY = 2 * w + r2; break;
            }
            case StairLayout.QuartBalance:
            case StairLayout.DemiBalance:
            {
                int nw = StairGeometryBuilder.WinderCount(d.Layout);
                int straight = g.Risers - 1 - nw; int k1 = straight - straight / 2, k2 = straight / 2;      // girons droits (n-1 girons au total)
                double r1 = k1 * gk, r2 = k2 * gk;
                FlightX(0, 0, 1, k1 + 1, gk, w);
                if (d.Layout == StairLayout.QuartBalance)
                {
                    // zone balancée carrée ; les marches rayonnent depuis le sommet intérieur (r1, w) du virage à gauche
                    Rect(r1, 0, w, w);
                    for (int i = 1; i < nw; i++)
                    {
                        double a = -Math.PI / 2 + (Math.PI / 2) * i / nw;
                        var (ex, ey) = RayToRect(r1, w, a, r1, 0, r1 + w, w);
                        lines.Add((r1, w, ex, ey, "HACHURES"));
                    }
                    WalkArc(r1, w, w / 2, -Math.PI / 2, 0);
                    FlightY(r1, w, k2 + 1, gk, w); maxX = r1 + w; maxY = w + r2;
                }
                else
                {
                    // demi-tour : centre au milieu du jour, marches en éventail de -90° à +90°
                    double depth = 2 * w + d.GapM, cy0 = w + d.GapM / 2;
                    Rect(r1, 0, w, depth);
                    for (int i = 1; i < nw; i++)
                    {
                        double a = -Math.PI / 2 + Math.PI * i / nw;
                        var (ex, ey) = RayToRect(r1, cy0, a, r1, 0, r1 + w, depth);
                        lines.Add((r1, cy0, ex, ey, "HACHURES"));
                    }
                    lines.Add((r1, w, r1, w + d.GapM, "BETON"));
                    WalkArc(r1, cy0, (w + d.GapM) / 2, -Math.PI / 2, Math.PI / 2);
                    FlightX(r1, w + d.GapM, -1, k2 + 1, gk, w); maxX = r1 + w; maxY = depth;
                }
                note = "marches balancées (tracé schématique)";
                break;
            }
            default:
            {
                double ri = d.InnerRadiusM, ro = ri + w, th = d.TurnAngleDeg * Math.PI / 180;
                int n = g.Risers; int seg = 40;
                for (int i = 0; i < seg; i++)
                {
                    double a0 = th * i / seg, a1 = th * (i + 1) / seg;
                    lines.Add((ri * Math.Cos(a0), ri * Math.Sin(a0), ri * Math.Cos(a1), ri * Math.Sin(a1), "BETON"));
                    lines.Add((ro * Math.Cos(a0), ro * Math.Sin(a0), ro * Math.Cos(a1), ro * Math.Sin(a1), "BETON"));
                }
                for (int i = 0; i < n; i++) { double a = th * i / Math.Max(1, n - 1); lines.Add((ri * Math.Cos(a), ri * Math.Sin(a), ro * Math.Cos(a), ro * Math.Sin(a), "HACHURES")); }
                maxX = 2 * ro; maxY = 2 * ro;
                texts.Add((ro - 0.5, ro - 0.05, $"{g.Risers} contremarches"));
                lines.Add((0, 0, 0, 0, "COTES"));
                // décale pour rester dans le cadre
                for (int i = 0; i < lines.Count; i++) { var l = lines[i]; lines[i] = (l.X1 + ro, l.Y1 + ro, l.X2 + ro, l.Y2 + ro, l.L); }
                break;
            }
        }
        // échelle : zone 15..200 x 80..250 mm ; le plan est ancré en haut de la planche
        double areaW = 180, areaH = 150;
        double minX = lines.Min(l => Math.Min(l.X1, l.X2)), minY = lines.Min(l => Math.Min(l.Y1, l.Y2));
        double maxXs = lines.Max(l => Math.Max(l.X1, l.X2)), maxYs = lines.Max(l => Math.Max(l.Y1, l.Y2));
        double need = Math.Max((maxXs - minX) / areaW, (maxYs - minY) / areaH);       // m par mm
        double scale = Scales.First(sc => sc >= need * 1000);                         // 1:scale
        double kk = 1000.0 / scale;                                                    // mm papier par m
        double ox = 16 + (areaW - (maxXs - minX) * kk) / 2 - minX * kk, oy = 252 - maxYs * kk;
        foreach (var l in lines) s.Line(ox + l.X1 * kk, oy + l.Y1 * kk, ox + l.X2 * kk, oy + l.Y2 * kk, l.L);
        foreach (var t in texts) s.Text(ox + t.X * kk, oy + t.Y * kk, 2.2, t.T, "TEXTE");
        double topY = oy + maxYs * kk, botY = oy + minY * kk;
        s.Text(16, 281, 4.0, $"PLAN - échelle 1:{scale:0}", "TEXTE");
        s.Text(16, 275, 2.6, $"{Layouts.Name(d.Layout)} ; emmarchement {F(d.WidthM, "0.00")} m ; {g.Risers} contremarches h = {F(g.RiserM * 100)} cm ; giron {F(g.TreadM * 100)} cm", "TEXTE");
        s.Text(16, 271, 2.4, $"Départ → arrivée ; montée {F(d.HeightM, "0.00")} m. {note}", "TEXTE");
        s.Line(ox + minX * kk, topY + 3, ox + maxXs * kk, topY + 3, "COTES");
        s.Text(ox + minX * kk + 2, topY + 4.5, 2.4, $"longueur hors tout ≈ {F(maxXs - minX, "0.00")} m ; largeur ≈ {F(maxYs - minY, "0.00")} m", "COTES");
        if (firstRun is { } fr)
        {
            double gcm = gk * 100;
            s.Dim(ox + fr.X0 * kk, ox + fr.X1 * kk, oy + fr.Y * kk - 5, $"{fr.K - 1} g = {F(fr.X1 - fr.X0, "0.00")} m", 2.2);
            s.Line(ox + fr.X0 * kk, oy + fr.Y * kk - 0.5, ox + fr.X0 * kk, oy + fr.Y * kk - 6.5, "COTES"); s.Line(ox + fr.X1 * kk, oy + fr.Y * kk - 0.5, ox + fr.X1 * kk, oy + fr.Y * kk - 6.5, "COTES");
            if (fr.K >= 3) { double xa = ox + (fr.X0 + gk) * kk, xb2 = ox + (fr.X0 + 2 * gk) * kk; s.Dim(xa, xb2, oy + fr.Y * kk - 11, $"g={F(gcm, "0")}", 2.0); s.Line(xa, oy + fr.Y * kk - 0.5, xa, oy + fr.Y * kk - 12.5, "COTES"); s.Line(xb2, oy + fr.Y * kk - 0.5, xb2, oy + fr.Y * kk - 12.5, "COTES"); }
            s.DimVert(ox + minX * kk - 6, oy + fr.Y * kk, oy + (fr.Y + w) * kk, $"{F(w, "0.00")} m", 2.0);
        }
        s.Text(ox + minX * kk, botY - 17, 2.4, "DÉPART", "TEXTE");
        // données géométriques sous le plan
        double ydata = Math.Min(botY - 27, 140);
        s.Text(16, ydata, 3.0, "GÉOMÉTRIE", "TEXTE");
        string bl = g.BlondelOk ? "conforme (59 ≤ 2h + g ≤ 64)" : "NON conforme (59 ≤ 2h + g ≤ 64)";
        s.Text(16, ydata - 5, 2.4, $"Contremarche h = {F(g.RiserM * 100)} cm ; giron g = {F(g.TreadM * 100)} cm ; 2h + g = {F(g.Blondel * 100)} cm : {bl}", "TEXTE");
        s.Text(16, ydata - 9.5, 2.4, $"Inclinaison = {F(g.AngleDeg, "0.0")}° ; épaisseur de paillasse e = {F(g.ThicknessM * 100, "0")} cm ; {g.Flights.Count} volée(s) ; développement total {F(g.TotalRunM, "0.00")} m", "TEXTE");
        s.Text(16, ydata - 14, 2.4, $"Paliers : départ {F(d.StartLandingM, "0.00")} m ; intermédiaire {F(d.MidLandingM, "0.00")} m ; arrivée {F(d.EndLandingM, "0.00")} m ; enrobage {F(d.CoverCm, "0.#")} cm", "TEXTE");
    }

    private static readonly double[] Scales = { 10, 20, 25, 30, 40, 50, 75, 100, 150, 200 };

    // ---------------------------------------------------------------- coupes (une par volée)
    private static void DrawSections(Sheet s, StairResult r, double tableBottom)
    {
        int n = Math.Max(1, r.Elements.Count);
        double top = Math.Min(268, tableBottom - 14), bottom = 76;
        double band = Math.Min(100, (top - bottom) / n);
        s.Text(212, top + 6, 4.0, n > 1 ? "COUPES LONGITUDINALES DES VOLÉES" : "COUPE LONGITUDINALE", "TEXTE");
        for (int i = 0; i < r.Elements.Count && i < r.Geo.Flights.Count; i++)
            DrawFlightSection(s, r, i, top - i * band, band);
    }

    private static void DrawFlightSection(Sheet s, StairResult r, int idx, double bandTop, double band)
    {
        var d = r.Def; var g = r.Geo; var el = r.Elements[idx]; var f = g.Flights[idx];
        double rise = f.RiseM, e = g.ThicknessM, cover = Math.Max(d.CoverCm / 100, 0.02);
        double xb = el.BeforeM;
        int kSteps = Math.Max(2, f.Steps);
        // convention unique : k contremarches => (k-1) girons, RunM = (k-1) g ; la dernière contremarche aboutit au palier / plancher
        double gg = el.RunM / (kSteps - 1);
        double hh = rise / kSteps, m = hh / gg, alpha = Math.Atan(m), ca = Math.Cos(alpha), sa = Math.Sin(alpha);
        double tv = e / ca;                                   // épaisseur verticale de la paillasse
        double zr = rise;
        double xE = xb + (kSteps - 1) * gg;                   // pied de la dernière contremarche = fin de la ligne supérieure de la paillasse
        double xS = xb + kSteps * gg;                         // la sous-face (parallèle, décalée de tv) atteint le dessous du palier
        double span = Math.Max(el.SpanM, xE);
        double xSc = Math.Min(xS, span);                      // fin de la sous-face inclinée
        // ligne supérieure de la paillasse : elle passe par le PIED de chaque contremarche ; les marches sont des triangles posés dessus
        double Zt(double x) => (x - xb) * m;
        double Zs(double x) => Zt(x) - tv;                    // sous-face parallèle
        // échelle : hauteur réservée = montée + épaisseur ; 33 mm sous le dessin pour les cotes
        double areaW = 126, areaH = Math.Max(14, band - 33), ox0 = 214;
        double need = Math.Max(span / areaW, (rise + tv + 0.3) / areaH);
        double scale = Scales.First(sc => sc >= need * 1000); double k = 1000.0 / scale;
        double ox = ox0 + (areaW - span * k) / 2, oy = bandTop - 12 - (rise + tv + 0.25) * k;   // oy = ordonnée papier du niveau z = -tv
        Point2 P(double x, double z) => new(ox + x * k, oy + (z + tv) * k);
        void Seg(double xa, double za, double xb2, double zb) { var a1 = P(xa, za); var b1 = P(xb2, zb); s.Line(a1.X, a1.Y, b1.X, b1.Y, "BETON"); }
        s.Text(212, bandTop - 3.5, 2.8, $"{el.Name} - échelle 1:{scale:0}", "TEXTE");
        s.Text(212 + 60, bandTop - 3.5, 2.2, $"portée {F(span, "0.00")} m ; e = {F(e * 100, "0")} cm ; enrobage {F(cover * 100, "0.#")} cm", "TEXTE");

        // ---- contour béton
        double zEndS = Zs(xSc);                                // cote de la sous-face à l'appui d'arrivée
        Seg(0, -tv, xb, -tv); Seg(xb, -tv, xSc, zEndS); if (span > xS + 1e-9) Seg(xS, zr - tv, span, zr - tv);   // sous-face
        Seg(0, -tv, 0, 0); Seg(span, zEndS, span, zr);                                        // about
        if (xb > 0) Seg(0, 0, xb, 0);                                                          // palier de départ
        Seg(xb, 0, xE, zr - hh);                                                               // ligne supérieure : du pied de la 1re au pied de la dernière contremarche
        if (d.StepsFilled)
            for (int i = 0; i < kSteps; i++)
            {
                double xi = xb + i * gg, zi = i * hh;
                Seg(xi, zi, xi, zi + hh);                                                      // contremarche
                Seg(xi, zi + hh, i < kSteps - 1 ? xi + gg : span, zi + hh);                    // marche (la dernière rejoint le palier)
            }
        else { Seg(xE, zr - hh, xE, zr); Seg(xE, zr, span, zr); }
        // appuis
        foreach (var (x, z) in new[] { (0.0, -tv), (span, zEndS) })
        {
            var q = P(x, z);
            s.Line(q.X - 3, q.Y - 0.2, q.X + 3, q.Y - 0.2, "CONTOUR");
            s.Line(q.X, q.Y, q.X - 2, q.Y - 3.0, "CONTOUR"); s.Line(q.X, q.Y, q.X + 2, q.Y - 3.0, "CONTOUR");
            s.Line(q.X - 2, q.Y - 3.0, q.X + 2, q.Y - 3.0, "CONTOUR");
        }

        // ---- armatures : lit inférieur parallèle à la sous-face (en rouge), chapeaux
        double c = cover, cc = c / ca;
        void Bar(string layer, params (double X, double Z)[] pts)
        {
            for (int i = 0; i + 1 < pts.Length; i++)
            {
                var a1 = P(pts[i].X, pts[i].Z); var b1 = P(pts[i + 1].X, pts[i + 1].Z);
                s.Line(a1.X, a1.Y, b1.X, b1.Y, layer);
            }
        }
        double jd = (c - cc) / m;                              // décalage des jonctions (cadre incliné)
        var bot = new List<(double X, double Z)> { (0.05, -tv + c), (Math.Max(0.05, xb + jd), -tv + c) };
        if (xS + jd < span - 0.1) { bot.Add((xS + jd, zr - tv + c)); bot.Add((span - 0.05, zr - tv + c)); }
        else bot.Add((span - 0.05, Zs(span - 0.05) + cc));
        Bar("ARMATURES", bot.ToArray());
        double lc = Math.Min(0.25 * span, Math.Max(0.3, xE - 0.1));
        double xA = Math.Max(xb + 0.05, Math.Min(lc, xE - 0.05));
        var chA = new List<(double X, double Z)>();
        if (xb > 0.05) { chA.Add((0.05, -c)); chA.Add((xb, -cc)); } else chA.Add((0.05, Math.Max(-c, Zt(0.05) - cc)));
        chA.Add((xA, Zt(xA) - cc));
        Bar("ARMATURES_HAUTES", chA.ToArray());
        double xB = Math.Max(xb + 0.05, xE - lc);
        Bar("ARMATURES_HAUTES", (xB, Zt(xB) - cc), (xE, Zt(xE) - cc), (Math.Min(span - 0.06, xE + 0.15), zr - c), (span - 0.05, zr - c));
        // répartition : points sur le lit inférieur
        double xmid = 0.5 * (xb + xE);
        for (int i = -2; i <= 2; i++)
        {
            double xx = xmid + i * 0.10; var q = P(xx, Zs(xx) + cc + 0.012);
            s.Dot(q.X, q.Y, Math.Max(0.5, 0.006 * k), "ARMATURES2");
        }
        // repères numérotés (légende à droite)
        void Mark(double px, double pz, double dx, double dy, string n)
        {
            var q = P(px, pz);
            s.Line(q.X, q.Y, q.X + dx, q.Y + dy, "REPERES");
            s.Bubble(q.X + dx, q.Y + dy + (dy > 0 ? 1.6 : -1.6), 1.7, n);
        }
        double x1m = xmid - 0.35 * (xE - xb);
        Mark(x1m, Zs(x1m) + cc, 6, -9, "1");
        Mark(xA * 0.5, xb > 0.05 ? -c : Zt(xA * 0.5) - cc, -2, 8, "2");
        Mark((xB + xE) / 2, Zt((xB + xE) / 2) - cc, 2, 8, "3");
        Mark(xmid, Zs(xmid) + cc + 0.012, 8, -9, "4");

        // ---- cotes : marche (giron, contremarche), paillasse (longueur, épaisseur), portées
        int ti = Math.Max(0, Math.Min(kSteps - 3, kSteps / 2 - 1));
        if (d.StepsFilled && kSteps >= 3)
        {
            double xi = xb + ti * gg, zi = (ti + 1) * hh;
            var a1 = P(xi, zi); var b1 = P(xi + gg, zi);
            s.Dim(a1.X, b1.X, a1.Y + 6.5, F(gg * 100, "0.#"), 2.0);
            s.Line(a1.X, a1.Y + 0.5, a1.X, a1.Y + 8.5, "COTES"); s.Line(b1.X, b1.Y + 0.5, b1.X, b1.Y + 8.5, "COTES");
            var r1 = P(xi + gg, zi); var r2 = P(xi + gg, zi + hh);
            s.DimVert(r1.X - 3.5, r1.Y, r2.Y, F(hh * 100, "0.#"), 2.0);
            s.Line(r1.X - 5.3, r1.Y, r1.X - 0.2, r1.Y, "COTES"); s.Line(r1.X - 5.3, r2.Y, r1.X - 0.2, r2.Y, "COTES");
        }
        // paillasse : cote alignée sous la sous-face
        var A = P(xb, -tv); var B = P(xE, Zs(xE));
        double Lp = (xE - xb) / ca;                           // = longueur inclinée de la paillasse (pied 1re -> pied dernière contremarche)
        double ux = Math.Cos(alpha), uy = Math.Sin(alpha), nx = sa, ny = -ca, off = 6.5;
        var A2 = new Point2(A.X + nx * off, A.Y + ny * off); var B2 = new Point2(B.X + nx * off, B.Y + ny * off);
        s.Line(A.X + nx * 1.0, A.Y + ny * 1.0, A2.X + nx * 1.5, A2.Y + ny * 1.5, "COTES"); s.Line(B.X + nx * 1.0, B.Y + ny * 1.0, B2.X + nx * 1.5, B2.Y + ny * 1.5, "COTES");
        s.Line(A2.X, A2.Y, B2.X, B2.Y, "COTES");
        foreach (var q in new[] { A2, B2 }) s.Line(q.X - ux * 0.9 - nx * 0.9, q.Y - uy * 0.9 - ny * 0.9, q.X + ux * 0.9 + nx * 0.9, q.Y + uy * 0.9 + ny * 0.9, "COTES");
        string lab = $"paillasse L = {F(Lp, "0.00")} m";
        double th = 2.2, lw = Detailing.TextWidth(lab, th), Lpaper = Lp * k; if (lw > Lpaper) th = Math.Max(1.6, th * Lpaper / lw);
        lw = Detailing.TextWidth(lab, th);
        s.Text(A2.X + ux * (Lpaper / 2 - lw / 2) - nx * 0.9, A2.Y + uy * (Lpaper / 2 - lw / 2) - ny * 0.9, th, lab, "COTES", alpha * 180 / Math.PI);
        // épaisseur de paillasse (perpendiculaire à la ligne supérieure)
        double xmm = 0.5 * (xb + xE); var Mn = P(xmm, Zt(xmm));
        double thk = e * k; var Ms = new Point2(Mn.X + nx * thk, Mn.Y + ny * thk);
        s.Line(Mn.X, Mn.Y, Ms.X, Ms.Y, "COTES");
        s.Line(Mn.X - ux * 1.2, Mn.Y - uy * 1.2, Mn.X + ux * 1.2, Mn.Y + uy * 1.2, "COTES");
        s.Line(Ms.X - ux * 1.2, Ms.Y - uy * 1.2, Ms.X + ux * 1.2, Ms.Y + uy * 1.2, "COTES");
        s.Leader(Mn.X, Mn.Y, Mn.X - 12, Mn.Y + 9, $"e = {F(e * 100, "0")} cm", "COTES", 2.0);
        // portées et développement horizontal
        var L0 = P(0, -tv); var L1 = P(span, -tv);
        double yRun = oy - 14;
        if (xE > xb + 0.01) { var r0 = P(xb, -tv); var rr = P(xE, -tv); s.Dim(r0.X, rr.X, yRun, $"{kSteps - 1} g = {F(xE - xb, "0.00")} m"); }
        s.Dim(L0.X, L1.X, yRun - 7, $"portée {F(span, "0.00")} m");
        var z0 = P(0, 0); var z1 = P(0, zr);
        s.DimVert(ox - 8, z0.Y, z1.Y, $"{F(zr, "0.00")} m");

        // légende
        double lx = 343, ly = bandTop - 8;
        var entries = new List<(string N, string T)>
        {
            ("1", $"{el.BarsT} en travée : {F(el.AsT, "0.00")} cm²/m"),
            ("2", $"{el.BarsA} chapeaux : {F(el.AsA, "0.00")} cm²/m, L = {F(lc, "0.00")} m"),
            ("3", $"{el.BarsB} chapeaux : {F(el.AsB, "0.00")} cm²/m"),
            ("4", $"Répartition {el.BarsDistr} : {F(el.AsDistr, "0.00")} cm²/m"),
        };
        foreach (var en in entries)
        {
            if (ly < bandTop - band + 3) break;
            s.Bubble(lx + 1.7, ly + 0.6, 1.6, en.N);
            var wl = TitleBlock.Wrap(en.T, 58, 2.0);
            for (int i = 0; i < wl.Count; i++) { s.Text(lx + 4.6, ly - i * 2.7, 2.0, wl[i], "TEXTE"); }
            ly -= Math.Max(5.0, wl.Count * 2.7 + 2.0);
        }
    }

    // ---------------------------------------------------------------- tableau (coin supérieur droit, redimensionnable)
    private static SheetTable BuildTable(StairResult r)
    {
        var t = new SheetTable
        {
            Title = "TABLEAU DES VOLÉES", Subtitle = "Sollicitations ELU, armatures, charges et quantités",
            Header = new[] { "Élément", "L (m)", "Mt kN.m", "Ma kN.m", "Vu kN", "Travée", "Chapeaux", "Répartition", "État" },
            ColW = new[] { 22.0, 17, 17, 17, 14, 26, 26, 26, 16 }, TextH = 2.2, BodyRowMin = 5.6,
        };
        foreach (var e in r.Elements)
            t.Rows.Add(new[] { e.Name, F(e.SpanM, "0.00"), F(e.MtU, "0.0"), F(Math.Max(e.MaU, e.MbU), "0.0"), F(e.Vu, "0.0"), e.BarsT, e.BarsA, e.BarsDistr, e.Ok ? "OK" : "NON OK" });
        t.Rows.Add(new[] { "Charges", $"G vol. {F(r.Loads.GFlight, "0.00")}", $"G pal. {F(r.Loads.GLanding, "0.00")}", $"Q {F(r.Loads.Q, "0.00")}", "kN/m²", "", "", "", "" });
        t.Rows.Add(new[] { "Quantités", $"béton {F(r.ConcreteM3, "0.00")} m³", $"acier ≈ {r.SteelKg:0} kg", $"coffrage {F(r.FormworkM2, "0.0")} m²", "", "", "", "", "" });
        for (int i = 0; i < t.Rows.Count; i++) t.Shapes.Add(null);
        t.AutoSize();
        return t;
    }
}
