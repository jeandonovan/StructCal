using StructCalc.Core;

namespace StructCalc.Engine.Drawing;

/// <summary>Paramètres des coupes types de dalle (cm sauf indication contraire).</summary>
public sealed class SlabTypeParams
{
    // sélection des types
    public bool Solid = true, Ribbed = true, Predalle = true, HollowCore = true, FlatSlab = true, Composite = true;
    // dalle pleine
    public double SolidH = 16, Cover = 3; public int BotDia = 10, TopDia = 8; public double BotE = 15, TopE = 20;
    // corps creux
    public double HourdisH = 16, ToppingH = 4, RibSpacing = 60, RibWidth = 12; public int RibBars = 2, RibDia = 10;
    // prédalle
    public double PredalleH = 5, PredalleTotalH = 20;
    // alvéolée
    public double HollowH = 20; public int HollowCores = 5;
    // dalle champignon
    public double FlatH = 22, DropH = 38, DropWidth = 200, ColumnWidth = 40;
    // plancher mixte
    public double DeckH = 6, CompositeH = 12;
}

/// <summary>Planches de coupes types de dalle : dalle pleine, plancher à corps creux, prédalle, dalle alvéolée, dalle champignon, plancher mixte.
/// Dessins de principe cotés (non d'exécution) ; les cotes suivent l'unité de section du projet.</summary>
public static class SlabTypeSheets
{
    private static string D(double cm) => Units.SpS(cm);
    private static string U => Units.Section;

    private static void Conc(Sheet s, double x, double y, double w, double h, double step = 2.2)
    {
        s.Rect(x, y, w, h, "BETON");
        s.Hatch(x, y, w, h, step);
    }

    private static void Card(Sheet s, double x, double y, double w, double h, string title, string scale)
    {
        s.Rect(x, y, w, h, "TABLEAU");
        s.Text(x + 3, y + h - 6, 3.4, title, "TEXTE");
        s.Text(x + w - 4 - Detailing.TextWidth("Ech. " + scale, 2.4), y + h - 5.6, 2.4, "Ech. " + scale, "TEXTE");
    }

    // ------------------------------------------------------------------ 1. dalle pleine
    private static void Solid(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "1. DALLE PLEINE (coupe transversale)", "1:10");
        double k = 1.0;                                    // 1 cm = 1 mm de papier (1:10)
        double ox = x + 30, oy = y + 28, W = 120, H = p.SolidH * k, cv = p.Cover * k;
        Conc(s, ox, oy, W, H);
        for (double xx = ox + p.BotE * k / 2; xx < ox + W; xx += p.BotE * k) s.Dot(xx, oy + cv, Math.Max(0.7, p.BotDia / 20.0), "ARMATURES");
        for (double xx = ox + p.TopE * k / 2; xx < ox + W; xx += p.TopE * k) s.Dot(xx, oy + H - cv, Math.Max(0.6, p.TopDia / 20.0), "ARMATURES_HAUTES");
        s.Line(ox + 2, oy + cv + p.BotDia / 10.0, ox + W - 2, oy + cv + p.BotDia / 10.0, "ARMATURES2");      // armatures de répartition
        s.Line(ox + 2, oy + H - cv - p.TopDia / 10.0, ox + W - 2, oy + H - cv - p.TopDia / 10.0, "ARMATURES2");
        s.DimVert(ox - 8, oy, oy + H, D(p.SolidH));
        s.Dim(ox + p.BotE * k / 2, ox + p.BotE * k * 1.5, oy - 8, $"e={D(p.BotE)}");
        s.Text(x + 3, y + 14, 2.4, $"Nappe inférieure HA{p.BotDia} e = {D(p.BotE)} {U} (sens porteur) + répartition ; enrobage {D(p.Cover)} {U}", "TEXTE");
        s.Text(x + 3, y + 9.5, 2.4, $"Nappe supérieure HA{p.TopDia} e = {D(p.TopE)} {U} (chapeaux sur appuis et peau supérieure)", "TEXTE");
        s.Text(x + 3, y + 5, 2.1, "Usage : portées 3 à 6 m, dalles de balcon, planchers lourds, radiers de faible épaisseur, voiles-dalles.", "TEXTE");
    }

    // ------------------------------------------------------------------ 2. corps creux
    private static void Ribbed(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "2. PLANCHER À CORPS CREUX (hourdis + poutrelles)", "1:5");
        double k = 2.0;                                    // 1 cm = 2 mm (1:5)
        double e = p.RibSpacing * k, bw = p.RibWidth * k, hh = p.HourdisH * k, tp = p.ToppingH * k;
        double W = 2 * e, ox = x + (w - W) / 2 + 4, oy = y + 26;
        if (W > w - 30) { k = 1.2; e = p.RibSpacing * k; bw = p.RibWidth * k; hh = p.HourdisH * k; tp = p.ToppingH * k; W = 2 * e; ox = x + (w - W) / 2 + 4; }
        Conc(s, ox, oy + hh, W, tp);                                         // dalle de compression
        for (int i = 0; i < 2; i++)
        {
            double cx = ox + e / 2 + i * e;                                  // axe de la nervure
            Conc(s, cx - bw / 2, oy, bw, hh);
            double pt = Math.Min(4 * k, hh * 0.3);
            s.Rect(cx - bw / 2 + 0.6, oy, bw - 1.2, pt, "ACIER");           // talon de la poutrelle
            for (int b = 0; b < p.RibBars; b++)
                s.Dot(cx - bw / 4 + b * bw / 2 / Math.Max(1, p.RibBars - 1) , oy + 3 * k, Math.Max(0.7, p.RibDia / (k > 1.5 ? 10.0 : 16.0)), "ARMATURES");
        }
        // hourdis (entrevous) : 3 blocs dont 2 demi-blocs aux rives
        double[] bx = { ox, ox + e / 2 + bw / 2, ox + e + e / 2 + bw / 2 };
        double[] bwid = { e / 2 - bw / 2, e - bw, e / 2 - bw / 2 };
        for (int i = 0; i < 3; i++)
        {
            s.Rect(bx[i], oy, bwid[i], hh, "CONTOUR");
            double wall = 0.9 * k;
            s.Rect(bx[i] + wall * 1.5, oy + wall * 1.5, bwid[i] - wall * 3, hh - wall * 3, "FILIGRANE");
        }
        s.Line(ox + 1, oy + hh + tp - 1.8 * k, ox + W - 1, oy + hh + tp - 1.8 * k, "ARMATURES_HAUTES");   // treillis soudé
        s.DimVert(ox - 8, oy, oy + hh + tp, D(p.HourdisH + p.ToppingH));
        s.DimVert(ox + W + 8, oy + hh, oy + hh + tp, D(p.ToppingH));
        s.Dim(ox + e / 2 - bw / 2, ox + e / 2 + bw / 2, oy - 6, D(p.RibWidth));
        s.Dim(ox + e / 2, ox + e / 2 + e, oy - 13, $"entraxe {D(p.RibSpacing)}");
        s.Text(x + 3, y + 5.5, 2.1, $"Hourdis {D(p.HourdisH)} + dalle de compression {D(p.ToppingH)} ({U}) ; treillis soudé ST10 en compression ; {p.RibBars} HA{p.RibDia} par nervure.", "TEXTE");
    }

    // ------------------------------------------------------------------ 3. prédalle
    private static void Predalle(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "3. DALLE SUR PRÉDALLE (béton coulé en place)", "1:10");
        double k = 1.0, ox = x + 30, oy = y + 28, W = 120, H = p.PredalleTotalH * k, ph = p.PredalleH * k;
        Conc(s, ox, oy, W, ph, 1.6);
        Conc(s, ox, oy + ph, W, H - ph, 3.2);
        s.DashLine(ox, oy + ph, ox + W, oy + ph, "AXES", 2, 1);
        for (double xx = ox + 7.5; xx < ox + W; xx += 15) s.Dot(xx, oy + 2.0, 0.7, "ARMATURES");
        // raidisseurs treillis
        for (double xx = ox + 15; xx < ox + W - 10; xx += 60)
        {
            double top = oy + H - 3;
            s.Line(xx - 4, oy + ph, xx, top, "ARMATURES2"); s.Line(xx, top, xx + 4, oy + ph, "ARMATURES2");
            s.Dot(xx, top, 0.8, "ARMATURES_HAUTES"); s.Dot(xx - 4, oy + ph + 0.4, 0.6, "ARMATURES"); s.Dot(xx + 4, oy + ph + 0.4, 0.6, "ARMATURES");
        }
        s.Line(ox + 2, oy + H - 3.5, ox + W - 2, oy + H - 3.5, "ARMATURES_HAUTES");
        s.DimVert(ox - 8, oy, oy + ph, D(p.PredalleH));
        s.DimVert(ox - 18, oy, oy + H, D(p.PredalleTotalH));
        s.Text(x + 3, y + 14, 2.4, $"Prédalle préfabriquée {D(p.PredalleH)} {U} (armatures inférieures et raidisseurs treillis) + béton coulé en place {D(p.PredalleTotalH - p.PredalleH)} {U}", "TEXTE");
        s.Text(x + 3, y + 9.5, 2.4, "Armatures supérieures et chapeaux posés sur chantier ; la liaison prédalle / béton est assurée par les treillis.", "TEXTE");
        s.Text(x + 3, y + 5, 2.1, "Usage : grandes surfaces, cadence de chantier élevée, coffrage réduit.", "TEXTE");
    }

    // ------------------------------------------------------------------ 4. alvéolée
    private static void Hollow(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "4. DALLE ALVÉOLÉE PRÉCONTRAINTE (plancher préfabriqué)", "1:10");
        double k = 1.0, ox = x + 30, oy = y + 28, W = 120, H = p.HollowH * k;
        Conc(s, ox, oy, W, H, 2.6);
        int n = Math.Max(2, p.HollowCores);
        double r = Math.Min(H * 0.32, W / n * 0.38);
        for (int i = 0; i < n; i++)
        {
            double cx = ox + W / n * (i + 0.5);
            s.Circle(cx, oy + H / 2, r, "CONTOUR");
        }
        for (double xx = ox + 6; xx < ox + W; xx += 12) s.Dot(xx, oy + 3, 0.7, "ARMATURES");
        s.Line(ox, oy + H, ox, oy, "CONTOUR");
        s.DimVert(ox - 8, oy, oy + H, D(p.HollowH));
        s.Dim(ox, ox + W, oy - 8, D(120));
        s.Text(x + 3, y + 14, 2.4, $"Éléments de largeur {D(120)} {U}, hauteur {D(p.HollowH)} {U}, {n} alvéoles ; torons de précontrainte en sous-face.", "TEXTE");
        s.Text(x + 3, y + 9.5, 2.4, "Joints clavetés au mortier entre éléments ; table de compression ou chape armée éventuelle (5 cm).", "TEXTE");
        s.Text(x + 3, y + 5, 2.1, "Usage : grandes portées (6 à 12 m), parkings, bâtiments industriels et commerciaux.", "TEXTE");
    }

    // ------------------------------------------------------------------ 5. champignon
    private static void Flat(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "5. DALLE CHAMPIGNON (plancher-dalle avec chapiteau)", "1:20");
        double k = 0.5, ox = x + 14, oy = y + 20, W = 160;
        double H = p.FlatH * k, DH = p.DropH * k, DW = p.DropWidth * k / 10 * 1.0, CW = p.ColumnWidth * k;
        DW = Math.Min(p.DropWidth / 100.0 * 50, W * 0.6);
        double cx = ox + W / 2, colH = 26;
        Conc(s, ox, oy + colH + (DH - H), W, H, 2.4);                                    // dalle
        Conc(s, cx - DW / 2, oy + colH, DW, DH - H, 2.4);                               // chapiteau
        Conc(s, cx - CW / 2, oy, CW, colH, 2.4);                                        // poteau
        double top = oy + colH + DH;
        s.Line(ox + 2, top - 1.6, ox + W - 2, top - 1.6, "ARMATURES_HAUTES");           // chapeaux sur poteau
        s.Line(cx - DW / 2 - 6, top - 2.4, cx + DW / 2 + 6, top - 2.4, "ARMATURES_HAUTES");
        s.Line(ox + 2, oy + colH + (DH - H) + 1.5, ox + W - 2, oy + colH + (DH - H) + 1.5, "ARMATURES");
        s.DimVert(ox - 6, oy + colH + (DH - H), top, D(p.FlatH));
        s.DimVert(cx + DW / 2 + 12, oy + colH, top, D(p.DropH));
        s.Dim(cx - DW / 2, cx + DW / 2, oy + colH - 4, D(p.DropWidth));
        s.Text(x + 3, y + 14, 2.4, $"Dalle {D(p.FlatH)} {U}, chapiteau {D(p.DropH)} {U} sur {D(p.DropWidth)} {U} ; poteau {D(p.ColumnWidth)} {U} (poinçonnement à vérifier).", "TEXTE");
        s.Text(x + 3, y + 9.5, 2.4, "Chapeaux concentrés sur la bande de poteau ; armatures de poinçonnement possibles autour du poteau.", "TEXTE");
        s.Text(x + 3, y + 5, 2.1, "Usage : bâtiments sans poutres retombantes, hauteur d'étage réduite, planchers flexibles en plan.", "TEXTE");
    }

    // ------------------------------------------------------------------ 6. mixte
    private static void Composite(Sheet s, SlabTypeParams p, double x, double y, double w, double h)
    {
        Card(s, x, y, w, h, "6. PLANCHER MIXTE ACIER-BÉTON (bac collaborant)", "1:5");
        double k = 2.0, ox = x + 25, oy = y + 28, W = 120, H = p.CompositeH * k, dh = p.DeckH * k, pitch = 15 * k * 0.5;
        // béton au-dessus des nervures
        Conc(s, ox, oy + dh, W, H - dh, 2.0);
        // bac : trapèzes
        var pts = new List<(double X, double Y)>();
        double xx = ox;
        while (xx + pitch <= ox + W + 0.01)
        {
            pts.Add((xx, oy)); pts.Add((xx + pitch * 0.2, oy + dh)); pts.Add((xx + pitch * 0.6, oy + dh)); pts.Add((xx + pitch * 0.8, oy)); xx += pitch;
        }
        pts.Add((ox + W, oy));
        for (int i = 0; i + 1 < pts.Count; i++) s.Line(pts[i].X, pts[i].Y, pts[i + 1].X, pts[i + 1].Y, "ACIER");
        // hachures du béton remplissant les nervures (triangles/trapèzes)
        for (double hx = ox + pitch * 0.5; hx < ox + W - pitch * 0.2; hx += pitch) s.Line(hx - 1, oy + 0.6, hx + 1, oy + dh - 0.6, "HACHURES");
        s.Line(ox + 2, oy + H - 3.0 * k, ox + W - 2, oy + H - 3.0 * k, "ARMATURES_HAUTES");             // treillis anti-fissuration
        s.DimVert(ox - 8, oy, oy + H, D(p.CompositeH));
        s.DimVert(ox + W + 8, oy, oy + dh, D(p.DeckH));
        s.Text(x + 3, y + 14, 2.4, $"Bac acier nervuré h = {D(p.DeckH)} {U} + béton ; épaisseur totale {D(p.CompositeH)} {U} ; treillis soudé de répartition.", "TEXTE");
        s.Text(x + 3, y + 9.5, 2.4, "Connecteurs (goujons soudés) sur les poutres métalliques pour la liaison mixte ; bac étayé ou non selon la portée.", "TEXTE");
        s.Text(x + 3, y + 5, 2.1, "Usage : ossatures métalliques, planchers de bureaux, gain de temps (coffrage perdu).", "TEXTE");
    }

    public static List<Sheet> Build(SlabTypeParams p)
    {
        var list = new List<Action<Sheet, double, double, double, double>>();
        if (p.Solid) list.Add((s, x, y, w, h) => Solid(s, p, x, y, w, h));
        if (p.Ribbed) list.Add((s, x, y, w, h) => Ribbed(s, p, x, y, w, h));
        if (p.Predalle) list.Add((s, x, y, w, h) => Predalle(s, p, x, y, w, h));
        if (p.HollowCore) list.Add((s, x, y, w, h) => Hollow(s, p, x, y, w, h));
        if (p.FlatSlab) list.Add((s, x, y, w, h) => Flat(s, p, x, y, w, h));
        if (p.Composite) list.Add((s, x, y, w, h) => Composite(s, p, x, y, w, h));
        var res = new List<Sheet>();
        int pages = (int)Math.Ceiling(list.Count / 4.0);
        for (int pg = 0; pg < pages; pg++)
        {
            var s = new Sheet { Name = "Types de dalle", Title = "TYPES DE DALLE - COUPES TYPES" + (pages > 1 ? $" ({pg + 1}/{pages})" : ""), ScaleText = "voir chaque coupe" };
            const double cw = 195, ch = 96;
            for (int i = 0; i < 4 && pg * 4 + i < list.Count; i++)
            {
                int col = i % 2, row = i / 2;
                double x = 12 + col * (cw + 6), y = (row == 0 ? 176 : 72);
                list[pg * 4 + i](s, x, y, cw, ch);
            }
            s.Text(15, 277.5, 2.4, $"Cotes en {U}. Dessins de principe : les sections d'acier, enrobages et dispositions sont à définir par le calcul et le cahier des charges.", "TEXTE");
            res.Add(s);
        }
        return res;
    }
}
