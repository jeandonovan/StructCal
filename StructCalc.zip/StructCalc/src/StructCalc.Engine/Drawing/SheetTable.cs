namespace StructCalc.Engine.Drawing;

public enum TableHitKind { Column, Row, Left, Bottom }
public readonly record struct TableHit(TableHitKind Kind, int Index);

/// <summary>Tableau de planche (nomenclature, récapitulatif...) ancré dans le coin supérieur droit du cadre.
/// Le contenu de chaque case (texte ou schéma de façonnage) est remis en page DANS la case à chaque modification :
/// en tirant une ligne ou une colonne dans la visionneuse, tout se réajuste (taille du texte, retours à la ligne, échelle des schémas).</summary>
public sealed class SheetTable
{
    public const double DefaultRight = 408, DefaultTop = 284, MaxHeight = 205, MinCol = 6, MinRow = 3.2;
    public const double TitleHeightDefault = 9, HeaderHeightDefault = 9;
    public const double MinText = 1.2;

    public string Title = "", Subtitle = "", Layer = "TABLEAU";
    public string[] Header = Array.Empty<string>();
    public List<string[]> Rows { get; } = new();
    public List<BarLine?> Shapes { get; } = new();          // parallèle à Rows ; null = pas de schéma
    public int ShapeCol = -1;
    public double[] ColW = Array.Empty<double>();
    public double[] RowH = Array.Empty<double>();           // [0] = en-tête, puis une hauteur par ligne
    public double TitleH = TitleHeightDefault;
    public double Right = DefaultRight, Top = DefaultTop;
    public double TextH = 2.3;
    public double BodyRowMin = 5.6;                         // hauteur minimale d'une ligne de texte

    public double Width => ColW.Sum();
    public double X0 => Right - Width;
    public double GridTop => Top - TitleH;
    public double Height => TitleH + RowH.Sum();
    public double Bottom => Top - Height;

    private double[] _snapCol = Array.Empty<double>(), _snapRow = Array.Empty<double>();
    private static readonly Dictionary<string, double[]> Remembered = new();
    private string Key => Title + "|" + ColW.Length;

    // ------------------------------------------------------------------ dimensionnement automatique
    /// <summary>Hauteur de ligne d'un tableau à schémas, pour n lignes (même formule que AutoSize).</summary>
    public static double ShapeRowHeight(int n) => Math.Clamp((MaxHeight - TitleHeightDefault - HeaderHeightDefault) / Math.Max(1, n), 5.2, 10);
    public static double EstimateHeight(int n, bool shapes, double textRow = 6.2) =>
        TitleHeightDefault + HeaderHeightDefault + n * (shapes ? ShapeRowHeight(n) : textRow);

    private static double Need(string t, double w, double th)
    {
        if (string.IsNullOrWhiteSpace(t)) return 0;
        return TitleBlock.Wrap(t.Trim(), Math.Max(2, w - 1.4), th).Count * th * 1.25 + 1.2;
    }

    public void AutoSize(double maxHeight = MaxHeight)
    {
        int n = Rows.Count;
        var h = new double[n + 1];
        double hn = HeaderHeightDefault;
        for (int c = 0; c < ColW.Length && c < Header.Length; c++) hn = Math.Max(hn, Math.Min(Need(Header[c], ColW[c], 2.0), 12));
        h[0] = hn;
        double shapeRow = ShapeCol >= 0 ? ShapeRowHeight(n) : 0;
        for (int i = 0; i < n; i++)
        {
            double r = BodyRowMin;
            for (int c = 0; c < ColW.Length && c < Rows[i].Length; c++)
                if (c != ShapeCol) r = Math.Max(r, Math.Min(Need(Rows[i][c], ColW[c], 2.0), 12));
            if (ShapeCol >= 0 && i < Shapes.Count && Shapes[i] != null) r = Math.Max(r, shapeRow);
            h[i + 1] = r;
        }
        double total = TitleH + h.Sum();
        if (total > maxHeight)
        {
            double f = (maxHeight - TitleH) / h.Sum();
            for (int i = 0; i < h.Length; i++) h[i] = Math.Max(MinRow, h[i] * f);
        }
        RowH = h;
        ApplyRemembered();
    }

    private void ApplyRemembered()
    {
        if (Remembered.TryGetValue(Key, out var fr) && fr.Length == ColW.Length)
        {
            double w = Width;
            for (int i = 0; i < ColW.Length; i++) ColW[i] = Math.Max(MinCol, fr[i] * w);
        }
    }

    public void Remember() { double w = Width; Remembered[Key] = ColW.Select(c => c / w).ToArray(); }

    // ------------------------------------------------------------------ dessin
    public void Rebuild(Sheet s)
    {
        s.Items.RemoveAll(e => ReferenceEquals(e.Owner, this));
        int start = s.Items.Count;
        double w = Width, x0 = X0, yG = GridTop, H = RowH.Sum();
        if (TitleH > 0)
        {
            double h1 = Math.Min(4.6, TitleH);
            FitBox(s, Title, x0, Top - h1, w, h1, 3.0, "TEXTE", false);
            if (!string.IsNullOrWhiteSpace(Subtitle) && TitleH - h1 > 2) FitBox(s, Subtitle, x0, Top - TitleH, w, TitleH - h1, 2.0, "TEXTE", false);
        }
        s.Rect(x0, yG - H, w, H, Layer);
        double y = yG;
        for (int r = 0; r < RowH.Length - 1; r++) { y -= RowH[r]; s.Line(x0, y, x0 + w, y, Layer); }
        double hy = yG - RowH[0];
        s.Line(x0, hy + 0.35, x0 + w, hy + 0.35, Layer);                    // double trait sous l'en-tête
        double cx = x0;
        for (int c = 0; c < ColW.Length; c++)
        {
            if (c > 0) s.Line(cx, yG, cx, yG - H, Layer);
            bool center = c != ShapeCol && IsShort(c);
            if (c < Header.Length) FitBox(s, Header[c], cx, yG - RowH[0], ColW[c], RowH[0], TextH, "TEXTE", true);
            double yy = yG - RowH[0];
            for (int r = 0; r < Rows.Count; r++)
            {
                double rh = RowH[r + 1]; yy -= rh;
                if (c == ShapeCol)
                {
                    if (r < Shapes.Count && Shapes[r] is { } bar) BendShape.Draw(s, bar, cx + 0.5, yy + 0.4, ColW[c] - 1.0, rh - 0.8);
                }
                else if (c < Rows[r].Length) FitBox(s, Rows[r][c], cx, yy, ColW[c], rh, TextH, "TEXTE", center);
            }
            cx += ColW[c];
        }
        for (int i = start; i < s.Items.Count; i++) s.Items[i].Owner = this;
    }

    private bool IsShort(int c)
    {
        if (Rows.Count == 0) return false;
        return Rows.Average(r => c < r.Length ? (r[c] ?? "").Length : 0) <= 9;
    }

    /// <summary>Texte mis en page dans la case (x,y = coin inférieur gauche) : retour à la ligne, taille réduite si besoin, centré verticalement, jamais en dehors.</summary>
    private static void FitBox(Sheet s, string text, double x, double y, double w, double h, double th0, string layer, bool center)
    {
        text = (text ?? "").Trim();
        if (text.Length == 0 || w < 2 || h < 1.5) return;
        double aw = w - 1.4, ah = h - 0.8, th = Math.Min(th0, Math.Max(MinText, ah * 0.8));
        List<string> lines;
        while (true)
        {
            lines = TitleBlock.Wrap(text, aw, th);
            if (lines.Count * th * 1.25 <= ah + 0.01 || th <= MinText) break;
            th = Math.Max(MinText, th - 0.1);
        }
        int maxL = Math.Max(1, (int)Math.Floor(ah / (th * 1.25)));
        if (lines.Count > maxL)
        {
            lines = lines.Take(maxL).ToList();
            string last = lines[^1];
            while (last.Length > 1 && Detailing.TextWidth(last + "...", th) > aw) last = last[..^1];
            lines[^1] = last.TrimEnd() + "...";
        }
        double blockH = lines.Count * th * 1.25;
        double top = y + h - (h - blockH) / 2;
        for (int i = 0; i < lines.Count; i++)
        {
            double tw = Detailing.TextWidth(lines[i], th);
            double tx = center ? x + Math.Max(0.5, (w - tw) / 2) : x + 0.7;
            s.Text(tx, top - th * 1.25 * i - th * 1.0, th, lines[i], layer);
        }
    }

    // ------------------------------------------------------------------ interaction (visionneuse)
    public TableHit? HitTest(double px, double py, double tol)
    {
        double x0 = X0, w = Width, yG = GridTop, H = RowH.Sum(), yb = yG - H;
        if (px < x0 - tol || px > x0 + w + tol || py < yb - tol || py > yG + tol) return null;
        double cx = x0;
        if (Math.Abs(px - x0) <= tol) return new TableHit(TableHitKind.Left, 0);
        for (int c = 0; c < ColW.Length - 1; c++)
        {
            cx += ColW[c];
            if (Math.Abs(px - cx) <= tol && py <= yG + tol) return new TableHit(TableHitKind.Column, c + 1);
        }
        double y = yG;
        for (int r = 0; r < RowH.Length; r++)
        {
            y -= RowH[r];
            if (Math.Abs(py - y) <= tol)
                return r == RowH.Length - 1 ? new TableHit(TableHitKind.Bottom, 0) : new TableHit(TableHitKind.Row, r + 1);
        }
        return null;
    }

    public void BeginDrag() { _snapCol = (double[])ColW.Clone(); _snapRow = (double[])RowH.Clone(); }

    /// <summary>dx, dy : déplacement du curseur en mm de papier depuis le début du glissement (dy &gt; 0 vers le haut).</summary>
    public void Drag(TableHit hit, double dx, double dy)
    {
        switch (hit.Kind)
        {
            case TableHitKind.Column:
            {
                int i = hit.Index;
                double d = Math.Clamp(dx, Math.Min(0, -(_snapCol[i - 1] - MinCol)), Math.Max(0, _snapCol[i] - MinCol));
                ColW = (double[])_snapCol.Clone(); ColW[i - 1] = _snapCol[i - 1] + d; ColW[i] = _snapCol[i] - d;
                break;
            }
            case TableHitKind.Left:
            {
                double w0 = _snapCol.Sum(), nw = Math.Clamp(w0 - dx, MinCol * _snapCol.Length, 396), f = nw / w0;
                ColW = _snapCol.Select(c => c * f).ToArray();
                break;
            }
            case TableHitKind.Row:
            {
                int i = hit.Index;
                RowH = (double[])_snapRow.Clone(); RowH[i - 1] = Math.Max(MinRow, _snapRow[i - 1] - dy);
                break;
            }
            case TableHitKind.Bottom:
            {
                double h0 = _snapRow.Sum(), nh = Math.Clamp(h0 - dy, MinRow * _snapRow.Length, 230), f = nh / h0;
                RowH = _snapRow.Select(r => Math.Max(MinRow, r * f)).ToArray();
                break;
            }
        }
    }
}
