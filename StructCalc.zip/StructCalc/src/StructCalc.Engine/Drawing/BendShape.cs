using StructCalc.Core;

namespace StructCalc.Engine.Drawing;

/// <summary>Schémas de façonnage des aciers (formes de pliage cotées) pour les nomenclatures. Dessin schématique non à l'échelle ;
/// les cotes écrites sont les vraies valeurs, dans l'unité de section du projet.</summary>
public static class BendShape
{
    public enum Kind { Straight, HookOne, HookBoth, Pin, Stirrup }

    public static Kind KindOf(BarLine b)
    {
        string sh = b.Shape.ToLowerInvariant();
        if (sh.Contains("cadre")) return Kind.Stirrup;
        if (sh.Contains("épingle") || sh.Contains("epingle")) return Kind.Pin;
        if (sh.Contains("2 crochets")) return Kind.HookBoth;
        if (sh.Contains("crochet") || sh.Contains("retour")) return Kind.HookOne;
        return Kind.Straight;
    }

    public static string Name(BarLine b) => KindOf(b) switch
    {
        Kind.Stirrup => "cadre fermé",
        Kind.Pin => "épingle",
        Kind.HookBoth => "barre droite, 2 retours 90°",
        Kind.HookOne => "barre droite, 1 retour 90°",
        _ => "barre droite",
    };

    private static double Hook(BarLine b) => 12.0 * b.Dia / 1000.0;

    /// <summary>Dessine la forme dans la case (x,y) = coin inférieur gauche, w x h en mm de papier.</summary>
    public static void Draw(Sheet s, BarLine b, double x, double y, double w, double h)
    {
        var kind = KindOf(b);
        double th = Math.Clamp(h * 0.19, 1.1, 2.0);
        const string L = "ARMATURES";
        string Fmt(double m) => Units.SecS(m);
        void Lab(double cx, double cy, string t, bool center = true)
        {
            double tw = Detailing.TextWidth(t, th);
            s.Text(center ? cx - tw / 2 : cx, cy, th, t, "COTES");
        }
        double pad = Math.Max(1.2, h * 0.12);
        switch (kind)
        {
            case Kind.Straight:
            {
                double yy = y + h * 0.45;
                s.Line(x + pad, yy, x + w - pad, yy, L);
                Lab(x + w / 2, yy + th * 0.5, Fmt(b.LengthM));
                break;
            }
            case Kind.HookOne:
            {
                double hk = Hook(b), top = y + h * 0.66, bot = y + h * 0.16;
                double x0 = x + pad, x1 = x + w - pad - th * 3;
                s.Line(x0, top, x1, top, L);
                s.Line(x1, top, x1, bot, L);
                Lab(x0 + (x1 - x0) / 2, top + th * 0.4, Fmt(Math.Max(b.LengthM - hk, 0.05)));
                Lab(x1 + 0.8, (top + bot) / 2 - th * 0.3, Fmt(hk), false);
                break;
            }
            case Kind.HookBoth:
            {
                double hk = Hook(b), top = y + h * 0.66, bot = y + h * 0.16;
                double lab = th * 3;
                double x0 = x + pad + lab, x1 = x + w - pad - lab;
                s.Line(x0, top, x1, top, L);
                s.Line(x0, top, x0, bot, L);
                s.Line(x1, top, x1, bot, L);
                Lab(x + w / 2, top + th * 0.4, Fmt(Math.Max(b.LengthM - 2 * hk, 0.05)));
                Lab(x0 - Detailing.TextWidth(Fmt(hk), th) - 0.8, (top + bot) / 2 - th * 0.3, Fmt(hk), false);
                Lab(x1 + 0.8, (top + bot) / 2 - th * 0.3, Fmt(hk), false);
                break;
            }
            case Kind.Pin:
            {
                double hk = 0.075;
                double yy = y + h * 0.58, x0 = x + pad + 1.5, x1 = x + w - pad - 1.5, d = Math.Min(h * 0.26, 3.2);
                s.Line(x0, yy, x1, yy, L);
                s.Line(x0, yy, x0 + d, yy - d, L);
                s.Line(x1, yy, x1 - d, yy - d, L);
                Lab(x + w / 2, yy + th * 0.4, Fmt(Math.Max(b.DimA, b.LengthM - 2 * hk)));
                if (h > 6) Lab(x + w / 2, y + th * 0.3, "2 crochets 135°");
                break;
            }
            default: // cadre : le rectangle occupe toute la hauteur de la case, les cotes sont écrites à droite
            {
                double A = b.DimA > 0 ? b.DimA : 0.2, B = b.DimB > 0 ? b.DimB : 0.4;
                double ratio = Math.Clamp(A / B, 0.45, 2.2);
                string la = "a=" + Fmt(A), lb = "b=" + Fmt(B);
                double labW = Math.Min(w * 0.45, Math.Max(Detailing.TextWidth(la, th), Detailing.TextWidth(lb, th)) + 1.5);
                double availH = Math.Max(2, h - 2 * pad * 0.8), availW = Math.Max(2, w - labW - 2 * pad);
                double rh = Math.Min(availH, availW / ratio), rw = rh * ratio;
                double x0 = x + pad + (availW - rw) / 2, y0 = y + (h - rh) / 2;
                s.Line(x0, y0, x0 + rw, y0, L); s.Line(x0 + rw, y0, x0 + rw, y0 + rh, L);
                s.Line(x0 + rw, y0 + rh, x0, y0 + rh, L); s.Line(x0, y0 + rh, x0, y0, L);
                double d = Math.Min(rw, rh) * 0.28;
                s.Line(x0, y0 + rh, x0 + d, y0 + rh - d, L);       // retours à 135°
                s.Line(x0 + d * 0.45, y0 + rh, x0 + d * 1.1, y0 + rh - d * 0.65, L);
                double lx = x0 + rw + 1.6;
                s.Text(lx, y + h / 2 + th * 0.2, th, la, "COTES");
                s.Text(lx, y + h / 2 - th * 1.25, th, lb, "COTES");
                break;
            }
        }
    }
}
