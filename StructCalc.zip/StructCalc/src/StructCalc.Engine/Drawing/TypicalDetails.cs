using System.Globalization;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Drawing;

/// <summary>Planche de détails types : longueurs d'ancrage et de recouvrement par diamètre (selon fc28 et fe du projet), crochets, cadres.
/// Valeurs de principe (BAEL 91 / EC2 à adapter) : le bureau d'études garde la responsabilité des dispositions.</summary>
public static class TypicalDetails
{
    private static string N0(double v) => v.ToString("0", CultureInfo.InvariantCulture);
    private static string N1(double v) => v.ToString("0.0", CultureInfo.InvariantCulture);

    public static IEnumerable<Sheet> Build(StructModel m)
    {
        double fc = m.Fc28, fe = m.Fe;
        double ft = 0.6 + 0.06 * fc;
        double tau = 0.6 * 1.5 * 1.5 * ft;                  // τsu = 0,6 ψs² ft28 (HA, ψs = 1,5)
        var s = new Sheet { Name = "Details", Title = "DETAILS TYPES DE FERRAILLAGE (ancrages, recouvrements, crochets)", ScaleText = "Sans échelle" };

        s.Text(20, s.Height - 22, 5, $"Béton fc28 = {N0(fc)} MPa   -   acier HA fe = {N0(fe)} MPa   -   τsu = {N1(tau)} MPa   -   ft28 = {N1(ft)} MPa", "TEXTE");

        // ---- tableau des longueurs
        var rows = new List<string[]>();
        foreach (int d in new[] { 6, 8, 10, 12, 14, 16, 20, 25, 32 })
        {
            double ls = d * fe / (4 * tau);                 // mm
            double lr = ls;                                  // recouvrement = ls (barres non tendues en paquet exclues)
            double hookTail = 0.4 * ls;                      // ancrage courbe : projection = 0,4 ls
            double mandrel = 5.5 * d;
            double ret = Math.Max(10 * d, 50);
            rows.Add(new[] { "HA" + d, N0(Math.Ceiling(ls / 10) * 10), N0(Math.Ceiling(lr / 10) * 10), N0(Math.Ceiling(hookTail / 10) * 10), N0(mandrel), N0(ret) });
        }
        double top = s.Height - 40;
        s.Text(20, top, 4, "LONGUEURS (mm)", "TEXTE");
        s.Table(20, top - 4, new[] { 22.0, 38, 38, 44, 36, 36 }, 7.2,
            new[] { "Barre", "Ancrage droit ls", "Recouvrt lr", "Ancrage courbe 0,4 ls", "Mandrin 5,5 d", "Retour cadre 10 d" }, rows, 2.5);
        s.Text(20, top - 4 - 7.2 * (rows.Count + 1) - 8, 2.6, "ls = d.fe / (4 τsu), arrondi aux 10 mm supérieurs. Valeurs pour barres HA en zone courante ; majorer de 30 % en zone tendue de mauvaise adhérence.", "TEXTE");

        // ---- croquis 1 : ancrage droit et recouvrement (à droite du tableau)
        double ox = 250, oy = s.Height - 70;
        s.Text(ox, oy + 14, 4, "ANCRAGE DROIT ET RECOUVREMENT", "TEXTE");
        s.Rect(ox, oy - 34, 80, 30, "BETON");
        s.Line(ox + 10, oy - 20, ox + 90, oy - 20, "ARMATURES");
        s.Dim(ox + 10, ox + 80, oy - 14, "ls", 2.5);
        s.Text(ox + 2, oy - 40, 2.6, "Ancrage droit dans le béton", "TEXTE");

        // recouvrement : sous l'ancrage (la planche ne doit rien sortir du cadre)
        double rx = 300, ry = oy - 62;
        s.Line(rx, ry, rx + 60, ry, "ARMATURES");
        s.Line(rx + 30, ry - 6, rx + 90, ry - 6, "ARMATURES");
        s.Dim(rx + 30, rx + 60, ry + 6, "lr", 2.5);
        s.Text(rx + 2, ry - 16, 2.6, "Recouvrement de deux barres : lr", "TEXTE");

        // ---- croquis 2 : crochets
        double hx = 20, hy = 112;
        s.Text(hx, hy + 52, 4, "CROCHETS ET ANCRAGES COURBES", "TEXTE");
        // crochet à 90° avec mandrin
        double r = 6;
        s.Line(hx + 6, hy + 38, hx + 56, hy + 38, "ARMATURES");
        s.Arc(hx + 56, hy + 38 - r, r, 90, 0, "ARMATURES", 6);
        s.Line(hx + 56 + r, hy + 38 - r, hx + 56 + r, hy + 14, "ARMATURES");
        s.Text(hx + 4, hy + 4, 2.6, "Crochet à 90° : retour >= 10 d", "TEXTE");
        // crochet à 135°
        double cx = hx + 100, cy = hy + 38 - r;
        s.Line(cx, cy + r, cx + 50, cy + r, "ARMATURES");
        s.Arc(cx + 50, cy, r, 90, -45, "ARMATURES", 8);
        double ex = cx + 50 + r * Math.Cos(-45 * Math.PI / 180), ey = cy + r * Math.Sin(-45 * Math.PI / 180);
        s.Line(ex, ey, ex - 18 * Math.Cos(45 * Math.PI / 180), ey - 18 * Math.Sin(45 * Math.PI / 180), "ARMATURES");
        s.Text(cx - 2, hy + 4, 2.6, "Crochet à 135° (cadres) : retour >= 10 d, >= 5 cm", "TEXTE");
        // crochet à 180°
        double kx = hx + 210, ky = hy + 38;
        s.Line(kx, ky, kx + 44, ky, "ARMATURES");
        s.Arc(kx + 44, ky - r, r, 90, -90, "ARMATURES", 10);
        s.Line(kx + 44, ky - 2 * r, kx + 20, ky - 2 * r, "ARMATURES");
        s.Text(kx - 4, hy + 4, 2.6, "Crochet normal (180°) : retour >= 4 d", "TEXTE");

        // ---- croquis 3 : cadre et épingle
        double qx = 20, qy = 38;
        s.Text(qx, qy + 60, 4, "CADRE, EPINGLE, ENROBAGE", "TEXTE");
        s.Rect(qx, qy, 40, 52, "BETON");
        s.Stirrup(qx + 4, qy + 4, 32, 44, 3, 6, "CADRES");
        s.Dot(qx + 7, qy + 7, 1.8); s.Dot(qx + 33, qy + 7, 1.8); s.Dot(qx + 7, qy + 45, 1.8); s.Dot(qx + 33, qy + 45, 1.8); s.Dot(qx + 20, qy + 7, 1.8);
        s.DimH(qx, qx + 4, qy - 5, "c", 2.2);
        s.Text(qx + 48, qy + 40, 2.6, "c = enrobage nominal (voir Options du projet)", "TEXTE");
        s.Text(qx + 48, qy + 34, 2.6, "Espacement des cadres : zone critique réduite (séisme)", "TEXTE");
        s.Text(qx + 48, qy + 28, 2.6, "Crochets des cadres à 135° alternés d'un cadre à l'autre", "TEXTE");
        s.Text(qx + 48, qy + 22, 2.6, "Mandrin de cintrage : 5,5 d (HA) ; 3 d pour d <= 12 (cadres)", "TEXTE");

        // ---- notes
        var notes = new[]
        {
            "NOTES",
            "1. Ancrage dans un noeud poteau-poutre : barres basses prolongées au-delà de l'axe du poteau, avec coude à 90° (>= 15 d).",
            "2. Recouvrements décalés : pas plus de 50 % des barres recouvertes dans la même section.",
            "3. Les jonctions de poteaux se font au-dessus du plancher, en dehors des zones critiques en région sismique.",
            "4. Les valeurs sont celles du projet (fc28, fe) ; vérifier avec la norme appliquée avant exécution.",
        };
        double ny = 128;
        for (int i = 0; i < notes.Length; i++)
            foreach (var ln in TitleBlock.Wrap(notes[i], 105, i == 0 ? 3.4 : 2.6))
            {
                s.Text(300, ny, i == 0 ? 3.4 : 2.6, ln, "TEXTE");
                ny -= i == 0 ? 6 : 4.4;
            }
        return new[] { s };
    }
}
