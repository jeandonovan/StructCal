using System.Text.Json;

namespace StructCalc.Engine.Drawing;

/// <summary>Échange des planches d'exécution avec le complément Revit (fichier JSON dans le dossier d'échange).
/// Coordonnées en millimètres de papier, comme dans <see cref="Sheet"/>.</summary>
public static class SheetExchange
{
    public sealed class EntDto
    {
        public string K { get; set; } = "";      // L = ligne, C = cercle, T = texte
        public string L { get; set; } = "";      // calque
        public double X1 { get; set; }
        public double Y1 { get; set; }
        public double X2 { get; set; }
        public double Y2 { get; set; }
        public double R { get; set; }
        public double H { get; set; }
        public double Rot { get; set; }
        public bool Fill { get; set; }
        public string T { get; set; } = "";
    }

    public sealed class SheetDto
    {
        public string Name { get; set; } = "";
        public string Title { get; set; } = "";
        public string Number { get; set; } = "";
        public string ScaleText { get; set; } = "";
        public double Width { get; set; }
        public double Height { get; set; }
        public List<EntDto> Items { get; set; } = new();
    }

    private static readonly JsonSerializerOptions Opt = new() { WriteIndented = false };

    public static void Save(IEnumerable<Sheet> sheets, string path)
    {
        var list = sheets.Select(s => new SheetDto
        {
            Name = s.Name, Title = s.Title, Number = s.Number, ScaleText = s.ScaleText, Width = s.Width, Height = s.Height,
            Items = s.Items.Select(e => new EntDto
            {
                K = e.Kind == EntKind.Line ? "L" : e.Kind == EntKind.Circle ? "C" : "T",
                L = e.Layer, X1 = e.X1, Y1 = e.Y1, X2 = e.X2, Y2 = e.Y2, R = e.R, H = e.H, Rot = e.Rot, Fill = e.Fill, T = e.Text
            }).ToList()
        }).ToList();
        File.WriteAllText(path, JsonSerializer.Serialize(list, Opt));
    }

    public static List<SheetDto> Load(string path) =>
        JsonSerializer.Deserialize<List<SheetDto>>(File.ReadAllText(path), Opt) ?? new();
}
