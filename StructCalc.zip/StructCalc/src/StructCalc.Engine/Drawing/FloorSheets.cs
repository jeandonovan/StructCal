using System.Globalization;
using StructCalc.Engine.Floors;

namespace StructCalc.Engine.Drawing;

/// <summary>Planche d'un plancher à corps creux : élévation de la poutrelle continue (chapeaux, armatures inférieures), coupe transversale, tableaux.</summary>
public static class FloorSheets
{
    private static string F(double v, string f = "0.00") => v.ToString(f, CultureInfo.InvariantCulture);

    public static IEnumerable<Sheet> Build(AnalysisOutput o)
    {
        foreach (var r in o.RibbedFloors)
        {
            if (r.Spans.Count == 0) continue;
            var s = new Sheet { Name = "Plancher " + r.Def.Name, Title = $"PLANCHER À CORPS CREUX {r.Def.Name} ({RibbedFloorDesigner.Name(r.Def.HourdisCm, r.Def.ToppingCm)}) - ferraillage des poutrelles", ScaleText = "1:50 / 1:5" };
            Elevation(s, r); Section(s, r); Table(s, r);
            yield return s;
        }
    }

    private static void Elevation(Sheet s, RibbedFloorResult r)
    {
        var d = r.Def; double total = d.Spans.Sum();
        double sc = Math.Min(340 / total, 120);       // mm de dessin par mètre
        double x0 = 30, yb = 185, hTot = Math.Max(6, d.TotalHeightCm / 100 * sc * 2.5);
        s.Text(x0, yb + hTot + 14, 3.5, "ÉLÉVATION D'UNE POUTRELLE CONTINUE (hauteurs exagérées)", "TEXTE");
        double x = x0;
        var xs = new List<double> { x0 };
        foreach (var L in d.Spans) { x += L * sc; xs.Add(x); }
        s.Rect(x0, yb, x - x0, hTot, "CONTOUR");
        s.Line(x0, yb + hTot * 0.2, x, yb + hTot * 0.2, "HACHURES");
        for (int i = 0; i < xs.Count; i++)
        {
            bool edge = i == 0 || i == xs.Count - 1;
            s.Rect(xs[i] - 3, yb - 8, 6, 8, "CONTOUR");                    // appuis
            s.Text(xs[i] - 2, yb - 14, 3, ((char)('A' + i)).ToString(), "TEXTE");
        }
        for (int i = 0; i < d.Spans.Count; i++)
        {
            double xa = xs[i], xb = xs[i + 1], L = d.Spans[i] * sc;
            s.Line(xa + 2, yb + 2, xb - 2, yb + 2, "ARMATURES");                // barres inférieures
            s.Text(xa + L * 0.2, yb - 4.5, 2.6, r.Spans[i].BarsT, "ARMATURES");
            s.DimH(xa, xb, yb + hTot + 6, F(d.Spans[i]) + " m");
        }
        for (int i = 0; i < r.Supports.Count; i++)
        {
            var sp = r.Supports[i];
            if (sp.AsA <= 0) continue;
            bool edge = i == 0 || i == r.Supports.Count - 1;
            double lg = (edge ? 0.2 : 0.25) * (i == 0 ? d.Spans[0] : i == d.Spans.Count ? d.Spans[^1] : Math.Max(d.Spans[i - 1], d.Spans[i])) * sc;
            double xa = i == 0 ? xs[i] : xs[i] - lg; double xb = i == d.Spans.Count ? xs[i] : xs[i] + lg;
            if (i == 0) xb = xs[i] + lg;
            if (i == d.Spans.Count) xa = xs[i] - lg;
            s.Line(xa, yb + hTot - 2, xb, yb + hTot - 2, "ARMATURES");
            s.Text(Math.Max(x0, xa), yb + hTot + 1.5, 2.4, sp.Bars, "ARMATURES");
        }
    }

    private static void Section(Sheet s, RibbedFloorResult r)
    {
        var d = r.Def; double k = 1.2;        // mm par cm
        double x0 = 40, y0 = 120;
        double b = d.SpacingM * 100 * k * 0.6, b0 = d.WebCm * k, h = d.TotalHeightCm * k, h0 = d.ToppingCm * k, hh = d.HourdisCm * k;
        double cx = x0 + b / 2;
        s.Text(x0, y0 + h + 10, 3.5, "COUPE TRANSVERSALE", "TEXTE");
        s.Rect(x0, y0 + hh, b, h0, "CONTOUR");                                 // dalle de compression
        s.Rect(cx - b0 / 2, y0, b0, hh, "CONTOUR");                             // nervure
        s.Rect(x0 - 0.001, y0, (b - b0) / 2, hh, "HACHURES");                   // hourdis
        s.Rect(cx + b0 / 2, y0, (b - b0) / 2, hh, "HACHURES");
        s.Line(x0 + 3, y0 + hh + h0 * 0.5, x0 + b - 3, y0 + hh + h0 * 0.5, "ARMATURES");
        s.Text(x0 + b + 4, y0 + hh + h0 * 0.4, 2.6, r.Mesh, "ARMATURES");
        s.Circle(cx - b0 / 4, y0 + d.CoverCm * k, 1.6, "ARMATURES"); s.Circle(cx + b0 / 4, y0 + d.CoverCm * k, 1.6, "ARMATURES");
        s.DimH(x0, x0 + b, y0 - 8, $"entraxe {F(d.SpacingM)} m");
        s.DimV(x0 - 8, y0, y0 + h, $"{d.TotalHeightCm:0}");
        s.Text(cx - b0 / 2, y0 - 3.5, 2.6, $"b0 = {d.WebCm:0} cm", "TEXTE");
    }

    private static void Table(Sheet s, RibbedFloorResult r)
    {
        var t = new SheetTable
        {
            Title = "TABLEAU DES TRAVÉES", Subtitle = $"Étriers : {r.Stirrups} - espacement {r.StirrupSt:0} cm",
            Header = new[] { "Travée", "L (m)", "Mt,u", "As (cm²)", "Armatures" },
            ColW = new[] { 18.0, 18, 22, 24, 62 }, TextH = 2.6, BodyRowMin = 5.6,
        };
        foreach (var q in r.Spans) { t.Rows.Add(new[] { q.Index.ToString(), F(q.L), F(q.MtU), F(q.AsT), q.BarsT }); t.Shapes.Add(null); }
        t.AutoSize();
        s.AddTable(t);
        string meth = r.Method.Length > 80 ? r.Method.Substring(0, 80) + "..." : r.Method;
        s.Text(t.X0, t.Bottom - 6, 2.6, $"Méthode : {meth}", "TEXTE");
    }
}
