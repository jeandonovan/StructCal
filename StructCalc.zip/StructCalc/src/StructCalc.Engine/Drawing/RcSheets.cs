using System.Globalization;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Drawing;

/// <summary>Ligne de nomenclature d'aciers (un repère).</summary>
public sealed record BarLine(string Cat, string Elem, int Mark, int Count, int Dia, string Shape, double LengthM, string Role, int Qty = 1)
{
    public double TotalM => Count * Qty * LengthM;
    public double MassKg => TotalM * DesignSettings.KgPerM(Dia);
    /// <summary>Cotes de la forme (m) : côtés du cadre ou longueur droite de l'épingle (pour le schéma de façonnage).</summary>
    public double DimA { get; init; }
    public double DimB { get; init; }
}

/// <summary>Planches de ferraillage béton armé : poutres, poteaux, semelles, dalles, récapitulatif. Dessins de principe à contrôler avant exécution.</summary>
public static partial class RcSheets
{
    private static readonly double[] Scales = { 10, 20, 25, 30, 40, 50, 75, 100, 125, 150, 200, 250, 300, 400, 500 };
    private static string N2(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
    private static string N1(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);
    private static double R2(double v) => Math.Round(v, 2);

    /// <summary>Plus petite échelle normalisée (dénominateur) >= need.</summary>
    public static double PickScale(double need)
    {
        foreach (double s in Scales) if (need <= s) return s;
        return Scales[^1];
    }

    private static Sheet New(string name, string title, string scale) => new() { Name = name, Title = title, ScaleText = scale };

    public static List<List<T>> Group<T>(IEnumerable<T> items, bool group, Func<T, string> key, Func<T, int> id)
    {
        var res = new List<List<T>>();
        var map = new Dictionary<string, List<T>>();
        foreach (var it in items)
        {
            string k = group ? key(it) : "id" + id(it);
            if (!map.TryGetValue(k, out var l)) { l = new List<T>(); map[k] = l; res.Add(l); }
            l.Add(it);
        }
        return res;
    }

    private static string Ids(string prefix, IEnumerable<int> ids)
    {
        var l = ids.ToList();
        string s = string.Join(", ", l.Take(5).Select(i => prefix + i));
        return l.Count > 5 ? s + " +" + (l.Count - 5) : s;
    }

    /// <summary>Découpe un texte en lignes de maxChars caractères au plus.</summary>
    public static List<string> Wrap(string text, int maxChars)
    {
        var lines = new List<string>();
        string cur = "";
        foreach (var w in text.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            if (cur.Length > 0 && cur.Length + 1 + w.Length > maxChars) { lines.Add(cur); cur = w; }
            else cur = cur.Length == 0 ? w : cur + " " + w;
        }
        if (cur.Length > 0) lines.Add(cur);
        return lines;
    }

    // ===================================================================== positions des cadres
    public static List<double> StirrupPositions(double L, double e, double zone, double eNodal)
    {
        var pos = new SortedSet<double>();
        e = Math.Max(e, 0.05);
        bool useZone = eNodal > 0 && zone > 0;
        double p = 0.05;
        while (p < L / 2 && pos.Count < 600)
        {
            pos.Add(Math.Round(p, 3)); pos.Add(Math.Round(L - p, 3));
            p += (useZone && p < zone) ? Math.Min(eNodal, e) : e;
        }
        return pos.ToList();
    }

    public static (int T, int Sd) ColumnTies(int nBars, double b, double h)
    {
        int n = Math.Max(4, nBars), rem = Math.Max(0, n - 4);
        int t = (int)Math.Round(rem / 2.0 * b / (b + h));
        int sd = rem / 2 - t;
        if (sd < 0) { sd = 0; t = rem / 2; }
        return (t, sd);
    }

    private static double ClearLength(MemberDesignResult r) => Math.Max(r.Length - 0.30, 0.5);

    // ===================================================================== nomenclature des aciers
    public static List<BarLine> BeamBars(MemberDesignResult r, DesignSettings cfg, string elem, int qty)
    {
        var l = new List<BarLine>();
        double L = r.Length, b = r.B, h = r.H, cov = r.CoverM > 0 ? r.CoverM : 0.05;
        double Hk(int d) => 12.0 * d / 1000.0;
        int m = 1;
        l.Add(new BarLine("Poutres", elem, m++, r.BotN, r.BotDia, "droite + 2 crochets 90°", R2(L - 0.06 + 2 * Hk(r.BotDia)), "Lit inférieur filant", qty));
        if (r.Cantilever)
            l.Add(new BarLine("Poutres", elem, m++, r.TopN, r.TopDia, "droite + 2 crochets 90°", R2(L - 0.06 + 2 * Hk(r.TopDia)), "Chapeaux sur toute la longueur (console)", qty));
        else
            l.Add(new BarLine("Poutres", elem, m++, 2 * r.TopN, r.TopDia, "droite + crochet 90°", R2(cfg.BeamTopBarFactor * L + 0.30 + Hk(r.TopDia)), "Chapeaux sur appuis", qty));
        l.Add(new BarLine("Poutres", elem, m++, 2, cfg.MountingBarDiaMm, "droite + 2 crochets 90°", R2(L - 0.06 + 2 * Hk(cfg.MountingBarDiaMm)), "Barres de montage", qty));
        if (r.StirDia > 0)
        {
            int n = StirrupPositions(ClearLength(r), Math.Max(r.StirSpacingCm, 5) / 100.0, r.NodalZoneM, r.NodalSpacingCm / 100.0).Count;
            double inset = Math.Max(cov - r.BotDia / 2000.0, 0.02);
            double lu = 2 * ((b - 2 * inset) + (h - 2 * inset)) + 2 * cfg.HookFactor * r.StirDia / 1000.0;
            l.Add(new BarLine("Poutres", elem, m++, n, r.StirDia, "cadre fermé, crochets 135°", R2(lu), "Cadres", qty) { DimA = b - 2 * inset, DimB = h - 2 * inset });
        }
        return l;
    }

    public static List<BarLine> ColumnBars(MemberDesignResult r, DesignSettings cfg, string elem, int qty)
    {
        var l = new List<BarLine>();
        double L = r.Length, b = r.B, h = r.H, cov = r.CoverM > 0 ? r.CoverM : 0.04;
        int m = 1;
        l.Add(new BarLine("Poteaux", elem, m++, r.BotN, r.BotDia, "droite (attentes + recouvrement)", R2(L + cfg.LapFactor * r.BotDia / 1000.0), "Armatures longitudinales", qty));
        int nPos = StirrupPositions(L, Math.Max(r.StirSpacingCm, 5) / 100.0, r.NodalZoneM, r.NodalSpacingCm / 100.0).Count;
        double inset = Math.Max(cov - r.BotDia / 2000.0, 0.02), hook = 2 * cfg.HookFactor * r.StirDia / 1000.0;
        if (r.StirDia > 0)
            l.Add(new BarLine("Poteaux", elem, m++, nPos, r.StirDia, "cadre fermé, crochets 135°", R2(2 * ((b - 2 * inset) + (h - 2 * inset)) + hook), "Cadres", qty) { DimA = b - 2 * inset, DimB = h - 2 * inset });
        var (t, sd) = ColumnTies(r.BotN, b, h);
        if (r.StirDia > 0 && t > 0)
            l.Add(new BarLine("Poteaux", elem, m++, t * nPos, r.StirDia, "épingle, 2 crochets 135°", R2((h - 2 * inset) + hook), "Epingles (sens h)", qty) { DimA = h - 2 * inset });
        if (r.StirDia > 0 && sd > 0)
            l.Add(new BarLine("Poteaux", elem, m++, sd * nPos, r.StirDia, "épingle, 2 crochets 135°", R2((b - 2 * inset) + hook), "Epingles (sens b)", qty) { DimA = b - 2 * inset });
        return l;
    }

    /// <summary>Largeur du tableau de nomenclature et limite droite du dessin quand il est présent (le tableau occupe le coin supérieur droit).</summary>
    public const double ScheduleWidth = 132, DrawRightWithTable = 272, DrawRightFree = 405;

    /// <summary>Tableau de nomenclature dans le coin supérieur droit de la planche, avec le schéma de façonnage de chaque repère.
    /// Le contenu est remis en page dans les cases : on peut tirer une ligne ou une colonne dans la visionneuse.</summary>
    public static void ScheduleTable(Sheet s, List<BarLine> lines)
    {
        if (lines.Count == 0) return;
        string lu = Units.Length;
        var t = new SheetTable
        {
            Title = "NOMENCLATURE DES ACIERS",
            Subtitle = "Longueurs développées approchées, hors chutes ; schémas non à l'échelle",
            Header = new[] { "Elément", "Rep", "Nb", "HA", $"L ({lu})", $"Total ({lu})", "kg", "Rôle", $"Schéma de façonnage (cotes en {Units.Section})" },
            ColW = new[] { 18.0, 6, 7, 8, 10, 11, 9, 23, 40 },
            ShapeCol = 8,
        };
        foreach (var b in lines)
        {
            t.Rows.Add(new[]
            {
                b.Elem + (b.Qty > 1 ? " (x" + b.Qty + ")" : ""), b.Mark.ToString(), b.Count.ToString(), "HA" + b.Dia, Units.LenS(b.LengthM),
                Units.LenS(Math.Round(b.TotalM, 1)), N1(Math.Round(b.MassKg, 1)), b.Role, ""
            });
            t.Shapes.Add(b);
        }
        t.AutoSize();
        s.AddTable(t);
    }

    // ===================================================================== FAÇONNAGE (planche des formes)
    /// <summary>Planches « Façonnage des aciers » : une fiche par forme distincte, avec le schéma coté, le nombre de barres et la longueur développée.</summary>
    public static IEnumerable<Sheet> Bending(List<BarLine> all)
    {
        var res = new List<Sheet>();
        if (all.Count == 0) return res;
        var cards = all.GroupBy(b => $"{b.Cat}|{b.Dia}|{BendShape.KindOf(b)}|{b.LengthM:F2}|{b.DimA:F3}|{b.DimB:F3}")
                       .Select(g => (First: g.First(), N: g.Sum(q => q.Count * q.Qty), Marks: string.Join(", ", g.Select(q => q.Elem + "-" + q.Mark).Distinct().Take(4)))).ToList();
        const int cols = 4, rowsPer = 4;
        int per = cols * rowsPer, pages = (int)Math.Ceiling(cards.Count / (double)per);
        double cwid = 94, chei = 47;
        for (int p = 0; p < pages; p++)
        {
            var s = New("Faconnage", "FAÇONNAGE DES ACIERS (formes de pliage)" + (pages > 1 ? $" ({p + 1}/{pages})" : ""), "-");
            s.Text(15, 281, 3.0, $"Cotes en {Units.Section} ; longueur développée en {Units.Length}. Rayons de pliage et crochets selon la norme choisie. Schémas non à l'échelle.", "TEXTE");
            int i = 0;
            foreach (var c in cards.Skip(p * per).Take(per))
            {
                int cx = i % cols, cy = i / cols;
                double x = 15 + cx * (cwid + 2), y = 270 - (cy + 1) * (chei + 3);
                s.Rect(x, y, cwid, chei, "TABLEAU");
                s.TextFit(x + 2, y + chei - 5, 3.0, $"{c.First.Cat} - HA{c.First.Dia} - {BendShape.Name(c.First)}", "TEXTE", cwid - 4);
                BendShape.Draw(s, c.First, x + 3, y + 12, cwid - 6, chei - 20);
                s.TextFit(x + 2, y + 7, 2.4, $"{c.N} barres - L dév. = {Units.LenS(c.First.LengthM)} {Units.Length} - {c.First.Role}", "TEXTE", cwid - 4);
                s.TextFit(x + 2, y + 2.6, 2.1, "Rep. : " + c.Marks, "TEXTE", cwid - 4);
                i++;
            }
            res.Add(s);
        }
        return res;
    }

    // ===================================================================== POUTRES
    public static IEnumerable<Sheet> Beams(StructModel m, AnalysisOutput o, List<BarLine> all)
    {
        var cfg = m.Settings;
        var list = o.Members.Where(r => r.Type == MemberType.Beam && r.Kind == MaterialKind.ReinforcedConcrete && !r.Skipped).ToList();
        var groups = Group(list, cfg.GroupIdenticalElements,
            r => $"{r.B:F3}|{r.H:F3}|{r.Length:F2}|{r.BotN}|{r.BotDia}|{r.TopN}|{r.TopDia}|{r.StirDia}|{r.StirSpacingCm}|{r.NodalSpacingCm}|{r.NodalZoneM:F2}|{r.CoverM:F3}|{r.Cantilever}",
            r => r.MemberId);
        var res = new List<Sheet>();
        for (int pg = 0; pg * 2 < groups.Count; pg++)
        {
            var page = groups.Skip(pg * 2).Take(2).ToList();
            double secW = page.Max(g => SectionWidth(g[0]));
            double zr = cfg.ShowBarSchedule ? DrawRightWithTable : DrawRightFree;
            double lpMax = Math.Max(105, zr - 32 - secW);
            double sc = Math.Max(PickScale(page.Max(g => g[0].Length) * 1000 / lpMax), 25);
            var s = New("Poutres", "FERRAILLAGE DES POUTRES", $"1:{sc:0} (coupes 1:10 ou 1:20)");
            var sheetBars = new List<BarLine>();
            double yTop = 283;
            foreach (var g in page)
            {
                BeamBlock(s, g, m, yTop, sc, sheetBars, zr);
                yTop -= 106;
            }
            if (cfg.ShowBarSchedule) ScheduleTable(s, sheetBars);
            all.AddRange(sheetBars);
            res.Add(s);
        }
        return res;
    }

    private static double SecScaleFor(double hM, double bM) => Math.Max(hM, bM) * 100 > 55 ? 20 : 10;
    private static double SectionWidth(MemberDesignResult r)
    {
        double k = 1000 / SecScaleFor(r.H, r.B);
        return 2 * r.B * k + 38 + 16;
    }

    private static void BeamBlock(Sheet s, List<MemberDesignResult> g, StructModel m, double yTop, double sc, List<BarLine> sheetBars, double zr)
    {
        var r = g[0]; var cfg = m.Settings;
        double k = 1000 / sc, L = r.Length, Lc = ClearLength(r), b = r.B, h = r.H, cov = r.CoverM > 0 ? r.CoverM : 0.05;
        double x0 = 20, Lp = L * k, hp = h * k, cw = 0.30 * k;
        double yb = yTop - 27 - hp;
        string title = $"POUTRE {Ids("B", g.Select(q => q.MemberId))}   {Units.SecS(b)}x{Units.SecS(h)} {Units.Section}   L = {Units.LenS(L)} {Units.Length} (entre axes)" + (g.Count > 1 ? $"   -   {g.Count} poutres identiques" : "");
        s.TextFit(x0, yTop - 5, 3.8, title, "TEXTE", zr - x0 - 2);

        double xf0 = x0 + cw / 2, xf1 = x0 + Lp - cw / 2;      // faces des poteaux
        s.Rect(xf0, yb, xf1 - xf0, hp, "BETON");
        foreach (double xa in new[] { x0, x0 + Lp })
        {
            s.DashLine(xa - cw / 2, yb - 9, xa - cw / 2, yb + hp + 9, "CONTOUR", 3, 1.5);
            s.DashLine(xa + cw / 2, yb - 9, xa + cw / 2, yb + hp + 9, "CONTOUR", 3, 1.5);
            s.Axis(xa, yb - 12, xa, yb + hp + 12);
        }

        // ---- armatures longitudinales
        double yBot = yb + cov * k, yTopBar = yb + hp - cov * k, yCh = yTopBar - 1.6;
        double xs0 = x0 - cw / 2 + 0.03 * k, xs1 = x0 + Lp + cw / 2 - 0.03 * k;
        double Hook(int d) => Math.Max(1.5, Math.Min(12.0 * d / 1000.0 * k, hp - 2 * cov * k));
        double hb = Hook(r.BotDia), ht = Hook(r.TopDia), hm = Hook(cfg.MountingBarDiaMm);
        s.Line(xs0, yBot, xs1, yBot, "ARMATURES");
        s.Line(xs0, yBot, xs0, yBot + hb, "ARMATURES"); s.Line(xs1, yBot, xs1, yBot + hb, "ARMATURES");
        double chap = r.Cantilever ? (xf1 - xf0) / 2 : cfg.BeamTopBarFactor * L * k;
        if (r.Cantilever)
        {
            // poutre console : chapeaux sur toute la longueur (pas de coupure), crochets aux deux bouts
            s.Line(xs0 + 0.8, yCh, xs1 - 0.8, yCh, "ARMATURES_HAUTES");
            s.Line(xs0 + 0.8, yCh, xs0 + 0.8, yCh - ht, "ARMATURES_HAUTES");
            s.Line(xs1 - 0.8, yCh, xs1 - 0.8, yCh - ht, "ARMATURES_HAUTES");
        }
        else
        {
            s.Line(xs0 + 0.8, yCh, xf0 + chap, yCh, "ARMATURES_HAUTES");
            s.Line(xs0 + 0.8, yCh, xs0 + 0.8, yCh - ht, "ARMATURES_HAUTES");
            s.Line(xf1 - chap, yCh, xs1 - 0.8, yCh, "ARMATURES_HAUTES");
            s.Line(xs1 - 0.8, yCh, xs1 - 0.8, yCh - ht, "ARMATURES_HAUTES");
        }
        s.Line(xs0 + 1.6, yTopBar, xs1 - 1.6, yTopBar, "ARMATURES2");
        s.Line(xs0 + 1.6, yTopBar, xs0 + 1.6, yTopBar - hm, "ARMATURES2"); s.Line(xs1 - 1.6, yTopBar, xs1 - 1.6, yTopBar - hm, "ARMATURES2");

        // ---- cadres
        double e = Math.Max(r.StirSpacingCm, 5) / 100.0, en = r.NodalSpacingCm / 100.0, zn = r.NodalZoneM;
        var pos = StirrupPositions(Lc, e, zn, en);
        double yS0 = yb + cov * k * 0.55, yS1 = yb + hp - cov * k * 0.55;
        foreach (double p in pos) s.Line(xf0 + p * k, yS0, xf0 + p * k, yS1, "CADRES");

        // ---- cotes de répartition des cadres et portée
        double yd = yb - 15;
        if (en > 0 && zn > 0 && 2 * zn < Lc)
        {
            s.Dim(xf0, xf0 + zn * k, yd, $"e={Units.SpS(r.NodalSpacingCm)}");
            s.Dim(xf0 + zn * k, xf1 - zn * k, yd, $"e={Units.SpS(r.StirSpacingCm)} (zone courante)");
            s.Dim(xf1 - zn * k, xf1, yd, $"e={Units.SpS(r.NodalSpacingCm)}");
        }
        else s.Dim(xf0, xf1, yd, $"e={Units.SpS(r.StirSpacingCm)} {Units.Section}");
        s.Dim(x0, x0 + Lp, yb - 23, $"L = {Units.LenS(L)} {Units.Length} (entre axes des poteaux)");

        // ---- repères de coupe et bulles de repères
        double xA = (xf0 + xf1) / 2;
        double xB = xf0 + (en > 0 && zn > 0 ? 0.4 * zn * k : 0.1 * (xf1 - xf0));
        if (cfg.ShowCutMarks)
        {
            s.CutMark(xA, yb - 6, xA, yb + hp + 6, "A", 1, 0);
            s.CutMark(xB, yb - 6, xB, yb + hp + 6, "B", 1, 0);
        }
        double yBub = yb + hp + 17;
        if (cfg.ShowBarMarks)
        {
            double xm1 = xf0 + 0.25 * (xf1 - xf0);
            s.Line(xm1, yBot, xm1, yb - 4.6, "REPERES"); s.Bubble(xm1, yb - 6.5, 1.9, "1");
            double xm2 = xf0 + 0.55 * chap;
            s.Line(xm2, yCh, xm2, yBub - 1.9, "REPERES"); s.Bubble(xm2, yBub, 1.9, "2");
            double xm3 = xf0 + 0.40 * (xf1 - xf0);
            s.Line(xm3, yTopBar, xm3, yBub - 1.9, "REPERES"); s.Bubble(xm3, yBub, 1.9, "3");
            double target = xf0 + 0.72 * (xf1 - xf0);
            double xm4 = pos.Select(pp => xf0 + pp * k).OrderBy(xx => Math.Abs(xx - target)).FirstOrDefault(target);
            s.Line(xm4, yS1, xm4, yBub - 1.9, "REPERES"); s.Bubble(xm4, yBub, 1.9, "4");
        }

        // ---- nomenclature + légende
        var bars = BeamBars(r, cfg, Ids("B", g.Select(q => q.MemberId)), g.Count);
        sheetBars.AddRange(bars);
        double ly = yb - 32, maxW = Math.Max(90, zr - SectionWidth(r) - x0 - 14);
        string[] leg =
        {
            $"{r.BotN} HA{r.BotDia} : lit inférieur filant, L = {Units.LenS(bars[0].LengthM)} {Units.Length}, As = {Units.AsS(r.AsBottom)} {Units.AsU}",
            r.Cantilever
                ? $"{r.TopN} HA{r.TopDia} : chapeaux sur toute la longueur (console), L = {Units.LenS(bars[1].LengthM)} {Units.Length}, As = {Units.AsS(r.AsTop)} {Units.AsU}"
                : $"{2 * r.TopN} HA{r.TopDia} : chapeaux sur appuis ({r.TopN} par appui), L = {Units.LenS(bars[1].LengthM)} {Units.Length}, As = {Units.AsS(r.AsTop)} {Units.AsU}",
            $"2 HA{cfg.MountingBarDiaMm} : barres de montage, L = {Units.LenS(bars[2].LengthM)} {Units.Length}",
            r.StirDia > 0 ? $"Cadres HA{r.StirDia} (crochets 135°) : {bars[3].Count} cadres" + (en > 0 ? $", e = {Units.SpS(r.NodalSpacingCm)} {Units.Section} sur {Units.LenS(zn)} {Units.Length} à chaque appui, e = {Units.SpS(r.StirSpacingCm)} {Units.Section} ailleurs" : $", e = {Units.SpS(r.StirSpacingCm)} {Units.Section}") : "Pas de cadres"
        };
        for (int i = 0; i < leg.Length; i++)
        {
            double y = ly - i * 4.8;
            if (cfg.ShowBarMarks) s.Bubble(x0 + 2.2, y + 0.9, 1.9, (i + 1).ToString());
            s.TextFit(x0 + 6, y, 2.6, leg[i], "TEXTE", maxW * 0.86);       // marge : la largeur réelle des polices dépasse l'estimation
        }

        // ---- coupes
        double secK = 1000 / SecScaleFor(h, b);
        double ysec = yTop - 27 - h * secK;
        double secWidthOne = b * secK;
        double xsA = zr - SectionWidth(r);
        double xsB = xsA + secWidthOne + 38;
        string scTxt = SecScaleFor(h, b) == 10 ? "1:10" : "1:20";
        BeamSection(s, xsA, ysec, r, cov, secK, 0, "A", $"COUPE A-A : travée (ech. {scTxt})", cfg);
        BeamSection(s, xsB, ysec, r, cov, secK, r.TopN, "B", r.Cantilever ? $"COUPE B-B : encastrement (ech. {scTxt})" : $"COUPE B-B : appui (ech. {scTxt})", cfg);
    }

    /// <summary>Coupe transversale d'une poutre. nCh = nombre de chapeaux (repère 2) en plus des 2 barres de montage (repère 3).</summary>
    private static void BeamSection(Sheet s, double xs, double ys, MemberDesignResult r, double cov, double kk, int nCh, string letter, string caption, DesignSettings cfg)
    {
        double b = r.B, h = r.H, bw = b * kk, hh = h * kk;
        s.Rect(xs, ys, bw, hh, "BETON");
        double inset = Math.Max(cov - r.BotDia / 2000.0, 0.015) * kk;
        double phiT = Math.Max(r.StirDia, 6) / 1000.0 * kk;
        s.Stirrup(xs + inset, ys + inset, bw - 2 * inset, hh - 2 * inset, Math.Max(0.8, 2.5 * phiT), Math.Max(3.0, cfg.HookFactor * phiT), "CADRES");
        double xl = xs + cov * kk, xr = xs + (b - cov) * kk, yl = ys + cov * kk, yu = ys + (h - cov) * kk;
        double rb = Math.Max(r.BotDia / 2000.0 * kk, 0.9), rt = Math.Max(r.TopDia / 2000.0 * kk, 0.9), rm = Math.Max(cfg.MountingBarDiaMm / 2000.0 * kk, 0.9);
        var xb = new List<double>();
        for (int i = 0; i < r.BotN; i++) xb.Add(r.BotN == 1 ? (xl + xr) / 2 : xl + i * (xr - xl) / (r.BotN - 1));
        foreach (double x in xb) s.Dot(x, yl, rb, "ARMATURES");
        s.Dot(xl, yu, rm, "ARMATURES2"); s.Dot(xr, yu, rm, "ARMATURES2");
        var xc = new List<double>();
        for (int i = 1; i <= nCh; i++) xc.Add(xl + (xr - xl) * i / (nCh + 1));
        foreach (double x in xc) s.Dot(x, yu, rt, "ARMATURES_HAUTES");

        if (cfg.ShowBarMarks)
        {
            double xm = xb.Count > 1 ? xb[1] : xb[0];
            s.Line(xm, yl - rb, xm, ys - 4.1, "REPERES"); s.Bubble(xm, ys - 6, 1.9, "1");
            s.Line(xl, yu + rm, xl, ys + hh + 4.6, "REPERES"); s.Bubble(xl, ys + hh + 6.5, 1.9, "3");
            if (xc.Count > 0)
            {
                double x2 = xc[xc.Count / 2];
                s.Line(x2, yu + rt, x2, ys + hh + 4.6, "REPERES"); s.Bubble(x2, ys + hh + 6.5, 1.9, "2");
            }
            s.Line(xs + bw - inset, ys + hh * 0.45, xs + bw + 5.1, ys + hh * 0.45, "REPERES"); s.Bubble(xs + bw + 7, ys + hh * 0.45, 1.9, "4");
        }
        s.Dim(xs, xs + bw, ys - 13, Units.SecS(b));
        s.DimVert(xs + bw + 14, ys, ys + hh, Units.SecS(h));
        // légende sur deux lignes (« COUPE A-A » puis « travée (ech. 1:10) ») : deux coupes voisines ne se chevauchent plus
        int cut = caption.IndexOf(" : ", StringComparison.Ordinal);
        if (cut > 0)
        {
            s.Text(xs, ys - 19, 2.8, caption[..cut], "TEXTE");
            s.TextFit(xs, ys - 23.2, 2.4, caption[(cut + 3)..], "TEXTE", Math.Max(bw + 30, 36));
        }
        else
        {
            s.Text(xs, ys - 19, 2.8, caption.Length > 34 ? caption[..34] : caption, "TEXTE");
            if (caption.Length > 34) s.Text(xs, ys - 23, 2.4, caption[34..], "TEXTE");
        }
    }

    // ===================================================================== POTEAUX
    public static IEnumerable<Sheet> Columns(StructModel m, AnalysisOutput o, List<BarLine> all)
    {
        var cfg = m.Settings;
        var list = o.Members.Where(r => r.Type == MemberType.Column && r.Kind == MaterialKind.ReinforcedConcrete && !r.Skipped).ToList();
        var groups = Group(list, cfg.GroupIdenticalElements,
            r => $"{r.B:F3}|{r.H:F3}|{r.Length:F2}|{r.BotN}|{r.BotDia}|{r.StirDia}|{r.StirSpacingCm}|{r.NodalSpacingCm}|{r.NodalZoneM:F2}|{r.CoverM:F3}",
            r => r.MemberId);
        var res = new List<Sheet>();
        int perCol = cfg.ShowBarSchedule ? 2 : 3;
        for (int pg = 0; pg * perCol < groups.Count; pg++)
        {
            var page = groups.Skip(pg * perCol).Take(perCol).ToList();
            double lmax = page.Max(g => g[0].Length);
            double sc = PickScale(lmax * 1000 / 150);
            var s = New("Poteaux", "FERRAILLAGE DES POTEAUX", $"1:{sc:0} (coupes 1:10 ou 1:20)");
            var sheetBars = new List<BarLine>();
            for (int i = 0; i < page.Count; i++) ColumnBlock(s, page[i], m, 14 + i * 129, sc, sheetBars);
            if (cfg.ShowBarSchedule) ScheduleTable(s, sheetBars);
            all.AddRange(sheetBars);
            res.Add(s);
        }
        return res;
    }

    private static void ColumnBlock(Sheet s, List<MemberDesignResult> g, StructModel m, double x0, double sc, List<BarLine> sheetBars)
    {
        var r = g[0]; var cfg = m.Settings;
        double k = 1000 / sc, L = r.Length, b = r.B, h = r.H, cov = r.CoverM > 0 ? r.CoverM : 0.04;
        double xe = x0 + 26, yb = 84, top = yb + L * k, bw = b * k;
        s.TextFit(x0, 283, 3.4, $"POTEAU {Ids("P", g.Select(q => q.MemberId))}   {Units.SecS(b)}x{Units.SecS(h)} {Units.Section}", "TEXTE", 124);
        s.TextFit(x0, 278.4, 2.6, $"L = {Units.LenS(L)} {Units.Length}" + (g.Count > 1 ? $"   -   {g.Count} poteaux identiques" : ""), "TEXTE", 124);

        s.Rect(xe, yb, bw, L * k, "BETON");
        s.Line(xe - 6, yb, xe + bw + 6, yb, "CONTOUR"); s.Line(xe - 6, top, xe + bw + 6, top, "CONTOUR");
        s.Hatch(xe - 6, yb - 3, bw + 12, 3, 1.6);

        // armatures verticales et attentes
        double lap = cfg.LapFactor * r.BotDia / 1000.0;
        double xl = xe + cov * k, xr = xe + (b - cov) * k;
        s.Line(xl, yb + 1.0, xl, top, "ARMATURES"); s.Line(xr, yb + 1.0, xr, top, "ARMATURES");
        s.Line(xl + 1.4, top, xl + 1.4, top + lap * k, "ARMATURES2"); s.Line(xr - 1.4, top, xr - 1.4, top + lap * k, "ARMATURES2");
        s.DimVert(xe + bw + 11, top, top + lap * k, $"Lr={Units.LenS(lap)}");

        // cadres
        double e = Math.Max(r.StirSpacingCm, 5) / 100.0, en = r.NodalSpacingCm / 100.0, zn = r.NodalZoneM;
        var pos = StirrupPositions(L, e, zn, en);
        foreach (double p in pos) s.Line(xl - 0.4, yb + p * k, xr + 0.4, yb + p * k, "CADRES");

        // cotes à gauche : zones et hauteur totale
        double xd = xe - 14;
        if (en > 0 && zn > 0 && 2 * zn < L)
        {
            s.DimVert(xd, yb, yb + zn * k, $"e={Units.SpS(r.NodalSpacingCm)}");
            s.DimVert(xd, yb + zn * k, top - zn * k, $"e={Units.SpS(r.StirSpacingCm)}");
            s.DimVert(xd, top - zn * k, top, $"e={Units.SpS(r.NodalSpacingCm)}");
        }
        else s.DimVert(xd, yb, top, $"e={Units.SpS(r.StirSpacingCm)}");
        s.DimVert(xe - 21, yb, top, $"{Units.LenS(L)} {Units.Length}");

        // repère de coupe + bulles
        double yA = (yb + top) / 2;
        if (cfg.ShowCutMarks) s.CutMark(xe - 5, yA, xe + bw + 5, yA, "A", 0, 1);
        var bars = ColumnBars(r, cfg, Ids("P", g.Select(q => q.MemberId)), g.Count);
        sheetBars.AddRange(bars);
        if (cfg.ShowBarMarks)
        {
            double y1 = yb + 0.78 * L * k;
            s.Line(xr, y1, xe + bw + 5.1, y1, "REPERES"); s.Bubble(xe + bw + 7, y1, 1.9, "1");
            double y2 = yb + 0.32 * L * k;
            double y2s = pos.Select(pp => yb + pp * k).OrderBy(yy => Math.Abs(yy - y2)).FirstOrDefault(y2);
            s.Line(xr + 0.4, y2s, xe + bw + 5.1, y2s, "REPERES"); s.Bubble(xe + bw + 7, y2s, 1.9, "2");
        }

        // coupe A-A
        double secScale = SecScaleFor(h, b), kk = 1000 / secScale;
        double xs = xe + bw + 24, ysec = 255 - h * kk;
        ColumnSection(s, xs, ysec, r, cov, kk, cfg, bars);
        s.Text(xs, ysec - 19, 2.8, "COUPE A-A", "TEXTE");
        s.Text(xs, ysec - 23, 2.4, $"(ech. 1:{secScale:0})", "TEXTE");

        // légende
        double ly = ysec - 32;
        double maxW = x0 + 128 - xs - 4;
        var legend = new List<(string Mark, string Text)>
        {
            ("1", $"{r.BotN} HA{r.BotDia} : L = {Units.LenS(bars[0].LengthM)} {Units.Length}, As = {Units.AsS(r.AsBottom)} {Units.AsU}")
        };
        for (int i = 1; i < bars.Count; i++)
            legend.Add((bars[i].Mark.ToString(), bars[i].Role == "Cadres"
                ? $"Cadres HA{r.StirDia} : e = {Units.SpS(r.StirSpacingCm)} {Units.Section}" + (en > 0 ? $", e = {Units.SpS(r.NodalSpacingCm)} {Units.Section} sur {Units.LenS(zn)} {Units.Length} aux extrémités" : "")
                : $"{bars[i].Role} HA{r.StirDia} ({bars[i].Count} au total)"));
        double y = ly;
        foreach (var (mark, text) in legend)
        {
            var lines = Wrap(text, Math.Max(18, (int)(maxW / 1.55)));
            if (cfg.ShowBarMarks) s.Bubble(xs + 2.2, y + 0.9, 1.9, mark);
            foreach (var ln in lines) { s.Text(xs + 6, y, 2.4, ln, "TEXTE"); y -= 4.2; }
            y -= 1.2;
        }
    }

    /// <summary>Coupe transversale d'un poteau : cadre avec crochets 135°, barres d'angle, barres intermédiaires et épingles.</summary>
    private static void ColumnSection(Sheet s, double xs, double ys, MemberDesignResult r, double cov, double kk, DesignSettings cfg, List<BarLine> bars)
    {
        double b = r.B, h = r.H, bw = b * kk, hh = h * kk;
        s.Rect(xs, ys, bw, hh, "BETON");
        double inset = Math.Max(cov - r.BotDia / 2000.0, 0.015) * kk;
        double phiT = Math.Max(r.StirDia, 6) / 1000.0 * kk;
        s.Stirrup(xs + inset, ys + inset, bw - 2 * inset, hh - 2 * inset, Math.Max(0.8, 2.5 * phiT), Math.Max(3.0, cfg.HookFactor * phiT), "CADRES");
        var (t, sd) = ColumnTies(r.BotN, b, h);
        double xl = xs + cov * kk, xr = xs + (b - cov) * kk, yl = ys + cov * kk, yu = ys + (h - cov) * kk;
        double rad = Math.Max(r.BotDia / 2000.0 * kk, 0.9);
        double hook = Math.Max(2.5, cfg.HookFactor * phiT * 0.8);
        // épingles (derrière les barres)
        for (int i = 1; i <= t; i++) { double x = xl + i * (xr - xl) / (t + 1); s.Pin(x, yl, x, yu, hook, "CADRES"); }
        for (int i = 1; i <= sd; i++) { double y = yl + i * (yu - yl) / (sd + 1); s.Pin(xl, y, xr, y, hook, "CADRES"); }
        foreach (var (x, y) in new[] { (xl, yl), (xr, yl), (xl, yu), (xr, yu) }) s.Dot(x, y, rad, "ARMATURES");
        for (int i = 1; i <= t; i++) { double x = xl + i * (xr - xl) / (t + 1); s.Dot(x, yl, rad, "ARMATURES"); s.Dot(x, yu, rad, "ARMATURES"); }
        for (int i = 1; i <= sd; i++) { double y = yl + i * (yu - yl) / (sd + 1); s.Dot(xl, y, rad, "ARMATURES"); s.Dot(xr, y, rad, "ARMATURES"); }
        if (cfg.ShowBarMarks)
        {
            s.Line(xl, yu + rad, xl, ys + hh + 4.6, "REPERES"); s.Bubble(xl, ys + hh + 6.5, 1.9, "1");
            s.Line(xs + bw - inset, ys + hh * 0.5, xs + bw + 5.1, ys + hh * 0.5, "REPERES"); s.Bubble(xs + bw + 7, ys + hh * 0.5, 1.9, "2");
            var pinV = bars.FirstOrDefault(q => q.Role == "Epingles (sens h)");
            if (pinV != null && t > 0)
            {
                double xp = xl + (xr - xl) / (t + 1);
                s.Line(xp, yl - rad, xp, ys - 4.1, "REPERES"); s.Bubble(xp, ys - 6, 1.9, pinV.Mark.ToString());
            }
            var pinH = bars.FirstOrDefault(q => q.Role == "Epingles (sens b)");
            if (pinH != null && sd > 0)
            {
                double yp = yl + (yu - yl) / (sd + 1);
                s.Line(xl, yp, xs - 5.1, yp, "REPERES"); s.Bubble(xs - 7, yp, 1.9, pinH.Mark.ToString());
            }
        }
        s.Dim(xs, xs + bw, ys - 13, Units.SecS(b));
        s.DimVert(xs + bw + 14, ys, ys + hh, Units.SecS(h));
    }
}
