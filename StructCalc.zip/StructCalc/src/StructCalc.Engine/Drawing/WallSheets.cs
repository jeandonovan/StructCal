using System.Globalization;
using StructCalc.Engine.Walls;

namespace StructCalc.Engine.Drawing;

/// <summary>Planche d'un voile : élévation avec ouvertures, armatures générales, zones renforcées, chaînages et tableau.</summary>
public static class WallSheets
{
    private static string F(double v, string f = "0.00") => v.ToString(f, CultureInfo.InvariantCulture);

    public static IEnumerable<Sheet> Build(AnalysisOutput o)
    {
        foreach (var r in o.Walls)
        {
            if (r.Mesh.Elems.Count == 0) continue;
            var w = r.Def;
            var s = new Sheet { Name = "Voile " + w.Name, Title = $"VOILE {w.Name} - élévation et ferraillage", ScaleText = "voir cotes" };
            double sc = Math.Min(250 / w.LengthM, 160 / w.HeightM);          // mm par m
            double x0 = 30, y0 = 70;
            s.Rect(x0, y0, w.LengthM * sc, w.HeightM * sc, "CONTOUR");
            foreach (var op in w.Openings)
            {
                double ox = x0 + op.XM * sc, oy = y0 + op.ZM * sc, ow = op.WidthM * sc, oh = op.HeightM * sc;
                s.Rect(ox, oy, ow, oh, "CONTOUR");
                s.Line(ox, oy, ox + ow, oy + oh, "HACHURES"); s.Line(ox, oy + oh, ox + ow, oy, "HACHURES");
                var q = r.OpeningResults.FirstOrDefault(z => z.Opening == op);
                if (q != null)
                {
                    s.Line(ox - 2.5, oy, ox - 2.5, oy + oh, "ARMATURES"); s.Line(ox + ow + 2.5, oy, ox + ow + 2.5, oy + oh, "ARMATURES");
                    s.Line(ox, oy + oh + 2.5, ox + ow, oy + oh + 2.5, "ARMATURES");
                    if (op.ZM > 0) s.Line(ox, oy - 2.5, ox + ow, oy - 2.5, "ARMATURES");
                    s.Text(ox + 1, oy + oh + 5, 2.4, "linteau " + q.Lintel, "ARMATURES");
                    s.Text(ox + 1, oy + oh / 2, 2.4, op.Name + " " + F(op.WidthM) + "x" + F(op.HeightM), "TEXTE");
                    s.Text(ox + 1, oy + oh / 2 - 4, 2.4, "jambage " + q.Jamb, "ARMATURES");
                }
            }
            int k = 1;
            foreach (var z in r.Zones)
            {
                s.DashLine(x0 + z.X0 * sc, y0 + z.Y0 * sc, x0 + z.X1 * sc, y0 + z.Y0 * sc, "ARMATURES");
                s.DashLine(x0 + z.X1 * sc, y0 + z.Y0 * sc, x0 + z.X1 * sc, y0 + z.Y1 * sc, "ARMATURES");
                s.DashLine(x0 + z.X1 * sc, y0 + z.Y1 * sc, x0 + z.X0 * sc, y0 + z.Y1 * sc, "ARMATURES");
                s.DashLine(x0 + z.X0 * sc, y0 + z.Y1 * sc, x0 + z.X0 * sc, y0 + z.Y0 * sc, "ARMATURES");
                s.Text(x0 + z.X0 * sc + 1, y0 + z.Y1 * sc - 3, 2.4, "Z" + k++, "ARMATURES");
            }
            s.DimH(x0, x0 + w.LengthM * sc, y0 - 8, F(w.LengthM) + " m");
            s.DimV(x0 - 8, y0, y0 + w.HeightM * sc, F(w.HeightM) + " m");
            double tx = 310;
            s.Text(tx, 230, 3.5, "ARMATURES COURANTES (par face)", "TEXTE");
            s.Text(tx, 223, 2.8, "Verticales : " + r.GeneralV, "ARMATURES");
            s.Text(tx, 217, 2.8, "Horizontales : " + r.GeneralH, "ARMATURES");
            s.Text(tx, 211, 2.8, $"Épaisseur {w.ThicknessM * 100:0} cm ; enrobage {w.CoverCm:0.#} cm", "TEXTE");
            double yy = 200; k = 1;
            if (r.Zones.Count > 0) s.Text(tx, yy, 3.2, "ZONES RENFORCÉES", "TEXTE");
            foreach (var z in r.Zones.Take(8)) { yy -= 6; s.Text(tx, yy, 2.5, $"Z{k++} : V {z.BarsV} ; H {z.BarsH}", "ARMATURES"); }
            yy -= 10; if (r.OpeningResults.Count > 0) s.Text(tx, yy, 3.2, "OUVERTURES", "TEXTE");
            foreach (var q in r.OpeningResults.Take(6)) { yy -= 6; s.Text(tx, yy, 2.5, $"{q.Opening.Name} : jamb. {q.Jamb} ; linteau {q.Lintel}", "ARMATURES"); }
            yield return s;
        }
    }
}
