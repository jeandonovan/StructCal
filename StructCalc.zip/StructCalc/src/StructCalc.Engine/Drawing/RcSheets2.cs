using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Drawing;

public static partial class RcSheets
{
    private static (int dia, double e) ParseBars(string? t)
    {
        if (t == null) return (10, 20);
        var mt = Regex.Match(t, @"HA(\d+)\s*e=(\d+)");
        return mt.Success ? (int.Parse(mt.Groups[1].Value), double.Parse(mt.Groups[2].Value)) : (10, 20);
    }

    private static int CountAlong(double length, double spacingCm) => (int)Math.Floor(Math.Max(length, 0) / Math.Max(spacingCm, 3) * 100.0) + 1;

    // ===================================================================== SEMELLES
    private sealed record FootInfo(int Node, double A, double B, double H, double ColA, double ColB, int DA, double EA, int DB, double EB, double AsA, double AsB, bool Glacis = false, double Edge = 0);

    public static IEnumerable<Sheet> Footings(StructModel m, AnalysisOutput o, List<BarLine> all)
    {
        var cfg = m.Settings;
        var items = new List<FootInfo>();
        foreach (var f in o.Footings.Where(q => q.Values.ContainsKey("A_m")))
        {
            double A = f.Values["A_m"], B = f.Values["B_m"], h = f.Values["h_m"];
            var mt = Regex.Match(f.Element, @"nœud (\d+)");
            int node = mt.Success ? int.Parse(mt.Groups[1].Value) : -1;
            var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && (x.NodeI == node || x.NodeJ == node));
            bool gl; double edgeCm;
            if (f.Values.TryGetValue("glacis", out double gv)) { gl = gv > 0.5; edgeCm = f.Values.GetValueOrDefault("glacis_edge_m") * 100; }
            else { gl = m.FootingGlacis; edgeCm = m.FootingGlacisEdgeCm; }
            var (dA, eA) = ParseBars(f.Texts.GetValueOrDefault("Nappe // A"));
            var (dB, eB) = ParseBars(f.Texts.GetValueOrDefault("Nappe // B"));
            items.Add(new FootInfo(node, A, B, h, col?.B ?? 0.30, col?.H ?? 0.30, dA, eA, dB, eB,
                                   f.Values.GetValueOrDefault("As_A_cm2"), f.Values.GetValueOrDefault("As_B_cm2"), gl, gl ? StructCalc.Engine.Geometry.FootingSolids.EdgeThickness(h, edgeCm) : 0));
        }
        var groups = Group(items, cfg.GroupIdenticalElements,
            f => $"{f.A:F2}|{f.B:F2}|{f.H:F2}|{f.DA}|{f.EA}|{f.DB}|{f.EB}|{f.ColA:F2}|{f.ColB:F2}|{f.Glacis}|{f.Edge:F2}", f => f.Node);
        var res = new List<Sheet>();
        foreach (var g in groups)
        {
            var f = g[0];
            double sc = Math.Max(PickScale(Math.Max(f.A * 1000 / 150, f.B * 1000 / 115)), 20);
            double k = 1000 / sc;
            var s = New("Semelles", "FERRAILLAGE DES SEMELLES ISOLEES", $"1:{sc:0}");
            string ids = Ids("S", g.Select(q => q.Node));
            s.TextFit(20, 283, 3.8, $"SEMELLE ISOLEE {ids} sous noeud(s) - {Units.SecS(f.A)} x {Units.SecS(f.B)} {Units.Section}, h = {Units.SecS(f.H)} {Units.Section}" + (g.Count > 1 ? $"   -   {g.Count} semelles identiques" : ""), "TEXTE", cfg.ShowBarSchedule ? 250 : 385);

            double ox = 36, oy = 150, A = f.A, B = f.B, h = f.H, cov = Math.Max(cfg.CoverFootingCm / 100.0, 0.04);
            // ---------- plan
            s.Rect(ox, oy, A * k, B * k, "BETON");
            double cxl = ox + (A - f.ColA) * k / 2, cyl = oy + (B - f.ColB) * k / 2;
            if (f.Glacis)
            {
                // plateau du glacis (arête haute du pan incliné), en traits d'axe
                double pw = Math.Min(A, f.ColA + 2 * StructCalc.Engine.Geometry.FootingSolids.PlateauMargin), pd = Math.Min(B, f.ColB + 2 * StructCalc.Engine.Geometry.FootingSolids.PlateauMargin);
                double px0 = ox + (A - pw) * k / 2, py0 = oy + (B - pd) * k / 2;
                s.DashLine(px0, py0, px0 + pw * k, py0, "AXES", 2, 1); s.DashLine(px0 + pw * k, py0, px0 + pw * k, py0 + pd * k, "AXES", 2, 1);
                s.DashLine(px0 + pw * k, py0 + pd * k, px0, py0 + pd * k, "AXES", 2, 1); s.DashLine(px0, py0 + pd * k, px0, py0, "AXES", 2, 1);
                s.Text(px0 + 1, py0 - 3.4, 2.2, "plateau du glacis", "TEXTE");
            }
            s.Rect(cxl, cyl, f.ColA * k, f.ColB * k, "CONTOUR");
            s.Line(cxl, cyl, cxl + f.ColA * k, cyl + f.ColB * k, "CONTOUR"); s.Line(cxl, cyl + f.ColB * k, cxl + f.ColA * k, cyl, "CONTOUR");
            double y1 = oy + 0.72 * B * k, x2 = ox + 0.72 * A * k;
            s.Line(ox + cov * k, y1, ox + (A - cov) * k, y1, "ARMATURES");
            s.Line(ox + cov * k, y1 - 1.5, ox + cov * k, y1 + 1.5, "ARMATURES"); s.Line(ox + (A - cov) * k, y1 - 1.5, ox + (A - cov) * k, y1 + 1.5, "ARMATURES");
            s.Line(x2, oy + cov * k, x2, oy + (B - cov) * k, "ARMATURES2");
            s.Line(x2 - 1.5, oy + cov * k, x2 + 1.5, oy + cov * k, "ARMATURES2"); s.Line(x2 - 1.5, oy + (B - cov) * k, x2 + 1.5, oy + (B - cov) * k, "ARMATURES2");
            // zones de répartition (flèches)
            double xa = ox + 0.14 * A * k, yb2 = oy + 0.16 * B * k;
            s.Line(xa, oy + cov * k, xa, oy + (B - cov) * k, "COTES");
            s.Arrow(xa, oy + cov * k, 0, -1, "COTES"); s.Arrow(xa, oy + (B - cov) * k, 0, 1, "COTES");
            string t1 = $"HA{f.DA} e={f.EA:0}";
            s.Text(xa + 3.4, oy + B * k / 2 - Detailing.TextWidth(t1, 2.4) / 2, 2.4, t1, "ARMATURES", 90);
            s.Line(ox + cov * k, yb2, ox + (A - cov) * k, yb2, "COTES");
            s.Arrow(ox + cov * k, yb2, -1, 0, "COTES"); s.Arrow(ox + (A - cov) * k, yb2, 1, 0, "COTES");
            string t2 = $"HA{f.DB} e={f.EB:0}";
            s.Text(ox + A * k / 2 - Detailing.TextWidth(t2, 2.4) / 2, yb2 + 1.2, 2.4, t2, "ARMATURES2");
            // bulles
            if (cfg.ShowBarMarks)
            {
                s.Line(ox + cov * k, y1, ox - 4.1, y1, "REPERES"); s.Bubble(ox - 6, y1, 1.9, "1");
                s.Line(x2, oy + (B - cov) * k, x2, oy + B * k + 4.1, "REPERES"); s.Bubble(x2, oy + B * k + 6, 1.9, "2");
            }
            if (cfg.ShowCutMarks) s.CutMark(ox - 9, oy + B * k / 2, ox + A * k + 9, oy + B * k / 2, "A", 0, 1);
            s.Dim(ox, ox + A * k, oy - 10, Units.SecS(A));
            s.DimVert(ox + A * k + 12, oy, oy + B * k, Units.SecS(B));

            // ---------- coupe A-A
            double xc = 230, ys = 150, stubH = 26;
            s.Text(xc, ys + h * k + stubH + 14, 3.0, $"COUPE A-A (ech. 1:{sc:0})", "TEXTE");
            s.Rect(xc - 0.05 * k, ys - 0.05 * k, A * k + 0.10 * k, 0.05 * k, "CONTOUR");
            s.Hatch(xc - 0.05 * k, ys - 0.05 * k, A * k + 0.10 * k, 0.05 * k, 1.2);
            if (f.Glacis && h - f.Edge > 0.03)
            {
                double pw2 = Math.Min(A, f.ColA + 2 * StructCalc.Engine.Geometry.FootingSolids.PlateauMargin);
                double xl2 = xc + (A - pw2) * k / 2, xr2 = xc + (A + pw2) * k / 2, ye = ys + f.Edge * k;
                s.Line(xc, ys, xc + A * k, ys, "BETON"); s.Line(xc + A * k, ys, xc + A * k, ye, "BETON"); s.Line(xc + A * k, ye, xr2, ys + h * k, "BETON");
                s.Line(xr2, ys + h * k, xl2, ys + h * k, "BETON"); s.Line(xl2, ys + h * k, xc, ye, "BETON"); s.Line(xc, ye, xc, ys, "BETON");
                s.DimVert(xc - 8, ys, ye, Units.SecS(f.Edge));
                s.Text(xc + 2, ys + h * k + 2.5, 2.3, "GLACIS", "TEXTE");
            }
            else s.Rect(xc, ys, A * k, h * k, "BETON");
            double sl = xc + (A - f.ColA) * k / 2, sr = xc + (A + f.ColA) * k / 2;
            s.Line(sl, ys + h * k, sl, ys + h * k + stubH, "BETON"); s.Line(sr, ys + h * k, sr, ys + h * k + stubH, "BETON");
            s.Line(sl - 1.5, ys + h * k + stubH - 1, sr + 1.5, ys + h * k + stubH + 1, "CONTOUR");
            double hAv = f.Glacis ? f.Edge : h;      // les crochets des nappes doivent tenir dans l'épaisseur au bord
            double hkv = Math.Min(Math.Max(0.15, 12.0 * f.DA / 1000.0), Math.Max(hAv - 2 * cov, 0.08)) * k;
            double yLow = ys + cov * k, yHigh = yLow + (f.DA + f.DB) / 2000.0 * k + 0.6;
            s.Line(xc + cov * k, yLow, xc + (A - cov) * k, yLow, "ARMATURES");
            s.Line(xc + cov * k, yLow, xc + cov * k, yLow + hkv, "ARMATURES"); s.Line(xc + (A - cov) * k, yLow, xc + (A - cov) * k, yLow + hkv, "ARMATURES");
            int nDots = Math.Min(CountAlong(A - 2 * cov, f.EB), 40);
            double rdot = Math.Max(f.DB / 2000.0 * k, 0.8);
            var dotX = new List<double>();
            for (int i = 0; i < nDots; i++) dotX.Add(nDots == 1 ? xc + A * k / 2 : xc + cov * k + i * (A - 2 * cov) * k / (nDots - 1));
            foreach (double dx in dotX) s.Dot(dx, yHigh + rdot, rdot, "ARMATURES2");
            // attentes du poteau
            double xa1 = sl + 0.04 * k, xa2 = sr - 0.04 * k;
            s.Line(xa1, yLow + 1.2, xa1, ys + h * k + stubH - 2, "ARMATURES"); s.Line(xa2, yLow + 1.2, xa2, ys + h * k + stubH - 2, "ARMATURES");
            s.Line(xa1, yLow + 1.2, xa1 - 0.15 * k, yLow + 1.2, "ARMATURES"); s.Line(xa2, yLow + 1.2, xa2 + 0.15 * k, yLow + 1.2, "ARMATURES");
            if (cfg.ShowBarMarks)
            {
                double xm1 = xc + 0.14 * A * k;
                s.Line(xm1, yLow, xm1, ys + h * k + 7.1, "REPERES"); s.Bubble(xm1, ys + h * k + 9, 1.9, "1");
                double xm2 = dotX.OrderBy(dd => Math.Abs(dd - (xc + 0.86 * A * k))).First();
                s.Line(xm2, yHigh + 2 * rdot, xm2, ys + h * k + 7.1, "REPERES"); s.Bubble(xm2, ys + h * k + 9, 1.9, "2");
            }
            s.Dim(xc, xc + A * k, ys - 12, Units.SecS(A));
            s.DimVert(xc + A * k + 10, ys, ys + h * k, Units.SecS(h));
            if (f.Glacis) s.TextFit(xc, ys - 24, 2.3, $"semelle à glacis : épaisseur au bord {Units.SecS(f.Edge)} {Units.Section}, plateau poteau + {StructCalc.Engine.Geometry.FootingSolids.PlateauMargin * 100:0} cm de chaque côté", "TEXTE", 150);
            s.TextFit(xc, ys - 19, 2.3, $"enrobage {Units.SecS(cov)} {Units.Section} ; béton de propreté {Units.SecS(0.05)} {Units.Section}", "TEXTE", 150);

            // ---------- nomenclature et légende
            var lines = new List<BarLine>();
            string ename = ids;
            double hk = Math.Min(Math.Max(0.15, 12.0 * f.DA / 1000.0), Math.Max(hAv - 2 * cov, 0.08));
            lines.Add(new BarLine("Semelles", ename, 1, CountAlong(B - 2 * cov, f.EA), f.DA, "droite + 2 crochets 90°", R2(A - 2 * cov + 2 * hk), "Nappe inférieure // A", g.Count));
            double hk2 = Math.Min(Math.Max(0.15, 12.0 * f.DB / 1000.0), Math.Max(hAv - 2 * cov, 0.08));
            lines.Add(new BarLine("Semelles", ename, 2, CountAlong(A - 2 * cov, f.EB), f.DB, "droite + 2 crochets 90°", R2(B - 2 * cov + 2 * hk2), "Nappe supérieure // B", g.Count));
            all.AddRange(lines);
            double ly = 118;
            string[] leg =
            {
                $"{lines[0].Count} HA{f.DA} e = {Units.SpS(f.EA)} {Units.Section} : nappe inférieure // A (As = {Units.AsS(f.AsA)} {Units.AsU}), L = {Units.LenS(lines[0].LengthM)} {Units.Length}",
                $"{lines[1].Count} HA{f.DB} e = {Units.SpS(f.EB)} {Units.Section} : nappe supérieure // B (As = {Units.AsS(f.AsB)} {Units.AsU}), L = {Units.LenS(lines[1].LengthM)} {Units.Length}"
            };
            for (int i = 0; i < leg.Length; i++)
            {
                if (cfg.ShowBarMarks) s.Bubble(ox + 2.2, ly - i * 5.2 + 0.9, 1.9, (i + 1).ToString());
                s.TextFit(ox + 6, ly - i * 5.2, 2.6, leg[i], "TEXTE", 330);
            }
            if (cfg.ShowBarSchedule) ScheduleTable(s, lines);
            res.Add(s);
        }
        return res;
    }

    // ===================================================================== DALLES
    private sealed record SlabInfo(string Name, double W, double D, double H, int D1, double E1, int D2, double E2, int D3, double E3, bool Has3, int D4, double E4, bool Has4);

    public static IEnumerable<Sheet> Slabs(StructModel m, AnalysisOutput o, List<BarLine> all)
    {
        var cfg = m.Settings;
        var items = new List<SlabInfo>();
        foreach (var d in o.Slabs.Where(q => q.Values.ContainsKey("Asx_travee_cm2m")))
        {
            var panel = m.Slabs.FirstOrDefault(p => d.Element.StartsWith("Dalle " + p.Name));
            if (panel == null) continue;
            var (d1, e1) = ParseBars(d.Texts.GetValueOrDefault("Travée sens lx"));
            var (d2, e2) = ParseBars(d.Texts.GetValueOrDefault("Travée sens ly"));
            bool h3 = d.Texts.ContainsKey("Appui sens lx"), h4 = d.Texts.ContainsKey("Appui sens ly");
            var (d3, e3) = ParseBars(d.Texts.GetValueOrDefault("Appui sens lx"));
            var (d4, e4) = ParseBars(d.Texts.GetValueOrDefault("Appui sens ly"));
            items.Add(new SlabInfo(panel.Name, Math.Min(panel.Lx, panel.Ly), Math.Max(panel.Lx, panel.Ly), panel.H, d1, e1, d2, e2, d3, e3, h3, d4, e4, h4));
        }
        var groups = Group(items, cfg.GroupIdenticalElements,
            q => $"{q.W:F2}|{q.D:F2}|{q.H:F2}|{q.D1}|{q.E1}|{q.D2}|{q.E2}|{q.D3}|{q.E3}|{q.Has3}|{q.D4}|{q.E4}|{q.Has4}", q => q.Name.GetHashCode());
        var res = new List<Sheet>();
        foreach (var g in groups)
        {
            var q = g[0];
            double sc = Math.Max(PickScale(Math.Max(q.W * 1000 / 165, q.D * 1000 / 150)), 25);
            double k = 1000 / sc;
            var s = New("Dalles", "FERRAILLAGE DES DALLES", $"1:{sc:0} (coupe 1:10)");
            string names = string.Join(", ", g.Take(6).Select(z => z.Name)) + (g.Count > 6 ? " +" + (g.Count - 6) : "");
            s.TextFit(20, 283, 3.8, $"DALLE {names} : {Units.LenS(q.W)} x {Units.LenS(q.D)} {Units.Length}, h = {Units.SecS(q.H)} {Units.Section}" + (g.Count > 1 ? $"   -   {g.Count} dalles identiques" : "") + "   (petit côté lx à l'horizontale)", "TEXTE", cfg.ShowBarSchedule ? 250 : 385);
            double ox = 36, oy = 100, W = q.W, D = q.D, cov = Math.Max(cfg.CoverSlabCm / 100.0, 0.02);
            double ch = cfg.SlabTopBarFactor * W;

            // ---------- plan
            s.Rect(ox, oy, W * k, D * k, "BETON");
            double ya = oy + 0.62 * D * k, xb = ox + 0.62 * W * k;
            s.Line(ox + 0.03 * k, ya, ox + (W - 0.03) * k, ya, "ARMATURES");
            s.Line(ox + 0.03 * k, ya - 1.5, ox + 0.03 * k, ya + 1.5, "ARMATURES"); s.Line(ox + (W - 0.03) * k, ya - 1.5, ox + (W - 0.03) * k, ya + 1.5, "ARMATURES");
            s.Line(xb, oy + 0.03 * k, xb, oy + (D - 0.03) * k, "ARMATURES2");
            s.Line(xb - 1.5, oy + 0.03 * k, xb + 1.5, oy + 0.03 * k, "ARMATURES2"); s.Line(xb - 1.5, oy + (D - 0.03) * k, xb + 1.5, oy + (D - 0.03) * k, "ARMATURES2");
            double xa = ox + 0.10 * W * k, yz = oy + 0.12 * D * k;
            s.Line(xa, oy + 0.05 * k, xa, oy + (D - 0.05) * k, "COTES");
            s.Arrow(xa, oy + 0.05 * k, 0, -1, "COTES"); s.Arrow(xa, oy + (D - 0.05) * k, 0, 1, "COTES");
            string t1 = $"HA{q.D1} e={q.E1:0}";
            s.Text(xa + 3.4, oy + D * k * 0.5 - Detailing.TextWidth(t1, 2.4) / 2, 2.4, t1, "ARMATURES", 90);
            s.Line(ox + 0.05 * k, yz, ox + (W - 0.05) * k, yz, "COTES");
            s.Arrow(ox + 0.05 * k, yz, -1, 0, "COTES"); s.Arrow(ox + (W - 0.05) * k, yz, 1, 0, "COTES");
            string t2 = $"HA{q.D2} e={q.E2:0}";
            s.Text(ox + W * k / 2 - Detailing.TextWidth(t2, 2.4) / 2, yz + 1.2, 2.4, t2, "ARMATURES2");
            if (q.Has3)
            {
                double yc = oy + 0.30 * D * k;
                s.Line(ox, yc, ox + ch * k, yc, "ARMATURES_HAUTES"); s.Line(ox + (W - ch) * k, yc, ox + W * k, yc, "ARMATURES_HAUTES");
                s.Dim(ox, ox + ch * k, yc + 3, Units.SecS(ch));
                s.Dim(ox + (W - ch) * k, ox + W * k, yc + 3, Units.SecS(ch));
            }
            if (q.Has4)
            {
                double xcp = ox + 0.40 * W * k;
                s.Line(xcp, oy, xcp, oy + ch * k, "ARMATURES_HAUTES"); s.Line(xcp, oy + D * k - ch * k, xcp, oy + D * k, "ARMATURES_HAUTES");
            }
            if (cfg.ShowBarMarks)
            {
                s.Line(ox + 0.03 * k, ya, ox - 4.1, ya, "REPERES"); s.Bubble(ox - 6, ya, 1.9, "1");
                s.Line(xb, oy + (D - 0.03) * k, xb, oy + D * k + 4.1, "REPERES"); s.Bubble(xb, oy + D * k + 6, 1.9, "2");
                if (q.Has3) { double yc = oy + 0.30 * D * k; s.Line(ox, yc, ox - 4.1, yc, "REPERES"); s.Bubble(ox - 6, yc, 1.9, "3"); }
                if (q.Has4) { double xcp = ox + 0.40 * W * k; s.Line(xcp, oy, xcp, oy - 4.1, "REPERES"); s.Bubble(xcp, oy - 6, 1.9, "4"); }
            }
            if (cfg.ShowCutMarks) s.CutMark(ox - 10, oy + D * k * 0.47, ox + W * k + 10, oy + D * k * 0.47, "A", 0, 1);
            s.Dim(ox, ox + W * k, oy - 14, Units.SecS(W));
            s.DimVert(ox + W * k + 12, oy, oy + D * k, Units.SecS(D));

            // ---------- coupe A-A schématique (largeur non à l'échelle, épaisseur à 1:10)
            int nRows = 2 + (q.Has3 ? 1 : 0) + (q.Has4 ? 1 : 0);
            double dTab = cfg.ShowBarSchedule ? Math.Min(0, SheetTable.DefaultTop - SheetTable.EstimateHeight(nRows, true) - 8 - 262) : 0;   // la coupe se place sous le tableau
            double xs = ox + W * k + 38, kk = 100, hs = q.H * kk, SW = Math.Min(120, 405 - xs - 22), ys = 235 + dTab - hs;
            s.Text(xs, 262 + dTab, 3.0, "COUPE A-A (schématique)", "TEXTE");
            s.Text(xs, 258 + dTab, 2.3, "épaisseur à 1:10, portée non à l'échelle", "TEXTE");
            s.Rect(xs, ys, SW, hs, "BETON");
            s.Rect(xs - 9, ys - 12, 9, hs + 12, "CONTOUR"); s.Hatch(xs - 9, ys - 12, 9, hs + 12, 1.5);
            s.Rect(xs + SW, ys - 12, 9, hs + 12, "CONTOUR"); s.Hatch(xs + SW, ys - 12, 9, hs + 12, 1.5);
            double c1 = cov * kk, c2 = c1 + Math.Max(q.D1 / 1000.0 * kk, 1.2);
            s.Line(xs + 2, ys + c1, xs + SW - 2, ys + c1, "ARMATURES");
            int nd = 12; double rd = Math.Max(q.D2 / 2000.0 * kk, 0.8);
            for (int i = 0; i < nd; i++) s.Dot(xs + 6 + i * (SW - 12) / (nd - 1), ys + c2 + rd, rd, "ARMATURES2");
            double chp = Math.Min(35, SW * 0.3), yt = ys + hs - c1;
            if (q.Has3)
            {
                s.Line(xs - 5, yt, xs + chp, yt, "ARMATURES_HAUTES"); s.Line(xs - 5, yt, xs - 5, yt - Math.Min(hs - 2 * c1, 8), "ARMATURES_HAUTES");
                s.Line(xs + SW - chp, yt, xs + SW + 5, yt, "ARMATURES_HAUTES"); s.Line(xs + SW + 5, yt, xs + SW + 5, yt - Math.Min(hs - 2 * c1, 8), "ARMATURES_HAUTES");
                s.Text(xs + chp + 1, yt + 1.4, 2.2, $"L = {Units.SecS(ch)} {Units.Section}", "ARMATURES_HAUTES");
            }
            if (q.Has4)
            {
                double r4 = Math.Max(q.D4 / 2000.0 * kk, 0.8);
                for (int i = 0; i < 4; i++) { s.Dot(xs + 6 + i * 5, yt - 2 * r4 - 0.6, r4, "ARMATURES_HAUTES"); s.Dot(xs + SW - 6 - i * 5, yt - 2 * r4 - 0.6, r4, "ARMATURES_HAUTES"); }
            }
            if (cfg.ShowBarMarks)
            {
                s.Line(xs + SW * 0.3, ys + c1, xs + SW * 0.3, ys - 4.1, "REPERES"); s.Bubble(xs + SW * 0.3, ys - 6, 1.9, "1");
                s.Line(xs + SW * 0.7, ys + c2, xs + SW * 0.7, ys - 4.1, "REPERES"); s.Bubble(xs + SW * 0.7, ys - 6, 1.9, "2");
                if (q.Has3) { s.Line(xs + 8, yt, xs + 8, ys + hs + 4.1, "REPERES"); s.Bubble(xs + 8, ys + hs + 6, 1.9, "3"); }
                if (q.Has4) { s.Line(xs + SW - 8, yt - 2 * Math.Max(q.D4 / 2000.0 * kk, 0.8), xs + SW - 8, ys + hs + 4.1, "REPERES"); s.Bubble(xs + SW - 8, ys + hs + 6, 1.9, "4"); }
            }
            s.DimVert(xs + SW + 16, ys, ys + hs, Units.SecS(q.H));

            // ---------- nomenclature et légende
            var lines = new List<BarLine>();
            lines.Add(new BarLine("Dalles", names, 1, CountAlong(D - 0.06, q.E1), q.D1, "droite", R2(W - 0.06), "Lit inférieur // petit côté", g.Count));
            lines.Add(new BarLine("Dalles", names, 2, CountAlong(W - 0.06, q.E2), q.D2, "droite", R2(D - 0.06), "Lit inférieur // grand côté", g.Count));
            double leg3 = ch + 0.15 + Math.Max(q.H - 0.04, 0.05);
            if (q.Has3) lines.Add(new BarLine("Dalles", names, 3, 2 * CountAlong(D, q.E3), q.D3, "droite + retour 90°", R2(leg3), "Chapeaux d'appui // petit côté", g.Count));
            if (q.Has4) lines.Add(new BarLine("Dalles", names, 4, 2 * CountAlong(W, q.E4), q.D4, "droite + retour 90°", R2(leg3), "Chapeaux d'appui // grand côté", g.Count));
            all.AddRange(lines);
            double ly = ys - 24;
            var leg = new List<string>
            {
                $"HA{q.D1} e = {Units.SpS(q.E1)} {Units.Section} : lit inférieur parallèle au petit côté, {lines[0].Count} barres de {Units.LenS(lines[0].LengthM)} {Units.Length}",
                $"HA{q.D2} e = {Units.SpS(q.E2)} {Units.Section} : lit inférieur parallèle au grand côté, {lines[1].Count} barres de {Units.LenS(lines[1].LengthM)} {Units.Length}"
            };
            if (q.Has3) leg.Add($"HA{q.D3} e = {Units.SpS(q.E3)} {Units.Section} : chapeaux sur appuis (petit côté), L = {Units.SecS(ch)} {Units.Section} de chaque côté de l'appui");
            if (q.Has4) leg.Add($"HA{q.D4} e = {Units.SpS(q.E4)} {Units.Section} : chapeaux sur appuis (grand côté), L = {Units.SecS(ch)} {Units.Section} de chaque côté de l'appui");
            for (int i = 0; i < leg.Count; i++)
            {
                double y = ly - i * 5.6;
                if (cfg.ShowBarMarks) s.Bubble(xs + 2.2, y + 0.9, 1.9, (i + 1).ToString());
                s.TextFit(xs + 6, y, 2.5, leg[i], "TEXTE", 405 - xs - 10);
            }
            if (cfg.ShowBarSchedule) ScheduleTable(s, lines);
            res.Add(s);
        }
        return res;
    }

    // ===================================================================== RECAPITULATIF
    public static IEnumerable<Sheet> Recap(List<BarLine> all)
    {
        var res = new List<Sheet>();
        if (all.Count == 0) return res;
        var s = New("Recapitulatif", "RECAPITULATIF DES ARMATURES (masses par diametre)", "-");
        var dias = all.Select(b => b.Dia).Distinct().OrderBy(d => d).ToList();
        var cats = all.Select(b => b.Cat).Distinct().ToList();
        var hdr = new List<string> { "Elements" };
        hdr.AddRange(dias.Select(d => "HA" + d + " (kg)"));
        hdr.Add("Total (kg)");
        var cw = new List<double> { 50 };
        cw.AddRange(dias.Select(_ => 26.0));
        cw.Add(30);
        var rows = new List<string[]>();
        foreach (var c in cats)
        {
            var r = new List<string> { c };
            double tot = 0;
            foreach (int d in dias)
            {
                double kg = all.Where(b => b.Cat == c && b.Dia == d).Sum(b => b.MassKg);
                tot += kg; r.Add(kg > 0 ? Math.Round(kg).ToString("0") : "-");
            }
            r.Add(Math.Round(tot).ToString("0"));
            rows.Add(r.ToArray());
        }
        var last = new List<string> { "TOTAL" };
        foreach (int d in dias) last.Add(Math.Round(all.Where(b => b.Dia == d).Sum(b => b.MassKg)).ToString("0"));
        last.Add(Math.Round(all.Sum(b => b.MassKg)).ToString("0"));
        rows.Add(last.ToArray());
        var t = new SheetTable
        {
            Title = "RECAPITULATIF DES ARMATURES DU PROJET", Subtitle = "Masses par diamètre et par type d'élément",
            Header = hdr.ToArray(), ColW = cw.ToArray(), TextH = 3.0, BodyRowMin = 8, TitleH = 12,
        };
        foreach (var r in rows) { t.Rows.Add(r); t.Shapes.Add(null); }
        t.AutoSize();
        s.AddTable(t);
        double y = t.Bottom - 10, nx = t.X0;
        s.Text(nx, y, 2.8, "Masses calculées d'après les longueurs développées des nomenclatures de chaque planche (crochets et attentes inclus).", "TEXTE");
        s.Text(nx, y - 5, 2.8, "Elles n'incluent ni chutes, ni recouvrements d'exécution, ni armatures non dessinées (escaliers, voiles, longrines...) : prévoir environ +10 %.", "TEXTE");
        s.Text(nx, y - 10, 2.8, "Longueurs et formes de principe : à vérifier par l'ingénieur et le bureau des méthodes avant commande.", "TEXTE");
        res.Add(s);
        return res;
    }
}
