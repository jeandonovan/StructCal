using StructCalc.Core;

namespace StructCalc.Engine.Drawing;

/// <summary>Symboles de dessin de ferraillage : repères de coupe, bulles, cadres avec crochets à 135°, épingles, barres en coupe, flèches, tableaux.
/// Coordonnées en mm de papier ; les dimensions réelles sont converties par l'appelant (échelle).</summary>
public static class Detailing
{
    /// <summary>Largeur approximative d'un texte de hauteur h (mm).</summary>
    public static double TextWidth(string t, double h) => t.Length * h * 0.70;

    /// <summary>Texte réduit pour ne pas dépasser maxW (la hauteur est diminuée, jamais en dessous de 1,6 mm).</summary>
    public static void TextFit(this Sheet s, double x, double y, double h, string t, string layer, double maxW, double rot = 0)
    {
        double w = TextWidth(t, h);
        if (w > maxW && maxW > 0) h = Math.Max(1.6, h * maxW / w);
        s.Text(x, y, h, t, layer, rot);
    }

    /// <summary>Texte centré horizontalement sur cx.</summary>
    public static void TextCenter(this Sheet s, double cx, double y, double h, string t, string layer = "TEXTE")
        => s.Text(cx - TextWidth(t, h) / 2, y, h, t, layer);

    /// <summary>Disque plein (barre en coupe).</summary>
    public static void Dot(this Sheet s, double cx, double cy, double r, string layer = "ARMATURES")
    {
        r = Math.Max(r, 0.6);
        s.Items.Add(new DrawEntity { Kind = EntKind.Circle, Layer = layer, X1 = cx, Y1 = cy, R = r, Fill = true });
    }

    /// <summary>Arc approché par des segments (angles en degrés, sens trigonométrique).</summary>
    public static void Arc(this Sheet s, double cx, double cy, double r, double a0, double a1, string layer, int seg = 5)
    {
        double px = cx + r * Math.Cos(a0 * Math.PI / 180), py = cy + r * Math.Sin(a0 * Math.PI / 180);
        for (int i = 1; i <= seg; i++)
        {
            double a = (a0 + (a1 - a0) * i / seg) * Math.PI / 180;
            double qx = cx + r * Math.Cos(a), qy = cy + r * Math.Sin(a);
            s.Line(px, py, qx, qy, layer);
            px = qx; py = qy;
        }
    }

    /// <summary>Pointe de flèche en (x,y) orientée selon (dx,dy) (la pointe est en x,y).</summary>
    public static void Arrow(this Sheet s, double x, double y, double dx, double dy, string layer, double size = 2.4)
    {
        double len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 1e-9) return;
        double ux = dx / len, uy = dy / len, nx = -uy, ny = ux;
        double bx = x - ux * size, by = y - uy * size, w = size * 0.28;
        s.Line(x, y, bx + nx * w, by + ny * w, layer);
        s.Line(x, y, bx - nx * w, by - ny * w, layer);
        s.Line(bx + nx * w, by + ny * w, bx - nx * w, by - ny * w, layer);
    }

    /// <summary>Bulle : cercle avec un repère (lettre ou numéro) centré.</summary>
    public static void Bubble(this Sheet s, double cx, double cy, double r, string label, string layer = "REPERES")
    {
        s.Circle(cx, cy, r, layer);
        double h = r * 1.15;
        if (label.Length > 1) h = r * 0.95;
        s.Text(cx - TextWidth(label, h) / 2 + 0.05, cy - h * 0.34, h, label, layer);
    }

    /// <summary>Repère de coupe : trait fort de (x1,y1) à (x2,y2), flèches de sens de vue (vx,vy) et lettre dans une bulle à chaque extrémité.</summary>
    public static void CutMark(this Sheet s, double x1, double y1, double x2, double y2, string letter, double vx, double vy)
    {
        s.Line(x1, y1, x2, y2, "COUPES");
        double len = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (len < 1e-6) return;
        double ux = (x2 - x1) / len, uy = (y2 - y1) / len;
        double vl = Math.Sqrt(vx * vx + vy * vy); if (vl < 1e-9) { vx = 1; vy = 0; vl = 1; }
        vx /= vl; vy /= vl;
        // petits traits d'extrémité dans le sens de la vue (symbole « pliage » de la ligne de coupe) + flèches
        double ar = 5.0;
        foreach (var (px, py, sgn) in new[] { (x1, y1, -1.0), (x2, y2, 1.0) })
        {
            double ex = px + vx * ar, ey = py + vy * ar;
            s.Line(px, py, ex, ey, "COUPES");
            s.Arrow(ex, ey, vx, vy, "COUPES", 2.6);
            s.Bubble(px + ux * sgn * 3.4, py + uy * sgn * 3.4, 2.4, letter, "COUPES");
        }
    }

    /// <summary>Ligne de repère : trait de (x,y) vers (tx,ty) puis texte.</summary>
    public static void Leader(this Sheet s, double x, double y, double tx, double ty, string text, string layer, double h = 2.5)
    {
        s.Line(x, y, tx, ty, layer);
        s.Dot(x, y, 0.5, layer);
        s.Text(tx + (tx >= x ? 0.8 : -TextWidth(text, h) - 0.8), ty - h * 0.3, h, text, layer);
    }

    /// <summary>Cadre rectangulaire avec angles arrondis et deux retours de crochet à 135° au coin supérieur gauche.
    /// (x,y) = coin inférieur gauche de l'axe du cadre ; w,h = dimensions axe à axe ; r = rayon de pliage ; hook = longueur des retours.</summary>
    public static void Stirrup(this Sheet s, double x, double y, double w, double h, double r, double hook, string layer = "CADRES")
    {
        r = Math.Max(0.4, Math.Min(r, Math.Min(w, h) / 4));
        // côtés
        s.Line(x + r, y, x + w - r, y, layer);
        s.Line(x + w, y + r, x + w, y + h - r, layer);
        s.Line(x + w - r, y + h, x + r, y + h, layer);
        s.Line(x, y + h - r, x, y + r, layer);
        // angles arrondis
        s.Arc(x + w - r, y + r, r, -90, 0, layer, 3);
        s.Arc(x + w - r, y + h - r, r, 0, 90, layer, 3);
        s.Arc(x + r, y + r, r, 180, 270, layer, 3);
        // angle haut-gauche : le cadre se referme, deux retours à 135° pénètrent dans le noyau
        s.Arc(x + r, y + h - r, r, 90, 180, layer, 3);
        double d = hook * 0.7071;
        s.Line(x + r, y + h, x + r + d, y + h - d, layer);
        s.Line(x, y + h - r, x + d, y + h - r - d, layer);
    }

    /// <summary>Épingle (étrier intermédiaire) verticale ou horizontale avec un crochet à 135° à chaque extrémité.</summary>
    public static void Pin(this Sheet s, double x1, double y1, double x2, double y2, double hook, string layer = "CADRES")
    {
        s.Line(x1, y1, x2, y2, layer);
        double len = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (len < 1e-6) return;
        double ux = (x2 - x1) / len, uy = (y2 - y1) / len, nx = -uy, ny = ux, d = hook * 0.7071;
        s.Line(x1, y1, x1 + ux * d + nx * d, y1 + uy * d + ny * d, layer);
        s.Line(x2, y2, x2 - ux * d - nx * d, y2 - uy * d - ny * d, layer);
    }

    /// <summary>Ligne d'axe (trait mixte simplifié) avec dépassement.</summary>
    public static void Axis(this Sheet s, double x1, double y1, double x2, double y2)
        => s.DashLine(x1, y1, x2, y2, "AXES", 7, 1.5);

    /// <summary>Hachures de béton coupé (traits à 45° dans le rectangle).</summary>
    public static void Hatch(this Sheet s, double x, double y, double w, double h, double step, string layer = "HACHURES")
    {
        for (double d = step; d < w + h; d += step)
        {
            double x1 = x + Math.Max(0, d - h), y1 = y + Math.Min(h, d);
            double x2 = x + Math.Min(w, d), y2 = y + Math.Max(0, d - w);
            s.Line(x1, y1, x2, y2, layer);
        }
    }

    /// <summary>Cote linéaire horizontale avec flèches et valeur centrée (au-dessus du trait).</summary>
    public static void Dim(this Sheet s, double x1, double x2, double y, string label, double h = 2.3)
    {
        s.Line(x1, y, x2, y, "COTES");
        s.Line(x1, y - 1.8, x1, y + 1.8, "COTES"); s.Line(x2, y - 1.8, x2, y + 1.8, "COTES");
        s.Line(x1 - 0.9, y - 0.9, x1 + 0.9, y + 0.9, "COTES"); s.Line(x2 - 0.9, y - 0.9, x2 + 0.9, y + 0.9, "COTES");
        double w = TextWidth(label, h);
        double hh = h;
        if (w > Math.Abs(x2 - x1) && x2 != x1) hh = Math.Max(1.6, h * Math.Abs(x2 - x1) / w);
        s.Text((x1 + x2) / 2 - TextWidth(label, hh) / 2, y + 0.9, hh, label, "COTES");
    }

    /// <summary>Cote linéaire verticale, texte tourné de 90° à gauche du trait.</summary>
    public static void DimVert(this Sheet s, double x, double y1, double y2, string label, double h = 2.3)
    {
        s.Line(x, y1, x, y2, "COTES");
        s.Line(x - 1.8, y1, x + 1.8, y1, "COTES"); s.Line(x - 1.8, y2, x + 1.8, y2, "COTES");
        s.Line(x - 0.9, y1 - 0.9, x + 0.9, y1 + 0.9, "COTES"); s.Line(x - 0.9, y2 - 0.9, x + 0.9, y2 + 0.9, "COTES");
        double len = Math.Abs(y2 - y1), w = TextWidth(label, h), hh = h;
        if (w > len && len > 0) hh = Math.Max(1.6, h * len / w);
        s.Text(x - 0.9, (y1 + y2) / 2 - TextWidth(label, hh) / 2, hh, label, "COTES", 90);
    }

    /// <summary>Tableau : colW = largeurs des colonnes (mm), rowH = hauteur de ligne ; (x,yTop) = coin supérieur gauche. Retourne la hauteur totale.</summary>
    public static double Table(this Sheet s, double x, double yTop, double[] colW, double rowH, string[] header, IList<string[]> rows,
                               double th = 2.3, string layer = "TABLEAU")
    {
        double total = colW.Sum();
        int n = rows.Count + 1;
        double hTot = n * rowH;
        s.Rect(x, yTop - hTot, total, hTot, layer);
        for (int i = 1; i < n; i++) s.Line(x, yTop - i * rowH, x + total, yTop - i * rowH, layer);
        double cx = x;
        for (int c = 0; c < colW.Length; c++)
        {
            if (c > 0) s.Line(cx, yTop, cx, yTop - hTot, layer);
            s.TextFit(cx + 0.8, yTop - rowH + rowH * 0.3, th, header[c], "TEXTE", colW[c] - 1.2);
            for (int r = 0; r < rows.Count; r++)
                if (c < rows[r].Length)
                    s.TextFit(cx + 0.8, yTop - (r + 2) * rowH + rowH * 0.3, th, rows[r][c], "TEXTE", colW[c] - 1.2);
            cx += colW[c];
        }
        s.Line(x, yTop - rowH, x + total, yTop - rowH, layer);
        return hTot;
    }
}
