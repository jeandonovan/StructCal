using System.Globalization;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine.Drawing;

/// <summary>Génère les planches après le calcul : repérage/coffrage, ferraillage des poutres, poteaux, semelles, dalles, nomenclature, assemblages acier.
/// Dessins de principe à l'échelle (mm de papier) : à contrôler et compléter (recouvrements, ancrages, coudes, enrobages) avant exécution.</summary>
public static class DrawingGenerator
{
    private static readonly double[] Scales = { 10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500, 750, 1000 };
    private static string N2(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
    private static string N1(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);

    private static Sheet New(string name, string title, string scale) => new() { Name = name, Title = title, ScaleText = scale };
    private static double PickScale(double needMm) => Scales.FirstOrDefault(s => needMm / s <= 1) is double v && v > 0 ? v : 1000;

    public static List<Sheet> Generate(StructModel m, AnalysisOutput o, bool licensed)
    {
        var sheets = new List<Sheet>();
        sheets.AddRange(Cover(m, o));
        sheets.AddRange(Framing(m, o));
        var bars = new List<BarLine>();
        sheets.AddRange(RcSheets.Beams(m, o, bars));
        sheets.AddRange(RcSheets.Columns(m, o, bars));
        sheets.AddRange(RcSheets.Footings(m, o, bars));
        sheets.AddRange(RcSheets.Slabs(m, o, bars));
        sheets.AddRange(StairSheets.Build(o));
        sheets.AddRange(FloorSheets.Build(o));
        sheets.AddRange(WallSheets.Build(o));
        sheets.AddRange(SteelSheets(m, o));
        if (bars.Count > 0) sheets.AddRange(TypicalDetails.Build(m));
        sheets.AddRange(RcSheets.Bending(bars));
        sheets.AddRange(RcSheets.Recap(bars));
        var inf = m.Info;
        if (inf != null)
        {
            if (string.IsNullOrWhiteSpace(m.Settings.Client)) m.Settings.Client = inf.Client;
            if (string.IsNullOrWhiteSpace(m.Settings.Engineer)) m.Settings.Engineer = inf.Designer;
            if (string.IsNullOrWhiteSpace(m.Settings.SiteName)) m.Settings.SiteName = inf.Site;
            if (string.IsNullOrWhiteSpace(m.Settings.Revision)) m.Settings.Revision = inf.Revision;
        }
        string norms = $"{(string.IsNullOrEmpty(o.RcCode) ? "-" : o.RcCode)} / {(string.IsNullOrEmpty(o.SteelCode) ? "-" : o.SteelCode)}";
        int n = 1;
        foreach (var s in sheets) { s.Number = (n++).ToString("00"); SheetLayout.Prepare(s); TitleBlock.Add(s, m.Name, norms, licensed, m.Settings); }
        return sheets;
    }

    // ================================================================== nomenclature
    private static IEnumerable<Sheet> Cover(StructModel m, AnalysisOutput o)
    {
        var res = new List<Sheet>();
        var rows = o.Members.ToList();
        int per = 28, pages = Math.Max(1, (int)Math.Ceiling(rows.Count / (double)per));
        for (int p = 0; p < pages; p++)
        {
            var s = New("Nomenclature", "NOMENCLATURE DES ELEMENTS" + (pages > 1 ? $" ({p + 1}/{pages})" : ""), "-");
            var t = new SheetTable
            {
                Title = "NOMENCLATURE DES ELEMENTS (resultats du calcul)", Subtitle = "Sections, armatures et état de chaque barre",
                Header = new[] { "N°", "Type", "Section", "L (m)", "Armatures inf./long./profil", "Armatures sup.", "Transversales", "Etat" },
                ColW = new[] { 12.0, 30, 26, 14, 70, 48, 62, 22 },
                TextH = 2.6, BodyRowMin = 6.2, TitleH = 11,
            };
            foreach (var r in rows.Skip(p * per).Take(per))
            {
                string typ = (r.Type == MemberType.Column ? "Poteau " : "Poutre ") + (r.Kind == MaterialKind.Steel ? "acier" : "BA");
                t.Rows.Add(new[] { r.MemberId.ToString(), typ, r.SectionText, N2(r.Length), r.BarsBottom, r.Kind == MaterialKind.Steel || r.Type == MemberType.Column ? "-" : r.BarsTop, r.Stirrups, r.Status });
                t.Shapes.Add(null);
            }
            t.AutoSize();
            s.AddTable(t);
            if (p == pages - 1)
            {
                double y = t.Bottom - 8;
                foreach (var line in Quantities.Compute(m, o).ToText().Split('\n')) { s.Text(t.X0, y, 2.8, line.TrimEnd('\r'), "TEXTE"); y -= 5; if (y < 60) break; }
            }
            res.Add(s);
        }
        return res;
    }

    // ================================================================== repérage / coffrage
    private static IEnumerable<Sheet> Framing(StructModel m, AnalysisOutput o)
    {
        var res = new List<Sheet>();
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var mems = m.Members.Where(x => nodes.ContainsKey(x.NodeI) && nodes.ContainsKey(x.NodeJ)).ToList();
        if (mems.Count == 0) return res;
        double ymin = mems.Min(x => Math.Min(nodes[x.NodeI].Y, nodes[x.NodeJ].Y)), ymax = mems.Max(x => Math.Max(nodes[x.NodeI].Y, nodes[x.NodeJ].Y));
        bool planar = ymax - ymin < 0.01;
        string Lbl(Member x) => (x.Type == MemberType.Column ? "P" : "B") + x.Id + "  " + SecText(x, o);

        if (planar)
        {
            double xmin = mems.Min(x => Math.Min(nodes[x.NodeI].X, nodes[x.NodeJ].X)), xmax = mems.Max(x => Math.Max(nodes[x.NodeI].X, nodes[x.NodeJ].X));
            double zmin = mems.Min(x => Math.Min(nodes[x.NodeI].Z, nodes[x.NodeJ].Z)), zmax = mems.Max(x => Math.Max(nodes[x.NodeI].Z, nodes[x.NodeJ].Z));
            double sc = Math.Max(PickScale(Math.Max((xmax - xmin) * 1000 / 360, (zmax - zmin) * 1000 / 175)), 20);
            var s = New("Elevation", "ELEVATION - REPERAGE DES ELEMENTS", "1:" + sc);
            double k = 1000 / sc, ox = 30 + Math.Max(0, (360 - (xmax - xmin) * k) / 2), oy = 75;
            foreach (var x in mems) DrawMemberOutline(s, x, nodes, o, (px, py) => (ox + (px - xmin) * k, oy + (py - zmin) * k), k, true, Lbl(x));
            foreach (var sp in m.Supports.Where(q => nodes.ContainsKey(q.NodeId)))
            {
                var n = nodes[sp.NodeId]; double px = ox + (n.X - xmin) * k, py = oy + (n.Z - zmin) * k;
                s.Line(px - 4, py - 6, px + 4, py - 6, "CONTOUR"); s.Line(px - 4, py - 6, px, py, "CONTOUR"); s.Line(px + 4, py - 6, px, py, "CONTOUR");
            }
            foreach (double z in nodes.Values.Select(n => Math.Round(n.Z, 3)).Distinct().OrderBy(z => z))
                s.Text(14, oy + (z - zmin) * k - 1, 3, "+" + N2(z), "COTES");
            AutoDims(s, Axes(mems.SelectMany(x => new[] { nodes[x.NodeI].X, nodes[x.NodeJ].X })), Axes(mems.SelectMany(x => new[] { nodes[x.NodeI].Z, nodes[x.NodeJ].Z })),
                     (px, py) => (ox + (px - xmin) * k, oy + (py - zmin) * k));
            res.Add(s);
        }
        else
        {
            foreach (double z in mems.Where(x => x.Type == MemberType.Beam).Select(x => Math.Round((nodes[x.NodeI].Z + nodes[x.NodeJ].Z) / 2, 3)).Distinct().OrderBy(z => z))
            {
                var beams = mems.Where(x => x.Type == MemberType.Beam && Math.Abs((nodes[x.NodeI].Z + nodes[x.NodeJ].Z) / 2 - z) < 0.01).ToList();
                var cols = mems.Where(x => x.Type == MemberType.Column && (Math.Abs(nodes[x.NodeI].Z - z) < 0.01 || Math.Abs(nodes[x.NodeJ].Z - z) < 0.01)).ToList();
                var ns = beams.SelectMany(b => new[] { nodes[b.NodeI], nodes[b.NodeJ] }).ToList();
                double xmin = ns.Min(n => n.X), xmax = ns.Max(n => n.X), ymn = ns.Min(n => n.Y), ymx = ns.Max(n => n.Y);
                double sc = Math.Max(PickScale(Math.Max((xmax - xmin) * 1000 / 350, (ymx - ymn) * 1000 / 170)), 20);
                var s = New("Coffrage", "PLAN DE COFFRAGE - NIVEAU +" + N2(z), "1:" + sc);
                double k = 1000 / sc, ox = 30 + Math.Max(0, (360 - (xmax - xmin) * k) / 2), oy = 75;
                (double, double) Map(double px, double py) => (ox + (px - xmin) * k, oy + (py - ymn) * k);
                foreach (var b in beams) DrawMemberOutline(s, b, nodes, o, Map, k, false, Lbl(b));
                foreach (var c in cols)
                {
                    var n = Math.Abs(nodes[c.NodeI].Z - z) < 0.01 ? nodes[c.NodeI] : nodes[c.NodeJ];
                    var (px, py) = Map(n.X, n.Y);
                    double w = c.B * k, h = c.H * k;
                    s.Rect(px - w / 2, py - h / 2, w, h, "BETON");
                    s.Line(px - w / 2, py - h / 2, px + w / 2, py + h / 2, "BETON"); s.Line(px - w / 2, py + h / 2, px + w / 2, py - h / 2, "BETON");
                    s.Text(px + w / 2 + 1, py - h / 2 - 3, 2.5, Lbl(c), "TEXTE");
                }
                AutoDims(s, Axes(ns.Concat(cols.Select(c => Math.Abs(nodes[c.NodeI].Z - z) < 0.01 ? nodes[c.NodeI] : nodes[c.NodeJ])).Select(q => q.X)),
                         Axes(ns.Concat(cols.Select(c => Math.Abs(nodes[c.NodeI].Z - z) < 0.01 ? nodes[c.NodeI] : nodes[c.NodeJ])).Select(q => q.Y)), Map);
                res.Add(s);
            }
        }
        return res;
    }

    /// <summary>Valeurs triées sans doublons (à 5 mm près).</summary>
    private static List<double> Axes(IEnumerable<double> values)
    {
        var r = new List<double>();
        foreach (double v in values.OrderBy(q => q)) if (r.Count == 0 || v - r[^1] > 0.005) r.Add(v);
        return r;
    }

    /// <summary>Cotation automatique d'un plan ou d'une élévation : entraxes consécutifs et cote hors-tout sous le dessin, entraxes (ou hauteurs d'étage) et cote totale à gauche.</summary>
    private static void AutoDims(Sheet s, List<double> us, List<double> vs, Func<double, double, (double X, double Y)> map)
    {
        if (us.Count == 0 || vs.Count == 0) return;
        var (xl, yb) = map(us[0], vs[0]);
        if (us.Count >= 2)
        {
            for (int i = 0; i < us.Count - 1; i++) s.DimH(map(us[i], vs[0]).X, map(us[i + 1], vs[0]).X, yb - 12, N2(us[i + 1] - us[i]));
            if (us.Count > 2) s.DimH(xl, map(us[^1], vs[0]).X, yb - 19, N2(us[^1] - us[0]));
        }
        if (vs.Count >= 2)
        {
            for (int j = 0; j < vs.Count - 1; j++) s.DimV(xl - 12, map(us[0], vs[j]).Y, map(us[0], vs[j + 1]).Y, N2(vs[j + 1] - vs[j]));
            if (vs.Count > 2) s.DimV(xl - 19, yb, map(us[0], vs[^1]).Y, N2(vs[^1] - vs[0]));
        }
    }

    private static string SecText(Member x, AnalysisOutput o)
    {
        var r = o.Members.FirstOrDefault(q => q.MemberId == x.Id);
        return r != null ? r.SectionText : (x.Kind == MaterialKind.Steel ? x.Profile : $"{x.B * 100:0}x{x.H * 100:0}");
    }

    private static void DrawMemberOutline(Sheet s, Member x, Dictionary<int, Node> nodes, AnalysisOutput o,
                                          Func<double, double, (double X, double Y)> map, double k, bool elevation, string label)
    {
        var a = nodes[x.NodeI]; var b = nodes[x.NodeJ];
        var (ax, ay) = map(a.X, elevation ? a.Z : a.Y);
        var (bx, by) = map(b.X, elevation ? b.Z : b.Y);
        double dx = bx - ax, dy = by - ay, len = Math.Sqrt(dx * dx + dy * dy);
        if (len < 0.1) return;
        SteelProfile? p = null;
        bool isSteel = x.Kind == MaterialKind.Steel && SteelCatalog.TryGet(x.Profile, out p);
        double wid = isSteel ? p!.B / 1000.0 : x.B;
        double dep = isSteel ? p!.H / 1000.0 : x.H;
        double hw = (elevation ? (x.Type == MemberType.Column ? wid : dep) : wid) * k / 2;
        double nx = -dy / len * hw, ny = dx / len * hw;
        s.Line(ax + nx, ay + ny, bx + nx, by + ny, "BETON"); s.Line(ax - nx, ay - ny, bx - nx, by - ny, "BETON");
        s.DashLine(ax, ay, bx, by, "AXES", 6, 2);
        if (x.Type == MemberType.Column) s.Text((ax + bx) / 2 + hw + 1.5, (ay + by) / 2, 2.5, label, "TEXTE");
        else s.Text((ax + bx) / 2 - label.Length * 0.8, (ay + by) / 2 + hw + 1.5, 2.5, label, "TEXTE");
    }

    // ================================================================== assemblages acier
    private sealed record Joint(EndPlateDesign D, int Count);

    private static IEnumerable<Sheet> SteelSheets(StructModel m, AnalysisOutput o)
    {
        var res = new List<Sheet>();
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var steelCols = m.Members.Where(x => x.Kind == MaterialKind.Steel && x.Type == MemberType.Column).ToList();
        var endPlates = new Dictionary<string, (EndPlateDesign D, List<int> Nodes)>();
        foreach (var bm in m.Members.Where(x => x.Kind == MaterialKind.Steel && x.Type == MemberType.Beam))
        {
            var br = o.Members.FirstOrDefault(r => r.MemberId == bm.Id);
            if (br == null || br.Skipped || !SteelCatalog.TryGet(br.Profile, out var bp)) continue;
            foreach (bool atI in new[] { true, false })
            {
                int nodeId = atI ? bm.NodeI : bm.NodeJ;
                var col = steelCols.FirstOrDefault(c => c.NodeI == nodeId || c.NodeJ == nodeId);
                if (col == null) continue;
                var cr = o.Members.FirstOrDefault(r => r.MemberId == col.Id);
                if (cr == null || !SteelCatalog.TryGet(cr.Profile, out var cp)) continue;
                int idx = atI ? 0 : Math.Max(0, br.StX.Length - 1);
                double M = br.StMsag.Length > idx ? Math.Max(br.StMsag[idx], br.StMhog[idx]) : br.MuHog;
                double V = br.StV.Length > idx ? br.StV[idx] : br.Vu;
                var d = ConnectionDesigner.EndPlate(bp, cp, m.SteelFy, M, V);
                string key = $"{d.BeamProfile}|{d.ColumnProfile}|{d.BoltDia}|{d.TensionRows}|{d.CompressionRows}";
                if (!endPlates.TryGetValue(key, out var e)) endPlates[key] = (d, new List<int> { nodeId });
                else e.Nodes.Add(nodeId);
            }
        }
        var bases = new Dictionary<string, (BasePlateDesign D, List<int> Nodes)>();
        foreach (var sup in m.Supports.Where(q => nodes.ContainsKey(q.NodeId)))
        {
            var col = steelCols.FirstOrDefault(c => c.NodeI == sup.NodeId || c.NodeJ == sup.NodeId);
            if (col == null) continue;
            var cr = o.Members.FirstOrDefault(r => r.MemberId == col.Id);
            if (cr == null || cr.Skipped || !SteelCatalog.TryGet(cr.Profile, out var cp)) continue;
            int idx = col.NodeI == sup.NodeId ? 0 : Math.Max(0, cr.StX.Length - 1);
            double M = cr.StMsag.Length > idx ? Math.Max(cr.StMsag[idx], cr.StMhog[idx]) : 0;
            var d = ConnectionDesigner.BasePlate(cp, m.SteelFy, m.Fc28, cr.NuMax, M, cr.Vu);
            string key = $"{d.ColumnProfile}|{d.PlateB}|{d.PlateH}|{d.PlateT}|{d.AnchorDia}|{d.AnchorCount}";
            if (!bases.TryGetValue(key, out var e)) bases[key] = (d, new List<int> { sup.NodeId });
            else e.Nodes.Add(sup.NodeId);
        }
        var details = new List<Action<Sheet, double>>();
        foreach (var e in endPlates.Values) { var cap = e; details.Add((s, x0) => EndPlateDetail(s, cap.D, cap.Nodes, x0)); }
        foreach (var e in bases.Values) { var cap = e; details.Add((s, x0) => BasePlateDetail(s, cap.D, cap.Nodes, x0)); }
        for (int pg = 0; pg * 2 < details.Count; pg++)
        {
            var s = New("Assemblages", "ASSEMBLAGES METALLIQUES - SCHEMAS DE PRINCIPE", "1:5 / 1:10");
            for (int i = 0; i < 2 && pg * 2 + i < details.Count; i++) details[pg * 2 + i](s, 20 + i * 200);
            res.Add(s);
        }
        return res;
    }

    private static void EndPlateDetail(Sheet s, EndPlateDesign d, List<int> nodes, double x0)
    {
        SteelCatalog.TryGet(d.BeamProfile, out var bp); SteelCatalog.TryGet(d.ColumnProfile, out var cp);
        double k = 1 / 5.0;                                 // 1:5
        s.Text(x0, 275, 3.4, $"ASSEMBLAGE POUTRE {d.BeamProfile} / POTEAU {d.ColumnProfile} - platine d'extremite", "ACIER");
        s.Text(x0, 270, 2.6, "Noeuds : " + string.Join(", ", nodes.Distinct()), "TEXTE");
        double xc = x0 + 110, yc = 190;                       // face du poteau (bride) et axe de la poutre
        // poteau (vue de côté : âme parallèle à l'axe de la poutre)
        double Hc = cp.H * k, Bc = cp.B * k;
        s.Rect(xc, yc - 90, Hc, 180, "ACIER");
        s.Line(xc + cp.Tf * k, yc - 90, xc + cp.Tf * k, yc + 90, "ACIER");
        s.Line(xc + Hc - cp.Tf * k, yc - 90, xc + Hc - cp.Tf * k, yc + 90, "ACIER");
        // poutre
        double Hb = bp.H * k, tfb = bp.Tf * k, tp = d.PlateT * k;
        double xe = xc - tp;
        s.Line(xe - 70, yc + Hb / 2, xe, yc + Hb / 2, "ACIER"); s.Line(xe - 70, yc - Hb / 2, xe, yc - Hb / 2, "ACIER");
        s.Line(xe - 70, yc + Hb / 2 - tfb, xe, yc + Hb / 2 - tfb, "ACIER"); s.Line(xe - 70, yc - Hb / 2 + tfb, xe, yc - Hb / 2 + tfb, "ACIER");
        s.Line(xe - 70, yc + Hb / 2, xe - 70, yc - Hb / 2, "CONTOUR");
        // platine
        double top = yc + Hb / 2 + d.Extension * k, bot = yc - Hb / 2 - 15 * k;
        s.Rect(xe, bot, tp, top - bot, "ACIER");
        // boulons
        double dB = d.BoltDia * k;
        var ys = new List<double>();
        for (int i = 0; i < d.TensionRows; i++) ys.Add(yc + Hb / 2 + 1.5 * d.BoltDia * k - i * d.Pitch * k);
        for (int i = 0; i < d.CompressionRows; i++) ys.Add(yc - Hb / 2 + tfb + 1.5 * d.BoltDia * k + i * d.Pitch * k * 0.0 - i * d.Pitch * k);
        foreach (double y in ys)
        {
            s.Line(xe - 4, y, xc + cp.Tf * k + 6, y, "BOULONS");
            s.Rect(xe - 7, y - dB * 0.8, 3, dB * 1.6, "BOULONS");
            s.Rect(xc + cp.Tf * k + 6, y - dB * 0.8, 3, dB * 1.6, "BOULONS");
        }
        s.Line(xe, yc + Hb / 2 - 0.5, xe - 5, yc + Hb / 2 + 4, "SOUDURES"); s.Line(xe, yc - Hb / 2 + 0.5, xe - 5, yc - Hb / 2 - 4, "SOUDURES");
        s.Text(xe - 70, yc + Hb / 2 + 8, 2.6, $"soudure semelles a = {d.FlangeWeld:0} mm", "SOUDURES");
        s.Text(xe - 70, yc - Hb / 2 - 10, 2.6, $"soudure ame a = {d.WebWeld:0} mm", "SOUDURES");
        s.DimV(xe - 76, yc - Hb / 2, yc + Hb / 2, $"{bp.H:0}");
        s.DimV(xc + Hc + 8, bot, top, $"{d.PlateH:0}");
        // vue en plan (coupe sur rang de boulons)
        double px = x0 + 20, py = 70;
        s.Text(px, py + 48, 2.8, "COUPE EN PLAN (rang de boulons)", "TEXTE");
        s.Rect(px, py, cp.B * k, cp.Tf * k, "ACIER");
        s.Rect(px + (cp.B - d.PlateW) * k / 2, py + cp.Tf * k, d.PlateW * k, d.PlateT * k, "ACIER");
        s.Rect(px + (cp.B - bp.B) * k / 2, py + (cp.Tf + d.PlateT) * k, bp.B * k, bp.Tf * k * 1.0 + 4, "ACIER");
        foreach (double sgn in new[] { -1.0, 1.0 })
            s.Circle(px + cp.B * k / 2 + sgn * d.Gauge * k / 2, py + (cp.Tf + d.PlateT / 2) * k, d.BoltDia / 2.0 * k, "BOULONS");
        s.DimH(px + (cp.B - d.PlateW) * k / 2, px + (cp.B + d.PlateW) * k / 2, py - 8, $"{d.PlateW:0}");
        // texte de synthèse
        double ty = 120; double tx = x0;
        foreach (var line in d.Notes) { s.Text(tx + 95, ty, 2.5, line.Length > 95 ? line[..95] : line, "TEXTE"); ty -= 5.5; if (ty < 62) break; }
    }

    private static void BasePlateDetail(Sheet s, BasePlateDesign d, List<int> nodes, double x0)
    {
        SteelCatalog.TryGet(d.ColumnProfile, out var cp);
        double k = 1 / 5.0;
        s.Text(x0, 275, 3.4, $"PIED DE POTEAU {d.ColumnProfile} - platine d'assise et tiges d'ancrage", "ACIER");
        s.Text(x0, 270, 2.6, "Noeuds : " + string.Join(", ", nodes.Distinct()), "TEXTE");
        double cx = x0 + 70, base0 = 150;
        double pw = d.PlateB * k, tp = d.PlateT * k;
        s.Rect(cx - pw / 2 - 20, base0 - 70, pw + 40, 70, "BETON");
        s.Rect(cx - pw / 2, base0, pw, tp, "ACIER");
        s.Line(cx - cp.B * k / 2, base0 + tp, cx - cp.B * k / 2, base0 + tp + 70, "ACIER");
        s.Line(cx + cp.B * k / 2, base0 + tp, cx + cp.B * k / 2, base0 + tp + 70, "ACIER");
        double ex = Math.Min(60, d.PlateB * 0.5 * k - 6);
        foreach (double sgn in new[] { -1.0, 1.0 })
        {
            double ax = cx + sgn * (pw / 2 - 50 * k);
            s.Line(ax, base0 + tp + 8, ax, base0 - Math.Min(d.AnchorLength * k, 65), "BOULONS");
            s.Rect(ax - 2, base0 + tp, 4, 3, "BOULONS");
            s.Line(ax, base0 - Math.Min(d.AnchorLength * k, 65), ax + sgn * 6, base0 - Math.Min(d.AnchorLength * k, 65), "BOULONS");
        }
        s.DimH(cx - pw / 2, cx + pw / 2, base0 - 76, $"{d.PlateB:0}");
        s.Text(cx + pw / 2 + 4, base0 + tp / 2, 2.6, $"platine {d.PlateT:0} mm", "ACIER");
        double py = 60 + 20, ph = d.PlateH * k;
        double px = x0 + 20;
        s.Text(px, py + ph + 6, 2.8, "VUE EN PLAN", "TEXTE");
        s.Rect(px, py, pw, ph, "ACIER");
        double x1 = px + pw / 2 - cp.B * k / 2, y1 = py + ph / 2 - cp.H * k / 2;
        s.Rect(x1, y1, cp.B * k, cp.Tf * k, "ACIER"); s.Rect(x1, y1 + (cp.H - cp.Tf) * k, cp.B * k, cp.Tf * k, "ACIER");
        s.Line(px + pw / 2, y1 + cp.Tf * k, px + pw / 2, y1 + (cp.H - cp.Tf) * k, "ACIER");
        foreach (double sx in new[] { 50 * k, pw - 50 * k })
            foreach (double sy in new[] { 50 * k, ph - 50 * k })
                s.Circle(px + sx, py + sy, d.AnchorDia / 2.0 * k + 0.5, "BOULONS");
        s.DimV(px + pw + 6, py, py + ph, $"{d.PlateH:0}");
        double ty = 125;
        foreach (var line in d.Notes) { s.Text(x0 + 105, ty, 2.5, line.Length > 85 ? line[..85] : line, "TEXTE"); ty -= 5.5; if (ty < 62) break; }
    }
}
