using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Contrôle de cohérence de la configuration (norme, séisme, enrobages, armatures). Retourne des conseils lisibles ; liste vide = rien à signaler.</summary>
public static class SettingsAdvisor
{
    public static List<string> Check(StructModel m)
    {
        var l = new List<string>();
        var s = m.Settings; var sz = m.Seismic;
        bool seismicCode = m.RcCodeId.Equals("RPA99", StringComparison.OrdinalIgnoreCase) || m.RcCodeId.Equals("EC8", StringComparison.OrdinalIgnoreCase);
        bool hasRc = m.Members.Any(x => x.Kind == MaterialKind.ReinforcedConcrete) || m.Slabs.Count > 0;

        if (hasRc)
        {
            if (sz.Enabled && !seismicCode)
                l.Add($"Séisme activé alors que la norme béton armé « {m.RcCodeId} » n'impose aucune disposition parasismique : choisissez RPA99 ou EC8 pour les zones critiques et les pourcentages d'armatures.");
            if (!sz.Enabled && seismicCode)
                l.Add($"La norme « {m.RcCodeId} » est parasismique mais le calcul sismique est désactivé : activez-le (page Séisme) ou choisissez BAEL91 / CBA93 / EC2.");
            if (sz.Enabled && sz.Norm == "RPA99" && m.RcCodeId.Equals("EC8", StringComparison.OrdinalIgnoreCase))
                l.Add("Les forces sismiques sont calculées selon le spectre RPA99 mais le béton est dimensionné selon EC8 : mélange de normes à éviter.");
            if (sz.Enabled && sz.Norm == "EC8" && m.RcCodeId.Equals("RPA99", StringComparison.OrdinalIgnoreCase))
                l.Add("Les forces sismiques sont calculées selon EC8 mais le béton est dimensionné selon RPA99 : mélange de normes à éviter.");
        }

        int maxBeam = s.BeamDias().Where(d => d <= 25).DefaultIfEmpty(s.BeamDias().Min()).Max();
        double needAxis = 2.0 + 0.6 + maxBeam / 20.0;     // enrobage 2 cm + cadre 6 mm + moitié de la barre (cm)
        if (s.CoverBeamCm < needAxis)
            l.Add($"Enrobage à l'axe des poutres ({s.CoverBeamCm:0.#} cm) faible pour des barres jusqu'à HA{maxBeam} : prévoir au moins {needAxis:0.#} cm (enrobage + cadre + demi-barre).");
        int maxCol = s.ColumnDias().Where(d => d <= 25).DefaultIfEmpty(s.ColumnDias().Min()).Max();
        double needCol = 2.0 + 0.6 + maxCol / 20.0;
        if (s.CoverColumnCm < needCol)
            l.Add($"Enrobage à l'axe des poteaux ({s.CoverColumnCm:0.#} cm) faible pour des barres jusqu'à HA{maxCol} : prévoir au moins {needCol:0.#} cm.");
        if (s.CoverFootingCm < 5)
            l.Add("Enrobage des semelles inférieur à 5 cm : l'enrobage minimal est de 5 cm au contact du sol (BAEL / EC2).");
        if (s.StirrupDiaRatio > 3.0)
            l.Add("Les cadres peuvent devenir inférieurs au tiers du diamètre des barres longitudinales (règle usuelle : diamètre des cadres >= diamètre longitudinal / 3).");
        if (s.MountingBarDiaMm < 8)
            l.Add("Barres de montage de moins de 8 mm : peu robustes pour tenir les cadres.");
        if (s.ColumnMaxPercent > 6)
            l.Add("Pourcentage maximal d'armatures de poteau supérieur à 6 % : au-delà, la mise en œuvre du béton est difficile.");
        if (s.ColumnMaxPercent > 0 && s.ColumnMinPercent > s.ColumnMaxPercent)
            l.Add("Le pourcentage minimal des poteaux est supérieur au pourcentage maximal.");
        if (s.BeamMaxPercent > 0 && s.BeamMinPercent > s.BeamMaxPercent)
            l.Add("Le pourcentage minimal des poutres est supérieur au pourcentage maximal.");
        if (m.Fe >= 500 && s.LapFactor < 50)
            l.Add($"Recouvrement de {s.LapFactor:0}φ avec un acier fe = {m.Fe:0} MPa : vérifiez la longueur de scellement (souvent 50φ pour HA500).");
        if (sz.Enabled && (sz.Zone == "IIb" || sz.Zone == "III") && s.LapFactor < 50 && m.RcCodeId.Equals("RPA99", StringComparison.OrdinalIgnoreCase))
            l.Add("RPA 99 en zone IIb ou III : la longueur de recouvrement minimale est de 50φ.");
        if (sz.Enabled && sz.Norm == "RPA99" && (sz.R < 1.5 || sz.R > 6))
            l.Add($"Coefficient de comportement R = {sz.R:0.##} inhabituel (RPA 99 : de 2 à 6 selon le système de contreventement).");
        if (sz.Enabled && sz.Norm == "EC8" && (sz.BehaviorQ < 1.5 || sz.BehaviorQ > 6.5))
            l.Add($"Coefficient de comportement q = {sz.BehaviorQ:0.##} inhabituel (EC8 : de 1,5 à 6,5 selon la classe de ductilité).");
        if (sz.Enabled && hasRc && m.Members.Any(x => x.Kind == MaterialKind.ReinforcedConcrete && x.Type == MemberType.Column && x.B < 0.25 && x.H < 0.25))
            l.Add("Poteaux de moins de 25 cm en zone sismique : dimension minimale non conforme (RPA 99 : 25 cm en zones I et II, 30 cm en zone III).");
        if (s.SlabMinSpacingCm < 7)
            l.Add("Espacement minimal des armatures de dalle inférieur à 7 cm : bétonnage difficile.");
        return l;
    }
}
