using System.Text;
using System.Text.Json;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Lecture d'un fichier projet avec contrôles et progression, pour l'ouverture depuis l'écran d'accueil. Les erreurs ont un message clair en français.</summary>
public static class ProjectFile
{
    /// <summary>Extensions de projets StructCalc.</summary>
    public static readonly string[] ProjectExtensions = { ".stcx", ".json" };

    /// <summary>Formats connus mais non pris en charge comme modèle (message dédié).</summary>
    public static readonly string[] UnsupportedModelExtensions = { ".ifc", ".ifczip", ".rvt", ".rfa", ".obj", ".stl", ".fbx", ".3ds", ".skp", ".dwg", ".dxf", ".pdf" };

    /// <summary>Message d'erreur si l'extension n'est pas celle d'un projet StructCalc, null si elle l'est.</summary>
    public static string? CheckExtension(string path)
    {
        string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
        if (ProjectExtensions.Contains(ext)) return null;
        string name = System.IO.Path.GetFileName(path);
        return ext switch
        {
            ".ifc" or ".ifczip" => $"« {name} » est un fichier IFC : l'import IFC n'est pas encore pris en charge. Exportez le modèle depuis Revit avec le complément StructCalc (Revit 2025), ou ouvrez le plan en fond de plan.",
            ".rvt" or ".rfa" => $"« {name} » est un fichier Revit : il ne s'ouvre pas directement. Dans Revit, utilisez le complément StructCalc > « Envoyer vers StructCalc ».",
            ".dwg" or ".dxf" or ".pdf" => $"« {name} » est un plan (fond de plan), pas un projet : utilisez « Importer un modèle » pour l'ajouter comme fond de plan.",
            ".obj" or ".stl" or ".fbx" or ".3ds" or ".skp" => $"« {name} » est un modèle 3D de géométrie : ce format n'est pas pris en charge (pas de barres ni de sections). Utilisez le complément Revit ou un projet StructCalc (.stcx).",
            _ => $"« {name} » : format « {(ext == "" ? "inconnu" : ext)} » non pris en charge. Formats acceptés : projet StructCalc (.stcx, .json)."
        };
    }

    /// <summary>Lit et contrôle un projet. progress reçoit une valeur de 0 à 1. Lève <see cref="InvalidDataException"/> (message clair) si le fichier n'est pas un projet valide.</summary>
    public static StructModel Read(string path, Action<double>? progress = null)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("Fichier introuvable : " + path);
        long len = new FileInfo(path).Length;
        if (len == 0) throw new InvalidDataException("Le fichier est vide.");
        using var ms = new MemoryStream();
        using (var fs = File.OpenRead(path))
        {
            var buf = new byte[65536]; int n;
            while ((n = fs.Read(buf, 0, buf.Length)) > 0) { ms.Write(buf, 0, n); progress?.Invoke(0.7 * ms.Length / len); }
        }
        ms.Position = 0;
        string text;
        using (var sr = new StreamReader(ms, Encoding.UTF8, true)) text = sr.ReadToEnd();
        progress?.Invoke(0.75);
        try
        {
            using var doc = JsonDocument.Parse(text);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object || !(root.TryGetProperty("Nodes", out _) || root.TryGetProperty("Members", out _)))
                throw new InvalidDataException("Ce fichier n'est pas un projet StructCalc (aucune structure reconnue).");
        }
        catch (JsonException) { throw new InvalidDataException("Ce fichier n'est pas un projet StructCalc valide : son contenu est illisible."); }
        progress?.Invoke(0.85);
        StructModel m;
        try { m = ModelIO.FromJson(text); }
        catch (JsonException ex) { throw new InvalidDataException("Le projet est endommagé ou créé par une version incompatible : " + ex.Message); }
        progress?.Invoke(1.0);
        return m;
    }

    /// <summary>Taille lisible : « 12 Ko », « 3,4 Mo ».</summary>
    public static string SizeText(long bytes)
    {
        var fr = System.Globalization.CultureInfo.GetCultureInfo("fr-FR");
        if (bytes < 1024) return bytes + " octets";
        if (bytes < 1024 * 1024) return (bytes / 1024.0).ToString("0.#", fr) + " Ko";
        if (bytes < 1024L * 1024 * 1024) return (bytes / 1048576.0).ToString("0.#", fr) + " Mo";
        return (bytes / 1073741824.0).ToString("0.##", fr) + " Go";
    }
}
