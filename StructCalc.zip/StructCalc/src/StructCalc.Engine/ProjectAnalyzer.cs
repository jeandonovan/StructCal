using StructCalc.Core;
using StructCalc.Core.Codes.RPA99;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine;

public sealed class AnalysisOutput
{
    public List<MemberDesignResult> Members { get; set; } = new();
    public List<DesignResult> Slabs { get; set; } = new();
    public List<DesignResult> Footings { get; set; } = new();
    /// <summary>Dalles maillées : flèche, moments, tranchants, armatures aux nœuds du maillage.</summary>
    public List<StructCalc.Engine.Structure.SlabField> SlabFields { get; set; } = new();
    /// <summary>Poinçonnement des dalles sur les poteaux qui les portent directement.</summary>
    public List<StructCalc.Engine.Structure.PunchingResult> Punching { get; set; } = new();
    /// <summary>Charges de planchers reçues par les voiles (zones d'influence des voiles).</summary>
    public List<StructCalc.Engine.Structure.WallLoadResult> WallLoads { get; set; } = new();
    public List<string> Messages { get; set; } = new();
    public int Iterations { get; set; }
    public GlobalResults? Global { get; set; }
    public string RcCode { get; set; } = "";
    public string SteelCode { get; set; } = "";
    public List<StructCalc.Engine.Stairs.StairResult> Stairs { get; set; } = new();
    public List<StructCalc.Engine.Structure.RaftResult> Rafts { get; set; } = new();
    public List<StructCalc.Engine.Walls.WallResult> Walls { get; set; } = new();
    public List<StructCalc.Engine.Floors.RibbedFloorResult> RibbedFloors { get; set; } = new();
    /// <summary>Magasin des résultats détaillés (cas, combinaisons, enveloppes ELU/ELS, réactions, déplacements) : base de l'explorateur de résultats et des diagrammes.</summary>
    public StructCalc.Engine.Results.ResultsStore? Store { get; set; }
    public List<ExtraDesign> Extras { get; set; } = new();     // escaliers, planchers à corps creux, fondations avec sol, voiles... (texte + quantités)
    public bool AllOk => Members.All(r => r.Ok || r.Skipped) && Slabs.All(s => s.Ok) && Footings.All(f => f.Ok) && Extras.All(x => x.Ok) && Punching.All(p => p.Ok);
}

/// <summary>Résultat d'un module de calcul complémentaire (escalier, plancher à corps creux, voile...) : rapport texte et quantités.</summary>
public sealed class ExtraDesign
{
    public string Title { get; set; } = "";
    public string Text { get; set; } = "";
    public bool Ok { get; set; } = true;
    public double ConcreteM3 { get; set; }
    public double SteelKg { get; set; }
    public double FormworkM2 { get; set; }
    /// <summary>Données structurées pour les échanges (ex. semelle : Kind, Name, ExternalId, A, B, H, NappeA, NappeB).</summary>
    public Dictionary<string, string> Data { get; } = new();
}

/// <summary>Pipeline complet : solveur EF -> séisme -> combinaisons -> dimensionnement (norme BA ou CM selon le matériau) -> optimisation des sections.</summary>
public static class ProjectAnalyzer
{
    public static AnalysisOutput Run(StructModel m, bool optimize = true, int maxIter = 8)
    {
        StructCalc.Core.Licensing.LicenseManager.Require(m.Members.Count);
        StructCalc.Engine.Structure.StoreyOps.SyncAllSlabLoads(m);       // charges des dalles à jour avec les poutres actuelles (zones d'influence)
        bool hasExtras = m.Stairs.Count > 0 || m.RibbedFloors.Count > 0 || m.FootingDefs.Count > 0 || m.Walls.Count > 0;
        if (m.Members.Count == 0 && m.Slabs.Count == 0 && m.Shells.Count == 0)
        {
            if (!hasExtras) throw new InvalidOperationException("Modèle vide.");
            var only = new AnalysisOutput();
            DesignExtras(m, only, GetRcCode(m, only));
            return only;
        }
        // profils par défaut des barres acier
        foreach (var mem in m.Members.Where(x => x.Kind == MaterialKind.Steel && string.IsNullOrWhiteSpace(x.Profile)))
            mem.Profile = mem.Type == MemberType.Column ? "HEA240" : "IPE300";

        AnalysisOutput output = new();
        var log = new List<string>();
        int it = 0;
        if (m.Members.Count > 0 || m.Shells.Count > 0)
        {
            for (; it < maxIter; it++)
            {
                output = AnalyzeOnce(m);
                if (!optimize || it == maxIter - 1) break;
                bool changed = false;
                foreach (var r in output.Members.Where(r => !r.Ok && !r.Skipped))
                {
                    var mem = m.Members.First(x => x.Id == r.MemberId);
                    string before = mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:F0}x{mem.H * 100:F0}";
                    if (Upsize(mem))
                    {
                        changed = true;
                        string after = mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:F0}x{mem.H * 100:F0} cm";
                        log.Add($"Itération {it + 1} : barre {mem.Id} {before} -> {after}");
                    }
                }
                if (!changed) break;
            }
        }
        output.Iterations = it + 1;
        output.Messages.InsertRange(0, log);
        if (m.Seismic.Enabled && !m.Seismic.UseModalPeriod && !m.Seismic.UseResponseSpectrum && m.Members.Count > 0)
        {
            try
            {
                var modal = ModalAnalysis.Compute(m, 8);
                if (modal.Modes.Count > 0)
                {
                    double zr = m.Nodes.Max(n => n.Z) - m.Nodes.Min(n => n.Z);
                    double tEmp = m.Seismic.Ct * Math.Pow(Math.Max(zr, 0.5), 0.75);
                    output.Extras.Add(new ExtraDesign
                    {
                        Title = "Analyse modale (information)",
                        Text = modal.Report + $"\nPériode empirique utilisée pour l'effort sismique : {tEmp:0.000} s ; période modale dominante : X = {modal.DominantPeriod(SeismicDirection.X):0.000} s, Y = {modal.DominantPeriod(SeismicDirection.Y):0.000} s." +
                               "\nPour utiliser la période modale dans le calcul : menu Calcul > « Séisme : période modale ».",
                        Ok = true
                    });
                }
            }
            catch { /* information seulement : une structure instable est déjà signalée par le calcul statique */ }
        }

        var rc = GetRcCode(m, output, quiet: true);
        if (rc != null)
        {
            foreach (var s in m.Slabs)
            {
                if (!StructCalc.Engine.Structure.SlabPresets.DesignedAsSolid(s.Kind)) continue;     // corps creux, alvéolée, mixte : charges et métré seulement
                var r = StructCalc.Engine.Structure.SlabMethods.Design(m, s, rc, ToInput(m, s));
                while (optimize && !r.Ok && s.H < 0.40)
                {
                    s.H = Math.Round(s.H + 0.01, 2);
                    r = StructCalc.Engine.Structure.SlabMethods.Design(m, s, rc, ToInput(m, s));
                }
                r.Element = $"Dalle {s.Name} ({s.Lx:F2} x {s.Ly:F2} m, h={s.H * 100:F0} cm)";
                output.Slabs.Add(r);
            }
        }
        if (m.Members.Count == 0) DesignExtras(m, output, rc);
        output.SlabFields = StructCalc.Engine.Structure.SlabFE.SolveAll(m);
        foreach (var sfld in output.SlabFields) StructCalc.Engine.Structure.SlabStress.Extend(sfld);
        output.Messages.AddRange(StructCalc.Engine.Structure.InfluenceZones.Check(m, output));
        try
        {
            output.WallLoads = StructCalc.Engine.Structure.WallInfluence.Compute(m);
            output.Punching = StructCalc.Engine.Structure.Punching.Check(m, output);
            if (output.Punching.Count > 0)
            {
                output.Messages.Add("Poinçonnement des dalles sur poteaux (appuis directs sans poutre) :");
                foreach (var pr in output.Punching) output.Messages.Add((pr.Ok ? "   " : "   ATTENTION ") + pr.Text);
            }
        }
        catch { }
        return output;
    }

    private static SlabInput ToInput(StructModel m, SlabPanel s) =>
        new(s.Lx, s.Ly, s.H, s.GExtra, s.Q, s.Continuity, m.Fc28, m.Fe, s.Crack, (s.CoverCm > 0 ? s.CoverCm : m.Settings.CoverSlabCm) / 100.0, m.Settings);

    internal static bool Upsize(Member mem)
    {
        if (mem.Kind == MaterialKind.Steel)
        {
            var next = SteelCatalog.Next(mem.Profile);
            if (next == null) return false;
            mem.Profile = next.Name;
            return true;
        }
        const double Max = 1.5;
        if (mem.Type == MemberType.Column)
        {
            if (mem.B >= Max && mem.H >= Max) return false;
            mem.B = Math.Min(Max, Math.Round(mem.B + 0.05, 2));
            mem.H = Math.Min(Max, Math.Round(mem.H + 0.05, 2));
            return true;
        }
        if (mem.H >= Max) return false;
        mem.H = Math.Round(mem.H + 0.05, 2);
        if (mem.H > 2.5 * mem.B) mem.B = Math.Round(mem.B + 0.05, 2);
        return true;
    }

    private static IReinforcedConcreteCode? GetRcCode(StructModel m, AnalysisOutput o, bool quiet = false)
    {
        IDesignCode code;
        try { code = DesignCodeRegistry.Get(m.RcCodeId); }
        catch { if (!quiet) o.Messages.Add($"Norme BA '{m.RcCodeId}' inconnue."); return null; }
        o.RcCode = code.DisplayName;
        if (!code.IsImplemented || code is not IReinforcedConcreteCode rc)
        {
            if (!quiet) o.Messages.Add($"Norme BA '{code.DisplayName}' non disponible : calcul BA impossible (choisissez une norme BA).");
            return null;
        }
        if (rc is Rpa99Code rpa) rpa.Zone = m.Seismic.Zone;
        return rc;
    }

    private static ISteelCode? GetSteelCode(StructModel m, AnalysisOutput o, bool quiet = false)
    {
        IDesignCode code;
        try { code = DesignCodeRegistry.Get(m.SteelCodeId); }
        catch { if (!quiet) o.Messages.Add($"Norme CM '{m.SteelCodeId}' inconnue."); return null; }
        o.SteelCode = code.DisplayName;
        if (!code.IsImplemented || code is not ISteelCode sc)
        {
            if (!quiet) o.Messages.Add($"Norme CM '{code.DisplayName}' non disponible : calcul acier impossible (choisissez une norme CM).");
            return null;
        }
        return sc;
    }

    private static AnalysisOutput AnalyzeOnce(StructModel m)
    {
        var o = new AnalysisOutput();
        var types = new HashSet<ActionType> { ActionType.G };
        foreach (var l in m.NodalLoads) types.Add(l.Case);
        foreach (var l in LoadExpander.MemberLoadsOf(m)) types.Add(l.Case);
        if (m.Shells.Any(sh => sh.Q != 0)) types.Add(ActionType.Q);
        var cases = new Dictionary<ActionType, CaseResult>();
        foreach (var t in types.Where(t => t != ActionType.E)) cases[t] = FrameSolver.Solve(m, t);

        var seismicLoads = new List<NodalLoad>();
        ModalResult? modalKeep = null;
        if (m.Seismic.Enabled)
        {
            double? tModal = null;
            if (m.Seismic.UseModalPeriod)
            {
                try
                {
                    var modal = ModalAnalysis.Compute(m, 8);
                    if (modal.Modes.Count > 0)
                    {
                        modalKeep = modal;
                        double tm = modal.DominantPeriod(m.Seismic.Direction);
                        double zrange = m.Nodes.Max(n => n.Z) - m.Nodes.Min(n => n.Z);
                        double tEmp = m.Seismic.Ct * Math.Pow(Math.Max(zrange, 0.5), 0.75);
                        bool isEc8 = m.Seismic.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase);
                        if (!isEc8 && tm > 1.3 * tEmp) tm = 1.3 * tEmp;       // RPA 99 art. 4.2.4
                        if (tm > 0) tModal = tm;
                        o.Extras.Add(new ExtraDesign { Title = "Analyse modale", Text = modal.Report + $"\nPériode retenue pour l'effort sismique : {tm:0.000} s (formule empirique : {tEmp:0.000} s)." , Ok = true });
                    }
                    else o.Messages.Add("Analyse modale non réalisée (" + modal.Note + ") : période empirique utilisée.");
                }
                catch (Exception ex) { o.Messages.Add("Analyse modale non réalisée : " + ex.Message + " Période empirique utilisée."); }
            }
            var seis = SeismicLoads.Compute(m, tModal);
            o.Messages.Add(seis.Info);
            bool spectral = false;
            if (m.Seismic.UseResponseSpectrum)
            {
                try
                {
                    var modalRs = ModalAnalysis.Compute(m, 15);
                    if (modalRs.Modes.Count > 0)
                    {
                        var rs = ResponseSpectrum.Compute(m, modalRs, SeismicLoads.Compute(m).BaseShear);
                        if (rs != null)
                        {
                            cases[ActionType.E] = rs.Case;
                            seismicLoads.AddRange(rs.NodalForces);
                            modalKeep = modalRs;
                            o.Extras.Add(new ExtraDesign { Title = "Analyse modale spectrale (CQC)", Text = rs.Report + "\n" + modalRs.Report, Ok = rs.MassRatio >= 0.9 });
                            o.Messages.Add($"Séisme : analyse modale spectrale, {rs.ModesUsed} mode(s), V = {rs.VFinal:0} kN (V statique : {rs.VStatic:0} kN).");
                            spectral = true;
                            try { var sc2 = StoreyChecks.Compute(m, rs.Case, rs.NodalForces); if (sc2 != null) o.Extras.Add(sc2); }
                            catch (Exception ex) { o.Messages.Add("Contrôle des déplacements inter-étages indisponible : " + ex.Message); }
                        }
                    }
                    else o.Messages.Add("Analyse modale spectrale non réalisée (" + modalRs.Note + ") : force statique équivalente utilisée.");
                }
                catch (Exception ex) { o.Messages.Add("Analyse modale spectrale non réalisée : " + ex.Message + " Force statique équivalente utilisée."); }
            }
            if (!spectral && seis.Loads.Count > 0)
            {
                cases[ActionType.E] = FrameSolver.Solve(m, ActionType.E, seis.Loads);
                seismicLoads.AddRange(seis.Loads);
                try { var sc = StoreyChecks.Compute(m, cases[ActionType.E], seis.Loads); if (sc != null) o.Extras.Add(sc); }
                catch (Exception ex) { o.Messages.Add("Contrôle des déplacements inter-étages indisponible : " + ex.Message); }
            }
        }
        else if (types.Contains(ActionType.E)) cases[ActionType.E] = FrameSolver.Solve(m, ActionType.E);

        var rc = GetRcCode(m, o);
        var cm = GetSteelCode(m, o);
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        foreach (var mem in m.Members)
        {
            double len = Dist(nodes[mem.NodeI], nodes[mem.NodeJ]);
            if (mem.Kind == MaterialKind.Steel)
            {
                if (cm != null)
                {
                    var mr = MemberDesigner.DesignSteel(m, mem, len, cm, cases);
                    MemberDesigner.FillEnvelope(mr, CombinationSet.For(m, cm.Combinations), cases, mem.Id);
                    o.Members.Add(mr);
                }
                else o.Members.Add(Skipped(mem, len, "Norme CM indisponible."));
            }
            else
            {
                if (rc != null)
                {
                    var mr = MemberDesigner.DesignRc(m, mem, len, rc, cases);
                    if (mem.CoverNomCm > 0)
                    {
                        // enrobage nominal : l'axe des barres = enrobage + cadre + demi-barre est connu une fois les barres choisies -> on recalcule avec la valeur réelle
                        for (int pass = 0; pass < 4 && !mr.Skipped && mr.StirDia > 0; pass++)
                        {
                            double actual = mem.CoverNomCm / 100.0 + mr.StirDia / 1000.0 + Math.Max(mr.BotDia, mem.Type == MemberType.Column ? 0 : mr.TopDia) / 2000.0;
                            if (Math.Abs(actual - mem.Cover) < 0.0015) break;
                            mem.Cover = actual;
                            mr = MemberDesigner.DesignRc(m, mem, len, rc, cases);
                        }
                        if (!mr.Skipped && mr.StirDia > 0)
                        {
                            double cNom = mem.CoverNomCm;
                            mr.Notes.Add($"Enrobage nominal {cNom:0.#} cm ; axe des barres d' = {mem.Cover * 100:0.0} cm (enrobage + cadre HA{mr.StirDia} + demi-barre) ; " +
                                         $"cadres : section extérieure {mem.B * 100 - 2 * cNom:0.#} x {mem.H * 100 - 2 * cNom:0.#} cm.");
                        }
                    }
                    MemberDesigner.FillEnvelope(mr, CombinationSet.For(m, rc.Combinations), cases, mem.Id);
                    o.Members.Add(mr);
                }
                else o.Members.Add(Skipped(mem, len, "Norme BA indisponible."));
            }
        }

        var codeCombos = rc?.Combinations ?? cm?.Combinations;
        var combosForGlobal = codeCombos == null ? null : CombinationSet.For(m, codeCombos);
        if (combosForGlobal != null)
        {
            try
            {
                o.Store = new StructCalc.Engine.Results.ResultsStore(m, cases, combosForGlobal.ToList());
                o.Store.SeismicLoads.AddRange(seismicLoads);
                o.Store.SetModal(modalKeep);
            }
            catch (Exception ex) { o.Messages.Add("Magasin de résultats indisponible : " + ex.Message); }
            try { o.Global = GlobalResultsBuilder.Build(m, combosForGlobal, cases); }
            catch (Exception ex) { o.Messages.Add("Résultats globaux indisponibles : " + ex.Message); }
            try { var shd = ShellDesigner.Compute(m, combosForGlobal, cases); if (shd != null) o.Extras.Add(shd); }
            catch (Exception ex) { o.Messages.Add("Dimensionnement des coques indisponible : " + ex.Message); }
            try { var con = ConsoleDesigner.Compute(m, o); if (con != null) o.Extras.Add(con); }
            catch (Exception ex) { o.Messages.Add("Calcul des consoles indisponible : " + ex.Message); }
            try { var stab = StabilityCheck.Compute(m, combosForGlobal, cases); if (stab != null) o.Extras.Add(stab); }
            catch (Exception ex) { o.Messages.Add("Contrôle de stabilité indisponible : " + ex.Message); }
            if (m.UseCustomCombos && m.CustomCombos.Count > 0) o.Messages.Add($"Combinaisons personnalisées utilisées ({m.CustomCombos.Count}) à la place de celles de la norme.");
        }

        if (rc != null && (m.SigmaSolKPa > 0 || m.Soil.Enabled))
        {
            foreach (var sup in m.Supports)
            {
                var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && x.Kind == MaterialKind.ReinforcedConcrete
                                                         && (x.NodeI == sup.NodeId || x.NodeJ == sup.NodeId));
                if (col == null) continue;
                var supNode = m.Nodes.FirstOrDefault(q => q.Id == sup.NodeId);
                if (supNode != null && m.Rafts.Any(rf => Math.Abs(supNode.Z - rf.ZTop) < 1.0 && StructCalc.Engine.Structure.RaftDesigner.Contains(rf, supNode.X, supNode.Y))) continue;     // charge reprise par le radier
                double nu = 0, ns = 0;
                foreach (var c in CombinationSet.For(m, rc.Combinations))
                {
                    double fz = 0;
                    foreach (var kv in c.Factors)
                        if (kv.Value != 0 && cases.TryGetValue(kv.Key, out var cr) && cr.Reactions.TryGetValue(sup.NodeId, out var rr))
                            fz += kv.Value * rr[2];
                    if (c.State == LimitState.ELS) ns = Math.Max(ns, fz); else nu = Math.Max(nu, fz);
                }
                if (nu <= 0) continue;
                DesignResult fr;
                var userDef = m.FootingDefs.FirstOrDefault(x => x.Name == $"S{sup.NodeId}" && x.Kind == FootingKind.Isolee);
                if (userDef != null)
                {
                    // la semelle définie dans l'assistant Sol et semelles gouverne : mêmes dimensions dans le plan, la 3D et les métrés
                    fr = StructCalc.Engine.Geotech.FootingSizer.Design(userDef, m.Soil, rc, m.Fc28, m.Fe, m.Settings.CoverFootingCm / 100.0, m.Settings).Design;
                    if (userDef.NuKN < nu * 0.98)
                        o.Messages.Add($"Semelle {userDef.Name} : la charge saisie dans l'assistant (Nu = {userDef.NuKN:0} kN) est inférieure à la réaction du calcul (Nu = {nu:0} kN) : mettez-la à jour dans l'assistant Sol et semelles.");
                }
                else if (m.Soil.Enabled)
                {
                    var fd = new FootingDef { Name = $"S{sup.NodeId}", ColA = col.B, ColB = col.H, NuKN = nu, NserKN = ns, Glacis = m.FootingGlacis, GlacisEdgeCm = m.FootingGlacisEdgeCm };
                    fr = StructCalc.Engine.Geotech.FootingSizer.Design(fd, m.Soil, rc, m.Fc28, m.Fe, m.Settings.CoverFootingCm / 100.0, m.Settings).Design;
                }
                else fr = rc.DesignIsolatedFooting(new FootingInput(col.B, col.H, nu, ns, m.SigmaSolKPa, m.Fc28, m.Fe, m.Settings.CoverFootingCm / 100.0));
                fr.Element = $"Semelle sous nœud {sup.NodeId} (Nu={nu:F0} kN, Nser={ns:F0} kN)";
                o.Footings.Add(fr);
            }
        }
        if (rc != null && m.Rafts.Count > 0)
        {
            try { DesignRafts(m, o, rc, cases); }
            catch (Exception ex) { o.Messages.Add("Radier : " + ex.Message); }
        }
        DesignExtras(m, o, rc);
        try { AdvancedChecks.Run(m, o, rc); } catch (Exception ex) { o.Messages.Add("Vérifications complémentaires : " + ex.Message); }
        return o;
    }

    /// <summary>Radiers : charges des poteaux (réactions d'appui) et des voiles posés dessus, puis vérification et ferraillage.</summary>
    private static void DesignRafts(StructModel m, AnalysisOutput o, IReinforcedConcreteCode rc, Dictionary<ActionType, CaseResult> cases)
    {
        foreach (var rf in m.Rafts)
        {
            var loads = new List<StructCalc.Engine.Structure.RaftLoad>();
            foreach (var sup in m.Supports)
            {
                var n = m.Nodes.FirstOrDefault(q => q.Id == sup.NodeId);
                if (n == null || Math.Abs(n.Z - rf.ZTop) >= 1.0 || !StructCalc.Engine.Structure.RaftDesigner.Contains(rf, n.X, n.Y)) continue;
                var col = m.Members.FirstOrDefault(x => x.Type == MemberType.Column && (x.NodeI == sup.NodeId || x.NodeJ == sup.NodeId));
                double nu = 0, ns = 0;
                foreach (var c in CombinationSet.For(m, rc.Combinations))
                {
                    double fz = 0;
                    foreach (var kv in c.Factors)
                        if (kv.Value != 0 && cases.TryGetValue(kv.Key, out var cr) && cr.Reactions.TryGetValue(sup.NodeId, out var rr)) fz += kv.Value * rr[2];
                    if (c.State == LimitState.ELS) ns = Math.Max(ns, fz); else nu = Math.Max(nu, fz);
                }
                if (nu <= 0) continue;
                bool swap = col != null && Math.Abs(Math.Sin(col.Roll * Math.PI / 180.0)) > 0.7;
                loads.Add(new StructCalc.Engine.Structure.RaftLoad { Name = "N" + sup.NodeId, X = n.X, Y = n.Y, Nu = nu, Ns = ns, Column = true,
                    A = col == null ? 0.3 : (swap ? col.H : col.B), B = col == null ? 0.3 : (swap ? col.B : col.H) });
            }
            foreach (var w in m.Walls)
            {
                if (Math.Abs(w.Z - rf.ZTop) >= 1.0) continue;
                double ca = Math.Cos(w.AngleDeg * Math.PI / 180), sa = Math.Sin(w.AngleDeg * Math.PI / 180);
                if (StructCalc.Engine.Structure.RaftDesigner.Contains(rf, w.X + w.LengthM / 2 * ca, w.Y + w.LengthM / 2 * sa))
                    loads.AddRange(StructCalc.Engine.Structure.RaftDesigner.WallLoads(w));
            }
            foreach (var ll in rf.LineLoads) loads.AddRange(StructCalc.Engine.Structure.RaftDesigner.LineLoadLoads(ll));
            var rr2 = StructCalc.Engine.Structure.RaftDesigner.Design(rf, loads, m.Soil, m.SigmaSolKPa, rc, m.Fc28, m.Fe, m.Settings);
            rr2.Design.Element = $"Radier {rf.Name} ({rf.Area:0.0} m², h={rf.H * 100:0} cm)";
            o.Rafts.Add(rr2);
            var fx = new ExtraDesign { Title = "Radier " + rf.Name, Text = rr2.Report, Ok = rr2.Ok, ConcreteM3 = rr2.ConcreteM3, SteelKg = rr2.SteelKg, FormworkM2 = 0 };
            fx.Data["Kind"] = "Raft"; fx.Data["Name"] = rf.Name; fx.Data["ExternalId"] = rf.ExternalId; fx.Data["Ok"] = rr2.Ok ? "OK" : "NON OK";
            foreach (var kv in rr2.Design.Texts) fx.Data[kv.Key] = kv.Value;
            o.Extras.Add(fx);
            if (!rr2.Ok) o.Messages.Add($"Radier {rf.Name} NON OK : " + string.Join(" ", rr2.Design.Warnings));
        }
    }


    /// <summary>Modules complémentaires : escaliers, planchers à corps creux (indépendants du solveur EF).</summary>
    private static void DesignExtras(StructModel m, AnalysisOutput o, IReinforcedConcreteCode? rc)
    {
        if (rc == null) return;
        foreach (var st in m.Stairs)
        {
            try
            {
                var sr = StructCalc.Engine.Stairs.StairDesigner.Design(st, rc, m.Fc28, m.Fe, m.Settings);
                o.Stairs.Add(sr);
                o.Extras.Add(new ExtraDesign { Title = "Escalier " + st.Name, Text = sr.Report, Ok = sr.Ok, ConcreteM3 = sr.ConcreteM3, SteelKg = sr.SteelKg, FormworkM2 = sr.FormworkM2 });
            }
            catch (Exception ex) { o.Messages.Add($"Escalier {st.Name} : {ex.Message}"); }
        }
        foreach (var fd in m.FootingDefs)
        {
            try
            {
                var fs = StructCalc.Engine.Geotech.FootingSizer.Design(fd, m.Soil, rc, m.Fc28, m.Fe, m.Settings.CoverFootingCm / 100.0, m.Settings);
                // une semelle Sn posée sous le nœud n est déjà comptée avec les semelles du modèle (pas de double comptage)
                bool counted = o.Footings.Any(x => "S" + StructCalc.Engine.Geometry.FootingPlacement.NodeIdOf(x.Element) == fd.Name);
                var fx = new ExtraDesign { Title = "Semelle " + fd.Name + (counted ? " (sous le nœud, comptée dans les semelles du modèle)" : ""), Text = fs.Report, Ok = fs.Ok, ConcreteM3 = counted ? 0 : fs.ConcreteM3, SteelKg = counted ? 0 : fs.SteelKg, FormworkM2 = 0 };
                if (!string.IsNullOrEmpty(fd.ExternalId) && fs.Design.Texts.ContainsKey("Nappe // A"))
                {
                    var ci = System.Globalization.CultureInfo.InvariantCulture;
                    fx.Data["Kind"] = "Footing"; fx.Data["Strip"] = fd.Kind == FootingKind.Filante ? "1" : "0"; fx.Data["Name"] = fd.Name; fx.Data["ExternalId"] = fd.ExternalId; fx.Data["Ok"] = fs.Ok ? "OK" : "NON OK";
                    fx.Data["A"] = fs.A.ToString(ci); fx.Data["B"] = fs.B.ToString(ci); fx.Data["H"] = fs.H.ToString(ci);
                    fx.Data["NappeA"] = fs.Design.Texts["Nappe // A"]; fx.Data["NappeB"] = fs.Design.Texts.GetValueOrDefault("Nappe // B", "");
                }
                o.Extras.Add(fx);
            }
            catch (Exception ex) { o.Messages.Add($"Semelle {fd.Name} : {ex.Message}"); }
        }
        foreach (var wd in m.Walls)
        {
            try
            {
                var wr = StructCalc.Engine.Walls.WallDesigner.Design(wd, rc, m.Fc28, m.Fe, m.Settings);
                o.Walls.Add(wr);
                o.Extras.Add(new ExtraDesign { Title = "Voile " + wd.Name, Text = wr.Report, Ok = wr.Ok, ConcreteM3 = wr.ConcreteM3, SteelKg = wr.SteelKg, FormworkM2 = wr.FormworkM2 });
            }
            catch (Exception ex) { o.Messages.Add($"Voile {wd.Name} : {ex.Message}"); }
        }
        foreach (var f in m.RibbedFloors)
        {
            try
            {
                var fr = StructCalc.Engine.Floors.RibbedFloorDesigner.Design(f, rc, m.Fc28, m.Fe, m.Settings);
                o.RibbedFloors.Add(fr);
                double area = (f.Spans.Sum()) * 1.0;     // par file de poutrelles : surface = L x entraxe
                double surf = f.Spans.Sum() * f.SpacingM;
                o.Extras.Add(new ExtraDesign { Title = "Plancher " + f.Name, Text = fr.Report, Ok = fr.Ok,
                    ConcreteM3 = fr.ConcreteM3PerM2 * surf, SteelKg = fr.SteelKgPerM * f.Spans.Sum(), FormworkM2 = surf });
                _ = area;
            }
            catch (Exception ex) { o.Messages.Add($"Plancher {f.Name} : {ex.Message}"); }
        }
    }

    private static MemberDesignResult Skipped(Member mem, double len, string why) => new()
    {
        MemberId = mem.Id, ExternalId = mem.ExternalId, Type = mem.Type, Kind = mem.Kind, B = mem.B, H = mem.H,
        Profile = mem.Profile, Length = len, Skipped = true, Warnings = { why }
    };

    private static double Dist(Node a, Node b) =>
        Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y) + (a.Z - b.Z) * (a.Z - b.Z));
}
