using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;

namespace StructCalc.Engine;

public enum IssueLevel { Info, Warning, Error }
/// <summary>Un message de vérification. <c>Code</c> identifie le type de problème et <c>Subject</c> / <c>Subject2</c> l'objet du modèle visé
/// (charge, dalle, coque, appui, liste de nœuds...), pour que l'interface sélectionne l'élément et propose des corrections fiables.</summary>
public sealed record ModelIssue(IssueLevel Level, string Message, int? NodeId = null, int? MemberId = null, string Code = "", object? Subject = null, object? Subject2 = null);

/// <summary>Vérification du modèle avant calcul : références, géométrie, sections, appuis, mécanismes, parties non appuyées.</summary>
public static class ModelChecker
{
    public static List<ModelIssue> Check(StructModel m)
    {
        var L = new List<ModelIssue>();
        foreach (var g in m.Nodes.GroupBy(n => n.Id).Where(g => g.Count() > 1))
            L.Add(new ModelIssue(IssueLevel.Error, $"Nœud {g.Key} défini {g.Count()} fois.", g.Key, null, "NODE_DUP"));
        foreach (var g in m.Members.GroupBy(n => n.Id).Where(g => g.Count() > 1))
            L.Add(new ModelIssue(IssueLevel.Error, $"Barre {g.Key} définie {g.Count()} fois.", null, g.Key, "MEM_DUP"));
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());

        var parent = nodes.Keys.ToDictionary(k => k, k => k);
        int Find(int a) { while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a]; } return a; }
        var used = new HashSet<int>();

        foreach (var mem in m.Members)
        {
            if (!nodes.ContainsKey(mem.NodeI) || !nodes.ContainsKey(mem.NodeJ))
            { L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : nœud inexistant ({mem.NodeI} - {mem.NodeJ}).", null, mem.Id, "MEM_NODE_MISSING")); continue; }
            if (mem.NodeI == mem.NodeJ) { L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : nœuds début et fin identiques.", null, mem.Id, "MEM_SAME_NODES")); continue; }
            var a = nodes[mem.NodeI]; var b = nodes[mem.NodeJ];
            double len = Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2) + Math.Pow(a.Z - b.Z, 2));
            if (len < 0.01) L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : longueur nulle ({len * 1000:0.#} mm).", null, mem.Id, "MEM_ZERO"));
            used.Add(mem.NodeI); used.Add(mem.NodeJ);
            parent[Find(mem.NodeI)] = Find(mem.NodeJ);
            if (mem.Kind == MaterialKind.ReinforcedConcrete)
            {
                if (mem.B <= 0 || mem.H <= 0) L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : section béton invalide (b={mem.B}, h={mem.H}).", null, mem.Id, "SEC_INVALID"));
                else if (mem.Cover >= mem.H / 2 || mem.Cover >= mem.B / 2)
                    L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : enrobage (axe des aciers) {mem.Cover * 100:0} cm trop grand pour la section.", null, mem.Id, "COVER_BIG"));
                if (len > 0 && mem.H > 0 && len / mem.H < 2 && mem.Type == MemberType.Beam)
                    L.Add(new ModelIssue(IssueLevel.Warning, $"Barre {mem.Id} : poutre très courte (L/h < 2) : modèle de poutre non valable (poutre-voile).", null, mem.Id, "BEAM_SHORT"));
            }
            else if (!string.IsNullOrWhiteSpace(mem.Profile) && !SteelCatalog.TryGet(mem.Profile, out _))
                L.Add(new ModelIssue(IssueLevel.Error, $"Barre {mem.Id} : profil acier inconnu '{mem.Profile}' (IPE, HEA, HEB disponibles).", null, mem.Id, "PROFILE_UNKNOWN"));
        }
        foreach (var l in m.MemberLoads.Where(l => m.Members.All(x => x.Id != l.MemberId)))
            L.Add(new ModelIssue(IssueLevel.Error, $"Charge répartie sur la barre inexistante {l.MemberId}.", null, null, "LOAD_MEM_MISSING", l));
        foreach (var l in m.MemberLoads)
        {
            var mem2 = m.Members.FirstOrDefault(x => x.Id == l.MemberId);
            if (mem2 == null || !nodes.TryGetValue(mem2.NodeI, out var na2) || !nodes.TryGetValue(mem2.NodeJ, out var nb2)) continue;
            double L2 = Math.Sqrt(Math.Pow(na2.X - nb2.X, 2) + Math.Pow(na2.Y - nb2.Y, 2) + Math.Pow(na2.Z - nb2.Z, 2));
            double ra = l.Relative ? l.A * L2 : l.A, rb = l.Relative ? l.B * L2 : l.B;
            if (l.Kind is MemberLoadKind.Point or MemberLoadKind.Moment && (ra < -1e-6 || ra > L2 + 1e-6))
                L.Add(new ModelIssue(IssueLevel.Error, $"Barre {l.MemberId} : charge ponctuelle à {ra:0.###} m, hors de la barre (longueur {L2:0.###} m).", null, l.MemberId, "LOAD_OUTSIDE", l));
            if (l.Kind == MemberLoadKind.Trapezoid)
            {
                if (ra < -1e-6 || rb > L2 + 1e-6 || ra > L2 + 1e-6 || rb < -1e-6)
                    L.Add(new ModelIssue(IssueLevel.Error, $"Barre {l.MemberId} : charge répartie de {ra:0.###} à {rb:0.###} m, hors de la barre (longueur {L2:0.###} m).", null, l.MemberId, "LOAD_TRAP_OUT", l, L2));
                else if (Math.Abs(rb - ra) < 1e-6)
                    L.Add(new ModelIssue(IssueLevel.Warning, $"Barre {l.MemberId} : charge répartie d'étendue nulle (ignorée).", null, l.MemberId, "LOAD_TRAP_ZERO", l));
            }
        }
        foreach (var sl in m.SurfaceLoads)
        {
            var ex = LoadExpander.Expand(m, sl);
            string nm = string.IsNullOrEmpty(sl.Name) ? "surfacique" : sl.Name;
            if (ex.TotalKn > 0 && ex.CarriedKn < 1e-9)
                L.Add(new ModelIssue(IssueLevel.Error, $"Charge {nm} ({sl.Q:0.##} kN/m²) : aucune poutre sur le contour du panneau, la charge n'est reportée nulle part.", null, null, "SURF_NOBEAM", sl));
            else if (ex.FreeEdges > 0 && ex.LoadedFraction >= 0.98)
            {
                var ownerSlab = m.Slabs.FirstOrDefault(d => sl.Name == d.Name + "-G" || sl.Name == d.Name + "-Q" || sl.Name.StartsWith(d.Name + "-G#") || sl.Name.StartsWith(d.Name + "-Q#"));
                bool console = ownerSlab != null && StructCalc.Engine.Structure.SlabCells.Of(m, ownerSlab).Any(c =>
                    ConsoleDesigner.IsConsoleCell(m, ownerSlab, c, out _) && Math.Abs(c.X0 - Math.Min(sl.X0, sl.X1)) < 0.01 && Math.Abs(c.Y0 - Math.Min(sl.Y0, sl.Y1)) < 0.01);
                if (console)
                    L.Add(new ModelIssue(IssueLevel.Warning, $"Charge {nm} : console ({ex.FreeEdges} bords libres, un seul bord porté par une poutre). La flexion (chapeaux), le tranchant, la flèche et l'ancrage de la console sont calculés automatiquement (onglet « Dalles / Semelles / Alertes ») ; vérifiez la torsion de la poutre d'appui. Si une poutre de rive est prévue, ajoutez-la : clic droit sur ce message.", null, null, "SURF_FREE_EDGES", sl));
                else
                    L.Add(new ModelIssue(IssueLevel.Warning, $"Charge {nm} : {ex.FreeEdges} bord(s) sans poutre (console / porte-à-faux, ou poutre oubliée) ; leur charge est reportée sur les bords portés par une poutre. Clic droit sur ce message : créer les poutres de rive manquantes.", null, null, "SURF_FREE_EDGES", sl));
            }
            else if (ex.LoadedFraction < 0.98)
                L.Add(new ModelIssue(IssueLevel.Warning, $"Charge {nm} : seulement {ex.LoadedFraction * 100:0} % de la charge est reportée sur des poutres (bord non porté ou poutre incomplète).", null, null, "SURF_PARTIAL", sl));
        }
        foreach (var l in m.NodalLoads.Where(l => !nodes.ContainsKey(l.NodeId)))
            L.Add(new ModelIssue(IssueLevel.Error, $"Charge nodale sur le nœud inexistant {l.NodeId}.", l.NodeId, null, "NLOAD_NODE", l));
        foreach (var s in m.Supports.Where(s => !nodes.ContainsKey(s.NodeId)))
            L.Add(new ModelIssue(IssueLevel.Error, $"Appui sur le nœud inexistant {s.NodeId}.", s.NodeId, null, "SUPPORT_NODE", s));

        // coques : nœuds existants, épaisseur ; elles relient les nœuds comme des barres (stabilité et appuis)
        foreach (var sh in m.Shells)
        {
            var sids = new[] { sh.N1, sh.N2, sh.N3, sh.N4 };
            if (sids.Any(q => !nodes.ContainsKey(q)))
            { L.Add(new ModelIssue(IssueLevel.Error, $"Coque {sh.Id} ({sh.Name}) : nœud inexistant.", null, null, "SHELL_NODE", sh)); continue; }
            foreach (int sid in sids) used.Add(sid);
            for (int k = 1; k < 4; k++) parent[Find(sids[k])] = Find(sids[0]);
            if (sh.T < 0.05) L.Add(new ModelIssue(IssueLevel.Warning, $"Coque {sh.Id} ({sh.Name}) : épaisseur très faible ({sh.T * 100:0.#} cm).", null, null, "SHELL_THIN", sh));
        }

        // appuis et mécanismes
        if (m.Members.Count > 0 || m.Shells.Count > 0)
        {
            if (m.Supports.Count == 0) L.Add(new ModelIssue(IssueLevel.Error, "Aucun appui : la structure n'est pas retenue (ajoutez des appuis avec l'outil Appui).", null, null, "NO_SUPPORT"));
            int fixedDof = m.Supports.Sum(s => (s.Ux ? 1 : 0) + (s.Uy ? 1 : 0) + (s.Uz ? 1 : 0) + (s.Rx ? 1 : 0) + (s.Ry ? 1 : 0) + (s.Rz ? 1 : 0));
            if (m.Supports.Count > 0 && fixedDof < 6)
                L.Add(new ModelIssue(IssueLevel.Error, $"Mécanisme probable : {fixedDof} degrés de liberté bloqués, au moins 6 sont nécessaires pour une structure 3D stable.", null, null, "MECHANISM"));
            var supported = new HashSet<int>(m.Supports.Where(s => nodes.ContainsKey(s.NodeId)).Select(s => Find(s.NodeId)));
            foreach (var comp in used.Where(n => nodes.ContainsKey(n)).GroupBy(Find).Where(g => !supported.Contains(g.Key)))
                L.Add(new ModelIssue(IssueLevel.Error, $"Partie de structure non appuyée (nœuds {string.Join(", ", comp.Take(6))}{(comp.Count() > 6 ? "..." : "")}) : reliez-la à un appui.", comp.First(), null, "UNSUPPORTED", comp.ToArray()));
        }
        foreach (var n in nodes.Values.Where(n => !used.Contains(n.Id) && (m.Members.Count > 0 || m.Shells.Count > 0)))
            L.Add(new ModelIssue(IssueLevel.Warning, $"Nœud {n.Id} isolé (aucune barre).", n.Id, null, "NODE_ISOLATED"));

        if (nodes.Count <= 1500)
        {
            var arr = nodes.Values.ToList();
            for (int i = 0; i < arr.Count; i++)
                for (int j = i + 1; j < arr.Count; j++)
                    if (Math.Abs(arr[i].X - arr[j].X) < 1e-3 && Math.Abs(arr[i].Y - arr[j].Y) < 1e-3 && Math.Abs(arr[i].Z - arr[j].Z) < 1e-3)
                        L.Add(new ModelIssue(IssueLevel.Warning, $"Nœuds {arr[i].Id} et {arr[j].Id} superposés : non reliés entre eux.", arr[i].Id, null, "NODE_OVERLAP", arr[j].Id));
        }

        if (m.Members.Count > 0 && m.MemberLoads.Count == 0 && m.NodalLoads.Count == 0 && m.SurfaceLoads.Count == 0 && !m.IncludeSelfWeight)
            L.Add(new ModelIssue(IssueLevel.Warning, "Aucune charge définie.", null, null, "NO_LOAD"));
        foreach (var s in m.Slabs)
        {
            if (s.Lx <= 0 || s.Ly <= 0 || s.H <= 0) L.Add(new ModelIssue(IssueLevel.Error, $"Dalle {s.Name} : dimensions invalides.", null, null, "SLAB_DIM", s));
            else if (s.H < 0.10) L.Add(new ModelIssue(IssueLevel.Warning, $"Dalle {s.Name} : épaisseur < 10 cm.", null, null, "SLAB_THIN", s));
            if (s.Placed && s.Lx > 0 && s.Ly > 0)
            {
                var sn = StructCalc.Engine.Structure.SlabSnap.Extent(m, s);
                double dmax = Math.Max(Math.Max(Math.Abs(sn.X0 - s.X0), Math.Abs(sn.X1 - (s.X0 + s.Lx))), Math.Max(Math.Abs(sn.Y0 - s.Y0), Math.Abs(sn.Y1 - (s.Y0 + s.Ly))));
                if (dmax > 0.005)
                    L.Add(new ModelIssue(IssueLevel.Info, $"Dalle {s.Name} : bords sur les faces des poutres (écart max. {dmax * 100:0.#} cm par rapport aux axes) ; ses charges sont reportées sur les axes des poutres.", null, null, "SLAB_EDGE", s));
            }
        }
        // zones d'influence superposées : une même surface chargée deux fois fausse toute la descente de charges
        var placed = m.Slabs.Where(s => s.Placed && s.Lx > 0 && s.Ly > 0).ToList();
        for (int i = 0; i < placed.Count; i++)
            for (int j = i + 1; j < placed.Count; j++)
            {
                var a = placed[i]; var b = placed[j];
                if (Math.Abs(a.Z - b.Z) > 2e-3) continue;
                double ox = Math.Min(a.X0 + a.Lx, b.X0 + b.Lx) - Math.Max(a.X0, b.X0), oy = Math.Min(a.Y0 + a.Ly, b.Y0 + b.Ly) - Math.Max(a.Y0, b.Y0);
                if (ox > 0.01 && oy > 0.01)
                    L.Add(new ModelIssue(IssueLevel.Error, $"Dalles {a.Name} et {b.Name} superposées ({ox:0.00} x {oy:0.00} m) au même niveau : la charge serait comptée deux fois. Supprimez ou redimensionnez l'une d'elles.", null, null, "SLAB_OVERLAP", a, b));
            }
        var gen = new HashSet<string>(m.Slabs.Where(s => s.Placed).SelectMany(s => m.SurfaceLoads.Where(l => l.Name == s.Name + "-G" || l.Name == s.Name + "-Q" || l.Name.StartsWith(s.Name + "-G#") || l.Name.StartsWith(s.Name + "-Q#")).Select(l => l.Name)));
        var sloads = m.SurfaceLoads.ToList();
        for (int i = 0; i < sloads.Count; i++)
            for (int j = i + 1; j < sloads.Count; j++)
            {
                var a = sloads[i]; var b = sloads[j];
                if (a.Case != b.Case || Math.Abs(a.Z - b.Z) > 2e-3) continue;
                if (gen.Contains(a.Name) && gen.Contains(b.Name)) continue;           // panneaux de dalles : déjà contrôlés ci-dessus
                double ox = Math.Min(Math.Max(a.X0, a.X1), Math.Max(b.X0, b.X1)) - Math.Max(Math.Min(a.X0, a.X1), Math.Min(b.X0, b.X1));
                double oy = Math.Min(Math.Max(a.Y0, a.Y1), Math.Max(b.Y0, b.Y1)) - Math.Max(Math.Min(a.Y0, a.Y1), Math.Min(b.Y0, b.Y1));
                if (ox > 0.01 && oy > 0.01)
                    L.Add(new ModelIssue(IssueLevel.Warning, $"Charges surfaciques « {a.Name} » et « {b.Name} » (cas {a.Case}) se recouvrent sur {ox:0.00} x {oy:0.00} m : vérifiez qu'elles ne comptent pas deux fois la même surface (dalle + charge manuelle ou plancher).", null, null, "SURF_OVERLAP", a, b));
            }
        return L;
    }
}
