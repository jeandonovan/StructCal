using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Efforts de coque au centre de l'élément, dans le repère local (e1, e2, n). Nx, Ny, Nxy en kN/m ; Mx, My, Mxy en kN.m/m ; Qx, Qy en kN/m.
/// Convention de flexion : un moment positif tend la face +n (côté de la normale).</summary>
public sealed class ShellForces
{
    public double Nx, Ny, Nxy, Mx, My, Mxy, Qx, Qy;
    public double[] E1 = new double[3], E2 = new double[3], Nrm = new double[3];

    public static ShellForces Combine(IEnumerable<(double F, ShellForces S)> parts)
    {
        var r = new ShellForces();
        bool first = true;
        foreach (var (f, s) in parts)
        {
            if (f == 0) continue;
            if (first) { r.E1 = (double[])s.E1.Clone(); r.E2 = (double[])s.E2.Clone(); r.Nrm = (double[])s.Nrm.Clone(); first = false; }
            r.Nx += f * s.Nx; r.Ny += f * s.Ny; r.Nxy += f * s.Nxy; r.Mx += f * s.Mx; r.My += f * s.My; r.Mxy += f * s.Mxy; r.Qx += f * s.Qx; r.Qy += f * s.Qy;
        }
        return r;
    }
}

internal sealed class ShellGeo
{
    public double[,] R = new double[3, 3];          // lignes : e1, e2, n (composantes globales)
    public double[] X = new double[4], Y = new double[4];
    public double Area;
    public double ProjectedZ;                        // |n_z| x aire : surface projetée horizontale
}

/// <summary>Coque plane à 4 nœuds, quadrilatère quelconque : membrane Q4 à modes incompatibles (Wilson-Taylor) + plaque de Mindlin MITC4 (Bathe-Dvorkin)
/// + rigidité de perçage (rotation autour de la normale) faible. Les formules ont été validées contre la plaque de Navier et une console courte (Timoshenko).</summary>
public static class ShellFem
{
    public const double Nu = 0.2;
    private const double Ks = 5.0 / 6.0;
    private const double DrillFactor = 1e-3;
    private static readonly double Gp = 1.0 / Math.Sqrt(3.0);
    private static readonly int[] SR = { -1, 1, 1, -1 };
    private static readonly int[] SS = { -1, -1, 1, 1 };

    private static double[] Sub(double[] a, double[] b) => new[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] };
    private static double[] Cross(double[] a, double[] b) => new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
    private static double Dot(double[] a, double[] b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    private static double[] Unit(double[] a) { double l = Math.Sqrt(Dot(a, a)); return l < 1e-12 ? new double[] { 1, 0, 0 } : new[] { a[0] / l, a[1] / l, a[2] / l }; }
    private static double[] P(Node n) => new[] { n.X, n.Y, n.Z };

    internal static ShellGeo Geometry(Node n1, Node n2, Node n3, Node n4)
    {
        var p = new[] { P(n1), P(n2), P(n3), P(n4) };
        var e1 = Unit(new[] { (p[1][0] - p[0][0]) + (p[2][0] - p[3][0]), (p[1][1] - p[0][1]) + (p[2][1] - p[3][1]), (p[1][2] - p[0][2]) + (p[2][2] - p[3][2]) });
        var nrm = Unit(Cross(Sub(p[2], p[0]), Sub(p[3], p[1])));
        var e2 = Unit(Cross(nrm, e1));
        e1 = Unit(Cross(e2, nrm));                      // repère strictement orthonormé
        var g = new ShellGeo();
        for (int c = 0; c < 3; c++) { g.R[0, c] = e1[c]; g.R[1, c] = e2[c]; g.R[2, c] = nrm[c]; }
        var cen = new[] { (p[0][0] + p[1][0] + p[2][0] + p[3][0]) / 4, (p[0][1] + p[1][1] + p[2][1] + p[3][1]) / 4, (p[0][2] + p[1][2] + p[2][2] + p[3][2]) / 4 };
        for (int i = 0; i < 4; i++) { var d = Sub(p[i], cen); g.X[i] = Dot(d, e1); g.Y[i] = Dot(d, e2); }
        // aire : demi-somme des produits en croix des diagonales
        g.Area = 0.5 * Math.Abs((g.X[2] - g.X[0]) * (g.Y[3] - g.Y[1]) - (g.X[3] - g.X[1]) * (g.Y[2] - g.Y[0]));
        g.ProjectedZ = g.Area * Math.Abs(nrm[2]);
        return g;
    }

    // ------------------------------------------------------------------ fonctions de forme
    private static void Shape(double r, double s, double[] N, double[] dr, double[] ds)
    {
        for (int i = 0; i < 4; i++)
        {
            N[i] = 0.25 * (1 + SR[i] * r) * (1 + SS[i] * s);
            dr[i] = 0.25 * SR[i] * (1 + SS[i] * s);
            ds[i] = 0.25 * SS[i] * (1 + SR[i] * r);
        }
    }

    private static void Jac(ShellGeo g, double r, double s, double[] N, double[] dr, double[] ds, double[,] J, out double det)
    {
        Shape(r, s, N, dr, ds);
        double a = 0, b = 0, c = 0, d = 0;
        for (int i = 0; i < 4; i++) { a += dr[i] * g.X[i]; b += dr[i] * g.Y[i]; c += ds[i] * g.X[i]; d += ds[i] * g.Y[i]; }
        J[0, 0] = a; J[0, 1] = b; J[1, 0] = c; J[1, 1] = d;
        det = a * d - b * c;
    }

    /// <summary>Gradient des fonctions de forme dans le repère local : dNx[0,i] = dN/dx, dNx[1,i] = dN/dy.</summary>
    private static void Grad(double[,] J, double det, double[] dr, double[] ds, double[,] dNx)
    {
        double i00 = J[1, 1] / det, i01 = -J[0, 1] / det, i10 = -J[1, 0] / det, i11 = J[0, 0] / det;
        for (int i = 0; i < 4; i++)
        {
            dNx[0, i] = i00 * dr[i] + i01 * ds[i];
            dNx[1, i] = i10 * dr[i] + i11 * ds[i];
        }
    }

    private static readonly (double R, double S)[] GaussPts = { (-Gp, -Gp), (Gp, -Gp), (Gp, Gp), (-Gp, Gp) };

    // ------------------------------------------------------------------ rigidité locale 24 x 24 (ddl du nœud i : 6i + u, v, w, thx, thy, thz)
    internal static double[,] LocalStiffness(ShellGeo g, double E, double t)
    {
        var K = new double[24, 24];
        double nu = Nu;
        double cm = E * t / (1 - nu * nu);
        double[,] Dm = { { cm, cm * nu, 0 }, { cm * nu, cm, 0 }, { 0, 0, cm * (1 - nu) / 2 } };
        double cb = E * t * t * t / (12 * (1 - nu * nu));
        double[,] Db = { { cb, cb * nu, 0 }, { cb * nu, cb, 0 }, { 0, 0, cb * (1 - nu) / 2 } };
        double gs = Ks * E / (2 * (1 + nu)) * t;

        var N = new double[4]; var dr = new double[4]; var ds = new double[4];
        var J = new double[2, 2]; var dNx = new double[2, 4];

        // ---- membrane Q4 + modes incompatibles
        var J0 = new double[2, 2];
        Jac(g, 0, 0, N, dr, ds, J0, out double det0);
        double j0i00 = J0[1, 1] / det0, j0i01 = -J0[0, 1] / det0, j0i10 = -J0[1, 0] / det0, j0i11 = J0[0, 0] / det0;
        var Kuu = new double[8, 8]; var Kua = new double[8, 4]; var Kaa = new double[4, 4];
        foreach (var (r, s) in GaussPts)
        {
            Jac(g, r, s, N, dr, ds, J, out double det);
            Grad(J, det, dr, ds, dNx);
            var B = new double[3, 8];
            for (int i = 0; i < 4; i++)
            {
                B[0, 2 * i] = dNx[0, i]; B[1, 2 * i + 1] = dNx[1, i];
                B[2, 2 * i] = dNx[1, i]; B[2, 2 * i + 1] = dNx[0, i];
            }
            var Bi = new double[3, 4];
            for (int k = 0; k < 2; k++)
            {
                double a = k == 0 ? -2 * r : 0, b = k == 0 ? 0 : -2 * s;
                double g0 = (j0i00 * a + j0i01 * b) * det0 / det, g1 = (j0i10 * a + j0i11 * b) * det0 / det;
                Bi[0, 2 * k] = g0; Bi[1, 2 * k + 1] = g1; Bi[2, 2 * k] = g1; Bi[2, 2 * k + 1] = g0;
            }
            AddBtDB(Kuu, B, 8, Dm, B, 8, det);
            AddBtDB(Kua, B, 8, Dm, Bi, 4, det);
            AddBtDB(Kaa, Bi, 4, Dm, Bi, 4, det);
        }
        // Km = Kuu - Kua Kaa^-1 Kua^T
        var Kau = new double[4, 8];
        for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) Kau[i, j] = Kua[j, i];
        var X = SolveMulti(Kaa, Kau, 4, 8);
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8; j++)
            {
                double v = Kuu[i, j];
                for (int k = 0; k < 4; k++) v -= Kua[i, k] * X[k, j];
                int ni = i / 2, ci = i % 2, nj = j / 2, cj = j % 2;
                K[6 * ni + ci, 6 * nj + cj] += v;
            }

        // ---- plaque de Mindlin MITC4 (ddl : w, thx, thy)
        var tie = new double[4][][];                     // points A(0,1) B(-1,0) C(0,-1) D(1,0) : [gr, gs] (12 composantes chacun)
        var tr = new (double R, double S)[] { (0, 1), (-1, 0), (0, -1), (1, 0) };
        for (int q = 0; q < 4; q++)
        {
            Jac(g, tr[q].R, tr[q].S, N, dr, ds, J, out _);
            var gr = new double[12]; var gsv = new double[12];
            for (int i = 0; i < 4; i++)
            {
                gr[3 * i] = dr[i]; gr[3 * i + 1] = -N[i] * J[0, 1]; gr[3 * i + 2] = N[i] * J[0, 0];
                gsv[3 * i] = ds[i]; gsv[3 * i + 1] = -N[i] * J[1, 1]; gsv[3 * i + 2] = N[i] * J[1, 0];
            }
            tie[q] = new[] { gr, gsv };
        }
        var Kp = new double[12, 12];
        foreach (var (r, s) in GaussPts)
        {
            Jac(g, r, s, N, dr, ds, J, out double det);
            Grad(J, det, dr, ds, dNx);
            var Bb = new double[3, 12];
            for (int i = 0; i < 4; i++)
            {
                Bb[0, 3 * i + 2] = dNx[0, i];
                Bb[1, 3 * i + 1] = -dNx[1, i];
                Bb[2, 3 * i + 2] = dNx[1, i]; Bb[2, 3 * i + 1] = -dNx[0, i];
            }
            AddBtDB(Kp, Bb, 12, Db, Bb, 12, det);
            var Bs = ShearB(J, det, r, s, tie);
            for (int i = 0; i < 12; i++)
                for (int j = 0; j < 12; j++)
                    Kp[i, j] += gs * det * (Bs[0, i] * Bs[0, j] + Bs[1, i] * Bs[1, j]);
        }
        for (int i = 0; i < 12; i++)
            for (int j = 0; j < 12; j++)
                K[6 * (i / 3) + 2 + i % 3, 6 * (j / 3) + 2 + j % 3] += Kp[i, j];

        // ---- rigidité de perçage
        double kd = DrillFactor * E * t * g.Area / 4;
        for (int i = 0; i < 4; i++) K[6 * i + 5, 6 * i + 5] += kd;
        return K;
    }

    private static double[,] ShearB(double[,] J, double det, double r, double s, double[][][] tie)
    {
        var grv = new double[12]; var gsv = new double[12];
        for (int i = 0; i < 12; i++)
        {
            grv[i] = 0.5 * (1 + s) * tie[0][0][i] + 0.5 * (1 - s) * tie[2][0][i];     // A et C
            gsv[i] = 0.5 * (1 + r) * tie[3][1][i] + 0.5 * (1 - r) * tie[1][1][i];     // D et B
        }
        double i00 = J[1, 1] / det, i01 = -J[0, 1] / det, i10 = -J[1, 0] / det, i11 = J[0, 0] / det;
        var Bs = new double[2, 12];
        for (int i = 0; i < 12; i++)
        {
            Bs[0, i] = i00 * grv[i] + i01 * gsv[i];
            Bs[1, i] = i10 * grv[i] + i11 * gsv[i];
        }
        return Bs;
    }

    /// <summary>C += Bl^T D Br * w   (D 3x3 ; Bl : 3 x nl ; Br : 3 x nr).</summary>
    private static void AddBtDB(double[,] C, double[,] Bl, int nl, double[,] D, double[,] Br, int nr, double w)
    {
        var DB = new double[3, nr];
        for (int a = 0; a < 3; a++) for (int j = 0; j < nr; j++) { double s = 0; for (int k = 0; k < 3; k++) s += D[a, k] * Br[k, j]; DB[a, j] = s; }
        for (int i = 0; i < nl; i++)
            for (int j = 0; j < nr; j++)
            {
                double s = 0;
                for (int a = 0; a < 3; a++) s += Bl[a, i] * DB[a, j];
                C[i, j] += s * w;
            }
    }

    /// <summary>Résout A X = B (A n x n, B n x m) par élimination de Gauss avec pivot partiel.</summary>
    private static double[,] SolveMulti(double[,] A0, double[,] B0, int n, int m)
    {
        var a = (double[,])A0.Clone(); var b = (double[,])B0.Clone();
        for (int c = 0; c < n; c++)
        {
            int p = c;
            for (int r = c + 1; r < n; r++) if (Math.Abs(a[r, c]) > Math.Abs(a[p, c])) p = r;
            if (Math.Abs(a[p, c]) < 1e-300) throw new InvalidOperationException("Élément de coque dégénéré (surface nulle).");
            if (p != c)
            {
                for (int k = 0; k < n; k++) (a[c, k], a[p, k]) = (a[p, k], a[c, k]);
                for (int k = 0; k < m; k++) (b[c, k], b[p, k]) = (b[p, k], b[c, k]);
            }
            for (int r = c + 1; r < n; r++)
            {
                double f = a[r, c] / a[c, c];
                if (f == 0) continue;
                for (int k = c; k < n; k++) a[r, k] -= f * a[c, k];
                for (int k = 0; k < m; k++) b[r, k] -= f * b[c, k];
            }
        }
        var x = new double[n, m];
        for (int k = 0; k < m; k++)
            for (int r = n - 1; r >= 0; r--)
            {
                double s = b[r, k];
                for (int c = r + 1; c < n; c++) s -= a[r, c] * x[c, k];
                x[r, k] = s / a[r, r];
            }
        return x;
    }

    /// <summary>Rigidité globale 24 x 24 = T^T K T, T = diag(R, R, ...) (8 blocs 3x3 : translations et rotations de chaque nœud).</summary>
    internal static double[,] GlobalStiffness(ShellGeo g, double E, double t)
    {
        var kl = LocalStiffness(g, E, t);
        var tmp = new double[24, 24];
        // tmp = kl * T
        for (int i = 0; i < 24; i++)
            for (int blk = 0; blk < 8; blk++)
                for (int c = 0; c < 3; c++)
                {
                    double s = 0;
                    for (int k = 0; k < 3; k++) s += kl[i, 3 * blk + k] * g.R[k, c];
                    tmp[i, 3 * blk + c] = s;
                }
        var kg = new double[24, 24];
        // kg = T^T * tmp
        for (int j = 0; j < 24; j++)
            for (int blk = 0; blk < 8; blk++)
                for (int c = 0; c < 3; c++)
                {
                    double s = 0;
                    for (int k = 0; k < 3; k++) s += g.R[k, c] * tmp[3 * blk + k, j];
                    kg[3 * blk + c, j] = s;
                }
        return kg;
    }

    /// <summary>Efforts au centre à partir des déplacements globaux des 4 nœuds (24 valeurs).</summary>
    internal static ShellForces Recover(ShellGeo g, double E, double t, double[] ug)
    {
        var ul = new double[24];
        for (int blk = 0; blk < 8; blk++)
            for (int a = 0; a < 3; a++)
            {
                double s = 0;
                for (int k = 0; k < 3; k++) s += g.R[a, k] * ug[3 * blk + k];
                ul[3 * blk + a] = s;
            }
        double nu = Nu;
        var N = new double[4]; var dr = new double[4]; var ds = new double[4];
        var J = new double[2, 2]; var dNx = new double[2, 4];
        Jac(g, 0, 0, N, dr, ds, J, out double det);
        Grad(J, det, dr, ds, dNx);

        double ex = 0, ey = 0, gxy = 0, kx = 0, ky = 0, kxy = 0;
        for (int i = 0; i < 4; i++)
        {
            double u = ul[6 * i], v = ul[6 * i + 1], thx = ul[6 * i + 3], thy = ul[6 * i + 4];
            ex += dNx[0, i] * u; ey += dNx[1, i] * v; gxy += dNx[1, i] * u + dNx[0, i] * v;
            kx += dNx[0, i] * thy; ky += -dNx[1, i] * thx; kxy += dNx[1, i] * thy - dNx[0, i] * thx;
        }
        double cm = E * t / (1 - nu * nu), cb = E * t * t * t / (12 * (1 - nu * nu));
        var f = new ShellForces
        {
            Nx = cm * (ex + nu * ey), Ny = cm * (nu * ex + ey), Nxy = cm * (1 - nu) / 2 * gxy,
            Mx = cb * (kx + nu * ky), My = cb * (nu * kx + ky), Mxy = cb * (1 - nu) / 2 * kxy
        };

        // cisaillement transverse (MITC au centre)
        var tr = new (double R, double S)[] { (0, 1), (-1, 0), (0, -1), (1, 0) };
        var tie = new double[4][][];
        for (int q = 0; q < 4; q++)
        {
            var Jq = new double[2, 2];
            Jac(g, tr[q].R, tr[q].S, N, dr, ds, Jq, out _);
            var gr = new double[12]; var gsv = new double[12];
            for (int i = 0; i < 4; i++)
            {
                gr[3 * i] = dr[i]; gr[3 * i + 1] = -N[i] * Jq[0, 1]; gr[3 * i + 2] = N[i] * Jq[0, 0];
                gsv[3 * i] = ds[i]; gsv[3 * i + 1] = -N[i] * Jq[1, 1]; gsv[3 * i + 2] = N[i] * Jq[1, 0];
            }
            tie[q] = new[] { gr, gsv };
        }
        Jac(g, 0, 0, N, dr, ds, J, out det);
        var Bs = ShearB(J, det, 0, 0, tie);
        var pl = new double[12];
        for (int i = 0; i < 4; i++) { pl[3 * i] = ul[6 * i + 2]; pl[3 * i + 1] = ul[6 * i + 3]; pl[3 * i + 2] = ul[6 * i + 4]; }
        double gx = 0, gy = 0;
        for (int i = 0; i < 12; i++) { gx += Bs[0, i] * pl[i]; gy += Bs[1, i] * pl[i]; }
        double gsh = Ks * E / (2 * (1 + nu)) * t;
        f.Qx = gsh * gx; f.Qy = gsh * gy;
        for (int c = 0; c < 3; c++) { f.E1[c] = g.R[0, c]; f.E2[c] = g.R[1, c]; f.Nrm[c] = g.R[2, c]; }
        return f;
    }

    // ------------------------------------------------------------------ charges et poids
    public static double UnitWeight => 25.0;

    /// <summary>Poids (kN) à chaque nœud : poids propre, charge permanente supplémentaire et psi x charge d'exploitation, réparti par quart sur les 4 nœuds.</summary>
    public static Dictionary<int, double> NodalWeights(StructModel m, double psi)
    {
        var w = new Dictionary<int, double>();
        if (m.Shells.Count == 0) return w;
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(x => x.Key, x => x.First());
        foreach (var s in m.Shells)
        {
            if (!nodes.TryGetValue(s.N1, out var a) || !nodes.TryGetValue(s.N2, out var b) || !nodes.TryGetValue(s.N3, out var c) || !nodes.TryGetValue(s.N4, out var d)) continue;
            var g = Geometry(a, b, c, d);
            double q = (m.IncludeSelfWeight ? UnitWeight * s.T : 0) + s.GExtra + psi * s.Q;
            double wk = q * g.Area / 4;
            foreach (int id in new[] { s.N1, s.N2, s.N3, s.N4 }) w[id] = (w.TryGetValue(id, out var v) ? v : 0) + wk;
        }
        return w;
    }

    /// <summary>Charges nodales équivalentes (repère global, 24 valeurs) d'un cas : poids propre et permanentes (G), exploitation (Q), vers le bas.</summary>
    internal static double[] EquivalentLoad(StructModel m, ShellPanel s, ShellGeo g, ActionType c)
    {
        var f = new double[24];
        double p = 0;
        if (c == ActionType.G) p = (m.IncludeSelfWeight ? UnitWeight * s.T * g.Area : 0) + s.GExtra * g.ProjectedZ;
        else if (c == ActionType.Q) p = s.Q * g.ProjectedZ;
        if (p == 0) return f;
        for (int i = 0; i < 4; i++) f[6 * i + 2] = -p / 4;
        return f;
    }
}
