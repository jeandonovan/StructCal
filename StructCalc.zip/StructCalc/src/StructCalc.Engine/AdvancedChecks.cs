using System.Text;
using System.Text.RegularExpressions;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Vérifications complémentaires exécutées après le dimensionnement : flèche calculée (BAEL B.6.5), ouverture des fissures (EC2 7.3.4),
/// longueurs d'ancrage et de recouvrement, barres qui tiennent dans la section, poteau fort / poutre faible, tassements différentiels,
/// stabilité (glissement, renversement) des murs de soutènement. Les résultats sont ajoutés aux notes / avertissements des barres et à une rubrique « Vérifications complémentaires ».</summary>
public static class AdvancedChecks
{
    const double Es = 200000.0, N = 15.0;

    public static void Run(StructModel m, AnalysisOutput o, IReinforcedConcreteCode? rc = null)
    {
        var rep = new StringBuilder();
        bool allOk = true;
        double fc = m.Fc28, fe = m.Fe, ft28 = 0.6 + 0.06 * fc;
        double ei = 11000.0 * Math.Cbrt(fc);      // MPa, module instantané
        var byId = m.Members.ToDictionary(x => x.Id);
        foreach (var r in o.Members)
        {
            if (r.Skipped || r.Kind != MaterialKind.ReinforcedConcrete || !byId.TryGetValue(r.MemberId, out var mem)) continue;
            try
            {
                if (r.Type == MemberType.Beam) allOk &= CheckBeam(m, r, mem, fc, fe, ft28, ei, rep);
                else allOk &= CheckColumn(r, fc, fe, ft28, rep);
            }
            catch (Exception ex) { o.Messages.Add($"Vérifications complémentaires (barre {r.MemberId}) : {ex.Message}"); }
        }
        try { CheckAnchorageIntoColumns(m, o, byId, fc, fe, ft28, rep); } catch (Exception ex) { o.Messages.Add("Ancrages : " + ex.Message); }
        if (m.Seismic.Enabled)
        {
            try { CheckStrongColumn(m, o, byId, fe, fc, rep); } catch (Exception ex) { o.Messages.Add("Poteau fort / poutre faible : " + ex.Message); }
        }
        try { CheckSlabDeflections(m, o, rep); } catch (Exception ex) { o.Messages.Add("Flèche des dalles : " + ex.Message); }
        try { allOk &= CheckDifferentialSettlement(m, o, rep); } catch (Exception ex) { o.Messages.Add("Tassements différentiels : " + ex.Message); }
        try { allOk &= CheckRetainingWalls(m, o, rep); } catch (Exception ex) { o.Messages.Add("Murs de soutènement : " + ex.Message); }

        if (rc != null && m.Settings.SlabCompareMethods)
        {
            try
            {
                var solid = m.Slabs.Where(sp => StructCalc.Engine.Structure.SlabPresets.DesignedAsSolid(sp.Kind) && sp.CalcMode != SlabCalcMode.MassOnly && sp.Lx > 0.3 && sp.Ly > 0.3).Take(12).ToList();
                if (solid.Count > 0)
                {
                    var cmp = new StringBuilder();
                    foreach (var sp in solid) cmp.AppendLine(StructCalc.Engine.Structure.SlabMethods.Compare(m, sp, rc, solid.Count <= 6));
                    o.Extras.Add(new ExtraDesign { Title = "Dalles : comparaison des méthodes de calcul", Text = cmp.ToString(), Ok = true });
                }
            }
            catch (Exception ex) { o.Messages.Add("Comparaison des méthodes de dalle : " + ex.Message); }
        }
        if (rep.Length == 0) return;
        var ex2 = new ExtraDesign { Title = "Vérifications complémentaires", Ok = allOk };
        ex2.Text = "VÉRIFICATIONS COMPLÉMENTAIRES (flèche, fissuration, ancrages, dispositions, fondations)\n" + rep +
            "\nHypothèses : moment de service ≈ moment ultime / 1,4 ; flèche selon le mode choisi dans l'assistant (Maillage et flèches : BAEL B.6.5,2 Ifi/Ifv ou EC2 7.4.3) ; fissuration selon EC2 7.3.4 (combinaison quasi permanente) ; " +
            "ancrage ls = φ fe / (4 τs), τs = 0,6 ψs² ft28, ψs = 1,5. Ces contrôles complètent le dimensionnement et ne le remplacent pas : à confirmer par l'ingénieur.";
        ex2.Data["Kind"] = "Checks";
        o.Extras.Add(ex2);
    }

    // ------------------------------------------------------------------ poutres
    static bool CheckBeam(StructModel m, MemberDesignResult r, Member mem, double fc, double fe, double ft28, double ei, StringBuilder rep)
    {
        bool ok = true;
        double b = r.B > 0 ? r.B : mem.B, h = r.H > 0 ? r.H : mem.H, L = r.Length;
        double c = r.CoverM > 0 ? r.CoverM : mem.Cover, d = h - c;
        if (L <= 0.5 || d <= 0) return true;
        bool cant = r.Cantilever;
        // zone tendue de référence : travée (armatures basses) ou console (armatures hautes)
        double asT = (cant ? r.AsTop : r.AsBottom) * 1e-4, asC = (cant ? r.AsBottom : r.AsTop) * 1e-4;
        double mu = cant ? Math.Abs(r.MuHog) : Math.Abs(r.MuSag), me = cant ? 0 : Math.Abs(r.MuHog);
        if (asT <= 0 || mu <= 0) return true;

        // ---- flèche : mode choisi dans l'assistant de configuration (Maillage et flèches)
        var cfg = m.Settings;
        bool ec2Code = m.RcCodeId.StartsWith("EC", StringComparison.OrdinalIgnoreCase);
        string mode = DeflMode(cfg, ec2Code, r.ForfaitaireSatisfied);
        if (mode != "Forfaitaire" && mode != "Aucune")
        {
            double Mser = mu / 1.4, Meser = me / 1.4, perm = Math.Clamp(cfg.DeflectionPermanentShare, 0.0, 1.0);
            double wB = 0, wE = 0;
            if (mode == "CalcBael" || mode == "CalcMax") wB = DeflBael(b, h, d, c, asT, asC, L, cant, Mser, Meser, perm, ft28, ei);
            if (mode == "CalcEc2" || mode == "CalcMax") wE = DeflEc2(b, h, d, c, asT, asC, L, cant, Mser, Meser, perm, fc, cfg.CreepPhi);
            double w = Math.Max(wB, wE);
            string how = mode == "CalcBael" ? "BAEL B.6.5,2" : mode == "CalcEc2" ? "EC2 7.4.3" : $"BAEL {wB * 1000:0.0} mm / EC2 {wE * 1000:0.0} mm, la plus défavorable";
            double lim = DeflLimit(cant ? 2 * L : L, cfg, ec2Code);
            string ver = w <= lim ? "OK" : "NON OK";
            r.Notes.Add($"Flèche calculée ({how}, long terme) = {w * 1000:0.0} mm, limite {lim * 1000:0.0} mm : {ver}.");
            rep.AppendLine($"Barre {r.MemberId} (poutre {b * 100:0}×{h * 100:0}, L = {L:0.00} m) : flèche {w * 1000:0.0} mm / {lim * 1000:0.0} mm ({how}) {ver}.");
            if (w > lim)
            {
                r.Warnings.Add($"Flèche calculée {w * 1000:0.0} mm > {lim * 1000:0.0} mm : augmenter la hauteur ou les armatures, ou prévoir une contre-flèche.");
                r.Ok = false; ok = false;
            }
        }

        // ---- ouverture des fissures wk (EC2 7.3.4), combinaison quasi permanente ≈ 0,7 M service
        double wkLim = mem.Crack == CrackingClass.PeuPrejudiciable ? 0.4 : mem.Crack == CrackingClass.Prejudiciable ? 0.3 : 0.2;
        double wkSag = CrackWidth(b, h, d, c, r.AsBottom * 1e-4, r.AsTop * 1e-4, r.BotDia, r.StirDia, mem, fc, Math.Abs(r.MuSag) / 1.4 * 0.7);
        double wkHog = CrackWidth(b, h, d, c, r.AsTop * 1e-4, r.AsBottom * 1e-4, r.TopDia, r.StirDia, mem, fc, Math.Abs(r.MuHog) / 1.4 * 0.7);
        double wk = Math.Max(wkSag, wkHog);
        if (wk > 0)
        {
            string v2 = wk <= wkLim ? "OK" : "NON OK";
            r.Notes.Add($"Fissuration EC2 7.3.4 : wk = {wk:0.00} mm (travée {wkSag:0.00} / appui {wkHog:0.00}), limite {wkLim:0.0} mm : {v2}.");
            rep.AppendLine($"Barre {r.MemberId} : ouverture des fissures wk = {wk:0.00} mm / {wkLim:0.0} mm {v2}.");
            if (wk > wkLim) { r.Warnings.Add($"Ouverture des fissures wk = {wk:0.00} mm > {wkLim:0.0} mm : réduire le diamètre des barres, augmenter leur nombre ou l'enrobage de calcul."); r.Ok = false; ok = false; }
        }

        // ---- barres qui tiennent dans la largeur
        double cn = (mem.CoverNomCm > 0 ? mem.CoverNomCm : 2.5) / 100.0, stir = r.StirDia / 1000.0;
        double avail = b - 2 * (cn + stir);
        foreach (var (n, dia, nom) in new[] { (r.BotN, r.BotDia, "inférieures"), (r.TopN, r.TopDia, "supérieures") })
        {
            if (n <= 0 || dia <= 0) continue;
            double phi = dia / 1000.0, sMin = Math.Max(phi, 0.03);
            int perLayer = (int)Math.Floor((avail + sMin) / (phi + sMin) + 1e-9);
            if (perLayer < 1) perLayer = 1;
            if (n > perLayer)
            {
                if (n <= 2 * perLayer) r.Warnings.Add($"{n}HA{dia} {nom} : {perLayer} barres au plus par lit dans b = {b * 100:0} cm (enrobage, cadre, espacement ≥ {sMin * 100:0.0} cm) : prévoir 2 lits et vérifier d.");
                else { r.Warnings.Add($"{n}HA{dia} {nom} ne tiennent pas dans b = {b * 100:0} cm (2 lits = {2 * perLayer} barres au plus) : élargir la poutre ou passer à un diamètre supérieur."); r.Ok = false; ok = false; }
            }
        }
        // ---- cadres
        double phiMin = Math.Min(r.BotDia > 0 ? r.BotDia : 99, r.TopDia > 0 ? r.TopDia : 99);
        double phiMax = Math.Min(Math.Min(h * 1000 / 35.0, phiMin), b * 1000 / 10.0);
        if (r.StirDia > 0 && phiMax < 90 && r.StirDia > phiMax + 0.5)
            r.Warnings.Add($"Cadre HA{r.StirDia} supérieur à min(h/35 ; φl ; b/10) = {phiMax:0.#} mm (BAEL A.7.2,2) : prendre un cadre plus petit.");
        if (r.StirSpacingCm > 0 && r.StirSpacingCm > Math.Min(0.9 * d * 100, 40) + 0.01)
            r.Warnings.Add($"Espacement des cadres {r.StirSpacingCm:0} cm > min(0,9 d ; 40 cm) = {Math.Min(0.9 * d * 100, 40):0} cm.");
        AddLaps(r, fe, ft28);
        return ok;
    }

    // ------------------------------------------------------------------ flèches
    /// <summary>Mode de vérification de flèche effectif (Auto et ForfPuisCalc résolus).</summary>
    public static string DeflMode(DesignSettings cfg, bool ec2Code, bool forfOk)
    {
        string mode = string.IsNullOrEmpty(cfg.DeflectionMethod) ? "Auto" : cfg.DeflectionMethod;
        if (mode == "Auto") return ec2Code ? "CalcEc2" : "CalcBael";
        if (mode == "ForfPuisCalc") return forfOk ? "Forfaitaire" : (ec2Code ? "CalcEc2" : "CalcBael");
        return mode;
    }

    /// <summary>Limite de flèche (m) pour une portée de référence L (m ; 2 L pour une console).</summary>
    public static double DeflLimit(double L, DesignSettings cfg, bool ec2Code)
    {
        switch (cfg.DeflectionLimitMode)
        {
            case "EC2": return L / 250.0;
            case "L500": return L / 500.0;
            case "Manuel": return L / Math.Max(cfg.DeflectionManualDenominator, 1.0);
            default: return ec2Code ? L / 250.0 : (L <= 5.0 ? L / 500.0 : 0.005 + L / 1000.0);
        }
    }

    /// <summary>Coefficient k·M·L²/(E I) : poutre sur appuis avec moments d'extrémité (w = L²(5 Mt - Me)/(48 E I)), console (M L²/(4 E I)).</summary>
    static double Kdefl(bool cant, double Mc, double Me, double L) => cant ? Mc * L * L / 4.0 : Math.Max(5 * Mc - Me, 0.5 * Mc) * L * L / 48.0;

    /// <summary>Flèche à long terme (m) selon BAEL B.6.5,2 : w = wv(permanent) + wi(total) - wi(permanent), avec Ifi et Ifv.</summary>
    static double DeflBael(double b, double h, double d, double c, double asT, double asC, double L, bool cant, double Mser, double Meser, double perm, double ft28, double ei)
    {
        double f(double M, double Mend, bool longTerm)
        {
            double Mc = Math.Max(M, 1e-6);
            double a2 = b / 2, a1 = N * (asT + asC), a0 = -N * (asC * c + asT * d);
            double x = (-a1 + Math.Sqrt(a1 * a1 - 4 * a2 * a0)) / (2 * a2);
            double z = d - x / 3;
            double sigS = Mc / (asT * z) / 1000.0;                       // MPa
            double delta = asT / (b * d);
            double lamI = 0.05 * ft28 / (delta * (2 + 3.0));              // b0 = b
            double lam = longTerm ? 0.4 * lamI : lamI;
            double muF = Math.Max(0, 1 - 1.75 * ft28 / (4 * delta * sigS + ft28));
            double I0 = b * h * h * h / 12 + N * asT * Math.Pow(d - h / 2, 2) + N * asC * Math.Pow(h / 2 - c, 2);
            double If = 1.1 * I0 / (1 + lam * muF);
            double E = (longTerm ? ei / 3.0 : ei) * 1000.0;               // kN/m²
            return Kdefl(cant, Mc, Mend, L) / (E * If);
        }
        return f(Mser * perm, Meser * perm, true) + (f(Mser, Meser, false) - f(Mser * perm, Meser * perm, false));
    }

    /// <summary>Flèche à long terme (m) selon EC2 7.4.3 : w = ζ wII + (1 - ζ) wI sous charges quasi permanentes, module efficace Ecm/(1+φ).</summary>
    static double DeflEc2(double b, double h, double d, double c, double asT, double asC, double L, bool cant, double Mser, double Meser, double perm, double fc, double phi)
    {
        double fcm = fc + 8, ecm = 22000.0 * Math.Pow(fcm / 10.0, 0.3), eEff = ecm / (1 + Math.Max(phi, 0)), ae = Es / eEff;
        double fctm = 0.3 * Math.Pow(fc, 2.0 / 3.0);
        double a2 = b / 2, a1 = ae * (asT + asC), a0 = -ae * (asC * c + asT * d);
        double x = (-a1 + Math.Sqrt(a1 * a1 - 4 * a2 * a0)) / (2 * a2);
        double I2 = b * x * x * x / 3 + ae * asT * Math.Pow(d - x, 2) + ae * asC * Math.Pow(x - c, 2);
        double I1 = b * h * h * h / 12 + ae * asT * Math.Pow(d - h / 2, 2) + ae * asC * Math.Pow(h / 2 - c, 2);
        double M = Mser * perm, Me = Meser * perm, Mcr = fctm * 1000.0 * (b * h * h / 6.0);
        double zeta = M > Mcr ? 1 - 0.5 * Math.Pow(Mcr / M, 2) : 0.0;
        double E = eEff * 1000.0;
        double k = Kdefl(cant, Math.Max(M, 1e-6), Me, L);
        return zeta * k / (E * I2) + (1 - zeta) * k / (E * I1);
    }

    /// <summary>Flèche des dalles : estimation à long terme à partir de la flèche élastique du maillage (non fissurée, module instantané),
    /// multipliée par (1 + φ × part permanente) × 1,25 (fissuration).</summary>
    static bool CheckSlabDeflections(StructModel m, AnalysisOutput o, StringBuilder rep)
    {
        var cfg = m.Settings;
        bool ec2Code = m.RcCodeId.StartsWith("EC", StringComparison.OrdinalIgnoreCase);
        string mode = string.IsNullOrEmpty(cfg.DeflectionMethod) ? "Auto" : cfg.DeflectionMethod;
        if (mode == "Forfaitaire" || mode == "Aucune" || o.SlabFields.Count == 0) return true;
        double kappa = (1 + Math.Max(cfg.CreepPhi, 0) * Math.Clamp(cfg.DeflectionPermanentShare, 0, 1)) * 1.25;
        double worstRatio = 0; string worst = ""; bool ok = true;
        foreach (var f in o.SlabFields)
        {
            var (_, wmax) = f.Range(StructCalc.Engine.Structure.SlabFieldKind.Deflection);
            if (wmax <= 0 || f.Span <= 0) continue;
            double wLt = wmax * kappa, lim = DeflLimit(f.Span, cfg, ec2Code) * 1000.0, ratio = wLt / lim;
            if (ratio > worstRatio) { worstRatio = ratio; worst = $"dalle {f.Name} : {wLt:0.0} mm / {lim:0.0} mm"; }
            if (ratio > 1.0) { ok = false; o.Messages.Add($"Dalle {f.Name} : flèche à long terme estimée {wLt:0.0} mm > {lim:0.0} mm (flèche élastique {wmax:0.0} mm × {kappa:0.0}) : augmenter l'épaisseur."); }
        }
        if (worstRatio > 0) rep.AppendLine($"Flèche des dalles (estimation à long terme, facteur {kappa:0.0} sur la flèche élastique) : la plus défavorable {worst} {(ok ? "OK" : "NON OK")}.");
        return ok;
    }

    /// <summary>Ouverture de fissure EC2 7.3.4 (mm) pour une zone tendue d'aire At (m²) ; M = moment quasi permanent (kN.m). 0 si non fissurée.</summary>
    static double CrackWidth(double b, double h, double d, double cAxe, double At, double Ac, int dia, int stirDia, Member mem, double fc, double M)
    {
        if (At <= 0 || dia <= 0 || M <= 0) return 0;
        double fcm = fc + 8, ecm = 22000.0 * Math.Pow(fcm / 10.0, 0.3);   // MPa
        double ae = Es / ecm, fctm = 0.3 * Math.Pow(fc, 2.0 / 3.0);
        double a2 = b / 2, a1 = ae * (At + Ac), a0 = -ae * (Ac * cAxe + At * d);
        double x = (-a1 + Math.Sqrt(a1 * a1 - 4 * a2 * a0)) / (2 * a2);
        double Icr = b * x * x * x / 3 + ae * At * Math.Pow(d - x, 2) + ae * Ac * Math.Pow(x - cAxe, 2);
        double Mcr = fctm * 1000.0 * (b * h * h / 6.0);                    // kN.m (section brute, approx.)
        if (M < Mcr * 0.999) return 0;
        double sigS = ae * M / Icr * (d - x) / 1000.0;                       // MPa
        double hceff = Math.Min(Math.Min(2.5 * (h - d), (h - x) / 3.0), h / 2.0);
        double rho = At / (b * hceff);
        double phi = dia, cNom = (mem.CoverNomCm > 0 ? mem.CoverNomCm * 10.0 : 25.0);   // mm, à la face du cadre
        double cBar = cNom + stirDia;                                           // enrobage de la barre longitudinale
        double srmax = 3.4 * cBar + 0.425 * 0.8 * 0.5 * phi / rho;
        double eps = Math.Max(0.6 * sigS / Es, (sigS - 0.4 * fctm / rho * (1 + ae * rho)) / Es);
        return srmax * eps;
    }

    // ------------------------------------------------------------------ poteaux
    static bool CheckColumn(MemberDesignResult r, double fc, double fe, double ft28, StringBuilder rep)
    {
        bool ok = true;
        double ac = r.B * r.H;
        if (ac <= 0 || r.AsTop <= 0) return true;
        double rho = r.AsTop * 1e-4 / ac * 100.0;
        rep.AppendLine($"Barre {r.MemberId} (poteau {r.B * 100:0}×{r.H * 100:0}) : taux d'armatures {rho:0.00} % (0,2 % à 4 %).");
        if (rho < 0.2 - 1e-9) r.Warnings.Add($"Taux d'armatures {rho:0.00} % < 0,2 % de la section.");
        if (rho > 4.0 + 1e-9) { r.Warnings.Add($"Taux d'armatures {rho:0.0} % > 4 % de la section : élargir le poteau (zone de recouvrement > 6 % interdite)."); r.Ok = false; ok = false; }
        double phiL = r.TopDia > 0 ? r.TopDia : (r.BotDia > 0 ? r.BotDia : 0);
        if (phiL > 0 && r.StirSpacingCm > 0)
        {
            double a = Math.Min(r.B, r.H) * 100.0;
            double stMax = Math.Min(Math.Min(a + 10, 40), 15 * phiL / 10.0);
            if (r.StirSpacingCm > stMax + 0.01) r.Warnings.Add($"Espacement des cadres {r.StirSpacingCm:0} cm > min(a+10 ; 40 ; 15 φl) = {stMax:0} cm (BAEL A.8.1,3).");
            if (r.StirDia > 0 && r.StirDia < phiL / 3.0 - 0.01) r.Warnings.Add($"Cadre HA{r.StirDia} < φl/3 = {phiL / 3:0.#} mm.");
        }
        AddLaps(r, fe, ft28);
        return ok;
    }

    static double Ls(double dia, double fe, double ft28) => dia / 1000.0 * fe / (4.0 * 0.6 * 1.5 * 1.5 * ft28);

    static void AddLaps(MemberDesignResult r, double fe, double ft28)
    {
        int dia = Math.Max(r.BotDia, r.TopDia);
        if (dia <= 0) return;
        double ls = Ls(dia, fe, ft28);
        r.Notes.Add($"Ancrage droit ls = {ls * 100:0} cm (HA{dia}) ; crochet normal ≈ {0.4 * ls * 100:0} cm ; recouvrement lr ≈ {ls * 100:0} cm (≥ {0.6 * ls * 100:0} cm si barres jointives en zone comprimée).");
    }

    // ------------------------------------------------------------------ ancrage des poutres dans les poteaux d'extrémité
    static void CheckAnchorageIntoColumns(StructModel m, AnalysisOutput o, Dictionary<int, Member> byId, double fc, double fe, double ft28, StringBuilder rep)
    {
        var nodes = m.Nodes.ToDictionary(x => x.Id);
        foreach (var r in o.Members)
        {
            if (r.Skipped || r.Type != MemberType.Beam || r.Kind != MaterialKind.ReinforcedConcrete || !byId.TryGetValue(r.MemberId, out var bm)) continue;
            int dia = Math.Max(r.BotDia, r.TopDia);
            if (dia <= 0 || !nodes.TryGetValue(bm.NodeI, out var ni) || !nodes.TryGetValue(bm.NodeJ, out var nj)) continue;
            double dx = nj.X - ni.X, dy = nj.Y - ni.Y, len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 1e-6) continue;
            double ux = dx / len, uy = dy / len, ls = Ls(dia, fe, ft28);
            foreach (int nid in new[] { bm.NodeI, bm.NodeJ })
            {
                // extrémité libre de poutre prolongeante ? (aucune autre poutre colinéaire au nœud)
                bool continues = m.Members.Any(o2 => o2.Id != bm.Id && o2.Type == MemberType.Beam && (o2.NodeI == nid || o2.NodeJ == nid) && ContinuesBeam(nodes, o2, nid, ux, uy));
                if (continues) continue;
                var col = m.Members.FirstOrDefault(o2 => o2.Type == MemberType.Column && (o2.NodeI == nid || o2.NodeJ == nid));
                if (col == null) continue;
                double dim = Math.Abs(ux) * col.B + Math.Abs(uy) * col.H;      // dimension du poteau selon la poutre
                double room = dim - 0.04;                                       // moins l'enrobage du poteau
                double need = 0.4 * ls;
                if (need > room + 1e-9)
                    r.Warnings.Add($"Ancrage en extrémité (nœud {nid}) : crochet {need * 100:0} cm (0,4 ls, HA{dia}) > {room * 100:0} cm disponibles dans le poteau : élargir le poteau, réduire le diamètre ou prévoir des barres en U.");
                else
                    r.Notes.Add($"Ancrage en extrémité (nœud {nid}) : crochet {need * 100:0} cm ≤ {room * 100:0} cm disponibles dans le poteau : OK.");
            }
        }
    }

    static bool ContinuesBeam(Dictionary<int, Node> nodes, Member o2, int nid, double ux, double uy)
    {
        int other = o2.NodeI == nid ? o2.NodeJ : o2.NodeI;
        if (!nodes.TryGetValue(nid, out var a) || !nodes.TryGetValue(other, out var b)) return false;
        double dx = b.X - a.X, dy = b.Y - a.Y, l = Math.Sqrt(dx * dx + dy * dy);
        if (l < 1e-6) return false;
        return Math.Abs((dx * ux + dy * uy) / l) > 0.9;
    }

    // ------------------------------------------------------------------ poteau fort / poutre faible
    static void CheckStrongColumn(StructModel m, AnalysisOutput o, Dictionary<int, Member> byId, double fe, double fc, StringBuilder rep)
    {
        var nodes = m.Nodes.ToDictionary(x => x.Id);
        var res = o.Members.Where(x => !x.Skipped && x.Kind == MaterialKind.ReinforcedConcrete).ToDictionary(x => x.MemberId);
        double fyd = fe * 1000.0 / 1.15, fcd = fc * 1000.0 / 1.5;
        int bad = 0, tested = 0;
        foreach (var nd in m.Nodes)
        {
            var cols = m.Members.Where(c => c.Type == MemberType.Column && (c.NodeI == nd.Id || c.NodeJ == nd.Id) && res.ContainsKey(c.Id)).ToList();
            if (cols.Count < 2) continue;                                         // pas de nœud courant (tête de poteau)
            var beams = m.Members.Where(c => c.Type == MemberType.Beam && (c.NodeI == nd.Id || c.NodeJ == nd.Id) && res.ContainsKey(c.Id)).ToList();
            if (beams.Count == 0) continue;
            foreach (bool dirX in new[] { true, false })
            {
                double sumB = 0; int nb = 0;
                foreach (var bm in beams)
                {
                    int other = bm.NodeI == nd.Id ? bm.NodeJ : bm.NodeI;
                    if (!nodes.TryGetValue(other, out var q)) continue;
                    double dx = q.X - nd.X, dy = q.Y - nd.Y;
                    if (dirX ? Math.Abs(dx) < Math.Abs(dy) : Math.Abs(dy) <= Math.Abs(dx)) continue;
                    var rr = res[bm.Id];
                    double dd = (rr.H > 0 ? rr.H : bm.H) - (rr.CoverM > 0 ? rr.CoverM : bm.Cover);
                    sumB += Math.Max(rr.AsTop, rr.AsBottom) * 1e-4 * fyd * 0.9 * dd; nb++;
                }
                if (nb == 0) continue;
                double sumC = 0;
                foreach (var cm in cols)
                {
                    var rr = res[cm.Id];
                    double D = dirX ? cm.B : cm.H, W = dirX ? cm.H : cm.B;       // dimension dans le plan de flexion / perpendiculaire (poteau vertical : B // X)
                    double cv = rr.CoverM > 0 ? rr.CoverM : cm.Cover;
                    double mr = rr.AsTop * 1e-4 / 2 * fyd * Math.Max(D - 2 * cv, 0.05);
                    double n = Math.Min(rr.NuMax, 0.5 * fcd * D * W);
                    mr += Math.Max(0, n * (D / 2 - n / (2 * 0.85 * fcd * W)));
                    sumC += mr;
                }
                tested++;
                if (sumC < 1.25 * sumB)
                {
                    bad++;
                    foreach (var cm in cols) res[cm.Id].Warnings.Add($"Poteau fort / poutre faible non vérifié au nœud {nd.Id} (sens {(dirX ? "X" : "Y")}) : ΣMrc = {sumC:0} kN.m < 1,25 ΣMrb = {1.25 * sumB:0} kN.m (zone sismique).");
                }
            }
        }
        if (tested > 0) rep.AppendLine(bad == 0 ? $"Poteau fort / poutre faible : {tested} nœud(s)-sens contrôlés, ΣMrc ≥ 1,25 ΣMrb partout (approche simplifiée)." :
            $"Poteau fort / poutre faible : {bad} nœud(s)-sens sur {tested} ne vérifient pas ΣMrc ≥ 1,25 ΣMrb (voir les avertissements des poteaux).");
    }

    // ------------------------------------------------------------------ tassements différentiels
    static bool CheckDifferentialSettlement(StructModel m, AnalysisOutput o, StringBuilder rep)
    {
        var pts = new List<(int Node, double X, double Y, double S)>();
        var nodes = m.Nodes.ToDictionary(x => x.Id);
        foreach (var f in o.Footings)
        {
            if (!f.Values.TryGetValue("settlement_mm", out var s) || s <= 0) continue;
            var mt = Regex.Match(f.Element ?? "", @"nœud\s+(\d+)");
            if (!mt.Success || !int.TryParse(mt.Groups[1].Value, out int id) || !nodes.TryGetValue(id, out var nd)) continue;
            pts.Add((id, nd.X, nd.Y, s));
        }
        if (pts.Count < 2) return true;
        double worst = 0; (int, int) wp = (0, 0); double wd = 0, wds = 0;
        for (int i = 0; i < pts.Count; i++)
            for (int j = i + 1; j < pts.Count; j++)
            {
                double dist = Math.Sqrt(Math.Pow(pts[i].X - pts[j].X, 2) + Math.Pow(pts[i].Y - pts[j].Y, 2));
                if (dist < 0.5) continue;
                double ds = Math.Abs(pts[i].S - pts[j].S) / 1000.0, ang = ds / dist;
                if (ang > worst) { worst = ang; wp = (pts[i].Node, pts[j].Node); wd = dist; wds = ds * 1000; }
            }
        if (worst <= 0) return true;
        bool ok = worst <= 1.0 / 500.0;
        rep.AppendLine($"Tassements différentiels : distorsion angulaire max = 1/{(worst > 0 ? 1 / worst : 0):0} entre les nœuds {wp.Item1} et {wp.Item2} (Δs = {wds:0.0} mm sur {wd:0.0} m), limite 1/500 : {(ok ? "OK" : "NON OK")}.");
        if (!ok) o.Messages.Add($"Tassement différentiel entre semelles des nœuds {wp.Item1} et {wp.Item2} : 1/{1 / worst:0} > 1/500 (risque de fissuration des cloisons et des poutres) : égaliser les contraintes sous semelles, élargir ou relier par longrines/radier.");
        return ok;
    }

    // ------------------------------------------------------------------ murs de soutènement : glissement et renversement
    static bool CheckRetainingWalls(StructModel m, AnalysisOutput o, StringBuilder rep)
    {
        bool allOk = true;
        foreach (var w in m.Walls.Where(x => x.Retaining))
        {
            double h = w.RetainedHeightM > 0 ? w.RetainedHeightM : w.HeightM;
            double ang = w.AngleDeg * Math.PI / 180.0, wx = w.X + w.LengthM / 2 * Math.Cos(ang), wy = w.Y + w.LengthM / 2 * Math.Sin(ang);
            // semelle filante sous le mur : axe le plus proche du milieu du mur (< 0,8 m)
            FootingDef? best = null; double bd = 0.8;
            foreach (var f in m.FootingDefs.Where(x => x.Kind == FootingKind.Filante && x.LengthM > 0 && x.FixedA > 0))
            {
                double fa = f.AngleDeg * Math.PI / 180.0, ux = Math.Cos(fa), uy = Math.Sin(fa);
                double t = (wx - f.X0) * ux + (wy - f.Y0) * uy;
                if (t < -0.5 || t > f.LengthM + 0.5) continue;
                double dist = Math.Abs(-(wx - f.X0) * uy + (wy - f.Y0) * ux);
                if (dist < bd) { bd = dist; best = f; }
            }
            if (best == null) { o.Messages.Add($"Mur de soutènement {w.Name} : stabilité (glissement, renversement) non vérifiable, aucune semelle filante n'est associée."); continue; }
            double B = best.FixedA, T = best.ThicknessM > 0 ? best.ThicknessM : 0.40, t0 = w.ThicknessM;
            double K = w.KEarth, g = w.SoilGammaKnM3, q = w.SurchargeKPa;
            double hT = h + T;                                                   // poussée sur le mur + la semelle
            double P = 0.5 * K * g * hT * hT + K * q * hT;                       // kN/m
            double Mo = K * g * hT * hT * hT / 6.0 + K * q * hT * hT / 2.0;      // moment renversant au pied avant (kN.m/m)
            double Wmur = t0 * w.HeightM * 25.0, Wsem = B * T * 25.0, heel = Math.Max(0, (B - t0) / 2.0), Wsol = heel * h * g;
            double Mr = Wmur * B / 2 + Wsem * B / 2 + Wsol * (B - heel / 2);
            double V = Wmur + Wsem + Wsol;
            double mu = 0.5, Fres = mu * V;
            double fsO = Mr / Math.Max(Mo, 1e-6), fsS = Fres / Math.Max(P, 1e-6);
            double e = B / 2 - (Mr - Mo) / V;                                    // excentricité de la résultante
            bool ok = fsO >= 1.5 && fsS >= 1.5 && Math.Abs(e) <= B / 6.0 + 1e-9;
            allOk &= ok;
            string line = $"Mur {w.Name} (h = {h:0.00} m, semelle {B:0.00}×{T:0.00} m) : poussée {P:0} kN/m ; renversement FS = {fsO:0.00} (≥ 1,5) ; glissement FS = {fsS:0.00} (≥ 1,5, μ = {mu:0.0}) ; excentricité {Math.Abs(e):0.00} m (≤ B/6 = {B / 6:0.00} m) : {(ok ? "OK" : "NON OK")}.";
            rep.AppendLine(line);
            if (!ok) o.Messages.Add($"Mur de soutènement {w.Name} : stabilité insuffisante (renversement {fsO:0.00}, glissement {fsS:0.00}) : élargir la semelle côté terres, ajouter une bêche ou un contrefort.");
        }
        return allOk;
    }
}
