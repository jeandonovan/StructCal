using System.Text.Json;
using System.Text.Json.Serialization;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed class RevitSummaryItem
{
    public string ExternalId { get; set; } = "";
    public int MemberId { get; set; }
    public string Summary { get; set; } = "";
    public string Status { get; set; } = "";
    // ferraillage (béton armé) pour la création des armatures dans Revit : longueurs et enrobage en mètres, diamètres en mm
    public string Type { get; set; } = "";          // Column / Beam / ...
    public string Kind { get; set; } = "";          // ReinforcedConcrete / Steel
    public double B { get; set; }
    public double H { get; set; }
    public double Length { get; set; }
    public double Cover { get; set; }               // enrobage net des cadres (m)
    public int BotN { get; set; }
    public int BotDia { get; set; }
    public int TopN { get; set; }
    public int TopDia { get; set; }
    public int StirDia { get; set; }
    public double StirSpacingCm { get; set; }
    public double NodalSpacingCm { get; set; }
    public double NodalZoneM { get; set; }
    /// <summary>Dalles et semelles : coin minimal en plan (m), cote du dessus (m). Une dalle Revit est reprise en plusieurs panneaux (contour, trémies) : chaque panneau garde son rectangle.
    /// HasRect = vrai quand ces valeurs sont renseignées (B = largeur en X, Length = longueur en Y).</summary>
    public bool HasRect { get; set; }
    public double X0 { get; set; }
    public double Y0 { get; set; }
    public double ZTop { get; set; }
    /// <summary>Dalles : armatures par nappe, ex. « Travee_lx » = « HA10 e=15 » ; Lx, Ly, H en mètres.</summary>
    public Dictionary<string, string> Extra { get; set; } = new();
}

public static class ModelIO
{
    private static readonly JsonSerializerOptions Opt = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() },
    };

    public static void Save(StructModel m, string path) => File.WriteAllText(path, JsonSerializer.Serialize(m, Opt));

    public static StructModel Load(string path) =>
        JsonSerializer.Deserialize<StructModel>(File.ReadAllText(path), Opt) ?? new StructModel();

    public static StructModel FromJson(string json) =>
        JsonSerializer.Deserialize<StructModel>(json, Opt) ?? new StructModel();

    public static string ToJson(StructModel m) => JsonSerializer.Serialize(m, Opt);

    /// <summary>Résumé par barre (pour réinjection dans Revit).</summary>
    public static void SaveRevitSummary(AnalysisOutput o, string path, StructModel? model = null)
    {
        var items = o.Members.Select(r => new RevitSummaryItem
        {
            ExternalId = r.ExternalId, MemberId = r.MemberId, Summary = r.Summary, Status = r.Status,
            Type = r.Type.ToString(), Kind = r.Kind.ToString(), B = r.B, H = r.H, Length = r.Length,
            Cover = NetCover(model?.Members.FirstOrDefault(x => x.Id == r.MemberId), r),
            BotN = r.BotN, BotDia = r.BotDia, TopN = r.TopN, TopDia = r.TopDia, StirDia = r.StirDia,
            StirSpacingCm = r.StirSpacingCm, NodalSpacingCm = r.NodalSpacingCm, NodalZoneM = r.NodalZoneM
        }).ToList();
        // dalles venant de Revit : armatures lues dans le texte du calcul (« HA10 e=15 cm (...) »)
        if (model != null)
            foreach (var sl in model.Slabs.Where(x => !string.IsNullOrEmpty(x.ExternalId)))
            {
                var d = o.Slabs.FirstOrDefault(x => x.Element.StartsWith($"Dalle {sl.Name} ("));
                if (d == null) continue;
                var it = new RevitSummaryItem
                {
                    ExternalId = sl.ExternalId, MemberId = 0, Type = "Slab", Kind = "ReinforcedConcrete", B = sl.Lx, H = sl.H, Length = sl.Ly,
                    HasRect = sl.Placed, X0 = sl.X0, Y0 = sl.Y0, ZTop = sl.Z,
                    Cover = (sl.CoverCm > 0 ? sl.CoverCm : model.Settings.CoverSlabCm) / 100.0,
                    Status = d.Ok ? "OK" : "NON OK",
                    Summary = $"Dalle {sl.Name} h={sl.H * 100:F0} cm : " + string.Join(" ; ", d.Texts.Select(t => t.Key + " " + t.Value))
                };
                // « sens lx » du calcul = la portée la plus courte : si elle est suivant Y, les barres « lx » courent suivant Y
                bool swap = sl.Lx > sl.Ly;
                foreach (var (key, name) in new[] { ("Travée sens lx", swap ? "Travee_ly" : "Travee_lx"), ("Travée sens ly", swap ? "Travee_lx" : "Travee_ly"),
                                                    ("Appui sens lx", swap ? "Appui_ly" : "Appui_lx"), ("Appui sens ly", swap ? "Appui_lx" : "Appui_ly") })
                    if (d.Texts.TryGetValue(key, out var txt)) it.Extra[name] = txt;
                items.Add(it);
            }
        // semelles isolées venant de Revit : armatures des deux nappes
        foreach (var x in o.Extras.Where(e => e.Data.TryGetValue("Kind", out var k) && k == "Footing"))
        {
            var ci = System.Globalization.CultureInfo.InvariantCulture;
            bool strip = x.Data.GetValueOrDefault("Strip") == "1";
            var it = new RevitSummaryItem
            {
                ExternalId = x.Data["ExternalId"], MemberId = 0, Type = strip ? "FootingStrip" : "Footing", Kind = "ReinforcedConcrete",
                B = double.Parse(x.Data["A"], ci), Length = double.Parse(x.Data["B"], ci), H = double.Parse(x.Data["H"], ci),
                Cover = (model?.Settings.CoverFootingCm ?? 5.0) / 100.0,
                Status = x.Data["Ok"], Summary = strip ? $"Semelle filante {x.Data["Name"]} : transversales {x.Data["NappeA"]} ; répartition {x.Data["NappeB"]}" : $"Semelle {x.Data["Name"]} : nappe // A {x.Data["NappeA"]} ; nappe // B {x.Data["NappeB"]}"
            };
            it.Extra["Nappe_A"] = x.Data["NappeA"]; it.Extra["Nappe_B"] = x.Data["NappeB"];
            items.Add(it);
        }
        // semelles créées par StructCalc (sous les poteaux, sans équivalent dans Revit) : Revit les crée et les arme
        if (model != null)
            foreach (var pf in StructCalc.Engine.Geometry.FootingPlacement.From(model, o))
            {
                var fd = model.FootingDefs.FirstOrDefault(x => x.Name == pf.Name && x.Kind == FootingKind.Isolee);
                if (fd != null && !string.IsNullOrEmpty(fd.ExternalId)) continue;                 // semelle venue de Revit : déjà traitée ci-dessus
                var res = o.Footings.FirstOrDefault(f => StructCalc.Engine.Geometry.FootingPlacement.NodeIdOf(f.Element) == pf.NodeId);
                if (res == null) continue;
                var (ox, oy) = StructCalc.Engine.Geometry.FootingSolids.Shift(pf.A, pf.B, pf.ColA, pf.ColB, pf.Glacis, model.FootingAlignX, model.FootingAlignY);
                var it = new RevitSummaryItem
                {
                    ExternalId = "", MemberId = pf.NodeId, Type = "Footing", Kind = "ReinforcedConcrete", B = pf.A, Length = pf.B, H = pf.H,
                    HasRect = true, X0 = pf.X + ox - pf.A / 2, Y0 = pf.Y + oy - pf.B / 2, ZTop = pf.ZTop,
                    Cover = model.Settings.CoverFootingCm / 100.0, Status = pf.Ok ? "OK" : "NON OK",
                    Summary = $"Semelle {pf.Name} : {pf.A:0.00} x {pf.B:0.00} x {pf.H:0.00} m"
                };
                if (res.Texts.TryGetValue("Nappe // A", out var na)) it.Extra["Nappe_A"] = na;
                if (res.Texts.TryGetValue("Nappe // B", out var nb)) it.Extra["Nappe_B"] = nb;
                it.Extra["Nom"] = pf.Name;
                items.Add(it);
            }
        // radiers venant de Revit : un élément par rectangle, avec les 4 nappes
        foreach (var x in o.Extras.Where(e => e.Data.TryGetValue("Kind", out var k) && k == "Raft"))
        {
            var rf = model?.Rafts.FirstOrDefault(q => q.Name == x.Data["Name"]);
            if (rf == null || string.IsNullOrEmpty(rf.ExternalId)) continue;
            foreach (var pn in rf.Panels)
            {
                var it = new RevitSummaryItem
                {
                    ExternalId = rf.ExternalId, MemberId = 0, Type = "Raft", Kind = "ReinforcedConcrete", B = pn.Lx, Length = pn.Ly, H = rf.H,
                    HasRect = true, X0 = pn.X0, Y0 = pn.Y0, ZTop = rf.ZTop, Cover = rf.CoverCm / 100.0, Status = x.Data["Ok"],
                    Summary = $"Radier {rf.Name} h={rf.H * 100:F0} cm : inf. X {x.Data.GetValueOrDefault("Inf X")} ; inf. Y {x.Data.GetValueOrDefault("Inf Y")} ; sup. X {x.Data.GetValueOrDefault("Sup X")} ; sup. Y {x.Data.GetValueOrDefault("Sup Y")}"
                };
                foreach (var k in new[] { "Inf X", "Inf Y", "Sup X", "Sup Y" }) if (x.Data.TryGetValue(k, out var v)) it.Extra[k.Replace(' ', '_')] = v;
                items.Add(it);
            }
        }
        // voiles venant de Revit : armatures générales (verticales / horizontales par face) et ouvertures
        foreach (var wr in o.Walls)
        {
            var w = wr.Def;
            if (string.IsNullOrEmpty(w.ExternalId)) continue;
            var it = new RevitSummaryItem
            {
                ExternalId = w.ExternalId, MemberId = 0, Type = "Wall", Kind = "ReinforcedConcrete", B = w.LengthM, Length = w.HeightM, H = w.ThicknessM,
                Cover = w.CoverCm / 100.0, Status = wr.Ok ? "OK" : "NON OK",
                Summary = $"Voile {w.Name}{(w.Retaining ? " (soutènement)" : "")} e={w.ThicknessM * 100:F0} cm : vertical {wr.GeneralV} ; horizontal {wr.GeneralH} (chaque face)"
            };
            it.Extra["Vert"] = wr.GeneralV; it.Extra["Horiz"] = wr.GeneralH;
            items.Add(it);
        }
        // escaliers venant de Revit : armatures de chaque volée (travée, chapeaux d'appui, répartition) pour les poser en 3D dans les volées et paliers
        foreach (var sr in o.Stairs)
        {
            var d = sr.Def;
            if (string.IsNullOrEmpty(d.ExternalId) || sr.Elements.Count == 0) continue;
            var it = new RevitSummaryItem
            {
                ExternalId = d.ExternalId, MemberId = 0, Type = "Stair", Kind = "ReinforcedConcrete", B = d.WidthM, H = sr.Geo.ThicknessM, Length = sr.Elements.Sum(e => e.RunM),
                Cover = Math.Max(d.CoverCm, 2.0) / 100.0, Status = sr.Ok ? "OK" : "NON OK",
                Summary = $"Escalier {d.Name} e={sr.Geo.ThicknessM * 100:F0} cm : " + string.Join(" ; ", sr.Elements.Select(e => $"{e.Name} {e.BarsT} (chapeaux {e.BarsA} / {e.BarsB}, répartition {e.BarsDistr})"))
            };
            it.Extra["N"] = sr.Elements.Count.ToString();
            it.Extra["fc28"] = (model?.Fc28 ?? 25).ToString(System.Globalization.CultureInfo.InvariantCulture); it.Extra["fe"] = (model?.Fe ?? 500).ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (sr.Warnings.Count > 0) it.Extra["Avert"] = string.Join(" / ", sr.Warnings);
            for (int i = 0; i < sr.Elements.Count; i++)
            {
                var e = sr.Elements[i]; int k = i + 1;
                it.Extra[$"Main_{k}"] = e.BarsT; it.Extra[$"TopA_{k}"] = e.BarsA; it.Extra[$"TopB_{k}"] = e.BarsB; it.Extra[$"Distr_{k}"] = e.BarsDistr;
                it.Extra[$"Span_{k}"] = e.SpanM.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
                it.Extra[$"Before_{k}"] = e.BeforeM.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture); it.Extra[$"After_{k}"] = e.AfterM.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
            }
            items.Add(it);
        }
        File.WriteAllText(path, JsonSerializer.Serialize(items, Opt));
    }

    /// <summary>Enrobage net (m) à donner à Revit : l'enrobage nominal s'il est connu, sinon déduit de l'axe (axe - cadre - demi-barre).</summary>
    private static double NetCover(Member? mem, MemberDesignResult r)
    {
        if (mem == null) return 0;
        if (mem.CoverNomCm > 0) return mem.CoverNomCm / 100.0;
        return Math.Max(0.02, mem.Cover - r.StirDia / 1000.0 - Math.Max(r.BotDia, r.TopDia) / 2000.0);
    }

    public static List<RevitSummaryItem> LoadRevitSummary(string path) =>
        JsonSerializer.Deserialize<List<RevitSummaryItem>>(File.ReadAllText(path), Opt) ?? new();
}
