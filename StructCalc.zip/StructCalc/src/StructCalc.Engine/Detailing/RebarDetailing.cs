using System.Globalization;
using System.Net;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine.Detailing;

// ============================================================================================================================
//  Dispositions constructives de ferraillage (étape 5) : calculs purs, sans dessin, testés par des valeurs faites à la main.
//  Ce que ce module NE fait PAS (à ne pas prétendre) : détail de nœud poteau-poutre, escalier à crémaillère.
// ============================================================================================================================

/// <summary>Une barre développée : longueur à couper (mm) et éventuel défaut géométrique.</summary>
public sealed record DevelopedBar(double LengthMm, double StraightMm, double ArcMm, bool Valid, string Message);

/// <summary>Longueur développée exacte d'une barre cintrée. La ligne brisée donnée est celle de l'AXE de la barre (intersections théoriques des segments) ;
/// chaque angle est remplacé par un arc de rayon d'axe R = (mandrin + φ) / 2 : on retire les deux longueurs de tangente 2 R tan(θ/2) et on ajoute l'arc R θ.</summary>
public static class DevelopedLength
{
    public static DevelopedBar Of(IList<(double X, double Y)> axisPolyMm, double barDiaMm, double mandrelDiaMm)
    {
        if (axisPolyMm.Count < 2) return new DevelopedBar(0, 0, 0, false, "Il faut au moins deux points.");
        double R = (mandrelDiaMm + barDiaMm) / 2.0;
        int n = axisPolyMm.Count;
        var seg = new double[n - 1];
        var dir = new (double X, double Y)[n - 1];
        for (int i = 0; i < n - 1; i++)
        {
            double dx = axisPolyMm[i + 1].X - axisPolyMm[i].X, dy = axisPolyMm[i + 1].Y - axisPolyMm[i].Y, l = Math.Sqrt(dx * dx + dy * dy);
            if (l < 1e-9) return new DevelopedBar(0, 0, 0, false, $"Segment {i + 1} de longueur nulle.");
            seg[i] = l; dir[i] = (dx / l, dy / l);
        }
        var trim = new double[n];            // longueur de tangente retirée à chaque sommet intérieur
        double arcs = 0;
        var notes = new List<string>();
        bool valid = true;
        for (int i = 1; i < n - 1; i++)
        {
            double cos = Math.Max(-1, Math.Min(1, dir[i - 1].X * dir[i].X + dir[i - 1].Y * dir[i].Y));
            double theta = Math.Acos(cos);                       // angle de déviation (0 = barre droite)
            if (theta < 1e-6) continue;
            if (theta > Math.PI - 1e-3) { valid = false; notes.Add($"Pli {i} : retour sur soi (180°), cintrage impossible."); continue; }
            trim[i] = R * Math.Tan(theta / 2);
            arcs += R * theta;
        }
        double straight = 0;
        for (int i = 0; i < n - 1; i++)
        {
            double used = trim[i] + trim[i + 1];
            double s = seg[i] - used;
            if (s < -1e-6) { valid = false; notes.Add($"Segment {i + 1} ({seg[i]:0} mm) plus court que les tangentes des plis voisins ({used:0} mm) : le cintrage ne tient pas."); }
            straight += Math.Max(0, s);
        }
        return new DevelopedBar(straight + arcs, straight, arcs, valid, string.Join(" ", notes));
    }

    /// <summary>Gain de cintrage d'un pli d'angle θ (degrés) : longueur de la ligne brisée - longueur développée = R (2 tan(θ/2) - θ).</summary>
    public static double BendGainMm(double deflectionDeg, double barDiaMm, double mandrelDiaMm)
    {
        double R = (mandrelDiaMm + barDiaMm) / 2.0, t = deflectionDeg * Math.PI / 180;
        return R * (2 * Math.Tan(t / 2) - t);
    }

    /// <summary>Cadre rectangulaire fermé : périmètre d'axe, moins le gain aux 4 angles à 90°, plus deux crochets à 135° (arc + retour). Longueur de l'axe.
    /// b, h = dimensions extérieures de la section, cover = enrobage nominal du cadre, leg = longueur du retour du crochet (par défaut max(10 φ ; 70 mm)).</summary>
    public static double Stirrup(double bMm, double hMm, double coverMm, double barDiaMm, double mandrelDiaMm, double legMm = 0)
    {
        double w = bMm - 2 * coverMm - barDiaMm, h = hMm - 2 * coverMm - barDiaMm;       // dimensions de l'axe
        double R = (mandrelDiaMm + barDiaMm) / 2.0;
        if (legMm <= 0) legMm = Math.Max(10 * barDiaMm, 70);
        double perim = 2 * (w + h);
        double gain4 = 4 * BendGainMm(90, barDiaMm, mandrelDiaMm);
        double hooks = 2 * (R * 135 * Math.PI / 180 + legMm);
        return perim - gain4 + hooks;
    }
}

// ============================================================================================================================
public sealed record LapPlacement(int BarIndex, int Group, double OffsetM);

/// <summary>Décalage des recouvrements entre barres voisines : les barres d'une même nappe sont réparties en deux groupes alternés dont les recouvrements sont
/// décalés de 1,3 lr (centre à centre), de sorte qu'au plus 50 % des barres soient recouvertes dans une même section (EC2 8.7.2 ; BAEL A.6.1,253).</summary>
public static class LapStagger
{
    public const double SpacingFactor = 1.3;

    public static List<LapPlacement> Plan(int barCount, double lapM)
    {
        var l = new List<LapPlacement>();
        for (int i = 0; i < barCount; i++) l.Add(new LapPlacement(i, i % 2, (i % 2) * SpacingFactor * lapM));
        return l;
    }

    /// <summary>Part maximale des barres dont les recouvrements se chevauchent (deux recouvrements de longueur lr dont les débuts sont distants de moins de lr sont dans la même section).</summary>
    public static double MaxLappedFraction(IList<LapPlacement> plan, double lapM)
    {
        if (plan.Count == 0) return 0;
        int best = 0;
        foreach (var a in plan)
        {
            int n = plan.Count(b => Math.Abs(b.OffsetM - a.OffsetM) < lapM - 1e-9);
            best = Math.Max(best, n);
        }
        return (double)best / plan.Count;
    }

    /// <summary>Vrai si au plus 50 % des barres sont recouvertes dans une même section. Une barre unique ne peut pas être décalée.</summary>
    public static bool Ok(IList<LapPlacement> plan, double lapM) => plan.Count >= 2 && MaxLappedFraction(plan, lapM) <= 0.5 + 1e-9;
}

// ============================================================================================================================
public sealed record StitchResult(double VedMPa, double AsPerMetreCm2, double VrdMaxMPa, bool StrutOk, string Note);

/// <summary>Armatures de couture à la jonction table / âme d'une poutre en T (EC2 6.2.4) : l'effort rasant vEd = ΔFd / (hf Δx) doit être repris par
/// Asf/sf ≥ vEd hf / (fyd cot θ) (cot θ = 1,0 table tendue, 1,25 table comprimée), et la bielle vérifiée : vEd ≤ ν fcd sin θ cos θ.</summary>
public static class FlangeWebStitching
{
    public static StitchResult Design(double deltaFdKN, double dxM, double hfM, double fyMPa, double fck, bool compressionFlange)
    {
        if (dxM <= 0 || hfM <= 0) return new StitchResult(0, 0, 0, false, "Longueur de transmission ou épaisseur de table nulle.");
        double vEd = deltaFdKN / 1000.0 / (hfM * dxM);                         // MPa (kN -> MN)
        double cot = compressionFlange ? 1.25 : 1.0;
        double theta = Math.Atan(1.0 / cot);
        double fyd = fyMPa / 1.15, fcd = fck / 1.5;
        double nu = 0.6 * (1 - fck / 250.0);
        double vRdMax = nu * fcd * Math.Sin(theta) * Math.Cos(theta);
        double asPerM = vEd * hfM / (fyd * cot) * 10000.0;                  // vEd [MPa] x hf [m] / fyd [MPa] = m²/m ; x 10 000 = cm²/m
        string note = vEd > vRdMax ? $"Bielle de table écrasée : vEd = {vEd:0.00} MPa > {vRdMax:0.00} MPa. Épaissir la table." : $"Armature de couture requise {asPerM:0.00} cm²/m (à ajouter à la flexion transversale).";
        return new StitchResult(vEd, asPerM, vRdMax, vEd <= vRdMax, note);
    }
}

// ============================================================================================================================
public sealed record SupportAnchorageResult(int MemberId, int NodeId, string Support, int DiaMm, double LsMm, double HookMm, double AvailMm, string Solution, string Verdict);

/// <summary>Ancrage des armatures inférieures des poutres sur leurs vrais appuis : poteau ou poutre porteuse au nœud d'extrémité. Une poutre prolongée au-delà du nœud n'est pas un appui d'extrémité.
/// Disponible = dimension de l'appui dans le sens de la poutre - enrobage ; requis = ls (droit) ou 0,4 ls (crochet normal).</summary>
public static class SupportAnchorage
{
    public static List<SupportAnchorageResult> Evaluate(StructModel m, AnalysisOutput o, double fc28, double fe)
    {
        var res = new List<SupportAnchorageResult>();
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        foreach (var r in o.Members)
        {
            if (r.Skipped || r.Type != MemberType.Beam || r.Kind != MaterialKind.ReinforcedConcrete) continue;
            var bm = m.Members.FirstOrDefault(x => x.Id == r.MemberId);
            if (bm == null || r.BotDia <= 0 || !nodes.TryGetValue(bm.NodeI, out var ni) || !nodes.TryGetValue(bm.NodeJ, out var nj)) continue;
            double dx = nj.X - ni.X, dy = nj.Y - ni.Y, len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 1e-6) continue;                      // poutre verticale : hors sujet
            double ux = dx / len, uy = dy / len;
            double ls = RebarChecks.Anchorage(r.BotDia, fe, fc28).Ls;
            foreach (int nid in new[] { bm.NodeI, bm.NodeJ })
            {
                var others = m.Members.Where(x => x.Id != bm.Id && (x.NodeI == nid || x.NodeJ == nid)).ToList();
                bool continues = others.Any(x => x.Type == MemberType.Beam && IsCollinear(nodes, x, nid, ux, uy));
                if (continues) continue;
                string kind; double dim;
                var col = others.FirstOrDefault(x => x.Type == MemberType.Column);
                if (col != null) { kind = "poteau"; dim = Math.Abs(ux) * col.B + Math.Abs(uy) * col.H; }
                else
                {
                    var carrier = others.FirstOrDefault(x => x.Type == MemberType.Beam && !IsCollinear(nodes, x, nid, ux, uy));
                    if (carrier == null) continue;           // pas d'appui identifiable : on n'invente rien
                    kind = "poutre porteuse";
                    var (vx, vy) = DirectionAway(nodes, carrier, nid);
                    // largeur B de la porteuse, perpendiculaire à son axe : sa projection sur l'axe de notre poutre
                    double nx = -vy, ny = vx;
                    dim = Math.Abs(ux * nx + uy * ny) * carrier.B;
                }
                double avail = (dim - 0.04) * 1000.0;           // enrobage de l'appui : 4 cm
                double hook = 0.4 * ls;
                string sol, verdict;
                if (ls <= avail) { sol = "ancrage droit"; verdict = "Vérifiée"; }
                else if (hook <= avail) { sol = "crochet normal"; verdict = "Vérifiée"; }
                else { sol = "insuffisant : élargir l'appui, réduire le diamètre ou prévoir des barres en U"; verdict = RebarChecks.Verdict(avail, hook); }
                res.Add(new SupportAnchorageResult(r.MemberId, nid, kind, r.BotDia, ls, hook, avail, sol, verdict));
            }
        }
        return res;
    }

    private static (double X, double Y) DirectionAway(Dictionary<int, Node> nodes, Member x, int nid)
    {
        int other = x.NodeI == nid ? x.NodeJ : x.NodeI;
        if (!nodes.TryGetValue(nid, out var a) || !nodes.TryGetValue(other, out var b)) return (1, 0);
        double dx = b.X - a.X, dy = b.Y - a.Y, l = Math.Sqrt(dx * dx + dy * dy);
        return l < 1e-9 ? (1, 0) : (dx / l, dy / l);
    }

    private static bool IsCollinear(Dictionary<int, Node> nodes, Member x, int nid, double ux, double uy)
    {
        var (vx, vy) = DirectionAway(nodes, x, nid);
        return Math.Abs(vx * ux + vy * uy) > 0.98;        // à moins de ~11° : prolongement de la poutre
    }

    public static string ToHtml(StructModel m, AnalysisOutput o)
    {
        var rows = Evaluate(m, o, m.Fc28, m.Fe);
        if (rows.Count == 0) return "";
        var sb = new StringBuilder();
        sb.AppendLine("<h2>5c. Ancrage des armatures inférieures sur les appuis réels</h2>");
        sb.AppendLine("<table><tr><th>Poutre</th><th>Nœud</th><th>Appui</th><th>HA</th><th>ls (mm)</th><th>0,4 ls (mm)</th><th>Disponible (mm)</th><th>Solution</th><th>Verdict</th></tr>");
        var ci = CultureInfo.InvariantCulture;
        foreach (var r in rows)
            sb.AppendLine($"<tr><td>{r.MemberId}</td><td>{r.NodeId}</td><td>{WebUtility.HtmlEncode(r.Support)}</td><td>{r.DiaMm}</td><td>{r.LsMm.ToString("0", ci)}</td><td>{r.HookMm.ToString("0", ci)}</td><td>{r.AvailMm.ToString("0", ci)}</td><td>{WebUtility.HtmlEncode(r.Solution)}</td><td class='{(r.Verdict == "Vérifiée" ? "ok" : "ko")}'>{r.Verdict}</td></tr>");
        sb.AppendLine("</table>");
        return sb.ToString();
    }
}

// ============================================================================================================================
public sealed record ConfinementLine(int MemberId, string Type, double ZoneM, double SpacingCm, double MidSpacingCm, string Note);

/// <summary>Zones de confinement (zones critiques) des poutres et poteaux : longueur à chaque extrémité et espacement des cadres, tels que calculés selon la norme du projet.
/// Les barres sans exigence parasismique (norme non parasismique) n'ont pas de zone : elles sont listées avec l'indication « aucune exigence ».</summary>
public static class ConfinementZones
{
    public static List<ConfinementLine> Collect(AnalysisOutput o)
    {
        var l = new List<ConfinementLine>();
        foreach (var r in o.Members.Where(x => !x.Skipped && x.Kind == MaterialKind.ReinforcedConcrete && x.StirDia > 0))
        {
            if (r.NodalSpacingCm <= 0) { l.Add(new ConfinementLine(r.MemberId, r.Type.ToString(), 0, r.StirSpacingCm, r.StirSpacingCm, "aucune exigence de zone critique pour la norme du projet")); continue; }
            string note = r.NodalSpacingCm <= r.StirSpacingCm + 1e-9 ? $"cadres HA{r.StirDia} resserrés à e = {r.NodalSpacingCm:0.#} cm sur {r.NodalZoneM:0.00} m à chaque extrémité" : "espacement en zone critique supérieur à l'espacement courant : à vérifier";
            l.Add(new ConfinementLine(r.MemberId, r.Type.ToString(), r.NodalZoneM, r.NodalSpacingCm, r.StirSpacingCm, note));
        }
        return l;
    }

    public static string ToHtml(AnalysisOutput o)
    {
        var rows = Collect(o).Where(x => x.ZoneM > 0).ToList();
        if (rows.Count == 0) return "";
        var sb = new StringBuilder();
        sb.AppendLine("<h2>5d. Zones de confinement</h2><table><tr><th>Barre</th><th>Type</th><th>Longueur de zone (m)</th><th>e zone (cm)</th><th>e courant (cm)</th><th>Disposition</th></tr>");
        foreach (var r in rows)
            sb.AppendLine($"<tr><td>{r.MemberId}</td><td>{r.Type}</td><td>{r.ZoneM:0.00}</td><td>{r.SpacingCm:0.#}</td><td>{r.MidSpacingCm:0.#}</td><td>{WebUtility.HtmlEncode(r.Note)}</td></tr>");
        sb.AppendLine("</table>");
        return sb.ToString();
    }
}
