using StructCalc.Core.Steel;

namespace StructCalc.Engine;

public sealed class EndPlateDesign
{
    public string BeamProfile = "", ColumnProfile = "";
    public int BoltDia;
    public int TensionRows, CompressionRows;
    public double PlateT, PlateW, PlateH, Gauge, Pitch, Extension;
    public double FlangeWeld, WebWeld;
    public bool StiffenersAdvised;
    public double MkNm, VkN, UtilTension, UtilShear;
    public List<string> Notes = new();
}

public sealed class BasePlateDesign
{
    public string ColumnProfile = "";
    public double PlateB, PlateH, PlateT;
    public int AnchorDia, AnchorCount;
    public double AnchorLength;
    public double UtilBearing;
    public bool ShearKeyAdvised;
    public double NkN, MkNm, VkN;
    public List<string> Notes = new();
}

/// <summary>PRÉ-DIMENSIONNEMENT d'assemblages acier (platine d'extrémité boulonnée, pied de poteau) d'après les principes de l'EC3-1-8 :
/// boulons 8.8 (fub = 800 MPa), gamma_M2 = 1,25, gamma_M0 = 1,0. Résultat indicatif destiné aux plans de principe : une note de calcul
/// d'assemblage complète (rigidité, leviers, soudures, poinçonnement, voilement de l'âme) reste à établir par l'ingénieur.</summary>
public static class ConnectionDesigner
{
    private static readonly int[] Dia = { 16, 20, 24, 30 };
    private static readonly double[] As = { 157, 245, 353, 561 };
    private static double FtRd(int i) => 0.9 * 800 * As[i] / 1.25 / 1000.0;
    private static double FvRd(int i) => 0.6 * 800 * As[i] / 1.25 / 1000.0;

    public static EndPlateDesign EndPlate(SteelProfile beam, SteelProfile col, double fy, double MkNm, double VkN)
    {
        var r = new EndPlateDesign { BeamProfile = beam.Name, ColumnProfile = col.Name, MkNm = Math.Abs(MkNm), VkN = Math.Abs(VkN) };
        double z = (beam.H - beam.Tf) / 1000.0;
        double Ft = r.MkNm / z;
        int chosen = Dia.Length - 1, rows = 1;
        for (int i = 0; i < Dia.Length; i++)
        {
            int nT = Math.Max(2, (int)Math.Ceiling(Ft / FtRd(i)));
            int rw = (nT + 1) / 2;
            if (rw <= 3) { chosen = i; rows = rw; break; }
            chosen = i; rows = rw;
        }
        int d = Dia[chosen];
        r.BoltDia = d; r.TensionRows = rows;
        r.CompressionRows = Math.Max(1, Math.Min(3, (int)Math.Ceiling(r.VkN / (2 * FvRd(chosen)))));
        r.UtilTension = Ft / (2 * rows * FtRd(chosen));
        r.UtilShear = r.VkN / (2 * r.CompressionRows * FvRd(chosen));
        r.Pitch = 3 * d;
        r.Gauge = 100;
        r.PlateW = Math.Ceiling(Math.Max(beam.B, r.Gauge + 3 * d) / 10) * 10;
        r.Extension = rows >= 2 ? 1.5 * d + 15 : 0;
        r.PlateH = Math.Ceiling((beam.H + r.Extension + 15) / 10) * 10;
        r.PlateT = Math.Max(12, Math.Ceiling(0.9 * d / 2) * 2);
        r.FlangeWeld = Math.Max(5, Math.Ceiling(0.7 * beam.Tf));
        r.WebWeld = Math.Max(4, Math.Ceiling(0.5 * beam.Tw));
        double beff = beam.Tf + 2 * Math.Sqrt(2) * r.FlangeWeld + 2 * r.PlateT + 5 * (col.Tf + col.R);
        double Fcwc = beff * col.Tw * fy / 1000.0;
        r.StiffenersAdvised = Ft > Fcwc;
        r.Notes.Add($"M = {r.MkNm:0.0} kN.m, V = {r.VkN:0.0} kN, bras de levier z = {z * 1000:0} mm, Ft = {Ft:0} kN");
        r.Notes.Add($"Boulons HM{d} classe 8.8 : {rows} rang(s) tendu(s) x 2 + {r.CompressionRows} rang(s) comprimé(s) x 2 ; Ft,Rd = {FtRd(chosen):0} kN/boulon, Fv,Rd = {FvRd(chosen):0} kN/boulon");
        r.Notes.Add($"Taux tension {r.UtilTension * 100:0} %, taux cisaillement {r.UtilShear * 100:0} %");
        r.Notes.Add($"Platine {r.PlateW:0} x {r.PlateH:0} x {r.PlateT:0} mm ; soudures semelles a = {r.FlangeWeld:0} mm, âme a = {r.WebWeld:0} mm");
        if (r.StiffenersAdvised) r.Notes.Add($"Raidisseurs d'âme du poteau {col.Name} recommandés (Ft = {Ft:0} kN > résistance de l'âme ≈ {Fcwc:0} kN).");
        if (r.UtilTension > 1 || r.UtilShear > 1) r.Notes.Add("ATTENTION : taux > 100 % : augmenter le diamètre, le nombre de rangs ou la section.");
        return r;
    }

    public static BasePlateDesign BasePlate(SteelProfile col, double fy, double fc28, double NkN, double MkNm, double VkN)
    {
        var r = new BasePlateDesign { ColumnProfile = col.Name, NkN = Math.Max(0, NkN), MkNm = Math.Abs(MkNm), VkN = Math.Abs(VkN) };
        double fjd = fc28 / 1.5;          // beta_j * kj * fcd avec kj = 1,5
        double bp = Math.Ceiling((col.B + 100) / 10) * 10, hp = Math.Ceiling((col.H + 100) / 10) * 10;
        double sigmaMax = 0;
        for (int it = 0; it < 80; it++)
        {
            double e = r.NkN > 0 ? r.MkNm * 1000.0 / r.NkN : 0;                 // mm
            double s0 = r.NkN * 1000.0 / (bp * hp);
            sigmaMax = e <= hp / 6.0 ? s0 * (1 + 6 * e / hp) : 2 * r.NkN * 1000.0 / (3 * bp * Math.Max(hp / 2 - e, 1));
            if (sigmaMax <= fjd || bp > 1500) break;
            bp += 20; hp += 20;
        }
        r.PlateB = bp; r.PlateH = hp;
        r.UtilBearing = sigmaMax / fjd;
        double c = Math.Max((hp - 0.95 * col.H) / 2, (bp - 0.8 * col.B) / 2);
        double sPl = Math.Min(Math.Max(sigmaMax, 0.1), fjd);
        r.PlateT = Math.Max(15, Math.Ceiling(c * Math.Sqrt(3 * sPl / fy) / 2) * 2);

        double zl = (hp - 100) / 1000.0;
        double T = r.MkNm / zl - r.NkN / 2;
        int ai = 1;
        int count = 4;
        if (T > 0)
        {
            for (ai = 0; ai < Dia.Length; ai++) { if (Math.Ceiling(T / FtRd(ai)) <= 3) break; }
            ai = Math.Min(ai, Dia.Length - 1);
            int per = Math.Max(2, (int)Math.Ceiling(T / FtRd(ai)));
            count = 2 * per;
            r.Notes.Add($"Soulèvement : traction par ligne d'ancrages T = {T:0} kN -> {per} tige(s) par côté.");
        }
        else ai = 1;
        r.AnchorDia = Dia[ai]; r.AnchorCount = count;
        r.AnchorLength = Math.Max(400, 25.0 * Dia[ai]);
        r.ShearKeyAdvised = r.VkN > 0.3 * r.NkN + 0.1;
        r.Notes.Add($"N = {r.NkN:0} kN, M = {r.MkNm:0.0} kN.m, V = {r.VkN:0.0} kN ; fjd = {fjd:0.0} MPa ; contrainte max sous platine {sigmaMax:0.0} MPa ({r.UtilBearing * 100:0} %)");
        r.Notes.Add($"Platine {r.PlateB:0} x {r.PlateH:0} x {r.PlateT:0} mm ; {r.AnchorCount} tiges d'ancrage HM{r.AnchorDia} (8.8), scellement ≥ {r.AnchorLength:0} mm");
        if (r.ShearKeyAdvised) r.Notes.Add("Effort tranchant > 0,3 N : prévoir une bêche sous la platine ou vérifier les tiges en cisaillement.");
        return r;
    }
}
