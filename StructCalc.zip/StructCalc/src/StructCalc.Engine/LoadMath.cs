using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Charge répartie linéaire sur une partie de la barre, en axes LOCAUX (kN/m) : q varie de Q1 en A à Q2 en B.</summary>
public sealed class LoadSeg
{
    public double A, B;
    public double[] Q1 = new double[3], Q2 = new double[3];
}

/// <summary>Force ou moment concentré en axes locaux à l'abscisse A.</summary>
public sealed class LoadPt
{
    public double A;
    public double[] V = new double[3];
}

/// <summary>Toutes les charges d'une barre pour un cas donné, exprimées en axes locaux.</summary>
public sealed class LocalLoads
{
    public List<LoadSeg> Segs { get; } = new();
    public List<LoadPt> Forces { get; } = new();
    public List<LoadPt> Moments { get; } = new();
    public double Dt, Dg;
}

/// <summary>Charges sur barre : conversion en axes locaux, forces d'encastrement parfait (charges nodales équivalentes),
/// cumuls pour les efforts intérieurs, abscisses des sections de calcul.</summary>
public static class LoadMath
{
    private const double Eps = 1e-9;

    public static double Pos(MemberLoad l, double v, double L) => Math.Max(0, Math.Min(L, l.Relative ? v * L : v));

    public static double[] ToLocal(double[,] R, double x, double y, double z) => new[]
    {
        R[0, 0] * x + R[0, 1] * y + R[0, 2] * z,
        R[1, 0] * x + R[1, 1] * y + R[1, 2] * z,
        R[2, 0] * x + R[2, 1] * y + R[2, 2] * z,
    };

    public static double[] ToGlobal(double[,] R, double lx, double ly, double lz) => new[]
    {
        R[0, 0] * lx + R[1, 0] * ly + R[2, 0] * lz,
        R[0, 1] * lx + R[1, 1] * ly + R[2, 1] * lz,
        R[0, 2] * lx + R[1, 2] * ly + R[2, 2] * lz,
    };

    private static double[] Vec(MemberLoad l, double[,] R, double x, double y, double z) =>
        l.Frame == LoadFrame.Local ? new[] { x, y, z } : ToLocal(R, x, y, z);

    /// <summary>Intensité GLOBALE d'une charge répartie au début (end = false) ou à la fin (end = true) de son étendue.</summary>
    public static double[] GlobalIntensity(MemberLoad l, double[,] R, bool end)
    {
        double x = l.Wx, y = l.Wy, z = l.Wz;
        if (end && l.Kind == MemberLoadKind.Trapezoid) { x = l.Wx2; y = l.Wy2; z = l.Wz2; }
        return l.Frame == LoadFrame.Local ? ToGlobal(R, x, y, z) : new[] { x, y, z };
    }

    /// <summary>Convertit les charges d'une barre (déjà filtrées par cas) en description locale.</summary>
    public static LocalLoads ToLocalLoads(IEnumerable<MemberLoad> loads, double L, double[,] R)
    {
        var ll = new LocalLoads();
        foreach (var l in loads)
        {
            switch (l.Kind)
            {
                case MemberLoadKind.Uniform:
                {
                    var q = Vec(l, R, l.Wx, l.Wy, l.Wz);
                    ll.Segs.Add(new LoadSeg { A = 0, B = L, Q1 = q, Q2 = (double[])q.Clone() });
                    break;
                }
                case MemberLoadKind.Trapezoid:
                {
                    double a = Pos(l, l.A, L), b = Pos(l, l.B, L);
                    var q1 = Vec(l, R, l.Wx, l.Wy, l.Wz); var q2 = Vec(l, R, l.Wx2, l.Wy2, l.Wz2);
                    if (b < a) { (a, b) = (b, a); (q1, q2) = (q2, q1); }
                    if (b - a < Eps) break;
                    ll.Segs.Add(new LoadSeg { A = a, B = b, Q1 = q1, Q2 = q2 });
                    break;
                }
                case MemberLoadKind.Point:
                    ll.Forces.Add(new LoadPt { A = Pos(l, l.A, L), V = Vec(l, R, l.Px, l.Py, l.Pz) });
                    break;
                case MemberLoadKind.Moment:
                    ll.Moments.Add(new LoadPt { A = Pos(l, l.A, L), V = Vec(l, R, l.Mx, l.My, l.Mz) });
                    break;
                case MemberLoadKind.Thermal:
                    ll.Dt += l.Dt; ll.Dg += l.Dg;
                    break;
            }
        }
        return ll;
    }

    // ------------------------------------------------------------------ fonctions de forme de la poutre (Hermite)
    private static void Shape(double xi, double L, out double n1, out double n2, out double n3, out double n4)
    {
        double x2 = xi * xi, x3 = x2 * xi;
        n1 = 1 - 3 * x2 + 2 * x3; n2 = L * (xi - 2 * x2 + x3); n3 = 3 * x2 - 2 * x3; n4 = L * (-x2 + x3);
    }

    private static void ShapeD(double xi, double L, out double d1, out double d2, out double d3, out double d4)
    {
        double x2 = xi * xi;
        d1 = (-6 * xi + 6 * x2) / L; d2 = 1 - 4 * xi + 3 * x2; d3 = (6 * xi - 6 * x2) / L; d4 = -2 * xi + 3 * x2;
    }

    private static readonly double[] GX = { -0.8611363115940526, -0.3399810435848563, 0.3399810435848563, 0.8611363115940526 };
    private static readonly double[] GW = { 0.3478548451374538, 0.6521451548625461, 0.6521451548625461, 0.3478548451374538 };

    /// <summary>Charges nodales équivalentes (repère local, 12 ddl) de toutes les charges de la barre : intégrales des fonctions de forme.
    /// E, A, Iy, h, alpha : propriétés pour les effets thermiques.</summary>
    public static double[] FixedEnd(LocalLoads ll, double L, double E, double A, double Iy, double h, double alpha)
    {
        var f = new double[12];
        foreach (var s in ll.Segs)
        {
            double len = s.B - s.A;
            for (int g = 0; g < 4; g++)
            {
                double x = s.A + len * (GX[g] + 1) / 2, w = GW[g] * len / 2;
                double t = (x - s.A) / len, xi = x / L;
                Shape(xi, L, out double n1, out double n2, out double n3, out double n4);
                double qx = s.Q1[0] + (s.Q2[0] - s.Q1[0]) * t, qy = s.Q1[1] + (s.Q2[1] - s.Q1[1]) * t, qz = s.Q1[2] + (s.Q2[2] - s.Q1[2]) * t;
                f[0] += qx * (1 - xi) * w; f[6] += qx * xi * w;
                f[1] += qy * n1 * w; f[5] += qy * n2 * w; f[7] += qy * n3 * w; f[11] += qy * n4 * w;
                f[2] += qz * n1 * w; f[4] -= qz * n2 * w; f[8] += qz * n3 * w; f[10] -= qz * n4 * w;
            }
        }
        foreach (var p in ll.Forces)
        {
            double xi = p.A / L;
            Shape(xi, L, out double n1, out double n2, out double n3, out double n4);
            f[0] += p.V[0] * (1 - xi); f[6] += p.V[0] * xi;
            f[1] += p.V[1] * n1; f[5] += p.V[1] * n2; f[7] += p.V[1] * n3; f[11] += p.V[1] * n4;
            f[2] += p.V[2] * n1; f[4] -= p.V[2] * n2; f[8] += p.V[2] * n3; f[10] -= p.V[2] * n4;
        }
        foreach (var p in ll.Moments)
        {
            double xi = p.A / L;
            ShapeD(xi, L, out double d1, out double d2, out double d3, out double d4);
            f[3] += p.V[0] * (1 - xi); f[9] += p.V[0] * xi;
            f[1] += p.V[2] * d1; f[5] += p.V[2] * d2; f[7] += p.V[2] * d3; f[11] += p.V[2] * d4;          // moment autour de z
            f[2] += p.V[1] * -d1; f[4] += p.V[1] * d2; f[8] += p.V[1] * -d3; f[10] += p.V[1] * d4;        // moment autour de y (theta_y = -w')
        }
        if (Math.Abs(ll.Dt) > 0) { double n = E * A * alpha * ll.Dt; f[0] -= n; f[6] += n; }
        if (Math.Abs(ll.Dg) > 0 && h > 1e-9) { double m = E * Iy * alpha * ll.Dg / h; f[4] -= m; f[10] += m; }
        return f;
    }

    /// <summary>Cumul des charges entre 0 et x : résultante F, moment des charges par rapport à la section x (ML), moments concentrés MP.</summary>
    public static void Cumulate(LocalLoads ll, double x, double[] F, double[] ML, double[] MP)
    {
        Array.Clear(F); Array.Clear(ML); Array.Clear(MP);
        foreach (var s in ll.Segs)
        {
            if (x <= s.A + Eps) continue;
            double T = Math.Min(x, s.B) - s.A, len = s.B - s.A;
            for (int d = 0; d < 3; d++)
            {
                double q1 = s.Q1[d], k = (s.Q2[d] - s.Q1[d]) / len;
                F[d] += q1 * T + k * T * T / 2;
                ML[d] += (x - s.A) * (q1 * T + k * T * T / 2) - (q1 * T * T / 2 + k * T * T * T / 3);
            }
        }
        foreach (var p in ll.Forces)
        {
            if (p.A > x + Eps) continue;
            for (int d = 0; d < 3; d++) { F[d] += p.V[d]; ML[d] += p.V[d] * (x - p.A); }
        }
        foreach (var p in ll.Moments)
        {
            if (p.A > x + Eps) continue;
            for (int d = 0; d < 3; d++) MP[d] += p.V[d];
        }
    }

    /// <summary>Résultante globale verticale (kN, vers le haut positif) d'une charge sur une barre : sert au poids sismique.</summary>
    public static double VerticalResultant(MemberLoad l, double L, double[,] R)
    {
        switch (l.Kind)
        {
            case MemberLoadKind.Uniform:
            {
                var g = GlobalIntensity(l, R, false);
                return g[2] * L;
            }
            case MemberLoadKind.Trapezoid:
            {
                double a = Pos(l, l.A, L), b = Pos(l, l.B, L);
                var g1 = GlobalIntensity(l, R, false); var g2 = GlobalIntensity(l, R, true);
                return (g1[2] + g2[2]) / 2 * Math.Abs(b - a);
            }
            case MemberLoadKind.Point:
                return l.Frame == LoadFrame.Local ? ToGlobal(R, l.Px, l.Py, l.Pz)[2] : l.Pz;
            default:
                return 0;
        }
    }

    /// <summary>Abscisses des n sections de calcul : régulièrement réparties, mais les sections les plus proches des charges concentrées
    /// et des extrémités de charges partielles sont placées exactement dessus (pour ne pas manquer un pic de moment).</summary>
    public static double[] StationXs(IEnumerable<MemberLoad> loads, double L, int n)
    {
        var xs = new double[n];
        for (int k = 0; k < n; k++) xs[k] = L * k / (n - 1);
        var pts = new List<double>();
        foreach (var l in loads)
        {
            switch (l.Kind)
            {
                case MemberLoadKind.Trapezoid: pts.Add(Pos(l, l.A, L)); pts.Add(Pos(l, l.B, L)); break;
                case MemberLoadKind.Point:
                case MemberLoadKind.Moment: pts.Add(Pos(l, l.A, L)); break;
            }
        }
        var pinned = new HashSet<int>();
        foreach (double p in pts.Select(v => Math.Round(v, 6)).Distinct().OrderBy(v => v).Take(n - 2))
        {
            if (p <= 1e-6 || p >= L - 1e-6) continue;
            if (xs.Any(v => Math.Abs(v - p) < 1e-6)) continue;
            int best = -1; double bd = double.MaxValue;
            for (int k = 1; k < n - 1; k++)
            {
                if (pinned.Contains(k)) continue;
                double d = Math.Abs(xs[k] - p);
                if (d < bd) { bd = d; best = k; }
            }
            if (best < 0) continue;
            xs[best] = p; pinned.Add(best);
        }
        Array.Sort(xs);
        return xs;
    }
}
