using System.Globalization;
using System.Numerics;
using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine.Drawing;

namespace StructCalc.Engine;

/// <summary>Export IFC2x3 (poutres et poteaux en extrusion de profil rectangulaire ou en I) : s'ouvre dans Revit (toutes versions récentes : Fichier > Ouvrir > IFC),
/// ArchiCAD, Tekla, BIMvision, etc. Géométrie et noms uniquement (pas d'armatures ni de propriétés de calcul).</summary>
public static class IfcWriter
{
    private static string D(double v)
    {
        string s = v.ToString("0.######", CultureInfo.InvariantCulture);
        if (s == "-0") s = "0";
        return s.Contains('.') ? s : s + ".";
    }
    private static string Str(string t) => "'" + DxfWriter.Ascii(t).Replace("'", "''") + "'";

    private static string Guid22()
    {
        const string chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$";
        byte[] b = Guid.NewGuid().ToByteArray();
        byte[] be = { b[3], b[2], b[1], b[0], b[5], b[4], b[7], b[6], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15] };
        var n = new BigInteger(be, isUnsigned: true, isBigEndian: true);
        var sb = new char[22];
        for (int i = 21; i >= 0; i--) { sb[i] = chars[(int)(n % 64)]; n /= 64; }
        return new string(sb);
    }

    public static string ToIfc(StructModel m, AnalysisOutput? o, string fileName)
    {
        var sb = new StringBuilder();
        int id = 0;
        string E(string body) { id++; sb.Append('#').Append(id).Append('=').Append(body).Append(";\r\n"); return "#" + id; }

        sb.Append("ISO-10303-21;\r\nHEADER;\r\nFILE_DESCRIPTION(('ViewDefinition [CoordinationView]'),'2;1');\r\n");
        sb.Append($"FILE_NAME({Str(fileName)},'{DateTime.Now:yyyy-MM-ddTHH:mm:ss}',({Str(AppInfo.Author)}),({Str(AppInfo.Name)}),{Str(AppInfo.Name + " " + AppInfo.Version)},{Str(AppInfo.Name)},'');\r\n");
        sb.Append("FILE_SCHEMA(('IFC2X3'));\r\nENDSEC;\r\nDATA;\r\n");

        string person = E($"IFCPERSON($,{Str("EKRESSIN")},{Str("Maximilien")},$,$,$,$,$)");
        string org = E($"IFCORGANIZATION($,{Str(AppInfo.Name)},$,$,$)");
        string pao = E($"IFCPERSONANDORGANIZATION({person},{org},$)");
        string app = E($"IFCAPPLICATION({org},{Str(AppInfo.Version)},{Str(AppInfo.Name)},{Str(AppInfo.Name)})");
        string owner = E($"IFCOWNERHISTORY({pao},{app},$,.ADDED.,$,{pao},{app},{(int)DateTimeOffset.UtcNow.ToUnixTimeSeconds()})");
        string dirX = E("IFCDIRECTION((1.,0.,0.))"), dirZ = E("IFCDIRECTION((0.,0.,1.))");
        string origin = E("IFCCARTESIANPOINT((0.,0.,0.))");
        string axis0 = E($"IFCAXIS2PLACEMENT3D({origin},{dirZ},{dirX})");
        string ctx = E($"IFCGEOMETRICREPRESENTATIONCONTEXT($,{Str("Model")},3,1.E-05,{axis0},$)");
        string u1 = E("IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.)"), u2 = E("IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.)");
        string u3 = E("IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.)"), u4 = E("IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.)");
        string units = E($"IFCUNITASSIGNMENT(({u1},{u2},{u3},{u4}))");
        string proj = E($"IFCPROJECT('{Guid22()}',{owner},{Str(m.Name)},$,$,$,$,({ctx}),{units})");
        string pl0 = E($"IFCLOCALPLACEMENT($,{axis0})");
        string site = E($"IFCSITE('{Guid22()}',{owner},{Str("Site")},$,$,{pl0},$,$,.ELEMENT.,$,$,$,$,$)");
        string pl1 = E($"IFCLOCALPLACEMENT({pl0},{axis0})");
        string bld = E($"IFCBUILDING('{Guid22()}',{owner},{Str("Batiment")},$,$,{pl1},$,$,.ELEMENT.,$,$,$)");
        string pl2 = E($"IFCLOCALPLACEMENT({pl1},{axis0})");
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var levels = nodes.Values.Select(n => Math.Round(n.Z, 3)).Distinct().OrderBy(z => z).ToList();
        if (levels.Count == 0) levels.Add(0);
        var storeys = new Dictionary<double, string>();
        foreach (double z in levels)
            storeys[z] = E($"IFCBUILDINGSTOREY('{Guid22()}',{owner},{Str("Niveau +" + D(z))},$,$,{pl2},$,$,.ELEMENT.,{D(z)})");
        E($"IFCRELAGGREGATES('{Guid22()}',{owner},$,$,{proj},({site}))");
        E($"IFCRELAGGREGATES('{Guid22()}',{owner},$,$,{site},({bld}))");
        E($"IFCRELAGGREGATES('{Guid22()}',{owner},$,$,{bld},({string.Join(",", storeys.Values)}))");

        var byStorey = storeys.Keys.ToDictionary(z => z, z => new List<string>());
        foreach (var mem in m.Members)
        {
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            double L; double[,] R;
            try { (L, R) = FrameSolver.LocalAxes(a, b, mem.Roll); } catch { continue; }
            var res = o?.Members.FirstOrDefault(r => r.MemberId == mem.Id);
            string profile;
            if (mem.Kind == MaterialKind.Steel && SteelCatalog.TryGet(res?.Profile is { Length: > 0 } ? res.Profile : mem.Profile, out var sp))
                profile = E($"IFCISHAPEPROFILEDEF(.AREA.,{Str(sp.Name)},$,{D(sp.B / 1000)},{D(sp.H / 1000)},{D(sp.Tw / 1000)},{D(sp.Tf / 1000)},{D(sp.R / 1000)})");
            else
            {
                double bw = res?.B > 0 ? res.B : mem.B, hh = res?.H > 0 ? res.H : mem.H;
                profile = E($"IFCRECTANGLEPROFILEDEF(.AREA.,{Str($"{bw * 100:0}x{hh * 100:0}")},$,{D(bw)},{D(hh)})");
            }
            string pt = E($"IFCCARTESIANPOINT(({D(a.X)},{D(a.Y)},{D(a.Z)}))");
            string zAxis = E($"IFCDIRECTION(({D(R[0, 0])},{D(R[0, 1])},{D(R[0, 2])}))");
            string xAxis = E($"IFCDIRECTION(({D(R[1, 0])},{D(R[1, 1])},{D(R[1, 2])}))");
            string ax = E($"IFCAXIS2PLACEMENT3D({pt},{zAxis},{xAxis})");
            double zl = Math.Round(Math.Min(a.Z, b.Z), 3);
            string storeyKey = storeys.Keys.OrderBy(z => Math.Abs(z - zl)).First().ToString(CultureInfo.InvariantCulture);
            double sKey = storeys.Keys.OrderBy(z => Math.Abs(z - zl)).First();
            string place = E($"IFCLOCALPLACEMENT({pl2},{ax})");
            string solidPos = E($"IFCAXIS2PLACEMENT3D({origin},{dirZ},{dirX})");
            string solid = E($"IFCEXTRUDEDAREASOLID({profile},{solidPos},{dirZ},{D(L)})");
            string rep = E($"IFCSHAPEREPRESENTATION({ctx},{Str("Body")},{Str("SweptSolid")},({solid}))");
            string shape = E($"IFCPRODUCTDEFINITIONSHAPE($,$,({rep}))");
            string name = (mem.Type == MemberType.Column ? "P" : "B") + mem.Id;
            string desc = res != null ? res.Summary : $"{mem.B * 100:0}x{mem.H * 100:0}";
            string kind = mem.Type == MemberType.Column ? "IFCCOLUMN" : "IFCBEAM";
            string el = E($"{kind}('{Guid22()}',{owner},{Str(name)},{Str(desc)},$,{place},{shape},$)");
            byStorey[sKey].Add(el);
        }
        foreach (var kv in byStorey.Where(k => k.Value.Count > 0))
            E($"IFCRELCONTAINEDINSPATIALSTRUCTURE('{Guid22()}',{owner},$,$,({string.Join(",", kv.Value)}),{storeys[kv.Key]})");
        sb.Append("ENDSEC;\r\nEND-ISO-10303-21;\r\n");
        return sb.ToString();
    }

    public static void Save(StructModel m, AnalysisOutput? o, string path) =>
        File.WriteAllText(path, ToIfc(m, o, System.IO.Path.GetFileName(path)), Encoding.ASCII);
}
