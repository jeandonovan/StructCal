using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public sealed class FrameSpec
{
    public int BaysX { get; set; } = 2;
    public int BaysY { get; set; } = 0;            // 0 = portique plan (plan XZ)
    public int Storeys { get; set; } = 2;
    public double SpanX { get; set; } = 5.0;
    public double SpanY { get; set; } = 5.0;
    public double StoreyHeight { get; set; } = 3.2;
    public bool Steel { get; set; } = false;
    public double ColB { get; set; } = 0.30;
    public double ColH { get; set; } = 0.30;
    public double BeamB { get; set; } = 0.25;
    public double BeamH { get; set; } = 0.45;
    public string ColProfile { get; set; } = "HEA240";
    public string BeamProfile { get; set; } = "IPE300";
    public double G { get; set; } = 18;            // kN/m sur chaque poutre (hors poids propre)
    public double Q { get; set; } = 6;
    public bool FixedBase { get; set; } = true;
}

/// <summary>Assistant : génère une ossature régulière (poteaux + poutres, appuis, charges).</summary>
public static class FrameGenerator
{
    public static StructModel Generate(FrameSpec s)
    {
        if (s.BaysX < 1 || s.Storeys < 1 || s.SpanX <= 0 || s.StoreyHeight <= 0) throw new ArgumentException("Paramètres d'ossature invalides.");
        var m = new StructModel { Name = $"Ossature {s.BaysX}x{Math.Max(1, s.BaysY)} travées, {s.Storeys} niveaux" };
        int nx = s.BaysX + 1, ny = s.BaysY + 1, nz = s.Storeys + 1;
        var id = new int[nx, ny, nz];
        int nid = 1;
        for (int k = 0; k < nz; k++)
            for (int j = 0; j < ny; j++)
                for (int i = 0; i < nx; i++)
                {
                    m.Nodes.Add(new Node { Id = nid, X = i * s.SpanX, Y = j * s.SpanY, Z = k * s.StoreyHeight });
                    id[i, j, k] = nid++;
                }
        int mid = 1;
        MaterialKind kind = s.Steel ? MaterialKind.Steel : MaterialKind.ReinforcedConcrete;
        for (int k = 0; k < s.Storeys; k++)
            for (int j = 0; j < ny; j++)
                for (int i = 0; i < nx; i++)
                    m.Members.Add(new Member
                    {
                        Id = mid++, NodeI = id[i, j, k], NodeJ = id[i, j, k + 1], Type = MemberType.Column, Kind = kind,
                        B = s.ColB, H = s.ColH, Cover = 0.04, Profile = s.Steel ? s.ColProfile : "", LfFactor = s.Steel ? 1.0 : 0.7
                    });
        void Beam(int a, int b)
        {
            int bid = mid++;
            m.Members.Add(new Member
            {
                Id = bid, NodeI = a, NodeJ = b, Type = MemberType.Beam, Kind = kind, B = s.BeamB, H = s.BeamH, Cover = 0.05,
                Profile = s.Steel ? s.BeamProfile : "", LfFactor = 1.0
            });
            if (s.G != 0) m.MemberLoads.Add(new MemberLoad { MemberId = bid, Case = ActionType.G, Wz = -Math.Abs(s.G) });
            if (s.Q != 0) m.MemberLoads.Add(new MemberLoad { MemberId = bid, Case = ActionType.Q, Wz = -Math.Abs(s.Q) });
        }
        for (int k = 1; k < nz; k++)
            for (int j = 0; j < ny; j++)
                for (int i = 0; i < nx; i++)
                {
                    if (i < nx - 1) Beam(id[i, j, k], id[i + 1, j, k]);
                    if (s.BaysY > 0 && j < ny - 1) Beam(id[i, j, k], id[i, j + 1, k]);
                }
        for (int j = 0; j < ny; j++)
            for (int i = 0; i < nx; i++)
                m.Supports.Add(s.FixedBase
                    ? new SupportDef { NodeId = id[i, j, 0] }
                    : new SupportDef { NodeId = id[i, j, 0], Rx = false, Ry = false, Rz = false });
        if (s.Steel) m.SteelCodeId = "EC3";
        return m;
    }
}
