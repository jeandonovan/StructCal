using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Core.Steel;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine.Results;

/// <summary>Filtre commun des tableaux : niveau, type d'élément, matériau.</summary>
public sealed class ResultFilter
{
    public string Level = "";                 // "" = tous
    public MemberType? Type;
    public MaterialKind? Kind;
    public bool Accept(Member mem, StructureInfo info)
    {
        if (Type != null && mem.Type != Type) return false;
        if (Kind != null && mem.Kind != Kind) return false;
        if (Level != "" && info.LevelOfMember(mem.Id)?.Name != Level) return false;
        return true;
    }
}

/// <summary>Une entrée du catalogue de tableaux de l'explorateur de résultats.</summary>
public sealed class TableSpec
{
    public string Group = "", Name = "";
    public Func<TableData> Build = () => new TableData("");
    public override string ToString() => Name;
}

public static partial class ResultTables
{
    private static string Lv(StructureInfo info, double z) { int i = info.LevelAtZ(z); return i >= 0 && i < info.Levels.Count ? info.Levels[i].Name : ""; }

    private static string Status(double ratio, bool ok = true)
    {
        if (double.IsNaN(ratio)) return ok ? "Vérifié" : "Non vérifié";
        if (ratio > 1.0 + 1e-9 || !ok) return "Non vérifié";
        return ratio >= 0.95 ? "À la limite" : "Vérifié";
    }

    private static readonly string[] Comp = { "Fx", "Fy", "Fz", "Mx", "My", "Mz" };

    // ------------------------------------------------------------------ 1. réactions
    public static TableData Reactions(StructModel m, ResultsStore st, string source)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData($"Réactions d'appui - {source}", "Nœud", "Axes", "Niveau", "Appui");
        foreach (var c in Comp) { t.Headers.Add(c + " max"); t.Headers.Add("Combinaison " + c + " max"); t.Headers.Add(c + " min"); t.Headers.Add("Combinaison " + c + " min"); }
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        foreach (var r in st.Reactions(source))
        {
            nodes.TryGetValue(r.NodeId, out var nd);
            var sup = m.Supports.FirstOrDefault(s => s.NodeId == r.NodeId);
            var row = new List<object?> { r.NodeId, nd == null ? "" : info.AxisRef(nd.X, nd.Y), nd == null ? "" : Lv(info, nd.Z), SupportName(sup) };
            for (int i = 0; i < 6; i++) { row.Add(Math.Round(r.Max[i], 2)); row.Add(r.MaxCombo[i]); row.Add(Math.Round(r.Min[i], 2)); row.Add(r.MinCombo[i]); }
            t.Add(row.ToArray());
        }
        t.Notes.Add("Fx, Fy, Fz en kN ; Mx, My, Mz en kN.m. Pour un cas ou une combinaison isolée, max = min. La combinaison indiquée est celle qui produit l'extrême.");
        t.Notes.Add("Les réactions servent directement au prédimensionnement des fondations (Fz max = charge à reprendre par la semelle).");
        return t;
    }

    private static string SupportName(SupportDef? s)
    {
        if (s == null) return "Appui élastique / sol";
        bool tr = s.Ux && s.Uy && s.Uz, rot = s.Rx && s.Ry && s.Rz;
        if (tr && rot) return "Encastrement";
        if (tr && !s.Rx && !s.Ry && !s.Rz) return "Articulation";
        if (tr) return "Appui partiel (rotation)";
        return "Appui simple / glissant";
    }

    /// <summary>Réaction totale de la structure pour chaque cas et chaque combinaison (somme des appuis, simultanée).</summary>
    public static TableData TotalReactions(StructModel m, ResultsStore st)
    {
        var t = new TableData("Réaction totale de la structure", "Source", "ΣFx (kN)", "ΣFy (kN)", "ΣFz (kN)", "ΣMx (kN.m)", "ΣMy (kN.m)", "ΣMz (kN.m)");
        var ids = st.Cases.Values.SelectMany(c => c.Reactions.Keys).Distinct().ToList();
        foreach (var kv in st.Cases.OrderBy(k => k.Key))
        {
            var s = new double[6];
            foreach (var v in kv.Value.Reactions.Values) for (int i = 0; i < 6 && i < v.Length; i++) s[i] += v[i];
            t.Add("Cas " + kv.Key, R(s[0]), R(s[1]), R(s[2]), R(s[3]), R(s[4]), R(s[5]));
        }
        foreach (var c in st.Combos)
        {
            var s = new double[6];
            foreach (int id in ids) { var v = ResultsStore.CombineNode(c, st.Cases, cr => cr.Reactions, id); for (int i = 0; i < 6; i++) s[i] += v[i]; }
            t.Add(c.Name, R(s[0]), R(s[1]), R(s[2]), R(s[3]), R(s[4]), R(s[5]));
        }
        t.Notes.Add("Moments d'appui sommés sans transport des forces : ΣM n'est pas le moment à la base du bâtiment (voir Sismique).");
        return t;
    }

    private static double R(double v) => Math.Round(v, 2);

    /// <summary>Réactions par niveau d'appui ou par type d'appui : somme simultanée dans une même combinaison, extrêmes sur l'enveloppe ELU.</summary>
    public static TableData ReactionsGrouped(StructModel m, ResultsStore st, bool byLevel)
    {
        var info = StructureAnalyzer.Analyze(m);
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        string Key(int id)
        {
            if (!nodes.TryGetValue(id, out var nd)) return "?";
            if (byLevel) { string l = Lv(info, nd.Z); return l == "" ? $"Z = {nd.Z:0.00} m" : l; }
            return SupportName(m.Supports.FirstOrDefault(s => s.NodeId == id));
        }
        var ids = st.Cases.Values.SelectMany(c => c.Reactions.Keys).Distinct().ToList();
        var groups = ids.GroupBy(Key).OrderBy(g => g.Key).ToList();
        var t = new TableData(byLevel ? "Réactions par niveau (enveloppe ELU)" : "Réactions par type d'appui (enveloppe ELU)",
            byLevel ? "Niveau" : "Type d'appui", "Nb appuis", "ΣFz max (kN)", "Combinaison", "ΣFz min (kN)", "Combinaison", "ΣFx max", "ΣFx min", "ΣFy max", "ΣFy min");
        foreach (var g in groups)
        {
            double fzMax = double.MinValue, fzMin = double.MaxValue, fxMax = double.MinValue, fxMin = double.MaxValue, fyMax = double.MinValue, fyMin = double.MaxValue;
            string cMax = "", cMin = "";
            foreach (var c in st.Uls)
            {
                double fx = 0, fy = 0, fz = 0;
                foreach (int id in g) { var v = ResultsStore.CombineNode(c, st.Cases, cr => cr.Reactions, id); fx += v[0]; fy += v[1]; fz += v[2]; }
                if (fz > fzMax) { fzMax = fz; cMax = c.Name; }
                if (fz < fzMin) { fzMin = fz; cMin = c.Name; }
                fxMax = Math.Max(fxMax, fx); fxMin = Math.Min(fxMin, fx); fyMax = Math.Max(fyMax, fy); fyMin = Math.Min(fyMin, fy);
            }
            if (fzMax == double.MinValue) { fzMax = fzMin = fxMax = fxMin = fyMax = fyMin = 0; }
            t.Add(g.Key, g.Count(), R(fzMax), cMax, R(fzMin), cMin, R(fxMax), R(fxMin), R(fyMax), R(fyMin));
        }
        return t;
    }

    // ------------------------------------------------------------------ 2. efforts des barres
    public static TableData MemberForces(StructModel m, ResultsStore st, string source, ResultFilter f)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData($"Efforts des barres - {source}", "Barre", "Type", "Matériau", "Section", "Niveau", "Grandeur", "Unité",
            "Maximum", "Position (m)", "Combinaison max", "Minimum", "Position (m)", "Combinaison min");
        foreach (var mem in m.Members.Where(x => f.Accept(x, info)))
        {
            string sec = mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}";
            foreach (ForceQty q in Enum.GetValues(typeof(ForceQty)))
            {
                var s = st.Series(source, mem.Id, q);
                if (s.X.Length == 0) continue;
                int a = s.IndexOfMax(), b = s.IndexOfMin();
                t.Add(mem.Id, mem.Type == MemberType.Column ? "Poteau" : "Poutre", mem.Kind == MaterialKind.Steel ? "Acier" : "Béton armé", sec, info.LevelOfMember(mem.Id)?.Name ?? "",
                      ResultsStore.QtyName(q), ResultsStore.QtyUnit(q), R(s.Max[a]), R(s.X[a]), s.MaxCombo[a], R(s.Min[b]), R(s.X[b]), s.MinCombo[b]);
            }
        }
        t.Notes.Add("N : traction positive, compression négative. My > 0 : fibre supérieure tendue (appui), My < 0 : travée. Vy, Vz, T, My, Mz selon les axes locaux de la barre.");
        return t;
    }

    /// <summary>Enveloppe de chaque barre sur l'ensemble des combinaisons ELU : effort normal, tranchants, torsion, moments, flèche, avec la combinaison responsable.</summary>
    public static TableData Envelopes(StructModel m, AnalysisOutput o, ResultsStore st, ResultFilter f)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData("Enveloppes ELU par barre", "Barre", "Type", "Section", "N max (traction)", "N min (compression)", "|Vy| max", "|Vz| max", "|T| max",
            "M+ travée (-My min)", "M- appui (My max)", "|Mz| max", "Flèche max (mm)", "Combinaison flèche", "Combinaison N min", "Combinaison Vz", "Combinaison M appui");
        foreach (var mem in m.Members.Where(x => f.Accept(x, info)))
        {
            ForceSeries S(ForceQty q) => st.Series(ResultsStore.EnvUls, mem.Id, q);
            var n = S(ForceQty.N); if (n.X.Length == 0) continue;
            var vy = S(ForceQty.Vy); var vz = S(ForceQty.Vz); var tt = S(ForceQty.T); var my = S(ForceQty.My); var mz = S(ForceQty.Mz);
            int iN = n.IndexOfMin(), iV = vz.Max.Length == 0 ? 0 : (vz.AbsMax == vz.Max.Max() ? vz.IndexOfMax() : vz.IndexOfMin());
            var defl = o.Global?.Deflections.FirstOrDefault(d => d.MemberId == mem.Id);
            string sec = mem.Kind == MaterialKind.Steel ? mem.Profile : $"{mem.B * 100:0}x{mem.H * 100:0}";
            t.Add(mem.Id, mem.Type == MemberType.Column ? "Poteau" : "Poutre", sec, R(n.Max.Max()), R(n.Min.Min()), R(vy.AbsMax), R(vz.AbsMax), R(tt.AbsMax),
                  R(-my.Min.Min()), R(my.Max.Max()), R(mz.AbsMax), defl == null ? null : R(defl.DeltaMm), defl?.Combo ?? "",
                  n.MinCombo[iN], vz.Max.Length == 0 ? "" : (vz.MaxCombo[iV] == "" ? vz.MinCombo[iV] : vz.MaxCombo[iV]), my.MaxCombo[my.IndexOfMax()]);
        }
        t.Notes.Add("Le ferraillage est calculé à partir de ces enveloppes (toutes les combinaisons ELU/accidentelles), et non d'une seule combinaison.");
        return t;
    }

    // ------------------------------------------------------------------ 3. déplacements
    public static TableData Displacements(StructModel m, ResultsStore st, string source)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData($"Déplacements nodaux - {source}", "Nœud", "Axes", "Niveau", "ux (mm)", "uy (mm)", "uz (mm)", "θx (mrad)", "θy (mrad)", "θz (mrad)", "Total (mm)", "Combinaison");
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        foreach (var d in st.Displacements(source))
        {
            nodes.TryGetValue(d.NodeId, out var nd);
            double tot = Math.Sqrt(d.U[0] * d.U[0] + d.U[1] * d.U[1] + d.U[2] * d.U[2]) * 1000;
            t.Add(d.NodeId, nd == null ? "" : info.AxisRef(nd.X, nd.Y), nd == null ? "" : Lv(info, nd.Z), Math.Round(d.U[0] * 1000, 3), Math.Round(d.U[1] * 1000, 3), Math.Round(d.U[2] * 1000, 3),
                  Math.Round(d.U[3] * 1000, 3), Math.Round(d.U[4] * 1000, 3), Math.Round(d.U[5] * 1000, 3), Math.Round(tot, 3), d.Combo);
        }
        t.Notes.Add("Sur une enveloppe, chaque nœud est donné dans la combinaison où son déplacement est le plus grand. Pour un mode propre : forme normalisée à 10 mm (pas d'amplitude réelle).");
        return t;
    }

    public static TableData Deflections(StructModel m, AnalysisOutput o)
    {
        var t = new TableData("Flèches des poutres (ELS)", "Barre", "Portée (m)", "Flèche (mm)", "Limite (mm)", "L / flèche", "Taux flèche/limite", "Combinaison", "Position", "Statut");
        if (o.Global != null)
            foreach (var d in o.Global.Deflections.OrderByDescending(x => x.LimitMm > 0 ? x.DeltaMm / x.LimitMm : 0))
            {
                double ratio = d.LimitMm > 0 ? d.DeltaMm / d.LimitMm : 0;
                t.Add(d.MemberId, R(d.LengthM), R(d.DeltaMm), R(d.LimitMm), double.IsInfinity(d.Ratio) ? null : Math.Round(d.Ratio, 0), Math.Round(ratio, 2), d.Combo, "relative à la corde, entre appuis", Status(ratio, d.Ok));
            }
        t.Notes.Add("Flèche relative entre les deux extrémités de la barre (corde), valeur la plus défavorable sur les combinaisons ELS. Voir aussi la flèche calculée par la méthode BAEL/EC2 dans les vérifications complémentaires.");
        return t;
    }

    public static TableData Storeys(StructModel m, AnalysisOutput o, ResultsStore st, string source)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData($"Déplacements d'étage - {source}", "Niveau", "Z (m)", "Déplacement latéral ux max (mm)", "uy max (mm)", "Déplacement inter-étage max (mm)", "Hauteur d'étage (m)", "h / δ", "Limite h/…", "Base", "Combinaison", "Statut");
        var disp = st.Displacements(source).ToDictionary(d => d.NodeId);
        foreach (var lv in info.Levels)
        {
            double ux = 0, uy = 0;
            foreach (int id in lv.NodeIds) if (disp.TryGetValue(id, out var d)) { ux = Math.Max(ux, Math.Abs(d.U[0])); uy = Math.Max(uy, Math.Abs(d.U[1])); }
            var dr = o.Global?.Drifts.Where(x => x.Level == lv.Name).OrderBy(x => x.Ratio).FirstOrDefault();
            t.Add(lv.Name, R(lv.Z), R(ux * 1000), R(uy * 1000), dr == null ? null : R(dr.DeltaMm), dr == null ? null : R(dr.HeightM),
                  dr == null || double.IsInfinity(dr.Ratio) ? null : Math.Round(dr.Ratio, 0), dr?.LimitDenominator, dr?.Basis ?? "", dr?.Combo ?? "", dr == null ? "" : Status(dr.DeltaMm / Math.Max(dr.HeightM * 1000 / dr.LimitDenominator, 1e-9), dr.Ok));
        }
        t.Notes.Add("Inter-étage : poteaux entre deux niveaux consécutifs ; limite h/500 en service, h/100 sous séisme (RPA 99 : 1 % de la hauteur d'étage).");
        return t;
    }

    // ------------------------------------------------------------------ 4. contraintes des barres
    private static (double A, double Iy, double Iz, double HalfZ, double HalfY) Props(Member mem)
    {
        double A = mem.PropA > 0 ? mem.PropA : mem.B * mem.H;
        double Iy = mem.PropIy > 0 ? mem.PropIy : mem.B * Math.Pow(mem.H, 3) / 12.0;
        double Iz = mem.PropIz > 0 ? mem.PropIz : mem.H * Math.Pow(mem.B, 3) / 12.0;
        double hz = mem.H / 2, hy = mem.B / 2;
        if (mem.Kind != MaterialKind.ReinforcedConcrete && mem.PropA <= 0 && SteelCatalog.TryGet(mem.Profile, out var p))
        { A = p.A; Iy = p.Iy; Iz = p.Iz; hz = p.H / 2000.0; hy = p.B / 2000.0; }
        return (A, Iy, Iz, hz, hy);
    }

    /// <summary>Section rectangulaire fissurée en flexion composée (BAEL B.6 / EC2 7.2, coefficient d'équivalence n) : profondeur de l'axe neutre y, contrainte du béton comprimé et de l'acier tendu.
    /// Unités : m, kN, kN.m ; contraintes en kN/m². nc : effort normal de compression (&gt; 0), M &gt; 0 : fibre comprimée en haut ; as1 : armatures tendues (profondeur c1), as2 : comprimées (c2).
    /// Retourne null si la section n'est pas fissurée (axe neutre hors de la section).</summary>
    public static (double Sc, double Ss, double Y)? CrackedStress(double b, double h, double c1, double c2, double as1, double as2, double n, double nc, double M)
    {
        if (b <= 0 || h <= 0 || as1 + as2 <= 0 || c1 <= 0 || c1 >= h) return null;
        (double Sn, double Sm) S(double y)
        {
            double a2 = n * as2 * (y - c2), a1 = n * as1 * (y - c1);
            return (b * y * y / 2 + a2 + a1, b * y * y / 2 * (h / 2 - y / 3) + a2 * (h / 2 - c2) + a1 * (h / 2 - c1));
        }
        double G(double y) { var (sn, sm) = S(y); return M * sn - nc * sm; }
        double lo = 0.02 * h, prev = G(lo), yRoot = double.NaN;
        const int steps = 400;
        for (int i = 1; i <= steps; i++)
        {
            double y = 0.02 * h + (h - 0.02 * h) * i / steps, g = G(y);
            if (prev == 0 || prev * g < 0)
            {
                double a = y - (h - 0.02 * h) / steps, bb = y;
                for (int it = 0; it < 60; it++) { double mid = 0.5 * (a + bb); if (G(a) * G(mid) <= 0) bb = mid; else a = mid; }
                yRoot = 0.5 * (a + bb); break;
            }
            prev = g;
        }
        if (double.IsNaN(yRoot)) return null;
        var (sN, sM) = S(yRoot);
        double sc = Math.Abs(nc) > 1e-9 && Math.Abs(sN) > 1e-12 ? nc * yRoot / sN : Math.Abs(sM) > 1e-12 ? M * yRoot / sM : double.NaN;
        if (double.IsNaN(sc) || sc <= 0) return null;
        double ss = n * sc * (c1 - yRoot) / yRoot;
        return (sc, ss, yRoot);
    }

    public static TableData Stresses(StructModel m, ResultsStore st, string source, ResultFilter f, AnalysisOutput? o = null)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData($"Contraintes des barres - {source}", "Barre", "Type", "Matériau", "Section", "Niveau", "σ traction max (MPa)", "Position (m)", "Combinaison",
            "σ compression max (MPa)", "Position (m)", "Combinaison", "τ max (MPa)", "σ von Mises max (MPa)", "Limite (MPa)", "Taux",
            "σ béton, section fissurée (MPa)", "σ acier tendu, section fissurée (MPa)", "Limite acier 2/3 fe (MPa)", "Remarque");
        var combos = st.KindOf(source) == SourceKind.Case
            ? new List<Combination> { new(source, LimitState.ELS, new Dictionary<ActionType, double> { [Enum.Parse<ActionType>(source[4..])] = 1 }) }
            : source == ResultsStore.EnvUls ? st.Uls.ToList() : source == ResultsStore.EnvSls ? st.Sls.ToList() : st.Combos.Where(c => c.Name == source).ToList();
        double ft28 = 0.6 + 0.06 * m.Fc28;
        foreach (var mem in m.Members.Where(x => f.Accept(x, info)))
        {
            var (A, Iy, Iz, hz, hy) = Props(mem);
            if (A < 1e-9 || Iy < 1e-12 || Iz < 1e-12 || !st.Cases.Values.Any(c => c.Members.ContainsKey(mem.Id))) continue;
            double smax = double.MinValue, smin = double.MaxValue, tmax = 0, vm = 0, xT = 0, xC = 0; string cT = "", cC = "";
            var dr = o?.Members.FirstOrDefault(x => x.MemberId == mem.Id);
            bool rcm = mem.Kind == MaterialKind.ReinforcedConcrete && dr != null && !dr.Skipped;
            double asB = rcm ? dr!.BotN * Math.PI * dr.BotDia * dr.BotDia / 4e6 : 0, asT = rcm ? dr!.TopN * Math.PI * dr.TopDia * dr.TopDia / 4e6 : 0;      // m²
            if (rcm && mem.Type == MemberType.Column) { double tot = Math.Max(dr!.AsTop, asB * 1e4 + asT * 1e4) / 1e4; asB = asT = tot / 2; }
            double dEff = rcm ? Math.Max(mem.H - dr!.CoverM, 0.05) : 0, cEff = rcm ? Math.Max(dr!.CoverM, 0.02) : 0;
            double crSc = 0, crSs = 0; bool anyCracked = false;
            foreach (var c in combos)
                for (int k = 0; k < FrameSolver.Stations; k++)
                {
                    var s = MemberDesigner.Combine(c, st.Cases, mem.Id, k);
                    double sn = s.N / A, sb = Math.Abs(s.My) * hz / Iy + Math.Abs(s.Mz) * hy / Iz;
                    double top = (sn + sb) / 1000, bot = (sn - sb) / 1000;           // kN/m² -> MPa
                    double tau = 1.5 * Math.Max(Math.Abs(s.Vy), Math.Abs(s.Vz)) / A / 1000;
                    if (rcm && top > ft28)
                    {
                        // béton tendu au-delà de ft28 : section fissurée, contraintes recalculées avec n = 15 (flexion autour de l'axe fort)
                        bool hog = s.My > 0;                                                // fibre supérieure tendue
                        double tens = hog ? asT : asB, comp = hog ? asB : asT;
                        var cr = CrackedStress(mem.B, mem.H, dEff, cEff, tens, comp, 15, -s.N, Math.Abs(s.My));
                        if (cr != null) { anyCracked = true; crSc = Math.Max(crSc, cr.Value.Sc / 1000); crSs = Math.Max(crSs, cr.Value.Ss / 1000); }
                    }
                    if (top > smax) { smax = top; xT = s.X; cT = c.Name; }
                    if (bot < smin) { smin = bot; xC = s.X; cC = c.Name; }
                    tmax = Math.Max(tmax, tau);
                    vm = Math.Max(vm, Math.Sqrt(Math.Max(Math.Abs(top), Math.Abs(bot)) * Math.Max(Math.Abs(top), Math.Abs(bot)) + 3 * tau * tau));
                }
            if (smax == double.MinValue) continue;
            bool rc = mem.Kind == MaterialKind.ReinforcedConcrete;
            double lim = rc ? 0.6 * m.Fc28 : m.SteelFy;
            double use = rc ? -smin : vm;
            double limS = 2.0 / 3.0 * m.Fe;
            if (rc && anyCracked) use = Math.Max(crSc, 0) / 1.0;
            string rem = rc ? (anyCracked ? $"Béton tendu > ft28 = {ft28:0.0} MPa : section fissurée, contraintes recalculées (n = 15, flexion autour de l'axe fort)" : smax > ft28 ? "Béton tendu > ft28 : armatures non renseignées, section brute" : "") : "";
            t.Add(mem.Id, mem.Type == MemberType.Column ? "Poteau" : "Poutre", rc ? "Béton armé" : "Acier", rc ? $"{mem.B * 100:0}x{mem.H * 100:0}" : mem.Profile, info.LevelOfMember(mem.Id)?.Name ?? "",
                  Math.Round(smax, 2), R(xT), cT, Math.Round(smin, 2), R(xC), cC, Math.Round(tmax, 2), Math.Round(vm, 2), R(lim), Math.Round(Math.Max(Math.Max(use, 0) / lim, anyCracked ? crSs / limS : 0), 2),
                  anyCracked ? Math.Round(crSc, 2) : null, anyCracked ? Math.Round(crSs, 1) : null, rc ? R(limS) : null, rem);
        }
        t.Notes.Add("Contraintes élastiques de la section brute (N/A ± M·v/I, τ ≈ 1,5 V/A) ; si le béton est tendu au-delà de ft28, la section fissurée est recalculée (n = 15, armatures mises) : fibres supérieure et inférieure, effets de My et Mz cumulés dans le sens défavorable. Limite : 0,6 fc28 (béton, service) ou fy (acier).");
        return t;
    }

    // ------------------------------------------------------------------ 5. ferraillage
    public static TableData Reinforcement(StructModel m, AnalysisOutput o, ResultFilter f)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData("Ferraillage des barres béton armé", "Barre", "Type", "Section (cm)", "Niveau", "As travée requise (cm²)", "Barres inférieures", "As inférieure mise (cm²)",
            "As appui requise (cm²)", "Barres supérieures", "As supérieure mise (cm²)", "Cadres", "Espacement (cm)", "Espacement zone critique (cm)", "Ancrage ls (cm)", "Recouvrement lr (cm)",
            "ρ réel (%)", "ρ min (%)", "ρ max (%)", "Statut");
        double ft28 = 0.6 + 0.06 * m.Fc28;
        foreach (var r in o.Members.Where(x => x.Kind == MaterialKind.ReinforcedConcrete && !x.Skipped))
        {
            var mem = m.Members.FirstOrDefault(x => x.Id == r.MemberId); if (mem == null || !f.Accept(mem, info)) continue;
            double asBot = r.BotN * Math.PI * r.BotDia * r.BotDia / 400.0, asTop = r.TopN * Math.PI * r.TopDia * r.TopDia / 400.0;
            double d = Math.Max(r.H - r.CoverM, 0.05);
            bool col = r.Type == MemberType.Column;
            double ac = r.B * r.H * 1e4;                                        // cm²
            double asReal = col ? Math.Max(r.AsTop, asBot + asTop) : asBot;
            double rho = asReal / (col ? ac : Math.Max(r.B * d * 1e4, 1e-9)) * 100;
            double rhoMin = col ? 0.8 : 0.23 * ft28 / m.Fe * 100;
            double rhoMax = col ? 4.0 : 4.0 * r.H / d;
            int dia = Math.Max(r.BotDia, r.TopDia);
            double ls = dia * 0.1 * m.Fe / (4 * 0.6 * 1.5 * 1.5 * ft28);       // cm, φ en mm -> cm : φ·fe/(4·0,6ψ²·ft28)
            bool low = !col && r.AsBottom > asBot * 1.0001 && asBot > 0 || (!col && r.AsTop > asTop * 1.0001 && asTop > 0);
            t.Add(r.MemberId, col ? "Poteau" : "Poutre", $"{r.B * 100:0}x{r.H * 100:0}", info.LevelOfMember(r.MemberId)?.Name ?? "", R(r.AsBottom), r.BarsBottom, R(asBot),
                  R(r.AsTop), r.BarsTop, R(asTop), r.Stirrups, r.StirSpacingCm, r.NodalSpacingCm > 0 ? r.NodalSpacingCm : null, R(ls), R(ls), R(rho), R(rhoMin), R(rhoMax),
                  low ? "Non vérifié" : !r.Ok ? "Non vérifié" : rho > rhoMax ? "Non vérifié" : rho < rhoMin ? "À contrôler manuellement" : "Vérifié");
        }
        t.Notes.Add("As travée = armature inférieure requise ; As appui = chapeaux requis. ρ = As/(b·d) (poutres) ou As/(b·h) (poteaux). ρ min poutre = 0,23 ft28/fe ; ρ max = 4 % de la section. ls = φ·fe/(4·0,6·ψs²·ft28) (adhérence, indicatif) ; lr = ls.");
        return t;
    }
}
