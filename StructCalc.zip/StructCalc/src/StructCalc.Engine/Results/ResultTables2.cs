using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine.Results;

public static partial class ResultTables
{
    // ------------------------------------------------------------------ conformité (vérifié / non vérifié / à la limite / à contrôler)
    public static TableData Compliance(StructModel m, AnalysisOutput o)
    {
        var t = new TableData("Vérifications de conformité", "Vérification", "Élément", "Valeur calculée", "Limite", "Ratio", "Combinaison", "Position", "Statut");
        void Row(string chk, string elem, object? val, object? lim, double ratio, string combo, string pos, string status) =>
            t.Add(chk, elem, val, lim, double.IsNaN(ratio) ? null : Math.Round(ratio, 2), combo, pos, status);

        foreach (var r in o.Members)
        {
            string e = (r.Type == MemberType.Column ? "Poteau " : "Poutre ") + r.MemberId + " " + r.SectionText;
            if (r.Skipped) { Row("Dimensionnement", e, null, null, double.NaN, "", "", "À contrôler manuellement"); continue; }
            if (r.Kind == MaterialKind.Steel)
            {
                Row("Résistance acier (taux de travail)", e, Math.Round(r.Utilization, 2), 1.0, r.Utilization, "Enveloppe ELU", "section critique", Status(r.Utilization, r.Ok));
                continue;
            }
            double asBot = r.BotN * Math.PI * r.BotDia * r.BotDia / 400.0, asTop = r.TopN * Math.PI * r.TopDia * r.TopDia / 400.0;
            if (r.Type == MemberType.Column)
            {
                double prov = asBot + asTop;
                Row("Flexion composée N-M (armature totale, cm²)", e, R(r.AsTop), R(prov), prov > 0 ? r.AsTop / prov : double.NaN, "Enveloppe ELU", "section critique", Status(prov > 0 ? r.AsTop / prov : double.NaN, r.Ok));
                Row("Effort normal max (kN, compression)", e, R(r.NuMax), null, double.NaN, "Enveloppe ELU", "pied/tête", r.Ok ? "Vérifié" : "Non vérifié");
            }
            else
            {
                Row("Flexion - armature inférieure (cm²)", e, R(r.AsBottom), R(asBot), asBot > 0 ? r.AsBottom / asBot : double.NaN, "Enveloppe ELU", "travée", Status(asBot > 0 ? r.AsBottom / asBot : double.NaN, r.Ok));
                Row("Flexion - armature supérieure (cm²)", e, R(r.AsTop), R(asTop), asTop > 0 ? r.AsTop / asTop : double.NaN, "Enveloppe ELU", "appuis", Status(asTop > 0 ? r.AsTop / asTop : double.NaN, r.Ok));
                Row("Effort tranchant Vu (kN) - cadres", e, R(r.Vu), r.Stirrups, double.NaN, "Enveloppe ELU", "nu d'appui", r.Ok ? "Vérifié" : "Non vérifié");
            }
            foreach (var w in r.Warnings.Distinct()) Row("Avertissement", e, w, null, double.NaN, "", "", "À contrôler manuellement");
        }

        if (o.Global != null)
        {
            foreach (var d in o.Global.Deflections)
            {
                double ratio = d.LimitMm > 0 ? d.DeltaMm / d.LimitMm : 0;
                Row("Flèche (mm) - déplacement relatif", "Poutre " + d.MemberId, R(d.DeltaMm), R(d.LimitMm), ratio, d.Combo, "entre appuis", Status(ratio, d.Ok));
            }
            foreach (var d in o.Global.Drifts)
            {
                double lim = d.HeightM * 1000 / d.LimitDenominator, ratio = lim > 0 ? d.DeltaMm / lim : 0;
                Row($"Déplacement inter-étage (mm) - {d.Basis}", d.Level, R(d.DeltaMm), R(lim), ratio, d.Combo, "poteaux de l'étage", Status(ratio, d.Ok));
            }
        }
        foreach (var p in o.Punching)
        {
            Row("Poinçonnement vEd / vRd,c", $"Poteau {p.Column} / dalle {p.Slab} ({p.Position})", R(p.Util), 1.0, p.Util, "ELU (réactions de plancher)", p.Position, p.NeedsShear && p.Util <= 1 ? "À la limite" : Status(p.Util, p.Ok));
            Row("Poinçonnement vEd,0 / vRd,max", $"Poteau {p.Column} / dalle {p.Slab}", R(p.UtilMax), 1.0, p.UtilMax, "ELU", "nu du poteau", Status(p.UtilMax, p.UtilMax <= 1));
        }
        foreach (var s in o.Slabs) Row("Dalle (flexion, tranchant, flèche forfaitaire)", s.Element, null, null, double.NaN, "ELU/ELS", "", s.Ok ? "Vérifié" : "Non vérifié");
        foreach (var f in o.Footings) Row("Semelle (portance, flexion, poinçonnement)", f.Element, null, null, double.NaN, "ELU/ELS", "", f.Ok ? "Vérifié" : "Non vérifié");
        foreach (var r in o.Rafts)
        {
            double ratio = r.QAdm > 0 ? r.SigmaMax / r.QAdm : double.NaN;
            Row("Radier : capacité portante σmax (kPa)", r.Def.Name, R(r.SigmaMax), R(r.QAdm), ratio, "ELS", "sous le radier", Status(ratio, r.Ok));
            Row("Radier : tassement (mm)", r.Def.Name, R(r.SettlementMm), null, double.NaN, "ELS", "", r.Ok ? "Vérifié" : "Non vérifié");
        }
        foreach (var w in o.Walls)
        {
            double ratio = w.TauLim > 0 ? w.Tau / w.TauLim : double.NaN;
            Row("Voile : cisaillement τ (MPa)", w.Def.Name, R(w.Tau), R(w.TauLim), ratio, string.Join(", ", w.ComboNames.Take(3)), "pied de voile",
                (w.TauLim <= 0 || w.Tau <= 0) ? "À contrôler manuellement" : Status(ratio, w.Ok));   // valeurs nulles = voile non chargé / non vérifié, jamais « Vérifié »
            foreach (var wr in w.Warnings.Distinct()) Row("Voile : avertissement", w.Def.Name, wr, null, double.NaN, "", "", "À contrôler manuellement");
        }
        foreach (var x in o.Extras)
            Row("Module : " + x.Title, "", null, null, double.NaN, "", "", x.Ok ? "Vérifié" : "Non vérifié");
        foreach (var msg in o.Messages.Where(x => x.Contains("non réalisée") || x.Contains("indisponible") || x.Contains("impossible")))
            Row("Calcul non réalisé", "", msg, null, double.NaN, "", "", "À contrôler manuellement");

        t.Notes.Add("Statuts : Vérifié, À la limite (ratio ≥ 0,95), Non vérifié, À contrôler manuellement (résultat hors domaine de validité de la méthode, calcul non réalisé ou avertissement).");
        t.Notes.Add("Le ratio est valeur calculée / valeur limite (ou armature requise / armature mise). Interaction N-My-Mz des poteaux : traitée dans le dimensionnement du poteau (armature totale).");
        return t;
    }

    public static (int Ok, int Limit, int Ko, int Manual) ComplianceCounts(TableData c)
    {
        int ok = 0, lim = 0, ko = 0, man = 0;
        foreach (var r in c.Rows)
            switch (r[^1] as string) { case "Vérifié": ok++; break; case "À la limite": lim++; break; case "Non vérifié": ko++; break; default: man++; break; }
        return (ok, lim, ko, man);
    }

    // ------------------------------------------------------------------ poinçonnement
    public static TableData Punching(AnalysisOutput o)
    {
        var t = new TableData("Poinçonnement des dalles", "Poteau", "Dalle", "Position", "VEd (kN)", "β", "d (m)", "Contour du poteau u0 (m)", "Périmètre critique u1 (m)", "vEd (MPa)",
            "vRd,c (MPa)", "vRd,max (MPa)", "Taux vEd/vRd,c", "Taux vEd,0/vRd,max", "Asw (cm²/périmètre)", "Armatures de poinçonnement", "Chapiteau / épaisseur", "Règle", "Statut");
        foreach (var p in o.Punching)
        {
            string need = p.NeedsShear ? "Oui" : "Non";
            string rec = !p.Ok && p.UtilMax > 1 ? "Augmenter l'épaisseur ou ajouter un chapiteau" : p.NeedsShear ? "Armatures de poinçonnement" : "Aucune";
            t.Add(p.Column, p.Slab, p.Position, R(p.VEd), R(p.Beta), R(p.D), R(p.U0), R(p.U1), R(p.StressEd), R(p.StressRdc), R(p.StressRdMax), R(p.Util), R(p.UtilMax), R(p.AswCm2), need, rec, p.Rule, p.Ok ? (p.Util >= 0.95 ? "À la limite" : "Vérifié") : "Non vérifié");
        }
        t.Notes.Add("Le taux d'armature ρl est calculé à partir des aciers réels de la dalle : ρl = √(ρlx·ρly) (voir le détail dans le rapport du poinçonnement), jamais fixé arbitrairement.");
        return t;
    }

    // ------------------------------------------------------------------ dalles
    public static TableData Slabs(AnalysisOutput o)
    {
        var t = new TableData("Dalles : extrêmes des cartes de résultats", "Dalle", "Panneau", "Lx (m)", "Ly (m)", "h (cm)", "Maillage", "Flèche max (mm)", "Mx max (kN.m/m)", "Mx min", "My max", "My min",
            "|Mxy| max", "m1 max", "m2 min", "Vx max (kN/m)", "Vy max (kN/m)", "σ max face inf. (MPa)", "σ min (MPa)", "von Mises max (MPa)", "τ effort tranchant max (MPa)",
            "As inf. X max (cm²/m)", "As inf. Y max (cm²/m)", "As sup. X max", "As sup. Y max", "% aire à armer en haut", "Flèche admissible (mm)");
        foreach (var f in o.SlabFields)
        {
            (double Mn, double Mx) R2(SlabFieldKind k) => f.Range(k);
            double AbsMax(SlabFieldKind k) { var (a, b) = R2(k); return Math.Max(Math.Abs(a), Math.Abs(b)); }
            int top = 0, tot = 0;
            if (f.Values.TryGetValue(SlabFieldKind.Mx, out var mxv) && f.Values.TryGetValue(SlabFieldKind.My, out var myv))
                for (int i = 0; i < mxv.GetLength(0); i++) for (int j = 0; j < mxv.GetLength(1); j++) { tot++; if (mxv[i, j] < 0 || myv[i, j] < 0) top++; }
            t.Add(f.Name, f.Partial ? "Panneau" : "Dalle entière", R(f.Lx), R(f.Ly), R(f.H * 100), f.Triangulated ? "Triangulé DKT" : "Différences finies", R(R2(SlabFieldKind.Deflection).Mx),
                  R(R2(SlabFieldKind.Mx).Mx), R(R2(SlabFieldKind.Mx).Mn), R(R2(SlabFieldKind.My).Mx), R(R2(SlabFieldKind.My).Mn), R(AbsMax(SlabFieldKind.Mxy)),
                  R(R2(SlabFieldKind.M1).Mx), R(R2(SlabFieldKind.M2).Mn), R(AbsMax(SlabFieldKind.Vx)), R(AbsMax(SlabFieldKind.Vy)),
                  R(R2(SlabFieldKind.SigmaX).Mx), R(Math.Min(R2(SlabFieldKind.SigmaX).Mn, R2(SlabFieldKind.SigmaY).Mn)), R(R2(SlabFieldKind.VonMises).Mx), R(R2(SlabFieldKind.TauV).Mx),
                  R(R2(SlabFieldKind.AsXBot).Mx), R(R2(SlabFieldKind.AsYBot).Mx), R(R2(SlabFieldKind.AsXTop).Mx), R(R2(SlabFieldKind.AsYTop).Mx),
                  tot > 0 ? Math.Round(100.0 * top / tot, 0) : null, f.Span > 0 ? R(f.Span * 1000 / 250) : null);
        }
        t.Notes.Add("Mx > 0 : fibre inférieure tendue (aciers inférieurs) ; Mx < 0 : aciers supérieurs. Contraintes σ = 6m/h² de la section brute non fissurée (indicatives). Cartes complètes : liste « Carte » de l'onglet Résultats.");
        t.Notes.Add("Coupes de dalle (horizontale, verticale, oblique, bande, poteau, trémie) : onglet « Coupe de dalle » de l'explorateur.");
        return t;
    }

    /// <summary>Réactions linéiques de chaque dalle sur ses quatre bords (effort tranchant aux bords du maillage), maximum et moyenne.</summary>
    public static TableData SlabEdgeReactions(AnalysisOutput o)
    {
        var t = new TableData("Dalles : réactions linéiques sur les appuis (ELU)", "Dalle", "Bord", "Réaction max (kN/m)", "Réaction moyenne (kN/m)", "Longueur du bord (m)", "Réaction totale (kN)");
        foreach (var f in o.SlabFields)
        {
            if (!f.Values.TryGetValue(SlabFieldKind.Vx, out var vx) || !f.Values.TryGetValue(SlabFieldKind.Vy, out var vy)) continue;
            void Edge(string name, IEnumerable<double> vals, double len)
            {
                var a = vals.Select(Math.Abs).ToList(); if (a.Count == 0) return;
                t.Add(f.Name, name, R(a.Max()), R(a.Average()), R(len), R(a.Average() * len));
            }
            int nx = vx.GetLength(0), ny = vx.GetLength(1);
            Edge("X min (gauche)", Enumerable.Range(0, ny).Select(j => vx[0, j]), f.Ly);
            Edge("X max (droite)", Enumerable.Range(0, ny).Select(j => vx[nx - 1, j]), f.Ly);
            Edge("Y min (bas)", Enumerable.Range(0, nx).Select(i => vy[i, 0]), f.Lx);
            Edge("Y max (haut)", Enumerable.Range(0, nx).Select(i => vy[i, ny - 1]), f.Lx);
        }
        t.Notes.Add("Effort tranchant le long de chaque bord de la dalle (charges ELU) : charge linéique à transmettre aux poutres, voiles ou murs d'appui. Aux angles, la valeur est une approximation.");
        return t;
    }

    /// <summary>Coupe d'une carte de dalle le long d'un segment : valeurs échantillonnées sur n+1 points (NaN hors de la dalle).</summary>
    public static List<(double S, double X, double Y, double V)> SlabCut(IEnumerable<SlabField> cells, SlabFieldKind kind, double x0, double y0, double x1, double y1, int n = 120)
    {
        var list = cells.ToList();
        var res = new List<(double, double, double, double)>();
        double L = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
        for (int i = 0; i <= n; i++)
        {
            double u = (double)i / n, x = x0 + (x1 - x0) * u, y = y0 + (y1 - y0) * u, v = double.NaN;
            foreach (var f in list) { v = SlabStress.Sample(f, kind, x, y); if (!double.IsNaN(v)) break; }
            res.Add((u * L, x, y, v));
        }
        return res;
    }

    // ------------------------------------------------------------------ voiles
    public static TableData Walls(AnalysisOutput o)
    {
        var t = new TableData("Voiles et noyaux", "Voile", "Longueur (m)", "Hauteur (m)", "Épaisseur (cm)", "Maillage", "Déplacement max en tête (mm)", "Effort vertical ny le plus comprimé (kN/m)", "|nxy| max (kN/m)",
            "Moment de plaque max (kN.m/m)", "σ compression max (MPa)", "As vertical max (cm²/m)", "As horizontal max (cm²/m)", "τ (MPa)", "τ limite (MPa)", "Zones de confinement", "Statut");
        foreach (var w in o.Walls)
        {
            double ny = w.NyMin.Length == 0 ? 0 : w.NyMin.Min();
            t.Add(w.Def.Name, R(w.Def.LengthM), R(w.Def.HeightM), R(w.Def.ThicknessM * 100), w.Triangulated ? "Triangles" : "Quadrangles", R(w.MaxDispMm), R(ny), w.NxyMax.Length == 0 ? 0 : R(w.NxyMax.Max()),
                  w.MPlateMax.Length == 0 ? 0 : R(w.MPlateMax.Max()), w.SigC.Length == 0 ? 0 : R(w.SigC.Max()), w.AsV.Length == 0 ? 0 : R(w.AsV.Max()), w.AsH.Length == 0 ? 0 : R(w.AsH.Max()),
                  R(w.Tau), R(w.TauLim), w.Zones.Count, w.Ok ? "Vérifié" : "Non vérifié");
        }
        t.Notes.Add("Résultats détaillés (cartes, ferraillage, ouvertures) : fenêtre de l'assistant Voiles et rapport du voile.");
        return t;
    }

    // ------------------------------------------------------------------ séisme
    private static TableData NoStore(string title) { var t = new TableData(title, "Information"); t.Add("Résultats détaillés indisponibles : relancez le calcul (F5)."); return t; }

    public static TableData SeismicGlobal(StructModel m, AnalysisOutput o, ResultsStore? st)
    {
        if (st == null) return NoStore("Résultats sismiques");
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData("Résultats sismiques : efforts par niveau", "Niveau", "Z (m)", "Fx (kN)", "Fy (kN)", "Effort tranchant Vx (kN)", "Effort tranchant Vy (kN)", "Moment renversant Mx (kN.m)", "Moment renversant My (kN.m)", "Déplacement inter-étage (mm)", "Limite (mm)", "Statut");
        if (!m.Seismic.Enabled || st.SeismicLoads.Count == 0)
        {
            t.Notes.Add("Séisme non activé dans ce modèle (ou aucune force sismique calculée).");
            return t;
        }
        double z0 = m.Supports.Select(s => m.Nodes.FirstOrDefault(n => n.Id == s.NodeId)?.Z ?? double.MaxValue).DefaultIfEmpty(m.Nodes.Min(n => n.Z)).Min();
        var loads = st.SeismicLoads.Select(l => (z: m.Nodes.FirstOrDefault(n => n.Id == l.NodeId)?.Z ?? 0, fx: l.Fx, fy: l.Fy)).ToList();
        foreach (var lv in info.Levels)
        {
            double fx = loads.Where(l => Math.Abs(l.z - lv.Z) < 0.05).Sum(l => l.fx), fy = loads.Where(l => Math.Abs(l.z - lv.Z) < 0.05).Sum(l => l.fy);
            double vx = loads.Where(l => l.z >= lv.Z - 0.05).Sum(l => l.fx), vy = loads.Where(l => l.z >= lv.Z - 0.05).Sum(l => l.fy);
            double mx = loads.Where(l => l.z > lv.Z + 0.05).Sum(l => l.fy * (l.z - lv.Z)), my = loads.Where(l => l.z > lv.Z + 0.05).Sum(l => l.fx * (l.z - lv.Z));
            var dr = o.Global?.Drifts.FirstOrDefault(d => d.Level == lv.Name && d.Basis == "Séisme");
            t.Add(lv.Name, R(lv.Z), R(fx), R(fy), R(vx), R(vy), R(mx), R(my), dr == null ? null : R(dr.DeltaMm), dr == null ? null : R(dr.HeightM * 1000 / dr.LimitDenominator),
                  dr == null ? "" : Status(dr.DeltaMm / Math.Max(dr.HeightM * 1000 / dr.LimitDenominator, 1e-9), dr.Ok));
        }
        double bvx = loads.Sum(l => l.fx), bvy = loads.Sum(l => l.fy);
        t.Add("Base (Σ)", R(z0), null, null, R(bvx), R(bvy), R(loads.Sum(l => l.fy * (l.z - z0))), R(loads.Sum(l => l.fx * (l.z - z0))), null, null, "");
        if (st.Cases.TryGetValue(ActionType.E, out var ce))
        {
            double rx = ce.Reactions.Values.Sum(v => v[0]), ry = ce.Reactions.Values.Sum(v => v[1]);
            t.Notes.Add($"Réactions sismiques d'appui : ΣFx = {rx:0.0} kN, ΣFy = {ry:0.0} kN (équilibre avec l'effort tranchant à la base).");
        }
        t.Notes.Add($"Séisme combiné à la base : √(Vx² + Vy²) = {Math.Sqrt(bvx * bvx + bvy * bvy):0.0} kN ; règle 100 % / 30 % : Vx + 0,3 Vy = {Math.Abs(bvx) + 0.3 * Math.Abs(bvy):0.0} kN, 0,3 Vx + Vy = {0.3 * Math.Abs(bvx) + Math.Abs(bvy):0.0} kN. Le séisme est calculé dans la direction choisie du projet ; relancer avec l'autre direction pour comparer X et Y.");
        t.Notes.Add($"Effort tranchant d'un niveau = somme des forces sismiques du niveau et des niveaux supérieurs ; moment renversant pris à la cote du niveau. Direction du séisme du projet : {m.Seismic.Direction}.");
        return t;
    }

    public static TableData SeismicReactions(StructModel m, ResultsStore? st)
    {
        if (st == null || !st.Cases.TryGetValue(ActionType.E, out var ce)) return NoStore("Réactions sismiques aux appuis");
        var info = StructureAnalyzer.Analyze(m);
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var t = new TableData("Réactions sismiques aux appuis (cas E)", "Nœud", "Axes", "Fx (kN)", "Fy (kN)", "Fz (kN)", "Mx (kN.m)", "My (kN.m)", "Mz (kN.m)");
        foreach (var kv in ce.Reactions.OrderBy(k => k.Key))
        {
            nodes.TryGetValue(kv.Key, out var nd);
            var v = kv.Value.Concat(new double[6]).Take(6).ToArray();
            t.Add(kv.Key, nd == null ? "" : info.AxisRef(nd.X, nd.Y), R(v[0]), R(v[1]), R(v[2]), R(v[3]), R(v[4]), R(v[5]));
        }
        return t;
    }

    public static TableData SeismicEccentricity(StructModel m)
    {
        var info = StructureAnalyzer.Analyze(m);
        var t = new TableData("Excentricité masse / rigidité et torsion d'étage", "Niveau", "Poids (kN)", "Centre de masse X", "Y", "Centre de rigidité X", "Y", "e0x (m)", "e0y (m)",
            "Dimension Lx (m)", "Ly (m)", "e accidentelle 5 % (m)", "Poteaux", "Voiles", "Rayon de torsion / dimension", "Remarque");
        Dictionary<int, double> w;
        try { w = ModalAnalysis.NodalWeights(m, m.Seismic.PsiE); } catch { w = new(); }
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        double E = m.EcKNm2, G = E / 2.4;
        foreach (var lv in info.Levels)
        {
            var ln = lv.NodeIds.Where(nodes.ContainsKey).Select(i => nodes[i]).ToList();
            if (ln.Count == 0) continue;
            double W = 0, cx = 0, cy = 0;
            foreach (var n in ln) if (w.TryGetValue(n.Id, out double wi)) { W += wi; cx += wi * n.X; cy += wi * n.Y; }
            if (W < 1e-9) { W = 0; cx = ln.Average(n => n.X); cy = ln.Average(n => n.Y); } else { cx /= W; cy /= W; }
            // raideurs de translation selon X (kx) et Y (ky) avec leur position : poteaux (isotropes) et voiles (dans leur plan)
            var items = new List<(double X, double Y, double Kx, double Ky)>();
            int nCol = 0, nWall = 0;
            foreach (int cid in lv.ColumnIds)
            {
                var c = m.Members.FirstOrDefault(x => x.Id == cid); if (c == null || !nodes.TryGetValue(c.NodeI, out var a) || !nodes.TryGetValue(c.NodeJ, out var b)) continue;
                double L = Math.Max(Math.Abs(a.Z - b.Z), 0.5);
                double Iy = c.PropIy > 0 ? c.PropIy : c.B * Math.Pow(c.H, 3) / 12, Iz = c.PropIz > 0 ? c.PropIz : c.H * Math.Pow(c.B, 3) / 12;
                double k = 12 * E * Math.Sqrt(Iy * Iz) / (L * L * L);
                items.Add(((a.X + b.X) / 2, (a.Y + b.Y) / 2, k, k)); nCol++;
            }
            foreach (var wl in m.Walls)
            {
                double top = wl.Z + wl.HeightM;
                if (Math.Abs(top - lv.Z) > 0.3) continue;
                double th = wl.AngleDeg * Math.PI / 180, cs = Math.Cos(th), sn = Math.Sin(th);
                double Lw = wl.LengthM, tw = wl.ThicknessM, h = Math.Max(wl.HeightM, 0.5);
                double I = tw * Lw * Lw * Lw / 12, A = tw * Lw;
                double kin = 1.0 / (h * h * h / (3 * E * I) + 1.2 * h / (G * A));        // flexion + cisaillement dans le plan
                items.Add((wl.X + Lw / 2 * cs, wl.Y + Lw / 2 * sn, kin * cs * cs, kin * sn * sn)); nWall++;
            }
            double sKx = items.Sum(i => i.Kx), sKy = items.Sum(i => i.Ky);
            double crx = sKy > 0 ? items.Sum(i => i.Ky * i.X) / sKy : double.NaN;           // la position en X du centre de rigidité est pondérée par les raideurs opposant le mouvement en Y
            double cry = sKx > 0 ? items.Sum(i => i.Kx * i.Y) / sKx : double.NaN;
            double lx = ln.Max(n => n.X) - ln.Min(n => n.X), ly = ln.Max(n => n.Y) - ln.Min(n => n.Y);
            // rayon de torsion : rigidité de torsion / rigidité de translation
            double rt = double.NaN;
            if (!double.IsNaN(crx) && !double.IsNaN(cry) && sKx + sKy > 0)
            {
                double kt = items.Sum(i => i.Kx * (i.Y - cry) * (i.Y - cry) + i.Ky * (i.X - crx) * (i.X - crx));
                rt = Math.Sqrt(kt / Math.Max(Math.Min(sKx, sKy), 1e-9));
            }
            t.Add(lv.Name, R(W), R(cx), R(cy), double.IsNaN(crx) ? null : R(crx), double.IsNaN(cry) ? null : R(cry), double.IsNaN(crx) ? null : R(Math.Abs(cx - crx)), double.IsNaN(cry) ? null : R(Math.Abs(cy - cry)),
                  R(lx), R(ly), R(0.05 * Math.Max(lx, ly)), nCol, nWall, double.IsNaN(rt) ? null : R(rt / Math.Max(Math.Max(lx, ly), 1e-9)), items.Count > 0 ? "" : "Aucun élément porteur sous ce niveau");
        }
        t.Notes.Add("Centre de rigidité : raideur des poteaux (12·E·√(Iy·Iz)/h³, isotrope) et des voiles dans leur plan (flexion + cisaillement, orientés selon leur angle) ; murs de façade non modélisés ignorés.");
        t.Notes.Add("Moment de torsion d'étage ≈ V·(e0 + e accidentelle). Rayon de torsion / dimension en plan : valeur faible (< 0,3) = bâtiment sensible à la torsion.");
        return t;
    }

    /// <summary>Séisme statique équivalent dans les deux directions et combinaisons (SRSS, 100 % + 30 %).</summary>
    public static TableData SeismicCompare(StructModel m, ResultsStore? st)
    {
        if (st == null) return NoStore("Séisme X, Y et combiné");
        var t = new TableData("Séisme selon X, selon Y et combiné", "Cas", "Effort tranchant Vx (kN)", "Vy (kN)", "Moment renversant Mx (kN.m)", "My (kN.m)", "Déplacement en tête ux (mm)", "uy (mm)", "Inter-étage max (mm)", "Hauteur (m)", "Niveau");
        var d = st.SeismicDirections();
        if (d.Count < 2) { t.Notes.Add(m.Seismic.Enabled ? "Calcul des deux directions impossible (aucune force sismique)." : "Séisme non activé dans ce modèle."); return t; }
        var x = d.First(r => r.Dir == SeismicDirection.X); var y = d.First(r => r.Dir == SeismicDirection.Y);
        t.Add("Séisme selon X", R(Math.Abs(x.Vx)), R(Math.Abs(x.Vy)), R(Math.Abs(x.OverturnX)), R(Math.Abs(x.OverturnY)), R(x.TopUxMm), R(x.TopUyMm), R(x.DriftMm), R(x.DriftHeightM), x.DriftLevel);
        t.Add("Séisme selon Y", R(Math.Abs(y.Vx)), R(Math.Abs(y.Vy)), R(Math.Abs(y.OverturnX)), R(Math.Abs(y.OverturnY)), R(y.TopUxMm), R(y.TopUyMm), R(y.DriftMm), R(y.DriftHeightM), y.DriftLevel);
        double[] a = { Math.Abs(x.Vx), Math.Abs(x.Vy), Math.Abs(x.OverturnX), Math.Abs(x.OverturnY), x.TopUxMm, x.TopUyMm, x.DriftMm };
        double[] b = { Math.Abs(y.Vx), Math.Abs(y.Vy), Math.Abs(y.OverturnX), Math.Abs(y.OverturnY), y.TopUxMm, y.TopUyMm, y.DriftMm };
        object?[] Row(string name, Func<double, double, double> f) => new object?[] { name, R(f(a[0], b[0])), R(f(a[1], b[1])), R(f(a[2], b[2])), R(f(a[3], b[3])), R(f(a[4], b[4])), R(f(a[5], b[5])), R(f(a[6], b[6])), null, "" };
        t.Add(Row("Combiné : √(X² + Y²)", (p, q) => Math.Sqrt(p * p + q * q)));
        t.Add(Row("Combiné : 100 % X + 30 % Y", (p, q) => p + 0.3 * q));
        t.Add(Row("Combiné : 30 % X + 100 % Y", (p, q) => 0.3 * p + q));
        t.Notes.Add("Force sismique statique équivalente calculée successivement dans chaque direction avec les mêmes paramètres (période modale si activée). Les effets de torsion accidentelle s'ajoutent via e = 5 % de la dimension (tableau d'excentricité).");
        if (m.Seismic.UseResponseSpectrum) t.Notes.Add("L'analyse du projet utilise le spectre de réponse : cette comparaison est faite en force statique équivalente.");
        t.Notes.Add("Comportement élastique linéaire : le comportement en grande déformation (non linéaire) n'est pas modélisé.");
        return t;
    }

    public static TableData Modal(StructModel m, ResultsStore? st)
    {
        var t = new TableData("Analyse modale", "Mode", "Période T (s)", "Fréquence f (Hz)", "Facteur Γx", "Facteur Γy", "Masse participante X (%)", "Masse participante Y (%)", "Cumul X (%)", "Cumul Y (%)", "Type de mode", "Dominant");
        if (st == null) return NoStore("Analyse modale");
        var mr = st.EnsureModal(Math.Max(8, 12));
        if (mr == null || mr.Modes.Count == 0) { t.Notes.Add("Analyse modale non réalisée" + (mr == null ? "" : " (" + mr.Note + ")") + "."); return t; }
        double cx = 0, cy = 0; int need = 0;
        var domX = mr.Modes.OrderByDescending(x => x.RatioX).First(); var domY = mr.Modes.OrderByDescending(x => x.RatioY).First();
        foreach (var md in mr.Modes)
        {
            cx += md.RatioX; cy += md.RatioY;
            if (need == 0 && cx >= 0.9 && cy >= 0.9) need = md.Index;
            string type = md.RatioX >= 0.2 && md.RatioX >= md.RatioY ? "Translation X" : md.RatioY >= 0.2 ? "Translation Y" : md.RatioX + md.RatioY < 0.05 ? "Torsion ou mode local" : "Mode mixte (translation + torsion)";
            t.Add(md.Index, Math.Round(md.Period, 4), Math.Round(md.FreqHz, 3), R(md.GammaX), R(md.GammaY), R(md.RatioX * 100), R(md.RatioY * 100), R(cx * 100), R(cy * 100), type,
                  md == domX && md == domY ? "X et Y" : md == domX ? "X" : md == domY ? "Y" : "");
        }
        t.Notes.Add(need > 0 ? $"90 % de masse participante atteints en X et Y avec {need} mode(s)." : $"90 % de masse participante non atteints avec {mr.Modes.Count} modes : augmenter le nombre de modes ou vérifier le modèle (liaisons, masses).");
        t.Notes.Add($"Masse totale {mr.TotalMassTonnes:0.0} t. Masse participante verticale : voir le tableau « Analyse modale verticale ». La déformée modale s'affiche dans la vue 3D (liste « Source » du ruban).");
        return t;
    }

    public static TableData ModalVertical(StructModel m, ResultsStore? st)
    {
        var t = new TableData("Analyse modale verticale (masse participante Z)", "Mode", "Période T (s)", "Fréquence f (Hz)", "Facteur Γz", "Masse participante Z (%)", "Cumul Z (%)");
        if (st == null) return NoStore("Analyse modale verticale");
        var mr = st.EnsureModalZ(30);
        if (mr == null || mr.Modes.Count == 0) { t.Notes.Add("Analyse verticale non réalisée" + (mr == null ? "" : " (" + mr.Note + ")") + "."); return t; }
        double cz = 0;
        foreach (var md in mr.Modes) { cz += md.RatioZ; t.Add(md.Index, Math.Round(md.Period, 4), Math.Round(md.FreqHz, 3), R(md.GammaZ), R(md.RatioZ * 100), R(cz * 100)); }
        t.Notes.Add($"Masses concentrées aux nœuds, translation verticale : {mr.Modes.Count} modes, {cz * 100:0} % de la masse mobilisée. Les modes de flexion de planchers sont nombreux : un cumul inférieur à 90 % est normal avec peu de modes (EC8 : à examiner pour les éléments sensibles à l'action verticale).");
        return t;
    }

    // ------------------------------------------------------------------ catalogue
    public static List<TableSpec> Catalog(StructModel m, AnalysisOutput o, string source, ResultFilter f)
    {
        var st = o.Store;
        var l = new List<TableSpec>();
        void Add(string g, string n, Func<TableData> b) => l.Add(new TableSpec { Group = g, Name = n, Build = b });
        if (st != null)
        {
            Add("Réactions", "Réactions d'appui", () => Reactions(m, st, source));
            Add("Réactions", "Réaction totale par cas / combinaison", () => TotalReactions(m, st));
            Add("Réactions", "Réactions par niveau", () => ReactionsGrouped(m, st, true));
            Add("Réactions", "Réactions par type d'appui", () => ReactionsGrouped(m, st, false));
            Add("Efforts", "Efforts des barres (N, Vy, Vz, T, My, Mz)", () => MemberForces(m, st, source, f));
            Add("Efforts", "Enveloppes ELU par barre", () => Envelopes(m, o, st, f));
            Add("Efforts", "Enveloppes ELS par barre", () => MemberForces(m, st, ResultsStore.EnvSls, f));
            Add("Déplacements", "Déplacements nodaux", () => Displacements(m, st, source));
            Add("Déplacements", "Déplacements d'étage", () => Storeys(m, o, st, source));
            Add("Contraintes", "Contraintes des barres", () => Stresses(m, st, source, f, o));
        }
        Add("Déplacements", "Flèches des poutres", () => Deflections(m, o));
        Add("Ferraillage", "Ferraillage des barres", () => Reinforcement(m, o, f));
        Add("Dalles", "Dalles : extrêmes et contraintes", () => Slabs(o));
        Add("Dalles", "Réactions linéiques des dalles", () => SlabEdgeReactions(o));
        Add("Dalles", "Poinçonnement", () => Punching(o));
        Add("Voiles", "Voiles et noyaux", () => Walls(o));
        Add("Sismique", "Efforts sismiques par niveau", () => SeismicGlobal(m, o, st));
        Add("Sismique", "Réactions sismiques", () => SeismicReactions(m, st));
        Add("Sismique", "Excentricité et torsion d'étage", () => SeismicEccentricity(m));
        Add("Sismique", "Séisme X, Y et combiné", () => SeismicCompare(m, st));
        Add("Sismique", "Analyse modale", () => Modal(m, st));
        Add("Sismique", "Analyse modale verticale (masse Z)", () => ModalVertical(m, st));
        Add("Conformité", "Vérifications de conformité", () => Compliance(m, o));
        return l;
    }

    /// <summary>Tous les tableaux (sans filtre, source = enveloppe ELU) : export Excel complet et rapport.</summary>
    public static List<TableData> All(StructModel m, AnalysisOutput o, string source = ResultsStore.EnvUls)
    {
        var res = new List<TableData>();
        foreach (var spec in Catalog(m, o, source, new ResultFilter()))
        {
            try { var td = spec.Build(); if (td.Rows.Count > 0) res.Add(td); }
            catch (Exception ex) { var e = new TableData(spec.Name, "Erreur"); e.Add(ex.Message); res.Add(e); }
        }
        return res;
    }
}
