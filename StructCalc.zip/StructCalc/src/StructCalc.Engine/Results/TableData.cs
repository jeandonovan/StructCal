using System.Globalization;
using System.IO.Compression;
using System.Text;

namespace StructCalc.Engine.Results;

/// <summary>Tableau de résultats générique (titre, colonnes, lignes) : affiché dans la grille, exporté en CSV, Excel (.xlsx) ou HTML pour le rapport.</summary>
public sealed class TableData
{
    public string Title { get; }
    public List<string> Headers { get; } = new();
    public List<object?[]> Rows { get; } = new();
    public List<string> Notes { get; } = new();

    public TableData(string title, params string[] headers) { Title = title; Headers.AddRange(headers); }

    public TableData Add(params object?[] cells) { Rows.Add(cells); return this; }

    private static string Cell(object? v, CultureInfo ci) => v switch
    {
        null => "",
        double d => double.IsNaN(d) ? "" : double.IsInfinity(d) ? "∞" : Math.Round(d, 4).ToString("0.####", ci),
        float f => Math.Round(f, 4).ToString("0.####", ci),
        IFormattable fm => fm.ToString(null, ci),
        _ => v.ToString() ?? ""
    };

    public string CellText(object? v) => Cell(v, CultureInfo.CurrentCulture);

    /// <summary>CSV pour Excel français : séparateur « ; », virgule décimale, UTF-8 avec BOM à écrire par l'appelant.</summary>
    public string ToCsv()
    {
        var ci = CultureInfo.GetCultureInfo("fr-FR");
        var sb = new StringBuilder();
        string Q(string s) => s.IndexOfAny(new[] { ';', '"', '\n', '\r' }) >= 0 ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
        sb.AppendLine(Q(Title));
        sb.AppendLine(string.Join(";", Headers.Select(Q)));
        foreach (var r in Rows) sb.AppendLine(string.Join(";", r.Select(c => Q(Cell(c, ci)))));
        foreach (var n in Notes) sb.AppendLine(Q(n));
        return sb.ToString();
    }

    /// <summary>Échappe &lt; &gt; &amp; et les guillemets en gardant les accents lisibles (UTF-8).</summary>
    private static string Enc(string t) => t.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");

    public string ToHtml()
    {
        var ci = CultureInfo.GetCultureInfo("fr-FR");
        var sb = new StringBuilder();
        sb.AppendLine($"<h3>{Enc(Title)}</h3><table><tr>" + string.Concat(Headers.Select(h => $"<th>{Enc(h)}</th>")) + "</tr>");
        foreach (var r in Rows)
        {
            sb.Append("<tr>");
            foreach (var c in r)
            {
                string t = Cell(c, ci);
                string cls = t is "Non vérifié" or "NON OK" ? " class='ko'" : t is "Vérifié" or "OK" ? " class='ok'" : t.StartsWith("À ") ? " class='sk'" : "";
                sb.Append($"<td{cls}>{Enc(t)}</td>");
            }
            sb.AppendLine("</tr>");
        }
        sb.AppendLine("</table>");
        foreach (var n in Notes) sb.AppendLine($"<p style='font-size:12px;color:#555'>{Enc(n)}</p>");
        return sb.ToString();
    }

    // ------------------------------------------------------------------ Excel (.xlsx) sans bibliothèque externe
    private static string Esc(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (char c in s)
        {
            if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') continue;
            sb.Append(c switch { '&' => "&amp;", '<' => "&lt;", '>' => "&gt;", '"' => "&quot;", _ => c.ToString() });
        }
        return sb.ToString();
    }

    private static string ColName(int i)
    {
        string s = "";
        for (i++; i > 0; i = (i - 1) / 26) s = (char)('A' + (i - 1) % 26) + s;
        return s;
    }

    private static string SheetName(string raw, HashSet<string> used)
    {
        var sb = new StringBuilder();
        foreach (char c in raw) if ("[]:*?/\\".IndexOf(c) < 0) sb.Append(c);
        string n = sb.ToString().Trim();
        if (n.Length == 0) n = "Feuille";
        if (n.Length > 28) n = n[..28];
        string r = n; int k = 2;
        while (!used.Add(r.ToLowerInvariant())) r = n + " " + k++;
        return r;
    }

    public static byte[] ToXlsx(IEnumerable<TableData> sheets)
    {
        var list = sheets.ToList();
        if (list.Count == 0) list.Add(new TableData("Vide", "Information"));
        var used = new HashSet<string>();
        var names = list.Select(t => SheetName(t.Title, used)).ToList();
        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            void Put(string path, string content)
            {
                var e = zip.CreateEntry(path, CompressionLevel.Optimal);
                using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
                w.Write(content);
            }
            var ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (int i = 0; i < list.Count; i++)
                ct.Append($"<Override PartName=\"/xl/worksheets/sheet{i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            ct.Append("</Types>");
            Put("[Content_Types].xml", ct.ToString());
            Put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            var wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            var rel = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i = 0; i < list.Count; i++)
            {
                wb.Append($"<sheet name=\"{Esc(names[i])}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>");
                rel.Append($"<Relationship Id=\"rId{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i + 1}.xml\"/>");
            }
            wb.Append("</sheets></workbook>");
            rel.Append($"<Relationship Id=\"rId{list.Count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            Put("xl/workbook.xml", wb.ToString());
            Put("xl/_rels/workbook.xml.rels", rel.ToString());
            Put("xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE8EEF6\"/></patternFill></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs>" +
                "</styleSheet>");
            for (int s = 0; s < list.Count; s++)
            {
                var t = list[s];
                var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                    "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"2\" topLeftCell=\"A3\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>");
                sb.Append($"<row r=\"1\"><c r=\"A1\" t=\"inlineStr\" s=\"1\"><is><t>{Esc(t.Title)}</t></is></c></row>");
                sb.Append("<row r=\"2\">");
                for (int c = 0; c < t.Headers.Count; c++) sb.Append($"<c r=\"{ColName(c)}2\" t=\"inlineStr\" s=\"1\"><is><t>{Esc(t.Headers[c])}</t></is></c>");
                sb.Append("</row>");
                int row = 3;
                foreach (var r in t.Rows)
                {
                    sb.Append($"<row r=\"{row}\">");
                    for (int c = 0; c < r.Length; c++)
                    {
                        object? v = r[c];
                        string rf = ColName(c) + row;
                        if (v == null) continue;
                        if (v is double d) { if (double.IsNaN(d) || double.IsInfinity(d)) continue; sb.Append($"<c r=\"{rf}\"><v>{d.ToString("R", CultureInfo.InvariantCulture)}</v></c>"); }
                        else if (v is int i) sb.Append($"<c r=\"{rf}\"><v>{i}</v></c>");
                        else if (v is float f) sb.Append($"<c r=\"{rf}\"><v>{f.ToString("R", CultureInfo.InvariantCulture)}</v></c>");
                        else if (v is long l) sb.Append($"<c r=\"{rf}\"><v>{l}</v></c>");
                        else sb.Append($"<c r=\"{rf}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Esc(v.ToString() ?? "")}</t></is></c>");
                    }
                    sb.Append("</row>"); row++;
                }
                foreach (var n in t.Notes) { sb.Append($"<row r=\"{row}\"><c r=\"A{row}\" t=\"inlineStr\"><is><t>{Esc(n)}</t></is></c></row>"); row++; }
                sb.Append("</sheetData></worksheet>");
                Put($"xl/worksheets/sheet{s + 1}.xml", sb.ToString());
            }
        }
        return ms.ToArray();
    }
}
