using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine.Results;

public enum ForceQty { N, Vy, Vz, T, My, Mz }

public enum SourceKind { Case, Combo, EnvUls, EnvSls }

/// <summary>Valeurs d'une grandeur le long d'une barre : minimum et maximum à chaque section, avec la combinaison qui les produit.
/// Pour un cas de charge ou une combinaison isolée, minimum = maximum.</summary>
public sealed class ForceSeries
{
    public double[] X = Array.Empty<double>();
    public double[] Min = Array.Empty<double>(), Max = Array.Empty<double>();
    public string[] MinCombo = Array.Empty<string>(), MaxCombo = Array.Empty<string>();
    public int IndexOfMax() { int k = 0; for (int i = 1; i < Max.Length; i++) if (Max[i] > Max[k]) k = i; return k; }
    public int IndexOfMin() { int k = 0; for (int i = 1; i < Min.Length; i++) if (Min[i] < Min[k]) k = i; return k; }
    public double AbsMax => Max.Length == 0 ? 0 : Math.Max(Max.Max(), -Min.Min());
}

public sealed record SeismicDirResult(SeismicDirection Dir, double Vx, double Vy, double OverturnX, double OverturnY, double TopUxMm, double TopUyMm,
                                      double DriftMm, double DriftHeightM, string DriftLevel, double BaseShear);

/// <summary>Réaction (ou effort d'appui) minimale et maximale par composante, avec la combinaison responsable.</summary>
public sealed class ReactionLine
{
    public int NodeId;
    public double[] Min = new double[6], Max = new double[6];            // Fx Fy Fz Mx My Mz
    public string[] MinCombo = new string[6], MaxCombo = new string[6];
}

public sealed class NodeDisplacement
{
    public int NodeId;
    public double[] U = new double[6];                                    // m, rad
    public string Combo = "";
}

/// <summary>Magasin de résultats d'un calcul : cas de charge, combinaisons, charges sismiques, analyse modale. Toutes les sources d'affichage
/// (cas, combinaison, enveloppe ELU, enveloppe ELS) en sont dérivées à la demande, avec la combinaison responsable de chaque valeur extrême.</summary>
public sealed class ResultsStore
{
    public const string EnvUls = "Enveloppe ELU";
    public const string EnvSls = "Enveloppe ELS";

    public StructModel Model { get; }
    public Dictionary<ActionType, CaseResult> Cases { get; }
    public IReadOnlyList<Combination> Combos { get; }
    public List<NodalLoad> SeismicLoads { get; } = new();
    public ModalResult? Modal { get; private set; }
    public event Action? ModalChanged;

    private readonly Dictionary<string, ForceSeries> _cache = new();

    public ResultsStore(StructModel m, Dictionary<ActionType, CaseResult> cases, IReadOnlyList<Combination> combos)
    {
        Model = m; Cases = cases; Combos = combos;
    }

    public IReadOnlyList<Combination> Uls => Combos.Where(c => c.State != LimitState.ELS).ToList();
    public IReadOnlyList<Combination> Sls
    {
        get
        {
            var l = Combos.Where(c => c.State == LimitState.ELS).ToList();
            if (l.Count == 0) l.Add(new Combination("G+Q", LimitState.ELS, new Dictionary<ActionType, double> { [ActionType.G] = 1, [ActionType.Q] = 1 }));
            return l;
        }
    }

    /// <summary>Calcule (une seule fois) les modes propres : à la demande pour les modèles non sismiques.</summary>
    public ModalResult? EnsureModal(int nModes = 10)
    {
        if (Modal != null) return Modal;
        try { Modal = ModalAnalysis.Compute(Model, nModes); }
        catch { Modal = null; }
        ModalChanged?.Invoke();
        return Modal;
    }

    public void SetModal(ModalResult? mr) { Modal = mr; }

    /// <summary>Modes verticaux (translation Z) : masse participante verticale. Calculés à la demande.</summary>
    public ModalResult? ModalZ { get; private set; }

    public ModalResult? EnsureModalZ(int nModes = 30)
    {
        if (ModalZ != null) return ModalZ;
        try { ModalZ = ModalAnalysis.Compute(Model, nModes, true); }
        catch { ModalZ = null; }
        return ModalZ;
    }

    private List<SeismicDirResult>? _seismicDirs;

    /// <summary>Séisme statique équivalent calculé dans les deux directions (X puis Y) pour les comparer et les combiner (SRSS, 100 % + 30 %).</summary>
    public List<SeismicDirResult> SeismicDirections()
    {
        if (_seismicDirs != null) return _seismicDirs;
        var res = new List<SeismicDirResult>();
        var m = Model;
        if (!m.Seismic.Enabled) return _seismicDirs = res;
        var orig = m.Seismic.Direction;
        try
        {
            var info = StructureAnalyzer.Analyze(m);
            var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
            double z0 = m.Supports.Select(sp => nodes.TryGetValue(sp.NodeId, out var nd) ? nd.Z : double.MaxValue).DefaultIfEmpty(m.Nodes.Min(n => n.Z)).Min();
            foreach (var dir in new[] { SeismicDirection.X, SeismicDirection.Y })
            {
                m.Seismic.Direction = dir;
                double? t = null;
                if (m.Seismic.UseModalPeriod && Modal != null && Modal.Modes.Count > 0)
                {
                    double tm = Modal.DominantPeriod(dir);
                    double zr = m.Nodes.Max(n => n.Z) - m.Nodes.Min(n => n.Z);
                    double tEmp = m.Seismic.Ct * Math.Pow(Math.Max(zr, 0.5), 0.75);
                    if (!m.Seismic.Norm.Equals("EC8", StringComparison.OrdinalIgnoreCase) && tm > 1.3 * tEmp) tm = 1.3 * tEmp;
                    if (tm > 0) t = tm;
                }
                var seis = StructCalc.Engine.SeismicLoads.Compute(m, t);
                if (seis.Loads.Count == 0) continue;
                var cr = FrameSolver.Solve(m, ActionType.E, seis.Loads);
                var loads = seis.Loads.Select(l => (z: nodes.TryGetValue(l.NodeId, out var nd) ? nd.Z : 0.0, fx: l.Fx, fy: l.Fy)).ToList();
                double topZ = nodes.Values.Max(n => n.Z), topX = 0, topY = 0;
                foreach (var n in nodes.Values.Where(n => Math.Abs(n.Z - topZ) < 0.05))
                    if (cr.NodeDisp.TryGetValue(n.Id, out var u)) { topX = Math.Max(topX, Math.Abs(u[0])); topY = Math.Max(topY, Math.Abs(u[1])); }
                double dmax = 0, hAt = 0; string lvName = "";
                foreach (var c in m.Members.Where(x => x.Type == MemberType.Column))
                {
                    if (!nodes.TryGetValue(c.NodeI, out var a) || !nodes.TryGetValue(c.NodeJ, out var b)) continue;
                    if (!cr.NodeDisp.TryGetValue(a.Id, out var ua) || !cr.NodeDisp.TryGetValue(b.Id, out var ub)) continue;
                    double d = Math.Sqrt((ua[0] - ub[0]) * (ua[0] - ub[0]) + (ua[1] - ub[1]) * (ua[1] - ub[1])) * 1000, h = Math.Abs(a.Z - b.Z);
                    if (h > 0.5 && d / h > dmax / Math.Max(hAt, 1e-9)) { dmax = d; hAt = h; int li = info.LevelAtZ(Math.Max(a.Z, b.Z)); lvName = li >= 0 ? info.Levels[li].Name : ""; }
                }
                res.Add(new SeismicDirResult(dir, loads.Sum(l => l.fx), loads.Sum(l => l.fy), loads.Sum(l => l.fy * (l.z - z0)), loads.Sum(l => l.fx * (l.z - z0)),
                                             topX * 1000, topY * 1000, dmax, hAt, lvName, seis.BaseShear));
            }
        }
        catch { res.Clear(); }
        finally { m.Seismic.Direction = orig; }
        return _seismicDirs = res;
    }

    public IEnumerable<string> ForceSources()
    {
        foreach (var t in Cases.Keys.OrderBy(t => t)) yield return "Cas " + t;
        foreach (var c in Combos) yield return c.Name;
        yield return EnvUls;
        yield return EnvSls;
    }

    public IEnumerable<string> DeformSources()
    {
        foreach (var s in ForceSources()) yield return s;
        if (Modal != null) foreach (var md in Modal.Modes) yield return ModeName(md);
    }

    public static string ModeName(ModeInfo md) => $"Mode {md.Index} (T = {md.Period:0.000} s)";

    public SourceKind KindOf(string source)
    {
        if (source == EnvUls) return SourceKind.EnvUls;
        if (source == EnvSls) return SourceKind.EnvSls;
        if (source.StartsWith("Cas ")) return SourceKind.Case;
        return SourceKind.Combo;
    }

    private IReadOnlyList<Combination> CombosOf(string source) => source == EnvUls ? Uls : source == EnvSls ? Sls : Combos.Where(c => c.Name == source).ToList();

    private ActionType? CaseOf(string source) => source.StartsWith("Cas ") && Enum.TryParse<ActionType>(source[4..], out var t) ? t : null;

    private static double Pick(StationForces f, ForceQty q) => q switch
    {
        ForceQty.N => f.N, ForceQty.Vy => f.Vy, ForceQty.Vz => f.Vz, ForceQty.T => f.T, ForceQty.My => f.My, _ => f.Mz
    };

    /// <summary>Efforts d'une barre dans une source donnée (une section par entrée).</summary>
    public ForceSeries Series(string source, int memberId, ForceQty q)
    {
        string key = source + "|" + memberId + "|" + (int)q;
        if (_cache.TryGetValue(key, out var hit)) return hit;
        var s = new ForceSeries();
        int ns = FrameSolver.Stations;
        var kind = KindOf(source);
        if (kind == SourceKind.Case)
        {
            var t = CaseOf(source);
            if (t == null || !Cases.TryGetValue(t.Value, out var cr) || !cr.Members.TryGetValue(memberId, out var arr)) return Cache(key, s);
            s.X = arr.Select(a => a.X).ToArray();
            s.Min = arr.Select(a => Pick(a, q)).ToArray(); s.Max = s.Min.ToArray();
            s.MinCombo = Enumerable.Repeat(source, arr.Length).ToArray(); s.MaxCombo = s.MinCombo;
            return Cache(key, s);
        }
        var list = CombosOf(source);
        if (list.Count == 0 || !Cases.Values.Any(c => c.Members.ContainsKey(memberId))) return Cache(key, s);
        s.X = new double[ns]; s.Min = new double[ns]; s.Max = new double[ns];
        s.MinCombo = new string[ns]; s.MaxCombo = new string[ns];
        for (int k = 0; k < ns; k++) { s.Min[k] = double.MaxValue; s.Max[k] = double.MinValue; }
        foreach (var c in list)
            for (int k = 0; k < ns; k++)
            {
                var f = MemberDesigner.Combine(c, Cases, memberId, k);
                double v = Pick(f, q);
                s.X[k] = f.X;
                if (v < s.Min[k]) { s.Min[k] = v; s.MinCombo[k] = c.Name; }
                if (v > s.Max[k]) { s.Max[k] = v; s.MaxCombo[k] = c.Name; }
            }
        for (int k = 0; k < ns; k++)
        {
            if (s.Min[k] == double.MaxValue) { s.Min[k] = 0; s.MinCombo[k] = ""; }
            if (s.Max[k] == double.MinValue) { s.Max[k] = 0; s.MaxCombo[k] = ""; }
        }
        return Cache(key, s);
    }

    private ForceSeries Cache(string key, ForceSeries s) { _cache[key] = s; return s; }

    internal static double[] CombineNode(Combination c, Dictionary<ActionType, CaseResult> cases, Func<CaseResult, Dictionary<int, double[]>> sel, int node)
    {
        var r = new double[6];
        foreach (var kv in c.Factors)
        {
            if (Math.Abs(kv.Value) < 1e-12 || !cases.TryGetValue(kv.Key, out var cr)) continue;
            if (!sel(cr).TryGetValue(node, out var v)) continue;
            for (int i = 0; i < 6 && i < v.Length; i++) r[i] += kv.Value * v[i];
        }
        return r;
    }

    /// <summary>Réactions d'appui : minimum / maximum de chaque composante sur les combinaisons de la source, avec la combinaison responsable.</summary>
    public List<ReactionLine> Reactions(string source)
    {
        var res = new List<ReactionLine>();
        var ids = Cases.Values.SelectMany(c => c.Reactions.Keys).Distinct().OrderBy(x => x).ToList();
        var kind = KindOf(source);
        foreach (int id in ids)
        {
            var line = new ReactionLine { NodeId = id };
            for (int i = 0; i < 6; i++) { line.Min[i] = double.MaxValue; line.Max[i] = double.MinValue; line.MinCombo[i] = ""; line.MaxCombo[i] = ""; }
            void Take(double[] r, string name)
            {
                for (int i = 0; i < 6; i++)
                {
                    if (r[i] < line.Min[i]) { line.Min[i] = r[i]; line.MinCombo[i] = name; }
                    if (r[i] > line.Max[i]) { line.Max[i] = r[i]; line.MaxCombo[i] = name; }
                }
            }
            if (kind == SourceKind.Case)
            {
                var t = CaseOf(source);
                if (t != null && Cases.TryGetValue(t.Value, out var cr) && cr.Reactions.TryGetValue(id, out var v)) Take(v.Concat(new double[6]).Take(6).ToArray(), source);
            }
            else foreach (var c in CombosOf(source)) Take(CombineNode(c, Cases, cr => cr.Reactions, id), c.Name);
            for (int i = 0; i < 6; i++) if (line.Min[i] == double.MaxValue) { line.Min[i] = 0; line.Max[i] = 0; }
            res.Add(line);
        }
        return res;
    }

    /// <summary>Déplacements nodaux (m, rad) pour la source : un cas, une combinaison, ou la combinaison la plus défavorable de l'enveloppe ; ou une forme modale.</summary>
    public List<NodeDisplacement> Displacements(string source)
    {
        var res = new List<NodeDisplacement>();
        if (Modal != null)
        {
            var md = Modal.Modes.FirstOrDefault(x => ModeName(x) == source);
            if (md != null)
            {
                double mx = md.Shape.Values.Select(v => Math.Max(Math.Abs(v.Ux), Math.Abs(v.Uy))).DefaultIfEmpty(1).Max();
                if (mx < 1e-12) mx = 1;
                foreach (var n in Model.Nodes.GroupBy(n => n.Id).Select(g => g.First()))
                {
                    var d = new NodeDisplacement { NodeId = n.Id, Combo = source };
                    if (md.Shape.TryGetValue(n.Id, out var sh)) { d.U[0] = sh.Ux / mx * 0.01; d.U[1] = sh.Uy / mx * 0.01; }   // forme normalisée à 1 cm
                    res.Add(d);
                }
                return res;
            }
        }
        var kind = KindOf(source);
        foreach (var n in Model.Nodes.GroupBy(n => n.Id).Select(g => g.First()))
        {
            var d = new NodeDisplacement { NodeId = n.Id };
            if (kind == SourceKind.Case)
            {
                var t = CaseOf(source);
                if (t != null && Cases.TryGetValue(t.Value, out var cr) && cr.NodeDisp.TryGetValue(n.Id, out var v)) { d.U = v.Concat(new double[6]).Take(6).ToArray(); d.Combo = source; }
            }
            else
            {
                double best = -1;
                foreach (var c in CombosOf(source))
                {
                    var u = CombineNode(c, Cases, cr => cr.NodeDisp, n.Id);
                    double nn = Math.Sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
                    if (nn > best) { best = nn; d.U = u; d.Combo = c.Name; }
                }
            }
            res.Add(d);
        }
        return res;
    }

    /// <summary>Plus grande valeur absolue de la grandeur sur toutes les barres demandées (échelle des diagrammes).</summary>
    public double MaxAbs(string source, ForceQty q, IEnumerable<int> memberIds)
    {
        double m = 0;
        foreach (int id in memberIds) m = Math.Max(m, Series(source, id, q).AbsMax);
        return m;
    }

    public static string QtyName(ForceQty q) => q switch
    {
        ForceQty.N => "N", ForceQty.Vy => "Vy", ForceQty.Vz => "Vz", ForceQty.T => "T (torsion)", ForceQty.My => "My", _ => "Mz"
    };

    public static string QtyUnit(ForceQty q) => q is ForceQty.My or ForceQty.Mz or ForceQty.T ? "kN.m" : "kN";

    /// <summary>Résumé d'une barre pour l'infobulle : extrêmes de chaque effort avec la combinaison responsable.</summary>
    public string MemberSummary(string source, int memberId)
    {
        var parts = new List<string>();
        foreach (ForceQty q in Enum.GetValues(typeof(ForceQty)))
        {
            var s = Series(source, memberId, q);
            if (s.X.Length == 0) continue;
            int imx = s.IndexOfMax(), imn = s.IndexOfMin();
            double mx = s.Max[imx], mn = s.Min[imn];
            if (Math.Abs(mx) < 0.005 && Math.Abs(mn) < 0.005) continue;
            string txt = Math.Abs(mx - mn) < 1e-9 ? $"{QtyName(q)} = {mx:0.0}" : $"{QtyName(q)} = {mn:0.0} / {mx:0.0}";
            parts.Add(txt + " " + QtyUnit(q));
        }
        return parts.Count == 0 ? "" : $"[{source}] " + string.Join("  ·  ", parts);
    }
}
