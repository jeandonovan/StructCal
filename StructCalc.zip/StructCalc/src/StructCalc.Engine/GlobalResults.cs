using StructCalc.Core;
using StructCalc.Core.Model;
using StructCalc.Engine.Structure;

namespace StructCalc.Engine;

public sealed class ReactionRow
{
    public int NodeId { get; set; }
    public string AxisRef { get; set; } = "";
    public double[] Min { get; set; } = new double[6];      // Fx Fy Fz Mx My Mz (kN, kN.m) - enveloppe ELU / accidentelle
    public double[] Max { get; set; } = new double[6];
    public double FzService { get; set; }                   // kN, ELS
}

public sealed class DisplacementRow
{
    public int NodeId { get; set; }
    public double Ux { get; set; }                          // mm, valeurs de la combinaison ELS la plus défavorable pour ce nœud
    public double Uy { get; set; }
    public double Uz { get; set; }
    public double Total { get; set; }
    public string Combo { get; set; } = "";
}

public sealed class DeflectionRow
{
    public int MemberId { get; set; }
    public double LengthM { get; set; }
    public double DeltaMm { get; set; }
    public double LimitMm { get; set; }
    public double Ratio => DeltaMm > 1e-9 ? LengthM * 1000 / DeltaMm : double.PositiveInfinity;   // L / delta
    public bool Ok { get; set; } = true;
    public string Combo { get; set; } = "";
}

public sealed class DriftRow
{
    public string Level { get; set; } = "";                 // niveau supérieur de l'étage
    public double HeightM { get; set; }
    public double DeltaMm { get; set; }
    public double Ratio => DeltaMm > 1e-9 ? HeightM * 1000 / DeltaMm : double.PositiveInfinity;   // h / delta
    public double LimitDenominator { get; set; }            // 500 (service) ou 100 (séisme)
    public bool Ok { get; set; } = true;
    public string Basis { get; set; } = "";
    public string Combo { get; set; } = "";
}

/// <summary>Résultats globaux du modèle : réactions d'appui, déplacements, flèches des poutres, déplacements d'étage, déformée.</summary>
public sealed class GlobalResults
{
    public List<ReactionRow> Reactions { get; } = new();
    public List<DisplacementRow> Displacements { get; } = new();
    public List<DeflectionRow> Deflections { get; } = new();
    public List<DriftRow> Drifts { get; } = new();
    public Dictionary<string, double> TotalFzByCase { get; } = new();
    public string DeformedCombo { get; set; } = "";
    public Dictionary<int, double[]> Deformed { get; } = new();     // déplacements nodaux (m, rad) de la combinaison de service la plus défavorable
    public double MaxDisplacementMm { get; set; }
    public bool DeflectionsOk => Deflections.All(d => d.Ok);
    public bool DriftsOk => Drifts.All(d => d.Ok);
}

public static class GlobalResultsBuilder
{
    private static double[] Combine(Combination c, Dictionary<ActionType, CaseResult> cases, Func<CaseResult, Dictionary<int, double[]>> sel, int node)
    {
        var r = new double[6];
        foreach (var kv in c.Factors)
        {
            if (Math.Abs(kv.Value) < 1e-12 || !cases.TryGetValue(kv.Key, out var cr)) continue;
            if (!sel(cr).TryGetValue(node, out var v)) continue;
            for (int i = 0; i < 6; i++) r[i] += kv.Value * v[i];
        }
        return r;
    }

    public static GlobalResults Build(StructModel m, IEnumerable<Combination> combinations, Dictionary<ActionType, CaseResult> cases)
    {
        var g = new GlobalResults();
        var all = combinations.ToList();
        var uls = all.Where(c => c.State != LimitState.ELS).ToList();
        var sls = all.Where(c => c.State == LimitState.ELS).ToList();
        if (sls.Count == 0)
            sls.Add(new Combination("G+Q", LimitState.ELS, new Dictionary<ActionType, double> { [ActionType.G] = 1, [ActionType.Q] = 1 }));
        if (uls.Count == 0) uls = sls;
        var info = StructureAnalyzer.Analyze(m);
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(x => x.Key, x => x.First());

        foreach (var kv in cases)
            g.TotalFzByCase[kv.Key.ToString()] = Math.Round(kv.Value.Reactions.Values.Sum(r => r[2]), 3);

        // ---- réactions d'appui
        var supportIds = cases.Values.SelectMany(c => c.Reactions.Keys).Distinct().OrderBy(x => x).ToList();
        foreach (int id in supportIds)
        {
            var row = new ReactionRow { NodeId = id };
            if (nodes.TryGetValue(id, out var nd)) row.AxisRef = info.AxisRef(nd.X, nd.Y);
            for (int i = 0; i < 6; i++) { row.Min[i] = double.MaxValue; row.Max[i] = double.MinValue; }
            foreach (var c in uls)
            {
                var r = Combine(c, cases, cr => cr.Reactions, id);
                for (int i = 0; i < 6; i++) { row.Min[i] = Math.Min(row.Min[i], r[i]); row.Max[i] = Math.Max(row.Max[i], r[i]); }
            }
            foreach (var c in sls) row.FzService = Math.Max(row.FzService, Combine(c, cases, cr => cr.Reactions, id)[2]);
            for (int i = 0; i < 6; i++) { if (row.Min[i] == double.MaxValue) row.Min[i] = 0; if (row.Max[i] == double.MinValue) row.Max[i] = 0; }
            g.Reactions.Add(row);
        }

        // ---- déplacements (service)
        double bestNorm = -1;
        foreach (var n in m.Nodes)
        {
            DisplacementRow? best = null; double bn = -1;
            foreach (var c in sls)
            {
                var u = Combine(c, cases, cr => cr.NodeDisp, n.Id);
                double tot = Math.Sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]) * 1000;
                if (tot > bn) { bn = tot; best = new DisplacementRow { NodeId = n.Id, Ux = u[0] * 1000, Uy = u[1] * 1000, Uz = u[2] * 1000, Total = tot, Combo = c.Name }; }
            }
            if (best != null) g.Displacements.Add(best);
            if (bn > bestNorm) { bestNorm = bn; g.DeformedCombo = best!.Combo; }
        }
        g.MaxDisplacementMm = Math.Max(0, bestNorm);
        var def = sls.FirstOrDefault(c => c.Name == g.DeformedCombo) ?? sls[0];
        foreach (var n in m.Nodes) g.Deformed[n.Id] = Combine(def, cases, cr => cr.NodeDisp, n.Id);

        // ---- flèches des poutres (relatives à la corde)
        double limDen = m.DeflectionLimitDenominator > 1 ? m.DeflectionLimitDenominator : 250;
        foreach (var mem in m.Members.Where(x => x.Type == MemberType.Beam))
        {
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            double dx = b.X - a.X, dy = b.Y - a.Y, dz = b.Z - a.Z, L = Math.Sqrt(dx * dx + dy * dy + dz * dz);
            if (L < 1e-6) continue;
            double ex = dx / L, ey = dy / L, ez = dz / L;
            double worst = 0; string worstCombo = "";
            foreach (var c in sls)
            {
                var u0 = Combine(c, cases, cr => cr.NodeDisp, a.Id); var u1 = Combine(c, cases, cr => cr.NodeDisp, b.Id);
                // changement de tangente = theta x ex
                double[] t0 = { u0[4] * ez - u0[5] * ey, u0[5] * ex - u0[3] * ez, u0[3] * ey - u0[4] * ex };
                double[] t1 = { u1[4] * ez - u1[5] * ey, u1[5] * ex - u1[3] * ez, u1[3] * ey - u1[4] * ex };
                for (int k = 1; k <= 9; k++)
                {
                    double t = k / 10.0, t2 = t * t, t3 = t2 * t;
                    double h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
                    double[] d = new double[3];
                    for (int i = 0; i < 3; i++)
                    {
                        double curve = h00 * u0[i] + h10 * L * t0[i] + h01 * u1[i] + h11 * L * t1[i];
                        double chord = (1 - t) * u0[i] + t * u1[i];
                        d[i] = curve - chord;
                    }
                    double along = d[0] * ex + d[1] * ey + d[2] * ez;
                    double px = d[0] - along * ex, py = d[1] - along * ey, pz = d[2] - along * ez;
                    double perp = Math.Sqrt(px * px + py * py + pz * pz) * 1000;
                    if (perp > worst) { worst = perp; worstCombo = c.Name; }
                }
            }
            g.Deflections.Add(new DeflectionRow { MemberId = mem.Id, LengthM = L, DeltaMm = worst, LimitMm = L * 1000 / limDen, Ok = worst <= L * 1000 / limDen + 1e-9, Combo = worstCombo });
        }

        // ---- déplacements d'étage (poteaux entre deux niveaux consécutifs)
        if (info.Levels.Count >= 2)
        {
            var seismic = all.Where(c => c.Factors.TryGetValue(ActionType.E, out double f) && Math.Abs(f) > 1e-9).ToList();
            var service = sls;
            for (int lv = 1; lv < info.Levels.Count; lv++)
            {
                var low = info.Levels[lv - 1]; var up = info.Levels[lv];
                double h = up.Z - low.Z;
                if (h < 0.5) continue;
                var cols = m.Members.Where(x => x.Type == MemberType.Column && nodes.ContainsKey(x.NodeI) && nodes.ContainsKey(x.NodeJ)).ToList();
                foreach (var (basis, list, den) in new[] { ("Service", service, 500.0), ("Séisme", seismic, 100.0) })
                {
                    if (list.Count == 0) continue;
                    double worst = 0; string wc = "";
                    foreach (var col in cols)
                    {
                        var p = nodes[col.NodeI]; var q = nodes[col.NodeJ];
                        var lo = p.Z <= q.Z ? p : q; var hi = p.Z <= q.Z ? q : p;
                        if (info.LevelAtZ(lo.Z) != lv - 1 || info.LevelAtZ(hi.Z) != lv) continue;
                        foreach (var c in list)
                        {
                            var u0 = Combine(c, cases, cr => cr.NodeDisp, lo.Id); var u1 = Combine(c, cases, cr => cr.NodeDisp, hi.Id);
                            double d = Math.Sqrt((u1[0] - u0[0]) * (u1[0] - u0[0]) + (u1[1] - u0[1]) * (u1[1] - u0[1])) * 1000;
                            if (d > worst) { worst = d; wc = c.Name; }
                        }
                    }
                    if (wc == "") continue;
                    g.Drifts.Add(new DriftRow { Level = up.Name, HeightM = h, DeltaMm = worst, LimitDenominator = den, Ok = worst <= h * 1000 / den + 1e-9, Basis = basis, Combo = wc });
                }
            }
        }
        return g;
    }
}
