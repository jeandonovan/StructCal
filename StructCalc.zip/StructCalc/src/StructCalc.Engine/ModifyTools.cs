using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Une transformation géométrique du modèle : position des nœuds et effet sur les vecteurs horizontaux des charges.</summary>
public sealed class Xform
{
    public Func<double, double, double, (double X, double Y, double Z)> Point { get; init; } = (x, y, z) => (x, y, z);
    public Func<double, double, (double X, double Y)> Vec { get; init; } = (x, y) => (x, y);      // vecteur horizontal (force)
    public bool Reflect { get; init; }                                                              // symétrie : les moments changent de signe
    public double LengthScale { get; init; } = 1;                                                    // agrandissement (positions de charges)

    public static Xform Translation(double dx, double dy, double dz) => new() { Point = (x, y, z) => (x + dx, y + dy, z + dz) };

    public static Xform Rotation(double cx, double cy, double angleDeg)
    {
        double a = angleDeg * Math.PI / 180, c = Math.Cos(a), s = Math.Sin(a);
        return new Xform { Point = (x, y, z) => (cx + (x - cx) * c - (y - cy) * s, cy + (x - cx) * s + (y - cy) * c, z), Vec = (x, y) => (x * c - y * s, x * s + y * c) };
    }

    /// <summary>Symétrie par rapport au plan vertical passant par (x1,y1) et (x2,y2).</summary>
    public static Xform MirrorLine(double x1, double y1, double x2, double y2)
    {
        double dx = x2 - x1, dy = y2 - y1, l = Math.Sqrt(dx * dx + dy * dy);
        if (l < 1e-9) throw new ArgumentException("Axe de symétrie dégénéré.");
        dx /= l; dy /= l;
        return new Xform
        {
            Reflect = true,
            Point = (x, y, z) => { double t = (x - x1) * dx + (y - y1) * dy; double px = x1 + t * dx, py = y1 + t * dy; return (2 * px - x, 2 * py - y, z); },
            Vec = (x, y) => { double t = x * dx + y * dy; return (2 * t * dx - x, 2 * t * dy - y); },
        };
    }

    public static Xform Scale(double cx, double cy, double cz, double fx, double fy, double fz) =>
        new() { Point = (x, y, z) => (cx + (x - cx) * fx, cy + (y - cy) * fy, cz + (z - cz) * fz), LengthScale = Math.Max(fx, Math.Max(fy, fz)) };
}

/// <summary>Outils de modification de type CAO/DAO : copie, translation, rotation, symétrie, échelle, étirement, réseaux, division, prolongement, alignement, fusion des nœuds.
/// Toutes les fonctions travaillent sur le modèle et gardent la cohérence des charges, appuis et panneaux surfaciques.</summary>
public static class ModifyTools
{
    private const double Tol = 2e-3;
    private static (long, long, long) Key(double x, double y, double z) => ((long)Math.Round(x * 1000), (long)Math.Round(y * 1000), (long)Math.Round(z * 1000));

    private static int NextNode(StructModel m) => m.Nodes.Count == 0 ? 1 : m.Nodes.Max(n => n.Id) + 1;
    private static int NextMember(StructModel m) => m.Members.Count == 0 ? 1 : m.Members.Max(q => q.Id) + 1;

    private static Member CloneMember(Member s, int id, int a, int b) => new()
    {
        Id = id, NodeI = a, NodeJ = b, Type = s.Type, Kind = s.Kind, B = s.B, H = s.H, Cover = s.Cover, LfFactor = s.LfFactor,
        Crack = s.Crack, PropA = s.PropA, PropIy = s.PropIy, PropIz = s.PropIz, PropJ = s.PropJ, Profile = s.Profile
    };

    private static MemberLoad Transform(MemberLoad l, int newId, Xform t)
    {
        var c = l.Clone(newId);
        if (c.Frame == LoadFrame.Global)
        {
            (c.Wx, c.Wy) = t.Vec(c.Wx, c.Wy); (c.Wx2, c.Wy2) = t.Vec(c.Wx2, c.Wy2); (c.Px, c.Py) = t.Vec(c.Px, c.Py);
            var mm = t.Vec(c.Mx, c.My);
            if (t.Reflect) { c.Mx = -mm.X; c.My = -mm.Y; c.Mz = -c.Mz; } else { c.Mx = mm.X; c.My = mm.Y; }
        }
        return c;
    }

    /// <summary>Nouveau rectangle d'une charge surfacique après transformation, ou null si le panneau cesse d'être un rectangle aligné sur X/Y.</summary>
    private static (double X0, double Y0, double X1, double Y1, double Z)? MapRect(SurfaceLoad sl, Xform t)
    {
        var p = new[] { t.Point(sl.X0, sl.Y0, sl.Z), t.Point(sl.X1, sl.Y0, sl.Z), t.Point(sl.X1, sl.Y1, sl.Z), t.Point(sl.X0, sl.Y1, sl.Z) };
        double x0 = p.Min(q => q.X), x1 = p.Max(q => q.X), y0 = p.Min(q => q.Y), y1 = p.Max(q => q.Y);
        foreach (var q in p)
            if ((Math.Abs(q.X - x0) > Tol && Math.Abs(q.X - x1) > Tol) || (Math.Abs(q.Y - y0) > Tol && Math.Abs(q.Y - y1) > Tol)) return null;
        if (Math.Abs(p.Max(q => q.Z) - p.Min(q => q.Z)) > Tol) return null;
        return (x0, y0, x1, y1, p[0].Z);
    }

    private static bool PanelInside(SurfaceLoad sl, List<Node> nodes)
    {
        var corners = new[] { (sl.X0, sl.Y0), (sl.X1, sl.Y0), (sl.X1, sl.Y1), (sl.X0, sl.Y1) };
        return corners.All(cn => nodes.Any(n => Math.Abs(n.X - cn.Item1) < Tol && Math.Abs(n.Y - cn.Item2) < Tol && Math.Abs(n.Z - sl.Z) < Tol));
    }

    // ------------------------------------------------------------------ copie transformée (copier, rotation avec copie, symétrie, échelle avec copie...)
    /// <summary>Crée une copie transformée des barres (nœuds fusionnés par position). Retourne les identifiants des nouvelles barres.</summary>
    public static List<int> CopyTransformed(StructModel m, IEnumerable<int> memberIds, Xform t, bool copyLoads = true, bool copySupports = false)
    {
        var ids = new HashSet<int>(memberIds);
        var nodes = m.Nodes.ToDictionary(n => n.Id);
        var byPos = new Dictionary<(long, long, long), int>();
        foreach (var n in m.Nodes) byPos[Key(n.X, n.Y, n.Z)] = n.Id;
        int nextNode = NextNode(m), nextMem = NextMember(m);
        var existing = new HashSet<(int, int)>(m.Members.Select(q => (Math.Min(q.NodeI, q.NodeJ), Math.Max(q.NodeI, q.NodeJ))));
        var src = m.Members.Where(q => ids.Contains(q.Id) && nodes.ContainsKey(q.NodeI) && nodes.ContainsKey(q.NodeJ)).ToList();
        var map = new Dictionary<int, int>();
        foreach (int nid in src.SelectMany(q => new[] { q.NodeI, q.NodeJ }).Distinct().ToList())
        {
            var n = nodes[nid]; var p = t.Point(n.X, n.Y, n.Z);
            var k = Key(p.X, p.Y, p.Z);
            if (!byPos.TryGetValue(k, out int id))
            {
                id = nextNode++;
                m.Nodes.Add(new Node { Id = id, X = Math.Round(p.X, 6), Y = Math.Round(p.Y, 6), Z = Math.Round(p.Z, 6) });
                byPos[k] = id;
            }
            map[nid] = id;
        }
        var created = new List<int>();
        foreach (var s in src)
        {
            int a = map[s.NodeI], b = map[s.NodeJ];
            if (a == b || !existing.Add((Math.Min(a, b), Math.Max(a, b)))) continue;
            var nm = CloneMember(s, nextMem++, a, b);
            if (Math.Abs(t.LengthScale - 1) > 1e-9) { nm.B = s.B; nm.H = s.H; }
            m.Members.Add(nm); created.Add(nm.Id);
            if (copyLoads)
            {
                double ratio = LengthRatio(m, s, nm);
                foreach (var l in m.MemberLoads.Where(q => q.MemberId == s.Id).ToList())
                {
                    var c = Transform(l, nm.Id, t);
                    ScalePositions(c, ratio);
                    m.MemberLoads.Add(c);
                }
            }
        }
        if (copyLoads)
        {
            var srcNodes = src.SelectMany(q => new[] { q.NodeI, q.NodeJ }).Distinct().Select(i => nodes[i]).ToList();
            foreach (var sl in m.SurfaceLoads.ToList())
            {
                if (!PanelInside(sl, srcNodes)) continue;
                var r = MapRect(sl, t);
                if (r == null) continue;
                var cp = new SurfaceLoad { Name = sl.Name, Case = sl.Case, Q = sl.Q, Distribution = sl.Distribution, Z = Math.Round(r.Value.Z, 6), X0 = r.Value.X0, Y0 = r.Value.Y0, X1 = r.Value.X1, Y1 = r.Value.Y1 };
                if (!m.SurfaceLoads.Any(q => q.Case == cp.Case && Math.Abs(q.Z - cp.Z) < Tol && Math.Abs(q.X0 - cp.X0) < Tol && Math.Abs(q.Y0 - cp.Y0) < Tol && Math.Abs(q.X1 - cp.X1) < Tol && Math.Abs(q.Y1 - cp.Y1) < Tol))
                    m.SurfaceLoads.Add(cp);
            }
            foreach (var kv in map)
                foreach (var l in m.NodalLoads.Where(q => q.NodeId == kv.Key).ToList())
                    if (!m.NodalLoads.Any(q => q.NodeId == kv.Value && q.Case == l.Case))
                    {
                        var f = t.Vec(l.Fx, l.Fy); var mm = t.Vec(l.Mx, l.My);
                        m.NodalLoads.Add(new NodalLoad { NodeId = kv.Value, Case = l.Case, Fx = f.X, Fy = f.Y, Fz = l.Fz, Mx = t.Reflect ? -mm.X : mm.X, My = t.Reflect ? -mm.Y : mm.Y, Mz = t.Reflect ? -l.Mz : l.Mz });
                    }
        }
        if (copySupports)
            foreach (var kv in map)
            {
                var sp = m.Supports.FirstOrDefault(q => q.NodeId == kv.Key);
                if (sp != null && !m.Supports.Any(q => q.NodeId == kv.Value))
                    m.Supports.Add(new SupportDef { NodeId = kv.Value, Ux = sp.Ux, Uy = sp.Uy, Uz = sp.Uz, Rx = sp.Rx, Ry = sp.Ry, Rz = sp.Rz });
            }
        return created;
    }

    private static double LengthRatio(StructModel m, Member a, Member b)
    {
        var nodes = m.Nodes;
        Node? Na(int i) => nodes.FirstOrDefault(n => n.Id == i);
        var a1 = Na(a.NodeI); var a2 = Na(a.NodeJ); var b1 = Na(b.NodeI); var b2 = Na(b.NodeJ);
        if (a1 == null || a2 == null || b1 == null || b2 == null) return 1;
        double la = Dist(a1, a2), lb = Dist(b1, b2);
        return la < 1e-9 ? 1 : lb / la;
    }

    private static double Dist(Node a, Node b) => Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y) + (a.Z - b.Z) * (a.Z - b.Z));

    private static void ScalePositions(MemberLoad l, double ratio)
    {
        if (Math.Abs(ratio - 1) < 1e-9 || l.Relative) return;
        l.A *= ratio; l.B *= ratio;
    }

    // ------------------------------------------------------------------ transformation en place (déplacer, tourner, échelle, étirer)
    /// <summary>Transforme les nœuds indiqués. Les charges globales des barres dont les DEUX nœuds bougent suivent la rotation/symétrie ;
    /// les panneaux surfaciques suivent leurs quatre coins ; ceux qui deviendraient non rectangulaires sont supprimés.
    /// Retourne (nœuds déplacés, panneaux supprimés).</summary>
    public static (int Moved, int DroppedPanels) TransformInPlace(StructModel m, IEnumerable<int> nodeIds, Xform t)
    {
        var set = new HashSet<int>(nodeIds);
        var movedNodes = m.Nodes.Where(n => set.Contains(n.Id)).ToList();
        var oldPos = movedNodes.Select(n => new Node { Id = n.Id, X = n.X, Y = n.Y, Z = n.Z }).ToList();
        // longueurs avant
        var before = m.Members.Where(q => set.Contains(q.NodeI) || set.Contains(q.NodeJ)).ToDictionary(q => q.Id, q =>
        {
            var a = m.Nodes.FirstOrDefault(n => n.Id == q.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == q.NodeJ);
            return a == null || b == null ? 0 : Dist(a, b);
        });
        // panneaux (avant déplacement)
        var panelPlan = new List<(SurfaceLoad S, (double X0, double Y0, double X1, double Y1, double Z)? R)>();
        foreach (var sl in m.SurfaceLoads)
            if (PanelInside(sl, oldPos)) panelPlan.Add((sl, MapRect(sl, t)));
        foreach (var n in movedNodes)
        {
            var p = t.Point(n.X, n.Y, n.Z);
            n.X = Math.Round(p.X, 6); n.Y = Math.Round(p.Y, 6); n.Z = Math.Round(p.Z, 6);
        }
        int dropped = 0;
        foreach (var (s, r) in panelPlan)
        {
            if (r == null) { m.SurfaceLoads.Remove(s); dropped++; }
            else { s.X0 = r.Value.X0; s.Y0 = r.Value.Y0; s.X1 = r.Value.X1; s.Y1 = r.Value.Y1; s.Z = Math.Round(r.Value.Z, 6); }
        }
        foreach (var mem in m.Members)
        {
            if (!before.TryGetValue(mem.Id, out double l0)) continue;
            bool both = set.Contains(mem.NodeI) && set.Contains(mem.NodeJ);
            var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
            double l1 = a == null || b == null ? 0 : Dist(a, b);
            double ratio = l0 > 1e-9 ? l1 / l0 : 1;
            foreach (var l in m.MemberLoads.Where(q => q.MemberId == mem.Id))
            {
                if (both && l.Frame == LoadFrame.Global)
                {
                    (l.Wx, l.Wy) = t.Vec(l.Wx, l.Wy); (l.Wx2, l.Wy2) = t.Vec(l.Wx2, l.Wy2); (l.Px, l.Py) = t.Vec(l.Px, l.Py);
                    var mm = t.Vec(l.Mx, l.My);
                    if (t.Reflect) { l.Mx = -mm.X; l.My = -mm.Y; l.Mz = -l.Mz; } else { l.Mx = mm.X; l.My = mm.Y; }
                }
                ScalePositions(l, ratio);
            }
        }
        return (movedNodes.Count, dropped);
    }

    public static List<int> NodesOf(StructModel m, IEnumerable<int> memberIds) => SelectionTools.NodesOf(m, memberIds);

    // ------------------------------------------------------------------ étirement
    /// <summary>Étire : déplace de (dx,dy,dz) tous les nœuds situés dans le parallélépipède donné ; les barres qui les relient s'allongent ou se raccourcissent.</summary>
    public static (int Moved, int DroppedPanels) Stretch(StructModel m, double x0, double y0, double x1, double y1, double z0, double z1, double dx, double dy, double dz)
    {
        double xa = Math.Min(x0, x1) - Tol, xb = Math.Max(x0, x1) + Tol, ya = Math.Min(y0, y1) - Tol, yb = Math.Max(y0, y1) + Tol, za = Math.Min(z0, z1) - Tol, zb = Math.Max(z0, z1) + Tol;
        var ids = m.Nodes.Where(n => n.X >= xa && n.X <= xb && n.Y >= ya && n.Y <= yb && n.Z >= za && n.Z <= zb).Select(n => n.Id).ToList();
        return TransformInPlace(m, ids, Xform.Translation(dx, dy, dz));
    }

    // ------------------------------------------------------------------ réseaux
    /// <summary>Réseau rectangulaire : nx x ny x nz exemplaires (l'original compte pour 1), pas (dx,dy,dz). Retourne les nouvelles barres.</summary>
    public static List<int> ArrayRect(StructModel m, IEnumerable<int> memberIds, int nx, int ny, int nz, double dx, double dy, double dz, bool copySupports = true)
    {
        var ids = memberIds.ToList(); var res = new List<int>();
        for (int k = 0; k < Math.Max(1, nz); k++)
            for (int j = 0; j < Math.Max(1, ny); j++)
                for (int i = 0; i < Math.Max(1, nx); i++)
                {
                    if (i == 0 && j == 0 && k == 0) continue;
                    res.AddRange(CopyTransformed(m, ids, Xform.Translation(dx * i, dy * j, dz * k), true, copySupports));
                }
        return res;
    }

    /// <summary>Réseau polaire autour de (cx,cy) : count exemplaires répartis sur totalAngle (360 = cercle complet). Les copies sont tournées (rotateItems) ou seulement déplacées.</summary>
    public static List<int> ArrayPolar(StructModel m, IEnumerable<int> memberIds, double cx, double cy, int count, double totalAngle, bool copySupports = true)
    {
        var ids = memberIds.ToList(); var res = new List<int>();
        if (count < 2) return res;
        double step = Math.Abs(totalAngle - 360) < 1e-6 ? 360.0 / count : totalAngle / (count - 1);
        for (int i = 1; i < count; i++) res.AddRange(CopyTransformed(m, ids, Xform.Rotation(cx, cy, step * i), true, copySupports));
        return res;
    }

    // ------------------------------------------------------------------ division / prolongement
    /// <summary>Coupe une barre aux abscisses données (m depuis le nœud i). Les charges sont réparties sur les tronçons. Retourne les identifiants des tronçons (le premier garde l'identifiant d'origine).</summary>
    public static List<int> SplitMember(StructModel m, int memberId, IEnumerable<double> cuts)
    {
        var mem = m.Members.FirstOrDefault(q => q.Id == memberId);
        var res = new List<int>();
        if (mem == null) return res;
        var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ);
        if (a == null || b == null) return res;
        double L = Dist(a, b);
        if (L < 1e-6) return res;
        var cs = cuts.Where(c => c > 1e-3 && c < L - 1e-3).Distinct().OrderBy(c => c).ToList();
        if (cs.Count == 0) return res;
        var bounds = new List<double> { 0 }; bounds.AddRange(cs); bounds.Add(L);
        var nodeIds = new List<int> { mem.NodeI };
        int nn = NextNode(m);
        var byPos = new Dictionary<(long, long, long), int>();
        foreach (var n in m.Nodes) byPos[Key(n.X, n.Y, n.Z)] = n.Id;
        foreach (double c in cs)
        {
            double t = c / L;
            double x = a.X + (b.X - a.X) * t, y = a.Y + (b.Y - a.Y) * t, z = a.Z + (b.Z - a.Z) * t;
            if (!byPos.TryGetValue(Key(x, y, z), out int id))
            {
                id = nn++;
                m.Nodes.Add(new Node { Id = id, X = Math.Round(x, 6), Y = Math.Round(y, 6), Z = Math.Round(z, 6) });
                byPos[Key(x, y, z)] = id;
            }
            nodeIds.Add(id);
        }
        nodeIds.Add(mem.NodeJ);
        var oldLoads = m.MemberLoads.Where(q => q.MemberId == memberId).ToList();
        foreach (var l in oldLoads) m.MemberLoads.Remove(l);
        int nextMem = NextMember(m);
        int origJ = mem.NodeJ;
        for (int k = 0; k < bounds.Count - 1; k++)
        {
            Member seg;
            if (k == 0) { seg = mem; seg.NodeJ = nodeIds[1]; }
            else { seg = CloneMember(mem, nextMem++, nodeIds[k], nodeIds[k + 1]); m.Members.Add(seg); }
            res.Add(seg.Id);
            double s0 = bounds[k], s1 = bounds[k + 1];
            foreach (var l in oldLoads) foreach (var piece in LoadPiece(l, L, s0, s1, seg.Id)) m.MemberLoads.Add(piece);
        }
        return res;
    }

    private static IEnumerable<MemberLoad> LoadPiece(MemberLoad l, double L, double s0, double s1, int newId)
    {
        double len = s1 - s0;
        switch (l.Kind)
        {
            case MemberLoadKind.Thermal:
                yield return l.Clone(newId); yield break;
            case MemberLoadKind.Point:
            case MemberLoadKind.Moment:
            {
                double p = LoadMath.Pos(l, l.A, L);
                bool last = s1 >= L - 1e-6;
                if (p < s0 - 1e-9 || p > s1 + 1e-9 || (p >= s1 - 1e-9 && !last)) yield break;
                var c = l.Clone(newId); c.Relative = false; c.A = Math.Max(0, Math.Min(len, p - s0));
                yield return c; yield break;
            }
            default:
            {
                double a = 0, b = L;
                if (l.Kind == MemberLoadKind.Trapezoid) { a = LoadMath.Pos(l, l.A, L); b = LoadMath.Pos(l, l.B, L); if (b < a) (a, b) = (b, a); }
                double u0 = Math.Max(a, s0), u1 = Math.Min(b, s1);
                if (u1 - u0 < 1e-6) yield break;
                var c = l.Clone(newId);
                double f0 = (u0 - a) / Math.Max(b - a, 1e-12), f1 = (u1 - a) / Math.Max(b - a, 1e-12);
                double x1 = l.Wx, y1 = l.Wy, z1 = l.Wz, x2 = l.Kind == MemberLoadKind.Trapezoid ? l.Wx2 : l.Wx, y2 = l.Kind == MemberLoadKind.Trapezoid ? l.Wy2 : l.Wy, z2 = l.Kind == MemberLoadKind.Trapezoid ? l.Wz2 : l.Wz;
                bool full = u0 <= s0 + 1e-9 && u1 >= s1 - 1e-9 && l.Kind == MemberLoadKind.Uniform;
                if (full) { yield return c; yield break; }
                c.Kind = MemberLoadKind.Trapezoid; c.Relative = false; c.A = u0 - s0; c.B = u1 - s0;
                c.Wx = x1 + (x2 - x1) * f0; c.Wy = y1 + (y2 - y1) * f0; c.Wz = z1 + (z2 - z1) * f0;
                c.Wx2 = x1 + (x2 - x1) * f1; c.Wy2 = y1 + (y2 - y1) * f1; c.Wz2 = z1 + (z2 - z1) * f1;
                yield return c; yield break;
            }
        }
    }

    /// <summary>Divise chaque barre en n tronçons égaux. Retourne le nombre de barres créées.</summary>
    public static int DivideEqual(StructModel m, IEnumerable<int> memberIds, int parts)
    {
        if (parts < 2) return 0;
        int created = 0;
        foreach (int id in memberIds.ToList())
        {
            var mem = m.Members.FirstOrDefault(q => q.Id == id); if (mem == null) continue;
            var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ); if (a == null || b == null) continue;
            double L = Dist(a, b);
            created += SplitMember(m, id, Enumerable.Range(1, parts - 1).Select(i => L * i / parts)).Count - 1;
        }
        return Math.Max(0, created);
    }

    /// <summary>Coupe chaque barre à une distance donnée du nœud i (ou du nœud j si fromJ). Distance en m, ou fraction 0-1 si relative.</summary>
    public static int DivideAt(StructModel m, IEnumerable<int> memberIds, double d, bool relative, bool fromJ)
    {
        int created = 0;
        foreach (int id in memberIds.ToList())
        {
            var mem = m.Members.FirstOrDefault(q => q.Id == id); if (mem == null) continue;
            var a = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(n => n.Id == mem.NodeJ); if (a == null || b == null) continue;
            double L = Dist(a, b);
            double s = relative ? d * L : d;
            if (fromJ) s = L - s;
            created += SplitMember(m, id, new[] { s }).Count - 1;
        }
        return Math.Max(0, created);
    }

    /// <summary>Prolonge (d &gt; 0) ou raccourcit (d &lt; 0) chaque barre de d mètres à l'extrémité choisie. Un nouveau nœud est créé : les barres voisines ne bougent pas.</summary>
    public static int Extend(StructModel m, IEnumerable<int> memberIds, bool atEndJ, double d)
    {
        int n = 0;
        int nn = NextNode(m);
        foreach (int id in memberIds.ToList())
        {
            var mem = m.Members.FirstOrDefault(q => q.Id == id); if (mem == null) continue;
            var a = m.Nodes.FirstOrDefault(q => q.Id == mem.NodeI); var b = m.Nodes.FirstOrDefault(q => q.Id == mem.NodeJ); if (a == null || b == null) continue;
            double L = Dist(a, b); if (L < 1e-6 || L + d < 0.05) continue;
            var far = atEndJ ? a : b; var near = atEndJ ? b : a;
            double ux = (near.X - far.X) / L, uy = (near.Y - far.Y) / L, uz = (near.Z - far.Z) / L;
            double x = near.X + ux * d, y = near.Y + uy * d, z = near.Z + uz * d;
            var exist = m.Nodes.FirstOrDefault(q => Math.Abs(q.X - x) < Tol && Math.Abs(q.Y - y) < Tol && Math.Abs(q.Z - z) < Tol);
            int nid;
            if (exist != null) nid = exist.Id;
            else { nid = nn++; m.Nodes.Add(new Node { Id = nid, X = Math.Round(x, 6), Y = Math.Round(y, 6), Z = Math.Round(z, 6) }); }
            if (atEndJ) mem.NodeJ = nid; else mem.NodeI = nid;
            double ratio = (L + d) / L;
            foreach (var l in m.MemberLoads.Where(q => q.MemberId == id)) { if (atEndJ) ScalePositions(l, ratio); }
            n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ alignement et nettoyage
    /// <summary>Aligne les nœuds des barres choisies sur une coordonnée (axis 'x', 'y' ou 'z').</summary>
    public static (int Moved, int DroppedPanels) AlignNodes(StructModel m, IEnumerable<int> memberIds, char axis, double value)
    {
        var ids = NodesOf(m, memberIds);
        var nodes = m.Nodes.Where(n => ids.Contains(n.Id)).ToList();
        if (nodes.Count == 0) return (0, 0);
        int moved = 0, dropped = 0;
        foreach (var n in nodes)
        {
            double cur = axis == 'x' ? n.X : axis == 'y' ? n.Y : n.Z;
            double d = value - cur;
            if (Math.Abs(d) < 1e-9) continue;
            var r = TransformInPlace(m, new[] { n.Id }, Xform.Translation(axis == 'x' ? d : 0, axis == 'y' ? d : 0, axis == 'z' ? d : 0));
            moved += r.Moved; dropped += r.DroppedPanels;
        }
        return (moved, dropped);
    }

    /// <summary>Fusionne les nœuds distants de moins de tol (m), supprime les barres de longueur nulle et les doublons. Retourne (nœuds fusionnés, barres supprimées).</summary>
    public static (int MergedNodes, int RemovedMembers) MergeNodes(StructModel m, double tol = 0.005)
    {
        var order = m.Nodes.OrderBy(n => n.Id).ToList();
        var rep = new Dictionary<int, int>();
        var kept = new List<Node>();
        foreach (var n in order)
        {
            var hit = kept.FirstOrDefault(k => Math.Abs(k.X - n.X) <= tol && Math.Abs(k.Y - n.Y) <= tol && Math.Abs(k.Z - n.Z) <= tol);
            if (hit == null) kept.Add(n); else rep[n.Id] = hit.Id;
        }
        if (rep.Count == 0) return (0, 0);
        foreach (var mem in m.Members) { if (rep.TryGetValue(mem.NodeI, out int a)) mem.NodeI = a; if (rep.TryGetValue(mem.NodeJ, out int b)) mem.NodeJ = b; }
        foreach (var l in m.NodalLoads) if (rep.TryGetValue(l.NodeId, out int a)) l.NodeId = a;
        foreach (var s in m.Supports.ToList())
            if (rep.TryGetValue(s.NodeId, out int a))
            {
                if (m.Supports.Any(q => q.NodeId == a)) m.Supports.Remove(s); else s.NodeId = a;
            }
        foreach (var id in rep.Keys) { var nd = m.Nodes.FirstOrDefault(q => q.Id == id); if (nd != null) m.Nodes.Remove(nd); }
        int removed = 0;
        var seen = new HashSet<(int, int)>();
        foreach (var mem in m.Members.ToList())
        {
            var key = (Math.Min(mem.NodeI, mem.NodeJ), Math.Max(mem.NodeI, mem.NodeJ));
            if (mem.NodeI == mem.NodeJ || !seen.Add(key))
            {
                foreach (var l in m.MemberLoads.Where(q => q.MemberId == mem.Id).ToList()) m.MemberLoads.Remove(l);
                m.Members.Remove(mem); removed++;
            }
        }
        return (rep.Count, removed);
    }
}
