using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Résultat de la répartition d'une charge surfacique : charges de barre créées et part des bords effectivement portée par une poutre.</summary>
public sealed class SurfaceExpansion
{
    public List<MemberLoad> Loads { get; } = new();
    public double MinEdgeCoverage { get; set; } = 1.0;      // 0 à 1 : pire bord (part de sa longueur couverte par des poutres)
    public double LoadedFraction { get; set; } = 1.0;       // part de la charge totale réellement reportée sur des poutres
    public double TotalKn { get; set; }                     // charge totale q x aire (kN)
    public double CarriedKn { get; set; }
    /// <summary>Nombre de bords chargés mais sans poutre (console / porte-à-faux, ou poutre oubliée) : leur charge est reportée sur les bords portés.</summary>
    public int FreeEdges { get; set; }
}

/// <summary>Transforme les charges surfaciques en charges trapézoïdales sur les poutres du contour (méthode des lignes de rupture à 45°
/// ou portée dans un sens), et détecte automatiquement les panneaux rectangulaires fermés par des poutres.</summary>
public static class LoadExpander
{
    private const double Tol = 2e-3, FreeCov = 0.05;

    /// <summary>Charges de barre saisies + charges issues des charges surfaciques : c'est cette liste que le solveur utilise.</summary>
    public static List<MemberLoad> MemberLoadsOf(StructModel m)
    {
        var all = new List<MemberLoad>(m.MemberLoads);
        foreach (var s in m.SurfaceLoads)
            try { all.AddRange(Expand(m, s).Loads); } catch { }
        return all;
    }

    private sealed record Edge(double Sx, double Sy, double Dx, double Dy, double Le, double Lp, bool CarriesTwoWay, bool CarriesX, bool CarriesY, bool AlongX);

    private static double Weight(SurfaceDistribution mode, Edge e, double s)
    {
        switch (mode)
        {
            case SurfaceDistribution.OneWayX: return e.AlongX ? 0 : e.Lp / 2;     // bords x = x0 et x = x1 (parallèles à Y)
            case SurfaceDistribution.OneWayY: return e.AlongX ? e.Lp / 2 : 0;     // bords y = y0 et y = y1 (parallèles à X)
            default: return Math.Max(0, Math.Min(Math.Min(s, e.Le - s), e.Lp / 2));
        }
    }

    public static SurfaceExpansion Expand(StructModel m, SurfaceLoad s)
    {
        var res = new SurfaceExpansion();
        double x0 = Math.Min(s.X0, s.X1), x1 = Math.Max(s.X0, s.X1), y0 = Math.Min(s.Y0, s.Y1), y1 = Math.Max(s.Y0, s.Y1);
        double lx = x1 - x0, ly = y1 - y0;
        res.TotalKn = Math.Abs(s.Q) * lx * ly;
        if (lx < 1e-6 || ly < 1e-6 || Math.Abs(s.Q) < 1e-12) return res;

        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var edges = new[]
        {
            new Edge(x0, y0, 1, 0, lx, ly, true, false, false, true),     // bas  : y = y0
            new Edge(x1, y0, 0, 1, ly, lx, true, false, false, false),    // droite : x = x1
            new Edge(x0, y1, 1, 0, lx, ly, true, false, false, true),     // haut : y = y1
            new Edge(x0, y0, 0, 1, ly, lx, true, false, false, false),    // gauche : x = x0
        };
        double carried = 0, minCov = 1;
        var data = new List<(Edge E, List<(double P0, double P1, double W0, double W1)> Pieces, double WTotal, List<(Member M, double SI, double SJ)> OnEdge, double Cov)>();
        foreach (var e in edges)
        {
            double wTotal = 0;                       // intégrale de w(s) sur le bord (m²) : charge reportée par ce bord = q x wTotal
            // pièces linéaires de w(s)
            var pieces = new List<(double P0, double P1, double W0, double W1)>();
            if (s.Distribution == SurfaceDistribution.TwoWay)
            {
                double c = Math.Min(e.Lp / 2, e.Le / 2);
                pieces.Add((0, c, 0, c));
                if (e.Le - 2 * c > 1e-9) pieces.Add((c, e.Le - c, c, c));
                pieces.Add((e.Le - c, e.Le, c, 0));
            }
            else
            {
                double w = Weight(s.Distribution, e, 0);
                if (w > 1e-12) pieces.Add((0, e.Le, w, w));
            }
            foreach (var pc in pieces) wTotal += (pc.W0 + pc.W1) / 2 * (pc.P1 - pc.P0);

            // barres situées sur ce bord
            var onEdge = new List<(Member M, double SI, double SJ)>();
            foreach (var mem in m.Members)
            {
                if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
                if (Math.Abs(a.Z - s.Z) > Tol || Math.Abs(b.Z - s.Z) > Tol) continue;
                double ia = (a.X - e.Sx) * e.Dx + (a.Y - e.Sy) * e.Dy, ib = (b.X - e.Sx) * e.Dx + (b.Y - e.Sy) * e.Dy;
                double pa = Math.Abs((a.X - e.Sx) * e.Dy - (a.Y - e.Sy) * e.Dx), pb = Math.Abs((b.X - e.Sx) * e.Dy - (b.Y - e.Sy) * e.Dx);
                if (pa > Tol || pb > Tol) continue;
                if (Math.Min(ia, ib) < -Tol || Math.Max(ia, ib) > e.Le + Tol) continue;
                if (Math.Abs(ia - ib) < 1e-6) continue;
                onEdge.Add((mem, ia, ib));
            }

            // couverture du bord
            var iv = onEdge.Select(t => (Lo: Math.Max(0, Math.Min(t.SI, t.SJ)), Hi: Math.Min(e.Le, Math.Max(t.SI, t.SJ)))).OrderBy(t => t.Lo).ToList();
            double covered = 0, cur = 0;
            foreach (var t in iv) { if (t.Hi > cur) { covered += t.Hi - Math.Max(cur, t.Lo); cur = t.Hi; } }
            double cov = e.Le > 0 ? Math.Min(1, covered / e.Le) : 1;
            if (wTotal > 1e-12) minCov = Math.Min(minCov, cov);
            data.Add((e, pieces, wTotal, onEdge, cov));
        }

        // bords libres (console, porte-à-faux) : la part de charge de ces bords est reportée sur les bords portés par une poutre (aire conservée)
        double wCov = 0, wFree = 0;
        foreach (var dt in data)
        {
            if (dt.WTotal <= 1e-12) continue;
            if (dt.Cov < FreeCov) { wFree += dt.WTotal; res.FreeEdges++; } else wCov += dt.WTotal;
        }
        double boost = wCov > 1e-12 && wFree > 1e-12 ? (wCov + wFree) / wCov : 1.0;
        foreach (var dt in data)
        {
            var e = dt.E; var pieces = dt.Pieces; var onEdge = dt.OnEdge;
            double bst = dt.WTotal > 1e-12 && dt.Cov >= FreeCov ? boost : 1.0;
            foreach (var (mem, si, sj) in onEdge)
            {
                double lo = Math.Min(si, sj), hi = Math.Max(si, sj);
                bool forward = si <= sj;
                foreach (var pc in pieces)
                {
                    double u0 = Math.Max(pc.P0, lo), u1 = Math.Min(pc.P1, hi);
                    if (u1 - u0 < 1e-7) continue;
                    double span = pc.P1 - pc.P0;
                    double w0 = pc.W0 + (pc.W1 - pc.W0) * (u0 - pc.P0) / span, w1 = pc.W0 + (pc.W1 - pc.W0) * (u1 - pc.P0) / span;
                    if (w0 < 1e-12 && w1 < 1e-12) continue;
                    double qa = -s.Q * w0 * bst, qb = -s.Q * w1 * bst;     // Wz négatif = vers le bas
                    var ld = new MemberLoad { MemberId = mem.Id, Case = s.Case, Kind = MemberLoadKind.Trapezoid, Frame = LoadFrame.Global, Label = string.IsNullOrEmpty(s.Name) ? "surf." : s.Name };
                    if (forward) { ld.A = u0 - lo; ld.B = u1 - lo; ld.Wz = qa; ld.Wz2 = qb; }
                    else { ld.A = hi - u1; ld.B = hi - u0; ld.Wz = qb; ld.Wz2 = qa; }
                    res.Loads.Add(ld);
                    carried += (Math.Abs(qa) + Math.Abs(qb)) / 2 * (u1 - u0);
                }
            }
        }
        res.CarriedKn = carried;
        res.MinEdgeCoverage = minCov;
        res.LoadedFraction = res.TotalKn > 0 ? Math.Min(1, carried / res.TotalKn) : 1;
        return res;
    }

    // ------------------------------------------------------------------ détection automatique des panneaux
    public sealed record Panel(double Z, double X0, double X1, double Y0, double Y1);

    private sealed record Beam(double Z, bool AlongX, double Fixed, double Lo, double Hi);

    /// <summary>Panneaux rectangulaires horizontaux dont les quatre côtés sont entièrement portés par des poutres (axes X et Y).
    /// Un panneau = une maille entre deux axes de poutres consécutifs dans chaque direction.</summary>
    public static List<Panel> DetectPanels(StructModel m, double minSide = 0.5)
    {
        var nodes = m.Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        var beams = new List<Beam>();
        foreach (var mem in m.Members)
        {
            if (!nodes.TryGetValue(mem.NodeI, out var a) || !nodes.TryGetValue(mem.NodeJ, out var b)) continue;
            if (Math.Abs(a.Z - b.Z) > Tol) continue;
            double dx = Math.Abs(a.X - b.X), dy = Math.Abs(a.Y - b.Y);
            if (dx > Tol && dy <= Tol) beams.Add(new Beam(Math.Round(a.Z, 3), true, a.Y, Math.Min(a.X, b.X), Math.Max(a.X, b.X)));
            else if (dy > Tol && dx <= Tol) beams.Add(new Beam(Math.Round(a.Z, 3), false, a.X, Math.Min(a.Y, b.Y), Math.Max(a.Y, b.Y)));
        }
        var res = new List<Panel>();
        foreach (var zg in beams.GroupBy(b => b.Z))
        {
            var list = zg.ToList();
            var xs = Distinct(list.Where(b => !b.AlongX).Select(b => b.Fixed));
            var ys = Distinct(list.Where(b => b.AlongX).Select(b => b.Fixed));
            bool Covered(bool alongX, double fixedCoord, double lo, double hi)
            {
                var iv = list.Where(b => b.AlongX == alongX && Math.Abs(b.Fixed - fixedCoord) <= Tol && b.Hi > lo - Tol && b.Lo < hi + Tol)
                             .Select(b => (Lo: Math.Max(lo, b.Lo), Hi: Math.Min(hi, b.Hi))).OrderBy(t => t.Lo).ToList();
                double cur = lo;
                foreach (var t in iv) { if (t.Lo > cur + Tol) return false; cur = Math.Max(cur, t.Hi); }
                return cur >= hi - Tol;
            }
            for (int i = 0; i + 1 < xs.Count; i++)
                for (int j = 0; j + 1 < ys.Count; j++)
                {
                    double x0 = xs[i], x1 = xs[i + 1], y0 = ys[j], y1 = ys[j + 1];
                    if (x1 - x0 < minSide || y1 - y0 < minSide) continue;
                    if (Covered(true, y0, x0, x1) && Covered(true, y1, x0, x1) && Covered(false, x0, y0, y1) && Covered(false, x1, y0, y1))
                        res.Add(new Panel(zg.Key, x0, x1, y0, y1));
                }
        }
        return res.OrderBy(p => p.Z).ThenBy(p => p.Y0).ThenBy(p => p.X0).ToList();
    }

    private static List<double> Distinct(IEnumerable<double> v)
    {
        var res = new List<double>();
        foreach (double d in v.OrderBy(x => x))
            if (res.Count == 0 || d - res[^1] > Tol) res.Add(d);
        return res;
    }
}
