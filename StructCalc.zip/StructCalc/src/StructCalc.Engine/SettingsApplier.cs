using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

public static class SettingsApplier
{
    /// <summary>Applique les enrobages de la configuration à toutes les barres béton armé (poteau / poutre selon le type). Retourne le nombre de barres modifiées.</summary>
    public static int ApplyCovers(StructModel m)
    {
        int n = 0;
        foreach (var mem in m.Members.Where(x => x.Kind == MaterialKind.ReinforcedConcrete))
        {
            double c = (mem.Type == MemberType.Column ? m.Settings.CoverColumnCm : m.Settings.CoverBeamCm) / 100.0;
            double nom = mem.Type == MemberType.Column ? m.Settings.CoverNomColumnCm : m.Settings.CoverNomBeamCm;
            if (Math.Abs(mem.Cover - c) > 1e-9 || Math.Abs(mem.CoverNomCm - nom) > 1e-9) { mem.Cover = c; mem.CoverNomCm = nom; n++; }
        }
        return n;
    }
}
