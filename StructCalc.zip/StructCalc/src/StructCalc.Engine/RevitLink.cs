namespace StructCalc.Engine;

/// <summary>Lien StructCalc ↔ Revit : dossier d'échange commun (%APPDATA%\StructCalc\Revit), fichiers « from_revit.json » (modèle envoyé par Revit)
/// et « to_revit.json » (résumé des résultats renvoyé à Revit), chemin du logiciel pour que Revit puisse le lancer.</summary>
public static class RevitLink
{
    public static string Dir
    {
        get
        {
            string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "Revit");
            Directory.CreateDirectory(d);
            return d;
        }
    }

    /// <summary>Dernier modèle exporté par Revit.</summary>
    public static string FromRevit => Path.Combine(Dir, "from_revit.json");
    /// <summary>Dernier résumé de résultats envoyé à Revit.</summary>
    public static string ToRevit => Path.Combine(Dir, "to_revit.json");

    /// <summary>Modèle StructCalc envoyé à Revit pour y créer les éléments (poteaux, poutres, dalles).</summary>
    public static string ModelToRevit => Path.Combine(Dir, "model_to_revit.json");
    /// <summary>Identifiants Revit des éléments créés à partir du modèle StructCalc (renvoyés à StructCalc).</summary>
    public static string CreatedIds => Path.Combine(Dir, "created_ids.json");

    /// <summary>Planches d'exécution (ferraillage...) envoyées à Revit.</summary>
    public static string PlansToRevit => Path.Combine(Dir, "plans_to_revit.json");

    private static string AppPathFile => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "StructCalc", "app_path.txt");

    /// <summary>Mémorise l'emplacement du logiciel (appelé à son démarrage) pour que Revit sache où le lancer.</summary>
    public static void RememberApp(string exePath)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(AppPathFile)!);
            File.WriteAllText(AppPathFile, exePath);
        }
        catch { }
    }

    /// <summary>Emplacement du logiciel d'après la dernière exécution, ou null.</summary>
    public static string? FindApp()
    {
        try
        {
            if (File.Exists(AppPathFile))
            {
                string p = File.ReadAllText(AppPathFile).Trim();
                if (File.Exists(p)) return p;
            }
        }
        catch { }
        string[] cands =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "StructCalc", "StructCalc.App.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "StructCalc", "StructCalc.App.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "StructCalc", "StructCalc.App.exe"),
        };
        return cands.FirstOrDefault(File.Exists);
    }

    /// <summary>Le logiciel est-il déjà ouvert ?</summary>
    public static bool AppRunning() => System.Diagnostics.Process.GetProcessesByName("StructCalc.App").Length > 0;
}
