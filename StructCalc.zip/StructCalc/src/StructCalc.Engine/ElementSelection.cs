using System.Text;
using StructCalc.Core.Model;
using StructCalc.Engine.Geometry;

namespace StructCalc.Engine.Selection;

/// <summary>Famille d'élément sélectionnable. Une seule et même logique de sélection sert à toutes : barres, nœuds et éléments surfaciques.</summary>
public enum ElementKind { Bar, Node, Slab, Stair, Footing, Wall, Raft, Ribbed, Shell }

/// <summary>Identité d'un élément du MODÈLE (et non de son dessin dans une vue) : c'est ce qui reste sélectionné quand on change de vue.
/// Barres et nœuds : Id ; semelle sous nœud : Id = numéro du nœud ; semelle filante : Id = -1 et Name ; les autres : Name.</summary>
public readonly record struct ElementKey(ElementKind Kind, int Id, string Name)
{
    public static ElementKey Bar(int id) => new(ElementKind.Bar, id, "");
    public static ElementKey Node(int id) => new(ElementKind.Node, id, "");
    public static ElementKey FootingAt(int node) => new(ElementKind.Footing, node, "S" + node);
    public static ElementKey Named(ElementKind k, string name) => new(k, -1, name ?? "");

    public string Label => Kind switch
    {
        ElementKind.Bar => "Barre " + Id,
        ElementKind.Node => "Nœud " + Id,
        ElementKind.Slab => "Dalle " + Name,
        ElementKind.Stair => "Escalier " + Name,
        ElementKind.Footing => "Semelle " + Name,
        ElementKind.Wall => "Voile " + Name,
        ElementKind.Raft => "Radier " + Name,
        ElementKind.Ribbed => "Plancher nervuré " + Name,
        ElementKind.Shell => "Coque " + Name,
        _ => Name
    };
}

/// <summary>Noms (singulier / pluriel) et ordre d'affichage des familles.</summary>
public static class ElementKinds
{
    public static readonly ElementKind[] Order =
    {
        ElementKind.Bar, ElementKind.Node, ElementKind.Slab, ElementKind.Stair, ElementKind.Footing,
        ElementKind.Wall, ElementKind.Raft, ElementKind.Ribbed, ElementKind.Shell
    };

    public static string Singular(ElementKind k) => k switch
    {
        ElementKind.Bar => "barre", ElementKind.Node => "nœud", ElementKind.Slab => "dalle", ElementKind.Stair => "escalier",
        ElementKind.Footing => "semelle", ElementKind.Wall => "voile", ElementKind.Raft => "radier", ElementKind.Ribbed => "plancher nervuré",
        ElementKind.Shell => "coque", _ => "élément"
    };

    public static string Plural(ElementKind k) => k switch
    {
        ElementKind.Bar => "barres", ElementKind.Node => "nœuds", ElementKind.Slab => "dalles", ElementKind.Stair => "escaliers",
        ElementKind.Footing => "semelles", ElementKind.Wall => "voiles", ElementKind.Raft => "radiers", ElementKind.Ribbed => "planchers nervurés",
        ElementKind.Shell => "coques", _ => "éléments"
    };

    /// <summary>« 3 dalles », « 1 semelle »...</summary>
    public static string Count(ElementKind k, int n) => n + " " + (n > 1 ? Plural(k) : Singular(k));
}

/// <summary>Candidat sous le curseur : élément, profondeur (plus petit = plus près de la caméra), trait (barre) ou surface, opaque ou non.</summary>
public readonly record struct PickCandidate(ElementKey Key, double Depth, bool Line, bool Opaque);

/// <summary>Règles de désignation à l'écran : l'élément le plus proche de la caméra est choisi ; un clic répété au même endroit passe au suivant.</summary>
public static class PickLogic
{
    /// <summary>Ordre de priorité : nœuds d'abord (cible ponctuelle), puis le plus proche de la caméra. Une barre (trait) vue à travers
    /// une surface translucide (dalle, coque...) reste désignable ; une surface OPAQUE plus proche la masque.</summary>
    public static List<ElementKey> Order(IEnumerable<PickCandidate> cands, double eps = 1e-6)
    {
        var list = cands.ToList();
        double opaqueMin = list.Where(c => c.Opaque && !c.Line).Select(c => c.Depth).DefaultIfEmpty(double.PositiveInfinity).Min();
        int Group(PickCandidate c) => c.Key.Kind == ElementKind.Node ? 0 : (c.Line && c.Depth <= opaqueMin + eps) ? 1 : 2;
        var res = new List<ElementKey>();
        foreach (var c in list.OrderBy(Group).ThenBy(c => c.Depth))
            if (!res.Contains(c.Key)) res.Add(c.Key);
        return res;
    }

    /// <summary>Élément à retenir : le premier, ou le suivant de celui retenu au clic précédent si le clic est au même endroit.</summary>
    public static ElementKey? Choose(IReadOnlyList<ElementKey> ordered, ElementKey? last, bool samePlace)
    {
        if (ordered.Count == 0) return null;
        if (!samePlace || last == null) return ordered[0];
        int i = -1;
        for (int k = 0; k < ordered.Count; k++) if (ordered[k].Equals(last.Value)) { i = k; break; }
        if (i < 0) return ordered[0];
        return ordered[(i + 1) % ordered.Count];
    }
}

/// <summary>Résumé de la sélection pour la barre de sélection : nombre et type, dont masqués et hors vue.</summary>
public static class SelectionSummary
{
    public static string Describe(IReadOnlyCollection<ElementKey> keys, Func<ElementKey, bool>? hidden = null, Func<ElementKey, bool>? offView = null)
    {
        if (keys.Count == 0) return "Aucune sélection";
        var parts = new List<string>();
        foreach (var k in ElementKinds.Order)
        {
            int n = keys.Count(q => q.Kind == k);
            if (n > 0) parts.Add(ElementKinds.Count(k, n));
        }
        var sb = new StringBuilder();
        sb.Append(keys.Count).Append(keys.Count > 1 ? " éléments : " : " élément : ").Append(string.Join(", ", parts));
        int h = hidden == null ? 0 : keys.Count(hidden);
        int o = offView == null ? 0 : keys.Count(q => (hidden == null || !hidden(q)) && offView(q));
        var extra = new List<string>();
        if (h > 0) extra.Add(h + " masqué" + (h > 1 ? "s" : ""));
        if (o > 0) extra.Add(o + " hors vue");
        if (extra.Count > 0) sb.Append("  (").Append(string.Join(", ", extra)).Append(')');
        return sb.ToString();
    }
}

/// <summary>Liste des éléments du modèle par famille (base des commandes « Toutes les dalles », « Tous les voiles »...).</summary>
public static class ElementCatalog
{
    public const string RibbedNoFootprint = "Plancher nervuré non sélectionnable : emprise non définie.";

    /// <summary>Planchers nervurés dont l'emprise n'est pas définie (non cliquables dans les vues).</summary>
    public static bool IsUnpickable(StructModel m, ElementKey k) =>
        k.Kind == ElementKind.Ribbed && m.RibbedFloors.FirstOrDefault(r => r.Name == k.Name) is { HasFootprint: false };

    public static List<ElementKey> All(StructModel m, AnalysisOutput? o, ElementKind k)
    {
        var res = new List<ElementKey>();
        switch (k)
        {
            case ElementKind.Bar: res.AddRange(m.Members.Select(x => ElementKey.Bar(x.Id))); break;
            case ElementKind.Node: res.AddRange(m.Nodes.Select(x => x.Id).Distinct().Select(ElementKey.Node)); break;
            case ElementKind.Slab: res.AddRange(m.Slabs.Where(s => s.Placed).Select(s => ElementKey.Named(k, s.Name))); break;
            case ElementKind.Stair: res.AddRange(m.Stairs.Where(s => s.Placed).Select(s => ElementKey.Named(k, s.Name))); break;
            case ElementKind.Footing:
                if (o != null) res.AddRange(FootingPlacement.From(m, o).Select(p => ElementKey.FootingAt(p.NodeId)));
                res.AddRange(m.FootingDefs.Where(f => f.Kind == FootingKind.Filante).Select(f => ElementKey.Named(k, f.Name)));
                break;
            case ElementKind.Wall: res.AddRange(m.Walls.Select(w => ElementKey.Named(k, w.Name))); break;
            case ElementKind.Raft: res.AddRange(m.Rafts.Select(r => ElementKey.Named(k, r.Name))); break;
            case ElementKind.Ribbed: res.AddRange(m.RibbedFloors.Select(r => ElementKey.Named(k, r.Name))); break;
            case ElementKind.Shell: res.AddRange(m.Shells.Select(s => s.Name).Distinct().Select(n => ElementKey.Named(k, n))); break;
        }
        return res;
    }

    public static List<ElementKey> Everything(StructModel m, AnalysisOutput? o) =>
        ElementKinds.Order.SelectMany(k => All(m, o, k)).ToList();
}

/// <summary>État d'un élément après calcul et lien élément ↔ message : base des filtres « NON OK après calcul » et « avec messages »,
/// et de l'action « afficher les messages / résultats associés ».</summary>
public static class ElementStatus
{
    private static bool ExtraNotOk(AnalysisOutput o, string title) =>
        o.Extras.Any(x => !x.Ok && LabelIs(x.Title, title));

    /// <summary>Texte du module de calcul associé (escalier, voile, radier, plancher, semelle) ; "" s'il n'y en a pas.</summary>
    public static ExtraDesign? ExtraOf(AnalysisOutput? o, ElementKey k)
    {
        if (o == null) return null;
        string title = k.Kind switch
        {
            ElementKind.Stair => "Escalier " + k.Name, ElementKind.Wall => "Voile " + k.Name, ElementKind.Raft => "Radier " + k.Name,
            ElementKind.Ribbed => "Plancher " + k.Name, ElementKind.Footing => "Semelle " + (k.Id >= 0 ? "S" + k.Id : k.Name), _ => ""
        };
        if (title == "") return null;
        return o.Extras.FirstOrDefault(x => LabelIs(x.Title, title));
    }

    /// <summary>Vrai si le calcul a été fait ET que cet élément est NON OK. Sans résultat pour l'élément : faux (jamais deviné).</summary>
    public static bool NonOk(AnalysisOutput? o, ElementKey k)
    {
        if (o == null) return false;
        switch (k.Kind)
        {
            case ElementKind.Bar: return o.Members.Any(r => r.MemberId == k.Id && !r.Skipped && !r.Ok);
            case ElementKind.Slab: return o.Slabs.Any(s => !s.Ok && SlabNameOf(s.Element) == k.Name) || o.Punching.Any(p => !p.Ok && p.Slab == k.Name);
            case ElementKind.Footing:
                if (k.Id >= 0) return o.Footings.Any(f => !f.Ok && FootingPlacement.NodeIdOf(f.Element) == k.Id) || ExtraNotOk(o, "Semelle S" + k.Id);
                return ExtraNotOk(o, "Semelle " + k.Name);
            case ElementKind.Stair: return ExtraNotOk(o, "Escalier " + k.Name);
            case ElementKind.Wall: return ExtraNotOk(o, "Voile " + k.Name);
            case ElementKind.Raft: return ExtraNotOk(o, "Radier " + k.Name);
            case ElementKind.Ribbed: return ExtraNotOk(o, "Plancher " + k.Name);
            default: return false;
        }
    }

    private static string SlabNameOf(string? element)
    {
        var s = (element ?? "").Trim();
        if (!s.StartsWith("Dalle ", StringComparison.OrdinalIgnoreCase)) return "";
        var rest = s.Substring(6).Trim();
        int sp = rest.IndexOfAny(new[] { ' ', '(', ',' });
        return sp < 0 ? rest : rest.Substring(0, sp);
    }

    /// <summary>Le calcul a-t-il produit un résultat propre à cet élément ? (sinon on ne dit jamais « OK » à sa place)</summary>
    public static bool HasResult(AnalysisOutput? o, ElementKey k)
    {
        if (o == null) return false;
        switch (k.Kind)
        {
            case ElementKind.Bar: return o.Members.Any(r => r.MemberId == k.Id && !r.Skipped);
            case ElementKind.Slab: return o.Slabs.Any(s => SlabNameOf(s.Element) == k.Name);
            case ElementKind.Footing:
                if (k.Id >= 0) return o.Footings.Any(f => FootingPlacement.NodeIdOf(f.Element) == k.Id) || ExtraOf(o, k) != null;
                return ExtraOf(o, k) != null;
            case ElementKind.Stair: case ElementKind.Wall: case ElementKind.Raft: case ElementKind.Ribbed: return ExtraOf(o, k) != null;
            default: return false;
        }
    }

    /// <summary>Le libellé est exactement ce nom, ou ce nom suivi d'un espace ou d'une parenthèse (« Semelle S3 » ne correspond pas à « Semelle S30 »).</summary>
    private static bool LabelIs(string label, string name) =>
        label == name || label.StartsWith(name + " ", StringComparison.Ordinal) || label.StartsWith(name + "(", StringComparison.Ordinal);

    /// <summary>Ce message concerne-t-il cet élément ?</summary>
    public static bool Concerns(AppMessage msg, ElementKey k)
    {
        string lab = msg.ElementLabel ?? "";
        switch (k.Kind)
        {
            case ElementKind.Bar: return msg.MemberId == k.Id;
            case ElementKind.Node: return msg.NodeId == k.Id && msg.MemberId == null && msg.ElementKind != "Semelle";
            case ElementKind.Slab:
                return (msg.ElementKind == "Dalle" && (lab == "Dalle " + k.Name || SlabNameOf(lab) == k.Name))
                    || (msg.ElementKind == "Dalle / poteau" && lab.EndsWith("dalle " + k.Name, StringComparison.Ordinal));
            case ElementKind.Footing:
                if (k.Id >= 0) return (msg.ElementKind == "Semelle" && (msg.NodeId == k.Id || lab == "S" + k.Id)) || (msg.ElementKind == "Module" && LabelIs(lab, "Semelle S" + k.Id));
                return msg.ElementKind == "Module" && LabelIs(lab, "Semelle " + k.Name);
            case ElementKind.Stair: return msg.ElementKind == "Module" && LabelIs(lab, "Escalier " + k.Name);
            case ElementKind.Wall: return msg.ElementKind == "Module" && LabelIs(lab, "Voile " + k.Name);
            case ElementKind.Raft: return msg.ElementKind == "Module" && LabelIs(lab, "Radier " + k.Name);
            case ElementKind.Ribbed: return msg.ElementKind == "Module" && LabelIs(lab, "Plancher " + k.Name);
            case ElementKind.Shell: return msg.ElementKind == "Coque" && lab == "Coque " + k.Name;
            default: return false;
        }
    }

    /// <summary>Messages associés à l'élément (journal exclu : il ne désigne jamais un élément).</summary>
    public static List<AppMessage> MessagesOf(IEnumerable<AppMessage> all, ElementKey k) =>
        all.Where(q => q.Source != MsgSource.Journal && Concerns(q, k)).ToList();

    public static bool HasMessages(IEnumerable<AppMessage> all, ElementKey k) => all.Any(q => q.Source != MsgSource.Journal && Concerns(q, k));
}


/// <summary>Filtre global de sélection : familles à prendre (cases à cocher) et deux filtres communs à toutes les familles.</summary>
public sealed class ElementFilterSpec
{
    public bool Bars { get; set; } = true;
    public bool Nodes { get; set; }
    public bool Slabs { get; set; }
    public bool Stairs { get; set; }
    public bool Footings { get; set; }
    public bool Walls { get; set; }
    public bool Rafts { get; set; }
    public bool Ribbed { get; set; }
    public bool Shells { get; set; }
    /// <summary>« NON OK après calcul » : ne garde que les éléments dont le calcul est NON OK.</summary>
    public bool NonOkOnly { get; set; }
    /// <summary>« avec messages » : ne garde que les éléments auxquels un message se rapporte.</summary>
    public bool WithMessagesOnly { get; set; }

    public bool Has(ElementKind k) => k switch
    {
        ElementKind.Bar => Bars, ElementKind.Node => Nodes, ElementKind.Slab => Slabs, ElementKind.Stair => Stairs, ElementKind.Footing => Footings,
        ElementKind.Wall => Walls, ElementKind.Raft => Rafts, ElementKind.Ribbed => Ribbed, ElementKind.Shell => Shells, _ => false
    };

    public void Set(ElementKind k, bool v)
    {
        switch (k)
        {
            case ElementKind.Bar: Bars = v; break; case ElementKind.Node: Nodes = v; break; case ElementKind.Slab: Slabs = v; break;
            case ElementKind.Stair: Stairs = v; break; case ElementKind.Footing: Footings = v; break; case ElementKind.Wall: Walls = v; break;
            case ElementKind.Raft: Rafts = v; break; case ElementKind.Ribbed: Ribbed = v; break; case ElementKind.Shell: Shells = v; break;
        }
    }
}

/// <summary>Applique le filtre : une seule logique pour les barres (avec leurs critères détaillés) et pour tous les éléments surfaciques.</summary>
public static class ElementFilter
{
    public static List<ElementKey> Apply(StructModel m, AnalysisOutput? o, IReadOnlyCollection<AppMessage> msgs, SelectionFilterSpec barSpec, ElementFilterSpec spec,
                                         Func<ElementKey, bool>? hidden = null, IEnumerable<ElementKey>? restrictTo = null)
    {
        var only = restrictTo == null ? null : new HashSet<ElementKey>(restrictTo);
        var res = new List<ElementKey>();
        foreach (var kind in ElementKinds.Order)
        {
            if (!spec.Has(kind)) continue;
            IEnumerable<ElementKey> list;
            if (kind == ElementKind.Bar)
            {
                var baseIds = only?.Where(q => q.Kind == ElementKind.Bar).Select(q => q.Id);
                list = SelectionFilter.Apply(m, o, barSpec, baseIds).Select(ElementKey.Bar);
            }
            else list = ElementCatalog.All(m, o, kind);
            foreach (var k in list)
            {
                if (only != null && !only.Contains(k)) continue;
                if (hidden != null && hidden(k)) continue;
                if (spec.NonOkOnly && !ElementStatus.NonOk(o, k)) continue;
                if (spec.WithMessagesOnly && !ElementStatus.HasMessages(msgs, k)) continue;
                res.Add(k);
            }
        }
        return res;
    }

    /// <summary>Éléments NON OK après calcul (toutes familles) ou avec messages : base des commandes du menu Sélection.</summary>
    public static List<ElementKey> NonOk(StructModel m, AnalysisOutput? o) =>
        o == null ? new List<ElementKey>() : ElementCatalog.Everything(m, o).Where(k => ElementStatus.NonOk(o, k)).ToList();

    public static List<ElementKey> WithMessages(StructModel m, AnalysisOutput? o, IReadOnlyCollection<AppMessage> msgs) =>
        ElementCatalog.Everything(m, o).Where(k => ElementStatus.HasMessages(msgs, k)).ToList();
}
