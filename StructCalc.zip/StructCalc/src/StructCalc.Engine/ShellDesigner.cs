using System.Text;
using StructCalc.Core;
using StructCalc.Core.Model;

namespace StructCalc.Engine;

/// <summary>Dimensionnement indicatif des coques du modèle 3D (voiles et dalles maillés) : méthode de Wood-Armer pour la flexion, forces de membrane pour les voiles.
/// Résultats par groupe (nom), enveloppe des combinaisons ELU. À vérifier par l'ingénieur : le dimensionnement détaillé des voiles reste celui de l'assistant « Voiles en coques ».</summary>
public static class ShellDesigner
{
    /// <summary>Moments de calcul de Wood-Armer (kN.m/m) pour une face : le moment est positif lorsqu'il tend cette face.</summary>
    public static (double X, double Y) WoodArmer(double mx, double my, double mxy)
    {
        double t = Math.Abs(mxy);
        double ax = mx + t, ay = my + t;
        if (ax < 0) { ax = 0; ay = my + (mx != 0 ? mxy * mxy / Math.Abs(mx) : 0); }
        else if (ay < 0) { ay = 0; ax = mx + (my != 0 ? mxy * mxy / Math.Abs(my) : 0); }
        return (Math.Max(ax, 0), Math.Max(ay, 0));
    }

    /// <summary>Section d'acier (cm²/m) pour un moment ultime Mu (kN.m/m), flexion simple sans acier comprimé. over = true si la section béton est insuffisante.</summary>
    public static double AsFlexion(double mu, double d, double fc28, double fe, out bool over)
    {
        over = false;
        if (mu <= 1e-9) return 0;
        double fbu = 0.85 * fc28 / 1.5 * 1000.0;           // kN/m²
        double fsu = fe / 1.15 * 1000.0;
        double m = mu / (1.0 * d * d * fbu);
        if (m > 0.372) { over = true; m = 0.372; }
        double alpha = 1.25 * (1 - Math.Sqrt(1 - 2 * m));
        double z = d * (1 - 0.4 * alpha);
        return mu / (z * fsu) * 1e4;
    }

    private sealed class Acc
    {
        public string Kind = "";
        public int Count;
        public double T;
        public double AsX1, AsY1, AsX2, AsY2;               // flexion : face +n et face -n, directions locales 1 et 2 (cm²/m)
        public double AsMemX, AsMemY;                       // membrane : tirants (cm²/m, total des deux faces)
        public double SigC, MaxNxy, MaxM;
        public double Disp;
        public bool Over;
        public int IdAsX1, IdSig;
    }

    public static ExtraDesign? Compute(StructModel m, IReadOnlyList<Combination> combos, Dictionary<ActionType, CaseResult> cases)
    {
        if (m.Shells.Count == 0 || combos.Count == 0) return null;
        double fc = m.Fc28 > 0 ? m.Fc28 : 25, fe = m.Fe > 0 ? m.Fe : 500;
        double fsu = fe / 1.15 * 1000.0;                    // kN/m²
        double fbuMpa = 0.85 * fc / 1.5;
        var acc = new Dictionary<string, Acc>();
        var byGroup = m.Shells.GroupBy(s => s.Name).ToDictionary(g => g.Key, g => g.ToList());

        foreach (var kv in byGroup)
        {
            var a = new Acc { Kind = kv.Value[0].Kind, Count = kv.Value.Count, T = kv.Value[0].T };
            acc[kv.Key] = a;
            foreach (var sh in kv.Value)
            {
                double d = Math.Max(sh.T - 0.04, 0.05);
                foreach (var c in combos.Where(cb => cb.State != LimitState.ELS))
                {
                    var parts = new List<(double, ShellForces)>();
                    foreach (var f in c.Factors)
                        if (f.Value != 0 && cases.TryGetValue(f.Key, out var cr) && cr.Shells.TryGetValue(sh.Id, out var sf)) parts.Add((f.Value, sf));
                    if (parts.Count == 0) continue;
                    var s = ShellForces.Combine(parts);

                    var up = WoodArmer(s.Mx, s.My, s.Mxy);
                    var dn = WoodArmer(-s.Mx, -s.My, s.Mxy);
                    double ax1 = AsFlexion(up.X, d, fc, fe, out bool o1), ay1 = AsFlexion(up.Y, d, fc, fe, out bool o2);
                    double ax2 = AsFlexion(dn.X, d, fc, fe, out bool o3), ay2 = AsFlexion(dn.Y, d, fc, fe, out bool o4);
                    if (ax1 > a.AsX1) { a.AsX1 = ax1; a.IdAsX1 = sh.Id; }
                    a.AsY1 = Math.Max(a.AsY1, ay1); a.AsX2 = Math.Max(a.AsX2, ax2); a.AsY2 = Math.Max(a.AsY2, ay2);
                    a.Over |= o1 | o2 | o3 | o4;
                    a.MaxM = Math.Max(a.MaxM, Math.Max(Math.Abs(s.Mx), Math.Max(Math.Abs(s.My), Math.Abs(s.Mxy))));

                    // membrane : traction (Wood-Armer des efforts normaux) et compression principale
                    double nx = s.Nx + Math.Abs(s.Nxy), ny = s.Ny + Math.Abs(s.Nxy);
                    if (nx < 0) { nx = 0; ny = s.Ny + (s.Nx != 0 ? s.Nxy * s.Nxy / Math.Abs(s.Nx) : 0); }
                    else if (ny < 0) { ny = 0; nx = s.Nx + (s.Ny != 0 ? s.Nxy * s.Nxy / Math.Abs(s.Ny) : 0); }
                    a.AsMemX = Math.Max(a.AsMemX, Math.Max(nx, 0) / fsu * 1e4);
                    a.AsMemY = Math.Max(a.AsMemY, Math.Max(ny, 0) / fsu * 1e4);
                    double mean = (s.Nx + s.Ny) / 2, rad = Math.Sqrt(Math.Pow((s.Nx - s.Ny) / 2, 2) + s.Nxy * s.Nxy);
                    double sigC = Math.Max(0, -(mean - rad)) / sh.T / 1000.0;      // MPa, compression positive
                    if (sigC > a.SigC) { a.SigC = sigC; a.IdSig = sh.Id; }
                    a.MaxNxy = Math.Max(a.MaxNxy, Math.Abs(s.Nxy));
                }
            }
            // déplacement de service
            var ids = kv.Value.SelectMany(s => new[] { s.N1, s.N2, s.N3, s.N4 }).Distinct().ToList();
            foreach (var c in combos.Where(cb => cb.State == LimitState.ELS))
                foreach (int id in ids)
                {
                    double ux = 0, uy = 0, uz = 0;
                    foreach (var f in c.Factors)
                        if (f.Value != 0 && cases.TryGetValue(f.Key, out var cr) && cr.NodeDisp.TryGetValue(id, out var u)) { ux += f.Value * u[0]; uy += f.Value * u[1]; uz += f.Value * u[2]; }
                    double v = a.Kind == "Dalle" ? Math.Abs(uz) : Math.Sqrt(ux * ux + uy * uy);
                    a.Disp = Math.Max(a.Disp, v * 1000.0);
                }
        }

        var sb = new StringBuilder();
        sb.AppendLine("COQUES DU MODÈLE 3D (voiles et dalles maillés) : enveloppe des combinaisons ELU, méthode de Wood-Armer (indicatif)");
        sb.AppendLine("Convention : face +n = côté de la normale de l'élément (dalle : face supérieure) ; direction 1 = N1→N2 (voile : horizontale), direction 2 = N1→N4 (voile : verticale).");
        bool ok = true;
        foreach (var kv in acc)
        {
            var a = kv.Value;
            sb.AppendLine();
            sb.AppendLine($"{kv.Key} ({a.Kind}, e = {a.T * 100:0} cm, {a.Count} élément(s))");
            sb.AppendLine($"  Flexion  face +n : dir.1 {a.AsX1:0.00} cm²/m ; dir.2 {a.AsY1:0.00} cm²/m   |   face -n : dir.1 {a.AsX2:0.00} cm²/m ; dir.2 {a.AsY2:0.00} cm²/m");
            if (a.Kind == "Voile")
            {
                sb.AppendLine($"  Membrane (traction, total des 2 faces) : dir.1 {a.AsMemX:0.00} cm²/m ; dir.2 {a.AsMemY:0.00} cm²/m ; cisaillement max |nxy| = {a.MaxNxy:0} kN/m");
                string st = a.SigC <= fbuMpa ? "OK" : "NON VÉRIFIÉ";
                sb.AppendLine($"  Compression principale max = {a.SigC:0.00} MPa (limite {fbuMpa:0.0} MPa, élément {a.IdSig}) : {st}");
                if (a.SigC > fbuMpa) ok = false;
            }
            sb.AppendLine($"  Déplacement de service max = {a.Disp:0.0} mm ({(a.Kind == "Dalle" ? "flèche" : "déplacement horizontal")})");
            if (a.Over) { sb.AppendLine("  ⚠ Moment trop élevé pour une section simplement armée : augmenter l'épaisseur ou prévoir des aciers comprimés."); ok = false; }
        }
        sb.AppendLine();
        sb.AppendLine("Sections minimales, dispositions constructives et vérification au flambement/ductilité (RPA 99 art. 7.7, EC8) : à vérifier séparément.");
        return new ExtraDesign { Title = "Coques : voiles et dalles maillés", Text = sb.ToString(), Ok = ok };
    }
}
