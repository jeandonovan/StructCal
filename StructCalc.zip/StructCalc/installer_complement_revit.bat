@echo off
chcp 65001 >nul
title StructCalc - Installation du complement Revit 2025
echo ===============================================================
echo  Installation du complement StructCalc pour Revit 2025
echo  FERMEZ REVIT avant de continuer.
echo  (installer d'abord StructCalc, puis le lancer UNE FOIS : il memorise son emplacement)
echo ===============================================================
pause
set "DEST=%APPDATA%\Autodesk\Revit\Addins\2025"
if not exist "%DEST%" mkdir "%DEST%"
if not exist "%DEST%\StructCalc" mkdir "%DEST%\StructCalc"
copy /y "%~dp0StructCalc\*.dll" "%DEST%\StructCalc\" >nul
if errorlevel 1 goto err
copy /y "%~dp0StructCalc.addin" "%DEST%\" >nul
if errorlevel 1 goto err
echo.
echo OK. Ouvrez Revit 2025 : onglet Complements ^> StructCalc.
echo (Si Revit demande de charger le complement, choisissez "Toujours charger".)
goto fin
:err
echo ERREUR de copie : verifiez que Revit est ferme et que ce dossier est complet.
:fin
pause
