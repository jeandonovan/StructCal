@echo off
chcp 65001 >nul
title Installation d'Inno Setup 6 (outil gratuit pour creer Setup.exe)
set ISCC=
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set ISCC=%%~P
if defined ISCC (
  echo Inno Setup 6 est deja installe : %ISCC%
  goto fin
)
echo [1/2] Installation via winget...
winget install --id JRSoftware.InnoSetup -e --silent --accept-package-agreements --accept-source-agreements
set ISCC=
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set ISCC=%%~P
if defined ISCC goto ok
echo [2/2] Telechargement direct depuis jrsoftware.org...
powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://jrsoftware.org/download.php/is.exe' -OutFile '%TEMP%\innosetup.exe'"
if not exist "%TEMP%\innosetup.exe" goto manuel
"%TEMP%\innosetup.exe" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART
set ISCC=
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do if exist %%P set ISCC=%%~P
if defined ISCC goto ok
:manuel
echo Installation automatique impossible. Telechargez et installez manuellement : https://jrsoftware.org/isdl.php
goto fin
:ok
echo Inno Setup 6 installe : %ISCC%
:fin
echo.
pause
